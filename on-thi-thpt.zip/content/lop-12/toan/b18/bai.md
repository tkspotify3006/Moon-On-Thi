---
title: Xác suất có điều kiện
thoi-gian: 50 phút
muc-tieu:
  - Hiểu xác suất có điều kiện $P(A\mid B)$ là xác suất của $A$ được tính lại khi đã biết $B$ xảy ra, và tính được nó bằng cách đếm trên "không gian thu gọn" hoặc bằng công thức $P(A\mid B)=\dfrac{P(AB)}{P(B)}$
  - Nhận biết mối liên hệ giữa xác suất có điều kiện và xác suất, đặc biệt là với hai biến cố độc lập ($P(A\mid B)=P(A)$), và phân biệt rõ $P(A\mid B)$ với $P(B\mid A)$
  - Đọc bảng dữ liệu thống kê $2\times2$ (khảo sát, thử nghiệm thuốc, xét nghiệm y tế) để tính và giải thích ý nghĩa của xác suất có điều kiện
  - Vận dụng công thức nhân xác suất $P(AB)=P(B)\cdot P(A\mid B)$ cho hai biến cố bất kì, đặc biệt trong bài toán lấy lần lượt không hoàn lại
  - Vẽ và dùng sơ đồ hình cây để tổ chức lời giải, giải thích lời khuyên trong trò chơi "Ô cửa bí mật"
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. $P(A\mid B)$ là xác suất của $A$ **khi đã biết** $B$ xảy ra. Biết $B$ xảy ra thì "thế giới" thu nhỏ lại chỉ còn $B$, nên với kết quả đồng khả năng: $P(A\mid B)=\dfrac{n(AB)}{n(B)}$.
> 2. Công thức tổng quát (với $P(B)>0$): $P(A\mid B)=\dfrac{P(AB)}{P(B)}$.
> 3. **Công thức nhân xác suất** (đúng với mọi $A$, $B$): $P(AB)=P(B)\cdot P(A\mid B)=P(A)\cdot P(B\mid A)$.
> 4. $A$, $B$ độc lập ($P(A)>0$, $P(B)>0$) thì $P(A\mid B)=P(A)$ và $P(B\mid A)=P(B)$: biết thêm thông tin về $B$ không làm thay đổi khả năng xảy ra $A$.
> 5. **Sơ đồ hình cây**: nhánh đầu ghi xác suất thường, nhánh sau ghi xác suất có điều kiện. Xác suất một đường đi = **tích** các số trên đường đó. Nhớ: nói chung $P(A\mid B)\ne P(B\mid A)$.

Hôm nay trời nắng thì khả năng mai mưa là bao nhiêu? Một người đã sống đến 60 tuổi thì khả năng sống đến 80 tuổi là bao nhiêu (các công ty bảo hiểm rất cần con số này)? Một người có kết quả xét nghiệm dương tính thì khả năng người đó thật sự mắc bệnh là bao nhiêu? Trong cả ba câu hỏi, ta **đã biết thêm một thông tin**, và muốn **cập nhật** lại xác suất cho phù hợp. Đó chính là xác suất có điều kiện — chủ đề mở đầu Chương VI, nền móng cho công thức xác suất toàn phần và công thức Bayes ở Bài 19.

SGK mở đầu bài bằng trò chơi truyền hình "Ô cửa bí mật" (SGK tr. 64): có ba cánh cửa, sau một cửa là ô tô, sau hai cửa còn lại là con lừa. Người chơi chọn một cửa (chưa mở). Người quản trò, **biết** ô tô ở đâu, mở một cửa có lừa trong hai cửa còn lại, rồi hỏi: *giữ nguyên lựa chọn hay đổi sang cửa còn lại?* Hầu hết mọi người nghĩ "còn hai cửa thì mỗi cửa $\frac12$, đổi hay không như nhau". Cuối bài em sẽ thấy câu trả lời đúng khác hẳn.

> [!nen-tang] Nhắc lại lớp 10–11
> - **Phép thử, không gian mẫu** $\Omega$: tập mọi kết quả có thể. **Biến cố** $A$ là một tập con của $\Omega$.
> - **Xác suất cổ điển** (lớp 10): nếu các kết quả đồng khả năng thì $P(A)=\dfrac{n(A)}{n(\Omega)}$, với $n(A)$ là số kết quả thuận lợi cho $A$.
> - **Biến cố giao** $AB$ (hay $A\cap B$): "cả $A$ và $B$ cùng xảy ra". **Biến cố hợp** $A\cup B$: "ít nhất một trong hai xảy ra".
> - **Biến cố đối** $\overline{A}$: "$A$ không xảy ra", $P(\overline{A})=1-P(A)$.
> - **Công thức cộng** (lớp 11): $P(A\cup B)=P(A)+P(B)-P(AB)$. Nếu $A$, $B$ **xung khắc** ($AB=\varnothing$) thì $P(A\cup B)=P(A)+P(B)$.
> - **Hai biến cố độc lập** (lớp 11): việc xảy ra hay không của biến cố này không ảnh hưởng đến xác suất của biến cố kia. Khi đó $P(AB)=P(A)\cdot P(B)$, và các cặp $\overline{A}$ và $B$, $A$ và $\overline{B}$, $\overline{A}$ và $\overline{B}$ cũng độc lập.
> - **Quy tắc nhân** khi đếm: lấy lần lượt 2 viên bi không hoàn lại từ 10 viên thì có $10\cdot9=90$ cách (có thứ tự).

## 1. Xác suất có điều kiện

### 1.1. Ý tưởng: thông tin mới làm "thu gọn" không gian mẫu

Xét một ví dụ thật đơn giản. Một hộp có 12 tấm thẻ đánh số từ $1$ đến $12$, rút ngẫu nhiên một thẻ. Gọi $A$: "số trên thẻ chia hết cho $3$". Có $4$ thẻ ($3,6,9,12$) nên $P(A)=\dfrac{4}{12}=\dfrac13$.

Bây giờ, người rút thẻ liếc nhìn và nói: "*Thẻ của tôi mang số chẵn.*" Gọi $B$ là biến cố "thẻ mang số chẵn". Khi đã biết $B$ xảy ra, các thẻ lẻ **không còn khả năng** nào nữa. Kết quả chỉ có thể là một trong $6$ thẻ $2,4,6,8,10,12$, và vì lúc đầu 12 thẻ đồng khả năng nên $6$ thẻ này vẫn đồng khả năng. Trong $6$ thẻ đó, có $2$ thẻ chia hết cho $3$ (là $6$ và $12$, tức là các kết quả của $AB$). Vậy xác suất của $A$ **khi đã biết** $B$ xảy ra là $\dfrac26=\dfrac13$.

![Hình 1. Biết thẻ mang số chẵn, "không gian mẫu" thu gọn lại chỉ còn 6 thẻ chẵn. Xác suất của A được tính lại trên 6 thẻ đó](h1-khong-gian-thu-gon.svg)

Ở ví dụ này, kết quả tình cờ bằng $P(A)$. Nhưng nếu người kia nói "*số trên thẻ của tôi lớn hơn $8$*" thì thẻ chỉ còn là $9,10,11,12$, trong đó có $2$ thẻ chia hết cho $3$, nên xác suất của $A$ được cập nhật thành $\dfrac24=\dfrac12$ — **lớn hơn** $\dfrac13$. Thông tin mới có thể làm xác suất tăng, giảm hoặc giữ nguyên.

Ý chính cần nhớ: **biết $B$ đã xảy ra thì $B$ trở thành "không gian mẫu mới"** (gọi là *không gian thu gọn*), và $A$ chỉ còn xảy ra được ở phần chung $AB$.

### 1.2. Định nghĩa và công thức tính

> [!ghi-nho] Định nghĩa (SGK tr. 65)
> Cho hai biến cố $A$ và $B$. Xác suất của $A$ được tính **khi biết $B$ đã xảy ra** gọi là **xác suất của $A$ với điều kiện $B$**, kí hiệu $P(A\mid B)$ (đọc là "xác suất của $A$ khi biết $B$").

> [!ghi-nho] Công thức (SGK tr. 65)
> Với hai biến cố $A$, $B$ bất kì và $P(B)>0$:
> $$P(A\mid B)=\dfrac{P(AB)}{P(B)}.$$
> Khi các kết quả đồng khả năng, công thức trở thành $P(A\mid B)=\dfrac{n(AB)}{n(B)}$.

**Vì sao lại là công thức này?** Khi các kết quả đồng khả năng, ta vừa thấy ở mục 1.1: không gian thu gọn là $B$ (có $n(B)$ kết quả), các kết quả thuận lợi là $AB$. Do đó
$$\begin{aligned}P(A\mid B)&=\dfrac{n(AB)}{n(B)}=\dfrac{n(AB)/n(\Omega)}{n(B)/n(\Omega)}\\&=\dfrac{P(AB)}{P(B)}.\end{aligned}$$
Chia cả tử và mẫu cho $n(\Omega)$ để chuyển từ "đếm" sang "xác suất". Dạng $\dfrac{P(AB)}{P(B)}$ dùng được cả khi không đếm được kết quả (ví dụ khi chỉ biết các tỉ lệ phần trăm).

Như vậy em có **hai cách** tính $P(A\mid B)$:

- **Cách 1 — Theo định nghĩa (đếm trên không gian thu gọn):** hình dung $B$ đã xảy ra, tình huống còn lại ra sao, rồi tính xác suất của $A$ trong tình huống đó. Rất nhanh với bài lấy bi, rút thẻ.
- **Cách 2 — Theo công thức:** tính $P(AB)$ và $P(B)$ rồi chia. Dùng khi đề cho sẵn các xác suất hoặc khi khó hình dung tình huống.

> [!ghi-nho] Mấy tính chất nên nhớ
> - $0\le P(A\mid B)\le1$, vì $AB$ là một phần của $B$.
> - $P(\overline{A}\mid B)=1-P(A\mid B)$: trong không gian thu gọn $B$, "$A$ xảy ra" và "$A$ không xảy ra" vẫn là hai biến cố đối nhau.
> - $P(B\mid B)=1$. Nếu $A$ và $B$ xung khắc thì $P(A\mid B)=0$.
> - **Nói chung $P(A\mid B)\ne P(B\mid A)$**: hai xác suất có cùng tử số $P(AB)$ nhưng khác mẫu số ($P(B)$ so với $P(A)$).

> [!vi-du] Ví dụ 1
> Một hộp có $6$ viên bi đỏ và $4$ viên bi xanh, các viên bi cùng kích thước và khối lượng. Bạn Minh lấy ngẫu nhiên một viên bi, không trả lại vào hộp. Sau đó bạn Lan lấy ngẫu nhiên một viên trong các viên bi còn lại. Gọi $A$: "Lan lấy được bi đỏ", $B$: "Minh lấy được bi đỏ".
>
> a) Tính $P(A\mid B)$ bằng cả hai cách.
>
> b) Tính $P(A\mid\overline{B})$.

> [!goi-y] Gợi ý 1
> Cách 1: nếu Minh đã lấy được bi đỏ thì trong hộp còn bao nhiêu viên, mấy viên đỏ?

> [!goi-y] Gợi ý 2
> Cách 2: đếm có thứ tự. Minh có $10$ cách chọn, Lan có $9$ cách, nên $n(\Omega)=10\cdot9$. Đếm $n(B)$ (Minh lấy đỏ, Lan lấy tùy ý) và $n(AB)$ (cả hai lấy đỏ).

> [!loi-giai] Lời giải
> a) **Cách 1 (định nghĩa).** Nếu $B$ xảy ra, trong hộp còn $9$ viên gồm $5$ đỏ và $4$ xanh. Lan lấy ngẫu nhiên một viên nên $P(A\mid B)=\dfrac59$.
>
> **Cách 2 (công thức).** $n(\Omega)=10\cdot9=90$. Minh lấy đỏ có $6$ cách, Lan lấy viên bất kì trong $9$ viên còn lại: $n(B)=6\cdot9=54$. Cả hai lấy đỏ: $n(AB)=6\cdot5=30$. Vậy
> $$P(A\mid B)=\dfrac{P(AB)}{P(B)}=\dfrac{n(AB)}{n(B)}=\dfrac{30}{54}=\dfrac59.$$
>
> b) $\overline{B}$: "Minh lấy được bi xanh". Khi đó trong hộp còn $9$ viên gồm $6$ đỏ, $3$ xanh, nên $P(A\mid\overline{B})=\dfrac69=\dfrac23$.
>
> Nhận xét: việc Minh lấy bi gì **ảnh hưởng** đến khả năng Lan lấy được bi đỏ ($\frac59$ so với $\frac23$), vì bi không được trả lại.

> [!vi-du] Ví dụ 2
> Gieo hai con xúc xắc cân đối, đồng chất.
>
> a) Tính xác suất để có ít nhất một con xuất hiện mặt $6$ chấm, biết rằng tổng số chấm bằng $8$.
>
> b) Tính xác suất để tổng số chấm bằng $8$, biết rằng có ít nhất một con xuất hiện mặt $6$ chấm.

> [!goi-y] Gợi ý 1
> Không gian mẫu có $36$ kết quả $(i;j)$ đồng khả năng. Câu a: không gian thu gọn là các cặp có tổng bằng $8$. Liệt kê chúng ra.

> [!goi-y] Gợi ý 2
> Câu b: không gian thu gọn là các cặp có ít nhất một số $6$. Có $6+6-1=11$ cặp (đừng đếm cặp $(6;6)$ hai lần).

> [!loi-giai] Lời giải
> Gọi $A$: "có ít nhất một mặt $6$ chấm", $B$: "tổng số chấm bằng $8$".
>
> a) $B=\{(2;6),(3;5),(4;4),(5;3),(6;2)\}$, $n(B)=5$. Trong đó có $2$ cặp chứa số $6$, tức $n(AB)=2$. Vậy $P(A\mid B)=\dfrac25$.
>
> b) $A$ gồm $6$ cặp có con thứ nhất ra $6$ và $6$ cặp có con thứ hai ra $6$, trừ cặp $(6;6)$ bị đếm hai lần: $n(A)=11$. Trong đó chỉ có $(2;6)$ và $(6;2)$ có tổng bằng $8$. Vậy $P(B\mid A)=\dfrac{2}{11}$.
>
> Hai câu có cùng "phần chung" $AB$ ($2$ kết quả) nhưng **khác không gian thu gọn**, nên $P(A\mid B)=\dfrac25\ne\dfrac2{11}=P(B\mid A)$.

> [!bay] Đọc đúng "điều kiện" trong đề
> - Cụm "**biết rằng** …", "**nếu** …", "**trong số những** …", "**khi** …" chỉ ra biến cố **điều kiện** — biến cố đứng **sau** dấu "$\mid$". Biến cố cần tính xác suất đứng **trước** dấu "$\mid$".
> - Với $A$: "bị bệnh", $B$: "hút thuốc": "xác suất để người đó **hút thuốc và** bị bệnh" là $P(AB)$ (chia cho **cả** tổng thể). "Xác suất để người đó bị bệnh, **biết** người đó hút thuốc" là $P(A\mid B)$ (chỉ chia cho **số người hút thuốc**). Hai câu chỉ khác vài chữ nhưng đáp số khác hẳn.
> - Nhầm $P(A\mid B)$ với $P(B\mid A)$ là lỗi phổ biến nhất của bài này, và cũng là "bẫy" yêu thích của đề Đúng/Sai.

### 1.3. Xác suất có điều kiện và tính độc lập

Ở lớp 11, $A$ và $B$ độc lập nghĩa là việc $B$ xảy ra hay không **không ảnh hưởng** đến xác suất của $A$. Bây giờ ta có ngôn ngữ để nói điều đó chính xác: "xác suất của $A$ khi biết $B$" bằng "xác suất của $A$" lúc chưa biết gì.

> [!ghi-nho] Độc lập ⇔ thông tin không làm thay đổi xác suất (SGK tr. 66)
> Nếu $A$ và $B$ độc lập, $P(A)>0$, $P(B)>0$ thì
> $$P(A\mid B)=P(A)\quad\text{và}\quad P(B\mid A)=P(B).$$
> Hơn nữa, do các cặp biến cố đối cũng độc lập: $P(\overline{A}\mid B)=P(\overline{A})$, $P(A\mid\overline{B})=P(A)$.

**Chứng minh bằng công thức.** $A$, $B$ độc lập nên $P(AB)=P(A)P(B)$. Do đó $P(A\mid B)=\dfrac{P(A)P(B)}{P(B)}=P(A)$, tương tự $P(B\mid A)=\dfrac{P(B)P(A)}{P(A)}=P(B)$.

Ngược lại, nếu $P(B)>0$ và $P(A\mid B)=P(A)$ thì $P(AB)=P(B)\cdot P(A\mid B)=P(A)P(B)$, nên $A$, $B$ độc lập. Vì vậy, muốn **kiểm tra hai biến cố có độc lập không**, em có thể so sánh $P(A\mid B)$ với $P(A)$.

> [!vi-du] Ví dụ 3
> Gieo một con xúc xắc cân đối. Gọi $A$: "số chấm chẵn", $B$: "số chấm không vượt quá $4$", $C$: "số chấm không vượt quá $3$". Tính $P(A\mid B)$, $P(A\mid C)$ rồi cho biết $A$ có độc lập với $B$ không, có độc lập với $C$ không.

> [!goi-y] Gợi ý 1
> $P(A)=\dfrac36=\dfrac12$. Không gian thu gọn ứng với $B$ là $\{1;2;3;4\}$, ứng với $C$ là $\{1;2;3\}$.

> [!goi-y] Gợi ý 2
> So sánh từng xác suất có điều kiện với $P(A)=\dfrac12$.

> [!loi-giai] Lời giải
> - Biết $B$: kết quả thuộc $\{1;2;3;4\}$, có $2$ số chẵn, nên $P(A\mid B)=\dfrac24=\dfrac12=P(A)$. Vậy $A$ và $B$ **độc lập**. (Kiểm tra: $P(AB)=\dfrac26=\dfrac13=\dfrac12\cdot\dfrac46=P(A)P(B)$.)
> - Biết $C$: kết quả thuộc $\{1;2;3\}$, chỉ có số $2$ là chẵn, nên $P(A\mid C)=\dfrac13\ne\dfrac12$. Vậy $A$ và $C$ **không độc lập**.
>
> Ví dụ cho thấy độc lập là chuyện **về con số xác suất**, không phải chuyện "hai sự việc có vẻ liên quan nhau hay không".

> [!bay] Độc lập khác xung khắc
> - **Xung khắc**: $A$ và $B$ không thể cùng xảy ra, $P(AB)=0$. Khi đó, nếu $P(B)>0$ thì $P(A\mid B)=0$: biết $B$ xảy ra là chắc chắn $A$ không xảy ra, tức $B$ ảnh hưởng **rất mạnh** đến $A$.
> - Vì vậy hai biến cố xung khắc (với xác suất dương) **không bao giờ** độc lập. Đừng nhầm "không liên quan" (độc lập) với "không cùng xảy ra" (xung khắc).

### 1.4. Bảng dữ liệu thống kê 2 × 2

Trong y học, xã hội học, giáo dục…, người ta thường khảo sát một nhóm người theo **hai đặc điểm**, mỗi đặc điểm có hai khả năng (có/không). Kết quả được xếp vào một bảng gồm 2 dòng và 2 cột, gọi là **bảng dữ liệu thống kê $2\times2$** (SGK tr. 66). Chọn ngẫu nhiên một người trong nhóm thì các xác suất có điều kiện đọc được ngay từ bảng.

**Cách đọc bảng nhanh:**

1. **Thêm dòng "Tổng" và cột "Tổng"** (cộng từng hàng, từng cột). Đây là bước quan trọng nhất.
2. $P(A\mid B)$: điều kiện $B$ ứng với một hàng (hoặc một cột). Lấy **ô giao** của $A$ và $B$ chia cho **tổng của hàng (cột) $B$** — không chia cho tổng chung.
3. $P(AB)$, $P(A)$, $P(B)$: chia cho **tổng chung**.

> [!vi-du] Ví dụ 4
> Một trường khảo sát $600$ học sinh lớp 12 về thời gian ngủ mỗi đêm trong tháng trước kì thi thử và kết quả môn Toán của kì thi đó:
>
> | | Toán từ 8 điểm | Toán dưới 8 điểm |
> |---|---|---|
> | Ngủ đủ (từ 7 giờ) | 150 | 210 |
> | Ngủ không đủ | 60 | 180 |
>
> Chọn ngẫu nhiên một học sinh trong số này.
>
> a) Tính xác suất học sinh đó đạt Toán từ $8$ điểm, biết rằng học sinh đó ngủ đủ.
>
> b) Tính xác suất học sinh đó đạt Toán từ $8$ điểm, biết rằng học sinh đó ngủ không đủ.
>
> c) Biết học sinh được chọn đạt Toán từ $8$ điểm, tính xác suất học sinh đó ngủ đủ. So sánh với câu a.

> [!goi-y] Gợi ý 1
> Thêm cột tổng: hàng "ngủ đủ" có $150+210=360$ học sinh, hàng "ngủ không đủ" có $240$. Thêm dòng tổng: cột "từ 8 điểm" có $150+60=210$ học sinh.

> [!goi-y] Gợi ý 2
> Câu a, b: điều kiện là một **hàng**, chia cho tổng hàng. Câu c: điều kiện là một **cột**, chia cho tổng cột.

> [!loi-giai] Lời giải
> Gọi $A$: "đạt Toán từ $8$ điểm", $B$: "ngủ đủ". Bảng có thêm tổng:
>
> | | Từ 8 điểm ($A$) | Dưới 8 điểm | Tổng |
> |---|---|---|---|
> | Ngủ đủ ($B$) | 150 | 210 | 360 |
> | Ngủ không đủ ($\overline{B}$) | 60 | 180 | 240 |
> | Tổng | 210 | 390 | 600 |
>
> a) $P(A\mid B)=\dfrac{n(AB)}{n(B)}=\dfrac{150}{360}=\dfrac{5}{12}\approx0{,}417$.
>
> b) $P(A\mid\overline{B})=\dfrac{n(A\overline{B})}{n(\overline{B})}=\dfrac{60}{240}=\dfrac14=0{,}25$.
>
> c) $P(B\mid A)=\dfrac{n(AB)}{n(A)}=\dfrac{150}{210}=\dfrac57\approx0{,}714$. Con số này khác hẳn câu a: trong số học sinh **ngủ đủ**, khoảng $41{,}7\%$ đạt từ 8 điểm. Còn trong số học sinh **đạt từ 8 điểm**, khoảng $71{,}4\%$ là người ngủ đủ.
>
> Ý nghĩa: $\dfrac{P(A\mid B)}{P(A\mid\overline{B})}=\dfrac{5/12}{1/4}=\dfrac53\approx1{,}67$. Trong nhóm được khảo sát, tỉ lệ đạt từ 8 điểm ở học sinh ngủ đủ cao gấp khoảng $1{,}67$ lần ở học sinh ngủ không đủ.

> [!em-co-biet] Liên quan chưa chắc là nguyên nhân
> Ví dụ 4 cho thấy "ngủ đủ" và "điểm cao" có liên quan (không độc lập). Nhưng bảng $2\times2$ **chưa chứng minh** được ngủ đủ **làm cho** điểm cao: có thể những bạn học đều đặn, ít thức khuya ôn dồn thì vừa ngủ đủ vừa điểm cao. Muốn kết luận về nguyên nhân, nhà khoa học phải làm **thử nghiệm có đối chứng** (như thử thuốc: chia ngẫu nhiên bệnh nhân vào hai nhóm). Ví dụ trong SGK tr. 66–67 về **dây an toàn** dùng dữ liệu hơn $577\,000$ vụ tai nạn: tỉ lệ tử vong của người lái **không** thắt dây an toàn cao gấp khoảng $7{,}9$ lần người có thắt — em nên đọc để thấy xác suất có điều kiện "nói" được điều quan trọng thế nào.

## 2. Công thức nhân xác suất

### 2.1. Công thức

Từ $P(A\mid B)=\dfrac{P(AB)}{P(B)}$, nhân hai vế với $P(B)$ ta được ngay $P(AB)=P(B)\cdot P(A\mid B)$. Nếu $P(B)=0$ thì $P(AB)=0$ (vì $AB$ nằm trong $B$), nên đẳng thức vẫn đúng. Đổi vai $A$ và $B$ (vì $AB=BA$) ta có dạng thứ hai.

> [!ghi-nho] Công thức nhân xác suất (SGK tr. 68)
> Với hai biến cố $A$, $B$ **bất kì**:
> $$P(AB)=P(B)\cdot P(A\mid B)=P(A)\cdot P(B\mid A).$$
> Đọc thành lời: **xác suất để cả hai cùng xảy ra = xác suất của biến cố thứ nhất × xác suất của biến cố thứ hai khi biết biến cố thứ nhất đã xảy ra.**

**Vì sao cần công thức này?** Công thức $P(A\mid B)=\dfrac{P(AB)}{P(B)}$ dùng khi đã biết $P(AB)$. Nhưng trong nhiều bài, điều **dễ biết** lại là xác suất có điều kiện (lấy bi không hoàn lại: biết lần đầu ra gì thì lần sau dễ tính), còn $P(AB)$ mới là điều cần tìm. Công thức nhân đi theo đúng "thứ tự thời gian" của sự việc: việc đầu xảy ra, rồi việc sau xảy ra **trong điều kiện** việc đầu đã xảy ra.

> [!nen-tang] So sánh với lớp 11
> Lớp 11 em học $P(AB)=P(A)\cdot P(B)$ — công thức này **chỉ đúng khi $A$, $B$ độc lập**. Công thức nhân xác suất ở đây là **tổng quát**: khi $A$, $B$ độc lập thì $P(B\mid A)=P(B)$ và nó trở về công thức lớp 11.

> [!vi-du] Ví dụ 5
> Một hộp có $10$ phiếu bốc thăm, trong đó có $3$ phiếu trúng thưởng. Bạn Hà bốc lần lượt $2$ phiếu, không trả lại phiếu đã bốc.
>
> a) Tính xác suất để cả hai phiếu đều trúng thưởng.
>
> b) Tính xác suất để phiếu thứ nhất không trúng và phiếu thứ hai trúng.

> [!goi-y] Gợi ý 1
> Gọi $T_1$: "phiếu thứ nhất trúng", $T_2$: "phiếu thứ hai trúng". Câu a cần $P(T_1T_2)=P(T_1)\cdot P(T_2\mid T_1)$.

> [!goi-y] Gợi ý 2
> Nếu phiếu thứ nhất trúng thì trong hộp còn $9$ phiếu, trong đó có $2$ phiếu trúng.

> [!loi-giai] Lời giải
> a) $P(T_1)=\dfrac{3}{10}$. Biết $T_1$ xảy ra, hộp còn $9$ phiếu với $2$ phiếu trúng, nên $P(T_2\mid T_1)=\dfrac29$. Theo công thức nhân:
> $$P(T_1T_2)=\dfrac{3}{10}\cdot\dfrac29=\dfrac{1}{15}.$$
> b) $P(\overline{T_1})=\dfrac{7}{10}$. Biết phiếu đầu không trúng, hộp còn $9$ phiếu với **cả $3$** phiếu trúng: $P(T_2\mid\overline{T_1})=\dfrac39$. Vậy
> $$P(\overline{T_1}T_2)=\dfrac{7}{10}\cdot\dfrac39=\dfrac{7}{30}.$$
> Kiểm tra câu a bằng tổ hợp: chọn $2$ phiếu trong $10$ phiếu có $C_{10}^2=45$ cách, chọn $2$ phiếu trúng trong $3$ phiếu có $C_3^2=3$ cách: $\dfrac{3}{45}=\dfrac1{15}$, khớp kết quả.

> [!meo] Nhiều lần lấy liên tiếp: nhân dây chuyền
> Công thức nhân mở rộng được cho ba biến cố:
> $$P(ABC)=P(A)\cdot P(B\mid A)\cdot P(C\mid AB).$$
> Lấy lần lượt **không hoàn lại**, em chỉ việc viết tích các phân số, mỗi lần **tử và mẫu giảm theo** những gì đã lấy ra. Ví dụ: hộp $5$ đỏ, $3$ xanh, lấy lần lượt $3$ viên không hoàn lại, xác suất cả ba đỏ là $\dfrac58\cdot\dfrac47\cdot\dfrac36=\dfrac{5}{28}$.

> [!vi-du] Ví dụ 6
> Ở một trường THPT, $60\%$ học sinh tham gia câu lạc bộ thể thao. Trong số học sinh tham gia câu lạc bộ thể thao, có $30\%$ tham gia thêm câu lạc bộ âm nhạc. Chọn ngẫu nhiên một học sinh của trường.
>
> a) Tính xác suất học sinh đó tham gia cả hai câu lạc bộ.
>
> b) Biết rằng $25\%$ học sinh của trường tham gia câu lạc bộ âm nhạc. Tính xác suất học sinh được chọn tham gia câu lạc bộ thể thao, biết học sinh đó tham gia câu lạc bộ âm nhạc.

> [!goi-y] Gợi ý 1
> Gọi $T$: "tham gia CLB thể thao", $N$: "tham gia CLB âm nhạc". Câu "trong số học sinh tham gia thể thao, có $30\%$…" cho biết $P(N\mid T)=0{,}3$, **không phải** $P(N)$.

> [!goi-y] Gợi ý 2
> Câu b cần $P(T\mid N)=\dfrac{P(TN)}{P(N)}$, trong đó $P(TN)$ đã tính ở câu a.

> [!loi-giai] Lời giải
> a) $P(T)=0{,}6$, $P(N\mid T)=0{,}3$. Theo công thức nhân: $P(TN)=P(T)\cdot P(N\mid T)=0{,}6\cdot0{,}3=0{,}18$.
>
> b) $P(N)=0{,}25$, nên $P(T\mid N)=\dfrac{P(TN)}{P(N)}=\dfrac{0{,}18}{0{,}25}=0{,}72$.
>
> Nhận xét: $P(N\mid T)=0{,}3$ nhưng $P(T\mid N)=0{,}72$ — lại một lần nữa, đổi chỗ hai biến cố thì xác suất có điều kiện thay đổi.

### 2.2. Sơ đồ hình cây

Khi phép thử gồm **nhiều bước nối tiếp** (lấy lần 1 rồi lần 2, hôm nay rồi ngày mai…), ta tổ chức lời giải bằng **sơ đồ hình cây** (SGK tr. 69):

- Từ gốc, vẽ các **nhánh cấp 1** ứng với các khả năng của bước 1, ghi trên mỗi nhánh **xác suất** của khả năng đó.
- Từ mỗi nút, vẽ các **nhánh cấp 2** ứng với các khả năng của bước 2, ghi trên nhánh **xác suất có điều kiện** (khi đã biết kết quả bước 1 là nút đó).
- **Tổng các số trên những nhánh xuất phát từ cùng một nút bằng $1$** (dùng để tự kiểm tra hoặc điền số còn thiếu).
- **Xác suất của một đường đi** từ gốc đến ngọn = **tích** các số trên đường đó (chính là công thức nhân).
- Nếu biến cố cần tính gồm **nhiều đường đi** thì **cộng** xác suất các đường đó (các đường đi là các biến cố xung khắc).

> [!vi-du] Ví dụ 7
> Theo thống kê nhiều năm ở một vùng vào tháng 6: nếu hôm nay mưa thì ngày mai mưa với xác suất $0{,}6$; nếu hôm nay không mưa thì ngày mai mưa với xác suất $0{,}25$. Dự báo cho biết xác suất hôm nay có mưa là $0{,}3$. Tính xác suất để:
>
> a) Cả hôm nay và ngày mai đều mưa.
>
> b) Cả hai ngày đều không mưa.
>
> c) Trong hai ngày có đúng một ngày mưa.

> [!goi-y] Gợi ý 1
> Bước 1: hôm nay mưa ($0{,}3$) hay không ($0{,}7$). Bước 2: ngày mai. Điền nốt các nhánh: nếu hôm nay mưa thì mai **không** mưa với xác suất $1-0{,}6=0{,}4$, tương tự nhánh còn lại là $0{,}75$.

> [!goi-y] Gợi ý 2
> Câu c gồm **hai đường đi**: (mưa, không mưa) và (không mưa, mưa).

> [!loi-giai] Lời giải
> Vẽ sơ đồ hình cây như Hình 2.
>
> a) Đường (mưa, mưa): $0{,}3\cdot0{,}6=0{,}18$.
>
> b) Đường (không mưa, không mưa): $0{,}7\cdot0{,}75=0{,}525$.
>
> c) Hai đường (mưa, không mưa) và (không mưa, mưa): $0{,}3\cdot0{,}4+0{,}7\cdot0{,}25=0{,}12+0{,}175=0{,}295$.
>
> Kiểm tra: $0{,}18+0{,}525+0{,}295=1$ — ba trường hợp trên đã bao hết mọi khả năng.

![Hình 2. Sơ đồ hình cây của Ví dụ 7. Nhánh cấp 1 ghi xác suất của hôm nay, nhánh cấp 2 ghi xác suất có điều kiện của ngày mai. Xác suất mỗi đường đi bằng tích các số trên đường đó](h2-cay-thoi-tiet.svg)

> [!meo] Sơ đồ cây "rút gọn"
> Trong bài trắc nghiệm, em không cần vẽ đẹp: chỉ cần viết nhanh dạng `0,3 → 0,6` cho mỗi đường đi cần dùng rồi nhân. Nhưng **luôn điền đủ** các nhánh "phần bù" ($1-0{,}6=0{,}4$…), vì đề Đúng/Sai hay hỏi đúng những nhánh mà đề bài không cho trực tiếp.

### 2.3. Trở lại trò chơi "Ô cửa bí mật"

Giả sử người chơi chọn cửa số $1$ và người quản trò mở cửa số $3$ (thấy lừa). Gọi $E_1$, $E_2$, $E_3$ lần lượt là các biến cố "ô tô ở sau cửa số $1$, $2$, $3$", và $H$: "người quản trò mở cửa số $3$ thấy lừa". Người chơi cần so sánh $P(E_1\mid H)$ (giữ nguyên thì thắng) với $P(E_2\mid H)$ (đổi thì thắng).

- Ban đầu ô tô ở mỗi cửa như nhau: $P(E_1)=P(E_2)=P(E_3)=\dfrac13$.
- Nếu ô tô ở cửa $1$ (cửa người chơi chọn): cửa $2$ và $3$ đều là lừa, quản trò mở ngẫu nhiên một trong hai cửa, nên $P(H\mid E_1)=\dfrac12$.
- Nếu ô tô ở cửa $2$: quản trò không được mở cửa $1$ (người chơi đã chọn), không được mở cửa $2$ (có ô tô), nên **bắt buộc** mở cửa $3$: $P(H\mid E_2)=1$.
- Nếu ô tô ở cửa $3$: quản trò không bao giờ mở cửa $3$: $P(H\mid E_3)=0$.

Theo công thức tính xác suất có điều kiện rồi công thức nhân:
$$P(E_1\mid H)=\dfrac{P(E_1)\cdot P(H\mid E_1)}{P(H)}=\dfrac{1/6}{P(H)},$$
$$P(E_2\mid H)=\dfrac{P(E_2)\cdot P(H\mid E_2)}{P(H)}=\dfrac{1/3}{P(H)}.$$
Suy ra $P(E_2\mid H)=2P(E_1\mid H)$. Mặt khác, khi đã biết $H$ thì ô tô chỉ có thể ở cửa $1$ hoặc cửa $2$, nên $P(E_1\mid H)+P(E_2\mid H)=1$. Do đó
$$P(E_1\mid H)=\dfrac13,\qquad P(E_2\mid H)=\dfrac23.$$

![Hình 3. Sơ đồ hình cây của trò chơi khi người chơi chọn cửa 1. Hai đường tô cam là hai trường hợp quản trò mở cửa 3. Trong đó, đường "ô tô ở cửa 2" nặng gấp đôi](h3-o-cua-bi-mat.svg)

**Lời khuyên: nên đổi sang cửa còn lại** — khả năng thắng tăng từ $\dfrac13$ lên $\dfrac23$.

**Vì sao trực giác "mỗi cửa $\frac12$" sai?** Vì quản trò **không mở ngẫu nhiên**: ông ấy biết ô tô ở đâu và luôn tránh nó. Lựa chọn ban đầu đúng với xác suất $\frac13$, và việc quản trò mở một cửa lừa **không thay đổi** điều đó. Phần $\frac23$ còn lại, lúc đầu chia cho hai cửa kia, nay dồn hết vào cửa duy nhất chưa mở. Cách khác để thấy: người "luôn đổi" chỉ thua khi lần đầu đã chọn trúng ô tô (xác suất $\frac13$), nên thắng với xác suất $\frac23$.

> [!em-co-biet] Cập nhật Bayes (SGK tr. 71)
> Việc liên tục **cập nhật xác suất khi có thông tin mới** được ứng dụng rộng rãi: lọc thư rác, chẩn đoán y khoa, dự báo thời tiết, tìm kiếm cứu nạn trên biển… Năm 2014, lực lượng tuần duyên Mỹ đã dùng một phần mềm cập nhật xác suất theo kiểu này để thu hẹp dần vùng tìm kiếm và cứu sống một ngư dân rơi xuống biển. Công cụ toán học đầy đủ cho việc cập nhật ấy là **công thức Bayes** — em sẽ học ở Bài 19.

> [!ung-dung] Xác suất có điều kiện quanh ta
> - **Y học:** độ nhạy của xét nghiệm là $P(\text{dương tính}\mid\text{có bệnh})$, còn điều bệnh nhân quan tâm lại là $P(\text{có bệnh}\mid\text{dương tính})$ — hai số này có thể rất khác nhau (xem Dạng 1).
> - **Bảo hiểm:** phí bảo hiểm nhân thọ dựa trên xác suất sống thêm $n$ năm **khi biết** người đó đã đạt một độ tuổi nhất định.
> - **Di truyền (Sinh học 12):** "biết bố mẹ bình thường sinh con bị bệnh, tính xác suất đứa con tiếp theo bị bệnh" cũng là một xác suất có điều kiện.
> - **Kiểm tra chất lượng:** lấy sản phẩm không hoàn lại từ một lô hàng, mỗi lần lấy thay đổi xác suất của lần sau.

## Dạng bài thi hay gặp

### Dạng 1. Bảng thống kê 2 chiều → xác suất có điều kiện

- **Nhận biết:** bảng $2\times2$ (hoặc các số liệu "trong số … có …") về khảo sát, lớp học, thử thuốc, xét nghiệm; câu hỏi có "biết rằng", "trong số những người…". Rất hay ra dạng Đúng/Sai 4 ý hoặc trả lời ngắn.
- **Phương pháp:** (1) Đặt tên biến cố. (2) **Thêm dòng, cột tổng**. (3) $P(A\mid B)$ = ô giao chia **tổng hàng/cột của $B$**. $P(AB)$ = ô giao chia **tổng chung**. (4) Nếu đề cho tỉ lệ phần trăm, đổi ra số người cụ thể trước khi lập bảng (chọn tổng là $1000$ hoặc $10\,000$ cho dễ).
- **Bẫy:** chia nhầm cho tổng chung; nhầm $P(A\mid B)$ với $P(B\mid A)$; với xét nghiệm, tưởng "độ chính xác $90\%$" nghĩa là dương tính thì $90\%$ có bệnh.

> [!vi-du] Ví dụ 8 (Đúng/Sai)
> Một bệnh hiếm được xét nghiệm nhanh trên $1000$ người. Kết quả so với chẩn đoán chính xác sau đó:
>
> | | Dương tính | Âm tính |
> |---|---|---|
> | Có bệnh | 45 | 5 |
> | Không có bệnh | 38 | 912 |
>
> Chọn ngẫu nhiên một người trong số đó.
>
> a) Xác suất người đó có kết quả dương tính, biết người đó có bệnh, bằng $0{,}9$.
>
> b) Xác suất người đó có kết quả âm tính, biết người đó không có bệnh, bằng $0{,}96$.
>
> c) Biết người đó có kết quả dương tính, xác suất người đó có bệnh lớn hơn $0{,}7$.
>
> d) Biết người đó có kết quả âm tính, xác suất người đó không có bệnh lớn hơn $0{,}99$.

> [!goi-y] Gợi ý 1
> Tổng hàng: có bệnh $50$, không có bệnh $950$. Tổng cột: dương tính $45+38=83$, âm tính $5+912=917$.

> [!goi-y] Gợi ý 2
> Ý a, b: điều kiện là **hàng**. Ý c, d: điều kiện là **cột**.

> [!loi-giai] Lời giải
> a) **Đúng** — $\dfrac{45}{50}=0{,}9$.
>
> b) **Đúng** — $\dfrac{912}{950}=0{,}96$.
>
> c) **Sai** — $\dfrac{45}{83}\approx0{,}542$. Dù xét nghiệm phát hiện được $90\%$ người bệnh, trong số người dương tính chỉ khoảng $54\%$ thật sự có bệnh, vì số người không bệnh rất đông nên $4\%$ "báo nhầm" của họ ($38$ người) đã gần bằng số người bệnh thật.
>
> d) **Đúng** — $\dfrac{912}{917}\approx0{,}9945>0{,}99$.

### Dạng 2. Lấy bi, thẻ, sản phẩm lần lượt không hoàn lại

- **Nhận biết:** "lấy lần lượt", "không trả lại", "sau đó người thứ hai lấy…", "kiểm tra đến khi phát hiện…".
- **Phương pháp:** viết biến cố thành **dãy các bước**, mỗi bước nhân một phân số mà tử và mẫu đã trừ đi những gì lấy ra trước đó (công thức nhân dây chuyền). Nếu có nhiều thứ tự cùng thỏa mãn (ví dụ "hai bi khác màu") thì **cộng** các thứ tự.
- **Bẫy:** quên giảm mẫu số; quên cộng thứ tự ngược lại (đỏ–xanh và xanh–đỏ); dùng nhầm lấy có hoàn lại ($\frac{4}{15}\cdot\frac{4}{15}$…).

> [!vi-du] Ví dụ 9
> Một lô hàng có $15$ sản phẩm, trong đó có $4$ phế phẩm. Nhân viên kiểm tra lấy ngẫu nhiên lần lượt từng sản phẩm, không hoàn lại.
>
> a) Biết sản phẩm đầu tiên là phế phẩm, tính xác suất sản phẩm thứ hai cũng là phế phẩm.
>
> b) Tính xác suất phế phẩm **đầu tiên** được phát hiện ở lần lấy thứ ba (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Câu b nghĩa là: lần 1 tốt, lần 2 tốt, lần 3 là phế phẩm. Lô có $11$ sản phẩm tốt.

> [!goi-y] Gợi ý 2
> $P=\dfrac{11}{15}\cdot\dfrac{?}{14}\cdot\dfrac{?}{13}$.

> [!loi-giai] Lời giải
> a) Biết lần 1 là phế phẩm, còn $14$ sản phẩm với $3$ phế phẩm: xác suất cần tìm là $\dfrac{3}{14}$.
>
> b) Theo công thức nhân dây chuyền:
> $$P=\dfrac{11}{15}\cdot\dfrac{10}{14}\cdot\dfrac{4}{13}=\dfrac{440}{2730}=\dfrac{44}{273}\approx0{,}16.$$

### Dạng 3. Cho các xác suất, tính xác suất khác

- **Nhận biết:** đề cho vài con số trong $P(A)$, $P(B)$, $P(AB)$, $P(A\cup B)$, $P(A\mid B)$, $P(B\mid A)$ và hỏi các số còn lại, hoặc hỏi $A$, $B$ có độc lập không.
- **Phương pháp:** mọi thứ đi qua **$P(AB)$**. Tìm $P(AB)$ bằng công thức nhân (hoặc công thức cộng), rồi suy ra. Nhớ thêm: $P(A\overline{B})=P(A)-P(AB)$, $P(\overline{A}\,\overline{B})=1-P(A\cup B)$.
- **Bẫy:** tính $P(A\mid\overline{B})$ bằng $1-P(A\mid B)$ (sai! $1-P(A\mid B)$ là $P(\overline{A}\mid B)$); dùng $P(AB)=P(A)P(B)$ khi đề không nói độc lập.

> [!vi-du] Ví dụ 10
> Cho hai biến cố $A$, $B$ với $P(A)=0{,}3$, $P(B)=0{,}4$ và $P(B\mid A)=0{,}6$. Tính $P(A\mid B)$, $P(A\cup B)$ và $P(A\mid\overline{B})$. Hai biến cố $A$, $B$ có độc lập không?

> [!goi-y] Gợi ý 1
> $P(AB)=P(A)\cdot P(B\mid A)$.

> [!goi-y] Gợi ý 2
> $P(A\mid\overline{B})=\dfrac{P(A\overline{B})}{P(\overline{B})}=\dfrac{P(A)-P(AB)}{1-P(B)}$.

> [!loi-giai] Lời giải
> - $P(AB)=0{,}3\cdot0{,}6=0{,}18$.
> - $P(A\mid B)=\dfrac{0{,}18}{0{,}4}=0{,}45$.
> - $P(A\cup B)=0{,}3+0{,}4-0{,}18=0{,}52$.
> - $P(A\mid\overline{B})=\dfrac{0{,}3-0{,}18}{1-0{,}4}=\dfrac{0{,}12}{0{,}6}=0{,}2$.
>
> Vì $P(B\mid A)=0{,}6\ne0{,}4=P(B)$ nên $A$, $B$ **không độc lập**. (Hoặc: $P(AB)=0{,}18\ne0{,}12=P(A)P(B)$.)

### Dạng 4. Tìm số lượng chưa biết từ một xác suất (vận dụng)

- **Nhận biết:** số bi, số kẹo, số học sinh… là ẩn $n$ (hoặc $x$), đề cho xác suất của một biến cố "lấy lần lượt không hoàn lại".
- **Phương pháp:** viết xác suất theo công thức nhân, ra một phương trình (thường bậc hai) theo ẩn, giải và chọn nghiệm **nguyên dương** phù hợp.
- **Bẫy:** quên điều kiện ẩn nguyên dương và đủ lớn (ví dụ $n\ge2$); nhân chéo sai.

> [!vi-du] Ví dụ 11
> Một túi có $n$ viên kẹo, trong đó có $5$ viên vị cam, còn lại là vị dâu. Lấy ngẫu nhiên lần lượt $2$ viên, không trả lại. Biết xác suất để cả hai viên đều vị cam là $\dfrac29$. Tìm $n$.

> [!goi-y] Gợi ý 1
> $P=\dfrac{5}{n}\cdot\dfrac{4}{n-1}$.

> [!goi-y] Gợi ý 2
> Giải $\dfrac{20}{n(n-1)}=\dfrac29$.

> [!loi-giai] Lời giải
> Theo công thức nhân: $\dfrac5n\cdot\dfrac4{n-1}=\dfrac29\Leftrightarrow n(n-1)=90\Leftrightarrow n^2-n-90=0\Leftrightarrow n=10$ hoặc $n=-9$ (loại). Vậy túi có $n=10$ viên kẹo.

## Tóm tắt

| Nội dung | Công thức / Ghi nhớ |
|---|---|
| Định nghĩa | $P(A\mid B)$: xác suất của $A$ khi biết $B$ đã xảy ra |
| Đếm trên không gian thu gọn | $P(A\mid B)=\dfrac{n(AB)}{n(B)}$ (kết quả đồng khả năng) |
| Công thức | $P(A\mid B)=\dfrac{P(AB)}{P(B)}$, với $P(B)>0$ |
| Biến cố đối | $P(\overline{A}\mid B)=1-P(A\mid B)$ |
| Không đối xứng | Nói chung $P(A\mid B)\ne P(B\mid A)$ (cùng tử $P(AB)$, khác mẫu) |
| Độc lập | $P(A\mid B)=P(A)$, $P(B\mid A)=P(B)$. Xung khắc (xác suất dương) thì không độc lập |
| Công thức nhân | $P(AB)=P(B)\cdot P(A\mid B)=P(A)\cdot P(B\mid A)$ — đúng với mọi $A$, $B$ |
| Nhân dây chuyền | $P(ABC)=P(A)\cdot P(B\mid A)\cdot P(C\mid AB)$ |
| Bảng $2\times2$ | Thêm tổng. $P(A\mid B)$ = ô giao : tổng hàng/cột $B$. $P(AB)$ = ô giao : tổng chung |
| Sơ đồ hình cây | Nhánh sau ghi xác suất có điều kiện. Một đường đi: nhân. Nhiều đường đi: cộng. Các nhánh từ một nút có tổng $1$ |
| Ô cửa bí mật | Nên đổi cửa: thắng với xác suất $\dfrac23$ (giữ nguyên: $\dfrac13$) |

**Sơ đồ khi gặp đề:** đặt tên biến cố → tìm cụm "biết rằng / trong số / nếu" để xác định **điều kiện** (đứng sau dấu $\mid$) → nếu là bảng: thêm tổng, chia cho tổng hàng/cột điều kiện → nếu là lấy lần lượt: hình dung không gian thu gọn hoặc nhân dây chuyền → nếu là các con số $P(\cdot)$: tìm $P(AB)$ trước → kiểm tra lại bằng "tổng các nhánh bằng $1$".
