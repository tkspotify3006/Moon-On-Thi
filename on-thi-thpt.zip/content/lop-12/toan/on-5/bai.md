---
title: Ôn tập chương V
thoi-gian: 60 phút
muc-tieu:
  - Hệ thống hóa chương V — mặt phẳng, đường thẳng, góc, mặt cầu — quanh hai "vectơ đặc trưng" là vectơ pháp tuyến và vectơ chỉ phương, cùng cặp "tâm – bán kính" của mặt cầu
  - Phân biệt chắc chắn các cặp dễ nhầm (VTPT – VTCP, song song – vuông góc giữa đường và mặt, sin – côsin, góc giữa hai vectơ – góc giữa hai đường, $R$ – $R^2$, khoảng cách – độ cao…)
  - Nhận ra và tránh các lỗi sai hay gặp nhất của chương trong đề thi
  - Giải được các bài tổng hợp phối hợp nhiều bài, theo đúng ba dạng đề tốt nghiệp
  - Tự làm được các dạng của "Bài tập cuối chương V" (SGK tr. 61–63)
---
> [!ghi-nho] Chương này trong 10 dòng
> 1. **Hai chìa khóa:** mặt phẳng được chốt bởi một điểm và **VTPT $\vec n$** (vuông góc với mặt), đường thẳng được chốt bởi một điểm và **VTCP $\vec u$** (dọc theo đường). Mặt cầu được chốt bởi **tâm $I$** và **bán kính $R$**.
> 2. **Mặt phẳng** (Bài 14): $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$, tức $Ax+By+Cz+D=0$, với $\vec n=(A;\,B;\,C)$ là hệ số của $x$, $y$, $z$.
> 3. Cần một vectơ **vuông góc với hai vectơ** cho trước thì dùng **tích có hướng** $[\vec u,\vec v]$ (mẹo che cột, thử lại bằng tích vô hướng).
> 4. **Đường thẳng** (Bài 15): tham số $x=x_0+at$, $y=y_0+bt$, $z=z_0+ct$ hoặc chính tắc $\frac{x-x_0}{a}=\frac{y-y_0}{b}=\frac{z-z_0}{c}$. VTCP là hệ số của $t$, hay các mẫu số.
> 5. **Giao điểm** đường – mặt: thế $x,y,z$ theo $t$ vào phương trình mặt phẳng, giải ra $t$.
> 6. **Song song, vuông góc** đều quy về hai vectơ: tích vô hướng bằng $0$ hay hai vectơ tỉ lệ. Riêng đường – mặt thì **đảo vai**: $d\perp(P)\iff\vec u$ cùng phương $\vec n$, còn $d\parallel(P)\Rightarrow\vec u\perp\vec n$.
> 7. **Khoảng cách** điểm – mặt: $d(M,(P))=\dfrac{\lvert Ax_0+By_0+Cz_0+D\rvert}{\sqrt{A^2+B^2+C^2}}$.
> 8. **Góc** (Bài 16): cùng loại vectơ thì **côsin**, khác loại (VTCP với VTPT) thì **sin**. Luôn có trị tuyệt đối, góc nằm trong $[0^\circ;\,90^\circ]$.
> 9. **Mặt cầu** (Bài 17): $(x-a)^2+(y-b)^2+(z-c)^2=R^2$. Dạng khai triển là mặt cầu khi $a^2+b^2+c^2-d>0$. Lập phương trình nghĩa là **tìm tâm và bán kính**, tiếp xúc $(P)$ thì $R=d(I,(P))$.
> 10. **Bài thực tế:** chọn hệ trục (mặt đất là $(Oxy)$, $Oz$ hướng lên), dịch câu hỏi thành "điểm, vectơ, mặt phẳng, mặt cầu", làm tròn ở bước cuối.

Chương V là chương **hình học cuối cùng** của chương trình phổ thông và gần như chắc chắn có mặt trong đề tốt nghiệp: vài câu trắc nghiệm đọc VTPT, VTCP, tâm – bán kính, ít nhất một câu Đúng/Sai tổng hợp mặt phẳng – đường thẳng – góc – mặt cầu, và thường có một câu trả lời ngắn về bài toán thực tế (mái nhà, đường bay, đáy bể, vùng phủ sóng…). Bài ôn tập này **không giảng lại** — em đã có Bài 14, 15, 16, 17. Ở đây ta làm ba việc: (1) xếp cả chương lên **một bản đồ**; (2) tách bạch những thứ **dễ nhầm**; (3) luyện **bài tổng hợp** phối hợp nhiều bài như trong đề thật.

## 1. Bản đồ của chương

### 1.1. Hai vectơ đặc trưng, bốn bài

Cả chương dựa trên **ba công cụ** em đã có từ Chương II (Bài 6–8) và Bài 14: tọa độ của vectơ, **tích vô hướng** (đo vuông góc, đo góc) và **tích có hướng** (tạo ra vectơ vuông góc với hai vectơ). Trên nền đó, mỗi bài dựng một "đối tượng":

| Đối tượng | Được chốt bởi | Phương trình | Đọc ra ngay |
|---|---|---|---|
| Mặt phẳng (Bài 14) | 1 điểm + VTPT $\vec n$ | $Ax+By+Cz+D=0$ | $\vec n=(A;\,B;\,C)$ |
| Đường thẳng (Bài 15) | 1 điểm + VTCP $\vec u$ | tham số / chính tắc | điểm $M_0$, $\vec u=(a;\,b;\,c)$ |
| Mặt cầu (Bài 17) | tâm $I$ + bán kính $R$ | $(x-a)^2+(y-b)^2+(z-c)^2=R^2$ | $I(a;\,b;\,c)$, $R$ |

Bài 16 (góc) không có "đối tượng" mới: nó chỉ **đo góc giữa các vectơ đặc trưng** $\vec n$ và $\vec u$ của Bài 14 và Bài 15. Còn Bài 17 cần **khoảng cách** của Bài 14 cho điều kiện tiếp xúc.

![Hình 1. Bản đồ chương V: tọa độ, tích vô hướng và tích có hướng là nền; mặt phẳng (VTPT) và đường thẳng (VTCP) gặp nhau ở giao điểm và ở bài toán góc; khoảng cách điểm – mặt phẳng nối sang mặt cầu (tiếp xúc)](h1-ban-do-chuong.svg)

**Vì sao chỉ cần "một điểm + một vectơ"?** Vì cả mặt phẳng lẫn đường thẳng đều là những hình "thẳng": biết chúng đi qua đâu và hướng thế nào là biết hết. Đó là lí do mọi bài **lập phương trình** trong chương đều đi theo cùng một khuôn: *tìm điểm, tìm vectơ, thay vào công thức, thử lại*. Cái khó chỉ nằm ở bước "tìm vectơ" — mục 2.2 dưới đây gom hết các trường hợp.

### 1.2. Gặp câu hỏi nào — dùng công cụ nào

| Đề hỏi | Công cụ | Xem lại |
|---|---|---|
| "một VTPT / VTCP là", "tâm và bán kính là" | đọc hệ số (chú ý dấu, số $0$, dạng chưa chuẩn) | Bài 14 mục 2; Bài 15 mục 1.2–1.3; Bài 17 mục 1.2, 1.4 |
| "phương trình mặt phẳng qua… / chứa… / vuông góc…" | điểm + VTPT; VTPT thường là tích có hướng | Bài 14 mục 3, Dạng 1 |
| "phương trình đường thẳng qua… / vuông góc với $(P)$…" | điểm + VTCP; trắc nghiệm thì **thử điểm, so VTCP** | Bài 15 mục 1.4, Dạng 1 |
| "giao điểm của $d$ và $(P)$", "chạm sàn / chạm tường" | thế tham số vào $(P)$, giải $t$ | Bài 15 mục 1.5 |
| "vị trí tương đối" hai mặt / hai đường | so VTPT, VTCP; hai đường thì xét thêm $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$ | Bài 14 mục 4–5; Bài 15 mục 3 |
| "khoảng cách từ $M$ đến $(P)$", "giữa hai mặt song song" | công thức khoảng cách | Bài 14 mục 6 |
| "góc giữa…" | cùng loại côsin, khác loại sin | Bài 16 |
| "mặt cầu đường kính / qua điểm / tiếp xúc…", "điểm trong hay ngoài" | tìm tâm + bán kính; so $IM^2$ với $R^2$ | Bài 17 mục 1.3, Dạng 2 |
| bài thực tế (mái, sườn dốc, đường bay, đáy bể, vùng phủ sóng) | chọn hệ trục → dịch sang một trong các dòng trên | Dạng 4 của mỗi bài |

> [!meo] Ba câu tự hỏi trước khi đặt bút
> 1. **Đề nói về mặt phẳng hay đường thẳng?** Mặt phẳng thì nghĩ tới $\vec n$, đường thẳng thì nghĩ tới $\vec u$. Lẫn hai vectơ này là lỗi gốc của rất nhiều lỗi khác.
> 2. **Vectơ mình cần phải vuông góc với những gì?** Nếu với **hai** vectơ đã biết thì lấy tích có hướng của chúng.
> 3. **Đề hỏi một con số hay một phương trình?** Con số (khoảng cách, góc, bán kính) thì có trị tuyệt đối và căn. Phương trình thì thử lại bằng một điểm.

## 2. Bảng so sánh – phân biệt

### 2.1. Đọc đúng vectơ và điểm từ phương trình

| Phương trình → đọc ra | Bẫy |
|---|---|
| $(P):Ax+By+Cz+D=0$ → VTPT $(A;\,B;\,C)$, điểm: thay số tìm | thiếu biến thì tọa độ đó bằng $0$; $D$ **không** thuộc VTPT; dạng "$3x=2y-z+4$" phải chuyển vế trước |
| Tham số $x=x_0+at,\ \ldots$ → điểm $(x_0;\,y_0;\,z_0)$ là các số đứng một mình, VTCP $(a;\,b;\,c)$ là hệ số của $t$ | "$y=2$" nghĩa là hệ số của $t$ bằng $0$ |
| Chính tắc $\frac{x-x_0}{a}=\ldots$ → điểm: đổi dấu số ở tử, VTCP: các mẫu số | "$\frac{1-x}{2}$" phải đổi thành $\frac{x-1}{-2}$; "$\frac{2z-4}{6}$" thành $\frac{z-2}{3}$ |
| $(x-a)^2+(y-b)^2+(z-c)^2=R^2$ → tâm $I(a;\,b;\,c)$ (đổi dấu), $R=\sqrt{\text{vế phải}}$ | quên lấy căn; $(x+2)^2$ cho hoành độ tâm $-2$ |
| $x^2+y^2+z^2-2ax-2by-2cz+d=0$ → tâm: hệ số của $x,y,z$ chia $-2$, $R=\sqrt{a^2+b^2+c^2-d}$ | hệ số $x^2$ khác $1$ phải chia trước; dấu của $d$; cần $a^2+b^2+c^2-d>0$ |

### 2.2. Bốn quan hệ song song – vuông góc giữa đường thẳng và mặt phẳng

Đây là chỗ "hại não" nhất của chương, vì VTPT **vuông góc** với mặt phẳng còn VTCP **nằm dọc** theo đường thẳng. Khi xét một đường với một mặt, các chữ "song song" và "vuông góc" bị **đảo** khi chuyển sang vectơ:

![Hình 2. Bốn quan hệ: đường vuông góc mặt (u cùng phương n), đường song song mặt (u vuông góc n), hai mặt phẳng song song (n cùng phương n′), hai mặt phẳng vuông góc (n vuông góc n′)](h2-bon-quan-he.svg)

| Quan hệ hình | Điều kiện vectơ | Hệ quả khi lập phương trình |
|---|---|---|
| $(P)\parallel(Q)$ | $\vec n'=k\vec n$ và $D'\ne kD$ | mặt cần tìm **giữ nguyên** $A,B,C$, chỉ tính lại $D$ |
| $(P)\perp(Q)$ | $\vec n\cdot\vec n'=0$ | $\vec n_Q$ là **một VTCP** của $(P)$ |
| $d\parallel d'$ | $\vec u'=k\vec u$, điểm của $d$ không thuộc $d'$ | dùng lại $\vec u$ |
| $d\perp d'$ | $\vec u\cdot\vec u'=0$ (cắt nhau hay chéo nhau đều được) | $\vec u'$ là một trong hai vectơ mà $\vec u$ phải vuông góc |
| $d\perp(P)$ | $\vec u$ **cùng phương** $\vec n$ | VTCP của $d$ = VTPT của $(P)$, và ngược lại |
| $d\parallel(P)$ | $\vec u\cdot\vec n=0$ **và** điểm của $d$ không thuộc $(P)$ | $\vec u$ là một VTCP của $(P)$; $\vec n$ là một vectơ mà $\vec u$ phải vuông góc |
| $d\subset(P)$ | $\vec u\cdot\vec n=0$ **và** điểm của $d$ thuộc $(P)$ | mặt phẳng chứa $d$ nhận $\vec u$ làm VTCP |

Từ bảng này, gần như mọi câu "lập phương trình" quy về câu hỏi: **vectơ cần tìm phải vuông góc với hai vectơ nào?** Ví dụ:

| Đề cho | Vectơ cần tìm |
|---|---|
| mặt phẳng $(P)$ chứa $d$ và đi qua $A\notin d$ | $\vec n_P=[\vec u_d,\overrightarrow{M_0A}]$ ($M_0\in d$) |
| mặt phẳng $(Q)$ chứa $d$ và vuông góc với $(P)$ | $\vec n_Q=[\vec u_d,\vec n_P]$ |
| mặt phẳng $(P)$ chứa $d$ và song song với $d'$ | $\vec n_P=[\vec u_d,\vec u_{d'}]$ |
| mặt phẳng qua $A$ vuông góc với $(P)$ và $(Q)$ | $\vec n=[\vec n_P,\vec n_Q]$ |
| mặt phẳng chứa $A,B$ và vuông góc với $(P)$ | $\vec n=[\overrightarrow{AB},\vec n_P]$ |
| đường thẳng song song với $(P)$ và vuông góc với $d$ | $\vec u=[\vec n_P,\vec u_d]$ |
| đường thẳng song song với cả $(P)$ và $(Q)$ | $\vec u=[\vec n_P,\vec n_Q]$ |

> [!bay] "Song song với mặt phẳng" không có nghĩa là "VTCP bằng VTPT"
> Nhiều bạn thấy "$d$ vuông góc $(P)$" nhớ đúng là lấy $\vec u=\vec n_P$, rồi sang "$d$ song song $(P)$" cũng lấy luôn $\vec n_P$. Sai: song song thì $\vec u$ phải **vuông góc** với $\vec n_P$. Tương tự, "$(P)$ vuông góc $(Q)$" thì $\vec n_Q$ nằm **dọc** $(P)$, không phải VTPT của $(P)$.

### 2.3. Vị trí tương đối — ba bộ câu hỏi

| Cặp | Bước 1 | Bước 2 | Kết luận |
|---|---|---|---|
| hai mặt phẳng | $\vec n,\vec n'$ có tỉ lệ không? | nếu tỉ lệ $k$: so $D'$ với $kD$ | không tỉ lệ: cắt nhau; tỉ lệ, $D'\ne kD$: song song; $D'=kD$: trùng |
| đường – mặt (mở rộng, Bài 15 mục 1.5) | thế tham số vào $(P)$ được $pt+q=0$ | $p=\vec u\cdot\vec n$ | $p\ne0$: cắt; $p=0,\ q\ne0$: song song; $p=q=0$: nằm trong |
| hai đường thẳng | $[\vec u_1,\vec u_2]$ có bằng $\vec 0$ không? | bằng $\vec 0$: thử một điểm; khác $\vec 0$: tính $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$ | trùng / song song; cắt nhau ($=0$) / chéo nhau ($\ne0$) |

**Vì sao hai đường thẳng có tới bốn khả năng còn hai mặt phẳng chỉ có ba?** Hai mặt phẳng không song song thì **luôn** cắt nhau theo một giao tuyến. Còn hai đường thẳng không song song vẫn có thể "lướt qua nhau" mà không chạm — **chéo nhau**, như cầu vượt và con đường bên dưới. Phép thử $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=0$ chính là hỏi "hai đường có cùng nằm trong một mặt phẳng không?".

### 2.4. Ba công thức góc và góc giữa hai vectơ

| Góc giữa | Vectơ dùng | Công thức | Bằng $90^\circ$ khi | Bằng $0^\circ$ khi |
|---|---|---|---|---|
| hai vectơ (Bài 8) | $\vec a,\vec b$ | $\cos=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\lvert\vec b\rvert}$ — **không** trị tuyệt đối, góc tới $180^\circ$ | $\vec a\cdot\vec b=0$ | cùng hướng |
| hai đường thẳng | VTCP, VTCP | $\cos=\dfrac{\lvert\vec u\cdot\vec u'\rvert}{\lvert\vec u\rvert\lvert\vec u'\rvert}$ | $\vec u\cdot\vec u'=0$ | song song, trùng |
| đường thẳng – mặt phẳng | VTCP, VTPT | $\sin=\dfrac{\lvert\vec u\cdot\vec n\rvert}{\lvert\vec u\rvert\lvert\vec n\rvert}$ | $\vec u$ cùng phương $\vec n$ | $\vec u\cdot\vec n=0$ |
| hai mặt phẳng | VTPT, VTPT | $\cos=\dfrac{\lvert\vec n\cdot\vec n'\rvert}{\lvert\vec n\rvert\lvert\vec n'\rvert}$ | $\vec n\cdot\vec n'=0$ | song song, trùng |

Để ý cột "bằng $0^\circ$ khi" ở dòng đường – mặt: **tích vô hướng bằng $0$ lại cho góc $0^\circ$**, ngược hẳn với hai dòng kia. Đó cũng chính là cái "đảo vai" của mục 2.2. Hai góc **bù nhau** (đường – đường, mặt – mặt khi tích vô hướng âm) và hai góc **phụ nhau** (nhầm sin thành côsin) là hai cặp phương án nhiễu kinh điển.

> [!meo] Góc với mặt đất $(Oxy)$ — đọc trong 5 giây
> - Đường thẳng có VTCP $(a;\,b;\,c)$: $\sin\varphi=\dfrac{\lvert c\rvert}{\sqrt{a^2+b^2+c^2}}$ ("độ chênh cao chia chiều dài").
> - Mặt phẳng có VTPT $(A;\,B;\,C)$: $\cos\varphi=\dfrac{\lvert C\rvert}{\sqrt{A^2+B^2+C^2}}$.
>
> Một bên sin, một bên côsin, cùng dùng tọa độ thứ ba.

### 2.5. Khoảng cách, tiếp xúc và vị trí với mặt cầu

| Cần biết | So sánh | Kết luận |
|---|---|---|
| điểm $M$ và mặt cầu $(I;\,R)$ | $IM^2$ với $R^2$ (khỏi lấy căn) | nhỏ hơn: trong; bằng: thuộc; lớn hơn: ngoài |
| mặt phẳng $(P)$ và mặt cầu | $d=d(I,(P))$ với $R$ | $d=R$: **tiếp xúc** (Bài 17); $d>R$: không có điểm chung; $d<R$: cắt nhau (mở rộng) |
| điểm $M$ ngoài mặt cầu, khoảng cách tới mặt cầu (mở rộng, Bài 17 Dạng 2) | $IM$ với $R$ | gần nhất $IM-R$, xa nhất $IM+R$ |

Trường hợp $d<R$ là **mở rộng, ngoài SGK**: mặt phẳng cắt mặt cầu theo một **đường tròn** có tâm là hình chiếu $H$ của $I$ trên $(P)$ và bán kính $r=\sqrt{R^2-d^2}$ (định lí Pythagore trong tam giác $IHM$ vuông tại $H$, với $M$ là một điểm bất kì của đường tròn đó). Đề Đúng/Sai đôi khi hỏi "mặt phẳng có cắt mặt cầu không", khi đó chỉ cần so $d$ với $R$.

> [!bay] Ba "cặp đôi" về mặt cầu
> - **$R$ và $R^2$:** vế phải là $R^2$. Lập phương trình với $R=4$ thì vế phải là $16$, đọc phương trình có vế phải $16$ thì $R=4$.
> - **Đường kính và bán kính:** mặt cầu đường kính $AB$ có $R=\frac{AB}{2}$, nên $R^2=\frac{AB^2}{4}$.
> - **Mặt cầu và khối cầu:** vùng phủ sóng, vùng radar theo dõi là **khối cầu** ($IM\le R$).

### 2.6. Những cặp dễ nhầm trong bài toán thực tế

| Cặp | Phân biệt |
|---|---|
| **Độ cao thẳng đứng** – **khoảng cách vuông góc** | "cao hơn mặt dốc bao nhiêu" là hiệu cao độ (giữ $x,y$, so $z$); "cách mặt dốc bao xa" là $d(M,(P))$. Chỉ bằng nhau khi mặt phẳng nằm ngang (Bài 14 Dạng 4) |
| **Góc nghiêng của một đường** – **của một mặt** | ống nước, đường cáp, đường bay: **sin** với $\vec k$; mái nhà, đáy bể, sườn dốc: **côsin** với $\vec k$ |
| **Tham số $t$** – **thời gian** | chỉ là thời gian khi VTCP đúng bằng vectơ vận tốc (dịch chuyển trong 1 đơn vị thời gian); đã rút gọn VTCP thì $t$ không còn là giây (Bài 15 Dạng 4) |
| **Hai quỹ đạo cắt nhau** – **hai vật va chạm** | cắt nhau: tìm $t,s$ bất kì; va chạm: cần **cùng thời điểm** $t=s$ |
| **Đơn vị** | tọa độ theo m, km hay "1 đơn vị = 6 371 km"; làm tròn ở bước cuối, nhất là khi so với một ngưỡng (như $IM^2$ với $R^2$) |

## 3. Lỗi sai hay gặp của cả chương

> [!bay] Bài 14 — mặt phẳng
> - **1.** Đọc VTPT khi phương trình **chưa chuyển vế** hoặc **thiếu biến**: $3x=2y-z+4$ có VTPT $(3;\,-2;\,1)$, $3x-z+2=0$ có VTPT $(3;\,0;\,-1)$.
> - **2.** **Sai dấu tọa độ giữa** của tích có hướng (lấy "cột 1 – cột 3" thay vì "cột 3 – cột 1"). Luôn thử lại: $\vec n\cdot\vec u=0$, $\vec n\cdot\vec v=0$.
> - **3.** Thay điểm có tọa độ âm: $y-(-2)=y+2$. Quên đổi dấu là ra mặt phẳng không đi qua điểm đã cho.
> - **4.** Kết luận song song chỉ vì VTPT tỉ lệ, **quên so $D$** (có thể là trùng nhau).
> - **5.** Khoảng cách: quên trị tuyệt đối, quên căn ở mẫu, hoặc dùng công thức $\frac{\lvert D_1-D_2\rvert}{\sqrt{A^2+B^2+C^2}}$ khi hai phương trình **chưa cùng** $A,B,C$.

> [!bay] Bài 15 — đường thẳng
> - **6.** Lấy **điểm** làm VTCP (đọc $(x_0;\,y_0;\,z_0)$ thay vì hệ số của $t$), hoặc đọc chính tắc dạng "chưa chuẩn" $\frac{1-x}{2}$ mà không đổi dấu.
> - **7.** Kiểm tra điểm thuộc đường thẳng mà **chỉ thử một, hai phương trình**. Phải cùng một $t$ thỏa cả ba.
> - **8.** Trắc nghiệm "phương trình của $\Delta$ là" mà đi tìm phương án **giống hệt**. Phương trình đường thẳng không duy nhất: chỉ cần VTCP cùng phương và một điểm thuộc $\Delta$ (ví dụ đường $AB$ viết qua $A$ hay qua $B$ đều đúng, xem bài tự luyện T4 ở mục 5).
> - **9.** Hai đường thẳng dùng **chung tên tham số** $t$ khi lập hệ tìm giao điểm. Phải đổi một bên thành $s$.
> - **10.** Kết luận "cắt nhau" chỉ vì VTCP không cùng phương — chưa xét chéo nhau.

> [!bay] Bài 16 — góc
> - **11.** Dùng **côsin cho góc đường – mặt** (ra góc phụ). Hai đáp án cộng lại đúng $90^\circ$ là dấu hiệu.
> - **12.** **Quên trị tuyệt đối**, ra góc tù như $116{,}4^\circ$, $135^\circ$ cho góc giữa hai đường hoặc hai mặt phẳng.
> - **13.** Lấy nhầm vectơ: dùng VTPT của mặt phẳng như "VTCP", hoặc $(Oxy)$ có VTPT $\vec i$ (đúng là $\vec k$).
> - **14.** Máy tính để chế độ **Radian** khi bấm $\cos^{-1}$, $\sin^{-1}$ (cần **Deg**), hoặc làm tròn côsin quá sớm.

> [!bay] Bài 17 — mặt cầu
> - **15.** Giữ nguyên dấu khi đọc tâm, quên lấy căn khi đọc bán kính.
> - **16.** Dạng khai triển: không chia khi hệ số $x^2$ là $2$, nhầm dấu $d$, coi $a^2+b^2+c^2-d=0$ là mặt cầu.
> - **17.** Đường kính $AB$ mà lấy $R=AB$, hoặc tâm là trung điểm mà lại lấy $\frac12\overrightarrow{AB}$.
> - **18.** Tiếp xúc mặt phẳng tọa độ: tiếp xúc $(Oxy)$ thì $R=\lvert z_I\rvert$ (không phải $\lvert x_I\rvert$).

## 4. Bài tổng hợp

Năm bài dưới đây đều **phối hợp nhiều bài** của chương và bám ba dạng đề tốt nghiệp. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Đúng/Sai: mặt phẳng qua ba điểm, đường vuông góc, mặt cầu tiếp xúc, góc

> [!vi-du] Ví dụ 1 (Bài 14 + 15 + 16 + 17 — liên hệ SGK Bài tập 5.40)
> Trong không gian $Oxyz$, cho bốn điểm $A(1;\,1;\,1)$, $B(5;\,0;\,1)$, $C(1;\,3;\,0)$ và $D(2;\,3;\,10)$. Xét các mệnh đề:
>
> a) Mặt phẳng $(ABC)$ có phương trình $x+4y+8z-13=0$.
>
> b) Đường thẳng đi qua $D$ và vuông góc với $(ABC)$ cắt $(ABC)$ tại $H(1;\,-1;\,2)$.
>
> c) Mặt cầu tâm $D$ tiếp xúc với $(ABC)$ có phương trình $(x-2)^2+(y-3)^2+(z-10)^2=9$.
>
> d) Góc giữa mặt phẳng $(ABC)$ và mặt phẳng $(Oxy)$ xấp xỉ $62{,}7^\circ$.

> [!goi-y] Gợi ý 1
> a) $\overrightarrow{AB}=(4;\,-1;\,0)$, $\overrightarrow{AC}=(0;\,2;\,-1)$. Tính tích có hướng bằng mẹo che cột, rồi thử lại bằng điểm $B$, $C$.

> [!goi-y] Gợi ý 2
> b) Đường thẳng qua $D$ vuông góc với $(ABC)$ nhận VTPT của $(ABC)$ làm VTCP. Viết dạng tham số rồi thế vào phương trình mặt phẳng.

> [!goi-y] Gợi ý 3
> c) Bán kính bằng $d(D,(ABC))$ — và nhớ vế phải là $R^2$. d) Hai mặt phẳng: dùng **côsin**, VTPT của $(Oxy)$ là $\vec k$.

> [!loi-giai] Lời giải
> a) **Đúng.** $[\overrightarrow{AB},\overrightarrow{AC}]=\big((-1)(-1)-0\cdot2;\ 0\cdot0-4\cdot(-1);\ 4\cdot2-0\cdot(-1)\big)=(1;\,4;\,8)$.
> Qua $A$: $(x-1)+4(y-1)+8(z-1)=0\iff x+4y+8z-13=0$. Thử $B$: $5+0+8-13=0$ ✓, thử $C$: $1+12+0-13=0$ ✓.
>
> b) **Đúng.** Đường thẳng: $x=2+t$, $y=3+4t$, $z=10+8t$. Thế vào: $(2+t)+4(3+4t)+8(10+8t)-13=81+81t=0$, nên $t=-1$ và giao điểm là $H(1;\,-1;\,2)$.
>
> c) **Sai.** $R=d(D,(ABC))=\dfrac{\lvert2+12+80-13\rvert}{\sqrt{1+16+64}}=\dfrac{81}{9}=9$ (cũng bằng $DH=\sqrt{1+16+64}=9$). Phương trình đúng phải có vế phải $R^2=81$.
>
> d) **Sai.** $\cos\big((ABC),(Oxy)\big)=\dfrac{\lvert8\rvert}{9}=\dfrac89$, góc $\approx27{,}3^\circ$. Con số $62{,}7^\circ$ là $\sin^{-1}\frac89$ — nhầm sang công thức đường – mặt.

> [!meo]
> Ở câu b), $H$ chính là **tiếp điểm** của mặt cầu ở câu c) với $(ABC)$: bán kính đi tới tiếp điểm luôn vuông góc với mặt phẳng tiếp xúc (Bài 17, Hình 2). Hai câu b) và c) kiểm tra chéo cho nhau: $DH$ phải bằng $d(D,(ABC))$.

### 4.2. Mặt phẳng chứa một đường thẳng và vuông góc với một mặt phẳng

> [!vi-du] Ví dụ 2 (Bài 14 + 15 + 16 — liên hệ SGK Bài tập 5.44, 5.48)
> Cho đường thẳng $d:\dfrac{x-1}{2}=\dfrac{y}{1}=\dfrac{z-2}{-1}$ và mặt phẳng $(P):x+2y-2z-3=0$.
>
> a) Tìm giao điểm $M$ của $d$ và $(P)$.
>
> b) Tính góc giữa $d$ và $(P)$ (làm tròn đến hàng phần mười của độ).
>
> c) Viết phương trình mặt phẳng $(Q)$ chứa $d$ và vuông góc với $(P)$.

> [!goi-y] Gợi ý 1
> a) $d$ qua $(1;\,0;\,2)$, VTCP $\vec u=(2;\,1;\,-1)$. Đặt $x=1+2t$, $y=t$, $z=2-t$.

> [!goi-y] Gợi ý 2
> b) Đường – mặt: **sin**, với $\vec u$ và $\vec n_P=(1;\,2;\,-2)$.

> [!goi-y] Gợi ý 3
> c) $(Q)$ chứa $d$ nên nhận $\vec u$ làm VTCP. $(Q)\perp(P)$ nên nhận $\vec n_P$ làm VTCP thứ hai. VTPT $\vec n_Q=[\vec u,\vec n_P]$, và $(Q)$ đi qua một điểm bất kì của $d$.

> [!loi-giai] Lời giải
> **a)** $(1+2t)+2t-2(2-t)-3=6t-6=0\Rightarrow t=1$. Vậy $M(3;\,1;\,1)$.
>
> **b)** $\vec u\cdot\vec n_P=2+2+2=6$, $\lvert\vec u\rvert=\sqrt6$, $\lvert\vec n_P\rvert=3$.
> $$\sin(d,(P))=\frac{6}{3\sqrt6}=\frac{\sqrt6}{3}\approx0{,}816,$$
> nên góc $\approx54{,}7^\circ$.
>
> **c)** $[\vec u,\vec n_P]=\big(1\cdot(-2)-(-1)\cdot2;\ (-1)\cdot1-2\cdot(-2);\ 2\cdot2-1\cdot1\big)=(0;\,3;\,3)$, chọn $\vec n_Q=(0;\,1;\,1)$.
> $(Q)$ qua $(1;\,0;\,2)$: $(y-0)+(z-2)=0\iff y+z-2=0$.
> Thử lại: mọi điểm của $d$ có $y+z=t+2-t=2$ ✓ (cả $d$ nằm trong $(Q)$), và $\vec n_Q\cdot\vec n_P=0+2-2=0$ ✓.

> [!em-co-biet] Hình chiếu của một đường thẳng (mở rộng, ngoài SGK)
> Giao tuyến của $(Q)$ và $(P)$ chính là **hình chiếu vuông góc** của $d$ trên $(P)$: mọi đường vuông góc hạ từ một điểm của $d$ xuống $(P)$ đều nằm trong $(Q)$. Góc $54{,}7^\circ$ ở câu b) là góc giữa $d$ và đường hình chiếu ấy — đúng như định nghĩa góc giữa đường thẳng và mặt phẳng ở lớp 11.

### 4.3. Hai đường thẳng chéo nhau

> [!vi-du] Ví dụ 3 (Bài 14 + 15 + 16 — liên hệ SGK Bài tập 5.45, 5.47)
> Cho hai đường thẳng $d_1:\begin{cases}x=1+t\\y=t\\z=2-t\end{cases}$ và $d_2:\dfrac{x}{2}=\dfrac{y-2}{1}=\dfrac{z-1}{1}$.
>
> a) Xét vị trí tương đối của $d_1$ và $d_2$.
>
> b) Tính góc giữa $d_1$ và $d_2$ (làm tròn đến hàng phần mười của độ).
>
> c) Viết phương trình mặt phẳng $(P)$ chứa $d_1$ và song song với $d_2$.

> [!goi-y] Gợi ý 1
> $A_1(1;\,0;\,2)$, $\vec u_1=(1;\,1;\,-1)$; $A_2(0;\,2;\,1)$, $\vec u_2=(2;\,1;\,1)$. Tính $[\vec u_1,\vec u_2]$ trước — nó dùng được cho cả câu a) và câu c).

> [!goi-y] Gợi ý 2
> c) $(P)$ chứa $d_1$ nên có VTCP $\vec u_1$, còn $(P)\parallel d_2$ nên có VTCP $\vec u_2$. Nhớ kiểm tra $d_2$ **không nằm trong** $(P)$.

> [!loi-giai] Lời giải
> **a)** $[\vec u_1,\vec u_2]=\big(1\cdot1-(-1)\cdot1;\ (-1)\cdot2-1\cdot1;\ 1\cdot1-1\cdot2\big)=(2;\,-3;\,-1)\ne\vec 0$.
> $\overrightarrow{A_1A_2}=(-1;\,2;\,-1)$, $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=-2-6+1=-7\ne0$. Vậy $d_1$, $d_2$ **chéo nhau**.
>
> **b)** $\vec u_1\cdot\vec u_2=2+1-1=2$, nên
> $$\cos(d_1,d_2)=\frac{2}{\sqrt3\cdot\sqrt6}=\frac{\sqrt2}{3}\approx0{,}471,$$
> góc $\approx61{,}9^\circ$. (Hai đường chéo nhau vẫn có góc — góc chỉ phụ thuộc vào hướng.)
>
> **c)** $\vec n_P=[\vec u_1,\vec u_2]=(2;\,-3;\,-1)$, qua $A_1$: $2(x-1)-3y-(z-2)=0\iff2x-3y-z=0$.
> Kiểm tra $A_2\notin(P)$: $0-6-1=-7\ne0$ ✓, nên $d_2$ song song với $(P)$ chứ không nằm trong $(P)$.

> [!em-co-biet] Khoảng cách giữa hai đường chéo nhau (mở rộng, ngoài SGK)
> Vì $d_2\parallel(P)$ nên mọi điểm của $d_2$ cách $(P)$ như nhau, và đó chính là **khoảng cách giữa hai đường chéo nhau**: $d(A_2,(P))=\dfrac{\lvert-7\rvert}{\sqrt{4+9+1}}=\dfrac{7}{\sqrt{14}}\approx1{,}87$. Con số $-7$ ở tử chính là tích $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$ em vừa tính ở câu a).

### 4.4. Trả lời ngắn: đáy bể nghiêng bao nhiêu độ?

> [!vi-du] Ví dụ 4 (Bài 14 + 16 — liên hệ SGK Bài tập 5.50)
> Một bể nước có đáy phẳng nhưng nghiêng. Trên mặt nước, người ta chọn ba vị trí $A$, $B$, $C$ là ba đỉnh của một tam giác đều cạnh $4$ m, rồi thả dây dọi thẳng đứng xuống chạm đáy. Phần dây nằm trong nước ở $A$, $B$, $C$ dài lần lượt $1{,}5$ m, $2{,}1$ m và $2{,}4$ m (Hình 3).
>
> a) Đáy bể nghiêng so với mặt phẳng nằm ngang một góc bao nhiêu độ (làm tròn đến hàng phần mười)?
>
> b) Nếu thả dây dọi tại trọng tâm $G$ của tam giác $ABC$ thì phần dây trong nước dài bao nhiêu mét?

![Hình 3. Ba dây dọi thả từ A, B, C trên mặt nước chạm đáy bể nghiêng tại A′, B′, C′, độ sâu 1,5 m, 2,1 m và 2,4 m](h3-day-doi.svg)

> [!goi-y] Gợi ý 1
> Chọn mặt nước là $(Oxy)$, $Oz$ hướng lên, $A$ ở gốc, $B$ trên tia $Ox$. Tam giác đều cạnh $4$ thì $C(2;\,2\sqrt3;\,0)$. Điểm chạm đáy nằm **ngay dưới**: $A'(0;\,0;\,-1{,}5)$, $B'(4;\,0;\,-2{,}1)$, $C'(2;\,2\sqrt3;\,-2{,}4)$.

> [!goi-y] Gợi ý 2
> Mặt nước có VTPT $\vec k$. Góc giữa hai mặt phẳng: **côsin**. VTPT của đáy là $\big[\overrightarrow{A'B'},\overrightarrow{A'C'}\big]$ — được phép nhân với một số cho gọn.

> [!goi-y] Gợi ý 3
> b) Viết phương trình mặt đáy dạng "$z$ theo $x$, $y$", rồi thay tọa độ của $G$. Hoặc để ý: $z$ là hàm **bậc nhất** của $x$, $y$.

> [!loi-giai] Lời giải
> **a)** $\overrightarrow{A'B'}=(4;\,0;\,-0{,}6)$, $\overrightarrow{A'C'}=(2;\,2\sqrt3;\,-0{,}9)$.
> Tích có hướng $\big[\overrightarrow{A'B'},\overrightarrow{A'C'}\big]$ (che cột):
> - tọa độ 1: $0\cdot(-0{,}9)-(-0{,}6)\cdot2\sqrt3=1{,}2\sqrt3$;
> - tọa độ 2: $(-0{,}6)\cdot2-4\cdot(-0{,}9)=2{,}4$;
> - tọa độ 3: $4\cdot2\sqrt3-2\cdot0=8\sqrt3$.
>
> Nhân với $\frac{5}{2\sqrt3}$ cho gọn: $\vec n=(3;\,2\sqrt3;\,20)$, $\lvert\vec n\rvert=\sqrt{9+12+400}=\sqrt{421}$.
> $$\cos\varphi=\frac{20}{\sqrt{421}}\approx0{,}9747\ \Rightarrow\ \varphi\approx12{,}9^\circ.$$
>
> **b)** Mặt đáy qua $A'$: $3x+2\sqrt3\,y+20(z+1{,}5)=0$, tức là $z=-1{,}5-0{,}15x-\dfrac{\sqrt3}{10}y$.
> Trọng tâm $G\left(2;\,\frac{2\sqrt3}{3};\,0\right)$ nên điểm đáy ngay dưới $G$ có $z=-1{,}5-0{,}3-0{,}2=-2$. Dây dài $2$ m.
> Nhận xét: $2=\dfrac{1{,}5+2{,}1+2{,}4}{3}$ — độ sâu tại trọng tâm bằng **trung bình cộng** ba độ sâu, vì độ sâu là hàm bậc nhất của $x$, $y$.

> [!bay]
> - Góc giữa **hai mặt phẳng** (đáy và mặt nước) dùng **côsin**. Bấm $\sin^{-1}$ sẽ ra $77{,}1^\circ$ — một cái bể dốc như vách đá!
> - Đừng đặt các điểm đáy có cao độ **dương** rồi lại lẫn dấu: chọn hệ trục xong thì giữ nhất quán. Góc không phụ thuộc vào việc em cho $Oz$ hướng lên hay xuống.

### 4.5. Trả lời ngắn: vệ tinh nhìn thấy đến đâu?

> [!vi-du] Ví dụ 5 (Bài 14 + 17 — liên hệ SGK Bài tập 5.52)
> Coi Trái Đất là mặt cầu $(S):x^2+y^2+z^2=1$ trong hệ $Oxyz$ như SGK ($O$ là tâm, $1$ đơn vị $=6\,371$ km, tia $Oz$ qua cực Bắc, $(Oxy)$ là mặt phẳng xích đạo). Tại một thời điểm, một vệ tinh ở vị trí $B(0;\,0;\,2)$, ngay trên cực Bắc. Đường chân trời của vệ tinh là tập hợp các điểm $A\in(S)$ sao cho $\widehat{OAB}=90^\circ$ (Hình 4).
>
> a) Tính khoảng cách $AB$ từ vệ tinh đến một điểm $A$ trên đường chân trời (làm tròn đến hàng đơn vị, đơn vị km).
>
> b) Chứng minh mọi điểm của đường chân trời nằm trong một mặt phẳng. Viết phương trình mặt phẳng đó.
>
> c) Vệ tinh nhìn thấy những điểm của mặt đất nằm "phía trên" đường chân trời. Tại thời điểm đó, ở Hà Nội (vĩ độ khoảng $21^\circ N$) có nhìn thấy vệ tinh không?

![Hình 4. Mặt cắt qua trục Oz: vệ tinh B ở độ cao bằng một bán kính Trái Đất; tia nhìn BA tiếp xúc mặt đất tại A, OA ⊥ AB; đường chân trời nằm trên mặt phẳng z = 1/2, ứng với vĩ tuyến 30°N](h4-chan-troi.svg)

> [!goi-y] Gợi ý 1
> a) Tam giác $OAB$ vuông tại $A$, $OA=1$, $OB=2$. Dùng định lí Pythagore.

> [!goi-y] Gợi ý 2
> b) $\widehat{OAB}=90^\circ\iff\overrightarrow{AO}\cdot\overrightarrow{AB}=0$. Với $A(x;\,y;\,z)$, khai triển rồi dùng $x^2+y^2+z^2=1$ để khử các bình phương.

> [!goi-y] Gợi ý 3
> c) Điểm ở vĩ độ $\alpha^\circ N$ có cao độ $z=\sin\alpha^\circ$ (Bài 17 mục 2.2). So với mặt phẳng ở câu b).

> [!loi-giai] Lời giải
> **a)** $AB=\sqrt{OB^2-OA^2}=\sqrt{4-1}=\sqrt3$ đơn vị, tức là $\sqrt3\cdot6\,371\approx11\,035$ km.
>
> **b)** $\overrightarrow{AO}=(-x;\,-y;\,-z)$, $\overrightarrow{AB}=(-x;\,-y;\,2-z)$.
> $$\overrightarrow{AO}\cdot\overrightarrow{AB}=x^2+y^2+z^2-2z=1-2z.$$
> Bằng $0$ khi và chỉ khi $z=\frac12$. Vậy đường chân trời nằm trong mặt phẳng $z-\frac12=0$ (song song với mặt phẳng xích đạo).
>
> **c)** Đường chân trời là các điểm có $z=\frac12=\sin30^\circ$, tức là **vĩ tuyến $30^\circ N$**. Vệ tinh thấy được vùng $z\ge\frac12$, tức từ vĩ độ $30^\circ N$ trở lên. Hà Nội có $z=\sin21^\circ\approx0{,}358<\frac12$ nên **không** nhìn thấy vệ tinh này.

> [!em-co-biet] Đường chân trời là một đường tròn (mở rộng, ngoài SGK)
> Mặt phẳng $z=\frac12$ cách tâm $O$ một khoảng $\frac12<1=R$, nên cắt mặt cầu theo một **đường tròn** bán kính $\sqrt{1-\frac14}=\frac{\sqrt3}{2}$ (mục 2.5). Với vị trí $B$ bất kì, cách làm ở câu b) luôn cho mặt phẳng $\overrightarrow{OB}\cdot\overrightarrow{OM}=1$, tức $x_Bx+y_By+z_Bz=1$ — một phương trình mặt phẳng mà VTPT là $\overrightarrow{OB}$. Đây là lí do đài truyền hình, mạng vệ tinh phải dùng **nhiều vệ tinh** mới phủ kín Trái Đất.

## 5. Đối chiếu "Bài tập cuối chương V" (SGK tr. 61–63)

Bảng dưới cho biết mỗi bài tập của SGK kiểm tra điều gì, nên xem lại ở đâu, kèm một **bài tự luyện cùng dạng** (số liệu khác). Làm xong, mở đáp số bên dưới để tự chấm.

| SGK | Kiểm tra (xem lại) | Bài tự luyện cùng dạng |
|---|---|---|
| 5.31 | Đọc VTPT — *Bài 14 mục 2; mục 2.1* | (T1) Tìm một VTPT của $(P):2x=y-3z+5$. |
| 5.32 | Mặt phẳng qua điểm, biết VTPT — *Bài 14 mục 3.1* | (T2) Qua $I(2;\,0;\,-3)$, VTPT $(1;\,-4;\,2)$. |
| 5.33, 5.34 | Đọc VTCP — *Bài 15 mục 1.2–1.3; mục 2.1* | (T3) VTCP của $\frac{x+2}{3}=\frac{1-y}{2}=\frac{z}{-1}$ và của $x=4-t$, $y=2$, $z=1+3t$. |
| 5.35, 5.36 | Đường thẳng qua điểm + VTCP, qua hai điểm — *Bài 15 mục 1.4* | (T4) Đường thẳng $AB$ với $A(1;\,2;\,0)$, $B(3;\,1;\,4)$: viết hai phương trình tham số khác nhau. |
| 5.37 | Qua điểm, vuông góc với mặt phẳng — *mục 2.2* | (T5) Qua $K(1;\,-2;\,0)$, vuông góc với $(P):2x+y-3z+1=0$. |
| 5.38, 5.39 | Tâm, bán kính — *Bài 17 mục 1.2, 1.4* | (T6) $(S):x^2+y^2+z^2+6x-2z-6=0$. |
| 5.40 | Mặt phẳng qua ba điểm, đường thẳng qua hai điểm, mặt cầu đường kính / qua điểm — *Ví dụ 1* | (T7) $A(1;\,0;\,3)$, $B(2;\,2;\,1)$, $C(0;\,1;\,1)$: $(ABC)$; mặt cầu đường kính $AC$; mặt cầu tâm $A$ qua $B$. |
| 5.41 | Mặt phẳng chứa đường thẳng và một điểm — *mục 2.2* | (T8) Chứa $d:x=2+t$, $y=1-t$, $z=3+2t$ và gốc $O$. |
| 5.42 | Khoảng cách; mặt phẳng song song; chứa $A,B$ vuông góc $(P)$ — *Bài 14 mục 4–6* | (T9) $(P):x+2y-2z+4=0$, $A(2;\,2;\,-1)$, $B(0;\,1;\,1)$. |
| 5.43 | Vị trí hai đường; đường song song; mặt phẳng chứa điểm và đường; giao với $(Oxz)$ — *Bài 15* | (T10) $A(2;\,1;\,0)$, $d:\frac{x}{1}=\frac{y-1}{1}=\frac{z+1}{2}$, $d':\frac{x+1}{2}=\frac{y-1}{1}=\frac{z-2}{-1}$. |
| 5.44 | Mặt phẳng chứa $d$, vuông góc $(P)$ — *Ví dụ 2* | Làm lại câu b), c) của Ví dụ 2 với $(P):x-2y+3z+1=0$. |
| 5.45 | Mặt phẳng chứa $d$, song song $d'$ — *Ví dụ 3* | Đổi vai: mặt phẳng chứa $d_2$ và song song $d_1$ ở Ví dụ 3. |
| 5.46 | Qua điểm, vuông góc hai mặt phẳng — *mục 2.2* | (T11) Qua $A(0;\,1;\,-2)$, vuông góc với $x+y-z+5=0$ và $x-2y+z-1=0$. |
| 5.47 | Vị trí và góc của hai đường thẳng — *Ví dụ 3* | (T12) $d:x=1+2t$, $y=t$, $z=-1+t$ và $d':x=3+s$, $y=1-s$, $z=2s$. |
| 5.48 | Góc đường – mặt — *Bài 16 mục 2* | (T13) $d:\frac{x+1}{1}=\frac{y-2}{1}=\frac{z}{-4}$ và $(P):2x-y+2z+5=0$. |
| 5.49 | Góc mặt phẳng với $(Oxy)$ — *mục 2.4* | (T14) $(P):x+2y+3z-1=0$ và $(Oxy)$. |
| 5.50 | Đáy bể nghiêng — *Ví dụ 4* | Làm lại Ví dụ 4 với độ sâu $2$ m, $2{,}6$ m, $3{,}2$ m. |
| 5.51 | Góc giữa đường ống và mặt sàn — *mục 2.4, khung mẹo* | (T15) Ống thẳng qua $A(2;\,0;\,3)$, $B(5;\,4;\,1)$, sàn là $(Oxy)$. |
| 5.52 | Đường chân trời — *Ví dụ 5* | Làm lại Ví dụ 5 với vệ tinh ở $B(0;\,0;\,3)$. |

> [!loi-giai] Đáp số bài tự luyện
> - **T1.** Chuyển vế: $2x-y+3z-5=0$, VTPT $(2;\,-1;\,3)$.
> - **T2.** $(x-2)-4y+2(z+3)=0\iff x-4y+2z+4=0$.
> - **T3.** $\frac{1-y}{2}=\frac{y-1}{-2}$ nên VTCP $(3;\,-2;\,-1)$. Đường thứ hai: $(-1;\,0;\,3)$.
> - **T4.** $\overrightarrow{AB}=(2;\,-1;\,4)$. Qua $A$: $x=1+2t$, $y=2-t$, $z=4t$. Qua $B$: $x=3+2s$, $y=1-s$, $z=4+4s$. Cả hai đều đúng.
> - **T5.** $\dfrac{x-1}{2}=\dfrac{y+2}{1}=\dfrac{z}{-3}$.
> - **T6.** $I(-3;\,0;\,1)$, $R=\sqrt{9+0+1+6}=4$.
> - **T7.** $\overrightarrow{AB}=(1;\,2;\,-2)$, $\overrightarrow{AC}=(-1;\,1;\,-2)$, $[\overrightarrow{AB},\overrightarrow{AC}]=(-2;\,4;\,3)$ nên $(ABC):2x-4y-3z+7=0$. Mặt cầu đường kính $AC$: tâm $\left(\frac12;\,\frac12;\,2\right)$, $R^2=\frac{AC^2}{4}=\frac64=\frac32$. Mặt cầu tâm $A$ qua $B$: $R^2=AB^2=9$, $(x-1)^2+y^2+(z-3)^2=9$.
> - **T8.** $M_0(2;\,1;\,3)$, $\vec n=[\overrightarrow{OM_0},\vec u]=(5;\,-1;\,-3)$, mặt phẳng $5x-y-3z=0$.
> - **T9.** $d(A,(P))=\frac{\lvert2+4+2+4\rvert}{3}=4$. Song song qua $A$: $x+2y-2z-8=0$. Chứa $A,B$ vuông góc $(P)$: $\vec n=[\overrightarrow{AB},\vec n_P]=(-2;\,-2;\,-3)$, chọn $(2;\,2;\,3)$, mặt phẳng $2x+2y+3z-5=0$.
> - **T10.** $[\vec u,\vec u']=(-3;\,5;\,-1)$, $\overrightarrow{M_1M_2}=(-1;\,0;\,3)$, tích vô hướng $3+0-3=0$: **cắt nhau** (tại $(1;\,2;\,1)$). $\Delta:\frac{x-2}{1}=\frac{y-1}{1}=\frac{z}{2}$. Mặt phẳng chứa $A$ và $d$: $x+3y-2z-5=0$. Giao của $d$ với $(Oxz)$: $y=0\Rightarrow t=-1$, điểm $(-1;\,0;\,-3)$.
> - **T11.** $[(1;\,1;\,-1),(1;\,-2;\,1)]=(-1;\,-2;\,-3)$, mặt phẳng $x+2y+3z+4=0$.
> - **T12.** $\vec u=(2;\,1;\,1)$, $\vec u'=(1;\,-1;\,2)$, $[\vec u,\vec u']=(3;\,-3;\,-3)\ne\vec 0$, $\overrightarrow{M_1M_2}=(2;\,1;\,1)$, tích vô hướng $6-3-3=0$: **cắt nhau** tại $(3;\,1;\,0)$. $\vec u\cdot\vec u'=2-1+2=3$, $\cos=\frac{3}{\sqrt6\cdot\sqrt6}=\frac12$, góc $60^\circ$.
> - **T13.** $\sin=\frac{\lvert2-1-8\rvert}{\sqrt{18}\cdot3}=\frac{7}{9\sqrt2}$, góc $\approx33{,}4^\circ$.
> - **T14.** $\cos=\frac{3}{\sqrt{14}}$, góc $\approx36{,}7^\circ$.
> - **T15.** $\overrightarrow{AB}=(3;\,4;\,-2)$, $\sin=\frac{2}{\sqrt{29}}$, góc $\approx21{,}8^\circ$.
> - **Làm lại Ví dụ 2** (câu b, c): $\sin=\frac{\lvert2-2-3\rvert}{\sqrt6\cdot\sqrt{14}}=\frac{3}{\sqrt{84}}$, góc $\approx19{,}1^\circ$. $\vec n_Q=[(2;\,1;\,-1),(1;\,-2;\,3)]=(1;\,-7;\,-5)$, $(Q):x-7y-5z+9=0$.
> - **Làm lại Ví dụ 3:** cùng VTPT $(2;\,-3;\,-1)$, qua $A_2$: $2x-3y-z+7=0$.
> - **Làm lại Ví dụ 4:** VTPT gọn $(3;\,3\sqrt3;\,20)$, $\cos\varphi=\frac{20}{\sqrt{436}}$, góc $\approx16{,}7^\circ$. Dây dọi tại $G$ dài $\frac{2+2{,}6+3{,}2}{3}=2{,}6$ m.
> - **Làm lại Ví dụ 5:** $AB=\sqrt{9-1}=2\sqrt2\approx2{,}83$ đơn vị $\approx18\,020$ km. Mặt phẳng $3z=1$, tức $z=\frac13$ (vĩ tuyến khoảng $19{,}5^\circ N$, nên Hà Nội nhìn thấy vệ tinh này).

## Tóm tắt — danh sách kiểm tra trước giờ thi

| Khi gặp | Nhớ ngay |
|---|---|
| Phương trình mặt phẳng | chuyển hết về một vế → VTPT = hệ số $x,y,z$ (thiếu biến là $0$) |
| Phương trình đường thẳng | VTCP = hệ số của $t$ / mẫu số (chuẩn hóa tử trước) |
| Phương trình mặt cầu | tâm đổi dấu, $R$ lấy căn; khai triển: chia hệ số $x^2$, kiểm tra $a^2+b^2+c^2-d>0$ |
| Lập phương trình | điểm + vectơ; vectơ vuông góc với hai vectơ → tích có hướng; **thử lại** |
| Giao điểm đường – mặt | thế tham số, giải $t$ |
| Vị trí hai đường | $[\vec u_1,\vec u_2]$ rồi $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$ |
| Đường – mặt | $\perp$: $\vec u\parallel\vec n$; $\parallel$: $\vec u\perp\vec n$ và điểm không thuộc |
| Khoảng cách | trị tuyệt đối ở tử, căn ở mẫu; tiếp xúc: $R=d(I,(P))$ |
| Góc | cùng loại côsin, khác loại sin; trị tuyệt đối; Deg; kết quả $\le90^\circ$ |
| Thực tế | mặt đất $(Oxy)$; độ cao ≠ khoảng cách vuông góc; khối cầu cho "vùng phủ sóng"; làm tròn cuối cùng |

**Sơ đồ một dòng:** *tọa độ + tích vô hướng + tích có hướng → mặt phẳng ($\vec n$) và đường thẳng ($\vec u$) → giao điểm, vị trí, khoảng cách, góc → mặt cầu (tâm, bán kính, tiếp xúc) → bài toán thực tế.*
