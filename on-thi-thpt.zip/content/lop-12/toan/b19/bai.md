---
title: Công thức xác suất toàn phần và công thức Bayes
thoi-gian: 50 phút
muc-tieu:
  - Hiểu vì sao có công thức xác suất toàn phần (chia trường hợp theo $A$ và $\overline{A}$) và tính được $P(B)$ trong các tình huống thực tiễn
  - Vẽ và đọc được sơ đồ hình cây, dùng nó để tính xác suất "nhân dọc nhánh, cộng các nhánh"
  - Phân biệt rõ $P(A\mid B)$ với $P(B\mid A)$, nắm được công thức Bayes và ý nghĩa "cập nhật xác suất khi có thông tin mới"
  - Vận dụng hai công thức vào các bài toán thi hay gặp - xét nghiệm y tế, sản phẩm lỗi, lọc thư rác, dự báo thời tiết, chuyển bi giữa hai hộp
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Muốn tính $P(B)$ mà $B$ phụ thuộc vào việc $A$ có xảy ra hay không → **chia hai trường hợp** $A$ và $\overline{A}$.
> 2. Công thức xác suất toàn phần: $P(B)=P(A)\cdot P(B\mid A)+P(\overline{A})\cdot P(B\mid\overline{A})$.
> 3. Sơ đồ hình cây: **nhân** các xác suất dọc một đường đi, **cộng** các đường đi cùng dẫn tới $B$.
> 4. Công thức Bayes: $P(A\mid B)=\dfrac{P(A)\cdot P(B\mid A)}{P(B)}$ — "nhánh mình quan tâm" chia cho "tổng các nhánh tới $B$".
> 5. $P(A)$ là xác suất **trước** khi biết $B$, còn $P(A\mid B)$ là xác suất **sau** khi biết $B$ đã xảy ra. Bayes là công cụ **cập nhật** niềm tin.

Ở Bài 18 em đã gặp xác suất có điều kiện $P(A\mid B)$ — xác suất của $A$ khi biết $B$ đã xảy ra — và công thức nhân xác suất. Bài này dùng đúng hai công cụ ấy để giải quyết hai câu hỏi rất "đời":

- **Câu hỏi xuôi:** biết nguyên nhân có thể xảy ra với xác suất bao nhiêu và mỗi nguyên nhân dẫn tới kết quả với xác suất bao nhiêu, thì **kết quả** xảy ra với xác suất bao nhiêu? → *công thức xác suất toàn phần*.
- **Câu hỏi ngược:** đã thấy **kết quả** rồi, thì khả năng nó do nguyên nhân nào gây ra là bao nhiêu? → *công thức Bayes*.

> [!nen-tang] Nhắc lại Bài 18
> - $P(A\mid B)=\dfrac{P(AB)}{P(B)}$ với $P(B)>0$.
> - Công thức nhân: $P(AB)=P(A)\cdot P(B\mid A)$.
> - $P(\overline{A})=1-P(A)$ và $P(\overline{B}\mid A)=1-P(B\mid A)$ (khi đã biết $A$, thì $B$ hoặc xảy ra hoặc không).
> - Kí hiệu $AB$ (hay $A\cap B$) là biến cố "cả $A$ và $B$ cùng xảy ra".

## 1. Công thức xác suất toàn phần

### 1.1. Ý tưởng: chia trường hợp

Hình dung một hội chợ ngoài trời. Lượng khách có đạt chỉ tiêu hay không **phụ thuộc vào thời tiết**: trời nắng thì dễ đạt, trời mưa thì khó. Ban tổ chức biết:

- xác suất trời mưa hôm khai mạc,
- nếu mưa thì xác suất đạt chỉ tiêu là bao nhiêu,
- nếu không mưa thì xác suất đạt chỉ tiêu là bao nhiêu.

Câu hỏi "**xác suất đạt chỉ tiêu** là bao nhiêu?" không thể trả lời bằng một con số có sẵn, vì con số ấy thay đổi theo thời tiết. Cách tự nhiên nhất là **xét từng trường hợp** của thời tiết rồi gộp lại.

Gọi $A$ là "trời mưa", $B$ là "đạt chỉ tiêu". Biến cố $B$ xảy ra theo đúng một trong hai cách **không thể cùng xảy ra**:

- trời mưa **và** đạt chỉ tiêu: biến cố $AB$,
- trời không mưa **và** đạt chỉ tiêu: biến cố $\overline{A}B$.

Vì $AB$ và $\overline{A}B$ xung khắc, mà hợp của chúng là $B$, nên theo quy tắc cộng:

$$P(B)=P(AB)+P(\overline{A}B).$$

Mỗi số hạng tính bằng công thức nhân (Bài 18): $P(AB)=P(A)\cdot P(B\mid A)$ và $P(\overline{A}B)=P(\overline{A})\cdot P(B\mid\overline{A})$. Thế vào là được công thức.

> [!ghi-nho] Công thức xác suất toàn phần (SGK tr. 72)
> Cho hai biến cố $A$ và $B$. Khi đó
> $$\begin{aligned}P(B)&=P(A)\cdot P(B\mid A)\\&\quad+P(\overline{A})\cdot P(B\mid\overline{A}).\end{aligned}$$

Đọc công thức bằng lời: **xác suất của kết quả = (xác suất trường hợp 1) × (xác suất kết quả trong trường hợp 1) + (xác suất trường hợp 2) × (xác suất kết quả trong trường hợp 2)**. Nó giống như tính "điểm trung bình có trọng số": $P(B)$ là trung bình của $P(B\mid A)$ và $P(B\mid\overline{A})$ với trọng số $P(A)$ và $P(\overline{A})$. Vì thế $P(B)$ luôn nằm **giữa** hai số $P(B\mid A)$ và $P(B\mid\overline{A})$ — một cách kiểm tra nhanh đáp số.

> [!vi-du] Ví dụ 1
> Xác suất trời mưa vào ngày khai mạc một hội chợ ngoài trời là $0{,}3$. Nếu trời mưa, xác suất hội chợ đạt chỉ tiêu khách là $0{,}5$. Nếu không mưa, xác suất đó là $0{,}85$. Tính xác suất hội chợ đạt chỉ tiêu khách.

> [!goi-y] Gợi ý 1
> Đặt tên biến cố: $A$ là "trời mưa", $B$ là "đạt chỉ tiêu". Đề cho những số nào trong bốn số $P(A)$, $P(\overline{A})$, $P(B\mid A)$, $P(B\mid\overline{A})$?

> [!goi-y] Gợi ý 2
> $P(A)=0{,}3$ nên $P(\overline{A})=0{,}7$. "Nếu trời mưa thì…" là điều kiện $A$ → $P(B\mid A)=0{,}5$.

> [!loi-giai] Lời giải
> $P(A)=0{,}3$, $P(\overline{A})=0{,}7$, $P(B\mid A)=0{,}5$, $P(B\mid\overline{A})=0{,}85$.
> Theo công thức xác suất toàn phần:
> $$\begin{aligned}P(B)&=0{,}3\cdot0{,}5+0{,}7\cdot0{,}85\\&=0{,}15+0{,}595=0{,}745.\end{aligned}$$
> Kiểm tra: $0{,}745$ nằm giữa $0{,}5$ và $0{,}85$, và gần $0{,}85$ hơn vì trường hợp "không mưa" có trọng số lớn hơn ✓.

> [!bay] Cộng thẳng hai xác suất có điều kiện
> Lỗi hay gặp nhất: viết $P(B)=P(B\mid A)+P(B\mid\overline{A})=0{,}5+0{,}85=1{,}35$ — vô lí vì xác suất không vượt quá $1$. Hoặc lấy trung bình cộng $\dfrac{0{,}5+0{,}85}{2}$ — chỉ đúng khi $P(A)=P(\overline{A})=0{,}5$. Hai xác suất có điều kiện phải được **nhân với trọng số** $P(A)$, $P(\overline{A})$ của từng trường hợp.

### 1.2. Sơ đồ hình cây

Khi bài toán có nhiều số liệu, em nên vẽ **sơ đồ hình cây** để không nhầm. Cách vẽ:

1. Từ gốc kẻ hai nhánh tới $A$ và $\overline{A}$, ghi trên nhánh $P(A)$ và $P(\overline{A})$ (tổng bằng $1$).
2. Từ mỗi nút $A$, $\overline{A}$ lại kẻ hai nhánh tới $B$ và $\overline{B}$, ghi xác suất **có điều kiện**: từ $A$ ghi $P(B\mid A)$, $P(\overline{B}\mid A)$, từ $\overline{A}$ ghi $P(B\mid\overline{A})$, $P(\overline{B}\mid\overline{A})$. Hai nhánh xuất phát từ một nút luôn có tổng bằng $1$.
3. **Nhân** các số dọc một đường đi từ gốc → được xác suất của "cả đường đi" (ví dụ đường gốc → $A$ → $B$ cho $P(AB)$).
4. **Cộng** các đường đi cùng kết thúc ở $B$ → được $P(B)$.

![Hình 1. Sơ đồ hình cây: nhân dọc theo mỗi đường đi, cộng các đường đi kết thúc ở B](h1-so-do-cay.svg)

> [!meo] Kiểm tra cây đã đúng chưa
> Tổng xác suất của **cả bốn lá** phải bằng $1$. Nếu không bằng $1$, em đã ghi sai một số trên nhánh, thường là ghi $P(B)$ hoặc $P(AB)$ vào chỗ của $P(B\mid A)$.

Sơ đồ hình cây đặc biệt hữu ích với bài toán **"chuỗi ngày"**: hôm sau phụ thuộc hôm nay. Muốn đi từ thứ Hai tới thứ Tư thì phải "đi qua" thứ Ba, và thứ Ba chính là chỗ ta chia trường hợp.

> [!vi-du] Ví dụ 2
> Mỗi ngày bạn Minh đi học bằng xe đạp hoặc xe buýt. Nếu hôm nay Minh đi xe đạp thì xác suất hôm sau Minh vẫn đi xe đạp là $0{,}6$. Nếu hôm nay Minh đi xe buýt thì xác suất hôm sau Minh đi xe đạp là $0{,}5$. Biết thứ Hai tuần này Minh đi xe đạp. Tính xác suất thứ Tư Minh đi xe đạp.

> [!goi-y] Gợi ý 1
> Thứ Tư phụ thuộc vào thứ Ba, nên chọn $A$ là "thứ Ba đi xe đạp" và $B$ là "thứ Tư đi xe đạp".

> [!goi-y] Gợi ý 2
> Thứ Hai đi xe đạp nên $P(A)=0{,}6$. Còn $P(B\mid A)$ là "hôm trước xe đạp → hôm sau xe đạp", $P(B\mid\overline{A})$ là "hôm trước xe buýt → hôm sau xe đạp".

> [!loi-giai] Lời giải
> $P(A)=0{,}6$, $P(\overline{A})=0{,}4$, $P(B\mid A)=0{,}6$, $P(B\mid\overline{A})=0{,}5$.
> Cây có hai đường đi tới $B$: (xe đạp, xe đạp) với xác suất $0{,}6\cdot0{,}6=0{,}36$ và (xe buýt, xe đạp) với xác suất $0{,}4\cdot0{,}5=0{,}2$.
> Vậy $P(B)=0{,}36+0{,}2=0{,}56$.

> [!bay]
> Đừng trả lời $0{,}6$ (đó là xác suất cho **thứ Ba**). Thứ Tư cách thứ Hai **hai** ngày, phải qua một bước chia trường hợp.

### 1.3. Ứng dụng trong Sinh học: di truyền trong quần thể

Đây là dạng liên môn rất hợp với em — học sinh khối B. SGK có một bài Vận dụng cùng ý tưởng (SGK tr. 74), ta làm một ví dụ khác số liệu.

> [!nen-tang] Sinh học cần nhớ
> Cây con nhận **một** allele từ cây bố và **một** allele từ cây mẹ, một cách ngẫu nhiên và độc lập. Cây có kiểu gene $aa$ chắc chắn cho allele $a$. Cây có kiểu gene $Aa$ cho allele $a$ với xác suất $\dfrac12$.

> [!vi-du] Ví dụ 3
> Ở một loài cây, allele $A$ (hoa đỏ) trội hoàn toàn so với $a$ (hoa trắng). Trong một quần thể chỉ có hai loại kiểu gene: $aa$ chiếm $30\%$, $Aa$ chiếm $70\%$. Chọn ngẫu nhiên, độc lập một cây bố và một cây mẹ trong quần thể để lai. Tính xác suất cây con có kiểu gene $aa$ (hoa trắng).

> [!goi-y] Gợi ý 1
> Trước hết tính $P(M)$ với $M$ là "cây con nhận allele $a$ từ bố". Chia trường hợp theo kiểu gene của bố: $aa$ hay $Aa$.

> [!goi-y] Gợi ý 2
> Cây con có kiểu gene $aa$ khi nhận $a$ từ bố **và** nhận $a$ từ mẹ, hai việc độc lập.

> [!loi-giai] Lời giải
> Gọi $E$ là "bố có kiểu gene $aa$", khi đó $\overline{E}$ là "bố có kiểu gene $Aa$". Ta có $P(E)=0{,}3$, $P(\overline{E})=0{,}7$, $P(M\mid E)=1$, $P(M\mid\overline{E})=0{,}5$.
> $$P(M)=0{,}3\cdot1+0{,}7\cdot0{,}5=0{,}65.$$
> Tương tự, xác suất nhận $a$ từ mẹ cũng là $0{,}65$. Do bố và mẹ được chọn độc lập:
> Xác suất cây con có kiểu gene $aa$ là $0{,}65\cdot0{,}65=0{,}4225\approx42{,}25\%$.

> [!em-co-biet]
> Con số $0{,}65$ chính là **tần số allele $a$** trong quần thể ($0{,}3+\frac12\cdot0{,}7$). Em sẽ gặp lại phép tính này trong chương Di truyền quần thể của môn Sinh học. Công thức xác suất toàn phần là "phiên bản xác suất" của việc tính tần số allele.

### 1.4. Mở rộng (ngoài SGK): chia nhiều hơn hai trường hợp

SGK chỉ phát biểu công thức với hai trường hợp $A$, $\overline{A}$. Phần này là **mở rộng, ngoài SGK**. Nhưng đề thi rất hay cho **ba** nguồn (ba máy, ba phân xưởng, ba nhà cung cấp…). Ý tưởng giữ nguyên: các trường hợp $A_1, A_2, A_3$ phải **đôi một xung khắc và luôn có đúng một trường hợp xảy ra** (tổng xác suất bằng $1$). Khi đó

$$\begin{aligned}P(B)&=P(A_1)\cdot P(B\mid A_1)\\&\quad+P(A_2)\cdot P(B\mid A_2)\\&\quad+P(A_3)\cdot P(B\mid A_3).\end{aligned}$$

Trên sơ đồ hình cây, gốc chỉ việc có ba nhánh thay vì hai (xem Hình 4 ở phần Dạng bài thi).

## 2. Công thức Bayes

### 2.1. $P(A\mid B)$ và $P(B\mid A)$ — hai con số rất khác nhau

Một xét nghiệm y tế có thể sai theo hai kiểu:

- **dương tính giả:** xét nghiệm báo dương tính nhưng người đó **không** mắc bệnh,
- **âm tính giả:** xét nghiệm báo âm tính nhưng người đó **có** mắc bệnh.

Gọi $A$ là "người đó mắc bệnh", $B$ là "xét nghiệm dương tính". Nhà sản xuất thường công bố:

- $P(B\mid A)$: trong số người **bệnh**, tỉ lệ được báo dương tính — gọi là **độ nhạy**,
- $P(\overline{B}\mid\overline{A})$: trong số người **không bệnh**, tỉ lệ được báo âm tính — gọi là **độ đặc hiệu**. Khi đó $P(B\mid\overline{A})=1-$ độ đặc hiệu là xác suất **dương tính giả**.

Nhưng người đi xét nghiệm, khi cầm tờ kết quả dương tính, lại muốn biết điều khác: **"Mình đã dương tính, vậy xác suất mình thật sự bị bệnh là bao nhiêu?"** — đó là $P(A\mid B)$.

> [!bay] Đảo điều kiện — sai lầm kinh điển
> "Xét nghiệm có độ nhạy $95\%$" **không** có nghĩa là "người dương tính có $95\%$ khả năng bị bệnh". $P(B\mid A)$ và $P(A\mid B)$ thường khác nhau rất xa. Mẹo đọc: chữ đứng **sau** dấu gạch là điều **đã biết**. $P(B\mid A)$ là "đã biết bị bệnh, hỏi dương tính". $P(A\mid B)$ là "đã biết dương tính, hỏi bị bệnh".

Một ví dụ đời thường giúp em thấy rõ: gọi $N$ là “người đó là nam”, $C$ là “người đó là cầu thủ bóng đá chuyên nghiệp”. Hầu hết cầu thủ chuyên nghiệp là nam, nên $P(N\mid C)$ rất gần $1$. Nhưng chọn ngẫu nhiên một người nam, xác suất người đó là cầu thủ chuyên nghiệp, tức $P(C\mid N)$, lại rất gần $0$.

### 2.2. Công thức Bayes — rút ra trong hai dòng

Từ định nghĩa xác suất có điều kiện và công thức nhân:

$$P(A\mid B)=\frac{P(AB)}{P(B)}=\frac{P(A)\cdot P(B\mid A)}{P(B)}.$$

Mẫu số $P(B)$ thường chưa có sẵn, ta tính nó bằng công thức xác suất toàn phần.

> [!ghi-nho] Công thức Bayes (SGK tr. 75)
> Cho hai biến cố $A$, $B$ với $P(B)>0$. Khi đó
> $$P(A\mid B)=\frac{P(A)\cdot P(B\mid A)}{P(B)},$$
> trong đó mẫu số tính bằng công thức xác suất toàn phần:
> $$\begin{aligned}P(B)&=P(A)\cdot P(B\mid A)\\&\quad+P(\overline{A})\cdot P(B\mid\overline{A}).\end{aligned}$$
> Thay mẫu số bằng tổng này là được dạng đầy đủ của công thức Bayes như trong SGK.

**Đọc trên sơ đồ hình cây:** mẫu số là tổng các đường đi tới $B$ (đã tính bằng xác suất toàn phần), tử số là **riêng đường đi qua $A$** rồi tới $B$. Vậy

> [!ghi-nho]
> $P(A\mid B)$ = (xác suất đường đi qua $A$ rồi tới $B$) chia cho (tổng xác suất các đường đi tới $B$).

Hiểu như vậy em không cần học thuộc công thức dài: vẽ cây, tính các lá, lấy **"lá mình cần" chia cho "tổng các lá cùng loại"**.

> [!vi-du] Ví dụ 4
> Ở một trường, $40\%$ học sinh lớp 12 tham gia câu lạc bộ tiếng Anh. Một học sinh tham gia câu lạc bộ đạt IELTS từ $6{,}0$ trở lên với xác suất $0{,}5$, học sinh không tham gia đạt mức đó với xác suất $0{,}2$. Chọn ngẫu nhiên một học sinh lớp 12 và biết em này đạt IELTS từ $6{,}0$ trở lên. Tính xác suất em này có tham gia câu lạc bộ.

> [!goi-y] Gợi ý 1
> $A$ là "tham gia câu lạc bộ", $B$ là "đạt IELTS từ $6{,}0$". Điều **đã biết** là $B$, nên cần tính $P(A\mid B)$.

> [!goi-y] Gợi ý 2
> Tính hai lá dẫn tới $B$: $0{,}4\cdot0{,}5$ và $0{,}6\cdot0{,}2$.

> [!loi-giai] Lời giải
> Bước 1 — xác suất toàn phần: $P(B)=0{,}4\cdot0{,}5+0{,}6\cdot0{,}2=0{,}2+0{,}12=0{,}32$.
> Bước 2 — Bayes: $P(A\mid B)=\dfrac{0{,}2}{0{,}32}=0{,}625$.
> Nhận xét: trước khi biết kết quả IELTS, khả năng em này tham gia câu lạc bộ là $40\%$. Sau khi biết em đạt $6{,}0$, khả năng ấy tăng lên $62{,}5\%$.

### 2.3. Ý nghĩa: cập nhật xác suất khi có thông tin mới

Nhận xét cuối Ví dụ 4 chính là **linh hồn** của công thức Bayes (SGK tr. 75):

- $P(A)$ là hiểu biết **ban đầu** về $A$ (trước khi có thông tin), còn gọi là xác suất *tiên nghiệm*.
- Khi nhận được thông tin "$B$ đã xảy ra", ta **cập nhật** thành $P(A\mid B)$, còn gọi là xác suất *hậu nghiệm*.
- Thông tin $B$ "ủng hộ" $A$ (tức $P(B\mid A)>P(B\mid\overline{A})$) thì xác suất của $A$ **tăng lên**. Ngược lại thì giảm xuống.

Bây giờ là bài toán kinh điển nhất của bài — và cũng là dạng đề thi rất hay ra.

> [!vi-du] Ví dụ 5 (xét nghiệm dương tính)
> Một bệnh có tỉ lệ mắc trong cộng đồng là $1\%$. Xét nghiệm bệnh này có độ nhạy $90\%$ (người bệnh được báo dương tính với xác suất $0{,}9$). Người không bệnh vẫn bị báo dương tính với xác suất $0{,}05$. Bà K làm xét nghiệm và nhận kết quả dương tính. Tính xác suất bà K thật sự mắc bệnh.

> [!goi-y] Gợi ý 1
> Khi chưa biết gì thêm, bà K là "một người bất kì" trong cộng đồng, nên $P(A)=0{,}01$.

> [!goi-y] Gợi ý 2
> Vẽ cây (Hình 2). Lá "bệnh và dương tính" là $0{,}01\cdot0{,}9$, lá "không bệnh nhưng dương tính" là $0{,}99\cdot0{,}05$.

> [!loi-giai] Lời giải
> Gọi $A$ là "bà K mắc bệnh", $B$ là "xét nghiệm dương tính".
> $P(A)=0{,}01$, $P(\overline{A})=0{,}99$, $P(B\mid A)=0{,}9$, $P(B\mid\overline{A})=0{,}05$.
> $P(B)=0{,}01\cdot0{,}9+0{,}99\cdot0{,}05=0{,}009+0{,}0495=0{,}0585$.
> $$P(A\mid B)=\frac{0{,}009}{0{,}0585}\approx0{,}154.$$
> Dù dương tính, xác suất bà K mắc bệnh chỉ khoảng $15{,}4\%$ — **không phải** $90\%$!

![Hình 2. Sơ đồ hình cây của bài toán xét nghiệm: hai lá dẫn tới kết quả dương tính](h2-cay-xet-nghiem.svg)

**Vì sao thấp bất ngờ như vậy?** Hãy hình dung bằng **số người** thay vì xác suất. Lấy $10\,000$ người:

![Hình 3. Hình dung bằng tần số: trong 10 000 người, phần lớn người dương tính lại là dương tính giả](h3-10000-nguoi.svg)

Người không bệnh **đông gấp 99 lần** người bệnh. Vì thế dù chỉ $5\%$ trong số họ bị báo nhầm, con số $495$ người dương tính giả vẫn "lấn át" $90$ người dương tính thật. Đây là lí do bác sĩ thường cho **xét nghiệm lại** hoặc làm thêm xét nghiệm khác trước khi kết luận, nhất là với bệnh hiếm.

> [!meo] Cách "10 000 người"
> Với bài xét nghiệm, đổi xác suất thành số người (chọn $1\,000$, $10\,000$ hay $100\,000$ sao cho ra số nguyên) giúp em tính nhẩm nhanh và tự kiểm tra đáp số. Xác suất bệnh khi đã dương tính = (số người bệnh và dương tính) chia cho (tổng số người dương tính).

> [!ung-dung] Xét nghiệm lần hai
> Nếu bà K xét nghiệm thêm một lần nữa (giả sử hai lần xét nghiệm cho kết quả độc lập với nhau khi đã biết tình trạng bệnh) và vẫn dương tính, ta dùng Bayes **lần nữa**, lấy $0{,}154$ (chính xác là $\frac{2}{13}$) làm xác suất ban đầu mới:
> $$P=\frac{\frac{2}{13}\cdot0{,}9}{\frac{2}{13}\cdot0{,}9+\frac{11}{13}\cdot0{,}05}\approx0{,}766.$$
> Sau hai lần dương tính, khả năng mắc bệnh tăng lên khoảng $76{,}6\%$. Đó đúng là tinh thần "cập nhật khi có thông tin mới": mỗi bằng chứng mới lại làm hiểu biết của ta chính xác hơn.

Công thức Bayes cũng áp dụng cho kết quả **âm tính**. Khi đó điều đã biết là $\overline{B}$, ta thay $B$ bằng $\overline{B}$ và có thể hỏi về $A$ hoặc $\overline{A}$.

> [!vi-du] Ví dụ 6 (xét nghiệm âm tính)
> Với bệnh và xét nghiệm như Ví dụ 5, ông H nhận kết quả âm tính.
>
> a) Trước khi xét nghiệm, xác suất ông H không mắc bệnh là bao nhiêu?
>
> b) Sau khi có kết quả âm tính, xác suất ông H không mắc bệnh là bao nhiêu (làm tròn đến hàng phần nghìn)?

> [!goi-y] Gợi ý 1
> b) Cần tính $P(\overline{A}\mid\overline{B})$. Hai lá dẫn tới "âm tính" là "không bệnh, âm tính" và "bệnh, âm tính".

> [!goi-y] Gợi ý 2
> $P(\overline{B}\mid\overline{A})=1-0{,}05=0{,}95$ và $P(\overline{B}\mid A)=1-0{,}9=0{,}1$.

> [!loi-giai] Lời giải
> a) $P(\overline{A})=1-0{,}01=0{,}99$.
>
> b) Theo công thức Bayes (vai trò của $A$ do $\overline{A}$ đảm nhận, của $B$ do $\overline{B}$ đảm nhận):
> $$\begin{aligned}P(\overline{A}\mid\overline{B})&=\frac{0{,}99\cdot0{,}95}{0{,}99\cdot0{,}95+0{,}01\cdot0{,}1}\\&=\frac{0{,}9405}{0{,}9415}\approx0{,}999.\end{aligned}$$
> Kết quả âm tính làm khả năng "không bệnh" tăng từ $99\%$ lên khoảng $99{,}9\%$. Xét nghiệm âm tính rất đáng tin, còn dương tính thì cần kiểm tra thêm.

> [!bay] Chọn sai "lá" khi kết quả là âm tính
> Khi đề cho âm tính, nhiều bạn vẫn dùng $0{,}9$ và $0{,}05$ (là các xác suất **dương tính**). Phải đổi sang $P(\overline{B}\mid A)=0{,}1$ và $P(\overline{B}\mid\overline{A})=0{,}95$. Vẽ đủ cả bốn lá của cây là cách chắc chắn nhất để không nhầm.

## Dạng bài thi hay gặp

Mọi dạng đều theo một quy trình bốn bước:

1. **Đặt tên** biến cố: $A$ là "nguyên nhân" (trường hợp), $B$ là "kết quả quan sát được".
2. **Dịch đề** thành bốn số: $P(A)$, $P(\overline{A})$, $P(B\mid A)$, $P(B\mid\overline{A})$. Câu "nếu… thì xác suất…" luôn là xác suất **có điều kiện**.
3. Hỏi xác suất **của kết quả** → xác suất toàn phần. Hỏi xác suất **của nguyên nhân khi đã biết kết quả** ("biết rằng…", "chọn được… tính xác suất nó thuộc…") → Bayes.
4. Chỉ **làm tròn ở bước cuối**.

### Dạng 1. Hai trường hợp — câu Đúng/Sai 4 ý

- **Nhận biết:** một "nguyên nhân" chỉ có hai khả năng (mưa/không mưa, bệnh/không bệnh, thư rác/thư thường), có kèm các tỉ lệ "nếu… thì…".
- **Phương pháp:** vẽ cây hai tầng, tính sẵn **cả bốn lá**. Mỗi ý Đúng/Sai thường hỏi một lá, một tổng (xác suất toàn phần) hoặc một tỉ số (Bayes).
- **Bẫy:** ý hỏi $P(B\mid A)$ nhưng viết như $P(A\mid B)$, ý hỏi về $\overline{B}$ mà lại dùng số của $B$.

> [!vi-du] Ví dụ 7 (Đúng/Sai)
> Ở một vùng, tỉ lệ ngày có mưa trong tháng 7 là $40\%$. Một ứng dụng thời tiết, vào tối hôm trước, báo "mai có mưa" với xác suất $0{,}8$ nếu hôm sau thật sự mưa, và với xác suất $0{,}15$ nếu hôm sau không mưa. Xét một ngày ngẫu nhiên trong tháng 7.
>
> a) Xác suất ứng dụng báo "mai có mưa" là $0{,}41$.
>
> b) Xác suất hôm đó không mưa nhưng ứng dụng vẫn báo mưa là $0{,}15$.
>
> c) Biết ứng dụng đã báo mưa, xác suất hôm đó mưa thật lớn hơn $0{,}75$.
>
> d) Biết ứng dụng báo không mưa, xác suất hôm đó không mưa nhỏ hơn $0{,}85$.

> [!goi-y] Gợi ý 1
> $A$ là "hôm đó mưa", $B$ là "ứng dụng báo mưa". Bốn lá: $0{,}4\cdot0{,}8$, $0{,}4\cdot0{,}2$, $0{,}6\cdot0{,}15$, $0{,}6\cdot0{,}85$.

> [!goi-y] Gợi ý 2
> Ý b) hỏi xác suất của **cả** "không mưa **và** báo mưa" (một lá), không phải xác suất có điều kiện.

> [!loi-giai] Lời giải
> Bốn lá: $P(AB)=0{,}32$, $P(A\overline{B})=0{,}08$, $P(\overline{A}B)=0{,}09$, $P(\overline{A}\,\overline{B})=0{,}51$ (tổng bằng $1$ ✓).
>
> a) **Đúng** — $P(B)=0{,}32+0{,}09=0{,}41$.
>
> b) **Sai** — $P(\overline{A}B)=0{,}6\cdot0{,}15=0{,}09$. Số $0{,}15$ là $P(B\mid\overline{A})$.
>
> c) **Đúng** — $P(A\mid B)=\dfrac{0{,}32}{0{,}41}\approx0{,}780>0{,}75$.
>
> d) **Sai** — $P(\overline{B})=0{,}59$, $P(\overline{A}\mid\overline{B})=\dfrac{0{,}51}{0{,}59}\approx0{,}864>0{,}85$.

### Dạng 2. Nhiều nguồn (ba máy, ba phân xưởng) — trả lời ngắn

- **Nhận biết:** sản phẩm đến từ ba (hoặc nhiều) nguồn với tỉ lệ đóng góp khác nhau, mỗi nguồn có tỉ lệ lỗi riêng.
- **Phương pháp:** cây có ba nhánh ở tầng đầu (công thức mở rộng ở mục 1.4, ngoài SGK). Xác suất lỗi = tổng các tích. Xác suất sản phẩm thuộc nguồn $i$ khi đã biết nó lỗi = tích của nguồn $i$ chia cho tổng đó.
- **Bẫy:** nghĩ rằng sản phẩm lỗi "chắc là" của máy có **tỉ lệ lỗi** cao nhất. Thật ra phải so sánh **tích** (tỉ lệ đóng góp × tỉ lệ lỗi): máy làm ít sản phẩm thì dù hay lỗi cũng có thể góp ít phế phẩm.

> [!vi-du] Ví dụ 8
> Một xưởng có ba máy cùng làm một loại chi tiết. Máy I, II, III lần lượt làm ra $50\%$, $30\%$, $20\%$ tổng số chi tiết, với tỉ lệ chi tiết lỗi tương ứng $1\%$, $2\%$, $4\%$. Lấy ngẫu nhiên một chi tiết của xưởng.
>
> a) Tính xác suất chi tiết đó bị lỗi.
>
> b) Biết chi tiết lấy ra bị lỗi. Tính xác suất nó do máy III làm ra (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Ba trường hợp $A_1, A_2, A_3$ ("do máy I, II, III làm") có tổng xác suất $0{,}5+0{,}3+0{,}2=1$.

> [!goi-y] Gợi ý 2
> Ba lá "lỗi": $0{,}5\cdot0{,}01$, $0{,}3\cdot0{,}02$, $0{,}2\cdot0{,}04$.

> [!loi-giai] Lời giải
> a) $P(B)=0{,}005+0{,}006+0{,}008=0{,}019$.
>
> b) $P(A_3\mid B)=\dfrac{0{,}008}{0{,}019}\approx0{,}42$.
>
> Tương tự $P(A_1\mid B)\approx0{,}26$ và $P(A_2\mid B)\approx0{,}32$ (ba số này cộng lại bằng $1$).

![Hình 4. Sơ đồ hình cây ba nhánh (mở rộng, ngoài SGK): chi tiết do ba máy làm ra, mỗi máy có tỉ lệ lỗi riêng](h4-ba-may.svg)

### Dạng 3. Chuyển bi giữa hai hộp (hoặc chọn ngẫu nhiên một hộp)

- **Nhận biết:** "lấy một viên từ hộp I bỏ sang hộp II, rồi lấy từ hộp II", hoặc "chọn ngẫu nhiên một hộp rồi lấy một viên".
- **Phương pháp:** trường hợp là **viên bi được chuyển** (hoặc **hộp được chọn**). Trong mỗi trường hợp, đếm lại số bi của hộp II **sau khi chuyển** rồi tính xác suất cổ điển.
- **Bẫy:** quên rằng hộp II đã có thêm một viên (mẫu số tăng $1$). Với kiểu "chọn ngẫu nhiên một hộp", **không được** gộp bi hai hộp lại rồi tính.

> [!vi-du] Ví dụ 9
> Hộp I có $4$ bi đỏ và $6$ bi xanh, hộp II có $3$ bi đỏ và $2$ bi xanh. Lấy ngẫu nhiên một viên từ hộp I bỏ vào hộp II, rồi từ hộp II lấy ngẫu nhiên một viên.
>
> a) Tính xác suất viên lấy ra từ hộp II là bi đỏ.
>
> b) Biết viên lấy ra từ hộp II là bi đỏ. Tính xác suất viên bi đã chuyển là bi đỏ.

> [!goi-y] Gợi ý 1
> $A$ là "chuyển bi đỏ": $P(A)=\frac{4}{10}$. Nếu chuyển bi đỏ, hộp II có $4$ đỏ, $2$ xanh. Nếu chuyển bi xanh, hộp II có $3$ đỏ, $3$ xanh.

> [!goi-y] Gợi ý 2
> b) là câu hỏi ngược → Bayes: lá "chuyển đỏ, lấy đỏ" chia cho tổng các lá "lấy đỏ".

> [!loi-giai] Lời giải
> a) $P(B)=\dfrac{4}{10}\cdot\dfrac{4}{6}+\dfrac{6}{10}\cdot\dfrac{3}{6}=\dfrac{8}{30}+\dfrac{9}{30}=\dfrac{17}{30}\approx0{,}567$.
>
> b) $P(A\mid B)=\dfrac{8/30}{17/30}=\dfrac{8}{17}\approx0{,}47$.
>
> Nhận xét: biết lấy được bi đỏ, khả năng bi chuyển là đỏ tăng từ $0{,}4$ lên khoảng $0{,}47$ — hợp lí, vì chuyển bi đỏ sang làm hộp II "đỏ hơn".

> [!meo] Bấm máy với phân số
> Nhập thẳng phân số trên Casio fx-580VN X (phím phân số) và để máy giữ kết quả dạng phân số, ví dụ $\frac{4}{10}\times\frac{4}{6}+\frac{6}{10}\times\frac{3}{6}$ ra $\frac{17}{30}$. Lưu vào biến bằng **STO** (ví dụ $A$), rồi tính $\frac{8}{30}\div A$ để khỏi làm tròn sớm.

### Dạng 4. Bài toán ngược — tìm tỉ lệ ban đầu hoặc điều kiện của xét nghiệm

- **Nhận biết:** đề cho $P(B)$ (ví dụ "tỉ lệ người dương tính quan sát được là…") và hỏi $P(A)$, hoặc hỏi xét nghiệm phải tốt đến mức nào để $P(A\mid B)$ đạt một ngưỡng.
- **Phương pháp:** đặt ẩn ($p=P(A)$ hoặc $x=P(B\mid\overline{A})$), viết công thức xác suất toàn phần hoặc Bayes theo ẩn → giải phương trình/bất phương trình bậc nhất.
- **Bẫy:** quên $P(\overline{A})=1-p$ cũng chứa ẩn. Quên đổi giữa "độ đặc hiệu" và "xác suất dương tính giả" (tổng của chúng bằng $1$).

> [!vi-du] Ví dụ 10
> a) Một xét nghiệm cho kết quả dương tính với xác suất $0{,}9$ ở người bệnh và $0{,}1$ ở người không bệnh. Khi xét nghiệm đại trà, có $14\%$ số người cho kết quả dương tính. Ước lượng tỉ lệ mắc bệnh trong cộng đồng.
>
> b) Một bệnh có tỉ lệ mắc $2\%$, xét nghiệm có độ nhạy $95\%$. Xác suất dương tính giả phải nhỏ hơn hoặc bằng bao nhiêu để một người dương tính có ít nhất $50\%$ khả năng thật sự bị bệnh?

> [!goi-y] Gợi ý 1
> a) Gọi $p$ là tỉ lệ mắc bệnh: $0{,}9p+0{,}1(1-p)=0{,}14$.

> [!goi-y] Gợi ý 2
> b) Gọi $x=P(B\mid\overline{A})$. Điều kiện $\dfrac{0{,}02\cdot0{,}95}{0{,}02\cdot0{,}95+0{,}98x}\ge0{,}5$ tương đương "tử số $\ge$ phần còn lại của mẫu số".

> [!loi-giai] Lời giải
> a) $0{,}8p+0{,}1=0{,}14\iff p=0{,}05$. Tỉ lệ mắc bệnh khoảng $5\%$.
>
> b) Điều kiện tương đương $0{,}019\ge0{,}98x$, tức $x\le\dfrac{0{,}019}{0{,}98}\approx0{,}0194$. Vậy xác suất dương tính giả phải không quá khoảng $1{,}94\%$, tức độ đặc hiệu phải từ khoảng $98{,}06\%$ trở lên. Với bệnh hiếm, xét nghiệm phải có độ đặc hiệu **rất** cao thì kết quả dương tính mới đáng tin.

## Tóm tắt

| Nội dung | Công thức / cách làm |
|---|---|
| Bốn số cần có | $P(A)$, $P(\overline{A})=1-P(A)$, $P(B\mid A)$, $P(B\mid\overline{A})$ |
| Công thức nhân (Bài 18) | $P(AB)=P(A)\cdot P(B\mid A)$ |
| Xác suất toàn phần | $P(B)=P(A)\cdot P(B\mid A)+P(\overline{A})\cdot P(B\mid\overline{A})$ |
| Nhiều trường hợp $A_1,\dots,A_n$ (mở rộng, ngoài SGK) | $P(B)=\sum P(A_i)\cdot P(B\mid A_i)$ |
| Công thức Bayes | $P(A\mid B)=\dfrac{P(A)\cdot P(B\mid A)}{P(B)}$ |
| Đọc trên cây | Nhân dọc nhánh, cộng các nhánh tới $B$. Bayes = lá cần tìm chia tổng các lá tới $B$ |
| Độ nhạy | $P(B\mid A)$ — người bệnh được báo dương tính |
| Độ đặc hiệu | $P(\overline{B}\mid\overline{A})$ — người không bệnh được báo âm tính |
| Dương tính giả | $P(B\mid\overline{A})=1-$ độ đặc hiệu |

**Sơ đồ tư duy khi gặp đề:** đọc câu hỏi → hỏi **kết quả** thì cộng các nhánh (toàn phần) → hỏi **nguyên nhân khi đã biết kết quả** thì lấy một nhánh chia tổng (Bayes) → kiểm tra: tổng bốn lá bằng $1$, xác suất toàn phần nằm giữa các xác suất có điều kiện, kết quả Bayes có "hợp lí" theo hướng thông tin mới.
