---
title: Ôn tập chương VI
thoi-gian: 60 phút
muc-tieu:
  - Hệ thống hóa chương VI quanh một khái niệm duy nhất là xác suất có điều kiện $P(A\mid B)$, và ba công thức sinh ra từ nó - công thức nhân, công thức xác suất toàn phần, công thức Bayes
  - Phân biệt chắc chắn các cặp dễ nhầm - $P(AB)$ với $P(A\mid B)$ và $P(B\mid A)$, độc lập với xung khắc, $P(\overline{A}\mid B)$ với $P(A\mid\overline{B})$, xác suất toàn phần với Bayes, độ nhạy với xác suất mắc bệnh khi dương tính
  - Chuyển linh hoạt giữa ba cách tổ chức dữ liệu - đếm trên không gian thu gọn, bảng $2\times2$, sơ đồ hình cây
  - Nhận ra và tránh các lỗi sai hay gặp nhất của chương, giải được bài tổng hợp theo ba dạng đề tốt nghiệp
  - Tự làm được các dạng của "Bài tập cuối chương VI" (SGK tr. 79–80)
---
> [!ghi-nho] Chương này trong 10 dòng
> 1. $P(A\mid B)$ là xác suất của $A$ **khi đã biết** $B$ xảy ra. Biết $B$ thì "thế giới" thu lại chỉ còn $B$, nên $P(A\mid B)=\dfrac{P(AB)}{P(B)}$, hay $\dfrac{n(AB)}{n(B)}$ khi các kết quả đồng khả năng.
> 2. Biến cố đứng **sau** dấu "$\mid$" là điều đã biết, nhận ra qua các cụm "biết rằng", "nếu", "trong số những…".
> 3. **Công thức nhân** (đúng với mọi $A$, $B$): $P(AB)=P(A)\cdot P(B\mid A)=P(B)\cdot P(A\mid B)$.
> 4. $A$, $B$ độc lập khi và chỉ khi $P(A\mid B)=P(A)$. Xung khắc (xác suất dương) thì $P(A\mid B)=0$, nên **không** độc lập.
> 5. Trong không gian thu gọn $B$, phần bù vẫn là phần bù: $P(\overline{A}\mid B)=1-P(A\mid B)$. Nhưng $P(A\mid\overline{B})$ là một số khác hẳn.
> 6. **Bảng $2\times2$**: thêm dòng, cột tổng. $P(A\mid B)$ = ô giao chia **tổng hàng (cột) của $B$**, còn $P(AB)$ = ô giao chia **tổng chung**.
> 7. **Sơ đồ hình cây**: nhánh cấp 2 ghi xác suất có điều kiện. Một đường đi thì **nhân**, nhiều đường đi thì **cộng**.
> 8. **Xác suất toàn phần** (hỏi kết quả): $P(B)=P(A)\cdot P(B\mid A)+P(\overline{A})\cdot P(B\mid\overline{A})$.
> 9. **Bayes** (hỏi nguyên nhân khi đã thấy kết quả): $P(A\mid B)=\dfrac{P(A)\cdot P(B\mid A)}{P(B)}$, tức "lá mình cần" chia "tổng các lá dẫn tới $B$".
> 10. Nói chung $P(A\mid B)\ne P(B\mid A)$. Độ nhạy cao **chưa chắc** người dương tính có khả năng cao mắc bệnh — nhất là với bệnh hiếm.

Chương VI chỉ có hai bài nhưng là phần **dễ lấy điểm trọn** nếu em đọc đề cẩn thận: đề tốt nghiệp thường có một câu Đúng/Sai 4 ý về bảng số liệu hoặc sơ đồ cây, và một câu trả lời ngắn kiểu xét nghiệm, sản phẩm lỗi, chọn hộp rồi lấy bi. Đặc biệt với học sinh khối B, đây là chương "nói chuyện" trực tiếp với y học và di truyền học. Bài ôn tập này **không giảng lại** — em đã có Bài 18 và Bài 19. Ở đây ta làm ba việc: (1) xếp cả chương lên **một bản đồ**; (2) tách bạch những thứ **dễ nhầm**; (3) luyện **bài tổng hợp** phối hợp cả hai bài như trong đề thật.

## 1. Bản đồ của chương

### 1.1. Một khái niệm, ba công thức

Điều quan trọng nhất cần thấy: cả chương chỉ xoay quanh **một** khái niệm là xác suất có điều kiện. Ba công thức còn lại đều là định nghĩa ấy được viết lại theo một cách khác, phù hợp với dữ kiện đề cho.

| Công thức | Viết ra | Dùng khi đề cho sẵn… | Bài |
|---|---|---|---|
| Định nghĩa | $P(A\mid B)=\dfrac{P(AB)}{P(B)}$ | $P(AB)$ và $P(B)$, hoặc đếm được | Bài 18 mục 1 |
| Công thức nhân | $P(AB)=P(A)\cdot P(B\mid A)$ | xác suất "bước đầu" và xác suất "bước sau khi biết bước đầu" | Bài 18 mục 2 |
| Xác suất toàn phần | $P(B)=P(A)\cdot P(B\mid A)+P(\overline{A})\cdot P(B\mid\overline{A})$ | xác suất của từng nguyên nhân và của kết quả trong từng nguyên nhân | Bài 19 mục 1 |
| Bayes | $P(A\mid B)=\dfrac{P(A)\cdot P(B\mid A)}{P(B)}$ | như trên, nhưng hỏi **ngược** về nguyên nhân | Bài 19 mục 2 |

![Hình 1. Bản đồ chương VI. Nhân hai vế định nghĩa với P(B) được công thức nhân. Cộng hai trường hợp A và Ā được xác suất toàn phần. Đem nó làm mẫu số của định nghĩa là được công thức Bayes. Bên dưới là ba cách tổ chức dữ liệu dùng chung](h1-ban-do-chuong.svg)

**Vì sao nên nhìn chương theo cách này?** Vì khi quên công thức, em vẫn tự dựng lại được trong vài giây. Ví dụ, công thức Bayes trông dài, nhưng thực chất là định nghĩa $P(A\mid B)=\dfrac{P(AB)}{P(B)}$, trong đó tử $P(AB)$ tính bằng công thức nhân và mẫu $P(B)$ tính bằng xác suất toàn phần. Không có gì mới cả.

### 1.2. Gặp câu hỏi nào — dùng công cụ nào

| Đề hỏi | Công cụ | Xem lại |
|---|---|---|
| "biết lần đầu lấy được…, xác suất lần sau…" | không gian thu gọn: đếm lại những gì còn trong hộp | Bài 18 mục 1.1, Ví dụ 1 |
| bảng số liệu, "chọn ngẫu nhiên một người… biết người đó…" | thêm tổng, chia cho tổng hàng/cột điều kiện | Bài 18 mục 1.4, Dạng 1 |
| "lấy lần lượt, không hoàn lại", "cả hai", "lần thứ ba mới…" | công thức nhân (dây chuyền) | Bài 18 mục 2.1, Dạng 2 |
| cho vài số $P(A)$, $P(B)$, $P(AB)$, $P(A\mid B)$… hỏi số khác | đi qua $P(AB)$ | Bài 18 Dạng 3 |
| "có độc lập không?" | so $P(A\mid B)$ với $P(A)$ (hoặc $P(AB)$ với $P(A)P(B)$) | Bài 18 mục 1.3 |
| "nếu… thì xác suất… là…, tính xác suất của kết quả" | xác suất toàn phần, cây hai tầng | Bài 19 mục 1 |
| ba máy, ba nhà cung cấp, ba cách đi học… | cây ba nhánh, cộng ba tích (mở rộng, ngoài SGK) | Bài 19 mục 1.4, Dạng 2 |
| "biết kết quả là…, tính xác suất nó do… / thuộc…" | Bayes: một lá chia tổng các lá | Bài 19 mục 2, Dạng 1–3 |
| hai hộp, chọn hộp bằng xúc xắc/đồng xu, chuyển bi | trường hợp là **hộp được chọn** hoặc **bi được chuyển** | Bài 19 Dạng 3 |
| "tìm $n$", "tìm tỉ lệ ban đầu", "độ đặc hiệu phải bao nhiêu" | đặt ẩn, viết công thức nhân / toàn phần / Bayes theo ẩn | Bài 18 Dạng 4, Bài 19 Dạng 4 |

> [!meo] Ba câu tự hỏi trước khi đặt bút
> 1. **Điều gì đã biết?** Gạch chân cụm "biết rằng / nếu / trong số". Đó là biến cố đứng sau dấu "$\mid$". Không có cụm này thì đề đang hỏi xác suất "thường", có thể là $P(AB)$ hoặc $P(B)$.
> 2. **Đề cho dữ liệu ở dạng nào?** Số đếm (bảng, hộp bi) thì đếm trên không gian thu gọn. Tỉ lệ "nếu… thì…" thì vẽ cây.
> 3. **Đề hỏi xuôi hay hỏi ngược?** Hỏi xác suất của **kết quả** thì cộng các nhánh. Hỏi **nguyên nhân** khi đã thấy kết quả thì lấy một nhánh chia tổng.

## 2. Bảng so sánh – phân biệt

### 2.1. Ba con số $P(AB)$, $P(A\mid B)$, $P(B\mid A)$

Ba con số này có **cùng phần chung** $AB$ nhưng **khác "cái nền"** để so sánh. Đó là gốc rễ của hầu hết các bẫy trong chương.

| | $P(AB)$ | $P(A\mid B)$ | $P(B\mid A)$ |
|---|---|---|---|
| Đọc thành lời | $A$ **và** $B$ cùng xảy ra | $A$, **biết** $B$ đã xảy ra | $B$, **biết** $A$ đã xảy ra |
| "Cái nền" (chia cho) | toàn bộ, $n(\Omega)$ | chỉ những trường hợp $B$ | chỉ những trường hợp $A$ |
| Trên bảng $2\times2$ | ô giao : tổng chung | ô giao : tổng hàng/cột $B$ | ô giao : tổng hàng/cột $A$ |
| Trên sơ đồ cây (gốc tách theo $A$) | một **lá** | lá ① chia tổng các lá $B$ (Bayes) | một **nhánh cấp 2** |
| Cụm từ hay gặp | "vừa… vừa…", "và", "đồng thời" | "biết rằng… $B$", "trong số những người $B$" | "nếu $A$ thì…", "trong số những người $A$" |

![Hình 2. Một cây, bốn lá. Nhánh cấp 1 ghi P(A), P(Ā). Nhánh cấp 2 ghi xác suất có điều kiện. Mỗi lá là xác suất của một biến cố giao. Xác suất toàn phần là tổng hai lá cam, còn Bayes là lá ① chia tổng hai lá cam](h2-cay-bon-la.svg)

Hình 2 là "bản đồ thu nhỏ" của cả chương: **nhánh** là xác suất có điều kiện, **lá** là xác suất giao (công thức nhân), **tổng các lá cùng loại** là xác suất toàn phần, **một lá chia tổng** là Bayes. Đề Đúng/Sai rất hay đặt một con số của nhánh vào chỗ của lá (hoặc ngược lại) — nếu em vẽ đủ bốn lá thì sẽ không bị lừa.

### 2.2. Độc lập – xung khắc – lấy không hoàn lại

| | Độc lập | Xung khắc | Lấy lần lượt không hoàn lại |
|---|---|---|---|
| Nghĩa | biết $B$ **không làm thay đổi** khả năng $A$ | $A$, $B$ **không thể** cùng xảy ra | lần trước làm **thay đổi** hộp cho lần sau |
| Dấu hiệu bằng số | $P(A\mid B)=P(A)$, hay $P(AB)=P(A)P(B)$ | $P(AB)=0$, nên $P(A\mid B)=0$ | $P(B\mid A)\ne P(B\mid\overline{A})$ |
| Công thức nhân trở thành | $P(AB)=P(A)\cdot P(B)$ | $P(AB)=0$ | $P(AB)=P(A)\cdot P(B\mid A)$, giảm cả tử và mẫu |
| Ví dụ | gieo xúc xắc hai lần, lấy **có** hoàn lại | "lần 1 ra đỏ" và "lần 1 ra xanh" | "lần 1 ra đỏ" và "lần 2 ra đỏ" |

> [!bay] Ba điều hay bị đảo lộn
> - "Độc lập" là chuyện **con số**, không phải "trông có vẻ không liên quan". Phải kiểm tra bằng $P(A\mid B)$ và $P(A)$ (Bài 18 Ví dụ 3).
> - Hai biến cố xung khắc (xác suất dương) **không bao giờ** độc lập: biết $B$ xảy ra là chắc chắn $A$ không xảy ra, tức $B$ ảnh hưởng tới $A$ rất mạnh.
> - Lấy không hoàn lại thì các lần lấy **không** độc lập, nhưng xác suất "lần thứ hai ra đỏ" (khi chưa biết lần một) **vẫn bằng** xác suất "lần một ra đỏ". Hai điều này không mâu thuẫn — xem Ví dụ 2.

### 2.3. Biến cố đối bên trong xác suất có điều kiện

| Viết | Có bằng $1-P(A\mid B)$ không? | Vì sao |
|---|---|---|
| $P(\overline{A}\mid B)$ | **Có** | cùng "nền" $B$: trong số những trường hợp $B$, $A$ hoặc xảy ra hoặc không |
| $P(A\mid\overline{B})$ | **Không** | đổi sang nền khác hẳn ($\overline{B}$). Phải tính $\dfrac{P(A\overline{B})}{P(\overline{B})}=\dfrac{P(A)-P(AB)}{1-P(B)}$ |
| $P(\overline{A}\mid\overline{B})$ | **Không** | nền $\overline{B}$, bằng $1-P(A\mid\overline{B})$ |

Trên sơ đồ cây, quy tắc rất dễ nhớ: **hai nhánh xuất phát từ cùng một nút có tổng bằng $1$**. Từ nút $A$ có $P(B\mid A)+P(\overline{B}\mid A)=1$. Nhưng $P(B\mid A)$ và $P(B\mid\overline{A})$ nằm ở **hai nút khác nhau**, tổng của chúng chẳng có ý nghĩa gì.

### 2.4. Xác suất toàn phần – Bayes, và các thuật ngữ xét nghiệm

| | Xác suất toàn phần | Công thức Bayes |
|---|---|---|
| Hướng câu hỏi | xuôi: nguyên nhân → **kết quả** | ngược: đã thấy kết quả → **nguyên nhân** |
| Dấu hiệu trong đề | "tính xác suất (để) sản phẩm bị lỗi / người đó dương tính / lấy được bi đỏ" | "**biết** sản phẩm bị lỗi / người đó dương tính…, tính xác suất nó **do** máy I / người đó **mắc bệnh**" |
| Trên cây | **cộng** các lá dẫn tới $B$ | **một** lá chia tổng các lá dẫn tới $B$ |
| Kiểm tra nhanh | $P(B)$ nằm **giữa** $P(B\mid A)$ và $P(B\mid\overline{A})$ | nếu $P(B\mid A)>P(B\mid\overline{A})$ thì $P(A\mid B)>P(A)$ (thông tin "ủng hộ" $A$) |

| Thuật ngữ | Kí hiệu ($A$: mắc bệnh, $B$: dương tính) | Ghi nhớ |
|---|---|---|
| Tỉ lệ mắc bệnh (tiên nghiệm) | $P(A)$ | trước khi xét nghiệm |
| Độ nhạy | $P(B\mid A)$ | người **bệnh** được báo dương tính |
| Độ đặc hiệu | $P(\overline{B}\mid\overline{A})$ | người **không bệnh** được báo âm tính |
| Dương tính giả | $P(B\mid\overline{A})=1-$ độ đặc hiệu | người không bệnh bị báo nhầm |
| Điều bệnh nhân cần biết (hậu nghiệm) | $P(A\mid B)$ | tính bằng Bayes, có thể **rất nhỏ** dù độ nhạy cao |

### 2.5. Ba cách tổ chức cùng một dữ liệu

Cùng một tình huống có thể viết thành bảng, thành cây, hoặc thành "số người". Biết đổi qua lại giúp em chọn cách nhanh nhất và **tự kiểm tra** đáp số.

- **Từ tỉ lệ "nếu… thì…" sang bảng:** chọn một tổng thể dễ chia (như $1\,000$ hay $10\,000$ người), nhân dần theo cây để ra số người ở từng ô (Bài 19 Hình 3). Khi đó Bayes chỉ còn là "ô cần tìm chia tổng cột".
- **Từ bảng sang cây:** tổng hàng chia tổng chung là nhánh cấp 1, ô chia tổng hàng là nhánh cấp 2.
- **Từ thông tin "có bao nhiêu người thích…, bao nhiêu người không thích cả hai" sang bảng:** dùng công thức cộng (lớp 10–11) để tìm ô "cả hai" trước, rồi điền các ô còn lại (Ví dụ 3).

> [!nen-tang] Công thức cộng (lớp 10–11)
> $n(A\cup B)=n(A)+n(B)-n(AB)$. Số phần tử "thuộc ít nhất một" bằng tổng thể trừ số "không thuộc cái nào". Vì vậy $n(AB)=n(A)+n(B)-\big(n(\Omega)-n(\overline{A}\,\overline{B})\big)$.

## 3. Lỗi sai hay gặp của cả chương

> [!bay] Bài 18 — xác suất có điều kiện, công thức nhân
> - **1.** Chia nhầm "cái nền": tính $P(A\mid B)$ mà chia cho tổng chung (ra $P(AB)$), hoặc chia cho tổng của $A$ (ra $P(B\mid A)$).
> - **2.** Đảo điều kiện: đề hỏi "trong số người khỏi bệnh, tỉ lệ dùng thuốc Y" mà tính "trong số người dùng thuốc Y, tỉ lệ khỏi bệnh".
> - **3.** Dùng $P(AB)=P(A)\cdot P(B)$ khi đề **không** nói độc lập. Công thức đúng cho mọi trường hợp là $P(AB)=P(A)\cdot P(B\mid A)$.
> - **4.** Lấy không hoàn lại mà **quên giảm mẫu số** (hoặc quên giảm tử số khi lấy cùng loại).
> - **5.** "Hai viên khác màu" mà chỉ tính một thứ tự (đỏ rồi xanh), quên thứ tự ngược lại.
> - **6.** Viết $P(A\mid\overline{B})=1-P(A\mid B)$. Đúng phải là $P(\overline{A}\mid B)=1-P(A\mid B)$.
> - **7.** Coi hai biến cố xung khắc là độc lập, hoặc kết luận độc lập chỉ vì "nghe có vẻ không liên quan".

> [!bay] Bài 19 — xác suất toàn phần, Bayes
> - **8.** Cộng thẳng $P(B\mid A)+P(B\mid\overline{A})$ hoặc lấy trung bình cộng của chúng, quên nhân trọng số $P(A)$, $P(\overline{A})$.
> - **9.** Ghi nhầm $P(\overline{A}B)$ (một lá) bằng $P(B\mid\overline{A})$ (một nhánh). Nói chung hai số này khác nhau, vì lá bằng nhánh nhân thêm $P(\overline{A})$.
> - **10.** Chọn ngẫu nhiên **một hộp** rồi lấy bi mà lại **gộp bi hai hộp** để tính. Chỉ được gộp khi chọn ngẫu nhiên **một viên** trong tất cả các viên.
> - **11.** Đề cho kết quả **âm tính** (hay "không lỗi") nhưng vẫn dùng các nhánh dương tính ("lỗi").
> - **12.** Nghĩ sản phẩm lỗi "chắc là" của máy có **tỉ lệ lỗi** cao nhất. Phải so **tích** (tỉ lệ đóng góp × tỉ lệ lỗi).
> - **13.** Đồng nhất độ nhạy với $P(\text{mắc bệnh}\mid\text{dương tính})$.

> [!bay] Tính toán và làm tròn
> - **14.** Làm tròn sớm ở bước giữa (ví dụ $P(B)\approx0{,}06$ rồi mới chia) làm lệch đáp số trả lời ngắn. Giữ phân số hoặc lưu vào bộ nhớ máy tính, chỉ làm tròn ở bước cuối.
> - **15.** Đề hỏi "bao nhiêu phần trăm" mà ghi $0{,}134$ thay vì $13{,}4$, hoặc ngược lại.
> - **16.** Quên kiểm tra: tổng các lá phải bằng $1$, xác suất không vượt quá $1$, xác suất toàn phần phải nằm giữa hai xác suất có điều kiện.

## 4. Bài tổng hợp

Năm bài dưới đây đều **phối hợp cả hai bài** của chương và bám ba dạng đề tốt nghiệp. Mỗi bài ứng với một nhóm câu trong "Bài tập cuối chương VI" của SGK. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Đúng/Sai: từ ba con số đến bốn lá

> [!vi-du] Ví dụ 1 (Bài 18 + 19 — liên hệ SGK Bài tập 6.12–6.14)
> Cho hai biến cố $A$, $B$ với $P(A)=\dfrac38$, $P(B\mid A)=\dfrac23$, $P(B\mid\overline{A})=\dfrac25$. Xét các mệnh đề:
>
> a) $P(AB)=\dfrac14$.
>
> b) $P(\overline{A}B)=\dfrac25$.
>
> c) $P(B)=\dfrac12$.
>
> d) $P(A\mid\overline{B})=1-P(A\mid B)$.

> [!goi-y] Gợi ý 1
> Vẽ cây như Hình 2: nhánh cấp 1 là $\frac38$ và $\frac58$, nhánh cấp 2 từ $A$ là $\frac23$, $\frac13$, từ $\overline{A}$ là $\frac25$, $\frac35$.

> [!goi-y] Gợi ý 2
> Tính đủ bốn lá bằng cách nhân dọc nhánh. Ý b hỏi một **lá**, còn $\frac25$ là một **nhánh**.

> [!goi-y] Gợi ý 3
> Ý d: tính riêng $P(A\mid B)$ (lá ① chia tổng hai lá $B$) và $P(A\mid\overline{B})$ (lá ② chia tổng hai lá $\overline{B}$) rồi so sánh.

> [!loi-giai] Lời giải
> Bốn lá:
> - $P(AB)=\frac38\cdot\frac23=\frac14$
> - $P(A\overline{B})=\frac38\cdot\frac13=\frac18$
> - $P(\overline{A}B)=\frac58\cdot\frac25=\frac14$
> - $P(\overline{A}\,\overline{B})=\frac58\cdot\frac35=\frac38$
>
> Kiểm tra: $\frac14+\frac18+\frac14+\frac38=1$ ✓.
>
> a) **Đúng.** $P(AB)=\dfrac14$ (công thức nhân).
>
> b) **Sai.** $P(\overline{A}B)=\dfrac14$. Con số $\dfrac25$ là $P(B\mid\overline{A})$, tức một nhánh, chưa nhân với $P(\overline{A})=\dfrac58$.
>
> c) **Đúng.** $P(B)=\dfrac14+\dfrac14=\dfrac12$ (xác suất toàn phần). Kiểm tra: $\frac12$ nằm giữa $\frac25$ và $\frac23$ ✓.
>
> d) **Sai.** $P(A\mid B)=\dfrac{1/4}{1/2}=\dfrac12$ nên $1-P(A\mid B)=\dfrac12$. Còn $P(\overline{B})=\dfrac12$ và $P(A\mid\overline{B})=\dfrac{1/8}{1/2}=\dfrac14$. Hai số khác nhau vì "nền" khác nhau (lỗi số 6).

> [!meo]
> Ý c còn cho thêm thông tin: $P(A\mid B)=\dfrac12>\dfrac38=P(A)$. Vậy biết $B$ xảy ra làm khả năng $A$ **tăng lên**, nên $A$, $B$ không độc lập. Điều này khớp với dấu hiệu $P(B\mid A)=\frac23>\frac25=P(B\mid\overline{A})$ (mục 2.4).

### 4.2. Lấy lần lượt: xuôi bằng công thức nhân, ngược bằng Bayes

> [!vi-du] Ví dụ 2 (Bài 18 + 19 — liên hệ SGK Bài tập 6.15–6.17)
> Chị Hà có một túi gồm $6$ viên kẹo gừng và $3$ viên kẹo bạc hà, các viên kẹo giống hệt nhau về hình dạng. Chị lấy ngẫu nhiên một viên đưa cho bé Na, rồi lấy ngẫu nhiên tiếp một viên nữa trong túi cũng đưa cho bé Na.
>
> a) Tính xác suất bé Na nhận được hai viên kẹo gừng.
>
> b) Tính xác suất bé Na nhận được hai viên khác vị.
>
> c) Tính xác suất viên kẹo thứ hai là kẹo bạc hà.
>
> d) Biết viên thứ hai là kẹo bạc hà, tính xác suất viên thứ nhất là kẹo gừng.

> [!goi-y] Gợi ý 1
> Gọi $G_1$: "viên thứ nhất là kẹo gừng", $H_2$: "viên thứ hai là kẹo bạc hà". Câu a dùng công thức nhân: lấy xong viên gừng đầu thì túi còn $8$ viên, trong đó $5$ viên gừng.

> [!goi-y] Gợi ý 2
> Câu b có **hai thứ tự**: gừng rồi bạc hà, bạc hà rồi gừng. Câu c chia hai trường hợp theo viên thứ nhất (xác suất toàn phần).

> [!goi-y] Gợi ý 3
> Câu d hỏi **ngược** (biết lần sau, hỏi lần trước) nên dùng Bayes: $P(G_1\mid H_2)=\dfrac{P(G_1H_2)}{P(H_2)}$.

> [!loi-giai] Lời giải
> a) $P=\dfrac69\cdot\dfrac58=\dfrac{5}{12}$.
>
> b) Gừng rồi bạc hà: $\dfrac69\cdot\dfrac38=\dfrac14$. Bạc hà rồi gừng: $\dfrac39\cdot\dfrac68=\dfrac14$. Vậy $P=\dfrac14+\dfrac14=\dfrac12$.
>
> c) Theo xác suất toàn phần, chia theo viên thứ nhất:
> $$\begin{aligned}P(H_2)&=P(G_1)\cdot P(H_2\mid G_1)\\&\quad+P(\overline{G_1})\cdot P(H_2\mid\overline{G_1})\\&=\dfrac69\cdot\dfrac38+\dfrac39\cdot\dfrac28\\&=\dfrac14+\dfrac1{12}=\dfrac13.\end{aligned}$$
> d) $P(G_1\mid H_2)=\dfrac{P(G_1H_2)}{P(H_2)}=\dfrac{1/4}{1/3}=\dfrac34$.
>
> Kiểm tra câu d bằng không gian thu gọn: biết viên thứ hai là một trong $3$ viên bạc hà, viên thứ nhất là một trong $8$ viên còn lại, trong đó có $6$ viên gừng, nên xác suất là $\dfrac68=\dfrac34$ ✓.

> [!em-co-biet] Vì sao câu c lại ra đúng tỉ lệ ban đầu?
> $P(H_2)=\dfrac13$ bằng đúng tỉ lệ kẹo bạc hà trong túi lúc đầu. Đây không phải trùng hợp: khi **chưa biết** viên thứ nhất là gì, mọi viên kẹo đều có khả năng như nhau để nằm ở vị trí thứ hai. Cũng vì thế, khi bốc thăm lần lượt không hoàn lại, người bốc trước hay sau đều có cơ hội như nhau (em đã gặp ở phần luyện tập Bài 18). Nhưng **một khi đã biết** viên thứ nhất, xác suất của viên thứ hai thay đổi ngay ($\frac38$ hoặc $\frac28$).

### 4.3. Từ biểu đồ Ven sang bảng $2\times2$

> [!vi-du] Ví dụ 3 (Bài 18 — liên hệ SGK Bài tập 6.18, 6.19)
> Lớp 12B có $40$ học sinh, trong đó $22$ em thích môn Hóa học, $25$ em thích môn Sinh học và $3$ em không thích môn nào trong hai môn này. Chọn ngẫu nhiên một học sinh của lớp. Tính xác suất để học sinh đó:
>
> a) Thích cả hai môn.
>
> b) Thích Hóa học nhưng không thích Sinh học.
>
> c) Thích Hóa học, biết rằng học sinh đó thích Sinh học.
>
> d) Hai biến cố "thích Hóa học" và "thích Sinh học" có độc lập không?

> [!goi-y] Gợi ý 1
> Số học sinh thích ít nhất một môn là $40-3=37$. Dùng công thức cộng để tìm số em thích cả hai.

> [!goi-y] Gợi ý 2
> Lập bảng $2\times2$ có dòng, cột tổng (Hình 3). Câu c: điều kiện là cột "thích Sinh", chia cho tổng cột đó.

> [!goi-y] Gợi ý 3
> Câu d: so $P(\text{Hóa}\mid\text{Sinh})$ với $P(\text{Hóa})$.

> [!loi-giai] Lời giải
> Gọi $H$: "thích Hóa học", $S$: "thích Sinh học". Số em thích cả hai: $n(HS)=22+25-37=10$. Từ đó thích Hóa mà không thích Sinh: $22-10=12$ em, thích Sinh mà không thích Hóa: $25-10=15$ em.
>
> a) $P(HS)=\dfrac{10}{40}=\dfrac14$.
>
> b) $P(H\overline{S})=\dfrac{12}{40}=\dfrac{3}{10}$.
>
> c) $P(H\mid S)=\dfrac{n(HS)}{n(S)}=\dfrac{10}{25}=\dfrac25$.
>
> d) $P(H)=\dfrac{22}{40}=\dfrac{11}{20}\ne\dfrac25=P(H\mid S)$, nên $H$ và $S$ **không độc lập**. Trong lớp này, biết một bạn thích Sinh thì khả năng bạn ấy thích Hóa **giảm** từ $55\%$ xuống $40\%$.

![Hình 3. Ví dụ 3: điền ô "cả hai" trước bằng công thức cộng, rồi chuyển biểu đồ Ven thành bảng 2 × 2 có dòng, cột tổng](h3-venn-bang.svg)

> [!bay]
> Câu a và câu c chỉ khác vài chữ ("thích cả hai" với "thích Hóa, biết thích Sinh") nhưng mẫu số khác hẳn: $40$ và $25$. Câu b là $P(H\overline{S})$ chia cho $40$, **không phải** $P(H\mid\overline{S})=\dfrac{12}{15}$.

### 4.4. Chọn hộp bằng đồng xu: xác suất toàn phần và Bayes

> [!vi-du] Ví dụ 4 (Bài 19 — liên hệ SGK Bài tập 6.20)
> Hộp I có $3$ bút bi xanh và $1$ bút bi đỏ. Hộp II có $2$ bút bi xanh và $4$ bút bi đỏ. Một bạn tung đồng thời hai đồng xu cân đối: nếu cả hai đồng xu đều ra mặt sấp thì chọn hộp I, còn lại thì chọn hộp II. Sau đó bạn lấy ngẫu nhiên một chiếc bút từ hộp đã chọn.
>
> a) Tính xác suất lấy được bút xanh.
>
> b) Biết bạn lấy được bút xanh, tính xác suất chiếc bút đó lấy từ hộp I.

> [!goi-y] Gợi ý 1
> Tung hai đồng xu có $4$ kết quả đồng khả năng, chỉ $1$ kết quả là "sấp, sấp". Vậy $P(\text{hộp I})=\dfrac14$, **không phải** $\dfrac12$.

> [!goi-y] Gợi ý 2
> Trường hợp là **hộp được chọn**. Trong mỗi hộp tính xác suất lấy được bút xanh, rồi dùng xác suất toàn phần. Câu b hỏi ngược nên dùng Bayes.

> [!loi-giai] Lời giải
> Gọi $A$: "chọn hộp I", $X$: "lấy được bút xanh". Ta có $P(A)=\dfrac14$, $P(\overline{A})=\dfrac34$, $P(X\mid A)=\dfrac34$, $P(X\mid\overline{A})=\dfrac26=\dfrac13$.
>
> a) $P(X)=\dfrac14\cdot\dfrac34+\dfrac34\cdot\dfrac13=\dfrac{3}{16}+\dfrac14=\dfrac{7}{16}$.
>
> b) $P(A\mid X)=\dfrac{3/16}{7/16}=\dfrac37$.
>
> Nhận xét: hộp I "xanh hơn" hẳn hộp II, nên biết lấy được bút xanh thì khả năng đã chọn hộp I tăng từ $\frac14$ lên $\frac37$.

> [!bay] Hai cách tính sai hay gặp
> - **Gộp hai hộp:** $\dfrac{3+2}{4+6}=\dfrac12$. Sai vì bút trong hai hộp không đồng khả năng: mỗi bút hộp I được lấy với xác suất $\frac14\cdot\frac14=\frac1{16}$, còn mỗi bút hộp II chỉ $\frac34\cdot\frac16=\frac18$ (lỗi số 10).
> - **Coi mỗi hộp $\frac12$:** $\dfrac12\left(\dfrac34+\dfrac13\right)=\dfrac{13}{24}$. Sai vì bỏ qua cách chọn hộp bằng đồng xu.

### 4.5. Trả lời ngắn: cập nhật xác suất trong di truyền (mở rộng, liên môn — vận dụng cao)

Bài cuối dành cho em nhắm điểm 9+: một bài toán **mở rộng, liên môn Sinh học 12** (không có trong SGK Toán) mà bước then chốt là cập nhật xác suất bằng Bayes. Đây là dạng phả hệ hay gặp trong đề Sinh, nay em giải bằng công cụ của chương VI.

> [!nen-tang] Sinh học cần nhớ
> - Bệnh bạch tạng ở người do allele lặn $a$ trên nhiễm sắc thể thường quy định: kiểu gene $aa$ bị bệnh, $AA$ và $Aa$ bình thường.
> - Bố mẹ đều $Aa$ thì con có kiểu gene $AA$, $Aa$, $aa$ với xác suất $\frac14$, $\frac12$, $\frac14$.
> - Bố $Aa$, mẹ $Aa$ sinh con bị bệnh với xác suất $\frac14$. Bố $AA$ thì con không bị bệnh.
> - Khi đã biết kiểu gene của bố mẹ, kiểu gene của các lần sinh khác nhau là độc lập.

> [!vi-du] Ví dụ 5 (mở rộng, liên môn Sinh học — Bài 18 + 19, cùng dạng Bayes với SGK Bài tập 6.21)
> Anh Minh không bị bệnh bạch tạng, bố mẹ anh đều không bị bệnh nhưng em gái anh bị bệnh. Vợ anh, chị Lan, không bị bệnh nhưng có bố bị bệnh. Ngoài ra không có ai khác trong hai gia đình bị bệnh.
>
> a) Tính xác suất con đầu lòng của anh chị bị bệnh bạch tạng.
>
> b) Biết con đầu lòng của anh chị không bị bệnh. Tính xác suất anh Minh có kiểu gene $Aa$.
>
> c) Biết con đầu lòng không bị bệnh, tính xác suất con thứ hai bị bệnh (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Em gái bị bệnh nên bố mẹ anh Minh đều $Aa$. Anh Minh bình thường nên chỉ có thể là $AA$ hoặc $Aa$ — đây là xác suất có điều kiện: $P(Aa\mid\text{bình thường})=\dfrac{1/2}{3/4}$. Chị Lan có bố $aa$ nên chắc chắn nhận $a$ từ bố, mà chị bình thường, vậy chị là $Aa$.

> [!goi-y] Gợi ý 2
> Câu a: chia hai trường hợp theo kiểu gene anh Minh ($Aa$ hay $AA$) — xác suất toàn phần.

> [!goi-y] Gợi ý 3
> Câu b: thông tin "con đầu bình thường" là kết quả, hỏi ngược về kiểu gene anh Minh → Bayes. Câu c: dùng xác suất vừa cập nhật ở câu b làm trọng số mới.

> [!loi-giai] Lời giải
> Gọi $M$: "anh Minh có kiểu gene $Aa$". Do bố mẹ anh đều $Aa$ và anh bình thường: $P(M)=\dfrac{1/2}{1/4+1/2}=\dfrac23$, $P(\overline{M})=\dfrac13$ (anh là $AA$). Chị Lan là $Aa$.
>
> a) Nếu $M$ xảy ra (bố $Aa$, mẹ $Aa$): con bị bệnh với xác suất $\frac14$. Nếu $\overline{M}$ (bố $AA$): con không thể bị bệnh. Theo xác suất toàn phần:
> $$P(\text{con đầu bệnh})=\dfrac23\cdot\dfrac14+\dfrac13\cdot0=\dfrac16.$$
> b) Gọi $T$: "con đầu bình thường". $P(T\mid M)=\dfrac34$, $P(T\mid\overline{M})=1$, nên $P(T)=\dfrac23\cdot\dfrac34+\dfrac13\cdot1=\dfrac12+\dfrac13=\dfrac56$. Theo Bayes:
> $$P(M\mid T)=\dfrac{\frac23\cdot\frac34}{\frac56}=\dfrac{1/2}{5/6}=\dfrac35.$$
> c) Khi đã biết con đầu bình thường, anh Minh là $Aa$ với xác suất $\frac35$. Con thứ hai bị bệnh chỉ khi anh là $Aa$ và lần sinh này ra $aa$:
> $$P=\dfrac35\cdot\dfrac14=\dfrac{3}{20}=0{,}15.$$
> Đáp số: $0{,}15$.

> [!bay]
> Nhiều bạn trả lời câu c là $\dfrac16\approx0{,}17$, tức coi như chưa biết gì về con đầu. Thông tin "con đầu bình thường" làm khả năng anh Minh mang allele $a$ **giảm** từ $\frac23$ xuống $\frac35$, nên nguy cơ cho con thứ hai cũng giảm. Đây chính là tinh thần "cập nhật xác suất khi có thông tin mới" của Bayes.

> [!ung-dung] Tư vấn di truyền
> Các bác sĩ tư vấn di truyền làm đúng phép tính như Ví dụ 5 khi một gia đình có người bệnh muốn biết nguy cơ cho con. Mỗi thông tin mới (kết quả xét nghiệm người mang gene, số con đã sinh bình thường…) lại được đưa vào để cập nhật con số nguy cơ.

## 5. Đối chiếu "Bài tập cuối chương VI" (SGK tr. 79–80)

Bảng dưới cho biết mỗi bài tập của SGK kiểm tra điều gì, nên xem lại ở đâu, kèm một **bài tự luyện cùng dạng** (số liệu khác). Làm xong, mở đáp số bên dưới để tự chấm.

| SGK | Kiểm tra (xem lại) | Bài tự luyện cùng dạng |
|---|---|---|
| 6.12–6.14 | Từ $P(A)$, $P(B\mid A)$, $P(B\mid\overline{A})$ tính $P(AB)$, $P(B\overline{A})$, $P(B)$ — *Ví dụ 1, Hình 2* | (T1) Cho $P(A)=\frac13$, $P(B\mid A)=\frac34$, $P(B\mid\overline{A})=\frac12$. Tính $P(AB)$, $P(B\overline{A})$, $P(B)$ và $P(A\mid B)$. |
| 6.15–6.17 | Lấy lần lượt không hoàn lại, công thức nhân — *Ví dụ 2; Bài 18 mục 2.1* | (T2) Túi có $8$ kẹo dâu và $4$ kẹo cam, lấy lần lượt $2$ viên không trả lại. Tính xác suất được hai viên dâu, hai viên cam, viên dâu trước rồi viên cam. |
| 6.18 | Bảng $2\times2$ thử nghiệm, $P(A\mid B)$ và $P(B\mid A)$ — *Bài 18 mục 1.4; mục 2.1* | (T3) Thử nghiệm hai loại phân bón trên $1\,000$ cây: phân P có $420$ cây đạt năng suất cao, $180$ cây không đạt; phân Q có $300$ cây đạt, $100$ cây không đạt. Chọn ngẫu nhiên một cây. Tính xác suất cây đạt năng suất cao, biết cây dùng phân P. Tính xác suất cây dùng phân Q, biết cây đạt năng suất cao. |
| 6.19 | Biểu đồ Ven → bảng, xác suất giao và có điều kiện — *Ví dụ 3* | (T4) Nhóm $36$ học sinh: $20$ em chơi bóng đá, $18$ em chơi cầu lông, $4$ em không chơi môn nào. Chọn ngẫu nhiên một em. Tính xác suất em đó chơi cả hai môn, chơi bóng đá nhưng không chơi cầu lông, chơi bóng đá biết em đó chơi cầu lông. |
| 6.20 | Chọn chuồng/hộp bằng xúc xắc, xác suất toàn phần — *Ví dụ 4* | (T5) Giỏ I có $4$ quả cam, $2$ quả quýt. Giỏ II có $3$ quả cam, $5$ quả quýt. Gieo một con xúc xắc, ra số chấm là số nguyên tố thì chọn giỏ I, ngược lại chọn giỏ II, rồi lấy ngẫu nhiên một quả. Tính xác suất lấy được quả cam. Biết lấy được quả cam, tính xác suất nó từ giỏ I. |
| 6.21 | Bayes trong y tế — *Bài 19 mục 2; Ví dụ 5* | (T6) Ở một địa phương, $15\%$ người có bệnh nền. Sau tiêm một loại vaccine, người có bệnh nền có phản ứng phụ với xác suất $0{,}4$, người không có bệnh nền với xác suất $0{,}1$. Chọn ngẫu nhiên một người đã tiêm và thấy người này có phản ứng phụ. Tính xác suất người này có bệnh nền (làm tròn đến hàng phần nghìn). |

> [!loi-giai] Đáp số bài tự luyện
> - **T1.** $P(AB)=\frac13\cdot\frac34=\frac14$. $P(B\overline{A})=\frac23\cdot\frac12=\frac13$. $P(B)=\frac14+\frac13=\frac{7}{12}$. $P(A\mid B)=\frac{1/4}{7/12}=\frac37$.
> - **T2.** Hai dâu: $\frac{8}{12}\cdot\frac{7}{11}=\frac{14}{33}$. Hai cam: $\frac{4}{12}\cdot\frac{3}{11}=\frac{1}{11}$. Dâu rồi cam: $\frac{8}{12}\cdot\frac{4}{11}=\frac{8}{33}$.
> - **T3.** Phân P có $600$ cây, nên xác suất đạt năng suất cao là $\frac{420}{600}=0{,}7$. Có $420+300=720$ cây đạt năng suất cao, nên xác suất dùng phân Q là $\frac{300}{720}=\frac{5}{12}$.
> - **T4.** Cả hai: $20+18-32=6$ em, xác suất $\frac{6}{36}=\frac16$. Bóng đá không cầu lông: $14$ em, xác suất $\frac{14}{36}=\frac{7}{18}$. Bóng đá biết cầu lông: $\frac{6}{18}=\frac13$.
> - **T5.** Số nguyên tố là $2$, $3$, $5$ nên mỗi giỏ được chọn với xác suất $\frac12$. $P(\text{cam})=\frac12\cdot\frac46+\frac12\cdot\frac38=\frac13+\frac{3}{16}=\frac{25}{48}$. $P(\text{giỏ I}\mid\text{cam})=\frac{1/3}{25/48}=\frac{16}{25}$.
> - **T6.** $P(\text{phản ứng})=0{,}15\cdot0{,}4+0{,}85\cdot0{,}1=0{,}06+0{,}085=0{,}145$. $P(\text{bệnh nền}\mid\text{phản ứng})=\frac{0{,}06}{0{,}145}=\frac{12}{29}\approx0{,}414$.

## Tóm tắt — danh sách kiểm tra trước giờ thi

| Khi gặp | Nhớ ngay |
|---|---|
| Cụm "biết rằng / nếu / trong số" | đó là điều kiện, đứng **sau** dấu "$\mid$" |
| Định nghĩa | $P(A\mid B)=\dfrac{P(AB)}{P(B)}=\dfrac{n(AB)}{n(B)}$ |
| Lấy lần lượt không hoàn lại | công thức nhân, giảm tử và mẫu; "khác màu" thì cộng hai thứ tự |
| Bảng $2\times2$ | thêm tổng; có điều kiện thì chia tổng hàng/cột điều kiện, "và" thì chia tổng chung |
| Biết ít nhất một, không cái nào | công thức cộng, tìm ô "cả hai" trước |
| Biến cố đối | $P(\overline{A}\mid B)=1-P(A\mid B)$, nhưng $P(A\mid\overline{B})$ phải tính riêng |
| Độc lập | $P(A\mid B)=P(A)$. Xung khắc (xác suất dương) thì không độc lập |
| Sơ đồ cây | nhánh = có điều kiện, lá = giao; tổng các nhánh từ một nút bằng $1$, tổng các lá bằng $1$ |
| Hỏi kết quả | xác suất toàn phần: cộng các lá dẫn tới $B$ |
| Hỏi nguyên nhân khi biết kết quả | Bayes: một lá chia tổng các lá dẫn tới $B$ |
| Chọn hộp rồi lấy | trường hợp là hộp; **không** gộp bi; xác suất chọn hộp theo đúng cách chọn |
| Xét nghiệm | độ nhạy $P(B\mid A)$, dương tính giả $P(B\mid\overline{A})$; điều cần tìm là $P(A\mid B)$ |
| Làm tròn | giữ phân số đến bước cuối; "phần trăm" hay "xác suất" |

**Sơ đồ một dòng:** *đặt tên biến cố → tìm điều kiện → chọn cách tổ chức (không gian thu gọn, bảng, cây) → định nghĩa / công thức nhân / toàn phần / Bayes → kiểm tra tổng bằng $1$ và hướng thay đổi hợp lí.*
