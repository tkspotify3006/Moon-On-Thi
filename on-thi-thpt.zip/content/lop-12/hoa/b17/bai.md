---
title: Ôn tập chương 5
thoi-gian: 50 phút
muc-tieu:
  - Hệ thống hoá kiến thức chương Pin điện và điện phân: cặp oxi hoá – khử, thế điện cực chuẩn, pin Galvani, sức điện động chuẩn, một số nguồn điện, thứ tự điện phân và ứng dụng của điện phân.
  - Dùng thành thạo bảng thế điện cực chuẩn để so sánh tính khử, tính oxi hoá, dự đoán chiều phản ứng, chọn anode và cathode, tính sức điện động chuẩn và suy ngược E°.
  - Phân biệt chắc chắn pin điện hoá với bình điện phân (dấu điện cực, chiều chuyển hoá năng lượng, phản ứng tự xảy ra hay cưỡng bức) và các cặp khái niệm dễ nhầm khác của chương.
  - Giải được bài tập tổng hợp phối hợp hai bài: pin làm nguồn cho bình điện phân, điện phân hỗn hợp có Fe^3+^, điện phân nước kết hợp pin nhiên liệu.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. **Cặp oxi hoá – khử** M^n+^/M: dạng oxi hoá viết trước, dạng khử viết sau, M^n+^ + ne ⇌ M.
> 2. **E°** (25 °C, ion 1 M, quy ước E°(2H^+^/H~2~) = 0): E° **nhỏ** thì kim loại **khử mạnh**, E° **lớn** thì ion **oxi hoá mạnh**.
> 3. **Chiều phản ứng:** chất khử của cặp E° nhỏ + chất oxi hoá của cặp E° lớn (quy tắc α).
> 4. **Anode luôn là nơi oxi hoá, cathode luôn là nơi khử**, ở cả pin lẫn bình điện phân. Chỉ **dấu** của điện cực là đổi.
> 5. **Pin Galvani:** phản ứng **tự xảy ra**, hoá năng → điện năng. Anode là **cực âm** (cặp E° nhỏ), cathode là **cực dương** (cặp E° lớn).
> 6. **E°~pin~ = E°~cathode~ − E°~anode~ > 0**, không nhân E° với hệ số.
> 7. **Nguồn điện:** acquy chì, pin lithium-ion là pin sạc. Pin khô là pin sơ cấp. Pin nhiên liệu H~2~ – O~2~ chỉ thải nước. Pin Mặt Trời **không** dựa trên phản ứng oxi hoá – khử.
> 8. **Điện phân:** phản ứng **không tự xảy ra**, điện năng → hoá năng. Anode là **cực dương**, cathode là **cực âm**.
> 9. **Thứ tự điện phân:** ở cathode chất oxi hoá mạnh hơn bị khử trước, ở anode chất khử mạnh hơn bị oxi hoá trước. Anode kim loại (không trơ) thì chính nó tan ra.
> 10. **Ứng dụng:** sản xuất Al bằng điện phân Al~2~O~3~ nóng chảy, tinh luyện đồng với anode đồng thô, mạ điện với vật cần mạ làm cathode. Tính toán (mở rộng): $n_e = \dfrac{It}{F}$, F = 96 500 C/mol.

Bài này **không giảng lại từ đầu**. Em dùng nó để xâu chuỗi hai bài: Bài 15 (Thế điện cực và nguồn điện hoá học) và Bài 16 (Điện phân). Chỗ nào chưa vững, hãy quay lại đúng mục được dẫn.

## 1. Hệ thống hoá kiến thức

### 1.1. Bức tranh toàn chương

Cả chương xoay quanh **một** ý: electron chuyển từ chất khử sang chất oxi hoá. Chương hỏi ba câu nối tiếp nhau:

1. **Chất nào "muốn" nhường, chất nào "muốn" nhận electron, mạnh yếu ra sao?** Đo bằng thế điện cực chuẩn E° (Bài 15, mục 1–3).
2. **Nếu phản ứng tự xảy ra, làm sao lấy được dòng điện?** Tách hai nửa phản ứng ra hai điện cực: đó là **pin điện hoá** (Bài 15, mục 4–5).
3. **Nếu phản ứng không tự xảy ra, làm sao ép nó xảy ra?** Bơm điện năng vào: đó là **điện phân** (Bài 16).

![Hình 1. Hệ thống hoá chương 5: thế điện cực chuẩn là gốc, từ đó suy ra pin điện hoá và điện phân](he-thong.svg)

**Vì sao nói pin và điện phân là "hai chiều của cùng một phản ứng"?** Phản ứng Zn + Cu^2+^ → Zn^2+^ + Cu tự xảy ra, nên lắp thành pin thì cho ra 1,102 V. Muốn phản ứng ngược Cu + Zn^2+^ → Cu^2+^ + Zn xảy ra, em phải dùng một nguồn điện ngoài có hiệu điện thế **lớn hơn** 1,102 V đẩy electron theo chiều ngược lại. Lúc đó thiết bị trở thành bình điện phân. Sạc acquy chính là việc này: khi phóng điện acquy là pin, khi sạc nó là bình điện phân.

### 1.2. Một trục E°, bốn cách dùng

Bảng E° (SGK tr. 70) là công cụ duy nhất em cần cho cả chương. Hình dung các cặp xếp trên một trục, E° tăng từ trái sang phải. Mọi câu hỏi đều quy về việc **so vị trí** hai cặp trên trục này.

| Câu hỏi | Cách dùng E° | Xem lại |
|---|---|---|
| Kim loại nào khử mạnh hơn? Ion nào oxi hoá mạnh hơn? | E° nhỏ: kim loại khử mạnh. E° lớn: ion oxi hoá mạnh | Bài 15, mục 3.1 |
| Phản ứng có xảy ra không? | Xảy ra khi E°(cặp chứa chất khử) < E°(cặp chứa chất oxi hoá) | Bài 15, mục 3.2 |
| Trong pin, điện cực nào là cathode? E°~pin~ bằng bao nhiêu? | Cặp E° lớn là cathode. E°~pin~ = E°~lớn~ − E°~nhỏ~ | Bài 15, mục 4.3 |
| Khi điện phân dung dịch, ion nào bị khử trước ở cathode? | Ion có E° lớn hơn bị khử trước: Ag^+^ > Fe^3+^ > Cu^2+^ > H^+^… | Bài 16, mục 2.3 |

Để ý hàng 3 và hàng 4: trong **cả pin lẫn bình điện phân**, ion có E° lớn là ion "thắng" ở cathode. Đó không phải trùng hợp. Ion có E° lớn hút electron mạnh nhất, nên ở nơi electron được đưa tới (cathode), nó luôn được nhận trước.

> [!nen-tang] Các giá trị E° hay dùng nhất (V)
> - K^+^/K −2,924 · Na^+^/Na −2,713 · Mg^2+^/Mg −2,356 · Al^3+^/Al −1,676.
> - Zn^2+^/Zn −0,762 · Fe^2+^/Fe −0,44 · Ni^2+^/Ni −0,257 · Sn^2+^/Sn −0,137 · Pb^2+^/Pb −0,126.
> - 2H^+^/H~2~ 0 · Cu^2+^/Cu +0,340 · Fe^3+^/Fe^2+^ +0,771 · Ag^+^/Ag +0,799 · Hg^2+^/Hg +0,853 · Au^3+^/Au +1,52.
>
> Đề thi luôn cho sẵn số. Em chỉ cần nhớ **thứ tự**, nhất là vị trí của Fe^3+^/Fe^2+^ (giữa Cu và Ag).

### 1.3. Nguồn điện hoá học

Mọi pin điện hoá đều gồm **hai điện cực** ứng với hai cặp oxi hoá – khử và một chất điện li nối chúng (cầu muối, dung dịch, màng). Khác nhau ở chỗ chất phản ứng có được tái tạo hay cấp thêm hay không (Bài 15, mục 5).

| Nguồn điện | Loại | Điểm đề hay hỏi |
|---|---|---|
| Pin Galvani (Zn – Cu) | phòng thí nghiệm | cầu muối đóng kín mạch, giữ trung hoà điện |
| Pin khô | sơ cấp | rẻ, gọn, không sạc được |
| Acquy chì | sạc (thứ cấp) | rẻ, ổn định, nặng, nguy cơ ngộ độc chì khi tái chế thủ công |
| Pin lithium-ion | sạc (thứ cấp) | nhẹ, mật độ năng lượng cao, có nguy cơ cháy nổ |
| Pin nhiên liệu H~2~ – O~2~ | cấp nhiên liệu liên tục | sản phẩm chỉ có nước, hiệu suất cao, giá cao |
| Pin Mặt Trời | không phải pin điện hoá | quang năng → điện năng, nhờ chất bán dẫn |

### 1.4. Điện phân và ứng dụng

Khi điện phân, ở mỗi điện cực có nhiều "ứng viên". Quy tắc chọn (SGK tr. 81) chỉ có hai dòng: **cathode khử chất oxi hoá mạnh nhất trước**, **anode oxi hoá chất khử mạnh nhất trước**.

Thứ tự cụ thể khi làm đề (điện cực trơ), thống nhất với Bài 16:

- **Cathode:** Au^3+^ > Ag^+^ > Hg^2+^ > Fe^3+^ > Cu^2+^ > H^+^ (acid) > Pb^2+^ > Sn^2+^ > Ni^2+^ > Fe^2+^ > Zn^2+^ > H~2~O. Ion K^+^, Na^+^, Ca^2+^, Mg^2+^, Al^3+^ không bị khử trong dung dịch.
- **Anode trơ:** I^−^ > Br^−^ > Cl^−^ > H~2~O. Các anion SO~4~^2−^, NO~3~^−^, F^−^ coi như không bị điện phân.
- **Anode tan:** anode bằng kim loại không trơ (Cu, Ag, Ni…) thì **chính kim loại đó** bị oxi hoá trước.

> [!bay] Phần nào là SGK, phần nào là quy ước làm đề?
> - SGK nêu nguyên tắc chung và thứ tự Au^3+^ > Ag^+^ > Hg^2+^ > Cu^2+^ > H^+^ > H~2~O ở cathode, I^−^ > Br^−^ > Cl^−^ > H~2~O ở anode.
> - Vị trí của Fe^3+^ (khử về Fe^2+^), và việc Zn^2+^, Fe^2+^, Ni^2+^, Sn^2+^, Pb^2+^ bị khử **sau H^+^ của acid nhưng trước H~2~O**, là **quy ước thường dùng, ngoài SGK** (Bài 16, mục 2.3). Đề nào cho thứ tự khác thì làm theo đề.

Ba ứng dụng trong SGK đều là cùng một quy tắc áp vào ba tình huống:

| Ứng dụng | Anode (+) | Cathode (−) | Chất điện li | Ghi nhớ |
|---|---|---|---|---|
| Sản xuất nhôm | khối than chì, **bị O~2~ đốt cháy dần** | than chì lót đáy, Al lỏng đọng lại | Al~2~O~3~ nóng chảy + cryolite | 2Al~2~O~3~ → 4Al + 3O~2~ (đpnc), cryolite hạ nhiệt độ nóng chảy từ 2 050 °C xuống gần 1 000 °C |
| Tinh luyện đồng | **đồng thô**, tan dần | lá đồng tinh khiết | CuSO~4~ + H~2~SO~4~ | Cu chuyển từ anode sang cathode, [Cu^2+^] gần như không đổi |
| Mạ điện | **kim loại dùng để mạ**, tan dần | **vật cần mạ** | muối của kim loại mạ | độ dày lớp mạ tăng theo cường độ dòng và thời gian |

## 2. So sánh – phân biệt

### 2.1. Pin điện hoá và bình điện phân

Đây là bảng quan trọng nhất của chương. Hầu như đề nào cũng có một câu đánh tráo các ô trong bảng này.

| | Pin điện hoá (Bài 15) | Bình điện phân (Bài 16) |
|---|---|---|
| Phản ứng oxi hoá – khử | **tự xảy ra** | **không tự xảy ra**, phải dùng nguồn điện |
| Chuyển hoá năng lượng | hoá năng → điện năng | điện năng → hoá năng |
| Anode | nơi **oxi hoá**, là **cực âm** | nơi **oxi hoá**, là **cực dương** |
| Cathode | nơi **khử**, là **cực dương** | nơi **khử**, là **cực âm** |
| Anode được chọn thế nào? | điện cực của cặp có E° **nhỏ** hơn | điện cực nối với cực dương của nguồn |
| Electron ở mạch ngoài | từ anode qua dây dẫn sang cathode | từ anode về cực dương nguồn, từ cực âm nguồn sang cathode |
| Ion trong dung dịch | anion của cầu muối về cốc anode, cation về cốc cathode | anion về anode, cation về cathode |
| Khối lượng điện cực | anode kim loại tan dần (giảm), cathode có kim loại bám (tăng) | cathode có kim loại bám (tăng), anode trơ không đổi, anode tan thì giảm |
| Đại lượng đặc trưng | sức điện động E°~pin~ = E°~cathode~ − E°~anode~ | lượng chất tính theo $n_e = It/F$ (mở rộng) |
| Ví dụ | pin Zn – Cu, acquy khi phóng điện | điện phân CuSO~4~, NaCl, Al~2~O~3~, acquy khi sạc |

![Hình 2. Pin điện hoá và bình điện phân đặt cạnh nhau: dấu điện cực ngược nhau, nhưng anode luôn là nơi oxi hoá và electron luôn rời anode đi vào cathode](pin-dien-phan.svg)

**Vì sao dấu điện cực lại đổi?** Trong pin, anode là nơi chất khử **tự** nhường electron, electron dồn lại ở đó nên anode **âm**. Trong bình điện phân, nguồn điện **hút** electron ra khỏi anode (để ép chất khử nhường electron), nên anode thiếu electron, mang dấu **dương**. Dấu chỉ là hệ quả. Bản chất (anode = oxi hoá) thì không đổi.

> [!meo] Một câu nhớ cả hai thiết bị
> - "**A**node – **O**xi hoá, **C**athode – **K**hử" đúng cho mọi trường hợp.
> - Dấu: "**Pin âm A**node", nghĩa là trong pin anode âm. Sang điện phân thì đảo lại.
> - Hình 2 cho thấy ở **cả hai** thiết bị, electron đi trong dây dẫn từ phía anode sang phía cathode. Trong dung dịch **chỉ có ion** di chuyển.

### 2.2. Các cặp hay bị đánh tráo trong đề

| Cặp | Giống nhau | Khác nhau (chỗ đề hay hỏi) |
|---|---|---|
| Dạng oxi hoá – chất oxi hoá | đều là dạng có số oxi hoá cao hơn | "dạng oxi hoá" là vị trí trong cặp. Nó chỉ thành "chất oxi hoá" khi thật sự nhận electron trong phản ứng |
| Cặp Fe^2+^/Fe – cặp Fe^3+^/Fe^2+^ | đều có Fe^2+^ | ở cặp đầu Fe^2+^ là **dạng oxi hoá** (E° = −0,44). Ở cặp sau Fe^2+^ là **dạng khử** (E° = +0,771) |
| E° của cặp – E°~pin~ | đều đo bằng volt | E° của cặp có thể âm. E°~pin~ luôn dương, là **hiệu** hai E° |
| Điện phân nóng chảy – điện phân dung dịch | đều dùng dòng một chiều | dung dịch có **nước** tham gia ở cả hai cực. Na, K, Mg, Al chỉ điều chế bằng điện phân **nóng chảy** |
| Điện phân NaCl có màng ngăn – không màng ngăn | đều có H~2~ ở cathode, Cl~2~ ở anode | có màng ngăn: NaOH + H~2~ + Cl~2~. Không màng ngăn: Cl~2~ gặp NaOH, thu nước Javel (NaCl + NaClO) |
| Anode trơ – anode tan | đều là nơi oxi hoá | anode trơ (than chì, Pt): anion hoặc nước bị oxi hoá, thoát khí. Anode tan (Cu, Ag, Ni): kim loại tan ra |
| Điện phân CuSO~4~ (trơ) – tinh luyện đồng | cathode đều có Cu bám | trơ: anode thoát O~2~, dung dịch nhạt màu, sinh H~2~SO~4~. Tinh luyện: anode đồng tan, [Cu^2+^] gần như không đổi |
| Tinh luyện đồng – mạ điện | đều dùng anode tan | tinh luyện: cathode là **chính kim loại đó** (đồng tinh khiết). Mạ: cathode là **vật khác** cần phủ |
| Pin sơ cấp – pin sạc | đều là pin điện hoá | sơ cấp (pin khô) dùng một lần. Pin sạc (acquy chì, Li-ion) tái tạo chất phản ứng nhờ điện phân |
| Pin nhiên liệu – pin Mặt Trời | đều là nguồn năng lượng sạch | pin nhiên liệu là pin **điện hoá** (H~2~ bị oxi hoá, O~2~ bị khử). Pin Mặt Trời dùng **bán dẫn**, không có phản ứng oxi hoá – khử |

## 3. Bảng công thức tính toán của chương

| Bài toán | Công thức / tỉ lệ | Xem lại |
|---|---|---|
| Sức điện động chuẩn | E°~pin~ = E°~cathode~ − E°~anode~ | Bài 15, mục 4.3 |
| Suy ngược E° | E°~anode~ = E°~cathode~ − E°~pin~; E°~cathode~ = E°~anode~ + E°~pin~ | Bài 15, Dạng 2 |
| Ba điện cực X < Y < Z | E°~pin~(X–Z) = E°~pin~(X–Y) + E°~pin~(Y–Z) | Bài 15, Ví dụ 8 |
| Khối lượng điện cực trong pin | n~e~ = n(kim loại tan) × hoá trị = n(kim loại bám) × hoá trị | Bài 15, Dạng 3 |
| Số mol electron khi điện phân (ngoài SGK) | $n_e = \dfrac{It}{F}$, F = 96 500 C/mol, t tính bằng giây | Bài 16, mục 4 |
| Khối lượng chất ở điện cực | $m = \dfrac{A\,I\,t}{n\,F}$ | Bài 16, mục 4.1 |
| Đổi electron ra chất | 1 mol e: 1 mol Ag, 0,5 mol Cu, 0,5 mol H~2~, 0,5 mol Cl~2~, 0,25 mol O~2~, 1/3 mol Al | Bài 16, mục 4.1 |
| Thể tích khí (đkc) | V = n · 24,79 L | Bài 16, mục 4.1 |
| Khối lượng dung dịch giảm | m(kim loại bám) + m(các khí thoát ra) | Bài 16, Dạng 3 |
| Mạch nối tiếp | **cùng một n~e~** chạy qua mọi bình điện phân và pin trong mạch | mục 5.1 bài này |

> [!bay] Ba con số dễ sai của chương
> - O~2~ cần **4** electron: n(O~2~) = n~e~ : 4, không phải n~e~ : 2.
> - Thời gian phải đổi ra **giây** trước khi thế vào $n_e = It/F$.
> - Không nhân E° với hệ số phương trình. Cu + 2Ag^+^ vẫn có E°~pin~ = 0,799 − 0,340.

## 4. Lỗi sai hay gặp của cả chương

**Về cặp oxi hoá – khử và E°**

- Viết ngược cặp (Cu/Cu^2+^ thay vì Cu^2+^/Cu).
- Nghĩ E° càng lớn thì kim loại càng hoạt động (ngược lại: E° lớn thì kim loại khử **yếu**).
- Dùng nhầm cặp Fe^2+^/Fe (−0,44) khi Fe^2+^ đóng vai chất khử (phải dùng cặp Fe^3+^/Fe^2+^, +0,771).
- Cho rằng Cu không tác dụng với mọi muối sắt (Cu **có** khử được Fe^3+^ về Fe^2+^).
- Cho Na, K vào dung dịch CuSO~4~ rồi kết luận Cu bị đẩy ra (kim loại kiềm phản ứng với **nước** trước, tạo kết tủa Cu(OH)~2~).

**Về pin điện hoá**

- Nói anode của pin là nơi xảy ra sự khử, hoặc anode là cực dương.
- Cho electron đi qua cầu muối hoặc qua dung dịch (electron chỉ đi qua dây dẫn).
- Cho anion trong cầu muối chạy về cốc cathode (đúng là về cốc **anode**, nơi đang dư ion dương).
- Tính E°~pin~ = E°~anode~ − E°~cathode~ ra số âm, hoặc quên dấu trừ của E° âm.
- Cho rằng khối lượng anode giảm bằng khối lượng cathode tăng (Zn 65 khác Cu 64).
- Xếp pin Mặt Trời vào pin điện hoá.

**Về điện phân**

- Nói anode của bình điện phân là cực âm (đó là anode của **pin**).
- Cho rằng điện phân dung dịch NaCl, MgCl~2~, AlCl~3~ thu được kim loại.
- Viết khí SO~2~ ở anode khi điện phân CuSO~4~ (SO~4~^2−^ không bị điện phân, anode thoát **O~2~**).
- Quên anode tan: anode bằng đồng thì đồng tan ra, không thoát O~2~.
- Cho Fe^3+^ bị khử thẳng về Fe, hoặc cho Fe^2+^ bị khử trước H^+^ của acid.
- Nối vật cần mạ vào cực dương (vật sẽ bị ăn mòn chứ không được mạ).
- Cho rằng cryolite bị điện phân, hoặc anode than chì trong sản xuất nhôm là điện cực trơ không hao mòn.

**Về tính toán**

- Để thời gian theo phút hoặc giờ khi tính It/F.
- Chia n~e~ cho 2 khi tính O~2~.
- Không so n~e~ với lượng ion kim loại, nên bỏ sót H~2~ ở cathode hoặc O~2~ ở anode khi ion đã hết.
- Cộng cả H~2~SO~4~, NaOH vào khối lượng dung dịch giảm (chúng vẫn nằm trong dung dịch).

## 5. Bài tập tổng hợp

Các ví dụ dưới đây phối hợp cả hai bài. Hãy tự làm trước, mở từng gợi ý khi bí.

### 5.1. Pin làm nguồn điện cho bình điện phân

> [!vi-du] Ví dụ 1
> Một bộ nguồn gồm 3 pin Galvani Zn – Cu giống nhau mắc nối tiếp (mỗi pin: thanh Zn trong dung dịch ZnSO~4~, thanh Cu trong dung dịch CuSO~4~, có cầu muối) được dùng để điện phân dung dịch NaCl (hai điện cực than chì, có màng ngăn). Sau một thời gian, thanh Zn của **mỗi** pin giảm 1,3 g. Coi toàn bộ dòng điện của bộ pin dùng cho bình điện phân, khí không tan trong nước.
>
> a) Cực âm của bộ pin là một thanh Zn. Thanh Zn đó phải nối với điện cực nào của bình điện phân? Vì sao?
>
> b) Khối lượng thanh Cu của mỗi pin thay đổi thế nào?
>
> c) Tính thể tích mỗi khí (đkc) thoát ra ở bình điện phân và số mol NaOH tạo thành.

> [!goi-y] Gợi ý 1
> Thanh Zn là cực âm của pin, là nơi electron đi ra. Electron đi ra từ nguồn thì đi vào điện cực nào của bình điện phân?

> [!goi-y] Gợi ý 2
> Mạch nối tiếp nên số mol electron đi qua **mỗi** pin bằng số mol electron đi qua bình điện phân: n~e~ = 2 · n(Zn của một pin). Không nhân 3.

> [!loi-giai] Lời giải
> a) Zn là anode của pin, là **cực âm**, electron từ Zn đi ra mạch ngoài. Electron đó phải được đưa vào nơi xảy ra sự khử của bình điện phân, tức **cathode**. Vậy thanh Zn (cực âm của bộ pin) nối với **cathode** bình điện phân, thanh Cu ở đầu kia của bộ pin (cực dương) nối với **anode**.
>
> b) Mỗi pin: n(Zn) = 1,3 : 65 = 0,02 mol → n~e~ = 0,04 mol. Ở thanh Cu: Cu^2+^ + 2e → Cu, n(Cu) = 0,02 mol. Thanh Cu của mỗi pin **tăng** 0,02 · 64 = **1,28 g**.
>
> c) Bình điện phân nhận cùng 0,04 mol electron.
>
> Cathode: 2H~2~O + 2e → H~2~ + 2OH^−^, n(H~2~) = 0,02 mol, V = 0,02 · 24,79 ≈ **0,50 L**.
>
> Anode: 2Cl^−^ → Cl~2~ + 2e, n(Cl~2~) = 0,02 mol, V ≈ **0,50 L**.
>
> n(NaOH) = n(OH^−^) = n~e~ = **0,04 mol**.
>
> **Vì sao cần 3 pin?** Mỗi pin Zn – Cu chỉ có khoảng 1,1 V. Phản ứng 2NaCl + 2H~2~O → 2NaOH + H~2~ + Cl~2~ không tự xảy ra, cần hiệu điện thế tối thiểu khoảng 2,2 V theo lí thuyết, thực tế còn cao hơn (mở rộng, ngoài SGK). Mắc nối tiếp thì hiệu điện thế cộng lại (khoảng 3,3 V), còn dòng electron qua mọi pin vẫn như nhau. Một pin đơn lẻ không điện phân được dung dịch NaCl.

> [!meo] Mạch nối tiếp
> Pin (hay từng pin trong bộ pin nối tiếp), bình điện phân, ampe kế mắc nối tiếp thì **cùng một dòng electron** chạy qua. Em chỉ cần tìm n~e~ ở một chỗ (khối lượng một điện cực, thể tích một khí, hoặc It/F) rồi dùng cho mọi chỗ khác trong mạch.

### 5.2. Điện phân hỗn hợp có ion Fe^3+^

> [!vi-du] Ví dụ 2
> Điện phân dung dịch chứa 0,04 mol FeCl~3~ và 0,05 mol CuCl~2~ (điện cực trơ) với dòng điện 5 A trong 2 316 giây. Cho E° (V): Fe^2+^/Fe −0,44 · Cu^2+^/Cu +0,340 · Fe^3+^/Fe^2+^ +0,771. Coi khí không tan trong nước, nước bay hơi không đáng kể.
>
> a) Sắp xếp thứ tự các quá trình ở cathode.
>
> b) Tính khối lượng kim loại bám vào cathode.
>
> c) Tính thể tích khí (đkc) thoát ra ở anode và khối lượng dung dịch giảm.

> [!goi-y] Gợi ý 1
> Ở cathode, ion có E° lớn nhất bị khử trước. Fe^3+^ (+0,771) lớn hơn Cu^2+^ (+0,340), nhưng Fe^3+^ chỉ xuống **Fe^2+^**.

> [!goi-y] Gợi ý 2
> n~e~ = It/F. Trừ dần electron: Fe^3+^ → Fe^2+^ dùng 1e mỗi ion, Cu^2+^ → Cu dùng 2e mỗi ion. Ở anode, so tổng số mol Cl^−^ với n~e~.

> [!loi-giai] Lời giải
> a) Thứ tự ở cathode: Fe^3+^ + 1e → Fe^2+^, rồi Cu^2+^ + 2e → Cu, rồi mới đến Fe^2+^ + 2e → Fe (theo quy ước làm đề ở Bài 16).
>
> b) n~e~ = 5 · 2 316 : 96 500 = 0,12 mol.
>
> Fe^3+^ → Fe^2+^ dùng 0,04 mol e, còn 0,08 mol e. Cu^2+^ cần 0,1 mol e mới hết, nên Cu^2+^ còn dư: n(Cu) = 0,08 : 2 = 0,04 mol.
>
> Kim loại bám vào cathode chỉ là Cu: m = 0,04 · 64 = **2,56 g**. Chưa có Fe.
>
> c) Tổng n(Cl^−^) = 0,04 · 3 + 0,05 · 2 = 0,22 mol, lớn hơn 0,12, nên anode chỉ có Cl~2~: n(Cl~2~) = 0,12 : 2 = 0,06 mol, V = 0,06 · 24,79 ≈ **1,49 L**.
>
> Khối lượng dung dịch giảm = m(Cu) + m(Cl~2~) = 2,56 + 0,06 · 71 = **6,82 g**.

> [!bay]
> - Cho Fe^3+^ khử thẳng về Fe thì em sẽ tính 0,04 mol Fe bám cathode và chỉ còn 0 mol e cho Cu^2+^: sai cả thứ tự lẫn số liệu.
> - Bỏ qua Fe^3+^ (cho Cu^2+^ bị khử đầu tiên) thì ra 0,05 mol Cu = 3,2 g, cũng sai.

### 5.3. Hydrogen "xanh": điện phân nước rồi chạy pin nhiên liệu

> [!vi-du] Ví dụ 3 (vận dụng cao)
> Một trạm thử nghiệm dùng điện từ tấm pin Mặt Trời để điện phân dung dịch NaOH loãng (điện cực trơ) với dòng điện 9,65 A trong 5 giờ. Toàn bộ H~2~ thu được đưa vào một pin nhiên liệu hydrogen – oxygen.
>
> a) Vì sao điện phân dung dịch NaOH loãng thực chất là điện phân nước? Tính thể tích H~2~ và O~2~ (đkc) thu được.
>
> b) Khi pin nhiên liệu dùng hết lượng H~2~ trên, điện lượng nó cung cấp cho mạch ngoài là bao nhiêu coulomb? Khối lượng nước tạo thành là bao nhiêu?
>
> c) Pin nhiên liệu có E°~pin~ = 1,229 V. Nếu bình điện phân phải dùng hiệu điện thế 2,0 V, hãy so sánh điện năng tiêu thụ khi điện phân với điện năng tối đa pin nhiên liệu trả lại (điện năng W = q · U).

> [!nen-tang] Điện năng (Vật lí 11)
> - Điện lượng q (C) dịch chuyển qua hiệu điện thế U (V) thì điện năng tương ứng là W = q · U (J).
> - Cùng một điện lượng, hiệu điện thế càng lớn thì điện năng càng lớn.

> [!goi-y] Gợi ý 1
> Na^+^ không bị khử, OH^−^ ở anode bị oxi hoá thành O~2~ (thực chất là nước bị điện phân). Tính n~e~ = It/F với t = 5 · 3 600 s.

> [!goi-y] Gợi ý 2
> Trong pin nhiên liệu, H~2~ bị oxi hoá: H~2~ → 2H^+^ + 2e. Mỗi mol H~2~ trả lại đúng 2 mol electron, bằng số electron đã dùng để tạo ra nó khi điện phân.

> [!loi-giai] Lời giải
> a) Ở cathode, Na^+^ không bị khử nên nước bị khử thành H~2~. Ở anode, nước (hay OH^−^) bị oxi hoá thành O~2~. NaOH không bị tiêu hao, chỉ giúp dung dịch dẫn điện. Tổng: 2H~2~O → 2H~2~ + O~2~.
>
> n~e~ = 9,65 · 18 000 : 96 500 = 1,8 mol.
>
> n(H~2~) = 1,8 : 2 = 0,9 mol, V ≈ 0,9 · 24,79 ≈ **22,31 L**. n(O~2~) = 1,8 : 4 = 0,45 mol, V ≈ **11,16 L**.
>
> b) 0,9 mol H~2~ nhường 1,8 mol e, q = 1,8 · 96 500 = **173 700 C**. 2H~2~ + O~2~ → 2H~2~O nên n(H~2~O) = 0,9 mol, m = **16,2 g**.
>
> c) Điện năng điện phân: W~1~ = 173 700 · 2,0 = 347 400 J ≈ 347 kJ. Điện năng pin trả lại tối đa: W~2~ = 173 700 · 1,229 ≈ 213 477 J ≈ 213 kJ.
>
> Pin chỉ trả lại tối đa khoảng 213 : 347 ≈ **61%** điện năng đã bỏ ra. Phần còn lại mất đi dưới dạng nhiệt trong bình điện phân. Điện phân luôn phải dùng hiệu điện thế **lớn hơn** E°~pin~ của phản ứng ngược thì mới "ép" được phản ứng xảy ra.

> [!ung-dung] Vì sao vẫn làm hydrogen xanh dù hao hụt?
> Điện Mặt Trời, điện gió chỉ có lúc nắng, lúc gió. Biến điện dư thành H~2~ là cách **cất điện năng** để dùng lúc cần, hoặc chở đi xa. Pin nhiên liệu đốt H~2~ không thải CO~2~, chỉ thải nước.

### 5.4. Đúng/Sai: cùng một thiết bị, hai cách nối

> [!vi-du] Ví dụ 4 (Đúng/Sai)
> Lắp một thiết bị gồm thanh Zn nhúng trong dung dịch ZnSO~4~ 1 M và thanh Cu nhúng trong dung dịch CuSO~4~ 1 M, nối bằng cầu muối KNO~3~.
>
> Lần 1: nối hai thanh qua một bóng đèn nhỏ.
>
> Lần 2: bỏ bóng đèn, nối thanh Zn với cực âm và thanh Cu với cực dương của một nguồn điện một chiều 3 V.
>
> Xét các phát biểu:
>
> a) Ở lần 1, electron đi qua dây dẫn từ thanh Cu sang thanh Zn.
>
> b) Ở lần 2, thanh Zn trở thành cathode, tại đó Zn^2+^ bị khử thành Zn.
>
> c) Ở lần 2, phản ứng tổng là Cu + Zn^2+^ → Cu^2+^ + Zn, một phản ứng không tự xảy ra.
>
> d) Ở cả hai lần, thanh Cu đều là cathode.

> [!goi-y] Gợi ý 1
> Lần 1 là pin: điện cực có E° nhỏ hơn là anode. Lần 2: điện cực nối với cực âm của nguồn được bơm electron vào, nên là nơi xảy ra quá trình gì?

> [!goi-y] Gợi ý 2
> 3 V lớn hơn 1,102 V, nên nguồn đủ mạnh để đẩy electron ngược chiều với lần 1.

> [!loi-giai] Lời giải
> a) **Sai.** Lần 1 là pin Zn – Cu: Zn (E° nhỏ) là anode, electron đi từ **Zn sang Cu**.
>
> b) **Đúng.** Thanh Zn nhận electron từ cực âm của nguồn, nên là nơi xảy ra sự khử: Zn^2+^ + 2e → Zn. Đó là cathode (cực âm) của bình điện phân.
>
> c) **Đúng.** Anode lần 2 là thanh Cu: Cu → Cu^2+^ + 2e. Cộng lại được Cu + Zn^2+^ → Cu^2+^ + Zn, chiều ngược của phản ứng tự xảy ra.
>
> d) **Sai.** Lần 1 Cu là cathode, lần 2 Cu là **anode** (nối cực dương nguồn, bị oxi hoá, tan dần).
>
> Ví dụ này chính là nguyên lí của pin sạc: phóng điện là lần 1, sạc là lần 2.

## 6. Đối chiếu bài tập SGK (tr. 86)

**Câu 1 (bảng bốn cặp, ba câu hỏi nhỏ).** Ba câu hỏi đều là "so vị trí trên trục E°": khử mạnh nhất là E° nhỏ nhất, khử được H^+^ khi E° < 0, khử được Ag^+^ khi E° < +0,799. Chú ý: câu hỏi kiểu này ở **điều kiện chuẩn** chỉ so E°, chưa xét kim loại có phản ứng với nước hay không. Khi đề nói rõ "cho vào dung dịch muối" thì phải xét thêm kim loại kiềm, như Ví dụ 5 dưới đây.

> [!vi-du] Ví dụ 5 (tương tự Câu 1)
> Cho các cặp oxi hoá – khử và E° (V): Na^+^/Na −2,713 · Ni^2+^/Ni −0,257 · Cu^2+^/Cu +0,340 · Zn^2+^/Zn −0,762.
>
> a) Kim loại nào có tính khử mạnh nhất, yếu nhất?
>
> b) Có bao nhiêu kim loại khử được ion H^+^ thành H~2~ ở điều kiện chuẩn?
>
> c) Cho từng kim loại (dạng thanh hoặc mẩu nhỏ) vào dung dịch CuSO~4~. Có bao nhiêu kim loại đẩy được Cu ra khỏi dung dịch?

> [!goi-y] Gợi ý 1
> Sắp xếp E° tăng dần: Na < Zn < Ni < Cu. Câu b: so với 0 V. Câu c: so với +0,340 V.

> [!goi-y] Gợi ý 2
> Câu c: Na gặp dung dịch thì phản ứng với chất nào trước, Cu^2+^ hay H~2~O?

> [!loi-giai] Lời giải
> a) Khử mạnh nhất: **Na** (E° nhỏ nhất). Khử yếu nhất: **Cu** (E° lớn nhất).
>
> b) Na, Zn, Ni có E° < 0 → **3** kim loại.
>
> c) Theo E°, Na, Zn, Ni đều nhỏ hơn +0,340 V. Nhưng Na phản ứng với **nước** trước: 2Na + 2H~2~O → 2NaOH + H~2~, rồi NaOH tạo kết tủa Cu(OH)~2~ với CuSO~4~. Na không đẩy được Cu. Chỉ có Zn, Ni → **2** kim loại.

**Câu 2 (pin Pb – Zn).** Ba bước cố định: cặp E° nhỏ là anode, viết hai bán phản ứng rồi cộng, E°~pin~ = lớn − nhỏ. Em hãy tự làm với số liệu SGK, rồi đối chiếu cách làm với Ví dụ 6.

> [!vi-du] Ví dụ 6 (tương tự Câu 2)
> Cho pin điện hoá tạo bởi hai cặp Sn^2+^/Sn (E° = −0,137 V) và Ni^2+^/Ni (E° = −0,257 V) ở điều kiện chuẩn.
>
> a) Xác định anode, cathode.
>
> b) Viết quá trình ở mỗi điện cực và phản ứng xảy ra khi pin hoạt động.
>
> c) Tính sức điện động chuẩn của pin.

> [!goi-y] Gợi ý 1
> Cả hai E° đều âm. Số nào **nhỏ hơn**? (−0,257 hay −0,137)

> [!goi-y] Gợi ý 2
> E°~pin~ = E°~cathode~ − E°~anode~, cẩn thận hai dấu trừ.

> [!loi-giai] Lời giải
> a) −0,257 < −0,137 nên **Ni là anode** (cực âm), **Sn là cathode** (cực dương).
>
> b) Anode: Ni → Ni^2+^ + 2e. Cathode: Sn^2+^ + 2e → Sn.
>
> => Ni + Sn^2+^ → Ni^2+^ + Sn
>
> c) E°~pin~ = −0,137 − (−0,257) = **0,120 V**. Pin này có sức điện động rất nhỏ vì hai cặp nằm sát nhau trên trục E°.

**Câu 3 (tìm M từ E°~pin~, chọn M cho E°~pin~ lớn nhất).** Đây là bài "suy ngược E°". Ag^+^/Ag có E° lớn nhất trong bảng nên luôn là cathode. Từ đó E°(M^2+^/M) = E°(Ag^+^/Ag) − E°~pin~. Muốn E°~pin~ lớn nhất thì chọn M có E° **nhỏ nhất**, tức đứng xa Ag nhất trên trục.

> [!vi-du] Ví dụ 7 (tương tự Câu 3)
> Pin điện hoá gồm hai điện cực M^2+^/M và Ag^+^/Ag ở điều kiện chuẩn có sức điện động 0,936 V. Cho E° (V): Fe^2+^/Fe −0,44 · Ni^2+^/Ni −0,257 · Sn^2+^/Sn −0,137 · Cu^2+^/Cu +0,340 · Ag^+^/Ag +0,799.
>
> a) Trong số Fe, Ni, Sn, Cu, kim loại nào là M?
>
> b) Thay M bằng kim loại nào trong bốn kim loại trên để được pin (với điện cực Ag) có sức điện động chuẩn lớn nhất? Tính giá trị đó.

> [!goi-y] Gợi ý 1
> Cả bốn cặp đều có E° nhỏ hơn +0,799, nên điện cực bạc là cathode.

> [!goi-y] Gợi ý 2
> 0,936 = 0,799 − E°(M^2+^/M).

> [!loi-giai] Lời giải
> a) E°(M^2+^/M) = 0,799 − 0,936 = −0,137 V → M là **Sn**.
>
> b) Chọn kim loại có E° nhỏ nhất: **Fe**. E°~pin~ = 0,799 − (−0,44) = **1,239 V**.
>
> (So sánh: Ni – Ag là 1,056 V, Cu – Ag chỉ 0,459 V.)

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Cặp oxi hoá – khử | M^n+^/M; M^n+^ + ne ⇌ M |
| Ý nghĩa E° | E° nhỏ: kim loại khử mạnh; E° lớn: ion oxi hoá mạnh |
| Chiều phản ứng | chất khử (cặp E° nhỏ) + chất oxi hoá (cặp E° lớn) |
| Anode / cathode | anode luôn oxi hoá; cathode luôn khử |
| Dấu điện cực | pin: anode (−), cathode (+); điện phân: anode (+), cathode (−) |
| Sức điện động chuẩn | E°~pin~ = E°~cathode~ − E°~anode~ > 0 |
| Nguồn điện | pin sạc: acquy chì, Li-ion; sơ cấp: pin khô; pin nhiên liệu H~2~ – O~2~ thải nước; pin Mặt Trời không điện hoá |
| Thứ tự điện phân | cathode: oxi hoá mạnh khử trước; anode: khử mạnh oxi hoá trước |
| Cathode khi làm đề | Ag^+^ > Fe^3+^ (→ Fe^2+^) > Cu^2+^ > H^+^ > Pb^2+^, Sn^2+^, Ni^2+^, Fe^2+^, Zn^2+^ > H~2~O (quy ước ngoài SGK) |
| Anode trơ / anode tan | I^−^ > Br^−^ > Cl^−^ > H~2~O; anode kim loại thì kim loại tan |
| Sản xuất Al | 2Al~2~O~3~ → 4Al + 3O~2~ (đpnc, cryolite) |
| Tinh luyện Cu / mạ điện | anode đồng thô (kim loại mạ) tan; cathode đồng tinh khiết (vật cần mạ) |
| Tính toán (ngoài SGK) | $n_e = It/F$; F = 96 500 C/mol; mạch nối tiếp cùng n~e~ |

**Ba bước giải mọi bài của chương:**

1. **Xác định vai trò:** điện cực nào là anode (oxi hoá), cathode (khử)? Pin hay bình điện phân, để biết dấu.
2. **Chọn chất phản ứng theo E°:** trong pin, cặp E° nhỏ là anode. Trong điện phân, chất oxi hoá mạnh nhất về cathode trước, chất khử mạnh nhất ở anode trước (để ý anode tan).
3. **Tính theo electron:** E°~pin~ = lớn − nhỏ. Khối lượng, thể tích đều đi qua n~e~, chia n~e~ lần lượt cho từng quá trình theo đúng thứ tự.
