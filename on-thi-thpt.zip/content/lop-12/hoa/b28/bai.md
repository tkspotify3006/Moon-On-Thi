---
title: Sơ lược về phức chất
thoi-gian: 35 phút
muc-tieu:
  - Nêu được thế nào là phức chất; chỉ ra được nguyên tử trung tâm, phối tử, số phối tử và điện tích của một phức chất cho trước.
  - Giải thích được liên kết giữa nguyên tử trung tâm và phối tử là liên kết cho – nhận.
  - Nêu được ba dạng hình học phổ biến của phức chất (tứ diện, vuông phẳng, bát diện) và số phối tử tương ứng.
  - Trình bày được sự hình thành phức chất aqua của ion kim loại chuyển tiếp với H~2~O trong dung dịch nước.
  - Tính được điện tích của phức chất hoặc của nguyên tử trung tâm; phân biệt cầu nội, cầu ngoại.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Phức chất** gồm **nguyên tử trung tâm M** (cation hoặc nguyên tử kim loại) liên kết với các **phối tử L** (anion hoặc phân tử). Viết M và L trong móc vuông, ví dụ [Co(NH~3~)~6~]^3+^.
> 2. **Điện tích phức = điện tích của M + tổng điện tích các phối tử.** Phức có thể là cation, anion hoặc trung hoà.
> 3. Liên kết M – L là **liên kết cho – nhận**: phối tử **cho** cặp electron chưa liên kết, M **nhận** vào AO trống.
> 4. Ba dạng hình học phổ biến: **tứ diện** (4 L), **vuông phẳng** (4 L), **bát diện** (6 L).
> 5. Trong nước, ion kim loại chuyển tiếp M^n+^ nhận cặp electron của H~2~O tạo **phức chất aqua**, hầu hết là bát diện [M(H~2~O)~6~]^n+^. Ví dụ: dung dịch CuSO~4~ có màu xanh do [Cu(H~2~O)~6~]^2+^.

Em đã gặp phức chất nhiều lần mà có thể chưa để ý. Thuốc thử Tollens chứa [Ag(NH~3~)~2~]OH (Bài 4). Nước Schweizer hoà tan cellulose chứa ion [Cu(NH~3~)~4~]^2+^ (Bài 6). Trong cơ thể, phần "heme" của hemoglobin có một ion sắt nằm giữa một vòng hữu cơ lớn. Chất diệp lục cũng có cấu tạo tương tự, nhưng ở giữa là ion magnesium (SGK tr. 134). Bài này trả lời hai câu hỏi: phức chất **là gì**, và nó **được tạo thành như thế nào**.

## 1. Một số khái niệm cơ bản về phức chất

### 1.1. Nguyên tử trung tâm và phối tử

Hãy hình dung một phức chất như **một người đứng giữa, được nhiều người xung quanh nắm tay**. Người đứng giữa là **nguyên tử trung tâm**, những người xung quanh là **phối tử**.

- **Nguyên tử trung tâm** (kí hiệu **M**): thường là **cation kim loại** (Co^3+^, Cu^2+^, Zn^2+^…), đôi khi là **nguyên tử kim loại** trung hoà (Fe, Ni…).
- **Phối tử** (kí hiệu **L**): là **anion** (OH^−^, Cl^−^, F^−^, CN^−^…) hoặc **phân tử** (H~2~O, NH~3~, CO…). Điểm chung của chúng là đều có **cặp electron chưa liên kết** để "nắm" vào M (mục 3).

Khi viết công thức, ta đặt M và các phối tử trong **móc vuông**, M viết trước. Điện tích (nếu có) ghi ở góc trên bên phải, ngoài móc vuông.

| Phức chất | Nguyên tử trung tâm | Phối tử | Số phối tử | Điện tích |
|---|---|---|---|---|
| [Co(NH~3~)~6~]^3+^ | Co^3+^ | NH~3~ (phân tử) | 6 | +3 (cation) |
| [Zn(OH)~4~]^2−^ | Zn^2+^ | OH^−^ (anion) | 4 | −2 (anion) |
| [Fe(CO)~5~] | Fe (nguyên tử) | CO (phân tử) | 5 | 0 (trung hoà) |
| [PtCl~2~(NH~3~)~2~] | Pt^2+^ | Cl^−^ và NH~3~ | 4 | 0 (trung hoà) |

Ví dụ cuối cho thấy một phức chất có thể chứa **nhiều loại phối tử** khác nhau. Số phối tử là **tổng** số phối tử các loại: 2 Cl^−^ + 2 NH~3~ = 4.

> [!nen-tang] Đọc đúng chỉ số trong công thức phức
> Chỉ số **sau dấu ngoặc tròn** là số phối tử loại đó: (NH~3~)~6~ là 6 phân tử NH~3~. Chỉ số **bên trong** phối tử thuộc về chính phối tử: NH~3~ có 3 nguyên tử H, không phải 3 phối tử. Vì vậy [Zn(OH)~4~]^2−^ có 4 phối tử OH^−^, còn [Co(NH~3~)~6~]^3+^ có 6 phối tử NH~3~.

### 1.2. Điện tích của phức chất

Phức chất là một "khối" gồm M và các L. Vì vậy điện tích của cả khối bằng tổng điện tích các thành phần:

> [!ghi-nho] Công thức điện tích
> **q~phức~ = q~M~ + tổng điện tích các phối tử**

**Vì sao công thức này luôn đúng?** Khi phối tử cho cặp electron vào M, cặp electron đó chỉ được dùng chung chứ không chuyển hẳn sang M. Không có electron nào thêm vào hay mất đi khỏi cả khối, nên điện tích được bảo toàn.

Để dùng công thức, em cần thuộc điện tích của các phối tử hay gặp:

| Phối tử trung hoà (điện tích 0) | Phối tử mang điện tích −1 |
|---|---|
| H~2~O, NH~3~, CO | OH^−^, F^−^, Cl^−^, CN^−^ |

> [!vi-du] Ví dụ 1
> Cho các phức chất: [Mn(H~2~O)~6~]^2+^, [ZnCl~4~]^2−^, [Cr(CO)~6~]. Với mỗi phức chất, hãy chỉ ra nguyên tử trung tâm, phối tử, số phối tử và cho biết phức chất là cation, anion hay phân tử trung hoà.

> [!goi-y] Gợi ý 1
> Chữ đứng đầu trong móc vuông là nguyên tử trung tâm. Phần còn lại trong móc vuông là phối tử, chỉ số sau ngoặc (hoặc sau kí hiệu) là số phối tử.

> [!goi-y] Gợi ý 2
> Muốn biết M là ion hay nguyên tử, hãy tính: q~M~ = q~phức~ − tổng điện tích phối tử.

> [!loi-giai] Lời giải
> - [Mn(H~2~O)~6~]^2+^: phối tử là 6 phân tử H~2~O (điện tích 0), nên q~M~ = +2 − 0 = +2. Nguyên tử trung tâm là **Mn^2+^**. Phức là **cation**.
> - [ZnCl~4~]^2−^: phối tử là 4 ion Cl^−^, q~M~ = −2 − 4·(−1) = +2. Nguyên tử trung tâm là **Zn^2+^**. Phức là **anion**.
> - [Cr(CO)~6~]: phối tử là 6 phân tử CO, q~M~ = 0 − 0 = 0. Nguyên tử trung tâm là nguyên tử **Cr**. Phức là **phân tử trung hoà**.

> [!vi-du] Ví dụ 2
> a) Ion Fe^3+^ liên kết với 6 ion CN^−^. Viết công thức và tính điện tích của phức chất tạo thành.
>
> b) Xác định điện tích của nguyên tử trung tâm trong phức chất [CoCl(NH~3~)~5~]^2+^.

> [!goi-y] Gợi ý 1
> a) Cộng điện tích: một ion +3 và sáu ion −1.

> [!goi-y] Gợi ý 2
> b) Phức này có hai loại phối tử: 1 Cl^−^ và 5 NH~3~. Chỉ Cl^−^ mang điện tích.

> [!loi-giai] Lời giải
> a) q = +3 + 6·(−1) = −3. Phức chất là **[Fe(CN)~6~]^3−^**.
>
> b) +2 = q~Co~ + 1·(−1) + 5·0 → q~Co~ = **+3**. Nguyên tử trung tâm là Co^3+^.

> [!bay]
> - Viết điện tích của phức **ngoài** móc vuông: [Fe(CN)~6~]^3−^, không viết [Fe(CN)~6~^3−^].
> - Quên rằng phối tử là **anion** sẽ tính sai điện tích của M. Ví dụ [Zn(OH)~4~]^2−^ có Zn^2+^, không phải Zn^2−^ hay Zn.
> - Đừng đếm nhầm chỉ số trong phối tử thành số phối tử (xem khung nền tảng ở trên).

### 1.3. Cầu nội và cầu ngoại

Nhiều phức chất mang điện tích, nên trong hợp chất chúng phải đi kèm các ion trái dấu để trung hoà điện. SGK (mục Em có biết, tr. 135) gọi tên hai phần này:

- **Cầu nội**: phần trong móc vuông, gồm M và các phối tử. Đây là phần quyết định tính chất của phức chất.
- **Cầu ngoại**: các ion nằm ngoài móc vuông, có nhiệm vụ trung hoà điện tích của cầu nội.

![Hình 1. Các phần của phức chất [Co(NH₃)₆]Cl₃: nguyên tử trung tâm, phối tử, cầu nội, cầu ngoại](cau-tao.svg)

Khi tan trong nước, liên kết giữa cầu nội và cầu ngoại là liên kết ion nên bị tách ra, giống như một muối tan thông thường. **Cầu nội thì giữ nguyên** thành một ion phức:

=> [Ag(NH~3~)~2~]OH → [Ag(NH~3~)~2~]^+^ + OH^−^

=> [Co(NH~3~)~6~]Cl~3~ → [Co(NH~3~)~6~]^3+^ + 3Cl^−^

Trong thuốc thử Tollens, chính cation cầu nội [Ag(NH~3~)~2~]^+^ là phần tham gia phản ứng tráng bạc với aldehyde.

> [!em-co-biet] Cl^−^ trong và ngoài móc vuông khác nhau thế nào? (mở rộng, ngoài SGK)
> Ion Cl^−^ ở cầu ngoại tự do trong dung dịch, nên tạo kết tủa AgCl ngay khi gặp AgNO~3~. Ion Cl^−^ là phối tử trong cầu nội thì đang liên kết với M, nên **không** kết tủa ngay. Ví dụ, 1 mol [CoCl(NH~3~)~5~]Cl~2~ tác dụng với AgNO~3~ dư chỉ cho **2 mol** AgCl, dù phân tử có 3 nguyên tử Cl. Cuối thế kỉ XIX, nhà hoá học Alfred Werner đã dùng kiểu thí nghiệm này để tìm ra cấu tạo của phức chất. Một số đề luyện thi khai thác ý này ở mức vận dụng (Dạng 3).

> [!vi-du] Ví dụ 3
> Cho phức chất K~2~[PtCl~4~].
>
> a) Chỉ ra cầu nội, cầu ngoại, nguyên tử trung tâm và phối tử.
>
> b) Viết phương trình phân li trong nước. Hoà tan 0,1 mol chất này thì thu được tổng cộng bao nhiêu mol ion?

> [!goi-y] Gợi ý 1
> Phần trong móc vuông là cầu nội. Hai ion K^+^ nằm ngoài, mỗi ion +1, nên cầu nội phải có điện tích −2.

> [!goi-y] Gợi ý 2
> Khi phân li, chỉ tách cầu ngoại ra khỏi cầu nội. Cầu nội vẫn là **một** ion.

> [!loi-giai] Lời giải
> a) Cầu nội là [PtCl~4~]^2−^, cầu ngoại là 2 ion K^+^. Phối tử là 4 ion Cl^−^. Điện tích của Pt: −2 − 4·(−1) = +2, nên nguyên tử trung tâm là **Pt^2+^**.
>
> b) K~2~[PtCl~4~] → 2K^+^ + [PtCl~4~]^2−^. Mỗi mol chất cho 3 mol ion, nên 0,1 mol cho **0,3 mol ion**.

## 2. Một số dạng hình học của phức chất

Các phối tử không xếp lộn xộn quanh M. Chúng nằm ở những vị trí **xác định** trong không gian, tạo thành một "khung" hình học. SGK nêu ba dạng phổ biến (Bảng 28.1, tr. 135):

![Hình 2. Ba dạng hình học phổ biến của phức chất [MLₙ]. Nét đứt nối các phối tử chỉ để thấy rõ hình khối](hinh-hoc.svg)

| Dạng hình học | Số phối tử | Đặc điểm | Ví dụ |
|---|---|---|---|
| **Tứ diện** | 4 | M ở tâm, 4 L ở 4 đỉnh của một tứ diện đều (như phân tử CH~4~) | [Zn(OH)~4~]^2−^, [Ni(CO)~4~] |
| **Vuông phẳng** | 4 | M và 4 L cùng nằm trên **một mặt phẳng**, 4 L ở 4 đỉnh hình vuông, M ở tâm | [PtCl~4~]^2−^, [PtCl~2~(NH~3~)~2~] |
| **Bát diện** | 6 | 4 L ở 4 đỉnh hình vuông quanh M, 2 L còn lại ở phía trên và phía dưới M | [Co(NH~3~)~6~]^3+^, [Fe(H~2~O)~6~]^2+^ |

**Vì sao gọi là "bát diện"?** Nối 6 phối tử với nhau, em được một khối có **8 mặt** tam giác đều, giống hai kim tự tháp đáy vuông úp vào nhau. "Bát" nghĩa là tám.

**Cách nhận ra dạng hình học từ công thức:**

1. Đếm số phối tử.
2. Có **6** phối tử thì đó là **bát diện**.
3. Có **4** phối tử thì có hai khả năng: tứ diện hoặc vuông phẳng. Chỉ đếm số phối tử thì **chưa đủ** để chọn. Đề bài phải cho thêm thông tin, chẳng hạn "các phối tử cùng nằm trên một mặt phẳng với M" (vuông phẳng) hoặc "các phối tử ở 4 đỉnh của một tứ diện" (tứ diện).

> [!nen-tang] Hình tứ diện (lớp 10)
> Phân tử CH~4~ có nguyên tử C ở tâm, 4 nguyên tử H ở 4 đỉnh của một tứ diện đều, góc liên kết khoảng 109,5°. Phức tứ diện có hình dạng giống vậy, chỉ thay C bằng M và H bằng L. Còn ở dạng vuông phẳng, góc L–M–L giữa hai phối tử cạnh nhau là 90°.

> [!vi-du] Ví dụ 4
> Cho các phức chất: [Ni(H~2~O)~6~]^2+^, [CoF~6~]^3−^, [ZnCl~4~]^2−^ (các phối tử ở 4 đỉnh của một tứ diện), [Ni(CN)~4~]^2−^ (ion Ni^2+^ và 4 nguyên tử C của phối tử cùng nằm trên một mặt phẳng). Xác định dạng hình học của mỗi phức chất.

> [!goi-y] Gợi ý 1
> Đếm số phối tử trước. Phức nào có 6 phối tử?

> [!goi-y] Gợi ý 2
> Hai phức 4 phối tử: dựa vào thông tin trong ngoặc. "Cùng một mặt phẳng" là dấu hiệu của dạng nào?

> [!loi-giai] Lời giải
> - [Ni(H~2~O)~6~]^2+^ và [CoF~6~]^3−^ có 6 phối tử: dạng **bát diện**.
> - [ZnCl~4~]^2−^ có 4 phối tử ở 4 đỉnh tứ diện: dạng **tứ diện**.
> - [Ni(CN)~4~]^2−^ có 4 phối tử cùng mặt phẳng với M: dạng **vuông phẳng**.

> [!em-co-biet] Thuốc chữa ung thư cisplatin (mở rộng)
> Phức chất [PtCl~2~(NH~3~)~2~] dạng vuông phẳng có hai cách sắp xếp. Khi 2 phối tử Cl^−^ nằm **cạnh nhau** (cùng một cạnh hình vuông), ta có **cisplatin**, một thuốc điều trị ung thư. Cisplatin gắn vào DNA của tế bào ung thư và ngăn tế bào phân chia. Khi 2 phối tử Cl^−^ nằm **đối diện** nhau qua M, chất này hầu như không có tác dụng chữa bệnh. Cùng công thức, chỉ khác sắp xếp không gian, mà tác dụng đã khác hẳn. Đây là lí do hình học của phức chất quan trọng (SGK tr. 134 có nhắc tới vai trò của phức chất trong điều trị ung thư).

> [!bay]
> - "Phức có 4 phối tử thì luôn là tứ diện": **sai**. Có thể là tứ diện hoặc vuông phẳng.
> - Phức vuông phẳng có **4** phối tử, không phải 6 (đừng nhầm với "bát diện có mặt phẳng vuông ở giữa").
> - Phức có 2 hoặc 5 phối tử (như [Ag(NH~3~)~2~]^+^, [Fe(CO)~5~]) **không** thuộc ba dạng trên.

## 3. Liên kết trong phức chất

### 3.1. Liên kết giữa nguyên tử trung tâm và phối tử

> [!nen-tang] Liên kết cho – nhận (lớp 10)
> Liên kết cộng hoá trị thông thường: mỗi nguyên tử góp 1 electron vào cặp dùng chung. Liên kết **cho – nhận**: cặp electron dùng chung do **một** nguyên tử đóng góp. Ví dụ: NH~3~ + H^+^ → NH~4~^+^. Nguyên tử N của NH~3~ có một cặp electron chưa liên kết. Ion H^+^ có AO 1s trống. N "cho" cặp electron, H^+^ "nhận". Kí hiệu bằng mũi tên từ nguyên tử cho đến nguyên tử nhận: H~3~N→H^+^.

Liên kết giữa M và L trong phức chất chính là **liên kết cho – nhận**:

- **Phối tử cho**: phối tử có **cặp electron chưa liên kết** và đưa cặp electron đó ra dùng chung.
- **Nguyên tử trung tâm nhận**: M có **AO trống** để chứa cặp electron đó.

![Hình 3. Phối tử NH₃ cho cặp electron chưa liên kết vào AO trống của Co³⁺; sáu liên kết như vậy tạo thành [Co(NH₃)₆]³⁺](cho-nhan.svg)

Ví dụ:

- Trong [Co(NH~3~)~6~]^3+^, mỗi phân tử NH~3~ cho cặp electron chưa liên kết của nguyên tử **N** vào một AO trống của Co^3+^. Có 6 phối tử nên có **6 liên kết cho – nhận**.
- Trong [Zn(OH)~4~]^2−^, mỗi ion OH^−^ cho một cặp electron chưa liên kết của nguyên tử **O** vào AO trống của Zn^2+^. Có **4 liên kết cho – nhận**.

**Nguyên tử nào của phối tử đứng ra "cho"?** Là nguyên tử mang cặp electron chưa liên kết và hướng về M:

| Phối tử | NH~3~ | H~2~O | OH^−^ | CO | CN^−^ | F^−^, Cl^−^ |
|---|---|---|---|---|---|---|
| Nguyên tử cho cặp electron | N | O | O | C | C | F, Cl |

**Vì sao CH~4~ không làm phối tử được?** Nguyên tử C trong CH~4~ đã dùng cả 4 electron hoá trị để liên kết với 4 nguyên tử H, nên **không còn cặp electron chưa liên kết** nào để cho. Đây chính là điều kiện để một phân tử hay ion trở thành phối tử.

**Vì sao ion kim loại chuyển tiếp dễ tạo phức?** (mở rộng) Ion kim loại chuyển tiếp còn nhiều AO trống ở các phân lớp 3d, 4s, 4p. Chúng lại mang điện tích dương và có bán kính nhỏ, nên hút mạnh các cặp electron của phối tử. Đây là lí do Bài 27 nói kim loại chuyển tiếp tạo ra nhiều hợp chất có màu sắc phong phú: rất nhiều trong số đó là phức chất.

> [!meo] Đếm nhanh
> Với các phối tử trong SGK (mỗi phối tử chỉ cho **một** cặp electron):
> - số liên kết cho – nhận = số phối tử;
> - số electron M nhận được = 2 × số phối tử.

> [!vi-du] Ví dụ 5
> Mô tả sự hình thành liên kết trong ion phức [Zn(NH~3~)~4~]^2+^. Ion Zn^2+^ đã nhận tổng cộng bao nhiêu electron từ các phối tử?

> [!goi-y] Gợi ý 1
> Bên nào có cặp electron chưa liên kết, bên nào có AO trống?

> [!goi-y] Gợi ý 2
> Mỗi phối tử NH~3~ cho 1 cặp electron, tức 2 electron.

> [!loi-giai] Lời giải
> Nguyên tử trung tâm là Zn^2+^, có các AO trống. Mỗi phân tử NH~3~ có một cặp electron chưa liên kết ở nguyên tử N. Bốn phân tử NH~3~ lần lượt cho cặp electron này vào 4 AO trống của Zn^2+^, tạo thành **4 liên kết cho – nhận** H~3~N→Zn.
>
> Zn^2+^ nhận 4 cặp electron, tức **8 electron**.
>
> (Điện tích của phức vẫn là +2, vì các phối tử NH~3~ trung hoà và electron chỉ được dùng chung.)

> [!bay]
> - Chiều cho – nhận: **phối tử cho, M nhận**. Viết ngược "Zn^2+^ cho electron cho NH~3~" là sai.
> - Liên kết M – L **không phải** liên kết ion, dù M là cation và L có thể là anion.
> - Trong NH~3~, nguyên tử cho là **N**, không phải H (H không có cặp electron chưa liên kết).

### 3.2. Sự hình thành phức chất aqua của một số ion kim loại chuyển tiếp

**Quan sát** (SGK tr. 136, Hình 28.2 và 28.3): muối CuSO~4~ khan là chất bột **màu trắng**. Khi hoà tan vào nước, ta được dung dịch **màu xanh**.

**Giải thích:** khi tan, ion Cu^2+^ được các phân tử nước bao quanh. Nguyên tử O của H~2~O có cặp electron chưa liên kết. Sáu phân tử H~2~O cho cặp electron này vào AO trống của Cu^2+^, tạo thành ion phức **[Cu(H~2~O)~6~]^2+^**. Màu xanh của dung dịch là màu của ion phức này.

=> Cu^2+^ + 6H~2~O → [Cu(H~2~O)~6~]^2+^

![Hình 4. CuSO₄ khan màu trắng tan vào nước cho dung dịch màu xanh, vì ion Cu²⁺ nhận cặp electron của 6 phân tử H₂O, tạo phức aqua bát diện [Cu(H₂O)₆]²⁺](aqua.svg)

Phức chất có phối tử là H~2~O được gọi là **phức chất aqua** ("aqua" là tiếng Latin, nghĩa là nước). Đây là hiện tượng **chung** của các ion kim loại chuyển tiếp trong dung dịch nước:

- Ion M^n+^ nhận cặp electron chưa liên kết của H~2~O, tạo liên kết cộng hoá trị kiểu cho – nhận.
- Hầu hết phức chất aqua có dạng **bát diện**, công thức chung **[M(H~2~O)~6~]^n+^**.
- Ví dụ: Fe^2+^ tạo [Fe(H~2~O)~6~]^2+^, Co^3+^ tạo [Co(H~2~O)~6~]^3+^, Fe^3+^ tạo [Fe(H~2~O)~6~]^3+^.

**Vì sao điện tích phức aqua bằng điện tích của ion kim loại?** Phối tử H~2~O trung hoà điện, nên q = n + 6·0 = n.

**Điều này có ý nghĩa gì khi làm bài?** Từ trước đến nay, em vẫn viết "Cu^2+^", "Fe^3+^" trong dung dịch. Thật ra trong nước, các ion này tồn tại ở dạng phức aqua. Viết Cu^2+^ chỉ là cách viết gọn. Ở Bài 29, em sẽ thấy các phân tử H~2~O trong phức aqua có thể bị **thay thế** bởi phối tử khác (NH~3~, Cl^−^, OH^−^…), kèm theo đổi màu hoặc tạo kết tủa.

> [!ung-dung] Dùng muối copper(II) sulfate khan để phát hiện nước
> Vì CuSO~4~ khan màu trắng chuyển sang màu xanh khi gặp nước, người ta dùng nó để **phát hiện vết nước** trong các chất lỏng hữu cơ (ethanol, xăng, dầu) hoặc kiểm tra sản phẩm có chứa hơi nước trong thí nghiệm phân tích nguyên tố của hợp chất hữu cơ (lớp 11).

> [!vi-du] Ví dụ 6
> Phức chất aqua của Ni^2+^ và của Cr^3+^ đều có dạng bát diện.
>
> a) Viết công thức của mỗi phức chất aqua.
>
> b) Trong mỗi phức, có bao nhiêu liên kết cho – nhận? Nguyên tử nào của phối tử cho cặp electron?

> [!goi-y] Gợi ý 1
> Bát diện thì có mấy phối tử? Phối tử H~2~O có điện tích bao nhiêu?

> [!goi-y] Gợi ý 2
> Số liên kết cho – nhận bằng số phối tử.

> [!loi-giai] Lời giải
> a) Bát diện có 6 phối tử H~2~O (trung hoà), nên điện tích phức bằng điện tích ion kim loại: **[Ni(H~2~O)~6~]^2+^** và **[Cr(H~2~O)~6~]^3+^**.
>
> b) Mỗi phức có **6 liên kết cho – nhận**. Nguyên tử **O** của mỗi phân tử H~2~O cho một cặp electron chưa liên kết vào AO trống của Ni^2+^ (hoặc Cr^3+^).

> [!bay]
> - Phức aqua có 6 phối tử H~2~O nhưng **điện tích vẫn bằng điện tích ion kim loại**, không cộng thêm gì.
> - Màu xanh của dung dịch CuSO~4~ là màu của **[Cu(H~2~O)~6~]^2+^**, không phải của ion SO~4~^2−^ hay của muối khan.

## Dạng bài thi hay gặp

### Dạng 1. Xác định thành phần và điện tích của phức chất

**Nhận biết:** đề cho công thức phức chất, hỏi nguyên tử trung tâm, phối tử, số phối tử, điện tích của phức hoặc của M. Hay gặp ở câu 4 lựa chọn, câu Đúng/Sai và câu trả lời ngắn (đáp số là một số).

**Phương pháp:**

1. Tách cầu ngoại (nếu có) ra khỏi móc vuông. Điện tích cầu nội = −(tổng điện tích cầu ngoại).
2. Trong móc vuông: chữ đầu là M, phần còn lại là phối tử. Đếm số phối tử từng loại.
3. Dùng q~phức~ = q~M~ + tổng điện tích phối tử để tìm đại lượng chưa biết.

> [!vi-du] Ví dụ 7
> Cho phức chất Na~3~[CoF~6~]. Xét các phát biểu sau:
>
> a) Cầu nội là [CoF~6~]^3−^.
>
> b) Nguyên tử trung tâm là Co^3−^.
>
> c) Phức chất có 6 liên kết cho – nhận, mỗi liên kết do ion F^−^ cho cặp electron.
>
> d) Hoà tan 0,2 mol Na~3~[CoF~6~] vào nước thu được tổng cộng 2,0 mol ion.

> [!goi-y] Gợi ý 1
> Ba ion Na^+^ ở cầu ngoại có tổng điện tích +3, vậy cầu nội có điện tích bao nhiêu?

> [!goi-y] Gợi ý 2
> Khi phân li, cầu nội [CoF~6~]^3−^ là **một** ion, không vỡ ra thành Co và F.

> [!loi-giai] Lời giải
> a) **Đúng**: cầu ngoại 3Na^+^ (+3) nên cầu nội mang điện tích −3.
>
> b) **Sai**: q~Co~ = −3 − 6·(−1) = +3. Nguyên tử trung tâm là Co^3+^.
>
> c) **Đúng**: 6 phối tử F^−^, mỗi phối tử cho một cặp electron vào AO trống của Co^3+^.
>
> d) **Sai**: Na~3~[CoF~6~] → 3Na^+^ + [CoF~6~]^3−^, mỗi mol cho 4 mol ion. Vậy 0,2 mol cho 0,8 mol ion. Con số 2,0 mol là do tách nhầm cả cầu nội thành Co^3+^ + 6F^−^ (10 ion mỗi mol).

> [!bay]
> - Quên dấu khi phối tử là anion.
> - Coi cầu nội phân li thành từng phối tử khi tính số mol ion.

### Dạng 2. Dạng hình học và liên kết cho – nhận

**Nhận biết:** đề cho dãy phức chất, hỏi số phức có dạng bát diện/tứ diện/vuông phẳng; hoặc hỏi số liên kết cho – nhận, số electron M nhận; hoặc cho câu Đúng/Sai về phức aqua.

**Phương pháp:**

1. Đếm số phối tử: 6 → bát diện; 4 → tứ diện hoặc vuông phẳng (đọc thêm dữ kiện của đề).
2. Phức aqua của ion kim loại chuyển tiếp: mặc định **[M(H~2~O)~6~]^n+^, bát diện**.
3. Số liên kết cho – nhận = số phối tử; số electron nhận = 2 × số phối tử.

> [!vi-du] Ví dụ 8
> Cho dãy các phức chất: [Mn(H~2~O)~6~]^2+^, [Ni(CO)~4~] (tứ diện), [Fe(CN)~6~]^4−^, [PtCl~4~]^2−^ (vuông phẳng), [Cr(NH~3~)~6~]^3+^, [Ag(NH~3~)~2~]^+^. Có bao nhiêu phức chất có dạng hình học bát diện? Tính tổng số liên kết cho – nhận trong một đơn vị của mỗi phức bát diện đó.

> [!goi-y] Gợi ý 1
> Chỉ cần đếm phức nào có đúng 6 phối tử.

> [!goi-y] Gợi ý 2
> [Ag(NH~3~)~2~]^+^ có 2 phối tử, không thuộc ba dạng trong bài.

> [!loi-giai] Lời giải
> Các phức có 6 phối tử: [Mn(H~2~O)~6~]^2+^, [Fe(CN)~6~]^4−^, [Cr(NH~3~)~6~]^3+^. Vậy có **3** phức bát diện.
>
> Mỗi phức bát diện có **6** liên kết cho – nhận.

> [!bay]
> Không thấy chữ "tứ diện" hay "vuông phẳng" trong đề thì đừng tự đoán dạng của phức 4 phối tử. Đề luôn phải cho dữ kiện để phân biệt hai dạng này.

### Dạng 3. Cầu nội – cầu ngoại và phản ứng với AgNO~3~ (vận dụng cao)

**Nhận biết:** đề cho công thức dạng "MCl~x~·yNH~3~" hoặc "MCl~x~·yH~2~O" và lượng kết tủa AgCl khi cho AgNO~3~ dư vào. Đề hỏi công thức phức, số Cl^−^ trong cầu nội, hoặc số ion khi phân li. Dạng này mở rộng từ mục Em có biết (SGK tr. 135).

**Phương pháp:**

1. n(AgCl) : n(phức) = số Cl^−^ ở **cầu ngoại** (chỉ Cl^−^ tự do mới kết tủa ngay).
2. Số Cl^−^ trong cầu nội = tổng số Cl − số Cl^−^ cầu ngoại.
3. Lắp cầu nội sao cho đủ số phối tử của dạng hình học đề cho (thường là 6, bát diện). Phân tử H~2~O hay NH~3~ còn thừa thì nằm ngoài móc vuông.
4. Kiểm tra: điện tích cầu nội = số Cl^−^ cầu ngoại.

> [!vi-du] Ví dụ 9
> Muối chromium(III) chloride ngậm nước CrCl~3~·6H~2~O tồn tại ở vài dạng có màu khác nhau, trong đó Cr^3+^ luôn tạo phức bát diện. Hoà tan 0,02 mol một dạng màu lục vào nước rồi thêm AgNO~3~ dư, thu được 5,74 g kết tủa AgCl. Xác định công thức phức chất của dạng này.

> [!goi-y] Gợi ý 1
> M(AgCl) = 108 + 35,5 = 143,5. Tính n(AgCl) rồi so với n(phức).

> [!goi-y] Gợi ý 2
> Bát diện cần đúng 6 phối tử. Nếu có x ion Cl^−^ trong cầu nội thì cần thêm (6 − x) phân tử H~2~O làm phối tử.

> [!loi-giai] Lời giải
> n(AgCl) = 5,74 : 143,5 = 0,04 mol. Tỉ lệ 0,04 : 0,02 = 2, nên mỗi đơn vị có **2 Cl^−^ ở cầu ngoại**.
>
> Cl trong cầu nội: 3 − 2 = 1. Cầu nội cần 6 phối tử: 1 Cl^−^ + 5 H~2~O. Phân tử H~2~O còn lại (6 − 5 = 1) nằm ngoài móc vuông.
>
> Công thức: **[CrCl(H~2~O)~5~]Cl~2~·H~2~O**.
>
> Kiểm tra: điện tích cầu nội = +3 + 1·(−1) = +2, đúng bằng 2 Cl^−^ ở cầu ngoại. ✓

> [!bay]
> - Lấy **tổng** số Cl để tính AgCl là sai: Cl^−^ đã làm phối tử không kết tủa ngay.
> - Phân tử nước "thừa" (nước kết tinh) không phải phối tử, không tính vào số phối tử.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Phức chất | Nguyên tử trung tâm M (cation hoặc nguyên tử kim loại) + các phối tử L (anion hoặc phân tử có cặp electron chưa liên kết) |
| Công thức | [M L~n~]: M và L trong móc vuông; điện tích ghi ngoài móc |
| Điện tích | q~phức~ = q~M~ + tổng điện tích phối tử; H~2~O, NH~3~, CO: 0; OH^−^, F^−^, Cl^−^, CN^−^: −1 |
| Cầu nội – cầu ngoại | Cầu nội = phần trong móc vuông, quyết định tính chất; cầu ngoại trung hoà điện, tách ra khi tan |
| Hình học | Tứ diện: 4 L; vuông phẳng: 4 L (cùng mặt phẳng với M); bát diện: 6 L |
| Liên kết M – L | Cho – nhận: L cho cặp electron chưa liên kết → AO trống của M; số liên kết = số phối tử |
| Phức aqua | M^n+^ + 6H~2~O → [M(H~2~O)~6~]^n+^, hầu hết bát diện; CuSO~4~ khan trắng → dung dịch xanh [Cu(H~2~O)~6~]^2+^ |

**Sơ đồ suy luận khi gặp một phức chất:**

1. Tách cầu ngoại → biết điện tích cầu nội.
2. Đọc M và các phối tử → số phối tử → dạng hình học (6: bát diện; 4: tứ diện hoặc vuông phẳng).
3. q~M~ = q~phức~ − tổng điện tích phối tử.
4. Số liên kết cho – nhận = số phối tử; M nhận 2 × số phối tử electron.
