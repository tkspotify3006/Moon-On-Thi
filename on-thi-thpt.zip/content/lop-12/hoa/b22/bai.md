---
title: Sự ăn mòn kim loại
thoi-gian: 40 phút
muc-tieu:
  - Nêu được khái niệm ăn mòn kim loại từ những biến đổi quen thuộc của kim loại, hợp kim trong tự nhiên (thép gỉ, đồng xanh).
  - Phân biệt được ăn mòn hoá học và ăn mòn điện hoá; nêu đủ ba điều kiện của ăn mòn điện hoá, viết được quá trình ở anode và cathode khi gang, thép gỉ trong không khí ẩm.
  - Trình bày được hai phương pháp chống ăn mòn trong SGK là phương pháp điện hoá (kim loại hi sinh) và phương pháp phủ bề mặt, giải thích được vì sao mỗi cách bảo vệ được kim loại.
  - Mô tả và giải thích được thí nghiệm ăn mòn đinh sắt và thí nghiệm bảo vệ đinh sắt bằng dây kẽm.
  - Làm được các dạng bài thi: đếm số trường hợp ăn mòn điện hoá, xác định kim loại bị ăn mòn trước, giải thích hiện tượng thực tế (sắt tây, tôn, vỏ tàu), bài toán Zn + H~2~SO~4~ có thêm CuSO~4~.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Ăn mòn kim loại** là sự phá huỷ kim loại, hợp kim do các chất trong môi trường, trong đó **kim loại bị oxi hoá**: M → M^n+^ + ne.
> 2. **Ăn mòn hoá học**: kim loại nhường electron **trực tiếp** cho chất oxi hoá (O~2~, Cl~2~… thường ở nhiệt độ cao), **không** phát sinh dòng điện.
> 3. **Ăn mòn điện hoá** = một **pin điện** tự hình thành. Cần đủ 3 điều kiện: **hai điện cực khác nhau** (2 kim loại, hoặc kim loại – phi kim như Fe – C); **tiếp xúc** với nhau (trực tiếp hoặc qua dây dẫn); **cùng nhúng** trong một dung dịch chất điện li.
> 4. Trong cặp điện cực, kim loại **có tính khử mạnh hơn** (E° nhỏ hơn) là **anode (cực âm), bị ăn mòn**. Cathode không bị ăn mòn, ở đó O~2~ hoặc H^+^ bị khử.
> 5. Chống ăn mòn: **phương pháp điện hoá** (gắn kim loại hoạt động mạnh hơn làm "vật hi sinh", ví dụ Zn trên vỏ tàu) và **phương pháp phủ bề mặt** (sơn, dầu mỡ, mạ, tráng Sn → sắt tây, tráng Zn → tôn).

## 1. Ăn mòn kim loại

### 1.1. Khái niệm

Em đã gặp rất nhiều lần: chiếc ống thép, cánh cổng sắt để ngoài trời lâu ngày bị phủ một lớp **gỉ nâu đỏ**, bong ra từng mảng. Những đồ vật bằng đồng như chuông, tượng lâu năm thì phủ một lớp **gỉ màu xanh**. Kim loại sáng bóng ban đầu đã biến thành hợp chất (oxide, hydroxide, muối…), tức là bị "ăn" dần (SGK tr. 102, Hình 22.1).

Trong các hợp chất đó, kim loại ở dạng **ion dương**. Muốn từ nguyên tử trung hoà M trở thành ion M^n+^, kim loại phải **nhường electron**:

=> M → M^n+^ + ne

**Ăn mòn kim loại** là sự phá huỷ kim loại hoặc hợp kim dưới tác dụng của các chất trong môi trường, trong đó **kim loại bị oxi hoá** thành ion dương.

> [!nen-tang] Oxi hoá – khử (lớp 10) và tính khử của kim loại (Bài 15)
> - Chất **nhường** electron là chất khử, quá trình nhường electron là **sự oxi hoá**. Chất **nhận** electron là chất oxi hoá, quá trình nhận electron là **sự khử**.
> - Kim loại có E°(M^n+^/M) càng nhỏ thì tính khử càng mạnh, càng dễ bị oxi hoá, tức là càng dễ bị ăn mòn. Vàng, platinum có E° rất lớn nên gần như không bị ăn mòn.

Chất "lấy" electron của kim loại chính là các **chất oxi hoá** có sẵn trong môi trường: khí O~2~ trong không khí, O~2~ hoà tan trong nước, ion H^+^ trong mưa acid, khí Cl~2~, SO~2~… Tuỳ theo **cách** mà electron đi từ kim loại sang chất oxi hoá, người ta chia ăn mòn thành hai loại: **ăn mòn hoá học** và **ăn mòn điện hoá**.

### 1.2. Ăn mòn hoá học

**Ăn mòn hoá học** xảy ra khi kim loại **phản ứng oxi hoá – khử trực tiếp** với chất oxi hoá trong môi trường. Electron đi thẳng từ nguyên tử kim loại sang chất oxi hoá **ngay tại chỗ chúng chạm nhau**. Không có dòng electron chạy qua một mạch nào, nên **không phát sinh dòng điện**.

Ví dụ: các bộ phận bằng sắt của lò đốt tiếp xúc với không khí nóng bị oxi hoá thành oxide sắt từ (SGK tr. 103):

=> 3Fe + 2O~2~ → Fe~3~O~4~    (t°)

Ví dụ khác: thiết bị bằng sắt tiếp xúc với khí chlorine ở nhiệt độ cao (2Fe + 3Cl~2~ → 2FeCl~3~). Ăn mòn hoá học hay gặp ở nơi **nhiệt độ cao**, **không có nước** (lò đốt, động cơ, ống xả, máy móc tiếp xúc với khí nóng).

> [!vi-du] Ví dụ 1
> Một tấm chắn bằng sắt đặt trong lò đốt bị oxi hoá bề mặt thành Fe~3~O~4~. Sau một thời gian, khối lượng tấm chắn **tăng** 2,56 g. Tính khối lượng sắt đã bị ăn mòn. Giả sử lớp oxide vẫn bám trên tấm chắn.

> [!goi-y] Gợi ý 1
> Lớp oxide bám lại trên tấm sắt. Vậy phần khối lượng tăng thêm chính là khối lượng của nguyên tố nào?

> [!goi-y] Gợi ý 2
> Khối lượng tăng = khối lượng O đã kết hợp. Trong Fe~3~O~4~, tỉ lệ số mol Fe : O = 3 : 4.

> [!loi-giai] Lời giải
> Khối lượng tăng chính là khối lượng oxygen: n(O) = 2,56 : 16 = 0,16 mol.
>
> Trong Fe~3~O~4~: n(Fe) = 0,16 · 3 : 4 = 0,12 mol.
>
> Khối lượng sắt bị ăn mòn: m(Fe) = 0,12 · 56 = **6,72 g**.

### 1.3. Ăn mòn điện hoá

**a) Thí nghiệm ăn mòn đinh sắt**

Tóm tắt thí nghiệm (SGK tr. 103): cho một chiếc đinh sắt mới vào ống nghiệm, thêm khoảng 3 mL nước rồi để ngoài không khí vài ngày. Kết quả là đinh sắt xuất hiện **gỉ màu nâu đỏ**, gỉ lắng cả xuống đáy ống nghiệm.

Sắt khô trong không khí khô gỉ rất chậm, nhưng có **nước** là gỉ nhanh hơn nhiều. Vì sao? Đinh sắt **không phải sắt nguyên chất** mà là hợp kim của sắt với carbon (Bài 21). Nước có hoà tan O~2~, CO~2~ là **dung dịch chất điện li**. Sắt và carbon **khác nhau**, **chạm nhau**, lại **cùng nhúng** trong dung dịch chất điện li: đó là một **pin điện hoá** giống pin Zn – Cu ở Bài 15, chỉ có điều rất nhỏ và **bị đoản mạch**. Năng lượng của pin không thắp đèn nào, mà chỉ dùng để "ăn" sắt.

> [!ghi-nho] Định nghĩa
> **Ăn mòn điện hoá** là sự ăn mòn kim loại xảy ra khi **có sự tạo thành pin điện**. Kim loại đóng vai **anode** bị oxi hoá, electron đi qua chỗ tiếp xúc sang **cathode**, tại đó chất oxi hoá trong dung dịch bị khử.

**b) Cơ chế gỉ của gang, thép trong không khí ẩm**

Trong không khí ẩm, bề mặt gang, thép luôn có một **lớp nước rất mỏng** (hơi nước ngưng tụ, sương). Lớp nước này hoà tan O~2~ và CO~2~ nên trở thành dung dịch chất điện li. Sắt và carbon trong gang cùng tiếp xúc với dung dịch đó, tạo nên **vô số pin điện hoá rất nhỏ**, trong đó **Fe là anode**, **C là cathode** (SGK tr. 103, Hình 22.3).

![Hình 1. Ăn mòn điện hoá gang dưới một giọt nước: Fe (anode, cực âm) tan thành Fe²⁺; electron đi trong lòng kim loại sang hạt C (cathode, cực dương); ở cathode, O₂ hoà tan bị khử thành OH⁻; Fe²⁺ gặp OH⁻ rồi bị O₂ oxi hoá tiếp thành gỉ](giot-nuoc.svg)

- **Ở anode (Fe, cực âm)** xảy ra **sự oxi hoá**. Sắt tan vào lớp nước dưới dạng ion:

=> Fe → Fe^2+^ + 2e

- **Electron** do Fe nhường **đi trong lòng kim loại** sang hạt carbon (chỗ tiếp xúc giữa Fe và C đóng vai "dây dẫn").
- **Ở cathode (C, cực dương)** xảy ra **sự khử**. Oxygen hoà tan nhận electron:

=> O~2~ + 2H~2~O + 4e → 4OH^−^

(SGK viết với hệ số một nửa: ½O~2~ + H~2~O + 2e → 2OH^−^. Hai cách viết là một.)

- **Tạo gỉ**: ion Fe^2+^ tiếp tục bị oxygen không khí oxi hoá, tạo thành **gỉ sắt**, thành phần chính là **Fe~2~O~3~·nH~2~O** (màu nâu đỏ).

> [!em-co-biet] Từ Fe^2+^ đến gỉ sắt (mở rộng, ngoài SGK)
> Fe^2+^ gặp ion OH^−^ trong lớp nước, tạo Fe(OH)~2~. Chất này bị O~2~ oxi hoá thành Fe(OH)~3~, rồi mất bớt nước thành Fe~2~O~3~·nH~2~O:
>
> => Fe^2+^ + 2OH^−^ → Fe(OH)~2~
>
> => 4Fe(OH)~2~ + O~2~ + 2H~2~O → 4Fe(OH)~3~
>
> Lớp gỉ này **xốp, dễ bong**, không bám chặt như lớp oxide của nhôm. Vì thế nó không che được sắt bên dưới, và sắt cứ gỉ dần vào sâu bên trong.

**Vì sao Fe bị ăn mòn mà không phải C?** Điện cực **dễ nhường electron hơn** là anode. Fe có tính khử, còn C gần như không nhường electron trong điều kiện này. Carbon chỉ là "chỗ để" O~2~ nhận electron.

> [!bay]
> - Ở cathode, chất bị khử là **chất oxi hoá trong dung dịch** (O~2~, H^+^, Cu^2+^…), **không phải** kim loại làm cathode. Viết "Cu bị khử" hay "C bị khử" là sai.
> - Anode trong ăn mòn điện hoá là **cực âm** (giống pin, Bài 15), chứ không phải cực dương như trong điện phân.
> - Electron đi qua **chỗ tiếp xúc giữa hai điện cực** (trong lòng kim loại), không đi qua dung dịch. Trong dung dịch chỉ có **ion** di chuyển.

**c) Điều kiện của ăn mòn điện hoá**

Ăn mòn điện hoá chỉ xảy ra khi có **đủ cả ba** điều kiện sau (SGK tr. 103). Thiếu một điều kiện là không có pin, nên không có ăn mòn điện hoá.

| Điều kiện | Ý nghĩa ("vì sao cần") | Ví dụ đủ | Ví dụ thiếu |
|---|---|---|---|
| 1. Có **hai điện cực khác nhau**: hai kim loại khác nhau, hoặc kim loại và phi kim (C) | Phải có một cực "đẩy" electron mạnh hơn cực kia thì mới có dòng electron | Fe – Cu, Zn – Cu, Fe – C (gang, thép) | Một thanh Zn **tinh khiết** nhúng trong HCl |
| 2. Hai điện cực **tiếp xúc** trực tiếp hoặc nối với nhau bằng **dây dẫn** | Electron cần đường đi từ anode sang cathode | Đinh Fe quấn dây Cu, hợp kim | Thanh Fe và thanh Cu cắm riêng rẽ, không chạm, không nối dây |
| 3. Hai điện cực **cùng tiếp xúc** với một **dung dịch chất điện li** | Ion trong dung dịch khép kín mạch điện | Nước biển, nước mưa, không khí ẩm, dung dịch acid, muối | Không khí khô, dầu hoả, ethanol khan |

> [!vi-du] Ví dụ 2
> Trường hợp nào sau đây xảy ra ăn mòn điện hoá? Giải thích.
>
> a) Thanh Zn tinh khiết nhúng vào dung dịch HCl.
>
> b) Thanh Zn và thanh Cu nối với nhau bằng dây dẫn, cùng nhúng vào dung dịch HCl.
>
> c) Thanh Zn và thanh Cu nối với nhau bằng dây dẫn, nhúng vào hai cốc HCl riêng biệt (không có cầu muối).
>
> d) Hợp kim Zn – Cu để trong không khí khô.

> [!goi-y] Gợi ý 1
> Soát lần lượt 3 điều kiện cho từng trường hợp. Chỉ cần thiếu một điều kiện là loại.

> [!goi-y] Gợi ý 2
> Ở c), hai điện cực có "cùng" tiếp xúc với **một** dung dịch không? Ở d), có dung dịch chất điện li không?

> [!loi-giai] Lời giải
> a) Chỉ có một điện cực (Zn) → **không** có ăn mòn điện hoá. Zn tan trong HCl là ăn mòn hoá học.
>
> b) Đủ cả 3 điều kiện → **có** ăn mòn điện hoá. Zn là anode, bị ăn mòn. Khí H~2~ thoát ra chủ yếu trên bề mặt thanh Cu (cathode): 2H^+^ + 2e → H~2~.
>
> c) Hai cốc riêng, không có cầu muối, nên mạch không khép kín → **không** có ăn mòn điện hoá. (Zn trong cốc của nó vẫn bị ăn mòn hoá học.)
>
> d) Không có dung dịch chất điện li → **không** có ăn mòn điện hoá.
>
> Vậy chỉ có trường hợp **b)**.

### 1.4. So sánh hai dạng ăn mòn

| | Ăn mòn hoá học | Ăn mòn điện hoá |
|---|---|---|
| Bản chất | Phản ứng oxi hoá – khử **trực tiếp** | Phản ứng oxi hoá – khử trong một **pin điện** tự hình thành |
| Đường đi của electron | Từ kim loại sang **thẳng** chất oxi hoá | Từ anode qua chỗ tiếp xúc sang cathode, rồi chất oxi hoá nhận ở cathode |
| Dòng điện | Không phát sinh | Có dòng electron (nhỏ, bị đoản mạch) |
| Điều kiện hay gặp | Nhiệt độ cao, khí khô (O~2~, Cl~2~…) | Có hai điện cực khác nhau, có nước hoặc dung dịch điện li |
| Ví dụ | Lò đốt, ống xả, Fe cháy trong Cl~2~ | Gang, thép gỉ trong không khí ẩm, vỏ tàu trong nước biển |
| Mức độ phổ biến | Ít hơn | **Phổ biến hơn**, thường **nhanh hơn** |

> [!em-co-biet] Những yếu tố làm ăn mòn nhanh hơn (mở rộng, ngoài SGK)
> - **Độ ẩm** cao; môi trường có **muối** (nước biển) hoặc **acid** (mưa acid): dung dịch dẫn điện tốt hơn, có thêm H^+^ làm chất oxi hoá.
> - **Nhiệt độ** cao; hai kim loại tiếp xúc có **E° cách xa nhau**; kim loại có nhiều **tạp chất**.
>
> Vì thế cầu cảng, giàn khoan, nhà ven biển gỉ nhanh hơn hẳn vùng khô ráo.

Thử áp dụng: thép gỉ trong **không khí khô** thì chủ yếu là ăn mòn hoá học (không có dung dịch điện li). Thép gỉ trong **không khí ẩm** hay trong **nước biển** là ăn mòn điện hoá (Fe – C và lớp nước, nước biển là dung dịch điện li). Trong nước biển có nhiều muối, nên ăn mòn còn nhanh hơn trong không khí ẩm (đối chiếu câu hỏi 1, SGK tr. 104).

> [!em-co-biet] Thiệt hại do ăn mòn
> Ăn mòn, nhất là sự gỉ của thép, gây thiệt hại rất lớn. Gỉ làm thép giảm độ bền, kết cấu (cầu, nhà, đường ống) có thể sập, vỡ. SGK (tr. 104) cho biết ở Mỹ, khoảng một phần tư lượng thép sản xuất ra chỉ để thay thế thép đã bị ăn mòn.

## 2. Chống ăn mòn kim loại

Muốn chống ăn mòn, ta "đánh" vào điều kiện gây ăn mòn. SGK giới thiệu hai phương pháp phổ biến:

- **Phương pháp điện hoá**: vẫn để pin hình thành, nhưng bắt **kim loại khác** làm anode bị ăn mòn **thay** cho kim loại cần bảo vệ.
- **Phương pháp phủ bề mặt**: ngăn không cho kim loại **tiếp xúc** với môi trường (không có nước, không có O~2~ thì không có ăn mòn).

### 2.1. Phương pháp điện hoá

**Thí nghiệm** (tóm tắt, SGK tr. 104): lấy hai đinh sắt mới. Đinh (1) để nguyên. Đinh (2) quấn dây kẽm xung quanh. Cho mỗi đinh vào một ống nghiệm, thêm nước máy đến ngập đinh, để trong không khí khoảng 3 ngày.

**Kết quả:** đinh (1) gỉ nâu đỏ rõ rệt. Đinh (2) gần như không gỉ, nhưng dây kẽm bị mòn và có lớp chất màu trắng bám quanh.

**Giải thích:** ở đinh (2), Zn và Fe tiếp xúc nhau, cùng nằm trong nước (dung dịch điện li) → hình thành pin Zn – Fe. So sánh E°:

=> E°(Zn^2+^/Zn) = −0,762 V < E°(Fe^2+^/Fe) = −0,44 V

Zn có tính khử mạnh hơn nên Zn là **anode**, bị ăn mòn: Zn → Zn^2+^ + 2e. Electron chạy sang sắt. Sắt trở thành **cathode** nên không bị oxi hoá: chất bị khử trên bề mặt sắt là O~2~ hoà tan. Kẽm đã "hi sinh" để bảo vệ sắt.

> [!ghi-nho] Nguyên tắc của phương pháp điện hoá
> Gắn vào kim loại cần bảo vệ một **kim loại khác hoạt động hoá học mạnh hơn** (tính khử mạnh hơn, E° nhỏ hơn). Kim loại mạnh hơn trở thành **anode, bị ăn mòn thay**. Kim loại cần bảo vệ trở thành **cathode, được bảo vệ**. Kim loại bị ăn mòn thay gọi là **kim loại hi sinh** (anode hi sinh).

**Ví dụ điển hình:** để bảo vệ vỏ tàu biển bằng thép, người ta gắn các **tấm kẽm** lên phần vỏ **chìm dưới nước** (SGK tr. 104, Hình 22.4). Nước biển là dung dịch điện li rất tốt. Zn và thép tạo thành pin, Zn bị ăn mòn dần, còn vỏ thép được giữ nguyên. Định kì, khi tấm kẽm mòn gần hết, người ta thay tấm mới.

![Hình 2. Bảo vệ vỏ tàu thép bằng kim loại hi sinh: tấm Zn gắn trên vỏ là anode, bị ăn mòn; electron đi vào vỏ thép (cathode); trên bề mặt vỏ, O₂ hoà tan bị khử, nên sắt không bị oxi hoá](kim-loai-hi-sinh.svg)

Cách này cũng dùng cho đường ống, bể chứa, giàn khoan, tàu thuỷ trong nước biển hoặc đất ẩm (câu hỏi 2, SGK tr. 104: kẽm bị ăn mòn vì mạnh hơn sắt). Mở rộng: với ống thép chôn dưới đất, người ta còn dùng **khối magnesium** nối với ống bằng dây dẫn (điều kiện "tiếp xúc qua dây dẫn").

> [!bay]
> - Kim loại hi sinh phải **mạnh hơn** kim loại cần bảo vệ. Gắn Cu, Sn, Pb vào thép thì **ngược lại**: thép thành anode và bị ăn mòn **nhanh hơn** (xem Hình 3).
> - **Không** dùng Na, K, Ca làm kim loại hi sinh dù chúng rất mạnh: chúng phản ứng ngay với nước, tan mất trong chốc lát.
> - Phương pháp điện hoá **không ngăn** sự ăn mòn. Ăn mòn vẫn xảy ra, chỉ là **chuyển sang kim loại hi sinh**.

> [!vi-du] Ví dụ 3
> Một trụ thép của cầu cảng ngâm trong nước biển. Kĩ sư cân nhắc gắn lên trụ một trong các khối kim loại: Zn, Cu, Mg, Sn (E° lần lượt −0,762 V; +0,340 V; −2,356 V; −0,137 V; E°(Fe^2+^/Fe) = −0,44 V).
>
> a) Những kim loại nào bảo vệ được trụ thép? Kim loại nào làm trụ thép gỉ nhanh hơn?
>
> b) Nếu cần thay khối kim loại thật ít lần, nên chọn Zn hay Mg? (Biết mỗi khối nặng như nhau.)

> [!goi-y] Gợi ý 1
> Kim loại nào có E° **nhỏ hơn** −0,44 V thì sẽ làm anode thay cho sắt.

> [!goi-y] Gợi ý 2
> Câu b: cùng khối lượng, kim loại nào cung cấp được **nhiều mol electron hơn**? Zn^2+^ và Mg^2+^ đều nhận 2e cho mỗi mol, so sánh số mol trong 1 g.

> [!loi-giai] Lời giải
> a) Zn (−0,762) và Mg (−2,356) có E° nhỏ hơn Fe nên trở thành anode: **Zn, Mg bảo vệ được trụ thép**. Cu (+0,340) và Sn (−0,137) có E° lớn hơn Fe, nên sắt lại thành anode: **Cu, Sn làm trụ thép gỉ nhanh hơn**.
>
> b) 1 g Zn có 1/65 mol, nhường 2/65 ≈ 0,031 mol e. 1 g Mg có 1/24 mol, nhường 2/24 ≈ 0,083 mol e. Cùng khối lượng, Mg "dùng được" lâu gấp khoảng 2,7 lần, nên **Mg** cần thay ít lần hơn. (Thực tế ngoài biển người ta vẫn hay dùng Zn hoặc hợp kim nhôm, vì Mg tự ăn mòn khá nhanh trong nước biển. Đây là chi tiết kĩ thuật ngoài SGK.)

### 2.2. Phương pháp phủ bề mặt

Ý tưởng rất đơn giản: phủ lên bề mặt kim loại một lớp **cách li** để nước và oxygen **không chạm** được vào kim loại (SGK tr. 105). Có hai cách:

- **Phủ bằng chất vô cơ hoặc hữu cơ**: **sơn**, **dầu**, **mỡ**, men (tráng men nồi), nhựa. Ví dụ: sơn khung xe đạp, cửa sắt, bôi mỡ vào xích xe, tra dầu vào bản lề.
- **Phủ bằng một kim loại khác không bị gỉ** như Au, Sn, Zn (SGK; mạ Cr, Ni cũng hay gặp, mở rộng). Ví dụ: vỏ đồng hồ **mạ vàng**, **sắt tây** là lá thép tráng **thiếc (Sn)** dùng làm vỏ hộp đồ hộp, **tôn** là lá thép tráng **kẽm (Zn)** dùng lợp mái. Kĩ thuật mạ điện em đã học ở Bài 16.

**Vì sao Zn, Sn bền trong không khí dù khá hoạt động?** (mở rộng) Bề mặt Zn, Sn nhanh chóng phủ một lớp oxide (hoặc muối carbonate) rất mỏng, **đặc khít**, bám chặt, chặn kim loại bên dưới tiếp xúc với môi trường. Khác hẳn lớp gỉ sắt xốp, bong tróc.

**Khi lớp phủ bị xây xát thì sao?** Đây là câu hỏi đề thi rất thích. Lúc này phần sắt lộ ra, gặp nước, và sắt cùng kim loại phủ tạo thành **pin**. Kết quả phụ thuộc vào kim loại phủ **mạnh hơn hay yếu hơn** sắt (mở rộng từ kiến thức pin, ngoài SGK):

![Hình 3. Khi bị xây xát sâu tới lớp sắt: tôn (phủ Zn) thì Zn là anode, sắt vẫn được bảo vệ; sắt tây (phủ Sn) thì sắt là anode, bị ăn mòn nhanh ngay tại vết xước](ton-sat-tay.svg)

| | Tôn (thép phủ Zn) | Sắt tây (thép phủ Sn) |
|---|---|---|
| So sánh tính khử | Zn **mạnh hơn** Fe | Sn **yếu hơn** Fe |
| Anode (bị ăn mòn) khi xây xát | **Zn** | **Fe** |
| Hậu quả | Sắt vẫn được bảo vệ (lúc này lớp Zn bảo vệ theo kiểu điện hoá) | Sắt gỉ **nhanh hơn** cả khi không phủ, gỉ ăn sâu từ vết xước |

> [!ung-dung] Vì sao đồ hộp dùng sắt tây chứ không dùng tôn? (mở rộng)
> Thực phẩm đóng hộp thường có tính acid nhẹ (cà chua, trái cây, nước sốt). Kẽm dễ tan vào thực phẩm có acid, còn thiếc bền hơn và ít độc. Vì vậy mặt trong vỏ hộp được tráng thiếc. Nhưng hộp đã **móp, xước** thì sắt dễ gỉ thủng tại chỗ xước, nên không nên dùng đồ hộp móp méo, phồng.

> [!vi-du] Ví dụ 4
> An có một tấm tôn và một chiếc vỏ hộp sắt tây, cả hai đều bị một vết xước sâu tới lớp sắt. Cả hai được để ngoài trời mưa.
>
> a) Ở mỗi vật, kim loại nào bị ăn mòn?
>
> b) Vật nào sẽ bị thủng (gỉ xuyên qua lớp sắt) sớm hơn? Giải thích.

> [!goi-y] Gợi ý 1
> Vết xước để lộ sắt. Sắt và kim loại phủ tiếp xúc, cùng gặp nước mưa: đủ 3 điều kiện của pin.

> [!goi-y] Gợi ý 2
> E°(Zn^2+^/Zn) = −0,762 V, E°(Fe^2+^/Fe) = −0,44 V, E°(Sn^2+^/Sn) = −0,137 V. Kim loại nào có E° nhỏ hơn trong từng cặp?

> [!loi-giai] Lời giải
> a) Tấm tôn: Zn có E° nhỏ hơn Fe, nên **Zn** là anode và bị ăn mòn. Fe là cathode, được bảo vệ. Vỏ sắt tây: Fe có E° nhỏ hơn Sn, nên **Fe** là anode và bị ăn mòn. Sn là cathode.
>
> b) **Vỏ hộp sắt tây** bị thủng sớm hơn. Ở đó sắt chính là anode bị ăn mòn, lại chỉ lộ ra ở một vết xước nhỏ trong khi cathode (Sn) rất rộng. Toàn bộ dòng ăn mòn dồn vào chỗ xước nên gỉ ăn rất sâu và nhanh. Ở tấm tôn, sắt không bị ăn mòn cho tới khi lớp kẽm xung quanh bị tiêu hao hết.

### 2.3. Hợp kim chống gỉ và các cách khác (mở rộng)

Ngoài hai phương pháp chính trong SGK, còn có thể **thay đổi chính vật liệu** hoặc **môi trường**:

- **Dùng hợp kim chống gỉ**: thép không gỉ chứa **ít nhất 10% chromium** (SGK tr. 100). Vì sao nó bền, xem khung "Vì sao inox không gỉ" ở Bài 21.
- **Làm khô, làm sạch môi trường**: bảo quản nơi khô ráo, lau khô sau khi rửa, không để muối, acid bám lâu trên kim loại. Có thể thêm **chất kìm hãm ăn mòn** vào nước làm mát.

> [!ung-dung] Bảo vệ đồ dùng trong gia đình
> - Dao, kéo bằng thép thường: rửa xong lau khô, thỉnh thoảng bôi một lớp dầu ăn mỏng.
> - Cổng, lan can sắt: cạo sạch gỉ, sơn lót chống gỉ rồi mới sơn phủ. Chỗ sơn bong phải sơn dặm sớm.
> - Xích xe đạp, xe máy: tra dầu mỡ định kì, nhất là sau khi đi mưa.
> - **Không** buộc dây đồng vào khung sắt hay đóng đinh đồng vào tấm tôn ngoài trời: tạo pin, sắt (hoặc kẽm) bị ăn mòn nhanh hơn.

## Dạng bài thi hay gặp

### Dạng 1. Đếm số trường hợp xảy ra ăn mòn điện hoá

**Nhận biết:** đề cho 4–7 thí nghiệm, hỏi "có bao nhiêu thí nghiệm xảy ra ăn mòn điện hoá" (thường là câu trả lời ngắn).

**Phương pháp:**

1. Với mỗi thí nghiệm, tìm **hai điện cực khác nhau**. Chú ý điện cực thứ hai có thể **sinh ra trong quá trình phản ứng**: kim loại mạnh đẩy ion kim loại yếu hơn ra khỏi dung dịch, kim loại mới sinh **bám lên** thanh kim loại ban đầu.
2. Kiểm tra **tiếp xúc** (bám trực tiếp, hợp kim, hoặc nối dây).
3. Kiểm tra **dung dịch chất điện li** chung.
4. Đủ 3 điều kiện thì đếm. Dùng bảng nhận diện nhanh:

| Thí nghiệm | Ăn mòn | Lí do |
|---|---|---|
| Fe vào dung dịch CuSO~4~ (hoặc AgNO~3~, NiSO~4~…) | **Điện hoá** | Fe + Cu^2+^ → Fe^2+^ + Cu, Cu bám lên Fe tạo cặp Fe – Cu |
| Zn vào dung dịch H~2~SO~4~ loãng có thêm vài giọt CuSO~4~ | **Điện hoá** | Cu sinh ra bám lên Zn, tạo cặp Zn – Cu |
| Fe hoặc Cu vào dung dịch FeCl~3~ | Chỉ **hoá học** | Fe^3+^ chỉ về Fe^2+^, không sinh kim loại mới |
| Fe (hoặc Zn) tinh khiết vào HCl, H~2~SO~4~ loãng | Chỉ **hoá học** | Chỉ có một điện cực |
| Gang, thép (Fe – C), hợp kim Fe – Cu, Zn – Cu trong không khí ẩm hoặc dung dịch điện li | **Điện hoá** | Có sẵn hai điện cực tiếp xúc |
| Hai thanh kim loại khác nhau nối dây, cùng nhúng một dung dịch điện li | **Điện hoá** | Đủ 3 điều kiện |
| Đốt Fe trong O~2~ hoặc Cl~2~ | Chỉ **hoá học** | Không có dung dịch điện li |
| Fe vào dung dịch ZnCl~2~, MgSO~4~; Cu vào HCl | **Không** bị ăn mòn | Không có phản ứng |

> [!vi-du] Ví dụ 5
> Tiến hành các thí nghiệm sau:
>
> (1) Nhúng thanh Ni vào dung dịch CuSO~4~.
>
> (2) Nhúng thanh Fe vào dung dịch Fe~2~(SO~4~)~3~.
>
> (3) Nhúng thanh Zn vào dung dịch HCl có lẫn một ít CuCl~2~.
>
> (4) Đốt dây thép trong bình chứa khí O~2~.
>
> (5) Để một vật bằng gang ngoài không khí ẩm.
>
> (6) Nhúng thanh Cu vào dung dịch Fe~2~(SO~4~)~3~.
>
> Có bao nhiêu thí nghiệm xảy ra ăn mòn điện hoá?

> [!goi-y] Gợi ý 1
> Với thí nghiệm nhúng thanh kim loại vào dung dịch muối, viết phản ứng ra. Sản phẩm có kim loại mới bám lên thanh không?

> [!goi-y] Gợi ý 2
> Fe^3+^ chỉ bị Fe, Cu khử về Fe^2+^, không ra kim loại. Thí nghiệm đốt trong O~2~ có dung dịch điện li không?

> [!loi-giai] Lời giải
> (1) Ni + Cu^2+^ → Ni^2+^ + Cu, Cu bám lên Ni → cặp Ni – Cu → **điện hoá**.
>
> (2) Fe + 2Fe^3+^ → 3Fe^2+^, không có kim loại mới → chỉ hoá học.
>
> (3) Zn + Cu^2+^ → Zn^2+^ + Cu, Cu bám lên Zn, cùng trong dung dịch HCl → **điện hoá**.
>
> (4) Không có dung dịch điện li → hoá học.
>
> (5) Gang (Fe – C) và lớp nước ẩm → **điện hoá**.
>
> (6) Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^, không có kim loại mới → chỉ hoá học.
>
> Có **3** thí nghiệm xảy ra ăn mòn điện hoá: (1), (3), (5).

> [!bay]
> - Fe vào dung dịch **Fe^3+^** (FeCl~3~, Fe~2~(SO~4~)~3~) và Cu vào dung dịch **Fe^3+^**: chỉ ăn mòn **hoá học**, vì sản phẩm là Fe^2+^ chứ không phải Fe kim loại.
> - Ở thí nghiệm có muối của kim loại yếu hơn, phản ứng ban đầu là hoá học, **sau đó** mới có điện hoá khi kim loại bám lên. Đề hỏi "có xảy ra ăn mòn điện hoá" thì vẫn **đếm**.
> - Hai thanh kim loại khác nhau đặt trong cùng dung dịch nhưng **không chạm, không nối dây** thì **không** có ăn mòn điện hoá.

### Dạng 2. Kim loại nào bị ăn mòn trước? Giải thích hiện tượng thực tế

**Nhận biết:** đề cho cặp kim loại tiếp xúc (đinh tán, ống nối, tôn, sắt tây, vỏ tàu…), hỏi kim loại nào bị ăn mòn trước, hoặc Đúng/Sai về hiện tượng thực tế.

**Phương pháp:**

1. So sánh tính khử theo dãy E° (Bài 15): K, Na, Mg, Al, Zn, Fe, Ni, Sn, Pb, (H), Cu, Ag, Au. Kim loại **đứng trước** (E° nhỏ hơn) là **anode → bị ăn mòn**.
2. Với cặp kim loại – phi kim (Fe – C), kim loại bị ăn mòn.
3. Kim loại còn lại là cathode, **được bảo vệ** (trên đó O~2~ hoặc H^+^ bị khử, khí H~2~ thoát ra ở cathode nếu là dung dịch acid).

> [!vi-du] Ví dụ 6
> Cho các cặp kim loại tiếp xúc trực tiếp với nhau, cùng nhúng trong dung dịch NaCl: Fe – Zn, Fe – Sn, Fe – Cu, Fe – Al, Fe – Pb, Fe – Mg, Fe – Ni. Có bao nhiêu cặp trong đó Fe bị ăn mòn trước?

> [!goi-y] Gợi ý 1
> Fe bị ăn mòn khi Fe là kim loại **mạnh hơn** trong cặp.

> [!goi-y] Gợi ý 2
> Trong dãy: Mg, Al, Zn đứng trước Fe. Ni, Sn, Pb, Cu đứng sau Fe.

> [!loi-giai] Lời giải
> Fe mạnh hơn Sn, Cu, Pb, Ni, nên trong 4 cặp Fe – Sn, Fe – Cu, Fe – Pb, Fe – Ni, Fe là anode và bị ăn mòn trước. Ở 3 cặp còn lại (với Zn, Al, Mg), kim loại kia bị ăn mòn, Fe được bảo vệ.
>
> Đáp số: **4** cặp.

> [!bay]
> - Đừng nhầm "kim loại bị ăn mòn" với "kim loại ở ngoài, tiếp xúc trực tiếp với môi trường". Ở sắt tây xước, Sn nằm ngoài nhưng **Fe** mới bị ăn mòn.
> - Ni đứng **sau** Fe (E° = −0,257 V > −0,44 V). Nhiều em nhớ nhầm Ni mạnh hơn Fe.
> - Al thực tế được lớp Al~2~O~3~ bảo vệ, nhưng trong đề "cặp Fe – Al tiếp xúc trong dung dịch điện li", quy ước **Al** bị ăn mòn.

### Dạng 3. Thí nghiệm Zn + H~2~SO~4~ thêm CuSO~4~ (Đúng/Sai và tính toán)

**Nhận biết:** hai ống nghiệm cùng chứa Zn (hoặc Fe) và dung dịch acid loãng. Một ống được nhỏ thêm vài giọt dung dịch CuSO~4~. Đề hỏi hiện tượng, giải thích, có khi kèm tính thể tích khí.

**Phương pháp:**

1. Ống không có CuSO~4~: Zn + H~2~SO~4~ → ZnSO~4~ + H~2~. Ăn mòn **hoá học**. Bọt khí H~2~ sinh ra **ngay trên bề mặt Zn**, bám vào và che bớt bề mặt, nên phản ứng **chậm dần**.
2. Ống có CuSO~4~: Zn + CuSO~4~ → ZnSO~4~ + Cu. Lớp Cu bám lên Zn tạo **pin Zn – Cu** → ăn mòn **điện hoá**. Anode (Zn): Zn → Zn^2+^ + 2e. Cathode (Cu): 2H^+^ + 2e → H~2~, **khí thoát ra chủ yếu ở bề mặt Cu**, không che Zn. Kết quả: Zn tan và khí thoát ra **nhanh hơn**.
3. Tính toán: một phần Zn đã dùng để khử Cu^2+^, nên khi Zn tan hết, **tổng lượng H~2~ ít hơn** so với ống không thêm CuSO~4~ (nếu acid dư). Tính: n(H~2~) = n(Zn) − n(Cu^2+^).

> [!vi-du] Ví dụ 7
> Ống (1): 6,5 g Zn và dung dịch H~2~SO~4~ loãng dư. Ống (2): 6,5 g Zn, dung dịch H~2~SO~4~ loãng dư và 0,03 mol CuSO~4~. Xét các phát biểu:
>
> a) Ở ống (2) khí thoát ra nhanh hơn ống (1).
>
> b) Ở ống (2), Cu là anode, bị oxi hoá thành Cu^2+^.
>
> c) Ống (1) chỉ xảy ra ăn mòn hoá học.
>
> d) Khi Zn tan hết, thể tích khí ở ống (2) bằng thể tích khí ở ống (1) và bằng 2,479 L (đkc).

> [!goi-y] Gợi ý 1
> Ống (2) có cặp Zn – Cu. Kim loại nào mạnh hơn thì là anode?

> [!goi-y] Gợi ý 2
> Ở ống (2), có 0,03 mol Zn đã dùng để đẩy Cu ra, không tạo H~2~. Ở điều kiện chuẩn (25 °C, 1 bar), 1 mol khí chiếm 24,79 L.

> [!loi-giai] Lời giải
> a) **Đúng**: ống (2) có ăn mòn điện hoá, H~2~ thoát ra ở bề mặt Cu nên phản ứng nhanh hơn.
>
> b) **Sai**: Zn mạnh hơn Cu nên **Zn** là anode, bị oxi hoá. Cu là cathode, trên đó H^+^ bị khử thành H~2~.
>
> c) **Đúng**: ống (1) chỉ có một kim loại, Zn phản ứng trực tiếp với H^+^.
>
> d) **Sai**. n(Zn) = 6,5 : 65 = 0,1 mol.
>
> Ống (1): n(H~2~) = 0,1 mol → V = 0,1 · 24,79 = 2,479 L.
>
> Ống (2): n(H~2~) = 0,1 − 0,03 = 0,07 mol → V = 0,07 · 24,79 ≈ 1,74 L. Khí ở ống (2) **ít hơn**.

> [!bay]
> - "Khí thoát nhanh hơn" **không** có nghĩa là "khí thoát nhiều hơn". Nhanh hơn về tốc độ, nhưng tổng lượng có thể ít hơn vì một phần Zn đã khử Cu^2+^.
> - Nếu thay CuSO~4~ bằng MgSO~4~ (hoặc Na~2~SO~4~), Zn không đẩy được Mg ra, **không** có pin, tốc độ hầu như không đổi.

### Dạng 4. Bài toán gắn với ăn mòn (vận dụng)

**Nhận biết:** tính lượng kim loại bị ăn mòn, khối lượng gỉ, khối lượng lớp mạ, thời gian dùng được của kim loại hi sinh.

**Phương pháp:**

1. Viết sơ đồ bảo toàn nguyên tố: 2Fe → Fe~2~O~3~·nH~2~O (M = 160 + 18n); 3Fe → Fe~3~O~4~.
2. Khối lượng lớp mạ: m = D · V = D · S · độ dày (đổi về cùng đơn vị cm, g/cm^3^).
3. Kim loại hi sinh có dòng điện (mở rộng, dùng định luật Faraday ở Bài 16): $n_e = \dfrac{It}{F}$, với F = 96 500 C/mol. Mỗi mol Zn (hay Mg) nhường 2 mol electron.

> [!vi-du] Ví dụ 8
> Một thanh thép để ngoài trời, phần sắt bị gỉ là 2,8 g. Coi gỉ sắt có công thức Fe~2~O~3~·H~2~O. Tính khối lượng gỉ tạo thành.

> [!goi-y] Gợi ý 1
> Bảo toàn nguyên tố Fe: 2 mol Fe tạo 1 mol Fe~2~O~3~·H~2~O.

> [!goi-y] Gợi ý 2
> M(Fe~2~O~3~·H~2~O) = 160 + 18 = 178.

> [!loi-giai] Lời giải
> n(Fe) = 2,8 : 56 = 0,05 mol → n(gỉ) = 0,025 mol.
>
> m(gỉ) = 0,025 · 178 = **4,45 g**. Khối lượng gỉ lớn hơn khối lượng sắt bị mất, nên gỉ "phồng" lên và làm nứt lớp sơn, lớp bê tông bọc ngoài.

> [!vi-du] Ví dụ 9 (mở rộng, vận dụng cao)
> Một khối kẽm gắn vào vỏ tàu duy trì một dòng điện bảo vệ trung bình 0,2 A. Tính khối lượng kẽm bị tiêu hao trong 1 năm (365 ngày). Làm tròn đến hàng phần mười, đơn vị kg.

> [!goi-y] Gợi ý 1
> Đổi thời gian ra giây: t = 365 · 24 · 3 600 s. Điện lượng Q = I · t.

> [!goi-y] Gợi ý 2
> n(e) = Q : F. Zn → Zn^2+^ + 2e, nên n(Zn) = n(e) : 2.

> [!loi-giai] Lời giải
> t = 365 · 24 · 3 600 = 31 536 000 s.
>
> n(e) = 0,2 · 31 536 000 : 96 500 ≈ 65,36 mol → n(Zn) ≈ 32,68 mol.
>
> m(Zn) ≈ 32,68 · 65 ≈ 2 124 g ≈ **2,1 kg**.

> [!bay]
> - Gỉ sắt là Fe~2~O~3~·nH~2~O: **2** Fe cho **1** phân tử gỉ. Mỗi mol Zn hay Mg hi sinh cho **2** mol electron.
> - Khối lượng tăng của vật bị ăn mòn hoá học (lớp oxide bám lại) là khối lượng **oxygen** kết hợp (Ví dụ 1).

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Ăn mòn kim loại | Kim loại, hợp kim bị phá huỷ do chất trong môi trường. Bản chất: M → M^n+^ + ne (kim loại bị **oxi hoá**) |
| Ăn mòn hoá học | Oxi hoá – khử **trực tiếp**, không phát sinh dòng điện. Hay gặp ở nhiệt độ cao, khí khô. Ví dụ 3Fe + 2O~2~ → Fe~3~O~4~ |
| Ăn mòn điện hoá | Có **pin điện** hình thành. Phổ biến và nhanh hơn |
| Ba điều kiện | Hai điện cực khác nhau (KL – KL hoặc KL – C); tiếp xúc trực tiếp hoặc qua dây dẫn; cùng nhúng trong dung dịch chất điện li |
| Anode | Kim loại **mạnh hơn**, cực âm, **bị ăn mòn**: Fe → Fe^2+^ + 2e |
| Cathode | Cực dương, không bị ăn mòn. Ở đó O~2~ + 2H~2~O + 4e → 4OH^−^ (không khí ẩm) hoặc 2H^+^ + 2e → H~2~ (acid) |
| Gỉ sắt | Fe~2~O~3~·nH~2~O, nâu đỏ, xốp |
| Phương pháp điện hoá | Gắn kim loại **mạnh hơn** (Zn, Mg) làm anode hi sinh. Ví dụ: tấm Zn trên vỏ tàu |
| Phương pháp phủ bề mặt | Sơn, dầu, mỡ, men. Mạ hoặc tráng kim loại bền: Au, Sn (sắt tây), Zn (tôn), Cr, Ni |
| Khi xây xát | Tôn: Zn bị ăn mòn, Fe được bảo vệ. Sắt tây: Fe bị ăn mòn nhanh |
| Hợp kim chống gỉ | Thép không gỉ chứa ≥ 10% Cr (Bài 21) |
