---
title: Ôn tập chương 7
thoi-gian: 50 phút
muc-tieu:
  - Hệ thống hoá kiến thức chương Nguyên tố nhóm IA và nhóm IIA: cấu hình electron, xu hướng biến đổi tính chất vật lí và tính khử, phản ứng với nước, oxygen, chlorine, tính tan và màu ngọn lửa của hợp chất.
  - Đặt cạnh nhau hai nhóm IA và IIA để so sánh, chỉ ra điểm giống, điểm khác và các "ngoại lệ" (Be, Mg, khối lượng riêng của K) mà đề thi hay khai thác.
  - Phân biệt chắc chắn các cặp chất dễ nhầm: soda, baking soda và xút; đá vôi, vôi sống, vôi tôi; CaSO~4~ và BaSO~4~; nước cứng tạm thời và vĩnh cửu.
  - Giải được bài tập tổng hợp phối hợp hai bài: hỗn hợp kim loại IA và IIA tác dụng với nước rồi hấp thụ CO~2~, nhiệt phân hỗn hợp muối của hai nhóm, bài toán nung vôi gắn với năng lượng và môi trường.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. **Cấu hình:** nhóm IA là ns^1^, nhóm IIA là ns^2^. Nhường hết electron hoá trị nên số oxi hoá là **+1** (IA) và **+2** (IIA).
> 2. **Tính khử:** rất mạnh, **tăng dần từ trên xuống** trong mỗi nhóm. Cùng chu kì: IA mạnh nhất, IIA **chỉ đứng sau** IA.
> 3. **Tự nhiên:** cả hai nhóm **chỉ tồn tại ở dạng hợp chất**. Kim loại kiềm bảo quản trong **dầu hoả khan**.
> 4. **Vật lí:** đều là **kim loại nhẹ**. IA mềm, nóng chảy thấp, t~nc~ **giảm đều** từ Li đến Cs. IIA khó nóng chảy hơn IA, t~nc~ và D **không biến đổi đều**.
> 5. **Với nước:** mọi kim loại IA phản ứng (Li chậm, Na chạy trên mặt nước, K bốc cháy): 2M + 2H~2~O → 2MOH + H~2~. Nhóm IIA: **Be không**, Mg chậm, Ca, Sr, Ba mạnh: M + 2H~2~O → M(OH)~2~ + H~2~.
> 6. **Tính tan:** hợp chất IA hầu hết **dễ tan**. Nhóm IIA: carbonate **không tan**, nitrate **dễ tan**, sulfate **giảm** từ Mg đến Ba (BaSO~4~ không tan), hydroxide **tăng** từ Mg đến Ba.
> 7. **Màu ngọn lửa:** Li^+^ đỏ tía, Na^+^ vàng, K^+^ tím nhạt, Ca^2+^ đỏ cam, Sr^2+^ đỏ son, Ba^2+^ lục.
> 8. **Hợp chất IA:** điện phân dung dịch NaCl có màng ngăn → NaOH + Cl~2~ + H~2~. NaHCO~3~ kém bền nhiệt, Na~2~CO~3~ bền nhiệt, cả hai sản xuất bằng **phương pháp Solvay**.
> 9. **Hợp chất IIA:** MCO~3~ tác dụng với acid và với nước có CO~2~ (hang động, cặn ấm). MCO~3~ và M(NO~3~)~2~ nhiệt phân ra **oxide MO**, độ bền nhiệt **tăng** từ Mg đến Ba.
> 10. **Nước cứng:** nhiều Ca^2+^, Mg^2+^. Tạm thời (HCO~3~^−^), vĩnh cửu (Cl^−^, SO~4~^2−^), toàn phần. Làm mềm bằng **kết tủa** hoặc **trao đổi ion**.

Bài này **không giảng lại từ đầu**. Em dùng nó để xâu chuỗi hai bài: Bài 24 (Nguyên tố nhóm IA) và Bài 25 (Nguyên tố nhóm IIA). Chỗ nào chưa vững, hãy quay lại đúng mục được dẫn.

## 1. Hệ thống hoá kiến thức

### 1.1. Bức tranh toàn chương

Cả chương chỉ xoay quanh **một nguyên nhân**: nguyên tử nhóm IA và IIA có rất ít electron hoá trị (1 hoặc 2), lại có bán kính lớn, nên **rất dễ nhường electron**. Mọi tính chất khác là hệ quả:

1. **Dễ nhường electron** → tính khử rất mạnh → chỉ có ở dạng hợp chất trong tự nhiên, phản ứng với nước, oxygen, chlorine, phải bảo quản kĩ (Bài 24 mục 1, Bài 25 mục 1).
2. **Ít electron góp vào liên kết kim loại** → liên kết kim loại yếu → mềm, dễ nóng chảy. **Bán kính lớn, mạng tinh thể kém đặc khít** → nhẹ (Bài 24 mục 1.3). Nhóm IIA góp 2 electron nên "cứng cáp" hơn nhóm IA một bậc.
3. **Ion M^+^, M^2+^ rất bền, không màu** → hợp chất là chất ion, chỉ nhận ra bằng **màu ngọn lửa** hoặc phản ứng của **anion đi kèm** (kết tủa, khí).
4. **Hợp chất quan trọng** của hai nhóm gắn với đời sống và công nghiệp: muối ăn, xút, soda, bột nở (IA), đá vôi, vôi, thạch cao, nước cứng (IIA).

![Hình 1. Hệ thống hoá chương 7: một nguyên nhân (ít electron hoá trị, bán kính lớn) dẫn tới tính chất của đơn chất và hợp chất hai nhóm](he-thong.svg)

### 1.2. Đơn chất: hai nhóm đặt cạnh nhau

Bảng dưới gom các bảng số liệu của SGK (Bảng 24.1, 24.2, 25.1, 25.2, 25.3) lại thành một. Đọc theo **hàng ngang** để so sánh hai nhóm, đọc theo **cột** để nhớ từng nhóm.

| Tiêu chí | Nhóm IA (Li → Cs) | Nhóm IIA (Be → Ba) | Xem lại |
|---|---|---|---|
| Electron hoá trị | ns^1^ (1 electron) | ns^2^ (2 electron) | Bài 24 mục 1.1, Bài 25 mục 1.1 |
| Số oxi hoá trong hợp chất | +1 | +2 | |
| E°(M^n+^/M) | từ −2,7 V đến −3,0 V | từ −1,99 V (Be) đến −2,92 V (Ba) | |
| Tính khử | mạnh nhất trong các nhóm kim loại, tăng từ Li đến Cs | mạnh, chỉ sau IA, tăng từ Be đến Ba | |
| Trạng thái tự nhiên | chỉ hợp chất: nước biển, halite NaCl, sylvinite NaCl.KCl | chỉ hợp chất: calcite CaCO~3~, dolomite, phosphorite | Bài 24 mục 1.2, Bài 25 mục 1.2 |
| t~nc~ | thấp (Cs 28,4 °C đến Li 180,5 °C), giảm đều | cao hơn IA (651 °C đến 1 287 °C), không đều | Bài 24 mục 1.3, Bài 25 mục 1.3 |
| Khối lượng riêng | rất nhỏ, Li, Na, K nhẹ hơn nước | nhỏ (dưới 5 g/cm^3^), đều nặng hơn nước | |
| Với nước | tất cả phản ứng, mức độ Li < Na < K | Be không, Mg chậm, Ca, Sr, Ba mạnh | Bài 24 mục 1.4, Bài 25 mục 1.4 |
| Với O~2~ (đun nóng) | cháy, mức độ tăng từ Li đến K | Be cháy chậm, các kim loại khác cháy mạnh | |
| Bảo quản | dầu hoả khan, chân không, khí hiếm | Be bền trong không khí nhờ màng oxide, Mg bị oxi hoá chậm, Ca, Sr, Ba bị oxi hoá nhanh | Bài 24 mục 1.5, Bài 25 mục 1.4 |

**Vì sao nhóm IIA "yếu hơn một bậc" so với nhóm IA cùng chu kì?** Đi sang phải một ô trong cùng chu kì, hạt nhân có thêm một proton nhưng số lớp electron không đổi. Electron bị hút chặt hơn, bán kính nhỏ lại. Nguyên tử phải bỏ ra năng lượng để tách **hai** electron thay vì một. Kết quả: tính khử giảm, còn liên kết kim loại (2 electron mỗi nguyên tử) bền hơn nên nóng chảy cao hơn.

> [!bay] Ba "ngoại lệ" đề hay gài
> - E°(Li^+^/Li) âm nhất nhóm IA nhưng Li lại phản ứng với nước **chậm nhất** (Bài 24 mục 1.1). Làm bài theo SGK: mức độ phản ứng tăng từ Li đến Cs.
> - Khối lượng riêng nhóm IA không tăng đều: **K (0,89) nhẹ hơn Na (0,968)**.
> - Nhóm IIA có t~nc~ và D "nhảy cóc" vì kiểu mạng tinh thể khác nhau: Mg có t~nc~ thấp nhất, Ca có D nhỏ nhất (Bài 25 mục 1.3).

### 1.3. Hợp chất: tính tan và màu ngọn lửa

Hai câu hỏi đề thi luôn đặt ra với hợp chất của hai nhóm: **tan hay không tan?** và **nhận ra bằng cách nào?**

**Tính tan.** SGK phân loại theo độ tan S (g/100 g nước, 20 °C): S < 0,01 là không tan, 0,01 ≤ S < 1 là ít tan, S ≥ 1 là dễ tan (Bài 25 mục 2.1).

| Anion | Na^+^, K^+^ (IA) | Mg^2+^ | Ca^2+^ | Sr^2+^ | Ba^2+^ |
|---|---|---|---|---|---|
| OH^−^ | dễ tan (kiềm) | không tan | ít tan | dễ tan | dễ tan |
| CO~3~^2−^ | dễ tan | không tan | không tan | không tan | không tan |
| HCO~3~^−^ | dễ tan | dễ tan | dễ tan | dễ tan | dễ tan |
| SO~4~^2−^ | dễ tan | dễ tan | ít tan | ít tan | **không tan** |
| NO~3~^−^, Cl^−^ | dễ tan | dễ tan | dễ tan | dễ tan | dễ tan |

(Hàng HCO~3~^−^, Cl^−^ và cột nhóm IA là tổng hợp kiến thức lớp 11 và Bài 24, Bảng 25.4 SGK chỉ cho bốn hàng của nhóm IIA. Các muối M(HCO~3~)~2~ chỉ tồn tại trong dung dịch.)

Cách nhớ: **nhóm IA tan hết**. Nhóm IIA có hai dòng đi **ngược chiều nhau**: hydroxide tan dần lên (Mg → Ba), sulfate tan dần xuống (Mg → Ba). Carbonate thì không tan cả nhóm, đó là lí do Na~2~CO~3~ (tan) dùng để "kéo" Ca^2+^, Mg^2+^ ra khỏi nước cứng.

**Màu ngọn lửa.** Ion kim loại của hai nhóm đều không màu trong dung dịch, nên SGK dùng màu ngọn lửa để nhận biết (Bài 24 mục 2.1, Bài 25 mục 2.1).

![Hình 2. Màu ngọn lửa của sáu ion kim loại nhóm IA và IIA (màu vẽ minh hoạ gần đúng)](ngon-lua.svg)

> [!meo] Phân biệt ba màu "đỏ"
> - **Li^+^ đỏ tía** (đỏ ngả tím hồng).
> - **Ca^2+^ đỏ cam** (đỏ ngả cam, gần màu gạch).
> - **Sr^2+^ đỏ son** (đỏ tươi, màu pháo hoa đỏ).
> - Câu nhớ: "Li tía, Ca cam, Sr son". Ba^2+^ là màu duy nhất **lục**.

### 1.4. Các hợp chất quan trọng và mối liên hệ giữa hai bài

Hợp chất của sodium và calcium không đứng riêng mà **đan vào nhau** trong sản xuất. Nhìn Hình 3:

- **Phương pháp Solvay** (Bài 24) cần **đá vôi** CaCO~3~ (Bài 25) để có CO~2~, và **vôi** để tái tạo NH~3~. Phương trình tổng: 2NaCl + CaCO~3~ → Na~2~CO~3~ + CaCl~2~.
- **Soda** Na~2~CO~3~ (Bài 24) lại dùng để **làm mềm nước cứng** (Bài 25): Ca^2+^ + CO~3~^2−^ → CaCO~3~↓.
- **Vòng calcium** (Bài 25): CaCO~3~ → CaO → Ca(OH)~2~ → CaCO~3~, và cân bằng CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~ giải thích hang động, thạch nhũ, cặn ấm, nước cứng tạm thời.

![Hình 3. Các hợp chất quan trọng của sodium (Bài 24) và calcium (Bài 25) liên hệ với nhau qua phương pháp Solvay, nung vôi và làm mềm nước cứng](lien-ket.svg)

| Hợp chất | Tên thường | Tính chất then chốt | Ứng dụng chính | Xem lại |
|---|---|---|---|---|
| NaCl | muối ăn | điện phân dung dịch có màng ngăn ra NaOH, Cl~2~, H~2~ | gia vị, nước muối sinh lí 0,9%, công nghiệp chlorine – kiềm | Bài 24 mục 2.2a |
| NaHCO~3~ | baking soda, thuốc muối | kém bền nhiệt (khoảng 120 °C), tác dụng với acid sinh CO~2~ | bột nở, bình chữa cháy bột, viên sủi, giảm acid dạ dày | Bài 24 mục 2.2b |
| Na~2~CO~3~ | soda | bền nhiệt, dung dịch có tính base, kết tủa Ca^2+^, Mg^2+^, Fe^3+^ | thuỷ tinh, xà phòng, làm mềm nước, xử lí nước nhiễm phèn | Bài 24 mục 2.2b |
| CaCO~3~ | đá vôi, đá phấn | không tan, tan trong acid và trong nước có CO~2~, nhiệt phân ra CaO | vôi sống, xi măng, vật liệu xây dựng | Bài 25 mục 2.2a |
| CaO | vôi sống | tác dụng với nước toả nhiều nhiệt | khử chua đất, sát trùng, hút ẩm | Bài 25 mục 2.3 |
| Ca(OH)~2~ | vôi tôi, nước vôi | ít tan, base mạnh, hấp thụ CO~2~ | khử chua, làm mềm nước cứng tạm thời, vữa xây | Bài 25 mục 2.3 |
| CaSO~4~ ngậm nước | thạch cao | ít tan | vật liệu xây dựng, phấn viết bảng, bó bột | Bài 25 mục 2.3 |
| BaSO~4~ | | không tan, kể cả trong acid | chất cản quang chụp X-quang dạ dày | Bài 25 mục 1.5 |

## 2. So sánh – phân biệt

### 2.1. Xu hướng biến đổi: cái gì tăng, cái gì giảm?

Đề Đúng/Sai rất hay đánh tráo chữ "tăng" và "giảm". Học bảng này theo **cặp đối lập** sẽ khó nhầm hơn học từng dòng.

| Đi từ trên xuống trong nhóm | Nhóm IA | Nhóm IIA |
|---|---|---|
| Bán kính nguyên tử | tăng | tăng |
| Tính khử, mức độ phản ứng với nước | tăng | tăng |
| Nhiệt độ nóng chảy | **giảm đều** | **không đều** |
| Khối lượng riêng | nhìn chung tăng, trừ K < Na | không đều |
| Độ tan của hydroxide | đều dễ tan | **tăng** (Mg(OH)~2~ không tan → Ba(OH)~2~ dễ tan) |
| Độ tan của muối sulfate | đều dễ tan | **giảm** (MgSO~4~ dễ tan → BaSO~4~ không tan) |
| Độ bền nhiệt của muối carbonate, nitrate | Na~2~CO~3~, K~2~CO~3~ bền nhiệt | **tăng** từ Mg đến Ba (Δ~r~H°~298~ tăng) |

**Vì sao độ bền nhiệt lại tăng theo chiều tính khử tăng?** Nhớ lại Bài 25: phản ứng nhiệt phân có Δ~r~H°~298~ dương và **tăng** từ MgCO~3~ (100,7 kJ) đến BaCO~3~ (271,5 kJ). Phải cấp càng nhiều nhiệt thì muối càng khó phân huỷ, tức là càng bền. Không có mâu thuẫn nào ở đây: "bền nhiệt" là tính chất của **muối**, còn "tính khử" là tính chất của **kim loại**.

### 2.2. So sánh hợp chất cùng loại của hai nhóm

| Loại hợp chất | Nhóm IA | Nhóm IIA |
|---|---|---|
| Hydroxide | NaOH, KOH: base mạnh, dễ tan (kiềm) | Ca(OH)~2~ ít tan nhưng vẫn là base mạnh, Mg(OH)~2~ không tan |
| Muối carbonate | dễ tan, **bền nhiệt** (Na~2~CO~3~ không bị nhiệt phân khi nung thông thường) | không tan, **bị nhiệt phân**: MCO~3~ → MO + CO~2~ |
| Muối hydrogencarbonate | NaHCO~3~ là chất rắn, nhiệt phân: 2NaHCO~3~ → Na~2~CO~3~ + CO~2~ + H~2~O | Ca(HCO~3~)~2~ chỉ có trong dung dịch, đun nóng: → CaCO~3~↓ + CO~2~ + H~2~O |
| Muối nitrate | dễ tan | dễ tan, nhiệt phân ra **oxide**: M(NO~3~)~2~ → MO + 2NO~2~ + ½O~2~ |
| Muối sulfate | dễ tan | MgSO~4~ tan, CaSO~4~ ít tan, BaSO~4~ không tan |
| Tỉ lệ khi kim loại tác dụng với nước | n(H~2~) = ½ n(M), n(OH^−^) = n(M) | n(H~2~) = n(M), n(OH^−^) = 2n(M) |

> [!meo] Một tỉ lệ dùng chung cho cả hai nhóm
> Dù là Na hay Ba, mỗi mol H~2~ thoát ra luôn đi kèm **2 mol OH^−^** trong dung dịch: n(OH^−^) = 2n(H~2~). Với hỗn hợp kim loại IA và IIA, em không cần biết từng kim loại mà vẫn tính được ngay lượng acid trung hoà hoặc lượng CO~2~ hấp thụ.

### 2.3. Các cặp hay bị đánh tráo trong đề

| Cặp | Giống nhau | Khác nhau (chỗ đề hay hỏi) |
|---|---|---|
| Soda – baking soda – xút | đều là hợp chất của sodium, đều có tính base | soda là **Na~2~CO~3~** (bền nhiệt), baking soda là **NaHCO~3~** (kém bền nhiệt), xút là **NaOH** |
| Đá vôi – vôi sống – vôi tôi | đều là hợp chất calcium, chuyển hoá qua lại | đá vôi **CaCO~3~**, vôi sống **CaO**, vôi tôi **Ca(OH)~2~**. Nước vôi trong là dung dịch Ca(OH)~2~ |
| CaSO~4~ – BaSO~4~ | đều là kết tủa trắng của ion sulfate | CaSO~4~ **ít tan**, kết tủa chậm và ít. BaSO~4~ **không tan**, kết tủa ngay. Thạch cao là CaSO~4~ ngậm nước, chất cản quang là BaSO~4~ |
| BaSO~4~ – BaCO~3~ | đều là kết tủa trắng không tan trong nước | BaCO~3~ **tan trong acid**, sủi bọt CO~2~. BaSO~4~ **không tan** trong acid. Vì vậy không thay BaSO~4~ bằng BaCO~3~ khi chụp X-quang |
| Điện phân NaCl có màng ngăn – không màng ngăn | đều có H~2~ ở cathode, Cl~2~ ở anode | có màng ngăn: thu **NaOH, Cl~2~, H~2~**. Không màng ngăn: Cl~2~ gặp NaOH, thu **nước Javel** (NaCl + NaClO) |
| Điện phân dung dịch NaCl – nóng chảy | đều có Cl~2~ ở anode | chỉ điện phân **nóng chảy** mới thu được kim loại Na. Dung dịch thì nước bị khử ở cathode |
| Nước cứng tạm thời – vĩnh cửu | đều chứa nhiều Ca^2+^, Mg^2+^ | tạm thời đi kèm **HCO~3~^−^**, đun sôi là mềm. Vĩnh cửu đi kèm **Cl^−^, SO~4~^2−^**, phải dùng Na~2~CO~3~, Na~3~PO~4~ hoặc trao đổi ion |
| Ca(OH)~2~ – Na~2~CO~3~ khi làm mềm nước | đều tạo kết tủa CaCO~3~ | Ca(OH)~2~ chỉ dùng cho nước cứng **tạm thời**, phải **vừa đủ**. Na~2~CO~3~ dùng được cho **mọi loại** |
| Thổi CO~2~ vào nước vôi trong – vào dung dịch NaOH | đều hấp thụ CO~2~ | nước vôi trong: vẩn đục rồi trong lại khi CO~2~ dư. NaOH: không có kết tủa vì Na~2~CO~3~, NaHCO~3~ đều tan |
| Màu ngọn lửa Li^+^ – Ca^2+^ – Sr^2+^ | đều màu đỏ | Li^+^ đỏ **tía**, Ca^2+^ đỏ **cam**, Sr^2+^ đỏ **son** |

## 3. Bảng tỉ lệ và công thức tính toán của chương

| Bài toán | Tỉ lệ / công thức | Xem lại |
|---|---|---|
| Kim loại IA + nước | 2M + 2H~2~O → 2MOH + H~2~: n(H~2~) = n(M) : 2 | Bài 24 Dạng 1 |
| Kim loại IIA (Ca, Sr, Ba) + nước | M + 2H~2~O → M(OH)~2~ + H~2~: n(H~2~) = n(M) | Bài 25 mục 1.4 |
| Hỗn hợp IA, IIA + nước | n(OH^−^) = 2n(H~2~); m(dung dịch) = m(kim loại) + m(nước) − m(H~2~) | mục 5.1 bài này |
| Hai kim loại cùng nhóm, chu kì liên tiếp | M̄ = m : n, tìm hai kim loại có M kẹp M̄ | Bài 24 Ví dụ 6 |
| Nhiệt phân NaHCO~3~ | 2NaHCO~3~ (168 g) → Na~2~CO~3~ (106 g): khối lượng giảm 62 g | Bài 24 Dạng 2 |
| Nhiệt phân MCO~3~ | MCO~3~ → MO + CO~2~: khối lượng giảm = m(CO~2~) | Bài 25 Dạng 1 |
| Carbonate + acid | n(CO~2~) = n(CO~3~^2−^) khi acid dư; nhỏ acid vào carbonate thì tạo HCO~3~^−^ trước | Bài 24 Ví dụ 8 |
| CO~2~ + dung dịch kiềm | T = n(OH^−^) : n(CO~2~); khi 1 < T < 2: n(CO~3~^2−^) = n(OH^−^) − n(CO~2~) | Bài 25 Dạng 2 |
| Kết tủa MCO~3~ | n(↓) = số nhỏ hơn giữa n(CO~3~^2−^) và n(M^2+^) | Bài 25 Dạng 2 |
| Làm mềm nước bằng Na~2~CO~3~ | n(CO~3~^2−^) = n(Ca^2+^) + n(Mg^2+^) | Bài 25 Dạng 3 |
| Làm mềm nước bằng Na~3~PO~4~ | 3M^2+^ + 2PO~4~^3−^: n(PO~4~^3−^) = ⅔[n(Ca^2+^) + n(Mg^2+^)] | Bài 25 mục 3.3 |
| Chlorine – kiềm, Solvay | 2NaCl → 2NaOH + Cl~2~ + H~2~; 2NaCl → Na~2~CO~3~; CaCO~3~ → Na~2~CO~3~ | Bài 24 Dạng 3 |
| Nhiệt lượng nung vôi | Q = n(CaCO~3~) · 179,2 kJ/mol | mục 5.3 bài này |
| Thể tích khí (đkc) | V = n · 24,79 L (kmol thì 24,79 m^3^) | |

> [!bay] Bốn con số dễ sai của chương
> - Kim loại **IA**: n(H~2~) = **½** n(M). Kim loại **IIA**: n(H~2~) = n(M). Đổi chỗ hai tỉ lệ này là lỗi phổ biến nhất khi làm hỗn hợp.
> - Nung NaHCO~3~ mất **CO~2~ và H~2~O** (62 g ứng với 2 mol), nung CaCO~3~ chỉ mất **CO~2~**.
> - Solvay: **2** mol NaCl mới cho **1** mol Na~2~CO~3~.
> - Na~3~PO~4~: 2 mol PO~4~^3−^ kết tủa **3** mol Ca^2+^, không phải 1 : 1.

## 4. Lỗi sai hay gặp của cả chương

**Về đơn chất**

- Cho rằng tính khử **giảm** từ Li đến Cs (hay từ Be đến Ba) vì "nguyên tử nặng dần". Đúng là **tăng**, vì bán kính tăng.
- Nghĩ nhiệt độ nóng chảy cùng chiều với tính khử. Ở nhóm IA, t~nc~ **giảm** còn tính khử **tăng**.
- Cho rằng mọi kim loại nhóm IIA đều phản ứng với nước ở nhiệt độ thường (Be không phản ứng, Mg rất chậm).
- Cho rằng Li phản ứng với nước mạnh nhất vì E° âm nhất.
- Bảo quản Na trong ethanol, glycerol hoặc dầu ăn. Chỉ dùng **dầu hoả khan**.
- Cho Na, K vào dung dịch muối CuSO~4~, FeCl~3~ rồi kết luận kim loại bị đẩy ra. Kim loại kiềm phản ứng với **nước** trước, rồi kiềm tạo kết tủa hydroxide.

**Về hợp chất**

- Gọi CaSO~4~ là "không tan" (đúng là **ít tan**). Chỉ BaSO~4~ là sulfate không tan của nhóm.
- Gọi Ca(OH)~2~ là base yếu vì nó ít tan. Phần tan phân li hoàn toàn nên vẫn là base mạnh.
- Viết Na~2~CO~3~ bị nhiệt phân, hoặc viết nitrate nhóm IIA nhiệt phân ra nitrite.
- Nhầm màu ngọn lửa Li^+^, Ca^2+^, Sr^2+^ (ba màu đỏ) hoặc cho K^+^ màu vàng.
- Viết "điện phân dung dịch NaCl thu được Na".
- Nhầm soda Na~2~CO~3~ với xút NaOH hoặc với baking soda NaHCO~3~.

**Về nước cứng**

- Phân loại nước cứng theo **cation** (đúng là theo **anion** đi kèm).
- Cho rằng đun sôi làm mềm được mọi loại nước cứng.
- Dùng Ca(OH)~2~ **dư** để làm mềm, hoặc dùng Ca(OH)~2~ cho nước cứng vĩnh cửu.
- Cho rằng NaCl, HCl, Na~2~SO~4~ làm mềm được nước cứng.

**Về tính toán**

- Quên chia 2 khi tính H~2~ từ kim loại kiềm, hoặc chia 2 khi tính H~2~ từ Ca, Ba.
- Lấy n(kết tủa) = n(CO~2~) mà chưa xét tỉ lệ T.
- Quên trừ khối lượng H~2~ khi tính khối lượng dung dịch.
- Quên hiệu suất, hoặc nhân hiệu suất khi tính ngược từ sản phẩm về nguyên liệu (phải **chia**).

## 5. Bài tập tổng hợp

Các ví dụ dưới đây phối hợp cả hai bài. Hãy tự làm trước, mở từng gợi ý khi bí.

### 5.1. Hỗn hợp kim loại IA và IIA tác dụng với nước, rồi hấp thụ CO~2~

> [!vi-du] Ví dụ 1
> Cho 9,15 g hỗn hợp X gồm Na và Ba vào nước dư, thu được 2,479 L khí H~2~ (đkc) và dung dịch Y.
>
> a) Tính số mol mỗi kim loại trong X.
>
> b) Hấp thụ hoàn toàn 3,7185 L khí CO~2~ (đkc) vào Y. Tính khối lượng kết tủa.
>
> c) Lọc bỏ kết tủa rồi đun nóng nước lọc. Có xuất hiện thêm kết tủa không? Vì sao?

> [!goi-y] Gợi ý 1
> Viết hai phương trình với nước. Na cho ½ mol H~2~ mỗi mol, Ba cho 1 mol H~2~ mỗi mol. Lập hệ hai ẩn: khối lượng và số mol H~2~.

> [!goi-y] Gợi ý 2
> n(OH^−^) = 2n(H~2~). Tính T = n(OH^−^) : n(CO~2~) để biết tạo CO~3~^2−^, HCO~3~^−^ hay cả hai. So sánh n(CO~3~^2−^) với n(Ba^2+^).

> [!goi-y] Gợi ý 3
> Câu c: kết tủa mới chỉ xuất hiện khi trong nước lọc còn **đồng thời** HCO~3~^−^ và ion Ba^2+^ (hoặc Ca^2+^). Còn Ba^2+^ không?

> [!loi-giai] Lời giải
> a) 2Na + 2H~2~O → 2NaOH + H~2~ và Ba + 2H~2~O → Ba(OH)~2~ + H~2~.
>
> Gọi x = n(Na), y = n(Ba). n(H~2~) = 2,479 : 24,79 = 0,1 mol.
>
> 23x + 137y = 9,15 và x : 2 + y = 0,1. Giải ra x = **0,1 mol Na**, y = **0,05 mol Ba**.
>
> b) n(OH^−^) = 2 · 0,1 = 0,2 mol, n(CO~2~) = 3,7185 : 24,79 = 0,15 mol. T = 0,2 : 0,15 ≈ 1,33, nằm giữa 1 và 2, nên tạo cả CO~3~^2−^ và HCO~3~^−^.
>
> n(CO~3~^2−^) = 0,2 − 0,15 = 0,05 mol, n(HCO~3~^−^) = 0,15 − 0,05 = 0,1 mol.
>
> n(Ba^2+^) = 0,05 mol, vừa đúng bằng n(CO~3~^2−^), nên n(BaCO~3~) = 0,05 mol, m = 0,05 · 197 = **9,85 g**.
>
> c) **Không.** Toàn bộ Ba^2+^ đã vào kết tủa. Nước lọc chỉ còn 0,1 mol NaHCO~3~. Đun nóng thì 2NaHCO~3~ → Na~2~CO~3~ + CO~2~ + H~2~O, nhưng Na~2~CO~3~ tan nên không có kết tủa.

> [!bay]
> - Coi cả hai kim loại cho ½ mol H~2~ (hay cả hai cho 1 mol H~2~) sẽ giải ra số mol âm hoặc sai lệch.
> - Lấy n(BaCO~3~) = n(CO~2~) = 0,15 mol sẽ ra 29,55 g, vượt cả lượng Ba có trong hỗn hợp.

### 5.2. Nhiệt phân hỗn hợp muối của hai nhóm

> [!vi-du] Ví dụ 2
> Nung 26,8 g hỗn hợp NaHCO~3~ và CaCO~3~ đến khối lượng không đổi, thu được 16,2 g chất rắn X.
>
> a) Tính phần trăm khối lượng NaHCO~3~ trong hỗn hợp ban đầu (làm tròn đến hàng phần mười).
>
> b) Cho X vào nước dư, khuấy kĩ. Tính khối lượng kết tủa thu được.

> [!goi-y] Gợi ý 1
> Hai muối đều bị nhiệt phân, nhưng sản phẩm rắn khác nhau: NaHCO~3~ cho Na~2~CO~3~, CaCO~3~ cho CaO. Đặt a = n(NaHCO~3~), b = n(CaCO~3~), viết khối lượng chất rắn theo a và b.

> [!goi-y] Gợi ý 2
> Câu b: CaO gặp nước thành gì? Chất đó gặp Na~2~CO~3~ trong dung dịch thì sao?

> [!loi-giai] Lời giải
> a) 2NaHCO~3~ → Na~2~CO~3~ + CO~2~ + H~2~O và CaCO~3~ → CaO + CO~2~.
>
> Khối lượng ban đầu: 84a + 100b = 26,8.
>
> Chất rắn X gồm a/2 mol Na~2~CO~3~ và b mol CaO: 53a + 56b = 16,2.
>
> Giải ra a = 0,2, b = 0,1. %m(NaHCO~3~) = 0,2 · 84 : 26,8 · 100% ≈ **62,7%**.
>
> b) X gồm 0,1 mol Na~2~CO~3~ và 0,1 mol CaO. Trong nước:
>
> => CaO + H~2~O → Ca(OH)~2~
>
> => Ca(OH)~2~ + Na~2~CO~3~ → CaCO~3~↓ + 2NaOH
>
> Hai chất vừa đủ, n(CaCO~3~) = 0,1 mol, m = **10 g**. Dung dịch còn lại chứa 0,2 mol NaOH.

> [!em-co-biet] Phản ứng "xút hoá" soda
> Phản ứng Ca(OH)~2~ + Na~2~CO~3~ → CaCO~3~ + 2NaOH từng là cách sản xuất xút trước khi có công nghiệp điện phân dung dịch NaCl (mở rộng, ngoài SGK). Nó chạy được vì CaCO~3~ không tan, tách ra khỏi dung dịch.

### 5.3. Nung vôi: năng lượng và môi trường

Đây là phần mở rộng từ Câu 7 trong trang Ôn tập (SGK tr. 127), kết hợp biến thiên enthalpy (Hoá 10) với kiến thức Bài 25.

> [!nen-tang] Nhiệt lượng của phản ứng (Hoá 10)
> - Phương trình nhiệt hoá học CaCO~3~(s) → CaO(s) + CO~2~(g), Δ~r~H°~298~ = +179,2 kJ nghĩa là phân huỷ **1 mol** CaCO~3~ cần **hấp thụ** 179,2 kJ.
> - n mol thì cần n · 179,2 kJ. Δ~r~H > 0 là phản ứng thu nhiệt, Δ~r~H < 0 là phản ứng toả nhiệt.

> [!vi-du] Ví dụ 3 (vận dụng cao)
> Một lò vôi nung 1 tấn đá vôi chứa 90% CaCO~3~ về khối lượng (tạp chất không bị phân huỷ). Nhiệt cung cấp cho lò lấy từ đốt than (coi là carbon): C(s) + O~2~(g) → CO~2~(g), Δ~r~H°~298~ = −393,5 kJ. Chỉ 50% nhiệt toả ra được dùng cho phản ứng phân huỷ CaCO~3~.
>
> a) Nung vôi là quá trình toả nhiệt hay thu nhiệt? Tính khối lượng CaO tạo thành khi CaCO~3~ phân huỷ hoàn toàn.
>
> b) Tính khối lượng than cần dùng (làm tròn đến hàng đơn vị, đơn vị kg).
>
> c) Tính tổng số kmol CO~2~ lò thải ra. Phần CO~2~ do đốt than chiếm khoảng bao nhiêu phần trăm?

> [!goi-y] Gợi ý 1
> Đổi đơn vị: 900 kg CaCO~3~ = 9 kmol = 9 000 mol. Nhiệt cần = 9 000 · 179,2 kJ.

> [!goi-y] Gợi ý 2
> Than phải toả ra lượng nhiệt **gấp đôi** nhiệt cần (vì chỉ 50% được dùng). Mỗi mol C toả 393,5 kJ.

> [!loi-giai] Lời giải
> a) Δ~r~H°~298~ = +179,2 kJ > 0, nên nung vôi là quá trình **thu nhiệt**, phải đốt nhiên liệu liên tục.
>
> m(CaCO~3~) = 1 000 · 0,9 = 900 kg → n = 9 kmol → n(CaO) = 9 kmol, m(CaO) = 9 · 56 = **504 kg**.
>
> b) Nhiệt cần cho phản ứng: 9 000 · 179,2 = 1 612 800 kJ.
>
> Nhiệt than phải toả ra: 1 612 800 : 0,5 = 3 225 600 kJ.
>
> n(C) = 3 225 600 : 393,5 ≈ 8 197 mol → m(C) ≈ 8 197 · 12 ≈ 98 366 g ≈ **98 kg**.
>
> c) CO~2~ từ đá vôi: 9 kmol. CO~2~ từ than: khoảng 8,2 kmol. Tổng ≈ **17,2 kmol** (khoảng 426 m^3^ ở đkc).
>
> Phần do đốt than chiếm 8,2 : 17,2 ≈ **48%**, gần một nửa.

> [!ung-dung] Vì sao lò vôi thủ công gây ô nhiễm? (Câu 7c, SGK tr. 127)
> - Thải lượng lớn **CO~2~** (cả từ đá vôi lẫn từ than), góp phần gây hiệu ứng nhà kính.
> - Than cháy không hết sinh **CO** độc. Than có lẫn sulfur sinh **SO~2~**, gây mưa acid.
> - **Bụi** vôi, bụi than, tro xỉ làm ô nhiễm không khí, hại đường hô hấp. Lò thủ công hiệu suất nhiệt thấp nên tốn than và thải nhiều hơn lò công nghiệp.
> - Khai thác đá vôi làm mất cảnh quan núi đá, hang động.

### 5.4. Đúng/Sai: hai nhóm kim loại với nước

> [!vi-du] Ví dụ 4 (Đúng/Sai)
> Một học sinh lấy bốn mẩu kim loại nhỏ có khối lượng bằng nhau: Na, K, Mg, Ca. Thả mỗi mẩu vào một cốc nước ở nhiệt độ thường đã nhỏ sẵn vài giọt phenolphthalein. Xét các phát biểu sau:
>
> a) Mẩu Mg gần như không có hiện tượng gì rõ rệt ở nhiệt độ thường. Đun nóng cốc thì có bọt khí và dung dịch quanh mẩu Mg hồng nhạt.
>
> b) Mẩu Ca nổi và chạy trên mặt nước giống mẩu Na.
>
> c) Ở cốc chứa K, phản ứng mạnh nhất trong bốn cốc.
>
> d) Nếu Na và Ca đều phản ứng hết thì mẩu Na giải phóng nhiều khí H~2~ hơn mẩu Ca.

> [!goi-y] Gợi ý 1
> Nhớ khối lượng riêng: Na (0,968), K (0,89) nhẹ hơn nước, Ca (1,55), Mg (1,74) nặng hơn nước.

> [!goi-y] Gợi ý 2
> Câu d: cùng khối lượng m. n(H~2~) từ Na là m : (2 · 23) = m : 46. n(H~2~) từ Ca là m : 40. Số nào lớn hơn?

> [!loi-giai] Lời giải
> a) **Đúng.** Mg(OH)~2~ không tan bám lại thành lớp áo trên bề mặt nên phản ứng gần như dừng. Đun nóng thì phản ứng nhanh hơn, phần Mg(OH)~2~ tan rất ít cũng đủ làm phenolphthalein hồng nhạt.
>
> b) **Sai.** Ca nặng hơn nước (1,55 g/cm^3^) và nóng chảy ở 842 °C, nên không nổi lên và chảy thành giọt chạy trên mặt nước như Na. Mẩu Ca nằm trong nước, sủi bọt khí mạnh, dung dịch vẩn đục nhẹ vì Ca(OH)~2~ ít tan.
>
> c) **Đúng.** K có tính khử mạnh nhất trong bốn kim loại, phản ứng làm H~2~ bốc cháy.
>
> d) **Sai.** Cùng khối lượng m: Na cho m : 46 mol H~2~, Ca cho m : 40 mol H~2~. Vì m : 40 > m : 46 nên **Ca** cho nhiều H~2~ hơn. Kim loại IIA nhường 2 electron mỗi nguyên tử nên "lời" electron hơn.

## 6. Đối chiếu bài tập SGK (tr. 127)

**Câu 1 (so sánh nhóm IA với kim loại khác cùng chu kì).** Ba ý "tính khử mạnh nhất", "E° âm nhất", "bán kính lớn nhất" đều đúng với nhóm IA vì chúng đứng đầu chu kì. Ý sai là ý nói về **số electron hoá trị**: nhóm IA chỉ có **1** electron hoá trị, **ít nhất** trong chu kì.

**Câu 2 (Solvay).** Bốn muối có thể ghép từ các ion Na^+^, NH~4~^+^, Cl^−^, HCO~3~^−^. Chất tách ra khi làm lạnh là chất **ít tan nhất**, tức NaHCO~3~ (Bài 24 mục 2.2b). Đề hay gài NH~4~HCO~3~ vì nó cũng chứa HCO~3~^−^.

**Câu 3, Câu 4 (xu hướng độ tan sulfate, độ bền nhiệt carbonate).** Hai câu này là hai dòng "đi ngược chiều" trong bảng ở mục 2.1: độ tan sulfate **giảm** từ MgSO~4~ đến BaSO~4~, độ bền nhiệt carbonate **tăng** từ MgCO~3~ đến BaCO~3~.

**Câu 5 (nguyên tắc làm mềm nước).** Nước cứng là do **cation** Ca^2+^, Mg^2+^, nên làm mềm là làm giảm nồng độ hai ion này. Anion chỉ dùng để **phân loại** nước cứng.

**Câu 6 (phân biệt CaCl~2~ và BaCl~2~).** Có hai cách: màu ngọn lửa (đỏ cam và lục) và dùng ion sulfate (BaSO~4~ kết tủa ngay, CaSO~4~ ít tan). Ví dụ 5 luyện cùng ý với hai muối nitrate.

> [!vi-du] Ví dụ 5 (tương tự Câu 6)
> Có hai lọ mất nhãn chứa dung dịch Ca(NO~3~)~2~ và Ba(NO~3~)~2~ loãng, cùng nồng độ.
>
> a) Phân biệt hai dung dịch bằng màu ngọn lửa.
>
> b) Phân biệt bằng phương pháp hoá học. Vì sao không dùng dung dịch Na~2~CO~3~ được?

> [!goi-y] Gợi ý 1
> Hai dung dịch có chung anion NO~3~^−^, chỉ khác cation. Cần một thuốc thử cho kết quả **khác nhau** với Ca^2+^ và Ba^2+^.

> [!goi-y] Gợi ý 2
> Xem lại bảng tính tan: với CO~3~^2−^, cả hai cation cho kết quả giống hay khác nhau? Với SO~4~^2−^ thì sao?

> [!loi-giai] Lời giải
> a) Nhúng dây platinum sạch vào từng dung dịch rồi hơ trên ngọn lửa không màu. Ngọn lửa **đỏ cam** là Ca(NO~3~)~2~, ngọn lửa **lục** là Ba(NO~3~)~2~.
>
> b) Nhỏ vài giọt dung dịch Na~2~SO~4~ loãng (hoặc H~2~SO~4~ loãng) vào từng mẫu thử. Mẫu xuất hiện ngay **kết tủa trắng** là Ba(NO~3~)~2~:
>
> => Ba^2+^ + SO~4~^2−^ → BaSO~4~↓
>
> Mẫu không có kết tủa (hoặc chỉ vẩn đục rất chậm, rất ít vì CaSO~4~ ít tan) là Ca(NO~3~)~2~.
>
> Không dùng Na~2~CO~3~ vì **cả hai** đều cho kết tủa trắng (CaCO~3~ và BaCO~3~), không phân biệt được.

**Câu 7 (nung vôi).** Ví dụ 3 ở mục 5.3 đã đi đủ ba ý: thu nhiệt hay toả nhiệt, tính lượng vôi và năng lượng, tác hại môi trường. Ứng dụng của **vôi sống** (câu 7b): khử chua đất trồng, sát trùng, tẩy uế chuồng trại, hút ẩm, làm nguyên liệu sản xuất vôi tôi, vữa xây, xi măng và nhiều hoá chất (Bài 25 mục 2.3).

## Tóm tắt

| Nội dung | Nhóm IA | Nhóm IIA |
|---|---|---|
| Cấu hình, số oxi hoá | ns^1^; +1 | ns^2^; +2 |
| Tính khử | rất mạnh; tăng từ Li đến Cs | mạnh, sau IA; tăng từ Be đến Ba |
| Tự nhiên | chỉ ở dạng hợp chất | chỉ ở dạng hợp chất |
| Vật lí | mềm, nhẹ; t~nc~ thấp, giảm đều | nhẹ; t~nc~ cao hơn IA, không đều |
| Với nước | 2M + 2H~2~O → 2MOH + H~2~; Li < Na < K | Be không; Mg chậm; Ca, Sr, Ba: M + 2H~2~O → M(OH)~2~ + H~2~ |
| Với không khí, bảo quản | rất dễ bị oxi hoá; ngâm dầu hoả khan, chân không, khí hiếm | Be bền nhờ màng oxide; Mg oxi hoá chậm; Ca, Sr, Ba oxi hoá nhanh |
| Tính tan | hầu hết dễ tan | MCO~3~ không tan; nitrate tan; sulfate giảm; hydroxide tăng |
| Màu ngọn lửa | Li^+^ đỏ tía; Na^+^ vàng; K^+^ tím nhạt | Ca^2+^ đỏ cam; Sr^2+^ đỏ son; Ba^2+^ lục |
| Hợp chất quan trọng | NaCl (chlorine – kiềm); NaHCO~3~ kém bền nhiệt; Na~2~CO~3~ bền nhiệt; Solvay | CaCO~3~, CaO, Ca(OH)~2~, thạch cao, apatite; MCO~3~, M(NO~3~)~2~ → MO |
| Liên hệ | Solvay cần đá vôi; soda làm mềm nước cứng | nước cứng tạm thời, vĩnh cửu, toàn phần; kết tủa, trao đổi ion |

**Ba bước giải mọi bài của chương:**

1. **Xác định nhóm:** kim loại hay ion thuộc IA (hoá trị 1) hay IIA (hoá trị 2)? Từ đó chọn đúng tỉ lệ H~2~, OH^−^ và công thức muối.
2. **Xác định tính tan và độ bền:** chất nào kết tủa, chất nào tan, chất nào bị nhiệt phân và sản phẩm là gì (Na~2~CO~3~ bền, MCO~3~ ra MO, NaHCO~3~ ra Na~2~CO~3~).
3. **Tính theo mol và bảo toàn:** bảo toàn khối lượng khi nung, n(OH^−^) = 2n(H~2~), tỉ lệ T khi hấp thụ CO~2~, n(kết tủa) lấy theo chất hết trước.
