---
title: Nguyên tố nhóm IA
thoi-gian: 45 phút
muc-tieu:
  - Nêu được trạng thái tự nhiên của nguyên tố nhóm IA và giải thích vì sao chúng chỉ tồn tại ở dạng hợp chất.
  - Nêu được xu hướng biến đổi nhiệt độ nóng chảy, nhiệt độ sôi; giải thích được vì sao kim loại nhóm IA nhẹ và mềm.
  - Giải thích được vì sao kim loại nhóm IA có tính khử mạnh hơn các nhóm kim loại khác; mô tả được mức độ phản ứng tăng dần từ Li, Na đến K với nước, chlorine, oxygen.
  - Trình bày được cách bảo quản kim loại nhóm IA; nêu được tính tan của hợp chất nhóm IA và phân biệt ion Li^+^, Na^+^, K^+^ bằng màu ngọn lửa.
  - Trình bày được ứng dụng của NaCl và quá trình điện phân dung dịch NaCl trong công nghiệp chlorine – kiềm.
  - Giải thích được ứng dụng của NaHCO~3~, Na~2~CO~3~ và phương pháp Solvay sản xuất soda; giải được các bài toán thường gặp về kim loại kiềm và muối carbonate.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Nhóm IA (Li, Na, K, Rb, Cs, Fr) là **kim loại kiềm**, chỉ có **1 electron** lớp ngoài cùng (ns^1^). Chúng dễ nhường electron này: M → M^+^ + 1e, nên có **tính khử rất mạnh**, tăng dần từ Li đến Cs. Trong hợp chất chỉ có số oxi hoá **+1**.
> 2. Vì quá hoạt động, trong tự nhiên chúng **chỉ có ở dạng hợp chất** (NaCl, KCl…). Kim loại kiềm được **bảo quản trong dầu hoả** khan, chân không hoặc khí hiếm.
> 3. Kim loại kiềm **mềm** (cắt được bằng dao), **nhẹ**, nóng chảy thấp. Nhiệt độ nóng chảy, nhiệt độ sôi **giảm dần** từ Li đến Cs.
> 4. Hợp chất nhóm IA thường **dễ tan**, là chất điện li mạnh. Màu ngọn lửa: Li^+^ **đỏ tía**, Na^+^ **vàng**, K^+^ **tím nhạt**.
> 5. **NaCl**: điện phân dung dịch có màng ngăn → NaOH + Cl~2~ + H~2~. **NaHCO~3~** kém bền nhiệt, dùng làm bột nở, thuốc giảm chua. **Na~2~CO~3~** dùng làm thuỷ tinh, xà phòng, làm mềm nước. Cả hai được sản xuất bằng **phương pháp Solvay**.

Pin điện thoại là pin **lithium**, muối ăn và bột nở là hợp chất của **sodium**, phân kali chứa **potassium** (SGK tr. 108, Hình 24.1). Bài này giải thích vì sao các kim loại này "hăng hái" đến mức phải ngâm trong dầu hoả, và các hợp chất quan trọng của chúng được sản xuất thế nào.

## 1. Đơn chất nhóm IA

### 1.1. Đặc điểm chung

Nhóm IA gồm lithium (Li), sodium (Na), potassium (K), rubidium (Rb), caesium (Cs) và francium (Fr). Francium là nguyên tố phóng xạ, rất hiếm, nên SGK chỉ xét năm nguyên tố đầu. Kim loại nhóm IA còn gọi là **kim loại kiềm**, vì hydroxide của chúng (NaOH, KOH…) là những base mạnh, tan tốt (gọi là kiềm).

> [!nen-tang] Bán kính nguyên tử và năng lượng ion hoá (lớp 10)
> - Trong một nhóm A, đi từ trên xuống, số lớp electron **tăng**, nên bán kính nguyên tử **tăng**.
> - Electron ngoài cùng càng xa hạt nhân thì bị hút càng yếu, càng dễ tách ra. Nói cách khác, năng lượng ion hoá thứ nhất **giảm**, tính kim loại **tăng**.
> - Trong một chu kì, đi từ trái sang phải, bán kính **giảm**. Nguyên tố nhóm IA đứng **đầu** chu kì, nên có bán kính **lớn nhất** trong chu kì.

Đọc Bảng 24.1 (SGK tr. 109), em rút ra ba điều:

| Nguyên tố | Cấu hình | Bán kính (pm) | E°(M^+^/M) (V) |
|---|---|---|---|
| Li | [He]2s^1^ | 152 | −3,040 |
| Na | [Ne]3s^1^ | 186 | −2,713 |
| K | [Ar]4s^1^ | 227 | −2,924 |
| Rb | [Kr]5s^1^ | 248 | −2,924 |
| Cs | [Xe]6s^1^ | 265 | −2,923 |

1. **Cấu hình**: nguyên tố nhóm IA là **nguyên tố s**, chỉ có **1 electron hoá trị** ở phân lớp ns^1^. Mỗi nguyên tố đứng **đầu một chu kì**.
2. **Bán kính tăng dần** từ Li đến Cs (thêm một lớp electron mỗi chu kì).
3. **Thế điện cực chuẩn rất âm** (khoảng −2,7 V đến −3,0 V), âm hơn hẳn các kim loại khác như Mg (−2,356 V), Al, Zn, Fe.

**Vì sao kim loại kiềm có tính khử mạnh hơn mọi nhóm kim loại khác?** Hãy tưởng tượng electron ns^1^ như một quả bóng buộc lỏng vào hạt nhân bằng sợi dây dài. Nguyên tử chỉ có **một** electron ngoài cùng, lại có **bán kính lớn nhất** trong chu kì, nên electron này bị hạt nhân hút yếu. Mất electron này, nguyên tử đạt cấu hình bền của khí hiếm đứng trước (Na^+^ giống Ne). Vì vậy chúng nhường electron rất dễ:

=> M → M^+^ + 1e

Từ đó suy ra: trong mọi hợp chất, kim loại nhóm IA **chỉ có số oxi hoá +1**. Đi từ Li đến Cs, bán kính tăng nên electron càng dễ tách: **tính khử tăng dần từ Li đến Cs**.

![Hình 1. Đi từ Li đến Cs, bán kính nguyên tử tăng, tính khử tăng, còn nhiệt độ nóng chảy giảm dần (số liệu SGK Bảng 24.1, 24.2; vòng tròn vẽ tỉ lệ với bán kính)](xu-huong.svg)

> [!bay] E° của Li âm nhất nhưng Li không phải kim loại "mạnh nhất" khi phản ứng với nước
> Nhìn bảng, E°(Li^+^/Li) = −3,040 V là âm nhất. Nhiều bạn kết luận "Li phản ứng với nước mãnh liệt nhất". **Sai**. Thí nghiệm cho thấy Li phản ứng **chậm nhất**, K phản ứng mạnh nhất (mục 1.4). Khi làm bài, em nhớ theo SGK: **tính khử và mức độ phản ứng tăng dần từ Li đến Cs**.
>
> (Mở rộng, ngoài SGK: E° cho biết phản ứng **có xảy ra được không**, chứ không cho biết **nhanh hay chậm**. Ion Li^+^ rất nhỏ nên được các phân tử nước bao quanh rất chặt, làm E° âm hơn. Nhưng Li có nhiệt độ nóng chảy cao, mẩu Li không chảy ra khi phản ứng, nên bề mặt tiếp xúc với nước ít và phản ứng chậm.)

> [!vi-du] Ví dụ 1
> Nguyên tử X có cấu hình electron [Ne]3s^1^.
>
> a) X thuộc chu kì nào, nhóm nào? X là nguyên tố gì?
>
> b) Viết cấu hình electron của ion X^+^. Ion này có cấu hình giống khí hiếm nào?

> [!goi-y] Gợi ý 1
> Số lớp electron = số thứ tự chu kì. Electron cuối cùng ở phân lớp s, có 1 electron lớp ngoài cùng.

> [!goi-y] Gợi ý 2
> X nhường 1 electron ở lớp ngoài cùng (3s^1^). Còn lại cấu hình gì?

> [!loi-giai] Lời giải
> a) [Ne]3s^1^ = 1s^2^2s^2^2p^6^3s^1^, có 3 lớp electron, 1 electron lớp ngoài cùng ở phân lớp s. Vậy X ở **chu kì 3, nhóm IA**, Z = 11, X là **sodium (Na)**.
>
> b) Na → Na^+^ + 1e. Cấu hình của Na^+^ là **1s^2^2s^2^2p^6^**, giống khí hiếm **neon**.

### 1.2. Trạng thái tự nhiên

Trong tự nhiên, nguyên tố nhóm IA **chỉ tồn tại ở dạng hợp chất**, chủ yếu là **muối**. Sodium và potassium phổ biến nhất trong vỏ Trái Đất. Chúng có nhiều trong **nước biển**, **mỏ muối**, quặng **halite** (NaCl) và quặng **sylvinite** (NaCl.KCl).

**Vì sao không có kim loại kiềm tự do trong tự nhiên?** (câu hỏi 1, SGK tr. 109). Kim loại kiềm có tính khử rất mạnh, phản ứng ngay với nước, oxygen, chlorine… có xung quanh. Nếu từng có Na tự do, nó đã bị chuyển hết thành hợp chất từ lâu. Ngược lại, vàng có tính khử rất yếu nên mới tìm thấy ở dạng tự do (Bài 20).

### 1.3. Tính chất vật lí

Bảng 24.2 (SGK tr. 110) cho một số thông số vật lí:

| Kim loại | t~nc~ (°C) | t~s~ (°C) | D (g/cm^3^) | Độ cứng |
|---|---|---|---|---|
| Li | 180,5 | 1341 | 0,534 | 0,6 |
| Na | 97,8 | 881 | 0,968 | 0,5 |
| K | 63,4 | 759 | 0,89 | 0,4 |
| Rb | 39,3 | 691 | 1,532 | 0,3 |
| Cs | 28,4 | 668 | 1,878 | 0,2 |

(t~nc~: nhiệt độ nóng chảy; t~s~: nhiệt độ sôi; D: khối lượng riêng; độ cứng theo thang kim cương = 10.)

**a) Nhiệt độ nóng chảy và nhiệt độ sôi: thấp, giảm dần từ Li đến Cs**

Kim loại kiềm đều **dễ nóng chảy**, nóng chảy ở nhiệt độ thấp hơn các kim loại nhóm khác (so với sắt nóng chảy trên 1 500 °C). Na nóng chảy dưới 100 °C, tức là thấp hơn nhiệt độ nước sôi. Cs nóng chảy ở 28,4 °C: một ống thuỷ tinh hàn kín đựng Cs, cầm trong lòng bàn tay một lúc là Cs chảy lỏng.

**Vì sao?** Nhớ lại Bài 18: liên kết kim loại là lực hút giữa ion dương và "biển" electron tự do. Mỗi nguyên tử kim loại kiềm chỉ góp **1 electron** vào biển electron, và ion M^+^ lại **to**. Lực hút giữa chúng yếu, nên chỉ cần ít nhiệt là phá được mạng tinh thể. Đi từ Li đến Cs, ion càng to, liên kết càng yếu, nên nhiệt độ nóng chảy, nhiệt độ sôi **giảm dần**.

**b) Khối lượng riêng nhỏ**

Kim loại kiềm đều là **kim loại nhẹ** (khối lượng riêng nhỏ hơn 5 g/cm^3^). Li, Na, K còn nhẹ hơn nước (D < 1 g/cm^3^), nên **nổi** trên mặt nước khi phản ứng. Li là kim loại nhẹ nhất.

**Vì sao nhẹ?** Theo SGK, có hai lí do: **bán kính nguyên tử lớn** (mỗi nguyên tử chiếm nhiều chỗ) và **mạng tinh thể kém đặc khít** (giữa các nguyên tử còn nhiều khoảng trống). Cùng một thể tích, chứa được ít nguyên tử hơn nên nhẹ.

**c) Độ cứng thấp**

Liên kết kim loại **yếu**, các lớp nguyên tử dễ trượt lên nhau, nên kim loại kiềm rất **mềm**, cắt được bằng dao, kéo. Độ cứng giảm dần từ Li (0,6) đến Cs (0,2).

> [!bay]
> - Khối lượng riêng **không** tăng đều: K (0,89) **nhẹ hơn** Na (0,968). Đề hay hỏi "kim loại nhẹ nhất" (Li) hoặc "những kim loại nhẹ hơn nước" (Li, Na, K).
> - Nhiệt độ nóng chảy **giảm** từ Li đến Cs, ngược chiều với tính khử (tăng). Đừng nhầm hai xu hướng này.

> [!vi-du] Ví dụ 2
> Một ngày hè ở Hà Nội, nhiệt độ trong phòng là 35 °C. Dựa vào Bảng 24.2, cho biết:
>
> a) Ở nhiệt độ này, kim loại kiềm nào ở thể lỏng?
>
> b) Thả mẩu Li, Na, K, Rb vào một chất lỏng trơ có khối lượng riêng 1,0 g/cm^3^. Mẩu nào nổi, mẩu nào chìm?

> [!goi-y] Gợi ý 1
> Kim loại ở thể lỏng khi nhiệt độ môi trường **cao hơn** nhiệt độ nóng chảy và thấp hơn nhiệt độ sôi.

> [!goi-y] Gợi ý 2
> Vật nổi khi khối lượng riêng của nó **nhỏ hơn** khối lượng riêng của chất lỏng.

> [!loi-giai] Lời giải
> a) Chỉ **Cs** có nhiệt độ nóng chảy (28,4 °C) thấp hơn 35 °C, nên Cs ở thể lỏng. Rb nóng chảy ở 39,3 °C > 35 °C nên vẫn rắn.
>
> b) Li (0,534), Na (0,968), K (0,89) nhỏ hơn 1,0 nên **nổi**. Rb (1,532) lớn hơn 1,0 nên **chìm**.

### 1.4. Tính chất hoá học

Kim loại kiềm là những kim loại **hoạt động hoá học mạnh**. Tính khử **tăng dần từ Li đến Cs**. SGK (tr. 111) mô tả ba thí nghiệm với Li, Na, K. Em đọc thí nghiệm, rồi tự hỏi: phương trình là gì, và vì sao mức độ khác nhau.

**a) Tác dụng với nước**

Thả mẩu kim loại nhỏ vào chậu nước:

| Kim loại | Hiện tượng (tóm tắt Bảng 24.3) |
|---|---|
| Li | Chuyển động **chậm** trên mặt nước |
| Na | Chảy thành **giọt tròn**, chạy **nhanh** trên mặt nước |
| K | **Bốc cháy**, có tiếng nổ nhẹ |

Mức độ phản ứng: **Li < Na < K**. Phương trình chung:

=> 2M + 2H~2~O → 2MOH + H~2~↑    (M là Li, Na, K…)

Ví dụ: 2Na + 2H~2~O → 2NaOH + H~2~ và 2K + 2H~2~O → 2KOH + H~2~.

**Giải thích hiện tượng:**

- Mẩu kim loại **nổi** vì nhẹ hơn nước (mục 1.3).
- Phản ứng **toả nhiều nhiệt**. Na có nhiệt độ nóng chảy thấp (97,8 °C), nên nóng chảy thành giọt tròn. Khí H~2~ sinh ra đẩy giọt Na chạy trên mặt nước.
- Với K, phản ứng toả nhiệt mạnh đến mức H~2~ bốc cháy trong không khí, có tiếng nổ nhẹ.

**Nhận biết môi trường dung dịch sau phản ứng**: dung dịch chứa MOH là base mạnh, làm **phenolphthalein hoá hồng**, quỳ tím hoá xanh.

**Dùng E° để giải thích** (Bài 19 mục 2.2): về lí thuyết, kim loại có E° < −0,414 V có thể khử nước. Mg, Al, Zn, Fe tuy thoả điều kiện này nhưng bị lớp oxide, hydroxide không tan che phủ nên thực tế hầu như không phản ứng với nước ở nhiệt độ thường. Kim loại kiềm có E° rất âm (−2,7 V đến −3,0 V) và hydroxide MOH tan tốt, không tạo lớp che phủ, nên **tất cả** đều phản ứng với nước ngay ở nhiệt độ thường.

> [!vi-du] Ví dụ 3
> Cho 9,75 g potassium vào 90,5 g nước (dư). Tính thể tích khí H~2~ thoát ra ở điều kiện chuẩn (25 °C, 1 bar) và nồng độ phần trăm của dung dịch thu được.

> [!goi-y] Gợi ý 1
> 2K + 2H~2~O → 2KOH + H~2~. 2 mol K cho 2 mol KOH và **1** mol H~2~. Ở điều kiện chuẩn, 1 mol khí chiếm 24,79 L.

> [!goi-y] Gợi ý 2
> Khối lượng dung dịch = m(K) + m(nước) − m(H~2~ bay ra).

> [!loi-giai] Lời giải
> n(K) = 9,75 : 39 = 0,25 mol → n(KOH) = 0,25 mol, n(H~2~) = 0,125 mol.
>
> V(H~2~) = 0,125 · 24,79 ≈ **3,10 L**.
>
> m(dung dịch) = 9,75 + 90,5 − 0,125 · 2 = 100 g. m(KOH) = 0,25 · 56 = 14 g.
>
> C%(KOH) = 14 : 100 · 100% = **14%**.

**b) Tác dụng với chlorine**

Hơ nóng chảy mẩu kim loại trong muôi sắt rồi đưa nhanh vào bình khí chlorine: kim loại **bốc cháy**, mức độ tăng dần từ Li đến K. Sản phẩm là muối chloride (khói trắng):

=> 2M + Cl~2~ → 2MCl

Ví dụ: 2Na + Cl~2~ → 2NaCl.

**c) Tác dụng với oxygen**

Làm tương tự với bình khí oxygen: kim loại bốc cháy, mức độ tăng dần từ Li đến K. Phương trình dạng chung (tạo oxide M~2~O):

=> 4M + O~2~ → 2M~2~O

Ví dụ: 4Li + O~2~ → 2Li~2~O. Trong không khí ẩm, mặt cắt sáng bóng của Na, K **mờ đi rất nhanh** vì bị oxygen và hơi nước tấn công.

> [!em-co-biet] Sản phẩm cháy thật sự (mở rộng, ngoài SGK)
> Khi **đốt cháy** trong oxygen (dư), chỉ Li cho oxide thường Li~2~O. Na cháy cho chủ yếu sodium peroxide Na~2~O~2~ (2Na + O~2~ → Na~2~O~2~). K cháy cho KO~2~. Bài tập ở lớp 12 thường chỉ dùng dạng chung M~2~O, trừ khi đề nói rõ sản phẩm.

**Trả lời câu hỏi 2 (SGK tr. 112).**

- **Vì sao chỉ lấy mẩu kim loại nhỏ?** Phản ứng với nước toả nhiều nhiệt và sinh khí H~2~ dễ cháy nổ. Mẩu lớn làm phản ứng quá mãnh liệt: kim loại nóng chảy, bắn tung toé, H~2~ có thể nổ, dung dịch kiềm đặc bắn vào người gây bỏng.
- **Vì sao dùng sodium để loại nước khỏi ether?** Na phản ứng với vết nước có trong ether (2Na + 2H~2~O → 2NaOH + H~2~), còn ether **không** phản ứng với Na. Nước bị "ăn" hết, NaOH rắn được lọc bỏ, ta thu được ether khan.

### 1.5. Bảo quản

Kim loại nhóm IA được bảo quản **trong dầu hoả** (khan), **trong chân không** hoặc **trong khí hiếm**. Ví dụ: Na, K ngâm trong dầu hoả khan. Rb, Cs đựng trong ống thuỷ tinh hàn kín (SGK tr. 112, Hình 24.2).

**Vì sao ngâm được trong dầu hoả?** (câu hỏi 3a). Dầu hoả là hỗn hợp **hydrocarbon**: không chứa nước, không chứa nhóm –OH, nên **không phản ứng** với Na, K. Na, K nặng hơn dầu hoả nên chìm hẳn trong dầu, được dầu bao kín, cách li với **oxygen** và **hơi nước** trong không khí.

**Có dùng ethanol để bảo quản được không?** (câu hỏi 3b). **Không**. Ethanol có nhóm –OH, phản ứng với kim loại kiềm giống như nước (chậm hơn):

=> 2C~2~H~5~OH + 2Na → 2C~2~H~5~ONa + H~2~↑

Ngâm Na trong ethanol, Na sẽ bị "ăn" dần. Đây chính là phản ứng nhận biết alcohol em đã học ở lớp 11.

> [!bay]
> Không bảo quản kim loại kiềm trong **nước**, **ethanol**, **glycerol** hay chất lỏng có lẫn nước. Chỉ dùng dầu hoả **khan**, chân không hoặc khí hiếm.

## 2. Hợp chất của kim loại nhóm IA

### 2.1. Đặc điểm chung

- Hợp chất của kim loại kiềm **thường dễ tan trong nước**, tạo dung dịch **chất điện li mạnh**. Ví dụ: NaCl, KNO~3~, Na~2~CO~3~, NaOH đều tan tốt và phân li hoàn toàn thành ion.
- Ở nhiệt độ thường, các ion Li^+^, Na^+^, K^+^ đều **không màu**. Dung dịch NaCl, KCl trong suốt như nước.
- Khi **đốt nóng** kim loại kiềm hoặc hợp chất của chúng trên ngọn lửa không màu, ngọn lửa có **màu đặc trưng**. Đây là cách nhận biết hợp chất của kim loại nhóm IA.

**Thí nghiệm màu ngọn lửa** (SGK tr. 112): nhúng dây platinum (hoặc nickel) sạch vào dung dịch LiCl bão hoà, rồi hơ đầu dây trên ngọn lửa đèn khí. Làm tương tự với NaCl, KCl.

| Ion | Li^+^ | Na^+^ | K^+^ |
|---|---|---|---|
| Màu ngọn lửa | **đỏ tía** | **vàng** | **tím nhạt** |

**Vì sao có màu?** (mở rộng) Nhiệt đẩy electron lên mức năng lượng cao hơn. Khi rơi về mức cũ, electron phát ra ánh sáng có màu xác định, riêng cho từng nguyên tố, giống "vân tay" của nguyên tố.

> [!ung-dung] Màu ngọn lửa quanh ta
> - Nồi canh trào ra bếp gas làm ngọn lửa xanh chuyển sang **vàng**: đó là Na^+^ trong muối ăn.
> - Đèn đường cao áp phát ánh sáng vàng cam dùng hơi sodium.
> - Pháo hoa có màu nhờ muối kim loại: muối sodium cho màu vàng, muối lithium (và strontium, sẽ học ở Bài 25) cho màu đỏ.

> [!meo] Nhớ màu ngọn lửa
> "**Li** đỏ – **Na** vàng – **K** tím": đi từ Li đến K, màu chuyển từ đỏ, qua vàng, đến tím, giống thứ tự đỏ → vàng → tím của cầu vồng.

> [!vi-du] Ví dụ 4
> Có ba lọ mất nhãn, mỗi lọ chứa một trong các chất rắn: LiCl, NaCl, KCl. Bằng một phép thử, hãy nhận biết từng chất. Vì sao không dùng dung dịch AgNO~3~ được?

> [!goi-y] Gợi ý 1
> Ba muối có chung anion Cl^−^, chỉ khác cation. Phép thử nào phân biệt được cation kim loại kiềm?

> [!goi-y] Gợi ý 2
> AgNO~3~ phản ứng với ion nào trong ba muối?

> [!loi-giai] Lời giải
> Lấy mỗi chất một ít, dùng dây platinum sạch chấm vào rồi hơ lên ngọn lửa không màu. Ngọn lửa **đỏ tía** là LiCl, **vàng** là NaCl, **tím nhạt** là KCl.
>
> Không dùng AgNO~3~ được, vì cả ba muối đều chứa Cl^−^, đều cho cùng một kết tủa trắng AgCl. Muối Li^+^, Na^+^, K^+^ hầu như đều tan, nên khó tìm thuốc thử tạo kết tủa riêng với từng cation. Vì vậy màu ngọn lửa là cách đơn giản nhất.

### 2.2. Hợp chất quan trọng

**a) Sodium chloride (NaCl)**

**Ứng dụng** (SGK tr. 113):

- **Đời sống**: gia vị, bảo quản và chế biến thực phẩm (muối dưa, cà, cá…).
- **Y học**: nước muối sinh lí (NaCl 0,9%), chất điện giải bù nước cho người bị tiêu chảy, mất nước.
- **Công nghiệp hoá chất**: nguyên liệu sản xuất **chlorine – kiềm** (Cl~2~, NaOH), **nước Javel**, **soda** (Na~2~CO~3~)…

**Điện phân dung dịch NaCl trong công nghiệp chlorine – kiềm.** Phần này em đã học kĩ ở Bài 16 (mục 2.2). Ở đây ta nhìn lại dưới góc độ sản xuất.

![Hình 2. Điện phân dung dịch NaCl bão hoà có màng ngăn (sơ đồ đơn giản hoá, tự vẽ theo ý Hình 24.4 SGK tr. 113)](dien-phan.svg)

Dung dịch NaCl bão hoà có các ion Na^+^, Cl^−^ và phân tử nước.

- **Cathode (cực âm)**: Na^+^ có tính oxi hoá quá yếu, nên **nước bị khử**, 2H~2~O + 2e → H~2~ + 2OH^−^.
- **Anode (cực dương)**: Cl^−^ bị oxi hoá, 2Cl^−^ → Cl~2~ + 2e.

Phương trình điện phân có màng ngăn:

=> 2NaCl + 2H~2~O → 2NaOH + H~2~↑ + Cl~2~↑

**Vì sao cần màng ngăn?** Nếu Cl~2~ sinh ra ở anode gặp OH^−^ sinh ra ở cathode, chúng phản ứng với nhau (Cl~2~ + 2NaOH → NaCl + NaClO + H~2~O) và ta mất cả hai sản phẩm quý. Màng ngăn xốp giữ Cl~2~ ở vùng anode, chỉ cho ion Na^+^ đi qua sang vùng cathode để cùng với OH^−^ tạo NaOH.

Theo SGK, trong công nghiệp:

- Điện phân **có màng ngăn** → **xút** NaOH, khí **chlorine** Cl~2~ (và H~2~).
- Điện phân **không có màng ngăn** → **nước Javel** (chứa NaCl và NaClO): NaCl + H~2~O → NaClO + H~2~.

Thùng điện phân công nghiệp có anode bằng **than chì**, cathode bằng **sắt**. Nước muối bão hoà (khoảng 300 g/L) được đưa vào liên tục, nước muối loãng hơn (khoảng 200 g/L) đi ra, phía cathode thu dung dịch NaOH khoảng 32% (SGK tr. 113, mục Em có biết).

> [!bay]
> - Điện phân **dung dịch** NaCl **không** thu được Na. Muốn có Na phải điện phân NaCl **nóng chảy** (Bài 16, Bài 20).
> - Ở cathode là **nước** bị khử (sinh H~2~ và OH^−^), không phải Na^+^.

> [!vi-du] Ví dụ 5
> Một nhà máy điện phân dung dịch chứa 2,34 tấn NaCl (có màng ngăn) với hiệu suất 75%.
>
> a) Tính khối lượng NaOH thu được.
>
> b) Tính thể tích khí Cl~2~ thu được ở điều kiện chuẩn (làm tròn đến hàng đơn vị, đơn vị m^3^).

> [!goi-y] Gợi ý 1
> Đổi đơn vị cho gọn: 2,34 tấn = 2 340 kg. Khi khối lượng tính bằng kg thì số mol tính bằng **kmol**, và 1 kmol khí ở điều kiện chuẩn chiếm 24,79 m^3^.

> [!goi-y] Gợi ý 2
> Theo phương trình: 2 NaCl → 2 NaOH + 1 Cl~2~. Đi xuôi (từ nguyên liệu ra sản phẩm) thì **nhân** hiệu suất.

> [!loi-giai] Lời giải
> n(NaCl) = 2 340 : 58,5 = 40 kmol.
>
> a) m(NaOH) = 40 · 40 · 0,75 = **1 200 kg** (1,2 tấn).
>
> b) n(Cl~2~) = 40 : 2 · 0,75 = 15 kmol → V = 15 · 24,79 ≈ **372 m^3^**.

**b) Sodium hydrogencarbonate (NaHCO~3~) và sodium carbonate (Na~2~CO~3~)**

**Sodium hydrogencarbonate** (baking soda, "thuốc muối") là chất rắn màu trắng, **kém bền nhiệt**: bắt đầu bị phân huỷ ở khoảng 120 °C.

=> 2NaHCO~3~ → Na~2~CO~3~ + CO~2~ + H~2~O    (t°)

Từ tính chất này và tính chất tác dụng với acid, ta giải thích được các ứng dụng (câu hỏi SGK tr. 114):

| Ứng dụng | Cơ sở hoá học |
|---|---|
| **Bột nở** làm bánh | Khi nướng, NaHCO~3~ phân huỷ sinh khí CO~2~ và hơi nước. Khí thoát ra làm bánh phồng, xốp. |
| **Bình chữa cháy dạng bột** | Gặp nhiệt, NaHCO~3~ phân huỷ: phản ứng **thu nhiệt** làm giảm nhiệt độ. CO~2~ và hơi nước sinh ra **đẩy oxygen** ra khỏi đám cháy. |
| **Viên sủi** (NaHCO~3~ + acid hữu cơ HX) | Khi thả vào nước, hai chất tan ra và phản ứng: NaHCO~3~ + HX → NaX + CO~2~↑ + H~2~O. Khí CO~2~ tạo bọt. |
| **Xử lí nước dư acid** | HCO~3~^−^ "trung hoà" ion H^+^: HCO~3~^−^ + H^+^ → CO~2~ + H~2~O, nên pH tăng lên. |

**Sodium carbonate** (soda) là chất rắn màu trắng, **bền nhiệt** (không bị phân huỷ khi đun nóng thông thường), tan tốt trong nước tạo dung dịch có tính base. Ứng dụng (SGK tr. 114):

- Nguyên liệu sản xuất **thuỷ tinh**, **xà phòng**, bột giặt, giấy, sợi, chất tẩy rửa.
- **Xử lí, làm mềm nước**, điều chế các muối khác.
- Tẩy sạch vết dầu mỡ trên chi tiết máy trước khi sơn, hàn, mạ điện.

**Hai ứng dụng xử lí nước của Na~2~CO~3~** (SGK tr. 114):

*1. Làm mềm nước.* Nước cứng chứa nhiều ion Mg^2+^, Ca^2+^ (sẽ học ở Bài 25). Ion CO~3~^2−^ kết tủa các ion này:

=> Ca^2+^ + CO~3~^2−^ → CaCO~3~↓

=> Mg^2+^ + CO~3~^2−^ → MgCO~3~↓

*2. Xử lí nước nhiễm phèn* (chứa Fe^3+^). Tạo kết tủa Fe(OH)~3~ màu nâu đỏ rồi lọc bỏ:

=> 2Fe^3+^ + 3CO~3~^2−^ + 3H~2~O → 2Fe(OH)~3~↓ + 3CO~2~↑

**Vì sao không tạo Fe~2~(CO~3~)~3~?** Muối này không tồn tại trong nước: ion Fe^3+^ có tính acid, CO~3~^2−^ có tính base, hai ion cùng phản ứng với nước cho Fe(OH)~3~ kết tủa và khí CO~2~.

> [!bay]
> - **NaHCO~3~ kém bền nhiệt**, Na~2~CO~3~ **bền nhiệt**. Nung Na~2~CO~3~ không thu được CO~2~.
> - Bột nở hoạt động nhờ khí **CO~2~**, không phải nhờ H~2~ hay O~2~.
> - "Soda" là Na~2~CO~3~, còn "baking soda" là NaHCO~3~. Xút (NaOH) **khác** soda.

**Sản xuất: phương pháp Solvay.** Trong công nghiệp, NaHCO~3~ và Na~2~CO~3~ được sản xuất bằng **phương pháp Solvay**, từ nguyên liệu chính là **đá vôi, muối ăn, ammonia và nước** (SGK tr. 114–115). Quá trình gồm hai giai đoạn chính.

*Giai đoạn 1: tạo NaHCO~3~.* Nước muối bão hoà được hấp thụ NH~3~, rồi sục CO~2~ trong tháp carbonate hoá:

=> NaCl + NH~3~ + CO~2~ + H~2~O ⇌ NaHCO~3~ + NH~4~Cl

Khi **làm lạnh**, NaHCO~3~ kết tinh, được **lọc** tách khỏi hệ phản ứng.

*Giai đoạn 2: tạo Na~2~CO~3~.* Nung NaHCO~3~:

=> 2NaHCO~3~ → Na~2~CO~3~ + CO~2~ + H~2~O    (t°)

**Vì sao NaHCO~3~ lại tách ra được?** Trong dung dịch có bốn loại ion Na^+^, NH~4~^+^, Cl^−^, HCO~3~^−^, có thể ghép thành bốn muối NaCl, NH~4~Cl, NaHCO~3~, NH~4~HCO~3~. Trong bốn muối này, NaHCO~3~ **ít tan nhất**, nhất là khi lạnh, nên nó kết tinh trước. NaHCO~3~ rời khỏi dung dịch làm cân bằng chuyển dịch sang phải, tạo thêm NaHCO~3~. (Mở rộng: ở 20 °C, khoảng 9–10 g NaHCO~3~ tan trong 100 g nước, trong khi NaCl, NH~4~Cl tan khoảng 36–37 g.)

![Hình 3. Sơ đồ quá trình Solvay: đường liền là dòng nguyên liệu – sản phẩm; đường nét đứt là các chất được quay vòng (tự vẽ theo ý Hình 24.5 SGK tr. 115)](solvay.svg)

**Nguồn CO~2~ và NH~3~** (câu hỏi 4a, SGK tr. 115):

Nung đá vôi để có vôi sống và CO~2~:

=> CaCO~3~ → CaO + CO~2~    (t°)

Tái chế ammonia từ vôi sống và dung dịch NH~4~Cl (vôi sống tác dụng với nước tạo Ca(OH)~2~):

=> CaO + H~2~O → Ca(OH)~2~

=> Ca(OH)~2~ + 2NH~4~Cl → CaCl~2~ + 2NH~3~↑ + 2H~2~O

**Vì sao quy trình Solvay "thân thiện" hơn với môi trường?** (câu hỏi 4b). Nhìn Hình 3:

- **CO~2~** sinh ra khi nung NaHCO~3~ được đưa **quay lại** tháp carbonate hoá. Lượng CO~2~ còn thiếu lấy từ lò nung đá vôi.
- **NH~3~** không bị mất đi: nó chuyển thành NH~4~Cl, rồi được **tái tạo** bằng Ca(OH)~2~ và quay lại đầu quy trình.
- Nhờ quay vòng, nhà máy ít thải CO~2~ và NH~3~ ra không khí, đồng thời tiết kiệm nguyên liệu.

Cộng tất cả các phản ứng lại (NH~3~ và phần CO~2~ quay vòng triệt tiêu), ta được **phương trình tổng** của quá trình:

=> 2NaCl + CaCO~3~ → Na~2~CO~3~ + CaCl~2~

Như vậy, thực chất Solvay "đổi" muối ăn và đá vôi thành soda, với **sản phẩm phụ** là **CaCl~2~**.

> [!meo] Dùng phương trình tổng để tính nhanh
> Bài toán Solvay chỉ hỏi lượng NaCl, đá vôi và soda thì dùng thẳng: **2NaCl → Na~2~CO~3~** và **CaCO~3~ → Na~2~CO~3~**. Nhớ hệ số **2** của NaCl.

## Dạng bài thi hay gặp

### Dạng 1. Kim loại kiềm tác dụng với nước

**Nhận biết:** cho kim loại kiềm (hoặc hỗn hợp) vào nước, đề hỏi thể tích H~2~, nồng độ dung dịch, pH, lượng acid để trung hoà dung dịch, hoặc hỏi tên kim loại.

**Phương pháp:**

1. 2M + 2H~2~O → 2MOH + H~2~. Nhớ hai tỉ lệ: **n(H~2~) = n(M) : 2** và **n(OH^−^) = n(M) = 2n(H~2~)**.
2. Khối lượng dung dịch = m(kim loại) + m(nước) − m(H~2~).
3. Trung hoà dung dịch bằng acid: n(H^+^) = n(OH^−^) = 2n(H~2~).
4. Hỗn hợp **hai kim loại kiềm thuộc hai chu kì liên tiếp**: tính khối lượng mol trung bình M̄ = m : n, rồi tìm hai kim loại có M kẹp M̄ (Li 7, Na 23, K 39, Rb 85,5, Cs 133).

> [!vi-du] Ví dụ 6
> Cho 3,1 g hỗn hợp hai kim loại kiềm thuộc hai chu kì liên tiếp vào nước dư, thu được 1,2395 L khí H~2~ (điều kiện chuẩn) và dung dịch X.
>
> a) Xác định hai kim loại và phần trăm khối lượng của mỗi kim loại.
>
> b) Tính thể tích dung dịch HCl 0,5 M cần để trung hoà hết X.

> [!goi-y] Gợi ý 1
> Gọi chung hai kim loại là M. n(M) = 2 · n(H~2~). Từ đó tính M̄.

> [!goi-y] Gợi ý 2
> Biết hai kim loại rồi, lập hệ hai phương trình: tổng số mol và tổng khối lượng. Với câu b, n(HCl) = n(OH^−^) = n(M).

> [!loi-giai] Lời giải
> n(H~2~) = 1,2395 : 24,79 = 0,05 mol → n(M) = 0,1 mol → M̄ = 3,1 : 0,1 = 31.
>
> a) 23 < 31 < 39, nên hai kim loại là **Na** và **K**. Gọi x = n(Na), y = n(K): x + y = 0,1 và 23x + 39y = 3,1. Giải ra x = y = 0,05.
>
> %Na = 0,05 · 23 : 3,1 · 100% ≈ **37,1%**, %K ≈ **62,9%**.
>
> b) n(HCl) = n(OH^−^) = 0,1 mol → V = 0,1 : 0,5 = 0,2 L = **200 mL**.

> [!bay]
> - n(H~2~) bằng **một nửa** số mol kim loại kiềm. Quên chia 2 là lỗi hay gặp nhất.
> - Khối lượng dung dịch phải **trừ** khối lượng H~2~ bay ra.
> - Ở điều kiện chuẩn (25 °C, 1 bar), 1 mol khí chiếm **24,79 L**. Chỉ dùng 22,4 L khi đề nói điều kiện tiêu chuẩn cũ (0 °C, 1 atm).

### Dạng 2. NaHCO~3~, Na~2~CO~3~: nhiệt phân và tác dụng với acid

**Nhận biết:** nung hỗn hợp có NaHCO~3~ đến khối lượng không đổi, hoặc cho muối carbonate tác dụng với acid, đề hỏi khối lượng chất rắn, thể tích CO~2~, thành phần hỗn hợp.

**Phương pháp:**

1. **Nhiệt phân**: chỉ NaHCO~3~ bị phân huỷ. Mỗi 2 mol NaHCO~3~ (168 g) mất đi CO~2~ + H~2~O (62 g). Vậy khối lượng giảm = 31 · n(NaHCO~3~).
2. **Với acid** (mở rộng, rất hay gặp trong đề):
   - Nhỏ **từ từ acid vào** dung dịch Na~2~CO~3~: H^+^ chuyển hết CO~3~^2−^ thành HCO~3~^−^ trước (chưa có khí), sau đó HCO~3~^−^ + H^+^ → CO~2~.
   - Nhỏ **từ từ Na~2~CO~3~ vào** acid: acid luôn dư, nên có khí ngay: CO~3~^2−^ + 2H^+^ → CO~2~ + H~2~O.

> [!vi-du] Ví dụ 7
> Nung 27,4 g hỗn hợp NaHCO~3~ và Na~2~CO~3~ đến khối lượng không đổi, thu được 21,2 g chất rắn. Tính phần trăm khối lượng NaHCO~3~ trong hỗn hợp (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Na~2~CO~3~ không bị nhiệt phân. Khối lượng giảm đi chính là khối lượng CO~2~ và H~2~O bay ra.

> [!goi-y] Gợi ý 2
> 2NaHCO~3~ → Na~2~CO~3~ + CO~2~ + H~2~O: cứ 2 mol NaHCO~3~ thì khối lượng giảm 44 + 18 = 62 g.

> [!loi-giai] Lời giải
> Khối lượng giảm = 27,4 − 21,2 = 6,2 g → n(NaHCO~3~) = 2 · 6,2 : 62 = 0,2 mol.
>
> m(NaHCO~3~) = 0,2 · 84 = 16,8 g → %NaHCO~3~ = 16,8 : 27,4 · 100% ≈ **61,3%**.

> [!vi-du] Ví dụ 8
> Có hai thí nghiệm, đều dùng dung dịch chứa 0,15 mol HCl và dung dịch chứa 0,1 mol Na~2~CO~3~.
>
> (1) Nhỏ từ từ dung dịch HCl vào dung dịch Na~2~CO~3~, khuấy đều.
>
> (2) Nhỏ từ từ dung dịch Na~2~CO~3~ vào dung dịch HCl, khuấy đều.
>
> Tính thể tích CO~2~ (điều kiện chuẩn) thu được ở mỗi thí nghiệm (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Thí nghiệm (1): giọt acid đầu tiên gặp rất nhiều CO~3~^2−^, nên chỉ tạo HCO~3~^−^. Cần bao nhiêu mol H^+^ để chuyển hết 0,1 mol CO~3~^2−^ thành HCO~3~^−^?

> [!goi-y] Gợi ý 2
> Thí nghiệm (2): mỗi giọt Na~2~CO~3~ rơi vào nhiều acid, nên CO~3~^2−^ + 2H^+^ → CO~2~ ngay. Chất nào hết trước?

> [!loi-giai] Lời giải
> (1) CO~3~^2−^ + H^+^ → HCO~3~^−^: dùng 0,1 mol H^+^, còn 0,05 mol H^+^.
>
> HCO~3~^−^ + H^+^ → CO~2~ + H~2~O: n(CO~2~) = 0,05 mol → V = 0,05 · 24,79 ≈ **1,24 L**.
>
> (2) CO~3~^2−^ + 2H^+^ → CO~2~ + H~2~O. Cần 0,2 mol H^+^ cho 0,1 mol CO~3~^2−^, nhưng chỉ có 0,15 mol, nên H^+^ hết. n(CO~2~) = 0,15 : 2 = 0,075 mol → V ≈ **1,86 L**.
>
> Cùng lượng chất nhưng thứ tự nhỏ khác nhau thì lượng khí khác nhau.

> [!bay]
> - Khối lượng giảm khi nung là **CO~2~ + H~2~O** (62 g cho 2 mol NaHCO~3~), không chỉ CO~2~.
> - Nhỏ acid vào carbonate: **lúc đầu chưa có khí**. Đề Đúng/Sai hay hỏi hiện tượng này.

### Dạng 3. Bài toán sản xuất: chlorine – kiềm và Solvay

**Nhận biết:** đề cho lượng nguyên liệu (NaCl, đá vôi) và hiệu suất, hỏi lượng NaOH, Cl~2~, NaHCO~3~, Na~2~CO~3~, hoặc hỏi ngược.

**Phương pháp:**

1. Chlorine – kiềm: 2NaCl → 2NaOH + Cl~2~ + H~2~ (n(NaOH) = n(NaCl); n(Cl~2~) = n(NaCl) : 2).
2. Solvay: NaCl → NaHCO~3~ (1 : 1); 2NaCl → Na~2~CO~3~ (2 : 1); CaCO~3~ → Na~2~CO~3~ (1 : 1).
3. Tính bằng tấn, kg thì dùng Mmol, kmol cho gọn. Đi xuôi **nhân** H, đi ngược **chia** H.

> [!vi-du] Ví dụ 9
> Một nhà máy sản xuất soda theo phương pháp Solvay dùng 5,85 tấn NaCl. Hiệu suất cả quá trình (tính theo NaCl) là 80%. Tính khối lượng Na~2~CO~3~ thu được.

> [!goi-y] Gợi ý 1
> Dùng phương trình tổng: 2NaCl + CaCO~3~ → Na~2~CO~3~ + CaCl~2~. Đổi 5,85 tấn = 5 850 kg.

> [!goi-y] Gợi ý 2
> 2 mol NaCl mới cho 1 mol Na~2~CO~3~. Đi xuôi thì nhân H.

> [!loi-giai] Lời giải
> n(NaCl) = 5 850 : 58,5 = 100 kmol → n(Na~2~CO~3~) lí thuyết = 50 kmol.
>
> m(Na~2~CO~3~) = 50 · 106 · 0,8 = 4 240 kg = **4,24 tấn**.

> [!bay]
> Quên hệ số 2 (2NaCl → 1Na~2~CO~3~) sẽ ra kết quả gấp đôi. Nhớ M(Na~2~CO~3~) = **106**, M(NaHCO~3~) = **84**.

### Dạng 4. Lí thuyết tổng hợp và câu Đúng/Sai

**Nhận biết:** 4 ý về xu hướng biến đổi trong nhóm, thí nghiệm với nước, bảo quản, màu ngọn lửa, điện phân, ứng dụng của muối.

**Phương pháp:** đối chiếu từng ý với bảng Tóm tắt cuối bài, soát kĩ các từ khoá hay bị đánh tráo: **tăng/giảm** (tính khử tăng, nhiệt độ nóng chảy giảm từ Li đến Cs), **chậm nhất/mạnh nhất** (Li/K với nước), **dầu hoả/ethanol**, **có/không màng ngăn**, **bền/kém bền nhiệt**.

> [!vi-du] Ví dụ 10 (Đúng/Sai)
> Xét các phát biểu sau về kim loại nhóm IA:
>
> a) Trong hợp chất, kim loại nhóm IA chỉ có số oxi hoá +1.
>
> b) Từ Li đến Cs, nhiệt độ nóng chảy tăng dần vì nguyên tử nặng dần.
>
> c) Có thể bảo quản sodium bằng cách ngâm trong ethanol khan.
>
> d) Cho mẩu Na vào nước có vài giọt phenolphthalein, dung dịch chuyển màu hồng.

> [!goi-y] Gợi ý 1
> Nguyên tử nhóm IA có mấy electron hoá trị? Nhiệt độ nóng chảy phụ thuộc vào độ bền liên kết kim loại hay khối lượng nguyên tử?

> [!goi-y] Gợi ý 2
> Ethanol có nhóm –OH. Sản phẩm của Na với nước có môi trường gì?

> [!loi-giai] Lời giải
> a) **Đúng**: nguyên tử chỉ nhường được 1 electron hoá trị.
>
> b) **Sai**: nhiệt độ nóng chảy **giảm** dần, vì bán kính tăng làm liên kết kim loại yếu đi.
>
> c) **Sai**: Na phản ứng với ethanol giải phóng H~2~. Phải ngâm trong dầu hoả.
>
> d) **Đúng**: 2Na + 2H~2~O → 2NaOH + H~2~, NaOH là base mạnh làm phenolphthalein hoá hồng.

## Tóm tắt

| Nội dung | Kiến thức cần nhớ |
|---|---|
| Cấu hình | ns^1^, 1 electron hoá trị; đứng đầu mỗi chu kì |
| Tính khử | Rất mạnh (E° từ −2,7 V đến −3,0 V); M → M^+^ + 1e; số oxi hoá +1; tăng từ Li đến Cs |
| Tự nhiên | Chỉ ở dạng hợp chất: nước biển, mỏ muối, halite NaCl, sylvinite NaCl.KCl |
| Vật lí | Mềm, nhẹ (Li, Na, K nhẹ hơn nước), nóng chảy thấp; t~nc~, t~s~ giảm từ Li đến Cs |
| Với nước | 2M + 2H~2~O → 2MOH + H~2~; Li chậm, Na chạy trên mặt nước, K bốc cháy |
| Với Cl~2~, O~2~ | 2M + Cl~2~ → 2MCl; 4M + O~2~ → 2M~2~O; mức độ tăng từ Li đến K |
| Bảo quản | Dầu hoả khan, chân không, khí hiếm (Rb, Cs: ống thuỷ tinh hàn kín) |
| Hợp chất | Dễ tan, điện li mạnh, ion không màu; ngọn lửa: Li^+^ đỏ tía, Na^+^ vàng, K^+^ tím nhạt |
| NaCl | Gia vị, nước muối sinh lí; điện phân dung dịch có màng ngăn → NaOH + Cl~2~ + H~2~; không màng ngăn → nước Javel |
| NaHCO~3~ | Kém bền nhiệt (khoảng 120 °C); bột nở, chữa cháy, viên sủi, điều chỉnh pH |
| Na~2~CO~3~ | Bền nhiệt; thuỷ tinh, xà phòng, làm mềm nước (kết tủa CaCO~3~, MgCO~3~), xử lí nước phèn (Fe(OH)~3~) |
| Solvay | NaCl + NH~3~ + CO~2~ + H~2~O ⇌ NaHCO~3~↓ + NH~4~Cl; nung NaHCO~3~ → Na~2~CO~3~; quay vòng CO~2~, NH~3~; tổng: 2NaCl + CaCO~3~ → Na~2~CO~3~ + CaCl~2~ |

**Các tỉ lệ dùng trong tính toán:** n(H~2~) = n(M) : 2 (kim loại kiềm + nước); 2NaHCO~3~ nung giảm 62 g; 2NaCl → 2NaOH + Cl~2~; 2NaCl → Na~2~CO~3~; khí ở điều kiện chuẩn 24,79 L/mol.
