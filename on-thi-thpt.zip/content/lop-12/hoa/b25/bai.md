---
title: Nguyên tố nhóm IIA
thoi-gian: 55 phút
muc-tieu:
  - Nêu được trạng thái tự nhiên, cấu hình electron, bán kính nguyên tử, nhiệt độ nóng chảy, khối lượng riêng của các kim loại nhóm IIA, và giải thích vì sao tính khử tăng từ Be đến Ba.
  - Trình bày được phản ứng của kim loại nhóm IIA với oxygen, với nước; liên hệ mức độ phản ứng với độ tan của các hydroxide.
  - Dùng bảng tính tan để nhận xét độ tan của muối carbonate, sulfate, nitrate và hydroxide nhóm IIA; giải thích thí nghiệm so sánh độ tan CaSO~4~ và BaSO~4~.
  - Nhận biết Ca^2+^, Sr^2+^, Ba^2+^ bằng màu ngọn lửa; nhận biết từng ion Ca^2+^, Ba^2+^, SO~4~^2−^, CO~3~^2−^ trong dung dịch.
  - Viết được phương trình muối carbonate tác dụng với acid, với nước có CO~2~; phương trình nhiệt phân muối carbonate, muối nitrate và giải thích quy luật độ bền nhiệt bằng biến thiên enthalpy.
  - Nêu được ứng dụng của kim loại nhóm IIA, của đá vôi, vôi, thạch cao, apatite và vai trò của calcium trong cơ thể.
  - Nêu được khái niệm, phân loại, tác hại của nước cứng và cơ sở các phương pháp làm mềm nước cứng.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Nhóm IIA (Be, Mg, Ca, Sr, Ba) có cấu hình lớp ngoài **ns^2^**, dễ nhường 2 electron: M → M^2+^ + 2e. Số oxi hoá đặc trưng là **+2**. Từ Be đến Ba, bán kính tăng nên **tính khử tăng**. Trong tự nhiên chúng chỉ tồn tại ở dạng **hợp chất**.
> 2. Với nước: **Be không phản ứng**, Mg phản ứng chậm (nhanh hơn khi đun nóng), **Ca, Sr, Ba phản ứng mạnh** ngay ở nhiệt độ thường. Độ tan M(OH)~2~ tăng từ Mg đến Ba.
> 3. Muối carbonate đều **không tan**. Sulfate: MgSO~4~ tan, CaSO~4~ ít tan, **BaSO~4~ không tan**. Nitrate đều tan. Màu ngọn lửa: Ca^2+^ **đỏ cam**, Sr^2+^ **đỏ son**, Ba^2+^ **lục**.
> 4. MCO~3~ và M(NO~3~)~2~ đều bị nhiệt phân thành **oxide MO**. Độ bền nhiệt **tăng từ Mg đến Ba** (Δ~r~H°~298~ tăng). CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~ giải thích hang động, cặn ấm.
> 5. **Nước cứng** chứa nhiều Ca^2+^, Mg^2+^: tạm thời (HCO~3~^−^), vĩnh cửu (Cl^−^, SO~4~^2−^), toàn phần (cả hai). Làm mềm bằng **kết tủa** (đun sôi, Ca(OH)~2~ vừa đủ, Na~2~CO~3~, Na~3~PO~4~) hoặc **trao đổi ion**.

Nhóm IIA đứng ngay sau nhóm IA (Bài 24) trong mỗi chu kì. Vì vậy nhiều tính chất của chúng giống kim loại kiềm, chỉ "yếu hơn một bậc". Trong bài, em sẽ gặp lại rất nhiều thứ quen thuộc: đá vôi, vôi sống, nước vôi trong, phấn viết bảng, cặn trắng trong ấm đun nước. Tất cả đều là hợp chất của calcium, nguyên tố quan trọng nhất của nhóm.

## 1. Đơn chất nhóm IIA

### 1.1. Đặc điểm chung

Nhóm IIA gồm beryllium (Be), magnesium (Mg), calcium (Ca), strontium (Sr), barium (Ba) và radium (Ra, nguyên tố phóng xạ, ít gặp). Từ Bảng 25.1 (SGK tr. 117, số liệu vẽ lại ở Hình 1), ta rút ra ba điều:

- **Đều là nguyên tố s, lớp ngoài cùng có 2 electron (ns^2^).** Nguyên tử dễ nhường 2 electron này để đạt cấu hình bền của khí hiếm đứng trước: M → M^2+^ + 2e. Vì thế số oxi hoá đặc trưng trong hợp chất là **+2**.
- **Bán kính tăng dần từ Be đến Ba**, vì mỗi chu kì có thêm một lớp electron.
- **Thế điện cực chuẩn rất âm và giảm dần**, nên tính khử mạnh và **tăng dần** từ Be đến Ba.

> [!nen-tang] Bán kính, điện tích hạt nhân và tính kim loại (Hoá 10)
> Trong một nhóm A, đi từ trên xuống, điện tích hạt nhân tăng nhưng số lớp electron cũng tăng và ảnh hưởng trội hơn, nên bán kính tăng, electron ngoài cùng bị hút yếu hơn, tính khử tăng (xem thêm Bài 24 mục 1.1).

**Vì sao Ba có điện tích hạt nhân lớn gấp 14 lần Be mà lại dễ mất electron hơn?** Hai electron 6s của Ba ở rất xa hạt nhân, lại bị 54 electron bên trong "che chắn" bớt lực hút. Lực hút thực tế lên chúng yếu hơn nhiều so với ở Be.

**So với nhóm IA cùng chu kì**, kim loại nhóm IIA có tính khử **yếu hơn một chút**. Lí do: nguyên tử IIA có điện tích hạt nhân lớn hơn, bán kính nhỏ hơn, và phải mất tới 2 electron (xem Bài 24).

![Hình 1. Xu hướng biến đổi trong nhóm IIA từ Be đến Ba (vòng tròn vẽ theo tỉ lệ bán kính nguyên tử, số liệu Bảng 25.1 SGK tr. 117)](xu-huong.svg)

> [!vi-du] Ví dụ 1
> Nguyên tử X có cấu hình electron [Ar]4s^2^.
>
> a) Xác định vị trí của X trong bảng tuần hoàn và số oxi hoá đặc trưng của X trong hợp chất.
>
> b) So sánh tính khử của X với Mg và với K (Z = 19). Giải thích ngắn gọn.

> [!goi-y] Gợi ý 1
> Số lớp electron cho biết chu kì. Số electron lớp ngoài cùng (với nguyên tố s) cho biết số thứ tự nhóm A.

> [!goi-y] Gợi ý 2
> X và Mg cùng nhóm, khác chu kì. X và K cùng chu kì, khác nhóm. Mỗi cặp so sánh theo một quy luật.

> [!loi-giai] Lời giải
> a) X có 4 lớp electron → **chu kì 4**. Lớp ngoài cùng 4s^2^ → **nhóm IIA**. X là calcium (Z = 20). Số oxi hoá đặc trưng **+2** (X → X^2+^ + 2e).
>
> b) So với Mg (cùng nhóm, ở trên): Ca có bán kính lớn hơn (197 pm so với 160 pm), E° âm hơn (−2,84 V so với −2,356 V), nên **Ca khử mạnh hơn Mg**.
>
> So với K (cùng chu kì 4, nhóm IA): Ca có điện tích hạt nhân lớn hơn, bán kính nhỏ hơn và phải mất 2 electron, nên **Ca khử yếu hơn K**.

### 1.2. Trạng thái tự nhiên

Các nguyên tố nhóm IIA **chỉ tồn tại ở dạng hợp chất** trong tự nhiên.

**Vì sao?** Kim loại nhóm IIA có tính khử mạnh. Gặp oxygen, nước, CO~2~ trong không khí và trong đất, chúng bị oxi hoá ngay thành ion M^2+^. Qua hàng tỉ năm, không thể còn kim loại tự do.

Magnesium và calcium là hai nguyên tố nhóm IIA phổ biến nhất trên vỏ Trái Đất. Một số khoáng vật quan trọng (SGK tr. 117):

- **Calcite** CaCO~3~ (thành phần chính của đá vôi, đá phấn, đá hoa).
- **Dolomite** MgCO~3~·CaCO~3~.
- **Phosphorite** Ca~3~(PO~4~)~2~.

Ngoài ra, magnesium có trong **chất diệp lục** của cây xanh. Calcium có trong vỏ sò, mai cua, xương và răng.

### 1.3. Tính chất vật lí

Bảng 25.2 (SGK tr. 118) cho các thông số vật lí:

| Kim loại | t°~nc~ (°C) | t°~s~ (°C) | D (g/cm^3^) |
|---|---|---|---|
| Be | 1 287 | 2 467 | 1,85 |
| Mg | 651 | 1 100 | 1,74 |
| Ca | 842 | 1 484 | 1,55 |
| Sr | 757 | 1 366 | 2,64 |
| Ba | 727 | 1 845 | 3,51 |

- **Nhiệt độ nóng chảy cao hơn nhóm IA** cùng chu kì. Ví dụ, Mg nóng chảy ở 651 °C, trong khi Na chỉ khoảng 98 °C. Ca nóng chảy ở 842 °C, còn K chỉ khoảng 63 °C (Bài 24). Mỗi nguyên tử IIA góp 2 electron vào "biển electron" chung, nên liên kết kim loại bền hơn. Tuy vậy, so với đa số kim loại khác (Fe, Cu…), t°~nc~ của nhóm IIA vẫn tương đối thấp.
- **Đều là kim loại nhẹ.** Kim loại nặng nhất nhóm là Ba cũng chỉ có D = 3,51 g/cm^3^, nhỏ hơn 5 g/cm^3^ (ranh giới kim loại nhẹ, xem Bài 19).

> [!bay]
> Nhiệt độ nóng chảy và khối lượng riêng nhóm IIA **không biến đổi đều** từ Be đến Ba. Mg có t°~nc~ thấp nhất (651 °C), Ca có D nhỏ nhất (1,55 g/cm^3^). Đừng chọn phát biểu "t°~nc~ giảm dần từ Be đến Ba" hay "D tăng dần từ Be đến Ba".

> [!em-co-biet] Vì sao không đều?
> Các kim loại nhóm IIA có **kiểu mạng tinh thể khác nhau** (SGK tr. 118): Be, Mg có mạng lục phương, Ca, Sr có mạng lập phương tâm mặt, Ba có mạng lập phương tâm khối. Kiểu xếp khác nhau thì độ bền liên kết và độ đặc khít cũng khác, nên số liệu "nhảy cóc". Ở nhóm IA, cả nhóm cùng một kiểu mạng, nên t°~nc~ giảm khá đều.

### 1.4. Tính chất hoá học

Kim loại nhóm IIA có **tính khử mạnh, chỉ kém kim loại nhóm IA**.

**a) Tác dụng với oxygen**

=> 2M + O~2~ → 2MO

- **Ở điều kiện thường**, trong không khí: **Be bền** nhờ lớp màng oxide mỏng, đặc khít bảo vệ. **Mg bị oxi hoá chậm**. Ca, Sr, Ba bị oxi hoá **nhanh**, bề mặt chuyển dần sang màu xám.
- **Khi đốt nóng** trong không khí: Be phản ứng chậm. Các kim loại khác cháy mạnh, cho màu ngọn lửa đặc trưng: **calcium đỏ cam, strontium đỏ son, barium lục**.

**b) Tác dụng với nước**

Bảng 25.3 (SGK tr. 119) tóm tắt:

| Kim loại | Khả năng phản ứng với nước |
|---|---|
| Be | **Không** phản ứng |
| Mg | Chậm ở nhiệt độ thường, nhanh hơn khi đun nóng |
| Ca, Sr, Ba | **Mạnh** ngay ở nhiệt độ thường |

=> Mg + 2H~2~O → Mg(OH)~2~ + H~2~    (chậm, đun nóng thì nhanh hơn)

=> Ca + 2H~2~O → Ca(OH)~2~ + H~2~

Phương trình chung cho Ca, Sr, Ba: **M + 2H~2~O → M(OH)~2~ + H~2~**. Tỉ lệ mol: **n(H~2~) = n(M)**. Dung dịch thu được có tính kiềm (làm phenolphthalein hoá hồng).

**Vì sao mức độ phản ứng với nước lại tăng từ Mg đến Ba?** Có hai lí do cùng chiều.

1. Tính khử tăng từ Mg đến Ba, nên kim loại "muốn" nhường electron cho nước hơn.
2. **Độ tan của hydroxide tăng** (SGK tr. 119, ở 20 °C, g/100 g nước):

| Hydroxide | Mg(OH)~2~ | Ca(OH)~2~ | Sr(OH)~2~ | Ba(OH)~2~ |
|---|---|---|---|---|
| Độ tan | 1,25·10^−3^ | 0,173 | 1,77 | 3,89 |

Hãy hình dung miếng Mg trong nước: Mg(OH)~2~ sinh ra gần như không tan, nên bám lại thành một **lớp áo** trên bề mặt kim loại. Lớp áo này ngăn nước tiếp xúc với Mg, nên phản ứng gần như dừng lại. Với Ba, Ba(OH)~2~ tan tốt, vừa sinh ra đã bị nước cuốn đi. Bề mặt kim loại luôn "sạch", phản ứng diễn ra liên tục. Đun nóng làm Mg(OH)~2~ tan và bong ra tốt hơn, nên Mg phản ứng nhanh hơn.

Đây chính là ý của SGK: sản phẩm càng dễ tan thì càng dễ rời khỏi bề mặt kim loại, kim loại càng dễ tiếp tục phản ứng với nước. (Ca(OH)~2~ chỉ ít tan: 1 L nước vôi trong chứa tối đa khoảng 1,7 g, tức khoảng 0,023 M.)

> [!vi-du] Ví dụ 2
> Cho 1,60 g một kim loại M thuộc nhóm IIA tan hoàn toàn trong nước dư, thu được 0,9916 L khí H~2~ (đkc) và dung dịch X.
>
> a) Xác định M.
>
> b) Nhỏ vài giọt phenolphthalein vào X. Nêu hiện tượng.

> [!goi-y] Gợi ý 1
> Ở điều kiện chuẩn (25 °C, 1 bar), 1 mol khí chiếm 24,79 L. Phương trình M + 2H~2~O → M(OH)~2~ + H~2~ cho biết tỉ lệ mol M : H~2~ là bao nhiêu?

> [!goi-y] Gợi ý 2
> Biết n(M) và khối lượng thì tính được M = m : n.

> [!loi-giai] Lời giải
> a) n(H~2~) = 0,9916 : 24,79 = 0,04 mol. Theo phương trình, n(M) = n(H~2~) = 0,04 mol.
>
> M = 1,60 : 0,04 = **40** → M là **calcium**.
>
> b) X là dung dịch Ca(OH)~2~, có tính base, nên phenolphthalein chuyển **màu hồng**.

### 1.5. Ứng dụng

- **Beryllium**: chế tạo hợp kim có độ bền cơ học cao, không bị ăn mòn, khó nóng chảy. Ví dụ (mở rộng): hợp kim đồng – beryllium dùng làm dụng cụ như mỏ lết không phát ra tia lửa.
- **Magnesium**: chế tạo hợp kim nhẹ, bền, làm vật liệu sản xuất ô tô, máy bay, chi tiết máy.
- Hình 25.1 (SGK tr. 116) còn gợi ý: hợp chất của Ca dùng sản xuất xi măng, của Sr dùng làm pháo hoa (màu đỏ son), của Ba (BaSO~4~) làm chất cản quang khi chụp X-quang dạ dày, còn Ra là chất phóng xạ.

> [!ung-dung] Vì sao uống được barium sulfate, dù hợp chất barium độc?
> Ion Ba^2+^ tan trong máu rất độc (SGK lưu ý BaCl~2~ độc). Nhưng BaSO~4~ thuộc loại **không tan**, kể cả trong acid của dạ dày, nên gần như không có Ba^2+^ đi vào cơ thể. Nó chỉ phủ lên thành ống tiêu hoá và chặn tia X. Không được thay bằng BaCO~3~, vì BaCO~3~ tan trong acid dạ dày, giải phóng Ba^2+^ (mở rộng).

## 2. Hợp chất của kim loại nhóm IIA

### 2.1. Đặc điểm chung

**a) Tính tan trong nước**

SGK tr. 119 cho độ tan của các muối carbonate, sulfate, nitrate nhóm IIA. Ví dụ ở 20 °C (g/100 g nước): MgSO~4~ 33,7, CaSO~4~ 0,20, BaSO~4~ 0,0028, CaCO~3~ 0,0013, Ba(NO~3~)~2~ 9,02.

SGK phân loại tính tan theo độ tan S (g/100 g nước): **S < 0,01: không tan**, **0,01 ≤ S < 1: ít tan**, **S ≥ 1: dễ tan**. Áp dụng cho các muối và hydroxide, ta được Bảng 25.4 (SGK tr. 120):

| Anion | Mg^2+^ | Ca^2+^ | Sr^2+^ | Ba^2+^ |
|---|---|---|---|---|
| CO~3~^2−^ | K | K | K | K |
| SO~4~^2−^ | T | I | I | **K** |
| NO~3~^−^ | T | T | T | T |
| OH^−^ | **K** | I | T | T |

(T: dễ tan, I: ít tan, K: không tan)

Cách nhớ nhanh:

- **Carbonate: tất cả không tan** trong nước thường (đá vôi, vỏ sò…).
- **Nitrate: tất cả dễ tan** (giống quy luật chung của muối nitrate).
- **Sulfate và hydroxide đi ngược chiều nhau**: sulfate **giảm** độ tan từ Mg đến Ba (MgSO~4~ tan, BaSO~4~ không tan), hydroxide **tăng** độ tan từ Mg đến Ba (Mg(OH)~2~ không tan, Ba(OH)~2~ tan).

> [!bay]
> - MgCO~3~ có độ tan 0,01 g/100 g, đúng "ngưỡng". SGK xếp nó vào loại **không tan**. Làm bài theo Bảng 25.4.
> - **CaSO~4~ ít tan**, không phải "không tan". Chỉ có **BaSO~4~** là sulfate không tan của nhóm.
> - **Ca(OH)~2~ ít tan**, nhưng vẫn được coi là một base mạnh (phần đã tan phân li hoàn toàn). Đừng lẫn "ít tan" với "base yếu".

**Thí nghiệm so sánh độ tan CaSO~4~ và BaSO~4~** (SGK tr. 120). Tóm tắt: lấy hai ống nghiệm, ống (1) chứa dung dịch CaCl~2~, ống (2) chứa dung dịch BaCl~2~ (cùng nồng độ, cùng thể tích). Nhỏ từ từ từng giọt dung dịch CuSO~4~ vào mỗi ống đến khi thấy kết tủa.

**Hiện tượng:** ống BaCl~2~ có kết tủa trắng **ngay từ những giọt đầu**. Ống CaCl~2~ phải nhỏ **nhiều giọt hơn** mới thấy kết tủa.

=> Ba^2+^ + SO~4~^2−^ → BaSO~4~↓

=> Ca^2+^ + SO~4~^2−^ → CaSO~4~↓

**Giải thích:** BaSO~4~ có độ tan rất nhỏ, chỉ cần một lượng SO~4~^2−^ rất ít đã vượt quá giới hạn tan, kết tủa xuất hiện ngay. CaSO~4~ tan nhiều hơn hẳn (tính theo số mol, gấp khoảng 120 lần BaSO~4~), nên phải thêm nhiều SO~4~^2−^ thì dung dịch mới "bão hoà" và kết tủa mới tách ra.

**b) Màu ngọn lửa**

Giống kim loại nhóm IA, khi đốt kim loại nhóm IIA hoặc hợp chất của chúng trong ngọn lửa không màu, ngọn lửa có màu đặc trưng (SGK tr. 121):

| Ion | Ca^2+^ | Sr^2+^ | Ba^2+^ |
|---|---|---|---|
| Màu ngọn lửa | **đỏ cam** | **đỏ son** | **lục** (xanh lá) |

Cách làm: nhúng một que sạch (dây platinum, hoặc que tre đã ngâm nước) vào dung dịch muối rồi đưa vào ngọn lửa đèn khí. Ví dụ, để phân biệt ba dung dịch bão hoà CaCl~2~, SrCl~2~, BaCl~2~ (câu hỏi 2, SGK tr. 121), chỉ cần thử màu ngọn lửa: đỏ cam là CaCl~2~, đỏ son là SrCl~2~, lục là BaCl~2~.

> [!meo] Nhớ màu ngọn lửa cả hai nhóm
> Nhóm IA (Bài 24): Li^+^ đỏ tía, Na^+^ vàng, K^+^ tím nhạt. Nhóm IIA: Ca^2+^ đỏ cam, Sr^2+^ đỏ son, Ba^2+^ lục (pháo hoa đỏ dùng muối strontium, xanh lá dùng muối barium).

### 2.2. Một số hợp chất quan trọng

**a) Muối carbonate và muối nitrate**

**Tác dụng với acid.** Muối carbonate là muối của acid yếu (H~2~CO~3~), nên tác dụng được với nhiều acid vô cơ và hữu cơ mạnh hơn, giải phóng CO~2~:

=> CaCO~3~ + 2HCl → CaCl~2~ + CO~2~↑ + H~2~O

=> CaCO~3~ + 2CH~3~COOH → (CH~3~COO)~2~Ca + CO~2~↑ + H~2~O

Phương trình ion rút gọn của phản ứng thứ nhất: CaCO~3~ + 2H^+^ → Ca^2+^ + CO~2~ + H~2~O. Chú ý giữ nguyên công thức CaCO~3~ vì nó không tan.

> [!ung-dung] Làm sạch cặn đá vôi trong phích, ấm đun nước
> Cặn trắng đáy ấm chủ yếu là CaCO~3~ (câu hỏi SGK tr. 121). Ngâm giấm ăn (CH~3~COOH khoảng 4–5%) rồi đun nhẹ: cặn tan dần, sủi bọt CO~2~, tạo calcium acetate tan, chỉ cần tráng lại bằng nước. Nước cốt chanh (citric acid) cũng dùng được.

> [!vi-du] Ví dụ 3
> Đáy một chiếc ấm đun nước có 3,0 g cặn, coi như chỉ gồm CaCO~3~. Để hoà tan hết cặn, cần ít nhất bao nhiêu gam giấm ăn chứa 4% CH~3~COOH về khối lượng?

> [!goi-y] Gợi ý 1
> Viết phương trình CaCO~3~ với CH~3~COOH. Tỉ lệ mol là 1 : 2.

> [!goi-y] Gợi ý 2
> Tính khối lượng CH~3~COOH nguyên chất trước, rồi mới chia cho 4% để ra khối lượng giấm.

> [!loi-giai] Lời giải
> n(CaCO~3~) = 3,0 : 100 = 0,03 mol → n(CH~3~COOH) = 2 · 0,03 = 0,06 mol.
>
> m(CH~3~COOH) = 0,06 · 60 = 3,6 g → m(giấm) = 3,6 : 0,04 = **90 g**.

**Tác dụng với nước có hoà tan CO~2~.** Muối carbonate không tan trong nước thường, nhưng **tan dần trong nước có CO~2~**, vì tạo ra muối hydrogencarbonate tan được:

=> CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~

Đây là phản ứng **thuận nghịch**, và nó giải thích rất nhiều hiện tượng:

- **Chiều thuận**: nước mưa hoà tan CO~2~ trong không khí, thấm qua núi đá vôi, hoà tan dần CaCO~3~. Qua hàng triệu năm, núi đá vôi bị "đục" thành **hang động**.
- **Chiều nghịch**: dung dịch Ca(HCO~3~)~2~ nhỏ giọt từ trần hang, nước bay hơi và CO~2~ thoát ra, CaCO~3~ lại kết tủa, lâu dần thành **thạch nhũ**, măng đá. Đun nóng nước có Ca(HCO~3~)~2~ cũng làm cân bằng chuyển theo chiều nghịch, tạo **cặn trong ấm**.

![Hình 2. Chuyển hoá giữa các hợp chất quan trọng của calcium. Mũi tên xanh và cam là hai chiều của phản ứng CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~](chu-trinh-calcium.svg)

> [!em-co-biet] Thổi CO~2~ vào nước vôi trong
> Lúc đầu nước **vẩn đục** (CaCO~3~), thổi đến dư thì kết tủa **tan dần** (Ca(HCO~3~)~2~), đun nóng lại vẩn đục. Đây là cơ sở của Dạng 2 cuối bài.

**Phản ứng nhiệt phân.** Các muối carbonate nhóm IIA đều bị phân huỷ khi nung, tạo oxide:

=> MCO~3~(s) → MO(s) + CO~2~(g)    (t°)

Các muối nitrate nhóm IIA cũng đều bị nhiệt phân **tạo thành oxide**:

=> M(NO~3~)~2~(s) → MO(s) + 2NO~2~(g) + ½O~2~(g)    (t°)

Biến thiên enthalpy chuẩn của các phản ứng (SGK tr. 121–122, đơn vị kJ):

| Kim loại | Mg | Ca | Sr | Ba |
|---|---|---|---|---|
| Δ~r~H°~298~ nhiệt phân MCO~3~ | 100,7 | 179,2 | 234,6 | 271,5 |
| Δ~r~H°~298~ nhiệt phân M(NO~3~)~2~ | 255,2 | 369,5 | 452,4 | 506,2 |

> [!nen-tang] Biến thiên enthalpy (Hoá 10)
> - Δ~r~H°~298~ > 0: phản ứng **thu nhiệt**, phải cung cấp năng lượng thì phản ứng mới xảy ra.
> - Δ~r~H°~298~ càng lớn thì càng cần nhiều năng lượng, phản ứng càng khó xảy ra, nghĩa là chất ban đầu càng **bền nhiệt**.

**Kết luận:** Δ~r~H°~298~ tăng dần từ Mg đến Ba, nên **độ bền nhiệt của muối carbonate và muối nitrate tăng dần từ Mg đến Ba**. MgCO~3~ dễ bị nhiệt phân nhất, BaCO~3~ khó nhất.

> [!bay]
> - Nitrate nhóm IIA nhiệt phân **ra oxide MO + NO~2~ + O~2~**. Đừng viết theo kiểu KNO~3~ của nhóm IA (KNO~3~ → KNO~2~ + ½O~2~, mở rộng, ngoài SGK).
> - Δ~r~H°~298~ **lớn** nghĩa là **bền** hơn, không phải "phản ứng mạnh hơn".

**b) Nhận biết từng ion riêng rẽ Ca^2+^, Ba^2+^, SO~4~^2−^, CO~3~^2−^ trong dung dịch**

Nguyên tắc: dùng **phản ứng trao đổi tạo kết tủa** (CaSO~4~, BaSO~4~, CaCO~3~), kết hợp **phản ứng tạo khí** với acid.

> [!nen-tang] Điều kiện phản ứng trao đổi ion (Hoá 11)
> Phản ứng trao đổi trong dung dịch xảy ra khi tạo thành ít nhất một chất kết tủa, chất khí hoặc chất điện li yếu (như H~2~O).

Thí nghiệm SGK (tr. 122) tóm tắt như sau.

*Phần 1: nhận biết Ca^2+^, Ba^2+^, SO~4~^2−^.* Nhỏ dung dịch Na~2~SO~4~ vào ống chứa CaCl~2~ và ống chứa BaCl~2~. Nhỏ dung dịch BaCl~2~ vào ống chứa Na~2~SO~4~.

=> Ba^2+^ + SO~4~^2−^ → BaSO~4~↓ (trắng, xuất hiện **nhanh** và **nhiều**)

=> Ca^2+^ + SO~4~^2−^ → CaSO~4~↓ (trắng, xuất hiện **chậm** hơn và **ít** hơn, vì CaSO~4~ ít tan)

Như vậy: muốn nhận ra **Ba^2+^** thì dùng **SO~4~^2−^**, muốn nhận ra **SO~4~^2−^** thì dùng **Ba^2+^**. Hai ion "bắt cặp" với nhau tạo BaSO~4~.

*Phần 2: nhận biết CO~3~^2−^.* Trộn dung dịch Na~2~CO~3~ với dung dịch CaCl~2~: có **kết tủa trắng** CaCO~3~. Thêm dung dịch HCl dư: kết tủa **tan**, **sủi bọt khí** không màu.

=> Ca^2+^ + CO~3~^2−^ → CaCO~3~↓

=> CaCO~3~ + 2H^+^ → Ca^2+^ + CO~2~↑ + H~2~O

Kết tủa tan trong acid kèm sủi bọt khí là dấu hiệu của carbonate. Ngược lại, BaSO~4~ **không tan** trong acid (mở rộng), nên dễ phân biệt hai loại kết tủa trắng này. Lưu ý: BaCl~2~ **độc**, khi làm thí nghiệm phải tuân thủ quy tắc an toàn (SGK tr. 122).

> [!vi-du] Ví dụ 4
> Có ba lọ mất nhãn, mỗi lọ chứa một trong các dung dịch: NaCl, BaCl~2~, Na~2~CO~3~. Chỉ dùng thêm dung dịch H~2~SO~4~ loãng, hãy nhận biết từng dung dịch.

> [!goi-y] Gợi ý 1
> H~2~SO~4~ có cả ion H^+^ (gặp CO~3~^2−^ thì tạo khí) và ion SO~4~^2−^ (gặp Ba^2+^ thì tạo kết tủa).

> [!goi-y] Gợi ý 2
> Mỗi lọ sẽ cho một hiện tượng khác nhau: kết tủa, khí, hoặc không có gì.

> [!loi-giai] Lời giải
> Lấy mỗi lọ một ít làm mẫu thử, nhỏ dung dịch H~2~SO~4~ loãng vào.
>
> - Có **kết tủa trắng**: BaCl~2~.
>
> => BaCl~2~ + H~2~SO~4~ → BaSO~4~↓ + 2HCl
>
> - Có **sủi bọt khí**: Na~2~CO~3~.
>
> => Na~2~CO~3~ + H~2~SO~4~ → Na~2~SO~4~ + CO~2~↑ + H~2~O
>
> - **Không hiện tượng**: NaCl.

### 2.3. Ứng dụng của các hợp chất calcium

Đá vôi, vôi, nước vôi, thạch cao, quặng apatite, quặng fluorite… có nhiều ứng dụng trong đời sống và sản xuất (Bảng 25.5, SGK tr. 123):

| Nguyên liệu, vật liệu | Thành phần chính | Ứng dụng |
|---|---|---|
| Đá vôi | CaCO~3~ | Sản xuất vôi sống, xi măng, vật liệu xây dựng |
| Vôi sống | CaO | Khử chua đất, sát trùng, tẩy uế, hút ẩm trong công nghiệp |
| Vôi tôi, nước vôi | Ca(OH)~2~ | Khử chua, làm mềm nước cứng |
| Thạch cao | CaSO~4~ ngậm nước | Vật liệu xây dựng, phấn viết bảng |
| Apatite | chứa Ca~3~(PO~4~)~2~ | Sản xuất phân lân (superphosphate, phân lân nung chảy) |

Hình 2 cho thấy các chất này chuyển hoá qua lại. Nung đá vôi được vôi sống. Vôi sống tác dụng với nước (toả nhiều nhiệt) thành vôi tôi:

=> CaCO~3~ → CaO + CO~2~    (t°)

=> CaO + H~2~O → Ca(OH)~2~

Vữa vôi để ngoài không khí sẽ hấp thụ CO~2~, tạo lại CaCO~3~ cứng chắc: Ca(OH)~2~ + CO~2~ → CaCO~3~ + H~2~O.

**Vai trò của calcium trong cơ thể người.** Calcium phosphate và hydroxylapatite tham gia cấu tạo **xương và răng** (SGK tr. 123). Mở rộng (câu hỏi 3): một lượng nhỏ calcium trong máu tham gia co cơ, dẫn truyền thần kinh, đông máu. Thiếu calcium kéo dài góp phần gây còi xương ở trẻ em, loãng xương ở người cao tuổi. Sữa, tôm cá nhỏ ăn cả vỏ và xương, đậu phụ là các nguồn calcium tốt.

## 3. Nước cứng

### 3.1. Khái niệm, phân loại

Nước tự nhiên (sông, suối, ao hồ, nước ngầm) chảy qua đất đá nên hoà tan nhiều muối, trong đó có muối của Ca^2+^ và Mg^2+^.

- **Nước cứng** là nước chứa **nhiều ion Ca^2+^ và Mg^2+^**.
- **Nước mềm** là nước chứa ít hoặc không chứa các ion Ca^2+^ và Mg^2+^.

Dựa vào **anion** đi kèm với Ca^2+^, Mg^2+^, nước cứng được chia làm ba loại (SGK tr. 123):

| Loại | Anion đi kèm | Muối tiêu biểu |
|---|---|---|
| Tính cứng **tạm thời** | HCO~3~^−^ | Ca(HCO~3~)~2~, Mg(HCO~3~)~2~ |
| Tính cứng **vĩnh cửu** | Cl^−^, SO~4~^2−^ | CaCl~2~, MgCl~2~, CaSO~4~, MgSO~4~ |
| Tính cứng **toàn phần** | cả HCO~3~^−^ và Cl^−^, SO~4~^2−^ | hỗn hợp các muối trên |

Nước tự nhiên thường có tính cứng **toàn phần**.

**Vì sao gọi là "tạm thời"?** Vì chỉ cần **đun sôi**, phần lớn Ca^2+^, Mg^2+^ đi kèm HCO~3~^−^ sẽ tách ra ở dạng kết tủa carbonate. Tính cứng mất đi:

=> Ca(HCO~3~)~2~ → CaCO~3~↓ + CO~2~ + H~2~O    (t°)

=> Mg(HCO~3~)~2~ → MgCO~3~↓ + CO~2~ + H~2~O    (t°)

Đây chính là nguồn gốc của **cặn trong phích, ấm đun nước** (câu hỏi 4, SGK tr. 124). Còn Cl^−^, SO~4~^2−^ không bị biến đổi khi đun, nên tính cứng do chúng gây ra "vĩnh cửu" với việc đun sôi.

### 3.2. Tác hại của nước cứng

- **Nồi hơi** bị đóng cặn: lớp cặn dẫn nhiệt kém, gây tốn nhiên liệu, có thể làm nồi quá nhiệt cục bộ, không an toàn.
- **Đường ống dẫn nước** bị đóng cặn, làm giảm lưu lượng, thậm chí tắc ống.
- **Giặt bằng xà phòng**: ion Ca^2+^, Mg^2+^ kết hợp với gốc acid béo của xà phòng tạo muối ít tan, bám vào quần áo. Xà phòng ít bọt, tốn xà phòng, quần áo mau hỏng (nhớ lại Bài 2: chất giặt rửa tổng hợp không bị ảnh hưởng nhiều như xà phòng).
- **Nấu ăn**: thực phẩm lâu chín, giảm mùi vị.

### 3.3. Làm mềm nước cứng

**Nguyên tắc:** làm **giảm nồng độ** các ion Ca^2+^ và Mg^2+^ trong nước. Có hai cách: biến chúng thành chất **không tan** rồi tách ra (**phương pháp kết tủa**), hoặc **thay** chúng bằng cation khác (**phương pháp trao đổi ion**).

**a) Phương pháp kết tủa**

*Với nước cứng tạm thời* (chứa Ca(HCO~3~)~2~, Mg(HCO~3~)~2~), có hai cách:

1. **Không dùng hoá chất: đun sôi** (phương trình ở mục 3.1).
2. **Dùng hoá chất: Ca(OH)~2~ với lượng vừa đủ.** Ion OH^−^ chuyển HCO~3~^−^ thành CO~3~^2−^, rồi CO~3~^2−^ kết tủa Ca^2+^:

=> Ca(HCO~3~)~2~ + Ca(OH)~2~ → 2CaCO~3~↓ + 2H~2~O

=> Mg(HCO~3~)~2~ + 2Ca(OH)~2~ → Mg(OH)~2~↓ + 2CaCO~3~↓ + 2H~2~O

(Mg^2+^ tách ra tốt nhất ở dạng Mg(OH)~2~, chất khó tan hơn MgCO~3~. Một số tài liệu viết gọn sản phẩm là MgCO~3~ + CaCO~3~.)

**Vì sao dùng Ca(OH)~2~, chất chứa chính Ca^2+^, lại làm mềm được nước?** Mỗi Ca(OH)~2~ thêm vào mang 1 Ca^2+^ nhưng tạo ra 2 OH^−^, biến 2 HCO~3~^−^ thành 2 CO~3~^2−^. Hai CO~3~^2−^ này kéo theo **2** Ca^2+^ vào kết tủa: 1 ion có sẵn trong nước và 1 ion vừa thêm vào. Tổng cộng, Ca^2+^ trong nước giảm đi.

> [!bay]
> Phải dùng Ca(OH)~2~ **vừa đủ**. Nếu dư, phần Ca(OH)~2~ thừa lại đưa thêm Ca^2+^ vào nước, nước lại cứng.

*Với nước cứng vĩnh cửu* (chứa CaCl~2~, MgSO~4~…), đun sôi hay dùng Ca(OH)~2~ đều không có tác dụng, vì không có HCO~3~^−^ để tạo CO~3~^2−^. Phải đưa **CO~3~^2−^ hoặc PO~4~^3−^** từ ngoài vào, dùng **Na~2~CO~3~** hoặc **Na~3~PO~4~** (câu hỏi SGK tr. 124):

=> Ca^2+^ + CO~3~^2−^ → CaCO~3~↓

=> Mg^2+^ + CO~3~^2−^ → MgCO~3~↓

=> 3Ca^2+^ + 2PO~4~^3−^ → Ca~3~(PO~4~)~2~↓

Na~2~CO~3~ và Na~3~PO~4~ làm mềm được **mọi loại** nước cứng, vì chúng kết tủa Ca^2+^, Mg^2+^ bất kể anion đi kèm là gì.

> [!meo] NaOH thì sao? (mở rộng, hay gặp trong đề)
> Với nước cứng tạm thời, NaOH lượng vừa đủ cũng làm mềm được: OH^−^ + HCO~3~^−^ → CO~3~^2−^ + H~2~O, rồi CO~3~^2−^ kết tủa Ca^2+^, Mg^2+^. Các chất như HCl, NaCl, Na~2~SO~4~, NaNO~3~ **không** làm mềm được nước cứng, vì không tạo kết tủa với Ca^2+^, Mg^2+^.

**b) Phương pháp trao đổi ion**

**Vật liệu trao đổi ion** là vật liệu có khả năng trao đổi một số ion trong cấu tạo của nó với các ion có trong dung dịch. Để xử lí nước cứng, người ta thường dùng vật liệu polymer trao đổi cation, gọi là **nhựa cationite**.

Cho nước cứng chảy qua cột chứa nhựa cationite, các ion Ca^2+^, Mg^2+^ bị giữ lại trên cột, đồng thời các cation như Na^+^, H^+^ được giải phóng từ cột vào nước. Nước ra khỏi cột hầu như không còn Ca^2+^, Mg^2+^.

![Hình 3. Làm mềm nước cứng bằng cột nhựa cationite. Phương trình viết rút gọn, R là khung polymer (phần tái sinh nhựa là mở rộng, ngoài SGK)](trao-doi-ion.svg)

![Hình 4. Phân loại nước cứng và phương pháp làm mềm phù hợp với từng loại](nuoc-cung.svg)

> [!vi-du] Ví dụ 5
> Một mẫu nước giếng chứa các ion Ca^2+^, Mg^2+^, HCO~3~^−^ và Cl^−^.
>
> a) Mẫu nước này có tính cứng loại nào?
>
> b) Đun sôi thật lâu mẫu nước rồi lọc bỏ cặn. Nước thu được đã mềm chưa? Vì sao?

> [!goi-y] Gợi ý 1
> Nhìn anion: HCO~3~^−^ gây tính cứng gì, Cl^−^ gây tính cứng gì?

> [!goi-y] Gợi ý 2
> Đun sôi chỉ loại được phần Ca^2+^, Mg^2+^ "đi cùng" HCO~3~^−^.

> [!loi-giai] Lời giải
> a) Có cả HCO~3~^−^ (tính cứng tạm thời) và Cl^−^ (tính cứng vĩnh cửu), nên mẫu nước có tính cứng **toàn phần**.
>
> b) **Chưa mềm.** Đun sôi chỉ loại được Ca^2+^, Mg^2+^ ứng với HCO~3~^−^. Phần Ca^2+^, Mg^2+^ ứng với Cl^−^ vẫn còn trong nước (tính cứng vĩnh cửu). Muốn làm mềm hoàn toàn phải dùng thêm Na~2~CO~3~ hoặc Na~3~PO~4~ (xem Dạng 3).

## Dạng bài thi hay gặp

### Dạng 1. Muối carbonate: nhiệt phân và tác dụng với acid

**Nhận biết:** đề cho hỗn hợp muối carbonate (CaCO~3~, MgCO~3~, BaCO~3~, dolomite…), nung đến khối lượng không đổi hoặc cho tác dụng với acid. Đề hỏi khối lượng chất rắn, thể tích CO~2~, thành phần phần trăm.

**Phương pháp:**

1. Viết sơ đồ gọn: MCO~3~ → MO + CO~2~ (nhiệt phân), MCO~3~ + 2H^+^ → M^2+^ + CO~2~ + H~2~O (acid). Cả hai đều có **n(CO~2~) = n(MCO~3~)**.
2. **Bảo toàn khối lượng** khi nung: m(chất rắn) = m(ban đầu) − m(CO~2~). Khối lượng giảm chính là CO~2~.
3. Hỗn hợp hai muối: đặt ẩn số mol, lập hệ hai phương trình (khối lượng ban đầu và khối lượng giảm/CO~2~).
4. Nitrate: M(NO~3~)~2~ → MO + 2NO~2~ + ½O~2~. Chất rắn còn lại là **oxide**.

> [!vi-du] Ví dụ 6
> Nung 27,6 g hỗn hợp CaCO~3~ và MgCO~3~ đến khối lượng không đổi, thu được 14,4 g chất rắn. Tính phần trăm khối lượng CaCO~3~ trong hỗn hợp (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Khối lượng giảm là khối lượng CO~2~. Từ đó có tổng số mol hai muối.

> [!goi-y] Gợi ý 2
> Đặt n(CaCO~3~) = a, n(MgCO~3~) = b. Phương trình 1: 100a + 84b = 27,6. Phương trình 2: a + b = n(CO~2~).

> [!loi-giai] Lời giải
> m(CO~2~) = 27,6 − 14,4 = 13,2 g → n(CO~2~) = 0,3 mol → a + b = 0,3.
>
> 100a + 84b = 27,6. Thay b = 0,3 − a: 16a + 25,2 = 27,6 → a = 0,15, b = 0,15.
>
> %m(CaCO~3~) = 0,15 · 100 : 27,6 · 100% ≈ **54,3%**.

> [!bay]
> - Nung nitrate nhóm IIA ra **oxide**, không ra muối nitrite.
> - Nếu đề nói "nung một thời gian" (chưa đến khối lượng không đổi), chất rắn còn cả muối chưa phân huỷ. Khi đó vẫn có m(giảm) = m(CO~2~), nhưng không được coi muối đã phân huỷ hết.

### Dạng 2. CO~2~ tác dụng với dung dịch Ca(OH)~2~ hoặc Ba(OH)~2~

Dạng này là dạng thi quen thuộc, phát triển từ phản ứng CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~ (SGK tr. 121).

**Nhận biết:** sục/hấp thụ CO~2~ vào nước vôi trong hoặc dung dịch Ba(OH)~2~. Đề hỏi khối lượng kết tủa, hoặc ngược lại cho kết tủa để tìm lượng CO~2~.

**Phương pháp:** CO~2~ phản ứng với OH^−^ theo hai nấc:

=> CO~2~ + 2OH^−^ → CO~3~^2−^ + H~2~O

=> CO~2~ + OH^−^ → HCO~3~^−^

Tính tỉ lệ T = n(OH^−^) : n(CO~2~):

| T | Sản phẩm | Công thức nhanh |
|---|---|---|
| T ≥ 2 | Chỉ CO~3~^2−^ (OH^−^ có thể dư) | n(CO~3~^2−^) = n(CO~2~) |
| 1 < T < 2 | Cả CO~3~^2−^ và HCO~3~^−^ | n(CO~3~^2−^) = n(OH^−^) − n(CO~2~) |
| T ≤ 1 | Chỉ HCO~3~^−^ | không có kết tủa |

Sau đó: n(kết tủa MCO~3~) = số nhỏ hơn giữa n(CO~3~^2−^) và n(M^2+^).

**Vì sao công thức n(CO~3~^2−^) = n(OH^−^) − n(CO~2~)?** Gọi x = n(CO~3~^2−^), y = n(HCO~3~^−^). Bảo toàn C: x + y = n(CO~2~). Bảo toàn điện tích (mỗi OH^−^ thành một điện tích âm): 2x + y = n(OH^−^). Trừ hai phương trình được x = n(OH^−^) − n(CO~2~).

> [!vi-du] Ví dụ 7
> Hấp thụ hoàn toàn 3,9664 L CO~2~ (đkc) vào 2 L dung dịch Ca(OH)~2~ 0,05 M.
>
> a) Tính khối lượng kết tủa thu được.
>
> b) Khối lượng dung dịch sau phản ứng tăng hay giảm bao nhiêu gam so với dung dịch Ca(OH)~2~ ban đầu?

> [!goi-y] Gợi ý 1
> n(CO~2~) = 3,9664 : 24,79. n(OH^−^) = 2 · n(Ca(OH)~2~). Tính T.

> [!goi-y] Gợi ý 2
> b) Dung dịch nhận thêm khối lượng CO~2~, nhưng mất đi khối lượng kết tủa tách ra.

> [!loi-giai] Lời giải
> a) n(CO~2~) = 3,9664 : 24,79 = 0,16 mol. n(Ca(OH)~2~) = 0,1 mol → n(OH^−^) = 0,2 mol.
>
> T = 0,2 : 0,16 = 1,25 → tạo cả CO~3~^2−^ và HCO~3~^−^.
>
> n(CO~3~^2−^) = 0,2 − 0,16 = 0,04 mol < n(Ca^2+^) = 0,1 mol → n(CaCO~3~) = 0,04 mol → m = **4 g**.
>
> b) m(dd sau) − m(dd đầu) = m(CO~2~) − m(CaCO~3~) = 0,16 · 44 − 4 = 7,04 − 4 = 3,04 g > 0. Dung dịch **tăng 3,04 g**.

> [!bay]
> - Cùng một lượng kết tủa có thể ứng với **hai** giá trị CO~2~ (thiếu CO~2~ hoặc CO~2~ đã hoà tan bớt kết tủa). Đề hỏi "giá trị lớn nhất" thì lấy trường hợp có tạo HCO~3~^−^: n(CO~2~) = n(OH^−^) − n(↓).
> - Lấy số mol kết tủa bằng n(CO~2~) khi chưa xét T là lỗi phổ biến nhất.
> - Đun nóng dung dịch sau phản ứng thấy thêm kết tủa nghĩa là có Ca(HCO~3~)~2~ (xem Ví dụ 5, Bài 6).

### Dạng 3. Nước cứng: nhận dạng, chọn hoá chất, tính lượng hoá chất

**Nhận biết:** đề cho thành phần ion của mẫu nước, hỏi loại tính cứng, chất nào làm mềm được, hoặc lượng hoá chất cần dùng.

**Phương pháp:**

1. Nhìn **anion**: HCO~3~^−^ là tạm thời, Cl^−^ hay SO~4~^2−^ là vĩnh cửu, có cả hai là toàn phần.
2. Chọn cách làm mềm theo Hình 4: đun sôi, Ca(OH)~2~ vừa đủ, NaOH vừa đủ chỉ dùng cho tạm thời. Na~2~CO~3~, Na~3~PO~4~, trao đổi ion dùng cho mọi loại.
3. Tính lượng: với Na~2~CO~3~, **n(CO~3~^2−^) cần = n(Ca^2+^) + n(Mg^2+^)**. Với Ca(OH)~2~ cho nước chỉ chứa Ca(HCO~3~)~2~: **n(Ca(OH)~2~) = n(Ca(HCO~3~)~2~)**.
4. Kiểm tra lại bằng **bảo toàn điện tích**: 2[n(Ca^2+^) + n(Mg^2+^)] = n(HCO~3~^−^) + n(Cl^−^) + 2n(SO~4~^2−^).

> [!vi-du] Ví dụ 8
> Một mẫu nước có nồng độ các ion: Ca^2+^ 0,003 M, Mg^2+^ 0,002 M, Cl^−^ 0,004 M, HCO~3~^−^ 0,006 M.
>
> a) Kiểm tra bảo toàn điện tích và cho biết loại tính cứng.
>
> b) Tính khối lượng Na~2~CO~3~ tối thiểu để làm mềm hoàn toàn 5 L mẫu nước.
>
> c) Nếu chỉ đun sôi 5 L mẫu nước, số mol Ca^2+^ và Mg^2+^ còn lại tối thiểu là bao nhiêu?

> [!goi-y] Gợi ý 1
> a) Tổng điện tích dương = 2 · (0,003 + 0,002). Tổng điện tích âm = 0,004 + 0,006.

> [!goi-y] Gợi ý 2
> c) Khi đun sôi: 2HCO~3~^−^ → CO~3~^2−^ + CO~2~ + H~2~O. Số mol CO~3~^2−^ tạo ra bằng một nửa số mol HCO~3~^−^, và mỗi CO~3~^2−^ chỉ kéo được 1 ion M^2+^ vào kết tủa.

> [!loi-giai] Lời giải
> a) Điện tích dương: 2 · 0,005 = 0,010. Điện tích âm: 0,004 + 0,006 = 0,010. Cân bằng ✓. Có HCO~3~^−^ và Cl^−^ nên là nước cứng **toàn phần**.
>
> b) n(Ca^2+^) + n(Mg^2+^) = 5 · 0,005 = 0,025 mol → n(Na~2~CO~3~) = 0,025 mol → m = 0,025 · 106 = **2,65 g**.
>
> c) n(HCO~3~^−^) = 5 · 0,006 = 0,03 mol → n(CO~3~^2−^) = 0,015 mol → kết tủa tối đa 0,015 mol M^2+^.
>
> Còn lại tối thiểu 0,025 − 0,015 = **0,010 mol** Ca^2+^, Mg^2+^ (đúng bằng phần ứng với Cl^−^: 0,02 mol Cl^−^ : 2). Nước vẫn còn tính cứng vĩnh cửu.

### Dạng 4. Câu lí thuyết: xu hướng, nhận biết, Đúng/Sai

**Nhận biết:** đề hỏi xu hướng biến đổi trong nhóm, tính tan, màu ngọn lửa, thuốc thử nhận biết, hoặc cho 4 ý Đúng/Sai về thí nghiệm SGK.

**Phương pháp:** đối chiếu với bảng Tóm tắt và Hình 1. Chỗ hay bị gài: các đại lượng **tăng** từ Be đến Ba (bán kính, tính khử, độ tan M(OH)~2~, độ bền nhiệt muối), độ tan sulfate **giảm**, t°~nc~ và D **không đều**, các ngoại lệ của Be và Mg.

> [!vi-du] Ví dụ 9 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Tất cả kim loại nhóm IIA đều khử được nước ở nhiệt độ thường.
>
> b) Độ tan trong nước của các muối sulfate giảm dần từ MgSO~4~ đến BaSO~4~.
>
> c) Có thể dùng dung dịch Ca(OH)~2~ lấy dư để làm mềm nước cứng tạm thời.
>
> d) Nhiệt phân hoàn toàn Ca(NO~3~)~2~ thu được chất rắn là CaO.

> [!goi-y] Gợi ý 1
> Nhớ lại Bảng 25.3: kim loại nào không phản ứng với nước, kim loại nào phản ứng chậm?

> [!goi-y] Gợi ý 2
> Ý c: chú ý chữ "dư". Ý d: nitrate nhóm IIA khác nitrate nhóm IA thế nào?

> [!loi-giai] Lời giải
> a) **Sai**: Be không phản ứng với nước, Mg phản ứng rất chậm ở nhiệt độ thường.
>
> b) **Đúng**: MgSO~4~ dễ tan, CaSO~4~ và SrSO~4~ ít tan, BaSO~4~ không tan.
>
> c) **Sai**: Ca(OH)~2~ dư đưa thêm Ca^2+^ vào nước. Phải dùng lượng **vừa đủ**.
>
> d) **Đúng**: Ca(NO~3~)~2~ → CaO + 2NO~2~ + ½O~2~.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Cấu hình, số oxi hoá | ns^2^; M → M^2+^ + 2e; số oxi hoá +2 |
| Từ Be đến Ba | Bán kính tăng, E° giảm, tính khử tăng (chỉ kém nhóm IA) |
| Tự nhiên | Chỉ ở dạng hợp chất: calcite CaCO~3~, dolomite MgCO~3~·CaCO~3~, phosphorite Ca~3~(PO~4~)~2~ |
| Vật lí | Kim loại nhẹ (D < 5 g/cm^3^); t°~nc~ cao hơn nhóm IA; t°~nc~ và D không biến đổi đều |
| Với O~2~ | Be bền (màng oxide), Mg oxi hoá chậm; khi đốt: Ca đỏ cam, Sr đỏ son, Ba lục |
| Với H~2~O | Be không phản ứng; Mg chậm (đun nóng nhanh hơn); Ca, Sr, Ba mạnh: M + 2H~2~O → M(OH)~2~ + H~2~ |
| Tính tan | MCO~3~ đều không tan; nitrate đều tan; sulfate giảm từ Mg đến Ba (BaSO~4~ không tan); hydroxide tăng từ Mg đến Ba |
| Carbonate + acid | MCO~3~ + 2H^+^ → M^2+^ + CO~2~ + H~2~O |
| Carbonate + nước có CO~2~ | CaCO~3~ + CO~2~ + H~2~O ⇌ Ca(HCO~3~)~2~ (hang động, thạch nhũ, cặn ấm) |
| Nhiệt phân | MCO~3~ → MO + CO~2~; M(NO~3~)~2~ → MO + 2NO~2~ + ½O~2~; độ bền nhiệt tăng từ Mg đến Ba |
| Nhận biết ion | Ba^2+^ bằng SO~4~^2−^ (BaSO~4~ trắng); SO~4~^2−^ bằng Ba^2+^; CO~3~^2−^ bằng Ca^2+^ (kết tủa trắng tan trong acid, sủi bọt CO~2~) |
| Nước cứng | Nhiều Ca^2+^, Mg^2+^; tạm thời (HCO~3~^−^), vĩnh cửu (Cl^−^, SO~4~^2−^), toàn phần |
| Làm mềm | Tạm thời: đun sôi, Ca(OH)~2~ vừa đủ; mọi loại: Na~2~CO~3~, Na~3~PO~4~, trao đổi ion |

**Các công thức dùng trong tính toán:**

- M (Ca, Sr, Ba) + 2H~2~O → M(OH)~2~ + H~2~: n(H~2~) = n(M).
- Nhiệt phân, tác dụng acid: n(CO~2~) = n(MCO~3~); m(rắn) = m(đầu) − m(CO~2~).
- CO~2~ + OH^−^: T = n(OH^−^) : n(CO~2~); khi 1 < T < 2 thì n(CO~3~^2−^) = n(OH^−^) − n(CO~2~).
- Làm mềm bằng Na~2~CO~3~: n(Na~2~CO~3~) = n(Ca^2+^) + n(Mg^2+^).
- 1 mol khí ở đkc (25 °C, 1 bar) chiếm 24,79 L.
