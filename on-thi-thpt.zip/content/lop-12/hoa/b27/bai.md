---
title: Đại cương về kim loại chuyển tiếp dãy thứ nhất
thoi-gian: 45 phút
muc-tieu:
  - Nêu được đặc điểm cấu hình electron của nguyên tử kim loại chuyển tiếp dãy thứ nhất (từ Sc đến Cu) và viết được cấu hình electron của các ion tương ứng.
  - Trình bày được một số tính chất vật lí (nhiệt độ nóng chảy, khối lượng riêng, độ dẫn điện, dẫn nhiệt, độ cứng) và ứng dụng rút ra từ các tính chất đó.
  - Đọc bảng số liệu để so sánh tính chất vật lí của kim loại chuyển tiếp với kim loại họ s (K, Ca).
  - Giải thích được vì sao nguyên tố chuyển tiếp có nhiều số oxi hoá; nêu được số oxi hoá phổ biến, cấu hình electron và màu sắc của một số ion.
  - Mô tả và tính toán được thí nghiệm chuẩn độ iron(II) sulfate bằng thuốc tím; nhận biết được ion Cu^2+^, Fe^3+^ bằng dung dịch NaOH.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Dãy chuyển tiếp thứ nhất gồm 9 nguyên tố **từ Sc (Z = 21) đến Cu (Z = 29)**, thuộc **khối d**, chu kì 4. Cấu hình chung **[Ar]3d^1–10^4s^1–2^**: số electron 3d tăng từ 1 đến 10, còn 4s thường có 2 electron (**trừ Cr và Cu** có 4s^1^).
> 2. Kim loại chuyển tiếp **khó nóng chảy, cứng, phần lớn là kim loại nặng**, dẫn điện và dẫn nhiệt tương đối tốt. Cr cứng nhất trong các kim loại, Cu dẫn điện tốt chỉ sau Ag, còn Sc và Ti tương đối nhẹ.
> 3. Có nhiều electron hoá trị (3d và 4s) nên có **nhiều số oxi hoá**: Cr +3, +6; Mn +2, +4, +7; Fe +2, +3; Cu +2. Khi tạo ion, nguyên tử **mất electron 4s trước**, rồi mới đến 3d.
> 4. Ion có màu đặc trưng: Fe^2+^ lục nhạt, Fe^3+^ vàng, Cu^2+^ xanh lam, MnO~4~^−^ tím. Với NaOH: Fe(OH)~3~ **nâu đỏ**, Cu(OH)~2~ **xanh lam**.
> 5. Chuẩn độ Fe^2+^ bằng KMnO~4~ (môi trường H~2~SO~4~): **n(Fe^2+^) = 5·n(KMnO~4~)**. Dừng khi màu hồng **bền khoảng 20 giây**.

## 1. Đặc điểm cấu tạo nguyên tử

Mở đầu chương, SGK (tr. 128) cho em xem các ứng dụng quen thuộc: vợt cầu lông, thân máy bay, cưa sắt, khung xe tải, vỏ hộp, tàu thuỷ, nam châm, đồng xu, dây điện. Tất cả đều làm từ 9 kim loại đứng cạnh nhau trong bảng tuần hoàn, từ Sc đến Cu. Vì sao chúng bền, cứng, chịu nhiệt tốt như vậy? Câu trả lời bắt đầu từ cách electron được sắp xếp trong nguyên tử.

> [!nen-tang] Viết cấu hình electron khối d (Bài 18)
> - Thứ tự điền electron theo năng lượng: … 3s 3p **4s 3d** 4p… Phân lớp 4s được điền **trước** 3d.
> - Khi viết cấu hình thì sắp lại theo từng lớp: 3d đứng trước 4s. Ví dụ Fe (Z = 26) là [Ar]3d^6^4s^2^.
> - [Ar] là cấu hình của argon (18 electron): 1s^2^2s^2^2p^6^3s^2^3p^6^.
> - Nguyên tố có electron cuối cùng điền vào phân lớp d thuộc **khối d** (các nhóm B).

### 1.1. Cấu hình electron từ Sc đến Cu

Bảng 27.1 (SGK tr. 129) cho cấu hình của 9 nguyên tố. Em chỉ cần nhớ **một quy luật và hai ngoại lệ**:

| Z | Nguyên tố | Cấu hình electron |
|---|---|---|
| 21 | Sc | [Ar]3d^1^4s^2^ |
| 22 | Ti | [Ar]3d^2^4s^2^ |
| 23 | V | [Ar]3d^3^4s^2^ |
| 24 | Cr | [Ar]**3d^5^4s^1^** |
| 25 | Mn | [Ar]3d^5^4s^2^ |
| 26 | Fe | [Ar]3d^6^4s^2^ |
| 27 | Co | [Ar]3d^7^4s^2^ |
| 28 | Ni | [Ar]3d^8^4s^2^ |
| 29 | Cu | [Ar]**3d^10^4s^1^** |

- **Giống nhau**: đều có lõi bên trong là [Ar]. Electron hoá trị nằm ở hai phân lớp **3d và 4s**.
- **Khác nhau**: số electron 3d **tăng dần từ 1 (Sc) đến 10 (Cu)**. Phân lớp 4s thường có **2 electron**, trừ Cr và Cu chỉ có 1.

**Vì sao Cr và Cu "lệch" quy luật?** (giải thích thêm, ngoài SGK) Theo quy luật, Cr phải là 3d^4^4s^2^ và Cu phải là 3d^9^4s^2^. Nhưng phân lớp d **nửa bão hoà (d^5^)** hoặc **bão hoà (d^10^)** có năng lượng thấp, bền hơn. Vì thế một electron 4s "chuyển sang" 3d cho đủ 5 hoặc 10. Mẹo nhớ: thiếu 1 electron là đủ d^5^ hay d^10^ thì nguyên tử "mượn" 1 electron từ 4s.

![Hình 1. Electron ở phân lớp 3d và 4s của 9 nguyên tố từ Sc đến Cu (mỗi ô là một orbital). Số electron 3d tăng dần; Cr và Cu chỉ có 1 electron ở 4s](cau-hinh.svg)

**So với nhóm IA, IIA cùng chu kì 4** (câu hỏi 1 SGK tr. 129): K ([Ar]4s^1^) và Ca ([Ar]4s^2^) chỉ có electron hoá trị ở 4s, tối đa 2 electron. Kim loại chuyển tiếp có thêm **electron 3d** cũng tham gia làm electron hoá trị, nên có từ 3 (Sc) đến 11 (Cu) electron hoá trị. Đây là chìa khoá giải thích gần như mọi tính chất trong bài.

> [!em-co-biet] Kim loại chuyển tiếp nói chung
> Theo SGK (tr. 130), kim loại chuyển tiếp gồm **toàn bộ các nguyên tố họ d và họ f**, đều thuộc các nhóm B. Họ d có 4 dãy: 3d (chu kì 4, chính là bài này), 4d (chu kì 5), 5d (chu kì 6), 6d (chu kì 7). Họ f có 2 dãy: 4f (họ lanthanides) và 5f (họ actinides). Bạc, vàng, platinum đều là kim loại chuyển tiếp.

> [!vi-du] Ví dụ 1
> Cho cobalt (Z = 27) và nickel (Z = 28).
>
> a) Viết cấu hình electron rút gọn của hai nguyên tử.
>
> b) Mỗi nguyên tử có bao nhiêu electron ở phân lớp 3d, bao nhiêu electron hoá trị (3d + 4s)?

> [!goi-y] Gợi ý 1
> Bắt đầu từ [Ar] (18 electron). Còn lại bao nhiêu electron để điền vào 4s rồi 3d?

> [!goi-y] Gợi ý 2
> Co và Ni có thuộc hai trường hợp ngoại lệ (đủ d^5^ hoặc d^10^ khi mượn 1 electron) không?

> [!loi-giai] Lời giải
> a) Co: 27 − 18 = 9 electron, điền 4s^2^ rồi 3d^7^ → **[Ar]3d^7^4s^2^**. Ni: 28 − 18 = 10 electron → **[Ar]3d^8^4s^2^**. Cả hai không rơi vào ngoại lệ (mượn 1 electron vẫn không đủ d^10^).
>
> b) Co có 7 electron 3d, 7 + 2 = **9** electron hoá trị. Ni có 8 electron 3d, 8 + 2 = **10** electron hoá trị.

> [!bay]
> - Viết Cr là [Ar]3d^4^4s^2^ hay Cu là [Ar]3d^9^4s^2^ là lỗi hay gặp nhất. Hai cấu hình đúng: Cr [Ar]3d^5^4s^1^ và Cu [Ar]3d^10^4s^1^.
> - Theo SGK, dãy chuyển tiếp thứ nhất dừng ở **Cu (Z = 29)**. Zn (Z = 30) không nằm trong danh sách của bài này.
> - Lớp ngoài cùng (4s) chỉ có 1–2 electron, nhưng số electron **hoá trị** của kim loại chuyển tiếp phải tính cả 3d.

## 2. Tính chất vật lí và ứng dụng

### 2.1. Đọc Bảng 27.2

Bảng 27.2 (SGK tr. 130) cho 5 thông số vật lí của 9 kim loại. Em không cần thuộc hết các con số, nhưng cần biết **đọc bảng** và rút ra xu hướng, vì đề thi rất hay cho bảng số liệu.

| Kim loại | Sc | Ti | V | Cr | Mn | Fe | Co | Ni | Cu |
|---|---|---|---|---|---|---|---|---|---|
| t~nc~ (°C) | 1 541 | 1 668 | 1 917 | 1 907 | 1 244 | 1 535 | 1 494 | 1 453 | 1 084 |
| D (g/cm^3^) | 2,98 | 4,50 | 6,11 | 7,15 | 7,21 | 7,86 | 8,90 | 8,91 | 8,96 |
| Dẫn điện (Hg = 1) | 1,7 | 2,3 | 4,9 | 7,7 | 0,7 | 10 | 15,4 | 13,8 | 57,1 |
| Dẫn nhiệt (Hg = 1) | 1,9 | 2,6 | 3,7 | 11,3 | 0,9 | 9,7 | 12,0 | 11,0 | 48,3 |
| Độ cứng (kim cương = 10) | – | 6 | 7 | 8,5 | 6 | 4 | 5 | 4 | 3 |

(t~nc~: nhiệt độ nóng chảy; D: khối lượng riêng. Độ dẫn điện, dẫn nhiệt so với thuỷ ngân.)

Từ bảng, ta rút ra 4 nhận xét (khớp với Bảng 27.3, SGK tr. 131):

1. **Khó nóng chảy**: cả 9 kim loại đều nóng chảy trên 1 000 °C, cao nhất là V (1 917 °C) rồi đến Cr (1 907 °C), tiếp theo là Ti (1 668 °C).
2. **Cứng**: phần lớn có độ cứng từ 4 đến 8,5. **Chromium (8,5) là kim loại cứng nhất** trong tất cả các kim loại.
3. **Phần lớn là kim loại nặng** (D ≥ 5 g/cm^3^). Chỉ **Sc và Ti tương đối nhẹ**.
4. **Dẫn điện, dẫn nhiệt tương đối tốt**, nổi bật là **đồng** (dẫn điện tốt chỉ sau bạc).

> [!bay] Đọc số liệu, đừng chỉ đọc lời
> Bảng 27.3 SGK viết "khó nóng chảy, đặc biệt là vanadium, chromium và cobalt". Nhưng theo chính Bảng 27.2, cobalt (1 494 °C) còn nóng chảy thấp hơn Ti, Sc và Fe. Khi đề cho bảng số liệu và hỏi kim loại khó nóng chảy nhất, em **so các con số**: cao nhất là V, rồi Cr. (Ở Bảng 27.2, nhiệt độ nóng chảy của Sc in là "1,541", nghĩa là 1 541 °C.)

![Hình 2. Nhiệt độ nóng chảy của kim loại chuyển tiếp dãy thứ nhất so với K và Ca cùng chu kì 4 (số liệu SGK Bảng 24.2, 25.2, 27.2)](nhiet-do.svg)

**Vì sao kim loại chuyển tiếp khó nóng chảy và cứng hơn K, Ca?** (giải thích thêm, ngoài SGK) Nhớ lại Bài 18: liên kết kim loại là lực hút giữa các ion dương và "biển" electron tự do. Nguyên tử K chỉ góp 1 electron, Ca góp 2 electron vào biển electron. Kim loại chuyển tiếp góp được **nhiều hơn**, vì cả electron 3d cũng tham gia liên kết. Nguyên tử của chúng lại **nhỏ hơn**, nên các ion xếp sít nhau. Biển electron "đặc" hơn, ion nhỏ hơn, nên liên kết kim loại **bền hơn nhiều**. Muốn phá mạng tinh thể phải tốn nhiều nhiệt hơn (khó nóng chảy), và các lớp nguyên tử khó trượt lên nhau hơn (cứng). Nguyên tử nặng mà lại xếp sít nhau thì khối lượng riêng lớn.

**So sánh với kim loại họ s.** Em hãy đối chiếu (theo yêu cầu 2 SGK tr. 130):

| Kim loại | K | Ca | Fe | Cu |
|---|---|---|---|---|
| t~nc~ (°C) | 63,4 | 842 | 1 535 | 1 084 |
| D (g/cm^3^) | 0,89 | 1,55 | 7,86 | 8,96 |
| Dẫn điện (Hg = 1) | 13,3 | 28,5 | 10 | 57,1 |
| Độ cứng | 0,4 | 1,75 | 4 | 3 |

Fe và Cu nóng chảy cao hơn, nặng hơn và cứng hơn hẳn K, Ca. Riêng về **độ dẫn điện** thì không có quy luật "luôn hơn": Cu dẫn điện tốt nhất, nhưng Fe lại dẫn điện **kém hơn** cả K và Ca.

> [!bay]
> - "Kim loại chuyển tiếp dẫn điện tốt hơn kim loại họ s": **sai** nếu áp cho mọi kim loại. Theo bảng, Fe (10) và Mn (0,7) dẫn điện kém hơn K (13,3) và Ca (28,5).
> - "Tất cả kim loại chuyển tiếp dãy thứ nhất đều là kim loại nặng": **sai**, vì Sc (2,98) và Ti (4,50) có D < 5 g/cm^3^.
> - Các thông số **không biến đổi đều** từ Sc đến Cu. Ví dụ Mn nóng chảy thấp và dẫn điện kém bất thường, Cu lại mềm nhất trong 8 kim loại có số liệu độ cứng. Đừng chọn phát biểu kiểu "tăng dần từ Sc đến Cu", trừ **khối lượng riêng** (theo bảng thì tăng dần).

### 2.2. Ứng dụng xuất phát từ tính chất

Mỗi ứng dụng đều "trả lời" cho một tính chất (Bảng 27.3, SGK tr. 131):

| Tính chất | Ứng dụng |
|---|---|
| Khó nóng chảy | Dụng cụ, máy móc, thiết bị làm việc ở nhiệt độ cao |
| Rất cứng (Cr) | Hợp kim không gỉ, hợp kim siêu cứng: dụng cụ y tế, đồ nhà bếp, vòng bi, mũi khoan |
| Nhẹ, bền (Sc, Ti) | Vật liệu hàng không, gọng kính |
| Nặng, bền (Fe, Ni…) | Phương tiện giao thông, máy móc, bệ máy |
| Dẫn điện tốt (Cu) | Dây dẫn, thiết bị điện |
| Dẫn nhiệt tốt (Cu) | Nồi hơi, thiết bị trao đổi nhiệt, đồ gia dụng |

> [!ung-dung] Vì sao máy bay "thích" titanium?
> Ti vừa nhẹ (4,50 g/cm^3^, chưa bằng 60% của sắt), vừa bền, chịu nhiệt tốt và khó bị ăn mòn. Thay một chi tiết thép bằng chi tiết Ti cùng kích thước thì khối lượng giảm hơn 40%, máy bay đỡ tốn nhiên liệu hơn. Gọng kính titanium nhẹ và không gỉ cũng vì lí do này.

> [!vi-du] Ví dụ 2
> Dựa vào Bảng 27.2.
>
> a) Cùng khối lượng 1 kg, thể tích của titanium gấp bao nhiêu lần thể tích của sắt (làm tròn đến hàng phần trăm)?
>
> b) Một kĩ sư cần chọn kim loại cho ba việc: (1) mạ lên dụng cụ để chống trầy xước, (2) làm lõi dây cáp điện, (3) làm vỏ thiết bị bay cần nhẹ. Nên chọn kim loại nào trong số Cr, Cu, Ti?

> [!goi-y] Gợi ý 1
> V = m : D. Cùng m thì thể tích tỉ lệ **nghịch** với khối lượng riêng.

> [!goi-y] Gợi ý 2
> Xem dòng nào trong bảng ứng với từng yêu cầu: chống trầy xước cần độ cứng, cáp điện cần độ dẫn điện, thiết bị bay cần D nhỏ.

> [!loi-giai] Lời giải
> a) V(Ti) : V(Fe) = D(Fe) : D(Ti) = 7,86 : 4,50 ≈ **1,75** lần.
>
> b) (1) **Cr**, cứng nhất (8,5). (2) **Cu**, dẫn điện tốt nhất (57,1). (3) **Ti**, nhẹ (4,50 g/cm^3^) mà vẫn cứng (6).

## 3. Số oxi hoá của kim loại chuyển tiếp trong hợp chất

Đây là mục mở đầu phần II của SGK (Hợp chất của kim loại chuyển tiếp dãy thứ nhất).

### 3.1. Vì sao có nhiều số oxi hoá?

Kim loại nhóm IA chỉ có số oxi hoá +1, nhóm IIA chỉ có +2, vì chúng chỉ có 1 hoặc 2 electron hoá trị. Kim loại chuyển tiếp có **nhiều electron hoá trị ở cả 4s và 3d**. Năng lượng của hai phân lớp này lại gần nhau. Vì thế, tuỳ chất phản ứng, nguyên tử có thể nhường 2, 3, … electron, tạo ra **nhiều trạng thái oxi hoá khác nhau**.

Các số oxi hoá thường gặp (Bảng 27.4, SGK tr. 131):

| Nguyên tố | Cr | Mn | Fe | Cu |
|---|---|---|---|---|
| Số oxi hoá thường gặp | +3, +6 | +2, +4, +7 | +2, +3 | +2 |

> [!nen-tang] Cách tính số oxi hoá (Hoá 10)
> - Tổng số oxi hoá trong phân tử bằng 0, trong ion bằng điện tích ion.
> - O thường là −2; H là +1; K, Na là +1.
> - Nhóm SO~4~ mang điện tích 2−, nhóm OH mang 1−.

> [!vi-du] Ví dụ 3
> Xác định số oxi hoá của chromium trong Cr(OH)~3~, Na~2~CrO~4~, Na~2~Cr~2~O~7~ và của manganese trong MnSO~4~, MnO~2~, K~2~MnO~4~.

> [!goi-y] Gợi ý 1
> Gọi số oxi hoá cần tìm là x, rồi lập phương trình tổng bằng 0.

> [!goi-y] Gợi ý 2
> Với Na~2~Cr~2~O~7~ có **2** nguyên tử Cr: 2·(+1) + 2x + 7·(−2) = 0.

> [!loi-giai] Lời giải
> - Cr(OH)~3~: x + 3·(−1) = 0 → **+3**.
> - Na~2~CrO~4~: 2 + x − 8 = 0 → **+6**.
> - Na~2~Cr~2~O~7~: 2 + 2x − 14 = 0 → **+6**.
> - MnSO~4~: x − 2 = 0 → **+2**.
> - MnO~2~: x − 4 = 0 → **+4**.
> - K~2~MnO~4~: 2 + x − 8 = 0 → **+6**.
>
> K~2~MnO~4~ (potassium manganate, màu lục) cho thấy Mn còn có số oxi hoá +6, ngoài ba số oxi hoá "thường gặp" trong Bảng 27.4.

### 3.2. Cấu hình electron của ion

Khi tạo cation, nguyên tử kim loại chuyển tiếp **nhường electron 4s trước**, rồi mới đến 3d (SGK tr. 131):

=> Fe ([Ar]3d^6^4s^2^) → Fe^2+^ ([Ar]3d^6^) + 2e

=> Fe ([Ar]3d^6^4s^2^) → Fe^3+^ ([Ar]3d^5^) + 3e

**Vì sao 4s mất trước, dù 4s được điền trước?** Thứ tự **điền** electron và thứ tự **mất** electron là hai chuyện khác nhau. Lớp 4s là lớp **ngoài cùng**, xa hạt nhân nhất, nên electron 4s bị hút yếu nhất và bị tách ra đầu tiên.

**Cách làm nhanh**: viết cấu hình nguyên tử, bỏ hết electron 4s, nếu còn thiếu thì bỏ tiếp ở 3d.

> [!em-co-biet] Vì sao muối sắt(II) dễ chuyển thành sắt(III)?
> Fe^3+^ có cấu hình 3d^5^, phân lớp d nửa bão hoà nên khá bền. Vì thế Fe^2+^ (3d^6^) dễ nhường thêm 1 electron. Dung dịch FeSO~4~ để lâu ngoài không khí dần ngả vàng do một phần Fe^2+^ bị oxi hoá thành Fe^3+^ (giải thích thêm, ngoài SGK).

> [!vi-du] Ví dụ 4
> Viết cấu hình electron của các ion V^3+^ (Z~V~ = 23), Co^2+^ (Z~Co~ = 27) và Cu^+^ (Z~Cu~ = 29).

> [!goi-y] Gợi ý 1
> Viết cấu hình nguyên tử trước. Nhớ Cu là ngoại lệ: [Ar]3d^10^4s^1^.

> [!goi-y] Gợi ý 2
> Bỏ electron 4s trước. V^3+^ mất 3 electron: 2 electron 4s rồi thêm 1 electron 3d.

> [!loi-giai] Lời giải
> - V [Ar]3d^3^4s^2^ → V^3+^: **[Ar]3d^2^**.
> - Co [Ar]3d^7^4s^2^ → Co^2+^: **[Ar]3d^7^**.
> - Cu [Ar]3d^10^4s^1^ → Cu^+^: **[Ar]3d^10^** (chỉ mất 1 electron 4s).
>
> Em tự làm tiếp câu hỏi 2 SGK tr. 132 (Cr^3+^, Mn^2+^, Cu^2+^) và đối chiếu với Tóm tắt cuối bài.

> [!bay]
> - Viết Fe^2+^ là [Ar]3d^4^4s^2^ (bỏ electron 3d trước) là **sai**. Đúng là [Ar]3d^6^.
> - Ion Cr^3+^, Cu^2+^ phải đi từ cấu hình nguyên tử **ngoại lệ**: Cr^3+^ [Ar]3d^3^; Cu^2+^ [Ar]3d^9^.

## 4. Màu sắc của ion kim loại chuyển tiếp

Khác với ion Na^+^, Ca^2+^, Mg^2+^ (dung dịch không màu), nhiều ion kim loại chuyển tiếp có **màu đặc trưng** (Hình 27.2, SGK tr. 132):

| Dung dịch chứa ion | Màu |
|---|---|
| Fe^2+^ (ví dụ FeSO~4~) | lục nhạt |
| Fe^3+^ (ví dụ FeCl~3~) | vàng (đậm thì vàng nâu) |
| Cu^2+^ (ví dụ CuSO~4~) | xanh lam |
| MnO~4~^−^ (KMnO~4~, thuốc tím) | tím |

Màu sắc giúp ta **nhận ra ion bằng mắt** và **biết phản ứng đã xảy ra** (như trong phép chuẩn độ ở mục 5). Ion Mn^2+^ ở nồng độ loãng gần như không màu, đây là điều làm cho thuốc tím "mất màu" khi phản ứng (mở rộng).

> [!em-co-biet] Vì sao ion chuyển tiếp có màu? (mở rộng, ngoài SGK)
> Các ion này có phân lớp 3d chưa đầy electron. Electron 3d hấp thụ một phần ánh sáng nhìn thấy, phần ánh sáng còn lại đến mắt ta tạo thành màu. Ví dụ, dung dịch Cu^2+^ hấp thụ mạnh ánh sáng màu đỏ – cam nên ta thấy màu xanh lam. Ion có phân lớp 3d trống hoặc đầy (như Sc^3+^, Cu^+^) thường không màu.

## 5. Chuẩn độ iron(II) sulfate bằng thuốc tím

### 5.1. Phản ứng và nguyên tắc

Trong môi trường sulfuric acid, thuốc tím oxi hoá Fe^2+^ thành Fe^3+^ (SGK tr. 132):

=> 10FeSO~4~ + 2KMnO~4~ + 8H~2~SO~4~ → 5Fe~2~(SO~4~)~3~ + K~2~SO~4~ + 2MnSO~4~ + 8H~2~O

**Vì sao tỉ lệ là 5 : 1?** Xét sự trao đổi electron:

- Mn từ **+7** (trong MnO~4~^−^) xuống **+2** (Mn^2+^): **nhận 5 electron**.
- Fe từ **+2** lên **+3**: **nhường 1 electron**.

Một ion MnO~4~^−^ "ăn" 5 electron, nên phải cần 5 ion Fe^2+^ mới đủ. Phương trình ion thu gọn (mở rộng) cho thấy rõ tỉ lệ này:

=> MnO~4~^−^ + 5Fe^2+^ + 8H^+^ → Mn^2+^ + 5Fe^3+^ + 4H~2~O

Công thức dùng để tính:

$$n_{\mathrm{Fe^{2+}}} = 5\,n_{\mathrm{KMnO_4}}$$

$$C_{\mathrm{Fe}}\cdot V_{\mathrm{Fe}} = 5\,C_{\mathrm{KMnO_4}}\cdot V_{\mathrm{KMnO_4}}$$

**Nguyên tắc chuẩn độ**: ta biết chính xác nồng độ KMnO~4~ (dung dịch chuẩn) và thể tích FeSO~4~ lấy ra. Nhỏ từ từ KMnO~4~ cho đến khi Fe^2+^ vừa hết, đọc thể tích KMnO~4~ đã dùng, rồi tính ngược ra nồng độ FeSO~4~.

### 5.2. Thí nghiệm (SGK tr. 132)

Tóm tắt: dùng pipette lấy chính xác 5,0 mL dung dịch FeSO~4~ (khoảng 0,1 M) cho vào bình tam giác, thêm khoảng 5 mL H~2~SO~4~ 10%. Cho dung dịch KMnO~4~ 0,02 M vào burette, chỉnh về vạch 0. Nhỏ từng giọt KMnO~4~ xuống bình, vừa nhỏ vừa lắc. Dừng khi màu hồng **bền trong khoảng 20 giây**. Ghi thể tích, làm 3 lần, lấy trung bình.

![Hình 3. Chuẩn độ FeSO~4~ bằng KMnO~4~: trước điểm tương đương giọt thuốc tím mất màu ngay; tại điểm kết thúc chỉ 1 giọt dư làm dung dịch hồng nhạt bền](chuan-do.svg)

Hiểu **vì sao** của từng chi tiết:

- **Không cần chất chỉ thị.** Còn Fe^2+^ thì MnO~4~^−^ (tím) bị khử ngay thành Mn^2+^ (gần như không màu), nên giọt thuốc tím mất màu. Khi Fe^2+^ vừa hết, giọt KMnO~4~ dư tiếp theo không còn gì để phản ứng, nên dung dịch có màu hồng. KMnO~4~ vừa là chất phản ứng vừa là "chất chỉ thị".
- **Vì sao chờ màu hồng bền 20 giây?** Lúc gần kết thúc, màu hồng có thể xuất hiện ở chỗ giọt rơi rồi mất đi khi lắc, vì còn Fe^2+^ ở phần khác của bình. Màu bền nghĩa là Fe^2+^ đã hết thật.
- **Vì sao phải thêm H~2~SO~4~?** Phản ứng cần H^+^ (8H^+^ trong phương trình ion). Thiếu acid, MnO~4~^−^ bị khử thành MnO~2~ (kết tủa nâu đen), tỉ lệ 5 : 1 không còn đúng (mở rộng).
- **Vì sao làm 3 lần và lấy trung bình?** Để giảm sai số do đọc vạch, do giọt thừa.
- **Lưu ý của SGK**: ban đầu thuốc tím mất màu chậm, sau đó mất màu nhanh. Đó là vì chính ion Mn^2+^ sinh ra làm **xúc tác** cho phản ứng (mở rộng, ngoài SGK).

> [!bay]
> - Không acid hoá bằng HCl. KMnO~4~ oxi hoá được cả Cl^−^, nên tốn thêm thuốc tím và kết quả bị sai (mở rộng).
> - Quên hệ số **5** là lỗi phổ biến nhất: n(Fe^2+^) = **5**·n(KMnO~4~), không phải bằng nhau.
> - Dừng quá sớm (khi màu hồng chưa bền) thì V(KMnO~4~) nhỏ hơn thực tế, nên nồng độ Fe^2+^ tính được **thấp hơn** thực tế. Nhỏ quá tay sau điểm cuối thì ngược lại.

> [!vi-du] Ví dụ 5
> Chuẩn độ 10,0 mL dung dịch FeSO~4~ (đã thêm H~2~SO~4~ loãng) bằng dung dịch KMnO~4~ 0,02 M. Ba lần thí nghiệm dùng hết lần lượt 9,7 mL; 9,6 mL; 9,8 mL dung dịch KMnO~4~. Tính nồng độ mol của dung dịch FeSO~4~.

> [!goi-y] Gợi ý 1
> Lấy thể tích trung bình trước. Nhớ đổi mL sang L khi tính số mol (hoặc tính bằng mmol cho gọn).

> [!goi-y] Gợi ý 2
> n(Fe^2+^) = 5·n(KMnO~4~). Chia cho thể tích FeSO~4~ để ra nồng độ.

> [!loi-giai] Lời giải
> V~tb~(KMnO~4~) = (9,7 + 9,6 + 9,8) : 3 = 9,7 mL.
>
> n(KMnO~4~) = 0,02 · 9,7 = 0,194 mmol → n(FeSO~4~) = 5 · 0,194 = 0,97 mmol.
>
> C(FeSO~4~) = 0,97 : 10,0 = **0,097 M**.

> [!meo] Tính bằng mmol cho đỡ đổi đơn vị
> M × mL = mmol. Một dòng là xong: C~Fe~ = 5 · C~KMnO4~ · V~KMnO4~ : V~Fe~ (hai thể tích cùng đơn vị mL).

## 6. Nhận biết một số ion kim loại chuyển tiếp

Ion kim loại chuyển tiếp thường được nhận biết dựa vào **màu của ion**, **màu của hợp chất ít tan** (kết tủa) hoặc **màu của phức chất** (học ở Bài 28, 29).

Thí nghiệm SGK (tr. 133): nhỏ vài giọt NaOH vào ống chứa FeCl~3~ và ống chứa CuSO~4~.

=> FeCl~3~ + 3NaOH → Fe(OH)~3~↓ (**nâu đỏ**) + 3NaCl

=> CuSO~4~ + 2NaOH → Cu(OH)~2~↓ (**xanh lam**) + Na~2~SO~4~

Phương trình ion thu gọn: Fe^3+^ + 3OH^−^ → Fe(OH)~3~↓ và Cu^2+^ + 2OH^−^ → Cu(OH)~2~↓.

![Hình 4. Màu dung dịch và màu kết tủa hydroxide của một số ion. Fe(OH)~2~ (lục nhạt, hoá nâu đỏ trong không khí) là kiến thức mở rộng](nhan-biet.svg)

> [!em-co-biet] Thêm hai dấu hiệu hay gặp (mở rộng)
> - Fe^2+^ + NaOH tạo Fe(OH)~2~ màu trắng hơi xanh lục, để ngoài không khí chuyển dần sang nâu đỏ (bị O~2~ oxi hoá thành Fe(OH)~3~).
> - Dung dịch Fe^2+^ làm **mất màu** thuốc tím trong môi trường acid (phản ứng ở mục 5), còn Fe^3+^ thì không. Đây là cách phân biệt muối sắt(II) và sắt(III).

> [!vi-du] Ví dụ 6
> Có 4 lọ mất nhãn, mỗi lọ đựng một trong các dung dịch: FeCl~3~, CuCl~2~, MgCl~2~, NaCl. Chỉ dùng thêm dung dịch NaOH, hãy nhận biết từng lọ.

> [!goi-y] Gợi ý 1
> Trước khi dùng thuốc thử, quan sát màu dung dịch đã có thể đoán được hai lọ.

> [!goi-y] Gợi ý 2
> Mg(OH)~2~ là kết tủa gì (Bài 25)? NaOH có tạo kết tủa với NaCl không?

> [!loi-giai] Lời giải
> Lấy mỗi lọ một ít làm mẫu thử, nhỏ dung dịch NaOH vào:
>
> - Kết tủa **nâu đỏ** → FeCl~3~ (Fe(OH)~3~).
> - Kết tủa **xanh lam** → CuCl~2~ (Cu(OH)~2~).
> - Kết tủa **trắng** → MgCl~2~ (Mg(OH)~2~).
> - Không hiện tượng → NaCl.

## Dạng bài thi hay gặp

### Dạng 1. Cấu hình electron của nguyên tử, ion → xác định nguyên tố

**Nhận biết:** đề cho cấu hình của ion M^n+^ (hoặc số electron ở phân lớp 3d), hỏi M là nguyên tố nào, có bao nhiêu electron hoá trị, hoặc chọn cấu hình đúng/sai.

**Phương pháp:**

1. Đếm số electron của ion: 18 (lõi [Ar]) + số electron 3d (+ 4s nếu có).
2. **Cộng thêm n** (số electron đã mất) để ra Z của nguyên tử.
3. Viết lại cấu hình nguyên tử để kiểm tra, nhớ hai ngoại lệ Cr, Cu.

> [!vi-du] Ví dụ 7
> Ion X^3+^ có cấu hình electron [Ar]3d^3^. Ion Y^2+^ có cấu hình [Ar]3d^9^. Xác định X, Y và viết cấu hình electron nguyên tử của chúng.

> [!goi-y] Gợi ý 1
> X^3+^ có 18 + 3 = 21 electron. Nguyên tử X có nhiều hơn 3 electron.

> [!goi-y] Gợi ý 2
> Z~X~ = 24 và Z~Y~ = 29 đều là hai nguyên tố "ngoại lệ". Đừng viết X là [Ar]3d^4^4s^2^.

> [!loi-giai] Lời giải
> - X: Z = 18 + 3 + 3 = 24 → **Cr**, cấu hình [Ar]3d^5^4s^1^. Kiểm tra: bỏ 1 electron 4s và 2 electron 3d thì còn [Ar]3d^3^. ✓
> - Y: Z = 18 + 9 + 2 = 29 → **Cu**, cấu hình [Ar]3d^10^4s^1^. Kiểm tra: bỏ 1 electron 4s và 1 electron 3d thì còn [Ar]3d^9^. ✓

> [!bay]
> - Quên cộng n: thấy "[Ar]3d^3^" mà kết luận ngay Z = 21 (Sc) là sai.
> - Đề hay đưa phương án "[Ar]3d^7^4s^2^" cho Cu^2+^ hoặc "[Ar]3d^4^4s^2^" cho Cr để bẫy. Ion kim loại chuyển tiếp dãy thứ nhất thường **không còn** electron 4s.

### Dạng 2. Đọc bảng số liệu tính chất vật lí

**Nhận biết:** đề cho bảng (thường trích Bảng 27.2, có thể kèm K, Ca, Na, Mg), hỏi số kim loại thoả một điều kiện, so sánh, hay tính khối lượng, thể tích từ khối lượng riêng.

**Phương pháp:**

1. Gạch chân **điều kiện** của đề: "nặng" là D ≥ 5 g/cm^3^; "khó nóng chảy hơn X" là t~nc~ > t~nc~(X).
2. Đi lần lượt từng cột, đánh dấu và **đếm hai lần**.
3. Bài tính: m = D · V (1 cm^3^ ứng với D gam; 1 dm^3^ ứng với D kg).

> [!vi-du] Ví dụ 8
> Theo Bảng 27.2:
>
> a) Có bao nhiêu kim loại chuyển tiếp dãy thứ nhất có nhiệt độ nóng chảy cao hơn 1 500 °C?
>
> b) Có bao nhiêu kim loại là kim loại nặng?

> [!goi-y] Gợi ý 1
> So từng số trong dòng t~nc~ với 1 500. Cẩn thận với Sc (1 541) và Fe (1 535), chỉ hơn 1 500 một chút.

> [!goi-y] Gợi ý 2
> Kim loại nặng có D ≥ 5 g/cm^3^. Chỉ cần tìm kim loại **không** thoả rồi lấy 9 trừ đi.

> [!loi-giai] Lời giải
> a) Có **5** kim loại: Sc (1 541), Ti (1 668), V (1 917), Cr (1 907), Fe (1 535). Bốn kim loại Mn, Co, Ni, Cu đều thấp hơn 1 500 °C.
>
> Câu hỏi 1a SGK tr. 130 (so với Be, 1 287 °C) em tự làm theo cách này, chỉ Mn và Cu là thấp hơn Be.
>
> b) Sc (2,98) và Ti (4,50) nhẹ. Còn lại **7** kim loại nặng: V, Cr, Mn, Fe, Co, Ni, Cu.

### Dạng 3. Chuẩn độ Fe^2+^ bằng KMnO~4~

**Nhận biết:** có thuốc tím (KMnO~4~), muối sắt(II) (FeSO~4~, FeSO~4~·7H~2~O, viên sắt), môi trường H~2~SO~4~. Đề hỏi nồng độ, khối lượng, độ tinh khiết, hàm lượng sắt, hoặc thể tích KMnO~4~ cần dùng.

**Phương pháp:**

1. Tính thể tích KMnO~4~ trung bình (nếu có nhiều lần đo).
2. n(Fe^2+^) = 5 · n(KMnO~4~).
3. Nếu chỉ chuẩn độ một **phần** dung dịch (ví dụ 10 mL trong 100 mL) thì nhân với **hệ số pha loãng** (100 : 10).
4. Muối ngậm nước: M(FeSO~4~·7H~2~O) = 278 g/mol. Độ tinh khiết = m(muối tính được) : m(mẫu) · 100%.

> [!vi-du] Ví dụ 9
> Hoà tan 3,00 g một mẫu muối FeSO~4~·7H~2~O (có lẫn tạp chất không phản ứng) vào nước, được 100,0 mL dung dịch. Lấy 10,0 mL dung dịch này, thêm H~2~SO~4~ loãng rồi chuẩn độ bằng KMnO~4~ 0,02 M thì hết 10,4 mL. Tính phần trăm khối lượng FeSO~4~·7H~2~O trong mẫu (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Số mmol Fe^2+^ trong 10 mL = 5 · 0,02 · 10,4. Trong 100 mL thì gấp mấy lần?

> [!goi-y] Gợi ý 2
> Mỗi mol Fe^2+^ ứng với 1 mol FeSO~4~·7H~2~O nặng 278 g.

> [!loi-giai] Lời giải
> Trong 10 mL: n(Fe^2+^) = 5 · 0,02 · 10,4 = 1,04 mmol.
>
> Trong 100 mL: n = 1,04 · 10 = 10,4 mmol = 0,0104 mol.
>
> m(FeSO~4~·7H~2~O) = 0,0104 · 278 = 2,8912 g → % = 2,8912 : 3,00 · 100% ≈ **96,4%**.

> [!bay]
> - Quên nhân 10 (chỉ chuẩn độ 1/10 dung dịch) sẽ ra 9,6%, một con số vô lí cho "muối khá tinh khiết".
> - Dùng M = 152 (FeSO~4~ khan) thay vì 278 cho muối ngậm nước.

### Dạng 4. Câu Đúng/Sai lí thuyết tổng hợp

**Nhận biết:** 4 ý về cấu hình, tính chất vật lí, số oxi hoá, màu sắc, thí nghiệm chuẩn độ hoặc nhận biết.

**Phương pháp:** soát kĩ các từ khoá hay bị đánh tráo: **4s hay 3d mất trước**, **Cr/Cu ngoại lệ**, **"tất cả" hay "phần lớn"** (nặng, dẫn điện), **cứng nhất là Cr**, **5 : 1** trong chuẩn độ, **nâu đỏ / xanh lam**.

> [!vi-du] Ví dụ 10 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Nguyên tử các nguyên tố từ Sc đến Cu đều có 2 electron ở phân lớp 4s.
>
> b) Trong hợp chất K~2~Cr~2~O~7~ và CrO~3~, chromium đều có số oxi hoá +6.
>
> c) Trong phép chuẩn độ FeSO~4~ bằng KMnO~4~, cần thêm vài giọt phenolphthalein làm chất chỉ thị.
>
> d) Cho dung dịch NaOH vào dung dịch CuSO~4~ thu được kết tủa màu xanh lam.

> [!goi-y] Gợi ý 1
> Nhớ hai nguyên tố ngoại lệ. Tính số oxi hoá: CrO~3~ có x − 6 = 0.

> [!goi-y] Gợi ý 2
> KMnO~4~ có màu tím, sản phẩm Mn^2+^ gần như không màu. Vậy có cần chỉ thị không?

> [!loi-giai] Lời giải
> a) **Sai**: Cr và Cu chỉ có 1 electron 4s.
>
> b) **Đúng**: K~2~Cr~2~O~7~: 2 + 2x − 14 = 0 → x = +6; CrO~3~: x − 6 = 0 → x = +6.
>
> c) **Sai**: KMnO~4~ tự làm chỉ thị (màu hồng bền khi dư 1 giọt).
>
> d) **Đúng**: Cu(OH)~2~ màu xanh lam.

## Tóm tắt

| Nội dung | Kiến thức chính |
|---|---|
| Phạm vi | Sc (Z = 21) → Cu (Z = 29), chu kì 4, khối d |
| Cấu hình chung | [Ar]3d^1–10^4s^1–2^; Cr [Ar]3d^5^4s^1^; Cu [Ar]3d^10^4s^1^ |
| Tạo ion | Mất electron 4s trước, rồi 3d. Fe^2+^ [Ar]3d^6^; Fe^3+^ [Ar]3d^5^; Cr^3+^ [Ar]3d^3^; Mn^2+^ [Ar]3d^5^; Cu^2+^ [Ar]3d^9^ |
| Tính chất vật lí | Khó nóng chảy (cao nhất V, Cr > 1 900 °C), cứng (Cr cứng nhất), phần lớn là kim loại nặng (trừ Sc, Ti), dẫn điện và dẫn nhiệt tương đối tốt (Cu nổi bật) |
| Ứng dụng | Thiết bị chịu nhiệt; hợp kim không gỉ, siêu cứng (Cr); hàng không, gọng kính (Ti); giao thông, máy móc; dây dẫn, trao đổi nhiệt (Cu) |
| Số oxi hoá thường gặp | Cr +3, +6; Mn +2, +4, +7; Fe +2, +3; Cu +2 |
| Màu ion | Fe^2+^ lục nhạt; Fe^3+^ vàng; Cu^2+^ xanh lam; MnO~4~^−^ tím |
| Nhận biết bằng NaOH | Fe(OH)~3~ nâu đỏ; Cu(OH)~2~ xanh lam |

**Chuẩn độ:**

- 10FeSO~4~ + 2KMnO~4~ + 8H~2~SO~4~ → 5Fe~2~(SO~4~)~3~ + K~2~SO~4~ + 2MnSO~4~ + 8H~2~O.
- n(Fe^2+^) = 5·n(KMnO~4~); C~Fe~·V~Fe~ = 5·C~KMnO4~·V~KMnO4~.
- Điểm kết thúc: màu hồng nhạt bền khoảng 20 giây. KMnO~4~ tự làm chỉ thị. Môi trường H~2~SO~4~.
