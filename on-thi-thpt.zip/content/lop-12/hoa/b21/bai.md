---
title: Hợp kim
thoi-gian: 35 phút
muc-tieu:
  - Trình bày được hợp kim là gì, cách điều chế thường dùng và vì sao hợp kim được dùng nhiều hơn kim loại nguyên chất.
  - So sánh được tính chất của hợp kim với kim loại thành phần (tính chất hoá học, dẫn điện, dẫn nhiệt, độ cứng, độ dẻo, nhiệt độ nóng chảy) và giải thích được bằng cấu tạo tinh thể.
  - Nêu được thành phần, tính chất, ứng dụng của gang, thép, thép không gỉ (hợp kim của sắt) và duralumin (hợp kim của nhôm).
  - Giải được bài toán tính phần trăm khối lượng thành phần hợp kim khi cho tác dụng với acid, và bài toán hàm lượng carbon trong gang, thép.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Hợp kim** là vật liệu kim loại gồm **một kim loại cơ bản** và một số kim loại khác hoặc phi kim. Thường điều chế bằng cách **nung chảy các thành phần rồi để nguội**.
> 2. **Tính chất hoá học**: nhìn chung **tương tự các kim loại thành phần** (thành phần nào phản ứng được với acid thì vẫn phản ứng khi nằm trong hợp kim).
> 3. **Tính chất vật lí** khác nhiều: hợp kim vẫn có ánh kim, dẫn điện, dẫn nhiệt nhưng **dẫn điện, dẫn nhiệt kém hơn** kim loại cơ bản; **cứng hơn** và **kém dẻo hơn**; nhiệt độ nóng chảy **khác** kim loại thành phần (gang nóng chảy **thấp hơn** sắt).
> 4. Hợp kim của sắt: **gang** (khoảng 95% Fe, **2–4% C**, cứng nhưng giòn); **thép** (**dưới 2,0% C**); **thép không gỉ** (**ít nhất 10% Cr**). Hợp kim của nhôm: **duralumin** (trên 90% Al, khoảng 4% Cu…, nhẹ, cứng, bền, làm máy bay).
> 5. Bài toán: chỉ thành phần **có phản ứng** mới tạo khí. Tính số mol khí → số mol, khối lượng thành phần đó → phần trăm. Dùng **24,79 L/mol** ở điều kiện chuẩn.

Khung xe đạp, vỏ máy bay, nồi inox, nhẫn vàng… hầu như không làm từ kim loại nguyên chất. Bài này giải thích vì sao chỉ "pha" thêm vài phần trăm nguyên tố khác mà vật liệu lại cứng, bền hơn hẳn. Chìa khoá là **tinh thể kim loại** (Bài 18) và **electron tự do** (Bài 19).

## 1. Khái niệm và ứng dụng của hợp kim

### 1.1. Khái niệm hợp kim

**Hợp kim** là vật liệu kim loại chứa **một kim loại cơ bản** (chiếm phần lớn) cùng với **một số kim loại khác hoặc phi kim** (SGK tr. 99).

- **Thép, gang**: kim loại cơ bản là **Fe**, thêm **C** và một số nguyên tố khác (Mn, Si…).
- **Duralumin**: kim loại cơ bản là **Al**, thêm Cu, Mn, Mg, Si.

Cách điều chế thường dùng: **nung chảy các thành phần** cho chúng trộn đều vào nhau ở thể lỏng, **rồi để nguội** cho đông đặc thành khối rắn.

**Bên trong hợp kim trông như thế nào?** (giải thích mở rộng, ngoài SGK). Trong tinh thể kim loại, các ion dương xếp đều đặn như những viên bi giống hệt nhau (Bài 18). Nguyên tử lạ có hai cách vào mạng (Hình 1):

- **Thay thế**: nguyên tử kim loại có kích thước gần bằng **chiếm chỗ** một số nguyên tử kim loại cơ bản (Cu trong vàng trang sức).
- **Xen kẽ**: nguyên tử **rất nhỏ** **chui vào khe trống** giữa các nguyên tử kim loại cơ bản (C trong sắt).

![Hình 1. Kim loại nguyên chất gồm các nguyên tử giống nhau. Trong hợp kim, nguyên tử lạ thay thế một số nút mạng (giữa) hoặc xen vào khe trống (phải). Hình minh hoạ đơn giản, không theo tỉ lệ](cau-truc-hop-kim.svg)

Dù theo cách nào, hợp kim **vẫn có liên kết kim loại** và electron tự do, nhưng mạng tinh thể **không còn đều đặn**. Điểm này giải thích gần như mọi tính chất ở mục 2.

> [!bay]
> - Hợp kim **không phải** hợp chất. Thép không có "công thức hoá học" như FeC. Thành phần hợp kim có thể thay đổi trong một khoảng (gang có 2–4% C).
> - Hợp kim **có thể chứa phi kim** (C, Si, P, S…). Kim loại cơ bản là kim loại **chiếm nhiều nhất** (thép, gang: Fe).

> [!vi-du] Ví dụ 1
> Cho các vật liệu: (1) thép xây dựng; (2) dây đồng điện có độ tinh khiết 99,99%; (3) duralumin; (4) gang; (5) lá nhôm nguyên chất; (6) inox (thép không gỉ).
>
> a) Có bao nhiêu vật liệu là hợp kim?
>
> b) Với mỗi hợp kim, cho biết kim loại cơ bản.

> [!goi-y] Gợi ý 1
> Vật liệu nào gần như chỉ gồm một nguyên tố? Vật liệu đó là kim loại nguyên chất, không phải hợp kim.

> [!goi-y] Gợi ý 2
> Inox là tên thường gọi của thép không gỉ. Thép thì kim loại cơ bản là gì?

> [!loi-giai] Lời giải
> a) Đồng 99,99% và lá nhôm nguyên chất là kim loại nguyên chất. Các vật liệu còn lại là hợp kim: thép, duralumin, gang, inox. Có **4** hợp kim.
>
> b) Thép, gang, inox có kim loại cơ bản là **Fe**. Duralumin có kim loại cơ bản là **Al**.

### 1.2. Ứng dụng của hợp kim

Hợp kim được dùng **nhiều hơn hẳn** kim loại nguyên chất, vì kim loại nguyên chất thường **quá mềm** (vàng, nhôm, sắt) hoặc **dễ bị ăn mòn** (sắt). Thêm nguyên tố khác giúp "may đo" tính chất theo nhu cầu.

| Cần vật liệu… | Chọn hợp kim | Dùng để |
|---|---|---|
| Nhẹ, cứng, bền | **Duralumin** (hợp kim nhôm) | Thân, cánh máy bay, chi tiết ô tô |
| Cứng, bền, giá rẻ | **Thép** (hợp kim sắt) | Nhà cửa, cầu cống, chế tạo máy |
| Bền hoá học, không gỉ, không độc | **Thép không gỉ** (inox) | Đồ gia dụng, dụng cụ y tế, thiết bị hoá chất |
| Cứng, đúc khuôn được | **Gang** | Nồi gang, chi tiết máy; nguyên liệu luyện thép |
| Cứng hơn vàng, vẫn đẹp | **Hợp kim Au – Cu** | Đồ trang sức, đúc tiền, ngòi bút máy |

Từ thời cổ đại, con người đã dùng hợp kim (như đồng thiếc Cu – Sn của trống đồng Đông Sơn) làm công cụ và vũ khí. Ngày nay, hàng không, ô tô cần hợp kim **nhẹ, bền, chịu nhiệt**; ngành hoá chất cần hợp kim **bền hoá học và cơ học**; đồ gia dụng cần hợp kim **không gỉ, không độc**. Bảng trên cũng là câu trả lời cho câu hỏi 1 (SGK tr. 99).

## 2. Tính chất của hợp kim

Tính chất của hợp kim **phụ thuộc vào thành phần** các đơn chất tạo nên mạng tinh thể. Nhìn chung, tính chất **hoá học tương tự** các kim loại thành phần, còn tính chất **vật lí thường khác nhiều**.

### 2.1. Tính chất hoá học: giống kim loại thành phần

Trong hợp kim, mỗi nguyên tử vẫn giữ "bản tính" khử của mình: thành phần nào phản ứng được khi đứng riêng thì **vẫn phản ứng** trong hợp kim, thành phần nào không phản ứng thì **vẫn không**. Ví dụ, ngâm duralumin (Al, Cu, Mg…) trong dung dịch HCl dư: Al và Mg tan, có khí H~2~ thoát ra, còn Cu **không tan** và còn lại dưới dạng chất rắn (Bài 19: Cu có E° > 0 nên không khử được H^+^).

=> 2Al + 6HCl → 2AlCl~3~ + 3H~2~

=> Mg + 2HCl → MgCl~2~ + H~2~

> [!nen-tang] Kim loại nào tác dụng với acid? (Bài 19)
> - HCl, H~2~SO~4~ loãng: kim loại có **E° < 0** (Mg, Al, Zn, Fe…) tạo **H~2~**, Fe chỉ lên Fe^2+^. Cu, Ag, Au **không** phản ứng.
> - H~2~SO~4~ đặc, nóng: hầu hết kim loại phản ứng (trừ Au, Pt), tạo **SO~2~**, kể cả Cu.

### 2.2. Ánh kim, dẫn điện, dẫn nhiệt: có nhưng kém hơn

Hợp kim vẫn **có ánh kim, dẫn điện, dẫn nhiệt** vì vẫn còn electron tự do, nhưng **dẫn điện và dẫn nhiệt kém hơn** kim loại cơ bản. Ví dụ, đồng nguyên chất dẫn điện tốt hơn hợp kim của đồng.

**Vì sao?** Trong kim loại nguyên chất, mạng tinh thể đều đặn, electron tự do di chuyển khá thuận lợi. Nguyên tử lạ làm mạng **lệch, méo**, electron bị **lệch hướng** nhiều hơn, nên dòng electron yếu đi (Hình 2, nửa dưới).

> [!ung-dung] Dây dẫn điện và dây điện trở
> Dây dẫn điện dùng đồng có độ tinh khiết rất cao để ít hao phí. Ngược lại, dây điện trở trong bàn là, ấm đun cố ý dùng **hợp kim** (dẫn điện kém) để toả nhiều nhiệt.

### 2.3. Độ cứng và độ dẻo: cứng hơn, kém dẻo hơn

Độ cứng của hợp kim **thường lớn hơn** độ cứng của các kim loại thành phần, còn độ dẻo **thường kém hơn**.

**Vì sao?** Kim loại dẻo vì các lớp nguyên tử **trượt lên nhau** dễ dàng (Bài 19). Nguyên tử lạ có kích thước khác làm "gồ ghề" các lớp, như viên sỏi chèn giữa hai tấm kính, **cản trở sự trượt** (Hình 2, nửa trên). Lớp khó trượt thì vật liệu **cứng hơn** nhưng **khó uốn, kéo sợi hơn**.

![Hình 2. Nửa trên: nguyên tử lạ cản các lớp trượt lên nhau nên hợp kim cứng hơn, kém dẻo hơn. Nửa dưới: electron tự do bị lệch hướng nhiều lần nên hợp kim dẫn điện, dẫn nhiệt kém hơn](vi-sao-cung.svg)

**Ví dụ (SGK tr. 100)**: hợp kim **Au – Cu** (khoảng 8% – 12% Cu) **cứng hơn vàng**, nên được dùng đúc tiền, làm đồ trang sức, ngòi bút máy. Vàng nguyên chất quá mềm: nhẫn vàng 99,99% dễ móp, chấu giữ đá dễ bị bẻ cong.

### 2.4. Nhiệt độ nóng chảy: khác kim loại thành phần

Nhiệt độ nóng chảy của hợp kim **tuỳ thuộc vào thành phần và cấu tạo tinh thể**, nhưng **khác** kim loại thành phần. **Ví dụ (SGK tr. 100)**: gang (hợp kim Fe – C) có nhiệt độ nóng chảy **thấp hơn** sắt nguyên chất. Theo số liệu tham khảo (ngoài SGK), sắt nóng chảy ở khoảng 1 540 °C, còn gang chỉ khoảng 1 150 – 1 300 °C. Nhờ vậy gang dễ nấu chảy và **đổ khuôn** thành nồi, bệ máy. Không có quy luật "luôn thấp hơn": có hợp kim nóng chảy cao hơn một kim loại thành phần nhưng thấp hơn kim loại kia.

> [!ung-dung] Thiếc hàn (mở rộng, ngoài SGK)
> Thiếc nóng chảy ở khoảng 232 °C, chì ở khoảng 327 °C, nhưng thiếc hàn Sn – Pb (khoảng 63% Sn) nóng chảy chỉ ở khoảng **183 °C**, nên hàn được mạch điện mà không làm hỏng linh kiện.

## 3. Một số hợp kim quan trọng của sắt và nhôm

### 3.1. Hợp kim của sắt

Thêm **carbon** và một số nguyên tố khác vào sắt, ta được gang và thép. Điểm khác nhau quan trọng nhất là **hàm lượng carbon** (Hình 3).

![Hình 3. Gang và thép phân biệt bằng hàm lượng carbon: thép dưới 2%, gang khoảng 2–4%](thang-carbon.svg)

**a) Gang**

- **Thành phần**: khoảng **95% Fe**, **2% đến 4% C**, và một số nguyên tố khác như manganese, silicon, phosphorus, sulfur…
- **Tính chất**: **cứng hơn** sắt nhưng cũng **giòn hơn** sắt.
- **Ứng dụng**: làm **nguyên liệu sản xuất thép**, chế tạo **dụng cụ đun nấu** (nồi gang, chảo gang), các **chi tiết máy** (bệ máy, nắp cống…).

**Vì sao gang giòn?** (giải thích mở rộng) Carbon trong gang nhiều đến mức không "giấu" hết được vào khe mạng sắt. Phần thừa tạo các hạt cứng nằm rải rác, làm các lớp gần như không trượt được, nên gang cứng nhưng dễ nứt.

**b) Thép**

- **Thành phần**: hợp kim của sắt chứa **ít hơn 2,0% carbon** và một số nguyên tố như chromium, manganese, silicon…
- **Tính chất**: cứng, chịu nhiệt và có nhiều tính chất quý khác. Có thể **điều chỉnh** tính chất bằng cách thêm **titanium, vanadium, manganese**…
- **Ứng dụng**: **vật liệu chủ yếu** của ngành chế tạo máy, xây dựng và nhiều lĩnh vực khác.

**Thép không gỉ (inox)** là hợp kim của sắt chứa **ít nhất 10% chromium** theo khối lượng, ngoài ra có một lượng nhỏ carbon. Thép không gỉ **chống ăn mòn tốt hơn nhiều** so với sắt nguyên chất, thường dùng làm **dụng cụ y tế**, đồ gia dụng.

> [!em-co-biet] Vì sao inox "không gỉ"? (mở rộng, ngoài SGK)
> Chromium tạo trên bề mặt một lớp oxide Cr~2~O~3~ **rất mỏng, đặc khít, trong suốt**, ngăn không khí và nước tiếp xúc với sắt bên trong, bị xước thì tự hình thành lại. Lớp gỉ sắt thì xốp, bong ra, không che được sắt bên dưới.

> [!vi-du] Ví dụ 2
> Phân tích ba mẫu hợp kim Fe – C thu được kết quả:
>
> | Mẫu | Khối lượng mẫu | Thành phần |
> |---|---|---|
> | X | 50 g | chứa 1,6 g C |
> | Y | 20 g | chứa 0,8% C, 0,5% Mn |
> | Z | 10 g | chứa 18% Cr, 8% Ni, 0,05% C |
>
> Mỗi mẫu là gang, thép thường hay thép không gỉ?

> [!goi-y] Gợi ý 1
> Đổi tất cả về phần trăm khối lượng carbon: dưới 2% là thép, từ 2% đến 4% là gang.

> [!goi-y] Gợi ý 2
> Thép có ít nhất 10% Cr là thép không gỉ.

> [!loi-giai] Lời giải
> - Mẫu X: %C = 1,6 : 50 · 100% = 3,2%, nằm trong khoảng 2–4%. X là **gang**.
> - Mẫu Y: 0,8% C, dưới 2%, không có Cr. Y là **thép** thường.
> - Mẫu Z: rất ít C (thép), lại có 18% Cr, nhiều hơn 10%. Z là **thép không gỉ**.

### 3.2. Hợp kim của nhôm

**Duralumin** là hợp kim chứa **trên 90% nhôm**, **khoảng 4% đồng** và một số nguyên tố khác như manganese, magnesium, silicon…

Duralumin **nhẹ** (phần lớn là nhôm), lại **cứng và bền** hơn nhôm nhiều (Cu, Mg… làm mạng khó trượt), nên được dùng rộng rãi trong ngành **chế tạo máy bay**. Đặc tính vượt trội của gang, thép, duralumin so với kim loại cơ bản (câu hỏi 2, SGK tr. 101) được tóm lại ở dòng "Tính chất nổi bật" của bảng Tóm tắt.

> [!bay]
> - **Gang nhiều carbon hơn thép** (2–4% so với dưới 2%). Gang **cứng hơn** sắt nhưng **giòn hơn**.
> - Thép không gỉ có **ít nhất 10% chromium**, không phải 10% carbon hay nickel. Duralumin là hợp kim của **nhôm**, thêm chủ yếu **đồng** (khoảng 4%).
> - Nhiệt độ nóng chảy của hợp kim **khác** kim loại thành phần, **không** "luôn cao hơn" hay "luôn thấp hơn". Riêng gang so với sắt thì **thấp hơn**.
> - Hợp kim **cứng hơn** nhưng **dẫn điện kém hơn** kim loại cơ bản. Tính chất **hoá học** gần như giữ nguyên: Cu trong hợp kim không "tan theo" Al trong HCl.

## Dạng bài thi hay gặp

### Dạng 1. Đúng/Sai về khái niệm, tính chất, thành phần hợp kim

**Nhận biết:** 4 ý về khái niệm, tính chất so với kim loại thành phần, thành phần và ứng dụng của gang, thép, duralumin.

**Phương pháp:** soát từng ý theo bảng "So sánh hợp kim với kim loại thành phần" ở Tóm tắt và các mốc thành phần (2% C, 10% Cr, 4% Cu). Cẩn thận với các từ tuyệt đối như **luôn, chỉ, tất cả**.

> [!vi-du] Ví dụ 3 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Thép là hợp kim của sắt có hàm lượng carbon cao hơn gang.
>
> b) Cho một miếng duralumin vào dung dịch HCl dư, sau phản ứng vẫn còn lại chất rắn không tan.
>
> c) Dây dẫn điện trong nhà nên làm bằng hợp kim đồng vì hợp kim cứng hơn đồng nguyên chất.
>
> d) Trong hợp kim Au – Cu dùng làm trang sức, kim loại cơ bản là Au.

> [!goi-y] Gợi ý 1
> Nhớ mốc carbon: thép dưới 2%, gang 2–4%. Duralumin có những thành phần nào? Thành phần nào không tan trong HCl?

> [!goi-y] Gợi ý 2
> Dây điện cần tính chất nào quan trọng nhất: cứng hay dẫn điện tốt?

> [!loi-giai] Lời giải
> a) **Sai**: thép có **ít** carbon hơn gang.
>
> b) **Đúng**: Cu (khoảng 4%) không tác dụng với HCl nên còn lại.
>
> c) **Sai**: dây điện cần dẫn điện tốt. Hợp kim đồng dẫn điện **kém hơn** đồng nguyên chất.
>
> d) **Đúng**: Au chiếm phần lớn (khoảng 88–92%), Cu chỉ 8–12%.

### Dạng 2. Hợp kim tác dụng với acid: tính phần trăm khối lượng thành phần

**Nhận biết:** đề cho m gam hợp kim (Al – Cu, Al – Mg – Cu, Fe – C, Zn – Cu, Au – Cu…) tác dụng với acid, cho thể tích khí và/hoặc khối lượng chất rắn không tan. Hỏi khối lượng hay phần trăm một thành phần.

**Phương pháp:**

1. Xác định thành phần **nào phản ứng** (xem khung nền tảng ở mục 2.1). Chất rắn không tan = tổng khối lượng các thành phần không phản ứng.
2. Tính n(khí) = V : 24,79, rồi theo phương trình (hoặc bảo toàn electron) tìm số mol thành phần phản ứng. Hai thành phần phản ứng thì lập hệ 2 ẩn (khối lượng và số mol khí).
3. %m(thành phần) = m(thành phần) : m(hợp kim) · 100%.

> [!vi-du] Ví dụ 4
> Một hợp kim nhôm X gồm Al, Mg và Cu. Cho 10,00 g X vào dung dịch HCl dư. Sau khi phản ứng kết thúc thu được 13,01475 L khí H~2~ (điều kiện chuẩn) và còn lại 0,40 g chất rắn không tan. Tính phần trăm khối lượng mỗi kim loại trong X.

> [!goi-y] Gợi ý 1
> Chất rắn không tan là kim loại nào? Từ đó tính tổng khối lượng Al và Mg.

> [!goi-y] Gợi ý 2
> Gọi x = n(Al), y = n(Mg). Lập hai phương trình: theo khối lượng (27x + 24y) và theo số mol H~2~ (1,5x + y).

> [!loi-giai] Lời giải
> Cu không tác dụng với HCl nên m(Cu) = 0,40 g, m(Al) + m(Mg) = 9,60 g. n(H~2~) = 13,01475 : 24,79 = 0,525 mol.
>
> Hệ: 27x + 24y = 9,60 và 1,5x + y = 0,525 (vì 2Al → 3H~2~, Mg → H~2~).
>
> Giải ra x = 1/3 mol, y = 0,025 mol → m(Al) = 9,00 g; m(Mg) = 0,60 g.
>
> %Al = **90%**; %Mg = **6%**; %Cu = **4%**.

> [!vi-du] Ví dụ 5 (vận dụng)
> Để kiểm tra một chiếc vòng làm bằng hợp kim Au – Cu, người ta lấy 8,00 g vụn của nó cho tác dụng với dung dịch H~2~SO~4~ đặc, nóng, dư. Thu được 0,2479 L khí SO~2~ (điều kiện chuẩn, sản phẩm khử duy nhất). Tính phần trăm khối lượng Au và cho biết hàm lượng Cu có nằm trong khoảng SGK nêu (8% – 12%) không.

> [!goi-y] Gợi ý 1
> Au không phản ứng với H~2~SO~4~ đặc. Cu nhường 2 electron, mỗi phân tử SO~2~ nhận 2 electron.

> [!goi-y] Gợi ý 2
> Vậy n(Cu) = n(SO~2~).

> [!loi-giai] Lời giải
> => Cu + 2H~2~SO~4~ (đặc) → CuSO~4~ + SO~2~ + 2H~2~O
>
> n(SO~2~) = 0,2479 : 24,79 = 0,01 mol → n(Cu) = 0,01 mol → m(Cu) = 0,64 g.
>
> %Cu = 0,64 : 8,00 · 100% = 8%, nằm trong khoảng 8% – 12%. %Au = **92%**.

> [!bay]
> - Quên trừ phần không tan: chất rắn còn lại sau acid loãng là Cu (hoặc C), **không** phải lượng kim loại dư.
> - Fe với acid **loãng** chỉ lên **+2** (n(Fe) = n(H~2~)). Với H~2~SO~4~ đặc nóng, **Cu cũng phản ứng**.
> - Dùng **24,79 L/mol** (điều kiện chuẩn), không dùng 22,4.

### Dạng 3. Hàm lượng carbon trong gang, thép

**Nhận biết:** đề hỏi phân loại gang/thép, hoặc cho dữ kiện để tìm %C: đốt mẫu trong oxygen dư rồi hấp thụ CO~2~, hoặc luyện gang thành thép (giảm %C).

**Phương pháp:**

1. Phân loại: %C dưới 2% là **thép**, 2–4% là **gang**. Có từ 10% Cr trở lên là **thép không gỉ**.
2. Đốt mẫu (mở rộng): C + O~2~ → CO~2~. Toàn bộ CO~2~ vào Ca(OH)~2~ dư (chỉ tạo CaCO~3~): n(C) = n(CO~2~) = n(CaCO~3~), rồi %C = 12·n(C) : m(mẫu) · 100%.
3. Luyện gang thành thép (mở rộng): carbon bị oxi hoá bớt, coi **khối lượng Fe giữ nguyên**. Lập: m(thép) = m(Fe) : (1 − %C trong thép).

> [!vi-du] Ví dụ 6 (vận dụng cao, bối cảnh thực tế)
> Một nhà máy luyện 1 tấn gang chứa 4% C (coi phần còn lại là Fe) thành thép chứa 0,5% C. Giả sử chỉ có carbon bị loại bỏ, sắt không bị hao hụt. Tính khối lượng thép thu được và khối lượng carbon đã bị loại bỏ.

> [!goi-y] Gợi ý 1
> Lượng Fe trước và sau bằng nhau: m(Fe) = 1 000 · 96% kg.

> [!goi-y] Gợi ý 2
> Trong thép, Fe chiếm 100% − 0,5% = 99,5%.

> [!loi-giai] Lời giải
> m(Fe) = 1 000 · 0,96 = 960 kg.
>
> m(thép) = 960 : 0,995 ≈ **964,8 kg**.
>
> m(C còn lại) = 964,8 − 960 ≈ 4,8 kg. m(C bị loại) = 40 − 4,8 ≈ **35,2 kg**.

> [!bay]
> Khi luyện thép, khối lượng **Fe** giữ nguyên, **không** phải khối lượng hợp kim. Đáp án "1 000 · 99,5% = 995 kg" là sai.

## Tóm tắt

| | Gang | Thép | Thép không gỉ | Duralumin |
|---|---|---|---|---|
| Kim loại cơ bản | Fe (khoảng 95%) | Fe | Fe | Al (trên 90%) |
| Thành phần thêm | C 2–4%; Mn, Si, P, S… | C dưới 2,0%; Cr, Mn, Si… | Cr ít nhất 10%; ít C | Cu khoảng 4%; Mn, Mg, Si… |
| Tính chất nổi bật | Cứng hơn sắt nhưng giòn; nóng chảy thấp hơn sắt | Cứng, chịu nhiệt; điều chỉnh được bằng Ti, V, Mn… | Chống ăn mòn tốt | Nhẹ, cứng, bền |
| Ứng dụng | Luyện thép, nồi, chi tiết máy | Chế tạo máy, xây dựng | Dụng cụ y tế, đồ gia dụng | Chế tạo máy bay |

**So sánh hợp kim với kim loại thành phần:**

| Tính chất | Hợp kim so với kim loại thành phần |
|---|---|
| Tính chất hoá học | Tương tự |
| Ánh kim, dẫn điện, dẫn nhiệt | Vẫn có, nhưng dẫn điện, dẫn nhiệt **kém hơn** kim loại cơ bản |
| Độ cứng | Thường **lớn hơn** |
| Độ dẻo | Thường **kém hơn** |
| Nhiệt độ nóng chảy | **Khác** (tuỳ thành phần); gang **thấp hơn** sắt |

**Công thức tính toán:**

- Acid loãng: Cu, Ag, Au, C không phản ứng; Fe → Fe^2+^; n(khí) = V : 24,79.
- Đốt mẫu thép/gang: n(C) = n(CO~2~) = n(CaCO~3~) (Ca(OH)~2~ dư).
- Luyện gang thành thép: m(Fe) không đổi, m(thép) = m(Fe) : (1 − %C).
