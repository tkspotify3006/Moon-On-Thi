---
title: Kim loại trong tự nhiên và phương pháp tách kim loại
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái quát trạng thái tự nhiên của kim loại và một số quặng, mỏ kim loại phổ biến (bauxite, zinc blende, hematite, pyrite, chalcopyrite).
  - Hiểu nguyên tắc chung để tách kim loại là khử ion kim loại thành nguyên tử, và vì sao kim loại càng hoạt động thì càng khó tách.
  - Trình bày và giải thích được phương pháp tách kim loại hoạt động mạnh (Na, Mg, Al…) bằng điện phân nóng chảy.
  - Trình bày và giải thích được các phương pháp tách kim loại hoạt động trung bình, yếu (Zn, Fe, Cu…): nhiệt luyện, điện phân dung dịch, thuỷ luyện.
  - Trình bày được nhu cầu và thực tiễn tái chế sắt, nhôm, đồng và ý nghĩa của việc tái chế với môi trường.
  - Giải được các dạng bài: chọn phương pháp điều chế, khử oxide bằng CO/H~2~ (bảo toàn nguyên tố O), tính lượng kim loại thu được từ quặng có hiệu suất.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Trong tự nhiên, hầu hết kim loại ở dạng **hợp chất** (oxide, muối…) trong **quặng**. Chỉ vài kim loại kém hoạt động như **vàng, bạc, platinum** có ở dạng đơn chất.
> 2. Nguyên tắc tách mọi kim loại: **khử ion kim loại thành nguyên tử**, M^n+^ + ne → M.
> 3. Kim loại **mạnh** (K, Na, Ca, Mg, Al…): chỉ dùng **điện phân nóng chảy** hợp chất (oxide, muối chloride).
> 4. Kim loại **trung bình, yếu** (Zn, Fe, Sn, Pb, Cu…): **nhiệt luyện** (C, CO… khử oxide ở nhiệt độ cao), **điện phân dung dịch** muối, hoặc **thuỷ luyện** (hoà tan rồi dùng kim loại mạnh hơn khử ion).
> 5. **Tái chế** sắt, nhôm, đồng giúp tiết kiệm tài nguyên và năng lượng, giảm phát thải. Bài toán chính: CO/H~2~ khử oxide thì **n(O mất) = n(CO) = n(CO~2~)**; từ quặng ra kim loại thì đi theo nguyên tố kim loại và nhân hiệu suất.

Ở Bài 19, em đã thấy kim loại có **tính khử**: chúng dễ nhường electron để trở thành ion. Vì "thích" nhường electron như vậy, nên trong tự nhiên kim loại thường đã nhường electron từ lâu, tức là nằm ở dạng ion trong hợp chất. Muốn lấy lại kim loại, ta phải làm ngược lại: **trả electron cho ion**. Bài này trả lời câu hỏi: trả bằng cách nào, và vì sao mỗi kim loại lại cần một cách khác nhau?

## 1. Kim loại trong tự nhiên

### 1.1. Đơn chất hay hợp chất?

Trong vỏ Trái Đất có oxygen, nước, CO~2~, lưu huỳnh… Các chất này đều có thể oxi hoá kim loại. Qua hàng triệu năm, kim loại có tính khử càng mạnh thì càng bị oxi hoá hết. Vì vậy:

- **Hầu hết** kim loại tồn tại ở dạng **hợp chất**: oxide, muối sulfide, carbonate, silicate, chloride…
- Chỉ một số kim loại **kém hoạt động** như **vàng (Au), bạc (Ag), platinum (Pt)** được tìm thấy ở dạng **đơn chất** (SGK tr. 94). Chúng đứng cuối dãy hoạt động nên "không chịu" bị oxi hoá.

> [!bay]
> - Kim loại kiềm (Na, K…) **không bao giờ** có ở dạng đơn chất trong tự nhiên. Chúng phản ứng ngay với nước và oxygen. Muối NaCl trong nước biển, mỏ muối là dạng tồn tại của sodium.
> - Nhôm là kim loại phổ biến nhất trong vỏ Trái Đất, nhưng vẫn ở dạng hợp chất. "Phổ biến" không có nghĩa là "có dạng tự do".

### 1.2. Quặng

**Quặng** là đất, đá trong tự nhiên có chứa khoáng vật của kim loại (hoặc hợp chất của kim loại) với **trữ lượng đủ lớn** để khai thác có lợi (SGK tr. 94). Như vậy, không phải cứ đá nào có chứa kim loại cũng gọi là quặng. Hàm lượng quá thấp thì chi phí tách lớn hơn giá trị kim loại thu được.

Quặng luôn lẫn **tạp chất** (đất, cát, các oxide khác). Cách tách kim loại phụ thuộc vào **tính chất của kim loại** và **tính chất của quặng**.

Một số quặng thông dụng (theo Bảng 20.1, SGK tr. 94):

| Kim loại | Quặng | Thành phần chính |
|---|---|---|
| Al | Bauxite | Al~2~O~3~·2H~2~O |
| Zn | Zinc blende | ZnS |
| Fe | Hematite | Fe~2~O~3~ |
| Fe | Pyrite | FeS~2~ |
| Cu | Chalcopyrite | CuFeS~2~ |

> [!meo] Nhớ tên quặng theo "gốc từ"
> - **Hemat**ite: gốc Hi Lạp *haima* là "máu", vì bột quặng có màu đỏ như máu → Fe~2~O~3~ (gỉ sắt cũng màu đỏ nâu).
> - **Pyr**ite: *pyr* là "lửa", vì đập vào thép toé lửa → FeS~2~, có ánh vàng nên còn gọi là "vàng của kẻ ngốc".
> - **Chalco**pyrite: *chalco* là "đồng" → CuFeS~2~.
> - Zinc **blende**: quặng của kẽm (zinc) → ZnS.

> [!em-co-biet] Quặng sắt khác hay gặp trong đề
> Ngoài hematite và pyrite, đề thi còn nhắc tới **magnetite** (Fe~3~O~4~, có từ tính, hàm lượng sắt cao nhất) và **siderite** (FeCO~3~). Hai quặng này không có trong bảng SGK, em chỉ cần nhận ra công thức.

> [!ung-dung] Một số mỏ quặng quan trọng ở Việt Nam (tham khảo, ngoài SGK)
> Câu hỏi 1b (SGK tr. 95) yêu cầu em tự tìm hiểu. Một vài mỏ hay được nhắc tới:
> - **Bauxite**: trữ lượng lớn ở vùng **Tây Nguyên**, đã có nhà máy chế biến bauxite thành alumina (Al~2~O~3~).
> - **Sắt**: mỏ **Thạch Khê** (Hà Tĩnh) có trữ lượng lớn. Vùng Thái Nguyên, Lào Cai cũng có mỏ sắt.
> - **Đồng**: mỏ **Sin Quyền** (Lào Cai).
> - **Thiếc**: vùng Cao Bằng, Nghệ An. **Chì – kẽm**: vùng Bắc Kạn cũ (nay thuộc tỉnh Thái Nguyên).
>
> Tên tỉnh ghi theo địa giới sau khi sắp xếp năm 2025. Em nên đối chiếu thêm tài liệu địa lí địa phương khi trả lời câu hỏi này.

> [!vi-du] Ví dụ 1
> a) Tính phần trăm khối lượng sắt trong Fe~2~O~3~ (hematite) và trong FeS~2~ (pyrite).
>
> b) Vì sao trong công nghiệp, gang thép chủ yếu được luyện từ quặng oxide như hematite chứ không phải từ pyrite?

> [!goi-y] Gợi ý 1
> %Fe = (số nguyên tử Fe × 56) : M(hợp chất) × 100%. M(Fe~2~O~3~) = 160, M(FeS~2~) = 120.

> [!goi-y] Gợi ý 2
> Câu b): so sánh hàm lượng sắt, rồi nghĩ xem khi xử lí pyrite thì nguyên tố S đi đâu.

> [!loi-giai] Lời giải
> a) %Fe(Fe~2~O~3~) = 2·56 : 160 · 100% = **70%**.
>
> %Fe(FeS~2~) = 56 : 120 · 100% ≈ **46,7%**.
>
> b) Hematite giàu sắt hơn nhiều. Ngoài ra, muốn lấy sắt từ pyrite phải đốt quặng, lưu huỳnh chuyển thành khí SO~2~ rất độc, gây mưa acid. Vì vậy pyrite thường được dùng để sản xuất sulfuric acid hơn là để luyện gang.

## 2. Các phương pháp tách kim loại

### 2.1. Nguyên tắc

Trong quặng, kim loại ở dạng **ion dương** (Al^3+^ trong Al~2~O~3~, Fe^3+^ trong Fe~2~O~3~, Zn^2+^ trong ZnS…). Muốn có kim loại, ta phải **cho ion đó nhận electron**:

=> M^n+^ + ne → M

Đây là **quá trình khử**. Vậy nguyên tắc chung để tách (điều chế) mọi kim loại là **khử ion kim loại thành nguyên tử** (SGK tr. 95).

**Vì sao không có một cách chung cho mọi kim loại?** Hãy nhớ lại dãy điện hoá (Bài 15): kim loại có tính khử **càng mạnh** thì ion của nó có tính oxi hoá **càng yếu**, tức là **càng khó nhận lại electron**. Ion Al^3+^ "giữ chặt" trạng thái ion hơn nhiều so với Cu^2+^. Vì vậy:

- Ion kim loại **yếu** (Cu^2+^, Ag^+^…) dễ bị khử: chỉ cần một kim loại mạnh hơn như Fe là đủ.
- Ion kim loại **mạnh** (Na^+^, Mg^2+^, Al^3+^…) rất khó bị khử: không chất khử hoá học thông thường nào đủ mạnh, phải dùng **dòng điện**.

![Hình 1. Chọn phương pháp tách kim loại theo độ hoạt động hoá học. Ranh giới quan trọng nhất nằm giữa Al và Zn](chon-phuong-phap.svg)

> [!nen-tang] Chất khử, chất oxi hoá (lớp 10)
> - **Chất khử** nhường electron, số oxi hoá **tăng**. **Chất oxi hoá** nhận electron, số oxi hoá **giảm**.
> - Ion kim loại M^n+^ nhận electron, nên trong phản ứng tách kim loại, nó (hay hợp chất chứa nó) đóng vai trò **chất oxi hoá**.
> - Chất khử có thể là: C, CO, H~2~ (nhiệt luyện), kim loại mạnh hơn (thuỷ luyện), hoặc **cathode** của bình điện phân (điện phân).

> [!vi-du] Ví dụ 2
> Viết quá trình khử ion kim loại xảy ra khi tách kim loại từ mỗi hợp chất sau, và cho biết cần bao nhiêu mol electron để thu được 1 mol kim loại:
>
> a) Al~2~O~3~ → Al
>
> b) Fe~2~O~3~ → Fe
>
> c) MgCl~2~ → Mg

> [!goi-y] Gợi ý 1
> Tìm số oxi hoá của kim loại trong hợp chất. O có số oxi hoá −2, Cl có số oxi hoá −1.

> [!goi-y] Gợi ý 2
> Kim loại từ số oxi hoá +n về 0 thì mỗi nguyên tử nhận n electron.

> [!loi-giai] Lời giải
> a) Al có số oxi hoá +3: Al^3+^ + 3e → Al. Cần **3 mol electron** cho 1 mol Al.
>
> b) Fe có số oxi hoá +3: Fe^3+^ + 3e → Fe. Cần **3 mol electron** cho 1 mol Fe.
>
> c) Mg có số oxi hoá +2: Mg^2+^ + 2e → Mg. Cần **2 mol electron** cho 1 mol Mg.

### 2.2. Tách kim loại hoạt động mạnh: điện phân nóng chảy

Các kim loại hoạt động mạnh như **K, Na, Ca, Mg, Al…** được điều chế bằng **điện phân nóng chảy** hợp chất của chúng (**oxide** hoặc **muối chloride**) (SGK tr. 95).

**Vì sao phải "nóng chảy", không điện phân dung dịch được?** Trong dung dịch, ở cathode có cả ion kim loại và phân tử nước. Các ion Na^+^, Mg^2+^, Al^3+^ còn khó bị khử hơn cả nước, nên **nước bị khử trước**, sinh khí H~2~, không bao giờ thu được kim loại (xem Bài 16, mục 2.3). Khi đun hợp chất ion đến nóng chảy, không còn nước nữa. Lúc này các ion chuyển động tự do, dẫn điện được, và ion kim loại là "ứng viên" duy nhất nhận electron ở cathode.

**Vì sao không dùng C hay CO để khử?** Oxide của các kim loại này (Al~2~O~3~, MgO, CaO…) **rất bền**. C, CO, H~2~ không đủ mạnh để lấy oxygen ra khỏi chúng ở nhiệt độ của lò công nghiệp.

**a) Điện phân oxide nóng chảy: sản xuất nhôm**

Nhôm được sản xuất bằng cách điện phân Al~2~O~3~ (tinh chế từ quặng bauxite) ở trạng thái nóng chảy:

=> 2Al~2~O~3~ → 4Al + 3O~2~    (điện phân nóng chảy, có mặt cryolite)

Quá trình này em đã học kĩ ở **Bài 16, mục 3.1** (cấu tạo thùng điện phân và các bước). Ở đây chỉ trả lời gọn hai câu hỏi SGK đặt ra (SGK tr. 95):

1. **Vai trò của cryolite** (Na~3~AlF~6~): hạ nhiệt độ nóng chảy của hỗn hợp từ khoảng 2 050 °C xuống gần 1 000 °C (tiết kiệm năng lượng), tạo chất lỏng dẫn điện tốt hơn, và tạo lớp lỏng nhẹ nổi trên nhôm lỏng, ngăn nhôm bị oxi hoá bởi không khí.
2. **Vì sao phải thay cực dương (anode)?** Anode làm bằng than chì. Khí O~2~ sinh ra ở anode, ở nhiệt độ rất cao, đốt cháy dần chính anode: C + O~2~ → CO~2~ và 2C + O~2~ → 2CO. Anode bị mòn nên phải hạ dần xuống và định kì thay mới.

**b) Điện phân muối chloride nóng chảy**

Na, K, Ca, Mg… được điều chế bằng cách điện phân **muối chloride nóng chảy** của chúng. Ví dụ với MgCl~2~:

- MgCl~2~ nóng chảy phân li thành ion: MgCl~2~ → Mg^2+^ + 2Cl^−^.
- Ion Mg^2+^ di chuyển về **cathode (cực âm)** và nhận electron: Mg^2+^ + 2e → Mg.
- Ion Cl^−^ di chuyển về **anode (cực dương)** và nhường electron: 2Cl^−^ → Cl~2~ + 2e.

=> MgCl~2~(l) → Mg(l) + Cl~2~(g)    (điện phân nóng chảy)

Tương tự với muối ăn: 2NaCl → 2Na + Cl~2~ (điện phân nóng chảy). Khí Cl~2~ thu được ở anode cũng là một sản phẩm có giá trị.

> [!bay]
> - "Cho Na (hoặc K) vào dung dịch MgCl~2~ để đẩy Mg ra" là **sai**. Na phản ứng với nước trước, tạo NaOH và H~2~, rồi NaOH tạo kết tủa Mg(OH)~2~. Không thu được Mg.
> - Điện phân **dung dịch** NaCl chỉ cho NaOH, H~2~, Cl~2~, **không** cho Na (Bài 16).
> - Nhôm điện phân từ **Al~2~O~3~** nóng chảy, **không** từ AlCl~3~. Các kim loại còn lại trong nhóm (Na, K, Ca, Mg…) thường điện phân từ **muối chloride**.

> [!vi-du] Ví dụ 3
> Một nhà máy điện phân nóng chảy 19 kg MgCl~2~ với hiệu suất 85%.
>
> a) Tính khối lượng Mg thu được.
>
> b) Tính thể tích khí Cl~2~ thu được ở điều kiện chuẩn (đơn vị m^3^, làm tròn đến hàng phần trăm). Biết ở điều kiện chuẩn, 1 mol khí chiếm 24,79 L.

> [!goi-y] Gợi ý 1
> M(MgCl~2~) = 24 + 2·35,5 = 95. Làm việc theo kmol cho gọn: 19 kg ứng với 19 : 95 kmol.

> [!goi-y] Gợi ý 2
> Theo phương trình, 1 MgCl~2~ cho 1 Mg và 1 Cl~2~. Đi từ chất đầu đến sản phẩm thì **nhân** hiệu suất. 1 kmol khí ở điều kiện chuẩn chiếm 24,79 m^3^.

> [!loi-giai] Lời giải
> n(MgCl~2~) = 19 : 95 = 0,2 kmol.
>
> a) n(Mg) thực tế = 0,2 · 0,85 = 0,17 kmol → m(Mg) = 0,17 · 24 = **4,08 kg**.
>
> b) n(Cl~2~) = 0,17 kmol → V = 0,17 · 24,79 ≈ **4,21 m^3^**.

### 2.3. Tách kim loại hoạt động trung bình, yếu

Với các kim loại **Zn, Fe, Sn, Pb, Cu…**, ion của chúng dễ bị khử hơn. Ta có thể chọn một trong ba cách: **nhiệt luyện**, **điện phân dung dịch**, hoặc **thuỷ luyện**.

**a) Phương pháp nhiệt luyện**

**Nguyên tắc:** dùng chất khử như **C, CO** (và H~2~…) để khử **oxide kim loại** ở **nhiệt độ cao** (SGK tr. 96). Phương pháp này dùng cho các kim loại hoạt động trung bình, yếu như Zn, Fe, Sn, Pb, Cu.

**Vì sao cần nhiệt độ cao?** Liên kết giữa kim loại và oxygen trong oxide khá bền. Nhiệt độ cao cung cấp năng lượng để phá liên kết, đồng thời giúp phản ứng xảy ra đủ nhanh.

*Ví dụ 1 trong SGK: tách kẽm từ quặng zinc blende (ZnS).* Quặng là **sulfide**, mà C chỉ khử được **oxide**. Vì vậy phải qua hai bước:

- Bước 1, **đốt quặng** trong không khí để chuyển sulfide thành oxide:

=> 2ZnS + 3O~2~ → 2ZnO + 2SO~2~    (t°)

- Bước 2, **khử oxide** bằng than cốc ở nhiệt độ cao:

=> ZnO + C → Zn + CO    (t°)

*Ví dụ 2 trong SGK: tách sắt từ quặng hematite.* Ở nhiệt độ cao, khí CO khử iron(III) oxide thành sắt (ở nhiệt độ lò, sắt nóng chảy):

=> Fe~2~O~3~ + 3CO → 2Fe + 3CO~2~    (t°)

**Bản chất "lấy oxygen".** Nhìn kĩ phản ứng trên: mỗi phân tử CO lấy đi **1 nguyên tử O** của oxide để thành CO~2~. Tương tự, mỗi H~2~ lấy 1 nguyên tử O để thành H~2~O, mỗi C lấy 1 O để thành CO. Viết gọn:

=> CO + [O] → CO~2~

=> H~2~ + [O] → H~2~O

Đây là chìa khoá để giải nhanh bài toán khử oxide (xem **Dạng 2**).

![Hình 2. Khử oxide kim loại bằng CO: oxide mất oxygen, khí đi ra chứa CO~2~ (có thể nhận biết bằng nước vôi trong). Số mol O mất đi bằng số mol CO~2~ tạo thành](khu-oxide.svg)

> [!ghi-nho] Oxide nào bị CO, hydrogen khử?
> Theo quy ước dùng khi làm đề: CO, H~2~ (và C) khử được oxide của các kim loại **đứng sau Al** trong dãy hoạt động (ZnO, FeO, Fe~2~O~3~, Fe~3~O~4~, NiO, SnO~2~, PbO, CuO…). Chúng **không khử được** oxide của kim loại **từ Al trở về trước** (K~2~O, Na~2~O, BaO, CaO, MgO, Al~2~O~3~).

> [!bay]
> - Cho CO dư qua hỗn hợp nung nóng gồm Al~2~O~3~ và CuO: chất rắn thu được là **Al~2~O~3~ và Cu** (không phải Al và Cu).
> - Đừng nghĩ "nhiệt luyện" chỉ là đun nóng. Phải có **chất khử** lấy oxygen đi. Đun Fe~2~O~3~ một mình không cho Fe.
> - Quặng sulfide (ZnS, CuFeS~2~, FeS~2~) phải **đốt thành oxide trước** rồi mới khử.

> [!vi-du] Ví dụ 4
> Dẫn khí CO dư qua ống sứ đựng hỗn hợp X gồm Al~2~O~3~, MgO, Fe~3~O~4~, CuO nung nóng. Sau khi phản ứng xảy ra hoàn toàn, chất rắn còn lại trong ống gồm những chất nào?

> [!goi-y] Gợi ý 1
> Tách các oxide thành hai nhóm: của kim loại đứng trước Al (kể cả Al) và của kim loại đứng sau Al.

> [!goi-y] Gợi ý 2
> Nhóm bị khử thành kim loại, nhóm còn lại giữ nguyên. Fe~3~O~4~ bị khử đến tận Fe.

> [!loi-giai] Lời giải
> - Al~2~O~3~, MgO: oxide của kim loại mạnh, **không bị CO khử**, giữ nguyên.
> - Fe~3~O~4~ + 4CO → 3Fe + 4CO~2~ (t°).
> - CuO + CO → Cu + CO~2~ (t°).
>
> Chất rắn còn lại: **Al~2~O~3~, MgO, Fe, Cu**.

> [!em-co-biet] Lò cao luyện gang (mở rộng)
> Gang được sản xuất trong **lò cao**, là một tháp cao hàng chục mét. Quặng sắt, than cốc và đá vôi được nạp từ trên đỉnh, không khí nóng được thổi vào từ phía dưới. Than cốc cháy tạo CO~2~, rồi CO~2~ gặp than nóng đỏ tạo thành **CO**. Khí CO đi lên và khử dần oxide sắt theo các nấc Fe~2~O~3~ → Fe~3~O~4~ → FeO → Fe. Sắt nóng chảy hoà tan một ít carbon, tạo **gang** (chứa khoảng 2–5% C), chảy xuống đáy lò. Đá vôi biến tạp chất đất đá thành **xỉ**, nhẹ hơn nên nổi lên trên gang. Phần lớn gang sau đó được luyện tiếp thành thép.

> [!em-co-biet] Nhôm cũng là chất khử nhiệt luyện (mở rộng)
> Nhôm có tính khử mạnh, khử được oxide của nhiều kim loại đứng sau nó ở nhiệt độ cao, phản ứng toả nhiệt rất mạnh. Đây là **phản ứng nhiệt nhôm**, dùng để điều chế chromium từ Cr~2~O~3~ và để hàn đường ray (2Al + Fe~2~O~3~ → Al~2~O~3~ + 2Fe, sắt sinh ra nóng chảy).

**b) Phương pháp điện phân dung dịch**

Kim loại hoạt động trung bình hoặc yếu có thể điều chế bằng cách **điện phân dung dịch muối** của chúng (SGK tr. 96). Ví dụ:

=> CuCl~2~(aq) → Cu(s) + Cl~2~(g)    (điện phân dung dịch)

Khi điện phân dung dịch CuSO~4~ với hai điện cực than chì (Hình 20.2 SGK): điện cực nối với **cực âm** của nguồn là **cathode**, có **đồng màu đỏ** bám vào. Điện cực nối với **cực dương** là **anode**, có **bọt khí O~2~** thoát ra. Phương trình:

=> 2CuSO~4~ + 2H~2~O → 2Cu + O~2~ + 2H~2~SO~4~    (điện phân dung dịch)

Toàn bộ quá trình ở từng điện cực, và quy ước "ion từ Zn^2+^ trở về sau vẫn bị khử trong dung dịch", em xem lại **Bài 16, mục 2.1 và 2.3**.

**Vì sao điện phân dung dịch chỉ dùng được cho kim loại từ Zn trở về sau?** Theo quy ước làm đề ở Bài 16 (ngoài SGK), ion của chúng bị khử ở cathode **trước nước**. Còn ion từ Al^3+^ trở về trước thì thua nước, như đã giải thích ở mục 2.2.

> [!ung-dung] Tinh chế kẽm và đồng
> Điện phân dung dịch không chỉ để sản xuất mà còn để **làm sạch** kim loại (SGK tr. 98, mục "Em có thể"). Đồng thô từ nhiệt luyện được đúc làm anode, điện phân trong dung dịch CuSO~4~, đồng tinh khiết bám ở cathode (xem Bài 16, mục 3.2). Với kẽm, người ta thường hoà tan ZnO trong H~2~SO~4~ rồi điện phân dung dịch ZnSO~4~ (mở rộng). Kim loại thu được có độ tinh khiết rất cao, đồng như vậy mới dùng làm dây dẫn điện tốt.

**c) Phương pháp thuỷ luyện**

"Thuỷ" là nước: phương pháp này làm việc trong **dung dịch**, ở nhiệt độ thường. Gồm hai bước (SGK tr. 96):

1. **Hoà tan**: dùng dung dịch thích hợp (H~2~SO~4~, NaOH, NaCN…) để hoà tan kim loại hoặc hợp chất của kim loại trong quặng, tách khỏi phần đất đá không tan.
2. **Khử**: dùng kim loại có **tính khử mạnh hơn** (như Fe, Zn…) để khử ion kim loại trong dung dịch thành kim loại.

Ví dụ: dùng sắt khử ion Cu^2+^ trong dung dịch muối đồng:

=> Fe(s) + CuSO~4~(aq) → FeSO~4~(aq) + Cu(s)

**Vì sao Fe làm được việc này?** Theo dãy điện hoá, Fe có tính khử mạnh hơn Cu, còn Cu^2+^ có tính oxi hoá mạnh hơn Fe^2+^ (E° của Cu^2+^/Cu lớn hơn của Fe^2+^/Fe). Phản ứng đi theo chiều chất khử mạnh + chất oxi hoá mạnh tạo chất khử yếu + chất oxi hoá yếu (Bài 15).

SGK xếp thuỷ luyện vào nhóm phương pháp tách kim loại **hoạt động trung bình, yếu**. Ví dụ trong SGK là Cu, và mục "Em có biết" nói trong công nghiệp thuỷ luyện thường dùng cho **kim loại quý như Au, Ag**. Vì vậy khi làm đề, em nhớ thuỷ luyện **thường gặp với Cu, Ag, Au**: ion của chúng dễ bị kim loại phổ biến, rẻ tiền (Fe, Zn) khử. Đây là cách nói "thường dùng", không phải quy tắc chỉ được dùng cho ba kim loại này.

> [!em-co-biet] Tách vàng bằng dung dịch cyanide (SGK tr. 97)
> Quặng vàng thường rất nghèo, chỉ vài gam vàng trong mỗi tấn đá. Người ta nghiền quặng, ngâm trong dung dịch KCN và liên tục sục không khí. Vàng tan vào dung dịch ở dạng phức chất:
>
> => 4Au + 8KCN + O~2~ + 2H~2~O → 4K[Au(CN)~2~] + 4KOH
>
> Sau đó dùng bột kẽm đẩy vàng ra khỏi phức chất:
>
> => 2K[Au(CN)~2~] + Zn → K~2~[Zn(CN)~4~] + 2Au
>
> Cyanide rất độc. Nước thải của các mỏ vàng nếu không được xử lí sẽ gây ô nhiễm nghiêm trọng sông suối.

> [!vi-du] Ví dụ 5
> Nước thải của một xưởng mạ chứa ion Cu^2+^ với nồng độ 0,02 mol/L. Người ta cho 10 m^3^ nước thải này chảy qua bể chứa sắt phế liệu để thu hồi đồng. Giả sử toàn bộ Cu^2+^ bị khử.
>
> a) Tính khối lượng đồng thu hồi được.
>
> b) Tính khối lượng sắt tối thiểu bị tiêu hao.

> [!goi-y] Gợi ý 1
> Đổi 10 m^3^ = 10 000 L. Tính số mol Cu^2+^.

> [!goi-y] Gợi ý 2
> Fe + Cu^2+^ → Fe^2+^ + Cu: tỉ lệ mol 1 : 1 : 1 : 1.

> [!loi-giai] Lời giải
> n(Cu^2+^) = 10 000 · 0,02 = 200 mol.
>
> a) n(Cu) = 200 mol → m(Cu) = 200 · 64 = 12 800 g = **12,8 kg**.
>
> b) n(Fe) = 200 mol → m(Fe) = 200 · 56 = 11 200 g = **11,2 kg**.
>
> Vừa thu hồi được kim loại có giá trị, vừa loại bỏ ion kim loại nặng khỏi nước thải.

### 2.4. So sánh ba phương pháp cho kim loại trung bình, yếu

| | Nhiệt luyện | Điện phân dung dịch | Thuỷ luyện |
|---|---|---|---|
| Chất khử | C, CO, H~2~… | Dòng điện (electron ở cathode) | Kim loại mạnh hơn (Fe, Zn…) |
| Nguyên liệu | Oxide kim loại (quặng sulfide phải đốt trước) | Dung dịch muối | Dung dịch muối (sau khi hoà tan quặng) |
| Điều kiện | Nhiệt độ cao | Nguồn điện một chiều | Nhiệt độ thường |
| Áp dụng | Kim loại sau Al: Zn, Fe, Sn, Pb, Cu… | Kim loại sau Al: Zn, Ni, Cu, Ag… | Kim loại trung bình, yếu; thường gặp: Cu, Ag, Au |
| Ví dụ | Fe~2~O~3~ + 3CO → 2Fe + 3CO~2~ | CuCl~2~ → Cu + Cl~2~ | Fe + CuSO~4~ → FeSO~4~ + Cu |

## 3. Tái chế kim loại

### 3.1. Vì sao phải tái chế?

Trữ lượng quặng ngày càng cạn, trong khi nhu cầu dùng kim loại ngày càng tăng và lượng **phế thải kim loại** (xe cũ, vỏ lon, dây điện, đồ gia dụng hỏng…) ngày càng nhiều. **Tái chế** giải quyết cả ba vấn đề cùng lúc (SGK tr. 97):

- **Đảm bảo nguồn cung**: phế liệu trở thành "mỏ quặng" ngay trong thành phố.
- **Gia tăng giá trị kinh tế**: kim loại tái chế rẻ hơn kim loại sản xuất từ quặng.
- **Bảo vệ môi trường, phát triển bền vững**: bớt khai thác mỏ, bớt tiêu thụ năng lượng, bớt khí thải và chất thải.

**Vì sao tái chế lại tiết kiệm năng lượng nhiều đến vậy?** Trong phế liệu, kim loại **đã ở dạng đơn chất**, không cần bước khử ion tốn kém nữa, chỉ cần nấu chảy và làm sạch. Ví dụ với nhôm: sản xuất từ quặng cần điện phân Al~2~O~3~ nóng chảy gần 1 000 °C với dòng điện rất lớn, còn tái chế chỉ cần nấu chảy nhôm ở khoảng 660 °C.

### 3.2. Quy trình tái chế

Quy trình tái chế kim loại thường gồm các giai đoạn (SGK tr. 97): **thu gom, phân loại** → **xử lí sơ bộ** → **phối trộn phế liệu** → **nấu chảy** → **tinh chế** → **đúc, chế tạo, gia công**.

![Hình 3. Các giai đoạn của quy trình tái chế kim loại](tai-che.svg)

**Vì sao phải phân loại và phối trộn?** Mỗi kim loại, mỗi hợp kim có thành phần khác nhau. Trộn lẫn lung tung sẽ làm sản phẩm có thành phần không kiểm soát được, kém chất lượng. Phân loại kĩ và phối trộn theo tỉ lệ tính trước thì thu được hợp kim đúng yêu cầu.

### 3.3. Tái chế nhôm, đồng, sắt

- **Nhôm** là một trong những kim loại tái chế hiệu quả nhất. Nhôm có thể tái chế **nhiều lần mà không mất đi tính chất** vốn có. Nhôm tái chế dùng trong xây dựng, sản xuất ô tô, xe máy, xe đạp, thiết bị điện tử… Ước tính khoảng **75%** tổng lượng nhôm từng được sản xuất đến nay vẫn đang được sử dụng (SGK tr. 97).
- **Đồng** cũng tái chế được nhiều lần mà ít hao hụt. Đồng tái chế dùng làm vật liệu xây dựng, phương tiện giao thông, dụng cụ nấu ăn, nhạc cụ, dây dẫn điện… Khoảng **80%** lượng đồng từng khai thác vẫn đang được sử dụng.
- **Sắt** là kim loại được **tái chế nhiều nhất** thế giới. Phần lớn sắt tái chế được dùng để sản xuất **thép** cho xây dựng, ô tô… Tái chế sắt tiết kiệm năng lượng và giảm tác động tiêu cực của việc khai thác quặng.

> [!em-co-biet] Con số về tái chế thép (SGK tr. 98)
> - Thép chiếm khoảng 70% khối lượng một chiếc ô tô, nên xe cũ là nguồn thép phế liệu rất lớn mỗi năm.
> - So với sản xuất thép mới từ nguyên liệu thô, tái chế thép giảm khoảng **80%** lượng khí thải CO~2~, giảm **40%** lượng nước tiêu thụ và giảm **76%** ô nhiễm nước.

> [!em-co-biet] Tái chế nhôm tiết kiệm bao nhiêu năng lượng? (ngoài SGK)
> SGK chỉ nói tái chế nhôm "tiết kiệm năng lượng". Nhiều tài liệu quốc tế ước tính tái chế nhôm chỉ tốn khoảng **5%** năng lượng so với sản xuất từ quặng. Con số chính xác tuỳ công nghệ, em chỉ cần nhớ là tiết kiệm rất nhiều.

> [!ung-dung] Tái chế kim loại ở Việt Nam (tham khảo, ngoài SGK)
> Nhiều làng nghề tái chế kim loại đã hình thành lâu đời, như làng **Đa Hội** (Bắc Ninh) tái chế sắt thép, làng **Văn Môn** (Bắc Ninh) tái chế nhôm, chì. Tuy nhiên, ở nhiều cơ sở nhỏ lẻ, việc nấu chảy kim loại không có hệ thống xử lí khói, bụi và nước thải, gây ô nhiễm nặng cho đất, nước, không khí. Vì vậy tái chế cần đi kèm công nghệ sạch. Mỗi người có thể góp phần bằng cách **phân loại rác**, để riêng vỏ lon nhôm, đồ sắt, dây đồng cho người thu gom.

> [!vi-du] Ví dụ 6
> Một cơ sở tái chế 1 tấn vỏ lon nhôm. Vỏ lon chứa 96% nhôm về khối lượng, khi nấu chảy và tinh chế, lượng nhôm hao hụt 5%.
>
> a) Tính khối lượng nhôm thu được.
>
> b) Nếu sản xuất cùng lượng nhôm đó từ quặng bauxite chứa 51% Al~2~O~3~ (về khối lượng), với hiệu suất cả quá trình là 90%, thì cần bao nhiêu tấn quặng? (Làm tròn đến hàng phần trăm.)

> [!goi-y] Gợi ý 1
> a) Nhôm thu được = 1 · 96% · (100% − 5%).

> [!goi-y] Gợi ý 2
> b) Đi ngược từ Al về Al~2~O~3~: 2Al ứng với 1Al~2~O~3~, tức là 54 tấn Al ứng với 102 tấn Al~2~O~3~. Đi ngược thì **chia** hiệu suất, rồi chia tiếp cho 51% để ra khối lượng quặng.

> [!loi-giai] Lời giải
> a) m(Al) = 1 · 0,96 · 0,95 = **0,912 tấn**.
>
> b) m(Al~2~O~3~) lí thuyết = 0,912 · 102 : 54 ≈ 1,7227 tấn.
>
> m(Al~2~O~3~) cần = 1,7227 : 0,9 ≈ 1,9141 tấn → m(quặng) = 1,9141 : 0,51 ≈ **3,75 tấn**.
>
> Tái chế 1 tấn vỏ lon giúp không phải khai thác khoảng 3,75 tấn quặng bauxite, chưa kể lượng điện khổng lồ cho khâu điện phân.

## Dạng bài thi hay gặp

### Dạng 1. Chọn phương pháp, đếm số kim loại điều chế được

**Nhận biết:** đề cho một dãy kim loại (hoặc một dãy phản ứng), hỏi kim loại nào điều chế được bằng một phương pháp, hoặc **có bao nhiêu** kim loại, phản ứng thoả mãn.

**Phương pháp:**

1. Xếp các kim loại vào dãy hoạt động K, Na, Ba, Ca, Mg, Al | Zn, Fe, Ni, Sn, Pb, (H), Cu, Hg, Ag, Pt, Au. Kẻ "vạch" giữa **Al** và **Zn** (Hình 1).
2. **Trước vạch** (gồm cả Al): chỉ điện phân nóng chảy.
3. **Sau vạch**: nhiệt luyện, điện phân dung dịch đều được. Thuỷ luyện cũng dùng cho kim loại trung bình, yếu, thường gặp nhất là Cu, Ag, Au.
4. Nếu đề hỏi phương pháp nào điều chế được **hầu hết** kim loại (cả mạnh lẫn yếu) thì đó là **điện phân** (nóng chảy cho kim loại mạnh, dung dịch hoặc nóng chảy cho kim loại sau Al).

> [!vi-du] Ví dụ 7
> Cho các kim loại: Na, Mg, Al, Zn, Fe, Ni, Cu, K.
>
> a) Có bao nhiêu kim loại chỉ điều chế được bằng phương pháp điện phân nóng chảy?
>
> b) Có bao nhiêu kim loại điều chế được bằng phương pháp nhiệt luyện (dùng CO khử oxide)?

> [!goi-y] Gợi ý 1
> Kẻ vạch giữa Al và Zn. Đếm số kim loại ở mỗi bên.

> [!goi-y] Gợi ý 2
> Al nằm **trước** vạch. Nhiều bạn đếm nhầm Al vào nhóm nhiệt luyện.

> [!loi-giai] Lời giải
> a) Trước vạch: Na, Mg, Al, K → **4** kim loại.
>
> b) Sau vạch: Zn, Fe, Ni, Cu → **4** kim loại.

> [!bay]
> - **Al** chỉ điều chế bằng điện phân nóng chảy Al~2~O~3~. CO không khử được Al~2~O~3~.
> - Đề hỏi "phản ứng nào **thu được** kim loại" thì loại phản ứng của Na, K, Ba, Ca với dung dịch muối (chúng tác dụng với nước).
> - Mg tác dụng với dung dịch muối của kim loại yếu hơn vẫn đẩy được kim loại ra (Mg + CuSO~4~ → MgSO~4~ + Cu), vì Mg phản ứng rất chậm với nước lạnh.

### Dạng 2. Khử oxide kim loại bằng CO, H~2~ (bảo toàn nguyên tố O)

**Nhận biết:** CO hoặc H~2~ đi qua oxide (hoặc hỗn hợp oxide) nung nóng. Đề cho khối lượng chất rắn trước và sau, hoặc cho lượng khí sau phản ứng (thường dẫn vào nước vôi trong, dung dịch Ba(OH)~2~). Hỏi khối lượng, thể tích, phần trăm.

**Phương pháp** (không cần viết từng phương trình):

1. Mỗi CO (hay H~2~) lấy đi **1 nguyên tử O**: n(O mất) = n(CO phản ứng) = n(CO~2~), hoặc = n(H~2~) = n(H~2~O).
2. Khối lượng chất rắn giảm = khối lượng O bị lấy đi: m(rắn trước) − m(rắn sau) = 16 · n(O).
3. CO~2~ vào nước vôi trong (hay Ba(OH)~2~) **dư**: n(CO~2~) = n(kết tủa).
4. Nếu có oxide của kim loại mạnh (Al~2~O~3~, MgO…) thì nó **không mất O**, nhưng vẫn nằm trong chất rắn.
5. Khí sau phản ứng gồm CO~2~ và CO dư: số mol khí **không đổi** (1 CO → 1 CO~2~), dùng phân tử khối trung bình để tìm tỉ lệ.

> [!vi-du] Ví dụ 8
> Dẫn khí CO dư qua 20 g hỗn hợp CuO và Fe~2~O~3~ nung nóng. Sau khi phản ứng xảy ra hoàn toàn, dẫn toàn bộ khí đi ra vào dung dịch nước vôi trong dư, thu được 30 g kết tủa.
>
> a) Tính khối lượng chất rắn còn lại trong ống.
>
> b) Tính phần trăm khối lượng CuO trong hỗn hợp ban đầu.

> [!goi-y] Gợi ý 1
> Kết tủa là CaCO~3~ (M = 100). Từ đó suy ra n(CO~2~), cũng chính là số mol O mà oxide bị mất.

> [!goi-y] Gợi ý 2
> Câu b): đặt x = n(CuO), y = n(Fe~2~O~3~). Lập hai phương trình: khối lượng hỗn hợp và tổng số mol O (CuO có 1 O, Fe~2~O~3~ có 3 O).

> [!loi-giai] Lời giải
> n(CO~2~) = n(CaCO~3~) = 30 : 100 = 0,3 mol → n(O bị lấy) = 0,3 mol.
>
> a) m(chất rắn) = 20 − 0,3 · 16 = **15,2 g**.
>
> b) Ta có hệ: 80x + 160y = 20 và x + 3y = 0,3. Giải ra x = 0,15, y = 0,05.
>
> %m(CuO) = 0,15 · 80 : 20 · 100% = **60%**.

> [!vi-du] Ví dụ 9 (vận dụng)
> Cho V lít khí CO (điều kiện chuẩn) đi qua ống sứ đựng Fe~2~O~3~ nung nóng. Sau một thời gian, khối lượng chất rắn trong ống giảm 4,8 g, và hỗn hợp khí đi ra có tỉ khối so với H~2~ bằng 20. Tính V.

> [!goi-y] Gợi ý 1
> Khối lượng chất rắn giảm chính là khối lượng O bị lấy → n(CO~2~) tạo thành.

> [!goi-y] Gợi ý 2
> Khí đi ra gồm CO~2~ (44) và CO dư (28), có M trung bình = 20 · 2 = 40. Đặt a = n(CO dư), lập phương trình M trung bình. Tổng n(CO ban đầu) = n(CO~2~) + n(CO dư).

> [!loi-giai] Lời giải
> n(O) = 4,8 : 16 = 0,3 mol → n(CO~2~) = 0,3 mol.
>
> Gọi a là số mol CO dư: (28a + 44 · 0,3) : (a + 0,3) = 40 → 28a + 13,2 = 40a + 12 → a = 0,1.
>
> n(CO ban đầu) = 0,3 + 0,1 = 0,4 mol → V = 0,4 · 24,79 ≈ **9,92 L**.
>
> (Phản ứng không cần xảy ra hoàn toàn, chất rắn có thể là hỗn hợp Fe và các oxide sắt. Bảo toàn O giúp em không phải biết chính xác thành phần đó.)

> [!bay]
> - Khối lượng rắn **giảm** là m(O), không phải m(CO) hay m(CO~2~).
> - Số mol O trong oxide: CuO có 1, Fe~2~O~3~ có **3**, Fe~3~O~4~ có **4**. Đừng nhầm số mol oxide với số mol O.
> - Hỗn hợp có MgO, Al~2~O~3~: các oxide này không mất O. Khi tính phần trăm, nhớ chúng vẫn chiếm một phần khối lượng.
> - Nếu nước vôi trong **không dư** (có tạo Ca(HCO~3~)~2~), n(CO~2~) ≠ n(kết tủa).

### Dạng 3. Tính lượng kim loại thu được từ quặng (có hiệu suất)

**Nhận biết:** đề cho khối lượng quặng (thường theo tấn) và hàm lượng hợp chất chính, hỏi khối lượng kim loại (gang, kẽm…) thu được, hoặc hỏi ngược khối lượng quặng cần dùng.

**Phương pháp:**

1. m(hợp chất chính) = m(quặng) × % hợp chất.
2. Đi theo **nguyên tố kim loại** (bảo toàn nguyên tố), không cần viết phản ứng: ví dụ Fe~2~O~3~ (160) chứa 2Fe (112), ZnS (97) chứa Zn (65).
3. Đi xuôi (quặng → kim loại) thì **nhân** H. Đi ngược (kim loại → quặng) thì **chia** H.
4. Sản phẩm là **gang/thép chứa x% Fe** thì m(gang) = m(Fe) : x%.
5. Làm việc theo tấn và "tấn mol" cho gọn, không cần đổi ra gam.

> [!vi-du] Ví dụ 10
> Một lò cao dùng quặng hematite chứa 64% Fe~2~O~3~ (về khối lượng). Hiệu suất cả quá trình là 85%, gang thu được chứa 95% Fe.
>
> a) Từ 1 tấn quặng, thu được bao nhiêu kilogam gang? (Làm tròn đến hàng phần mười.)
>
> b) Cần bao nhiêu tấn quặng để sản xuất 1 tấn gang? (Làm tròn đến hàng phần trăm.)

> [!goi-y] Gợi ý 1
> 160 tấn Fe~2~O~3~ chứa 112 tấn Fe, tức là Fe chiếm 70% khối lượng Fe~2~O~3~.

> [!goi-y] Gợi ý 2
> m(Fe) thực tế = m(quặng) · 0,64 · 0,7 · 0,85. Gang có 95% Fe nên m(gang) = m(Fe) : 0,95. Câu b) là bài toán ngược của câu a).

> [!loi-giai] Lời giải
> a) m(Fe~2~O~3~) = 1 · 0,64 = 0,64 tấn → m(Fe) lí thuyết = 0,64 · 112 : 160 = 0,448 tấn.
>
> m(Fe) thực tế = 0,448 · 0,85 = 0,3808 tấn → m(gang) = 0,3808 : 0,95 ≈ 0,40084 tấn ≈ **400,8 kg**.
>
> b) 1 tấn quặng cho 0,40084 tấn gang, nên muốn có 1 tấn gang cần 1 : 0,40084 ≈ **2,49 tấn** quặng.

> [!bay]
> - Quên nhân hàm lượng % của hợp chất trong quặng.
> - Quên chia cho % Fe trong gang: gang **nặng hơn** lượng sắt nguyên chất chứa trong nó.
> - Với quặng sulfide (ZnS, FeS~2~), vẫn đi theo nguyên tố kim loại. Đừng nhầm M của oxide sau khi đốt với M của sulfide ban đầu.

### Dạng 4. Câu Đúng/Sai lí thuyết

**Nhận biết:** 4 ý về trạng thái tự nhiên, quặng, nguyên tắc, phạm vi áp dụng của từng phương pháp, tái chế.

**Phương pháp:** soát các từ khoá: **dạng đơn chất** (chỉ Au, Ag, Pt…), **"khử ion"** (không phải "oxi hoá"), **ranh giới Al | Zn**, **nóng chảy hay dung dịch**, **chất khử là gì**, **cathode hay anode**.

> [!vi-du] Ví dụ 11 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Nguyên tắc chung để điều chế kim loại là oxi hoá ion kim loại thành nguyên tử.
>
> b) Có thể điều chế Cu bằng cả ba phương pháp: nhiệt luyện, thuỷ luyện và điện phân dung dịch.
>
> c) Dùng khí H~2~ dư khử MgO ở nhiệt độ cao thu được Mg.
>
> d) Khi điện phân MgCl~2~ nóng chảy, ở cathode xảy ra quá trình khử ion Mg^2+^.

> [!goi-y] Gợi ý 1
> M^n+^ + ne → M: ion **nhận** electron. Nhận electron là quá trình gì?

> [!goi-y] Gợi ý 2
> Mg đứng trước hay sau Al? Ở cathode luôn xảy ra quá trình khử hay oxi hoá?

> [!loi-giai] Lời giải
> a) **Sai**: ion kim loại nhận electron, đó là quá trình **khử**.
>
> b) **Đúng**: CuO + CO → Cu + CO~2~ (nhiệt luyện); Fe + CuSO~4~ → FeSO~4~ + Cu (thuỷ luyện); điện phân dung dịch CuSO~4~ hoặc CuCl~2~.
>
> c) **Sai**: MgO là oxide của kim loại mạnh (đứng trước Al), H~2~ không khử được.
>
> d) **Đúng**: cathode luôn là nơi xảy ra quá trình khử: Mg^2+^ + 2e → Mg.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Trạng thái tự nhiên | Hầu hết ở dạng hợp chất trong quặng. Dạng đơn chất: Au, Ag, Pt… |
| Quặng (SGK) | Bauxite Al~2~O~3~·2H~2~O; zinc blende ZnS; hematite Fe~2~O~3~; pyrite FeS~2~; chalcopyrite CuFeS~2~ |
| Nguyên tắc | Khử ion kim loại: M^n+^ + ne → M |
| Điện phân nóng chảy | Kim loại mạnh (K, Na, Ca, Mg, Al…). Al từ Al~2~O~3~ (có cryolite), các kim loại khác từ muối chloride |
| Nhiệt luyện | C, CO, H~2~ khử oxide ở t° cao. Kim loại sau Al (Zn, Fe, Sn, Pb, Cu…). Sulfide phải đốt thành oxide trước |
| Điện phân dung dịch | Kim loại sau Al. Ion kim loại bị khử ở cathode |
| Thuỷ luyện | Hoà tan rồi dùng kim loại mạnh hơn (Fe, Zn) khử ion. Kim loại trung bình, yếu; thường gặp Cu, Ag, Au |
| Tái chế | Thu gom, phân loại → xử lí sơ bộ → phối trộn → nấu chảy → tinh chế → đúc, gia công. Tiết kiệm tài nguyên, năng lượng, giảm phát thải |

**Các hệ thức dùng trong tính toán:**

- CO + [O] → CO~2~; H~2~ + [O] → H~2~O.
- n(O mất) = n(CO) = n(CO~2~) = n(H~2~) = n(H~2~O).
- m(rắn giảm) = 16 · n(O).
- %Fe: Fe~2~O~3~ 70%; Fe~3~O~4~ ≈ 72,4%; FeS~2~ ≈ 46,7%.
- Từ quặng: m(kim loại) = m(quặng) · %hợp chất · (khối lượng kim loại trong 1 mol hợp chất : M) · H.
- Đi xuôi nhân H, đi ngược chia H.
