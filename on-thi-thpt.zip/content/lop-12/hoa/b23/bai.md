---
title: Ôn tập chương 6
thoi-gian: 50 phút
muc-tieu:
  - Hệ thống hoá kiến thức chương Đại cương về kim loại: cấu tạo và liên kết kim loại, tính chất vật lí và hoá học, kim loại trong tự nhiên và cách tách kim loại, hợp kim, ăn mòn và chống ăn mòn.
  - Thấy được sợi chỉ xuyên suốt chương: kim loại dễ nhường electron, nên có tính khử, tồn tại chủ yếu ở dạng hợp chất, phải khử ion để tách ra và dễ bị oxi hoá (ăn mòn).
  - Dùng một dãy hoạt động (dãy E°) để trả lời mọi câu hỏi "mạnh – yếu": phản ứng với nước, acid, muối; chọn phương pháp tách; chọn kim loại hi sinh.
  - Phân biệt chắc chắn các cặp khái niệm dễ nhầm và giải được bài tập tổng hợp phối hợp nhiều bài trong chương.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. **Nguyên tử kim loại** thường có **1–3 electron lớp ngoài cùng**, bán kính lớn, độ âm điện nhỏ, nên **dễ nhường electron**.
> 2. **Tinh thể kim loại**: ion dương ở nút mạng, electron hoá trị **chuyển động tự do**. **Liên kết kim loại** là lực hút tĩnh điện giữa electron tự do và các ion dương.
> 3. **Electron tự do** gây ra bốn tính chất vật lí chung: **dẻo, dẫn điện, dẫn nhiệt, ánh kim**.
> 4. **Tính chất hoá học chung là tính khử** (M → M^n+^ + ne): tác dụng với phi kim, nước, dung dịch acid, dung dịch muối. Mạnh hay yếu tra theo **E°**.
> 5. Trong tự nhiên hầu hết kim loại ở dạng **hợp chất**. Chỉ vài kim loại kém hoạt động (Au, Ag, Pt…) có dạng đơn chất.
> 6. **Nguyên tắc tách kim loại: khử ion kim loại thành nguyên tử** (M^n+^ + ne → M).
> 7. Kim loại mạnh (K, Na, Ca, Mg, Al): **điện phân nóng chảy**. Kim loại trung bình, yếu: **nhiệt luyện, điện phân dung dịch, thuỷ luyện**.
> 8. **Hợp kim**: một kim loại cơ bản + kim loại khác hoặc phi kim. Hoá học giống thành phần. Vật lí khác: **cứng hơn, kém dẻo, dẫn điện kém hơn**, nhiệt độ nóng chảy khác.
> 9. **Ăn mòn** là kim loại **bị oxi hoá** bởi chất trong môi trường. Có **ăn mòn hoá học** (trực tiếp) và **ăn mòn điện hoá** (có pin: hai điện cực khác nhau, tiếp xúc, cùng trong dung dịch điện li).
> 10. **Chống ăn mòn**: phương pháp **điện hoá** (gắn kim loại **mạnh hơn** làm anode hi sinh) và phương pháp **phủ bề mặt** (sơn, dầu mỡ, mạ, tráng).

Bài này **không giảng lại từ đầu**. Em dùng nó để xâu chuỗi năm bài: Bài 18 (Cấu tạo và liên kết), Bài 19 (Tính chất), Bài 20 (Tách kim loại), Bài 21 (Hợp kim), Bài 22 (Ăn mòn). Chỗ nào chưa vững, hãy quay lại đúng mục được dẫn. Chương này dùng rất nhiều kiến thức về E° của chương 5, nên em nên mở sẵn Bài 17 (Ôn tập chương 5) bên cạnh.

## 1. Hệ thống hoá kiến thức

### 1.1. Bức tranh toàn chương: một nguyên nhân, nhiều hệ quả

Cả chương 6 đều bắt nguồn từ **một** đặc điểm: nguyên tử kim loại giữ electron lớp ngoài rất lỏng lẻo. Từ đó suy ra lần lượt:

1. **Trong tinh thể**, các electron đó rời nguyên tử, đi lại tự do giữa các ion dương. Đó là **liên kết kim loại** (Bài 18).
2. **Electron tự do** làm kim loại dẻo, dẫn điện, dẫn nhiệt, có ánh kim (Bài 19, mục 1).
3. **Dễ nhường electron** nghĩa là kim loại có **tính khử** (Bài 19, mục 2).
4. Vì dễ nhường electron, ngoài tự nhiên kim loại đã "nhường" từ lâu, nên nằm trong quặng ở dạng **ion**. Muốn lấy lại kim loại phải **trả electron cho ion**, tức là **khử** (Bài 20).
5. Kim loại vừa tách ra lại có xu hướng **nhường electron** cho O~2~, H^+^… trong môi trường. Đó là **ăn mòn** (Bài 22), quá trình **ngược** với tách kim loại.
6. Muốn kim loại cứng hơn, bền hơn, người ta trộn thêm nguyên tố khác thành **hợp kim** (Bài 21).

![Hình 1. Hệ thống hoá chương 6: cấu tạo quyết định tính chất. Tách kim loại (khử ion) và ăn mòn (oxi hoá kim loại) là hai chiều ngược nhau của cùng một quá trình](he-thong.svg)

**Vì sao nói "kim loại khử càng mạnh thì càng khó tách ra, càng dễ bị ăn mòn"?** Kim loại khử mạnh như Al rất "muốn" ở dạng ion Al^3+^. Muốn ép Al^3+^ nhận lại electron, chất khử hoá học thông thường không làm nổi, phải dùng dòng điện (điện phân nóng chảy). Ngược lại, vàng có E° rất lớn, gần như không nhường electron, nên vừa có sẵn ở dạng đơn chất, vừa không bị gỉ. Hai câu hỏi tưởng khác nhau thực ra là một.

### 1.2. Cấu tạo quyết định tính chất

| Đặc điểm cấu tạo | Hệ quả | Xem lại |
|---|---|---|
| Thường 1–3 e lớp ngoài cùng, bán kính lớn, độ âm điện nhỏ | dễ nhường e, **tính khử** | Bài 18, mục 1; Bài 19, mục 2 |
| Electron tự do chạy khắp mạng tinh thể | **dẫn điện**: e chuyển dời có hướng khi có hiệu điện thế | Bài 19, mục 1.2 |
| Electron tự do va chạm, truyền năng lượng | **dẫn nhiệt** | Bài 19, mục 1.3 |
| Electron tự do phản xạ ánh sáng | **ánh kim** | Bài 19, mục 1.4 |
| Liên kết kim loại không định hướng, các lớp ion trượt lên nhau vẫn được e giữ | **dẻo** (dát mỏng, kéo sợi) | Bài 19, mục 1.1 |
| Nguyên tử lạ làm mạng tinh thể lệch, cản trượt, làm e lệch hướng | hợp kim **cứng hơn, kém dẻo, dẫn điện kém** | Bài 21, mục 2 |

> [!bay] "Thường" không phải "luôn luôn"
> - Một số kim loại có 4–5 electron lớp ngoài cùng (Sn, Pb, Bi…). Ngược lại H, He có 1–2 electron lớp ngoài nhưng **không** là kim loại (Bài 18, mục 1.2).
> - Các nguyên tố nhóm B (khối d, f) đều là kim loại. Khối s gồm kim loại nhưng còn có H, He.
> - Tính chất vật lí **riêng** (khối lượng riêng, nhiệt độ nóng chảy, độ cứng) **không** do electron tự do quyết định là chính. Chúng phụ thuộc bán kính, khối lượng nguyên tử, độ bền liên kết kim loại.

### 1.3. Tính chất hoá học: một dãy, nhiều câu hỏi

Mọi phản ứng của kim loại trong chương đều là **kim loại nhường electron cho một chất oxi hoá**. Chất oxi hoá khác nhau thì "ngưỡng" khác nhau, nhưng em luôn so trên **cùng một dãy E°** (Hình 2).

![Hình 2. Một dãy hoạt động (E° tăng dần từ trái sang phải) dùng cho cả chương: phản ứng với nước, với acid loãng; chọn phương pháp tách kim loại; kim loại có dạng đơn chất trong tự nhiên; kim loại hi sinh bảo vệ thép (lấy Fe làm mốc)](truc-e.svg)

| Phản ứng với | Điều kiện, sản phẩm | Điểm hay hỏi | Xem lại |
|---|---|---|---|
| Phi kim (O~2~, Cl~2~, S) | hầu hết kim loại, thường cần đun nóng | Fe + Cl~2~ → **FeCl~3~**; Fe + S → **FeS**; Hg + S ở nhiệt độ thường; Au, Ag, Pt không cháy trong O~2~ | Bài 19, mục 2.1 |
| Nước | K, Na, Ca, Ba, Li ở nhiệt độ thường → base + H~2~ | Mg phản ứng rất chậm; Al, Zn, Fe bị lớp oxide che | Bài 19, mục 2.2 |
| HCl, H~2~SO~4~ loãng | kim loại có E° < 0 → muối + **H~2~** | Fe chỉ lên **Fe^2+^**; Cu, Ag, Au không tan | Bài 19, mục 2.3a |
| H~2~SO~4~ đặc, nóng | hầu hết kim loại (trừ Au, Pt) → muối + **SO~2~** | Cu tan được; Fe lên Fe^3+^ (ngoài SGK); không tạo H~2~ | Bài 19, mục 2.3b |
| H~2~SO~4~ đặc, nguội | Al, Fe, Cr bị **thụ động hoá** | chở acid đặc bằng thùng sắt, nhôm | Bài 19, mục 2.3b |
| Dung dịch muối | kim loại E° nhỏ đẩy kim loại E° lớn | Na, K, Ca, Ba phản ứng với **nước** trước; Cu khử được Fe^3+^ về Fe^2+^ | Bài 19, mục 2.4 |

> [!nen-tang] Các giá trị E° hay dùng trong chương (V)
> - K^+^/K −2,924 · Na^+^/Na −2,713 · Mg^2+^/Mg −2,356 · Al^3+^/Al −1,676 · Zn^2+^/Zn −0,762.
> - Fe^2+^/Fe −0,44 · Ni^2+^/Ni −0,257 · Sn^2+^/Sn −0,137 · Pb^2+^/Pb −0,126 · 2H^+^/H~2~ 0.
> - Cu^2+^/Cu +0,340 · Fe^3+^/Fe^2+^ +0,771 · Ag^+^/Ag +0,799 · Au^3+^/Au +1,52.
>
> Quy tắc chiều phản ứng (Bài 15): **chất khử của cặp E° nhỏ** phản ứng với **chất oxi hoá của cặp E° lớn**.

### 1.4. Kim loại trong tự nhiên và phương pháp tách

Nguyên tắc chỉ có một: **M^n+^ + ne → M**. Điều thay đổi là **ai** cung cấp electron, và điều đó tuỳ vào ion "giữ" trạng thái ion chặt đến đâu.

| Nhóm kim loại | Phương pháp | Chất khử (nguồn electron) | Ví dụ | Xem lại |
|---|---|---|---|---|
| Mạnh: K, Na, Ca, Mg, Al | điện phân **nóng chảy** | cathode của bình điện phân | 2Al~2~O~3~ → 4Al + 3O~2~ (có cryolite); MgCl~2~ → Mg + Cl~2~ | Bài 20, mục 2.2 |
| Trung bình, yếu: Zn, Fe, Sn, Pb, Cu… | **nhiệt luyện** | C, CO, H~2~ (ở nhiệt độ cao) | Fe~2~O~3~ + 3CO → 2Fe + 3CO~2~ | Bài 20, mục 2.3a |
| Trung bình, yếu | **điện phân dung dịch** | cathode | CuCl~2~ → Cu + Cl~2~ | Bài 20, mục 2.3b |
| Trung bình, yếu (thường gặp: Cu, Ag, Au) | **thuỷ luyện** | kim loại mạnh hơn (Fe, Zn…) | Fe + CuSO~4~ → FeSO~4~ + Cu | Bài 20, mục 2.3c |

Ba ghi chú đi kèm bảng:

- Quặng **sulfide** (ZnS, CuFeS~2~) phải **đốt thành oxide** trước rồi mới khử bằng C, CO.
- CO, H~2~ chỉ khử oxide của kim loại **sau Al**. MgO, Al~2~O~3~, CaO… giữ nguyên.
- **Tái chế** kim loại (nhôm, đồng, sắt) tiết kiệm quặng và năng lượng, giảm phát thải (Bài 20, mục 3).

### 1.5. Hợp kim

| Hợp kim | Kim loại cơ bản | Thành phần đặc trưng | Tính chất nổi bật | Dùng làm |
|---|---|---|---|---|
| Gang | Fe | khoảng 2–4% C | cứng, **giòn**, nóng chảy thấp hơn sắt | luyện thép, nồi chảo, bệ máy |
| Thép | Fe | dưới 2% C, có thể thêm Mn, Si, Cr… | cứng, bền, điều chỉnh được tính chất | xây dựng, chế tạo máy |
| Thép không gỉ (inox) | Fe | **ít nhất 10% Cr** | chống ăn mòn tốt | dụng cụ y tế, đồ gia dụng |
| Duralumin | Al | khoảng 4% Cu, ít Mn, Mg, Si | nhẹ, cứng, bền | máy bay |
| Au – Cu | Au | khoảng 8–12% Cu | cứng hơn vàng | trang sức, tiền vàng |

Nhớ một quy tắc để làm bài tính toán: **trong hợp kim, mỗi thành phần phản ứng như khi đứng riêng**. Cho duralumin vào HCl dư thì Al, Mg tan, Cu còn lại. Cho Au – Cu vào H~2~SO~4~ đặc nóng thì chỉ Cu tan (Bài 21, mục 2.1).

### 1.6. Ăn mòn và chống ăn mòn

**Ăn mòn hoá học** (Bài 22, mục 1.2): electron đi **thẳng** từ kim loại sang chất oxi hoá, thường ở nhiệt độ cao, không có dung dịch điện li. Ví dụ: 3Fe + 2O~2~ → Fe~3~O~4~ trong lò đốt.

**Ăn mòn điện hoá** (Bài 22, mục 1.3) cần **đủ ba điều kiện**:

1. Hai điện cực **khác nhau** (hai kim loại, hoặc kim loại – phi kim như Fe – C).
2. Hai điện cực **tiếp xúc** trực tiếp hoặc nối bằng dây dẫn.
3. Cùng nhúng trong **một dung dịch chất điện li** (nước biển, không khí ẩm, acid…).

Khi đủ ba điều kiện, kim loại **có E° nhỏ hơn** là **anode, bị ăn mòn**. Ở cathode, chất oxi hoá trong dung dịch (O~2~, H^+^, Cu^2+^…) bị khử. Gang, thép gỉ trong không khí ẩm: Fe là anode, C là cathode, O~2~ + 2H~2~O + 4e → 4OH^−^, gỉ là Fe~2~O~3~·nH~2~O.

**Chống ăn mòn** (Bài 22, mục 2):

- **Phương pháp điện hoá**: gắn kim loại **mạnh hơn** (Zn, Mg) vào vật cần bảo vệ. Kim loại mạnh là anode hi sinh, bị ăn mòn thay.
- **Phương pháp phủ bề mặt**: sơn, dầu mỡ, tráng men, mạ hoặc tráng kim loại khác (tôn tráng Zn, sắt tây tráng Sn).

> [!ghi-nho] Đọc chương 6 theo chiều electron
> - Tách kim loại: ion kim loại **nhận** electron (bị khử).
> - Kim loại phản ứng hoá học, bị ăn mòn: kim loại **nhường** electron (bị oxi hoá).
> - Bảo vệ điện hoá: để **kim loại khác** nhường electron thay.

## 2. So sánh – phân biệt

### 2.1. Ăn mòn hoá học và ăn mòn điện hoá

Đây là bảng đề thi khai thác nhiều nhất của chương. Đề thường cho một loạt thí nghiệm rồi hỏi "có bao nhiêu trường hợp xảy ra ăn mòn điện hoá".

| | Ăn mòn hoá học | Ăn mòn điện hoá |
|---|---|---|
| Bản chất | kim loại phản ứng oxi hoá – khử **trực tiếp** | một **pin điện** tự hình thành và bị đoản mạch |
| Electron đi | thẳng từ kim loại sang chất oxi hoá | từ anode qua chỗ tiếp xúc sang cathode |
| Dòng điện | không phát sinh | có dòng electron |
| Cần mấy loại điện cực? | một kim loại là đủ | **hai** điện cực khác nhau |
| Môi trường hay gặp | khí khô, nhiệt độ cao (O~2~, Cl~2~) | dung dịch điện li: không khí ẩm, nước biển, acid |
| Kim loại bị ăn mòn | chính kim loại tiếp xúc chất oxi hoá | kim loại **có E° nhỏ hơn** (anode) |
| Tốc độ, mức phổ biến | chậm hơn, ít hơn | **nhanh hơn**, phổ biến hơn |
| Ví dụ | Fe trong lò đốt, Fe cháy trong Cl~2~, Zn tinh khiết trong HCl, Cu trong dung dịch FeCl~3~ | thép gỉ ngoài trời, Fe nhúng vào dung dịch CuSO~4~ (Cu bám lên Fe), Zn trong H~2~SO~4~ có thêm CuSO~4~ |

**Mẹo soát nhanh "có ăn mòn điện hoá không"**: hỏi đúng ba câu. Có hai chất dẫn điện khác nhau không? Chúng có chạm nhau (hoặc nối dây) không? Chúng có cùng ngâm trong một dung dịch điện li không? Một câu "không" là loại. Chú ý trường hợp **kim loại sinh ra bám lên kim loại ban đầu** (Fe + CuSO~4~, Zn + CuSO~4~, Ni + AgNO~3~): cặp điện cực tự xuất hiện, nên có ăn mòn điện hoá. Còn Fe + FeCl~3~, Cu + FeCl~3~ không sinh kim loại mới, chỉ là ăn mòn hoá học.

### 2.2. Tách kim loại và ăn mòn kim loại: hai chiều ngược nhau

| | Tách (điều chế) kim loại | Ăn mòn kim loại |
|---|---|---|
| Quá trình với kim loại | M^n+^ + ne → M (**khử**) | M → M^n+^ + ne (**oxi hoá**) |
| Có tự xảy ra không? | thường phải tốn năng lượng (nhiệt, điện) | **tự xảy ra**, gây thiệt hại |
| Kim loại khử mạnh (Al, Mg) | **khó** tách, phải điện phân nóng chảy | dễ bị oxi hoá (nhưng Al được lớp oxide bền che) |
| Kim loại khử yếu (Au, Ag) | dễ, có khi sẵn dạng đơn chất | gần như không bị ăn mòn |
| Con người làm gì? | cung cấp electron cho ion | ngăn kim loại mất electron (cách li hoặc cho kim loại khác mất thay) |

Bảng này giải thích vì sao **tái chế** có lợi: kim loại phế liệu vẫn đang ở dạng đơn chất, không cần tốn năng lượng khử lại từ ion như khi đi từ quặng.

### 2.3. Các cặp hay bị đánh tráo trong đề

| Cặp | Giống nhau | Khác nhau (chỗ đề hay hỏi) |
|---|---|---|
| Liên kết kim loại – liên kết ion | đều do lực hút tĩnh điện | kim loại: ion dương hút **electron tự do chung**. Ion: ion dương hút **ion âm** |
| Fe + Cl~2~ – Fe + S – Fe + HCl | Fe đều là chất khử | Cl~2~ mạnh: **FeCl~3~**. S yếu: **FeS**. HCl (H^+^ yếu): **FeCl~2~** |
| H~2~SO~4~ loãng – đặc nóng – đặc nguội | đều là H~2~SO~4~ | loãng: H^+^ oxi hoá, ra **H~2~**, Cu không tan. Đặc nóng: S^+6^ oxi hoá, ra **SO~2~**, Cu tan. Đặc nguội: Al, Fe, Cr **thụ động** |
| Điện phân nóng chảy – điện phân dung dịch | đều dùng dòng điện một chiều | nóng chảy: thu được **cả** kim loại mạnh. Dung dịch: K^+^, Na^+^, Mg^2+^, Al^3+^ thua nước, chỉ có H~2~ |
| Nhiệt luyện – thuỷ luyện | đều dùng chất khử hoá học | nhiệt luyện: C, CO, H~2~ khử **oxide** ở **nhiệt độ cao**. Thuỷ luyện: **kim loại** mạnh hơn khử ion trong **dung dịch** |
| Gang – thép | đều là hợp kim Fe – C | gang **2–4% C**, giòn. Thép **dưới 2% C**, dẻo dai hơn |
| Thép không gỉ – tôn | đều chống gỉ | inox: **hợp kim** có ≥ 10% Cr. Tôn: thép **phủ** lớp Zn |
| Tôn – sắt tây khi bị xước | đều là thép được phủ kim loại | tôn: **Zn** (mạnh hơn Fe) bị ăn mòn, Fe được bảo vệ. Sắt tây: **Fe** (mạnh hơn Sn) bị ăn mòn nhanh tại vết xước |
| Phương pháp điện hoá – phủ bề mặt | đều chống ăn mòn | điện hoá: kim loại hi sinh **vẫn bị ăn mòn**, chỉ thay cho vật. Phủ bề mặt: **cách li** vật với môi trường |
| Cu + FeCl~3~ – Cu + FeCl~2~ | đều là Cu với muối sắt | Cu khử được Fe^3+^ (+0,771) về Fe^2+^. Cu **không** khử được Fe^2+^ (−0,44) |

## 3. Bảng công thức tính toán của chương

| Bài toán | Công thức / cách làm | Xem lại |
|---|---|---|
| Kim loại + HCl, H~2~SO~4~ loãng | Σ(n~KL~ · hoá trị) = 2n(H~2~); m(muối chloride) = m(KL) + 71n(H~2~); m(muối sulfate) = m(KL) + 96n(H~2~) | Bài 19, Dạng 1 |
| Kim loại + H~2~SO~4~ đặc nóng | Σ(n~KL~ · hoá trị) = 2n(SO~2~) | Bài 19, Dạng 1 |
| Thanh kim loại nhúng vào muối | Δm(thanh) = m(KL bám vào) − m(KL tan ra) | Bài 19, Dạng 2 |
| Nhiều ion trong dung dịch | ion có E° **lớn** phản ứng **trước** (Ag^+^ > Fe^3+^ > Cu^2+^ > …) | Bài 19, Dạng 2 |
| Khử oxide bằng CO, H~2~ | n(CO) = n(CO~2~) = n(O bị lấy); n(H~2~) = n(O); m(rắn sau) = m(oxide) − 16n(O) | Bài 20, Dạng 2 |
| Từ quặng ra kim loại | m(KL) = m(quặng) · %hợp chất · (tỉ lệ khối lượng KL trong hợp chất) · H | Bài 20, Dạng 3 |
| Hợp kim + acid | thành phần nào tan thì tính như kim loại riêng; chất rắn còn lại là thành phần không tan | Bài 21, Dạng 2 |
| Gang → thép (chỉ C bị loại) | m(Fe) không đổi: m(thép) = m(Fe) : %Fe trong thép | Bài 21, Dạng 3 |
| Ăn mòn tạo oxide bám lại | Δm = m(O) (hoặc m(Cl)) đã kết hợp | Bài 22, Ví dụ 1 |
| Thể tích khí (đkc) | V = n · 24,79 L | Bài 19 |

> [!meo] Bảo toàn electron "đi đường vòng"
> Nếu kim loại đi một vòng rồi về **đúng số oxi hoá ban đầu**, em có thể bỏ qua các bước giữa. Ví dụ: Fe~2~O~3~ bị CO khử thành Fe, rồi Fe lại bị H~2~SO~4~ đặc nóng oxi hoá lên Fe^3+^. Fe đi từ +3 về +3, nên **số electron CO nhường bằng số electron SO~2~ nhận**: n(CO~2~) = n(SO~2~). Ví dụ 1 dưới đây minh hoạ điều này.

## 4. Lỗi sai hay gặp của cả chương

**Về cấu tạo và tính chất vật lí**

- Cho rằng **mọi** nguyên tử có 1–3 electron lớp ngoài đều là kim loại (H, He, B là phản ví dụ).
- Nói ở nút mạng tinh thể kim loại là **nguyên tử trung hoà** hoặc cho **ion âm** chuyển động tự do.
- Giải thích ánh kim, tính dẫn điện bằng **ion dương** (đúng là electron tự do).
- Cho nhôm dẫn điện tốt hơn đồng (thứ tự: Ag > Cu > Au > Al > Fe).

**Về tính chất hoá học**

- Viết Fe + Cl~2~ → FeCl~2~, hoặc Fe + HCl → FeCl~3~.
- Cho Cu tan trong HCl, H~2~SO~4~ loãng. Hoặc cho Al, Fe tan trong H~2~SO~4~ **đặc, nguội**.
- Cho Na, K vào dung dịch muối rồi kết luận kim loại bị đẩy ra.
- Quên Cu **có** phản ứng với Fe^3+^. Hoặc cho Cu đẩy được Fe ra khỏi muối sắt.
- Khi có nhiều ion, cho Cu^2+^ phản ứng trước Fe^3+^ (Fe^3+^ có E° lớn hơn nên phản ứng trước).

**Về tách kim loại**

- Viết nguyên tắc là "**oxi hoá** ion kim loại".
- Cho CO, H~2~ khử được MgO, Al~2~O~3~.
- Điện phân **dung dịch** NaCl, AlCl~3~ để lấy Na, Al. Điện phân AlCl~3~ nóng chảy để lấy Al (công nghiệp dùng **Al~2~O~3~**).
- Quên nhân (hoặc nhân hai lần) hiệu suất. Đi từ nguyên liệu đến sản phẩm thì **nhân** H.

**Về hợp kim**

- Cho thép nhiều carbon hơn gang. Cho inox là thép có 10% **carbon** hoặc **nickel**.
- Cho hợp kim dẫn điện tốt hơn kim loại nguyên chất, hoặc nhiệt độ nóng chảy hợp kim "luôn cao hơn".
- Cho Cu trong hợp kim "tan theo" Al khi ngâm HCl.

**Về ăn mòn**

- Cho một thanh Zn tinh khiết trong HCl bị ăn mòn điện hoá (chỉ có một điện cực).
- Cho ở cathode "kim loại cathode bị khử" (đúng là O~2~, H^+^… trong dung dịch bị khử).
- Gắn Cu, Sn lên thép để "bảo vệ" (thép thành anode, gỉ nhanh hơn).
- Cho sắt tây bị xước thì Sn bị ăn mòn trước.
- Nói phương pháp điện hoá làm sự ăn mòn **dừng lại** (thực ra chỉ chuyển sang kim loại hi sinh).

## 5. Bài tập tổng hợp

Các ví dụ dưới đây phối hợp nhiều bài trong chương. Hãy tự làm trước, mở từng gợi ý khi bí.

### 5.1. Khử oxide rồi hoà tan sản phẩm (Bài 20 + Bài 19)

> [!vi-du] Ví dụ 1
> Hỗn hợp X gồm 0,06 mol CuO và 0,05 mol Fe~2~O~3~. Dẫn khí CO dư qua X nung nóng đến khi phản ứng xảy ra hoàn toàn, thu được chất rắn Y. Toàn bộ khí đi ra được dẫn vào nước vôi trong dư.
>
> a) Tính khối lượng kết tủa và khối lượng Y.
>
> b) Cho Y vào dung dịch HCl dư. Tính thể tích H~2~ (đkc) và khối lượng chất rắn không tan.
>
> c) Nếu cho Y vào dung dịch H~2~SO~4~ đặc, nóng, dư thì thu được bao nhiêu mol SO~2~ (sản phẩm khử duy nhất)? So sánh với số mol CO~2~ ở câu a và giải thích.

> [!goi-y] Gợi ý 1
> Mỗi CO lấy đi 1 nguyên tử O để thành CO~2~. Đếm tổng số mol O trong hai oxide.

> [!goi-y] Gợi ý 2
> Y gồm Cu và Fe. Trong HCl chỉ Fe tan và chỉ lên Fe^2+^. Trong H~2~SO~4~ đặc nóng dư, Cu lên Cu^2+^, Fe lên Fe^3+^.

> [!loi-giai] Lời giải
> a) n(O) = 0,06 + 3 · 0,05 = 0,21 mol → n(CO~2~) = 0,21 mol → n(CaCO~3~) = 0,21 mol, m = **21 g**.
>
> Y gồm Cu 0,06 mol và Fe 0,1 mol: m(Y) = 0,06 · 64 + 0,1 · 56 = 3,84 + 5,6 = **9,44 g** (kiểm tra: 12,8 − 0,21 · 16 = 9,44 ✓).
>
> b) => Fe + 2HCl → FeCl~2~ + H~2~
>
> n(H~2~) = 0,1 mol, V = 0,1 · 24,79 = **2,479 L**. Chất rắn không tan là Cu: **3,84 g**.
>
> c) Bảo toàn electron: 2n(SO~2~) = 2 · 0,06 + 3 · 0,1 = 0,42 → n(SO~2~) = **0,21 mol**, đúng bằng n(CO~2~).
>
> Giải thích: Cu đi từ +2 (CuO) về 0 rồi lại lên +2. Fe đi từ +3 (Fe~2~O~3~) về 0 rồi lại lên +3. Electron mà CO đã "cho" kim loại, nay kim loại "trả" hết cho S^+6^. Mỗi CO nhường 2e, mỗi SO~2~ nhận 2e, nên số mol bằng nhau.

> [!bay]
> - Ở câu b, nếu viết Fe + HCl → FeCl~3~ em sẽ tính n(H~2~) = 0,15 mol, sai.
> - Ở câu c, nếu cho Fe chỉ lên Fe^2+^ em sẽ ra 0,16 mol SO~2~. H~2~SO~4~ đặc, nóng, **dư** đưa Fe lên +3.

### 5.2. Thanh sắt trong dung dịch hai muối: thứ tự phản ứng và dạng ăn mòn (Bài 19 + Bài 22)

> [!vi-du] Ví dụ 2
> Nhúng một thanh sắt (lượng dư) vào 200 mL dung dịch chứa Fe~2~(SO~4~)~3~ 0,1 M và CuSO~4~ 0,25 M. Phản ứng xảy ra hoàn toàn, toàn bộ Cu sinh ra bám vào thanh. Cho E° (V): Fe^2+^/Fe −0,44 · Cu^2+^/Cu +0,340 · Fe^3+^/Fe^2+^ +0,771.
>
> a) Viết các phản ứng theo đúng thứ tự xảy ra.
>
> b) Khối lượng thanh sắt tăng hay giảm bao nhiêu gam?
>
> c) Trong mỗi giai đoạn, sắt bị ăn mòn theo kiểu nào?

> [!goi-y] Gợi ý 1
> Fe là chất khử. Hai chất oxi hoá Fe^3+^ và Cu^2+^ "tranh" electron của Fe: chất có E° lớn hơn được nhận trước.

> [!goi-y] Gợi ý 2
> Δm = m(Cu bám vào) − m(Fe tan ra). Fe tan ở **cả hai** phản ứng, nhưng chỉ phản ứng thứ hai có kim loại bám vào.

> [!goi-y] Gợi ý 3
> Câu c: giai đoạn nào có hai điện cực khác nhau tiếp xúc nhau trong dung dịch điện li?

> [!loi-giai] Lời giải
> n(Fe^3+^) = 0,2 · 0,1 · 2 = 0,04 mol; n(Cu^2+^) = 0,2 · 0,25 = 0,05 mol.
>
> a) Fe^3+^ (+0,771) phản ứng trước Cu^2+^ (+0,340):
>
> => Fe + 2Fe^3+^ → 3Fe^2+^
>
> => Fe + Cu^2+^ → Fe^2+^ + Cu
>
> b) Fe tan: 0,04 : 2 + 0,05 = 0,07 mol → 0,07 · 56 = 3,92 g. Cu bám vào: 0,05 · 64 = 3,2 g.
>
> Δm = 3,2 − 3,92 = −0,72 g. Thanh sắt **giảm 0,72 g**.
>
> c) Giai đoạn 1: Fe phản ứng trực tiếp với Fe^3+^, không có kim loại mới, nên là **ăn mòn hoá học**. Giai đoạn 2: Cu sinh ra bám lên Fe, tạo cặp điện cực Fe – Cu tiếp xúc trong dung dịch điện li, nên có thêm **ăn mòn điện hoá** (Fe là anode).

> [!bay]
> - Nếu dung dịch chỉ có CuSO~4~, thanh sắt **tăng** 0,05 · 8 = 0,4 g. Có thêm Fe^3+^ thì thanh lại **giảm**, vì Fe tan ra ở giai đoạn 1 mà không có gì bám vào. Đừng mặc định "Fe + muối đồng thì thanh tăng".
> - Cu sinh ra nếu gặp Fe^3+^ còn dư sẽ bị hoà tan lại (Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^). Vì vậy Cu chỉ bám bền khi Fe^3+^ đã hết. Kết quả cuối cùng vẫn như trên vì Fe dư.

### 5.3. Từ quặng đến khung thép (Bài 20 + Bài 21 + Bài 22)

> [!vi-du] Ví dụ 3 (vận dụng, bối cảnh thực tế)
> Một nhà máy luyện gang từ quặng hematite chứa 80% Fe~2~O~3~ (về khối lượng), hiệu suất cả quá trình 90%. Gang thu được chứa 96% Fe, còn lại coi là carbon. Sau đó toàn bộ gang được luyện thành thép chứa 0,5% C (chỉ carbon bị loại bỏ, sắt không hao hụt).
>
> a) Từ 1 tấn quặng thu được bao nhiêu tấn gang?
>
> b) Lượng gang đó cho bao nhiêu tấn thép? Bao nhiêu kilogam carbon đã bị loại bỏ?
>
> c) Thép này được làm khung cửa ngoài trời gần biển. Đề xuất hai cách chống gỉ thuộc hai phương pháp khác nhau và giải thích.

> [!goi-y] Gợi ý 1
> Trong 160 g Fe~2~O~3~ có 112 g Fe. Đi từ quặng sang sắt thì nhân hiệu suất.

> [!goi-y] Gợi ý 2
> Sắt "đi xuyên" từ gang sang thép mà không đổi khối lượng. Dùng m(Fe) để tính cả gang lẫn thép.

> [!goi-y] Gợi ý 3
> Câu c: nhớ hai phương pháp trong SGK là phủ bề mặt và điện hoá. Gần biển là môi trường có dung dịch điện li gì?

> [!loi-giai] Lời giải
> a) m(Fe) = 1 · 0,80 · 112 : 160 · 0,90 = 0,504 tấn.
>
> m(gang) = 0,504 : 0,96 = **0,525 tấn**.
>
> b) m(thép) = 0,504 : 0,995 ≈ **0,507 tấn**.
>
> m(C bị loại) = 0,525 − 0,5065 ≈ 0,0185 tấn ≈ **18,5 kg**.
>
> c) Gần biển, không khí ẩm có muối, thép (Fe – C) bị **ăn mòn điện hoá** rất nhanh.
>
> - **Phủ bề mặt**: sơn chống gỉ rồi sơn phủ, hoặc mạ kẽm. Lớp phủ cách li thép với hơi nước và O~2~.
> - **Điện hoá**: nối khung với một khối kim loại mạnh hơn sắt như Zn (chôn trong đất ẩm cạnh chân khung). Zn là anode, bị ăn mòn thay. (Với khung cửa, cách phủ bề mặt thực tế và rẻ hơn. Cách điện hoá hợp với kết cấu chìm trong nước, đất như vỏ tàu, chân cầu cảng.)
>
> Mạ kẽm (tôn hoá) còn có thêm lợi thế: khi bị xước, Zn mạnh hơn Fe nên vẫn bảo vệ thép theo kiểu điện hoá.

### 5.4. Đúng/Sai: bốn chiếc đinh trong nước muối (Bài 21 + Bài 22)

> [!vi-du] Ví dụ 4 (Đúng/Sai)
> Bốn chiếc đinh thép giống nhau được xử lí như sau rồi cùng ngâm trong dung dịch NaCl loãng ở bốn cốc riêng, để vài ngày:
>
> (1) để nguyên; (2) quấn chặt dây đồng; (3) quấn chặt dây kẽm; (4) sơn kín toàn bộ.
>
> Xét các phát biểu:
>
> a) Đinh ở cốc (2) gỉ nhiều hơn đinh ở cốc (1).
>
> b) Ở cốc (3), kẽm bị oxi hoá, còn đinh thép đóng vai trò cathode.
>
> c) Ở cốc (1), đinh chỉ bị ăn mòn hoá học vì chỉ có một kim loại.
>
> d) Đinh ở cốc (3) và cốc (4) được bảo vệ theo cùng một phương pháp.

> [!goi-y] Gợi ý 1
> Thép là hợp kim của sắt với chất gì? Soát ba điều kiện ăn mòn điện hoá cho cốc (1).

> [!goi-y] Gợi ý 2
> So E°: Zn < Fe < Cu. Kim loại nào là anode trong từng cặp?

> [!loi-giai] Lời giải
> a) **Đúng.** Fe – Cu tạo pin, Fe (E° nhỏ hơn) là anode, bị ăn mòn nhanh hơn so với khi đứng một mình.
>
> b) **Đúng.** Zn có E° nhỏ hơn Fe nên Zn là anode bị oxi hoá, đinh là cathode, được bảo vệ.
>
> c) **Sai.** Thép là hợp kim Fe – C. Fe và C là hai điện cực khác nhau, tiếp xúc nhau, cùng trong dung dịch NaCl, nên đinh bị **ăn mòn điện hoá** (Bài 21 + Bài 22).
>
> d) **Sai.** Cốc (3) là phương pháp **điện hoá** (kim loại hi sinh). Cốc (4) là phương pháp **phủ bề mặt**.

## 6. Đối chiếu bài tập SGK (tr. 107)

**Câu 1 (đếm phát biểu đúng về cấu tạo).** Mỗi phát biểu ứng với một ý của Bài 18. Bẫy nằm ở các từ "tất cả", "các… đều". Hãy soát từng phát biểu với Bài 18 (mục 1 và 3) và bảng ở mục 1.2 bài này. Đặc biệt, so sánh bán kính trong **cùng chu kì**: kim loại đứng đầu chu kì nên bán kính **lớn hơn** phi kim. Làm thử Ví dụ 5.

> [!vi-du] Ví dụ 5 (tương tự Câu 1)
> Cho các phát biểu sau:
>
> (1) Trong tinh thể kim loại, các electron hoá trị chuyển động tự do trong toàn mạng.
>
> (2) Nguyên tử của mọi nguyên tố có 1 electron ở lớp ngoài cùng đều là kim loại.
>
> (3) Trong cùng một chu kì, kim loại có độ âm điện nhỏ hơn phi kim.
>
> (4) Các nguyên tố thuộc khối d đều là kim loại.
>
> (5) Liên kết kim loại hình thành do sự dùng chung từng cặp electron giữa hai nguyên tử cạnh nhau.
>
> Có bao nhiêu phát biểu đúng?

> [!goi-y] Gợi ý 1
> Phát biểu (2): nghĩ đến nguyên tố đứng đầu bảng tuần hoàn.

> [!goi-y] Gợi ý 2
> Phát biểu (5) mô tả liên kết gì? Electron trong liên kết kim loại thuộc về hai nguyên tử hay cả mạng?

> [!loi-giai] Lời giải
> (1) Đúng. (3) Đúng. (4) Đúng.
>
> (2) Sai: H có 1 electron lớp ngoài cùng nhưng là phi kim.
>
> (5) Sai: đó là liên kết cộng hoá trị. Liên kết kim loại là lực hút giữa ion dương và electron tự do **chung của cả mạng**.
>
> Có **3** phát biểu đúng.

**Câu 2 và Câu 3 (kim loại nào phản ứng).** Cả hai câu chỉ là "so vị trí trên dãy E°" (Hình 2). Câu 2: kim loại có E° > 0 không phản ứng với HCl. Câu 3: thanh kim loại M phản ứng với dung dịch muối của X khi E°(M) < E°(X). Đừng quên các phương án "kim loại yếu nhúng vào muối của kim loại mạnh" luôn sai.

> [!vi-du] Ví dụ 6 (tương tự Câu 2, Câu 3)
> Cho E° (V): Zn^2+^/Zn −0,762 · Ni^2+^/Ni −0,257 · Pb^2+^/Pb −0,126 · 2H^+^/H~2~ 0 · Cu^2+^/Cu +0,340 · Ag^+^/Ag +0,799.
>
> a) Trong các kim loại Zn, Ni, Pb, Cu, Ag, kim loại nào không phản ứng với dung dịch H~2~SO~4~ loãng?
>
> b) Thí nghiệm nào sau đây có phản ứng: (1) thanh Pb vào dung dịch NiSO~4~; (2) thanh Ni vào dung dịch Cu(NO~3~)~2~; (3) thanh Cu vào dung dịch Zn(NO~3~)~2~; (4) thanh Zn vào dung dịch Pb(NO~3~)~2~?

> [!goi-y] Gợi ý 1
> a) So với 0 V. b) Kim loại của thanh phải có E° **nhỏ hơn** E° của ion trong dung dịch.

> [!loi-giai] Lời giải
> a) Cu (+0,340) và Ag (+0,799) có E° > 0: **Cu, Ag** không phản ứng.
>
> b) (1) Pb (−0,126) > Ni (−0,257): **không**. (2) Ni (−0,257) < Cu (+0,340): **có**, Ni + Cu^2+^ → Ni^2+^ + Cu. (3) Cu > Zn: **không**. (4) Zn (−0,762) < Pb (−0,126): **có**, Zn + Pb^2+^ → Zn^2+^ + Pb.
>
> Có phản ứng: **(2) và (4)**.

**Câu 4 (sắp xếp cặp oxi hoá – khử từ phản ứng).** Mỗi phản ứng xảy ra cho em **một bất đẳng thức**: E°(cặp chứa chất khử phản ứng) < E°(cặp chứa chất oxi hoá phản ứng). Ghép các bất đẳng thức lại thành một dãy. Cẩn thận Fe^2+^ xuất hiện ở hai cặp khác nhau: Fe^2+^/Fe (Fe^2+^ là dạng oxi hoá) và Fe^3+^/Fe^2+^ (Fe^2+^ là dạng khử).

> [!vi-du] Ví dụ 7 (tương tự Câu 4)
> Cho các phản ứng xảy ra được:
>
> => Ni + Cu^2+^ → Ni^2+^ + Cu
>
> => Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^
>
> => Fe^2+^ + Ag^+^ → Fe^3+^ + Ag
>
> Sắp xếp các cặp Ni^2+^/Ni, Cu^2+^/Cu, Fe^3+^/Fe^2+^, Ag^+^/Ag theo chiều tăng dần thế điện cực chuẩn.

> [!goi-y] Gợi ý 1
> Phản ứng 1: chất khử Ni, chất oxi hoá Cu^2+^ → E°(Ni^2+^/Ni) < E°(Cu^2+^/Cu). Làm tương tự với hai phản ứng còn lại.

> [!loi-giai] Lời giải
> Phản ứng 1: E°(Ni^2+^/Ni) < E°(Cu^2+^/Cu).
>
> Phản ứng 2: chất khử Cu, chất oxi hoá Fe^3+^ → E°(Cu^2+^/Cu) < E°(Fe^3+^/Fe^2+^).
>
> Phản ứng 3: chất khử Fe^2+^ (thuộc cặp Fe^3+^/Fe^2+^), chất oxi hoá Ag^+^ → E°(Fe^3+^/Fe^2+^) < E°(Ag^+^/Ag).
>
> Dãy tăng dần: **Ni^2+^/Ni < Cu^2+^/Cu < Fe^3+^/Fe^2+^ < Ag^+^/Ag**. Khớp với bảng: −0,257 < +0,340 < +0,771 < +0,799.

**Câu 5 (hai thanh kẽm trong HCl, một cốc thêm CuSO~4~).** Đây chính là Dạng 3 của Bài 22. Cốc không có CuSO~4~: chỉ một kim loại, **ăn mòn hoá học**. Cốc có CuSO~4~: Zn đẩy Cu ra, Cu bám lên Zn, tạo pin Zn – Cu trong dung dịch acid, nên có thêm **ăn mòn điện hoá**, khí thoát ra nhanh hơn và chủ yếu trên bề mặt Cu. Ví dụ 8 đổi kim loại để em kiểm tra mình đã hiểu bản chất hay chỉ nhớ đáp án.

> [!vi-du] Ví dụ 8 (tương tự Câu 5)
> Hai đinh sắt nhỏ, **tinh khiết**, giống nhau được cho vào hai ống nghiệm chứa cùng một lượng dung dịch H~2~SO~4~ loãng. Nhỏ thêm vài giọt dung dịch CuSO~4~ vào ống (2).
>
> a) Ở mỗi ống xảy ra dạng ăn mòn nào?
>
> b) Ở ống (2), khí thoát ra nhanh hơn hay chậm hơn? Khí thoát ra chủ yếu ở đâu? Viết quá trình ở mỗi điện cực.

> [!goi-y] Gợi ý 1
> Ống (2): Fe có đẩy được Cu ra không? Cu sinh ra nằm ở đâu?

> [!loi-giai] Lời giải
> a) Ống (1): chỉ có Fe tinh khiết với acid, **ăn mòn hoá học**: Fe + 2H^+^ → Fe^2+^ + H~2~.
>
> Ống (2): trước hết Fe + Cu^2+^ → Fe^2+^ + Cu, Cu bám lên đinh. Fe và Cu tiếp xúc, cùng trong dung dịch acid, tạo pin: **ăn mòn điện hoá** (cùng với ăn mòn hoá học).
>
> b) Khí thoát ra **nhanh hơn**, chủ yếu trên bề mặt **Cu**.
>
> Anode (Fe): Fe → Fe^2+^ + 2e. Cathode (Cu): 2H^+^ + 2e → H~2~.
>
> Lí do nhanh hơn: H^+^ nhận electron ở bề mặt Cu, nên bọt H~2~ không bám che bề mặt Fe, Fe tiếp tục tan dễ dàng.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Cấu tạo | thường 1–3 e lớp ngoài; tinh thể: ion dương ở nút mạng + electron tự do |
| Liên kết kim loại | lực hút tĩnh điện giữa electron tự do và ion dương |
| Tính chất vật lí chung | dẻo, dẫn điện, dẫn nhiệt, ánh kim, đều do electron tự do |
| Tính chất hoá học | tính khử: M → M^n+^ + ne; với phi kim, nước, acid, muối |
| Fe với các chất oxi hoá | Cl~2~ → FeCl~3~; S → FeS; HCl → FeCl~2~; H~2~SO~4~ đặc nóng dư → Fe^3+^; H~2~SO~4~ đặc nguội: thụ động |
| Trong tự nhiên | hầu hết ở dạng hợp chất; Au, Ag, Pt có dạng đơn chất |
| Nguyên tắc tách | M^n+^ + ne → M |
| Phương pháp tách | mạnh (K → Al): điện phân nóng chảy; trung bình, yếu: nhiệt luyện, điện phân dung dịch, thuỷ luyện |
| Hợp kim | hoá học như thành phần; cứng hơn, kém dẻo, dẫn điện kém hơn |
| Gang / thép / inox / duralumin | Fe + 2–4% C / Fe + dưới 2% C / Fe + ≥ 10% Cr / Al + khoảng 4% Cu |
| Ăn mòn hoá học | electron đi thẳng sang chất oxi hoá; không có dòng điện |
| Ăn mòn điện hoá | hai điện cực khác nhau, tiếp xúc, cùng trong dung dịch điện li; E° nhỏ là anode, bị ăn mòn |
| Chống ăn mòn | điện hoá: gắn kim loại mạnh hơn (Zn, Mg); phủ bề mặt: sơn, dầu mỡ, mạ, tráng |

**Ba bước giải mọi bài của chương:**

1. **Tìm chất khử và chất oxi hoá:** kim loại nào nhường electron, chất nào nhận (O~2~, Cl~2~, H^+^, S^+6^, ion kim loại, C hay CO khi tách)?
2. **Tra dãy E° (Hình 2):** phản ứng có xảy ra không, xảy ra theo thứ tự nào, kim loại nào là anode, phương pháp tách nào phù hợp.
3. **Tính theo bảo toàn:** bảo toàn electron, bảo toàn nguyên tố O khi khử oxide, khối lượng sắt không đổi khi luyện thép, Δm của thanh kim loại.
