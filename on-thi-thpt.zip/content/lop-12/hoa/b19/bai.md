---
title: Tính chất vật lí và tính chất hoá học của kim loại
thoi-gian: 50 phút
muc-tieu:
  - Giải thích được các tính chất vật lí chung của kim loại (tính dẻo, dẫn điện, dẫn nhiệt, ánh kim) bằng sự có mặt của electron tự do trong tinh thể.
  - Nêu được ứng dụng của kim loại dựa vào tính chất vật lí chung và một số tính chất riêng (khối lượng riêng, nhiệt độ nóng chảy, độ cứng).
  - Hiểu tính chất hoá học chung của kim loại là tính khử. Viết được phương trình phản ứng của kim loại với phi kim (oxygen, chlorine, sulfur).
  - Dùng bảng thế điện cực chuẩn (kể cả cặp 2H~2~O/H~2~ + 2OH^−^ và 2H^+^/H~2~) để giải thích khi nào kim loại phản ứng với nước, với dung dịch HCl, H~2~SO~4~ loãng, H~2~SO~4~ đặc và với dung dịch muối.
  - Mô tả và giải thích các thí nghiệm SGK. Giải được bài toán kim loại + acid (bảo toàn electron, khối lượng muối) và kim loại + dung dịch muối (tăng giảm khối lượng thanh kim loại, thứ tự phản ứng).
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Ở điều kiện thường, kim loại đều ở thể rắn (trừ Hg), có **tính dẻo, dẫn điện, dẫn nhiệt, ánh kim**. Cả bốn tính chất đều do **electron tự do** trong tinh thể (Bài 18).
> 2. Tính chất riêng khác nhau rất xa: nhẹ nhất **Li**, nặng nhất **Os**; khó nóng chảy nhất **W**, lỏng ở nhiệt độ thường **Hg**; cứng nhất **Cr**, mềm nhất là các **kim loại kiềm**.
> 3. Tính chất hoá học chung là **tính khử**: M → M^n+^ + ne. Kim loại có E° càng nhỏ thì khử càng mạnh (Bài 15).
> 4. Phản ứng với phi kim (O~2~, Cl~2~, S); với nước (kim loại nhóm IA, IIA mạnh); với HCl, H~2~SO~4~ loãng nếu **E° < 0** (tạo H~2~, Fe chỉ lên Fe^2+^); với H~2~SO~4~ đặc (trừ Au, Pt) tạo **SO~2~**, không tạo H~2~; Al, Fe, Cr bị **thụ động** trong H~2~SO~4~ đặc nguội, HNO~3~ đặc nguội.
> 5. Kim loại mạnh hơn đẩy kim loại yếu hơn ra khỏi dung dịch muối. Bài toán: **bảo toàn electron**, m(muối) = m(kim loại) + m(gốc acid), thanh kim loại **tăng/giảm** khối lượng = m(bám vào) − m(tan ra).

Vì sao dây điện làm bằng đồng, nồi làm bằng nhôm, còn bóng đèn sợi đốt lại dùng dây tungsten? Vì sao thép gỉ nhanh trong nước mưa có acid, còn đồ đồng thì bền? Bài này trả lời các câu hỏi đó bằng hai "chìa khoá" đã học: **electron tự do** (Bài 18) và **thế điện cực chuẩn** (Bài 15).

## 1. Tính chất vật lí

Ở điều kiện thường, các kim loại đều có **tính dẻo, dẫn điện, dẫn nhiệt và có ánh kim**. Đây là các **tính chất vật lí chung**.

> [!nen-tang] Nhắc lại tinh thể kim loại (Bài 18)
> - Trong tinh thể kim loại, các **ion dương** nằm ở nút mạng.
> - Các **electron hoá trị** tách khỏi nguyên tử, chuyển động tự do khắp tinh thể (gọi là electron tự do).
> - **Liên kết kim loại** là lực hút tĩnh điện giữa các ion dương và các electron tự do.

Hãy giữ hình ảnh "các viên bi dương ngâm trong biển electron" trong đầu. Cả bốn tính chất chung dưới đây đều giải thích bằng hình ảnh này.

### 1.1. Tính dẻo

Kim loại **dễ rèn, dễ dát mỏng, dễ kéo sợi**. Phi kim rắn (như lưu huỳnh) và hợp chất ion (như muối ăn) thì ngược lại: gõ mạnh là vỡ vụn.

**Vì sao?** Khi có lực tác động (rèn, cán, kéo), các lớp ion dương trong mạng tinh thể **trượt lên nhau**. Các electron tự do vẫn len vào giữa và tiếp tục hút các ion, nên các lớp **trượt mà không tách rời** (SGK tr. 89, Hình 19.1). Kim loại chỉ đổi hình dạng, không vỡ.

Với tinh thể ion thì khác. Khi một lớp trượt đi, ion dương đối diện ion dương, ion âm đối diện ion âm. Các ion cùng dấu **đẩy nhau**, tinh thể nứt vỡ.

![Hình 1. Khi bị lực tác động, các lớp ion trong kim loại trượt lên nhau nhưng vẫn được biển electron giữ lại (trái). Trong tinh thể ion, sau khi trượt các ion cùng dấu đối diện nhau và đẩy nhau, tinh thể vỡ (phải)](tinh-deo.svg)

Những kim loại dẻo nhất là **Au, Ag, Al, Cu, Sn**. Vàng có thể dát thành lá mỏng khoảng **8 nm**, mỏng đến mức ánh sáng xuyên qua được.

> [!ung-dung] Tính dẻo trong đời sống
> Nhờ tính dẻo, kim loại được uốn cong, ép khuôn, kéo thành sợi theo đủ hình dạng: dây đồng, giấy nhôm (giấy bạc) gói thực phẩm, vỏ lon nước ngọt, lá vàng dùng thếp tượng, câu đối.

> [!vi-du] Ví dụ 1
> Một nghệ nhân dát 1,0 g vàng thành lá vàng dày đều 8 nm. Cho khối lượng riêng của vàng là 19,3 g/cm^3^ (số liệu ngoài SGK). Lá vàng thu được có diện tích khoảng bao nhiêu mét vuông?

> [!goi-y] Gợi ý 1
> Tính thể tích vàng từ khối lượng và khối lượng riêng: V = m : D.

> [!goi-y] Gợi ý 2
> Lá vàng là một "hình hộp rất dẹt": V = diện tích × độ dày. Đổi hết sang mét: 1 cm^3^ = 10^−6^ m^3^, 1 nm = 10^−9^ m.

> [!loi-giai] Lời giải
> V = 1,0 : 19,3 ≈ 0,0518 cm^3^ = 5,18 · 10^−8^ m^3^.
>
> Diện tích S = V : độ dày = 5,18 · 10^−8^ : (8 · 10^−9^) ≈ **6,5 m^2^**.
>
> Chỉ 1 gam vàng (nhỏ hơn một hạt đậu) mà phủ được một mặt sàn rộng 6,5 m^2^. Đó là sức mạnh của tính dẻo.

### 1.2. Tính dẫn điện

**Tất cả** kim loại đều dẫn điện.

**Vì sao?** Khi chưa có điện, các electron tự do chuyển động hỗn loạn theo mọi hướng. Khi nối hai đầu thanh kim loại với nguồn điện, các electron tự do bị cực dương hút và cực âm đẩy. Chúng **chuyển dời có hướng từ cực âm sang cực dương**. Dòng chuyển dời có hướng của hạt mang điện chính là dòng điện.

![Hình 2. Khi có hiệu điện thế, các electron tự do (chấm xanh) chuyển dời có hướng từ cực âm sang cực dương. Các ion dương (vòng cam) chỉ dao động quanh nút mạng](dan-dien.svg)

**Vì sao hầu hết phi kim không dẫn điện?** Trong phi kim, electron hoá trị bị giữ trong các **liên kết cộng hoá trị** giữa từng cặp nguyên tử (cặp electron dùng chung). Không có electron "của chung" để chạy thành dòng.

Thứ tự dẫn điện tốt: **Ag > Cu > Au > Al** > … Bạc dẫn điện tốt nhất nhưng đắt, nên dây dẫn điện thường làm bằng **đồng** và **nhôm**. Đồng dùng cho dây trong nhà, cuộn dây máy điện. Nhôm nhẹ, rẻ, dùng cho đường dây tải điện cao thế.

> [!em-co-biet] Nóng lên thì dẫn điện kém đi (mở rộng)
> Khi nhiệt độ tăng, các ion dương dao động mạnh hơn quanh nút mạng, cản đường electron nhiều hơn. Vì vậy kim loại nóng lên thì **dẫn điện kém đi**. Đây là lí do dây dẫn quá tải vừa nóng vừa hao điện nhiều hơn.

### 1.3. Tính dẫn nhiệt

**Vì sao?** Khi đốt nóng một đầu thanh kim loại, các electron tự do ở đầu đó nhận nhiệt, **chuyển động nhanh hơn** (động năng tăng). Chúng chạy khắp thanh, **va chạm** với các ion dương ở nút mạng và các electron khác, truyền bớt động năng cho chúng. Nhờ vậy nhiệt lan nhanh ra toàn bộ thanh.

Electron tự do vừa mang điện vừa mang nhiệt, nên **kim loại dẫn điện tốt thường dẫn nhiệt tốt** (Ag, Cu, Al đứng đầu cả hai bảng).

> [!ung-dung] Tính dẫn nhiệt trong đời sống
> - Xoong, nồi, chảo làm bằng nhôm, inox (hợp kim của sắt), đáy nồi cao cấp có lớp đồng để nhiệt truyền đều.
> - Tấm tản nhiệt của máy tính, két nước ô tô làm bằng nhôm hoặc đồng.
> - Ngược lại, quai nồi làm bằng nhựa, gỗ (dẫn nhiệt kém) để cầm không bị bỏng.

### 1.4. Tính ánh kim

**Vì sao?** Các electron tự do **phản xạ hầu hết các tia sáng nhìn thấy** chiếu tới bề mặt. Vì vậy kim loại có vẻ sáng lấp lánh, gọi là **ánh kim**.

Nhiều vật bằng kim loại trông xỉn, không có ánh kim. Đó là vì bề mặt bị phủ một lớp **oxide** hoặc gỉ: sắt có lớp gỉ sắt, nhôm có lớp aluminium oxide. Cạo lớp này đi sẽ thấy ánh kim. Ở dạng **bột mịn**, đa số kim loại có màu xám hoặc đen, vì ánh sáng bị tán xạ và hấp thụ giữa các hạt nhỏ.

> [!ung-dung] Tính ánh kim trong đời sống
> Vàng, bạc, bạch kim làm đồ trang sức. Bạc hoặc nhôm tráng mặt sau kính để làm gương. Lớp mạ chromium sáng bóng trên tay nắm cửa, vòi nước.

> [!bay]
> - "Kim loại dẫn điện tốt nhất là đồng": **sai**. Bạc dẫn điện tốt nhất. Đồng phổ biến hơn vì rẻ hơn nhiều.
> - "Các tính chất vật lí chung là do ion dương kim loại gây ra": **sai**. Nguyên nhân chính là **electron tự do**.

> [!vi-du] Ví dụ 2
> Mỗi ứng dụng sau dựa chủ yếu vào tính chất vật lí nào của kim loại?
>
> a) Kéo đồng thành sợi dây rất mảnh.
>
> b) Dùng dây đồng bọc nhựa để dẫn điện trong nhà.
>
> c) Làm chảo bằng nhôm.
>
> d) Phủ một lớp nhôm mỏng lên mặt sau tấm kính để làm gương.

> [!goi-y] Gợi ý 1
> Bốn tính chất chung: dẻo, dẫn điện, dẫn nhiệt, ánh kim. Mỗi câu ứng với đúng một tính chất "chính".

> [!goi-y] Gợi ý 2
> Gương cần bề mặt phản xạ ánh sáng tốt. Chảo cần truyền nhiệt từ bếp sang thức ăn.

> [!loi-giai] Lời giải
> a) **Tính dẻo** (kéo sợi). b) **Tính dẫn điện**. c) **Tính dẫn nhiệt**. d) **Tính ánh kim** (electron tự do phản xạ ánh sáng).

### 1.5. Một số tính chất vật lí riêng

Ngoài các tính chất chung, mỗi kim loại có những đặc điểm riêng. Ba tính chất SGK nêu (tr. 91):

| Tính chất | Thấp nhất | Cao nhất | Ghi chú |
|---|---|---|---|
| Khối lượng riêng D | **Li**: 0,534 g/cm^3^ | **Os**: 22,6 g/cm^3^ | D < 5 g/cm^3^: kim loại nhẹ. D ≥ 5 g/cm^3^: kim loại nặng |
| Nhiệt độ nóng chảy | **Hg**: −39 °C (lỏng ở điều kiện thường) | **W** (tungsten): 3 410 °C | Hg là kim loại duy nhất ở thể lỏng ở điều kiện thường |
| Độ cứng | Kim loại kiềm (K, Rb, Na, Cs): cắt được bằng dao | **Cr**: cắt được kính | |

**Vì sao các kim loại khác nhau nhiều như vậy?** Các tính chất riêng phụ thuộc vào **khối lượng nguyên tử, bán kính nguyên tử**, **độ bền liên kết kim loại** (số electron tự do, điện tích ion) và kiểu mạng tinh thể (phần giải thích này là mở rộng ngoài SGK). Ví dụ: kim loại kiềm chỉ có 1 electron hoá trị, bán kính lớn, nên liên kết kim loại yếu. Vì thế chúng mềm, nhẹ, nóng chảy ở nhiệt độ thấp. Tungsten và chromium có nhiều electron hoá trị tham gia liên kết, nên liên kết rất bền, cứng và khó nóng chảy.

> [!ung-dung] Chọn kim loại theo tính chất riêng
> - **Nhẹ** (Al, Mg, Ti và hợp kim): vỏ máy bay, khung xe đạp, vỏ điện thoại.
> - **Khó nóng chảy** (W): dây tóc bóng đèn sợi đốt, điện cực hàn hồ quang trong khí trơ, một số chi tiết phải chịu nhiệt độ rất cao.
> - **Cứng** (Cr): mạ lên dụng cụ, chi tiết máy để chống mài mòn. Thép chứa chromium làm dao cắt.
> - **Lỏng ở nhiệt độ thường** (Hg): trước đây dùng trong nhiệt kế, áp kế. Do hơi thuỷ ngân rất độc, nhiều nước đã hạn chế các dụng cụ này.

> [!vi-du] Ví dụ 3
> a) Một khối kim loại hình hộp có thể tích 20 cm^3^, nặng 54 g. Tính khối lượng riêng và cho biết đó là kim loại nhẹ hay nặng.
>
> b) Hai khối Os và Li có cùng thể tích. Khối Os nặng gấp bao nhiêu lần khối Li (làm tròn đến hàng đơn vị)?

> [!goi-y] Gợi ý 1
> D = m : V. So sánh với mốc 5 g/cm^3^.

> [!goi-y] Gợi ý 2
> Cùng thể tích thì tỉ lệ khối lượng bằng tỉ lệ khối lượng riêng.

> [!loi-giai] Lời giải
> a) D = 54 : 20 = **2,7 g/cm^3^** < 5 g/cm^3^ nên đây là **kim loại nhẹ** (đúng bằng D của nhôm).
>
> b) m(Os) : m(Li) = 22,6 : 0,534 ≈ **42 lần**.

## 2. Tính chất hoá học

Nguyên tử kim loại có ít electron hoá trị và giữ chúng lỏng lẻo (Bài 18), nên **dễ nhường electron**:

=> M → M^n+^ + ne

Vì vậy **tính chất hoá học chung của kim loại là tính khử**. Trong mọi phản ứng ở bài này, kim loại luôn là **chất khử**, số oxi hoá của kim loại **tăng** từ 0 lên +n.

Kim loại nào khử mạnh, kim loại nào khử yếu? Câu trả lời nằm trong **bảng thế điện cực chuẩn** (Bài 15): E°(M^n+^/M) càng nhỏ thì kim loại khử càng mạnh. Hình 3 tóm tắt cách dùng bảng này cho cả mục 2.

![Hình 3. Dùng trục thế điện cực chuẩn để dự đoán phản ứng của kim loại: E° nhỏ hơn −0,414 V có thể khử nước, E° nhỏ hơn 0 khử được H⁺ của HCl, H₂SO₄ loãng; kim loại đứng trước khử được ion kim loại đứng sau](truc-the-phan-ung.svg)

### 2.1. Tác dụng với phi kim

Hầu hết kim loại phản ứng với các phi kim điển hình như oxygen, chlorine, sulfur.

**Thí nghiệm** (SGK tr. 91, tóm tắt):

- **Mg cháy trong không khí**: kẹp dây Mg đốt trên đèn cồn. Mg cháy với **ngọn lửa sáng chói**, để lại bột **trắng** là MgO.
- **Al tác dụng với S**: trộn bột Al và bột S, cho vào ống nghiệm chịu nhiệt rồi đun. Hỗn hợp phản ứng mạnh, **toả nhiều nhiệt, phát sáng**, tạo chất rắn là Al~2~S~3~.

=> 2Mg + O~2~ → 2MgO    (t°)

=> 2Al + 3S → Al~2~S~3~    (t°)

**a) Với oxygen.** Hầu hết kim loại (**trừ Au, Ag, Pt**…) tác dụng với oxygen tạo oxide. Bột nhôm cháy mạnh trong không khí:

=> 4Al + 3O~2~ → 2Al~2~O~3~    (t°)

**b) Với chlorine.** Hầu hết kim loại tác dụng với khí chlorine khi đun nóng, tạo **muối chloride**. Dây sắt nóng đỏ cháy mạnh trong chlorine, tạo khói nâu đỏ chứa FeCl~3~:

=> 2Fe + 3Cl~2~ → 2FeCl~3~    (t°)

**c) Với sulfur (lưu huỳnh).** Nhiều kim loại khử được sulfur khi đun nóng. Riêng **thuỷ ngân phản ứng ngay ở nhiệt độ thường**:

=> Fe + S → FeS    (t°)

=> Hg + S → HgS

**Vì sao sắt cho FeCl~3~ nhưng chỉ cho FeS?** Chlorine là chất oxi hoá **mạnh**, kéo được sắt lên mức cao +3. Sulfur là chất oxi hoá **yếu** hơn nhiều, chỉ đưa sắt lên +2. Đây là điểm đề thi rất hay hỏi.

> [!ung-dung] Xử lí thuỷ ngân khi vỡ nhiệt kế
> Khi nhiệt kế thuỷ ngân bị vỡ, người ta rắc **bột lưu huỳnh** lên chỗ thuỷ ngân rơi vãi. Hg phản ứng với S ngay ở nhiệt độ thường tạo HgS rắn, không bay hơi, dễ thu gom. Nhờ vậy giảm được hơi thuỷ ngân độc trong phòng.

> [!bay]
> - Fe + Cl~2~ → **FeCl~3~** (không phải FeCl~2~). Fe + S → **FeS** (Fe hoá trị II). Fe + HCl → **FeCl~2~** (mục 2.3).
> - "Mọi kim loại đều tác dụng với oxygen": **sai**. Au, Ag, Pt không bị oxygen oxi hoá, nên vàng bạc giữ được vẻ sáng lâu.
> - Trong các phản ứng với phi kim, kim loại là **chất khử**, phi kim là chất oxi hoá.

> [!vi-du] Ví dụ 4
> Đốt cháy hoàn toàn 7,2 g kim loại M (hoá trị II) trong oxygen dư, thu được 12,0 g oxide.
>
> a) Xác định M.
>
> b) Nếu đốt 5,6 g sắt trong khí chlorine dư thì thu được bao nhiêu gam muối?

> [!goi-y] Gợi ý 1
> Khối lượng tăng lên chính là khối lượng oxygen đã kết hợp. Oxide của kim loại hoá trị II là MO, nên n(M) = n(O).

> [!goi-y] Gợi ý 2
> Câu b: sắt cháy trong chlorine tạo muối sắt hoá trị mấy?

> [!loi-giai] Lời giải
> a) m(O) = 12,0 − 7,2 = 4,8 g → n(O) = 4,8 : 16 = 0,3 mol = n(M).
>
> M = 7,2 : 0,3 = 24 → M là **magnesium (Mg)**.
>
> b) n(Fe) = 5,6 : 56 = 0,1 mol → n(FeCl~3~) = 0,1 mol.
>
> m(FeCl~3~) = 0,1 · 162,5 = **16,25 g**. (Nếu viết nhầm FeCl~2~ sẽ ra 12,7 g.)

### 2.2. Tác dụng với nước

Hầu hết kim loại **nhóm IA, IIA** có tính khử mạnh, tác dụng với nước ở nhiệt độ thường, giải phóng H~2~ và tạo dung dịch base:

=> 2Na + 2H~2~O → 2NaOH + H~2~

=> Ca + 2H~2~O → Ca(OH)~2~ + H~2~

**Dùng E° để giải thích.** Bảng thế điện cực chuẩn (SGK tr. 70) có cặp của nước:

=> 2H~2~O + 2e ⇌ H~2~ + 2OH^−^, E° = −0,414 V (pH = 7)

Theo quy tắc chiều phản ứng (Bài 15), kim loại có **E°(M^n+^/M) < −0,414 V** có thể khử nước, đẩy hydrogen ra khỏi nước.

**Lí thuyết và thực tế khác nhau ở đâu?** Trong bảng SGK, các kim loại từ Li đến Fe đều có E° nhỏ hơn −0,414 V. Nhưng ở nhiệt độ thường:

- Li, K, Ba, Ca, Na phản ứng rõ rệt với nước (Na, K phản ứng mãnh liệt).
- Mg phản ứng **rất chậm** với nước lạnh (nhanh hơn khi đun nóng).
- Al, Zn, Cr, Fe gần như không phản ứng, vì bề mặt bị phủ một lớp **oxide hoặc hydroxide không tan** ngăn kim loại tiếp xúc với nước.

Khi làm bài, câu "kim loại tác dụng với nước ở nhiệt độ thường" hiểu là **Li, Na, K, Ca, Ba** (và các kim loại kiềm, kiềm thổ tương tự như Rb, Cs, Sr).

> [!vi-du] Ví dụ 5
> Cho 4,6 g Na vào 100 g nước (dư). Tính thể tích khí H~2~ thoát ra ở điều kiện chuẩn (25 °C, 1 bar) và nồng độ phần trăm của dung dịch thu được (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Theo phương trình, 2 mol Na cho 2 mol NaOH và 1 mol H~2~. Ở điều kiện chuẩn, 1 mol khí chiếm 24,79 L.

> [!goi-y] Gợi ý 2
> Khối lượng dung dịch sau phản ứng = m(Na) + m(nước) − m(H~2~ bay ra).

> [!loi-giai] Lời giải
> n(Na) = 4,6 : 23 = 0,2 mol → n(NaOH) = 0,2 mol, n(H~2~) = 0,1 mol.
>
> V(H~2~) = 0,1 · 24,79 = **2,479 L**.
>
> m(dung dịch) = 4,6 + 100 − 0,1 · 2 = 104,4 g. m(NaOH) = 0,2 · 40 = 8 g.
>
> C% = 8 : 104,4 · 100% ≈ **7,66%**.

### 2.3. Tác dụng với dung dịch acid

**a) Với dung dịch HCl, H~2~SO~4~ loãng**

**Thí nghiệm** (SGK tr. 92, tóm tắt): cho vài hạt kẽm vào ống nghiệm rồi thêm khoảng 2 mL dung dịch H~2~SO~4~ 10%. Quan sát thấy **bọt khí** thoát ra trên bề mặt hạt kẽm, kẽm **tan dần**.

=> Zn + H~2~SO~4~ → ZnSO~4~ + H~2~

Bản chất của phản ứng là kim loại khử ion H^+^:

=> Zn + 2H^+^ → Zn^2+^ + H~2~

**Khi nào xảy ra?** So E° của kim loại với cặp 2H^+^/H~2~ (E° = 0). Ở điều kiện chuẩn, kim loại có **E°(M^n+^/M) < 0** (đứng **trước H** trong dãy điện hoá) mới khử được H^+^ thành H~2~.

**Vì sao Cu, Ag, Au không tan trong HCl, H~2~SO~4~ loãng?** Vì E°(Cu^2+^/Cu) = +0,340 V, E°(Ag^+^/Ag) = +0,799 V, E°(Au^3+^/Au) = +1,52 V đều **lớn hơn 0**. Các kim loại này là chất khử **yếu hơn** H~2~, nên không khử được H^+^ (SGK tr. 93, câu hỏi 7).

Sắt tan trong acid loãng chỉ tạo **muối sắt(II)**. Có thể ghi số oxi hoá để thấy rõ chất khử và chất oxi hoá:

=> Fe^0^ + H~2~^+1^SO~4~ → Fe^+2^SO~4~ + H~2~^0^

> [!ung-dung] Vì sao đồ thép nhanh hỏng trong môi trường acid, đồ đồng thì bền hơn?
> Sắt có E° = −0,44 V < 0 nên bị H^+^ trong mưa acid, nước thải, thực phẩm chua oxi hoá thành Fe^2+^. Đồng có E° = +0,340 V > 0 nên H^+^ không oxi hoá được đồng. Vì thế không nên đựng giấm, dưa muối lâu ngày trong nồi sắt, nồi nhôm.

**Công thức hay dùng** (kim loại + HCl hoặc H~2~SO~4~ loãng):

- Bảo toàn electron: tổng (số mol kim loại × hoá trị) = 2 · n(H~2~).
- Bảo toàn H: n(HCl) = 2 · n(H~2~); n(H~2~SO~4~) = n(H~2~).
- m(muối chloride) = m(kim loại) + 71 · n(H~2~).
- m(muối sulfate) = m(kim loại) + 96 · n(H~2~).

**Vì sao có 71 và 96?** Cứ 1 mol H~2~ bay ra thì có 2 mol H^+^ bị khử. Với HCl, 2 mol H^+^ đi kèm 2 mol Cl^−^ ở lại trong muối, nặng 2 · 35,5 = 71 g. Với H~2~SO~4~, 2 mol H^+^ đi kèm 1 mol SO~4~^2−^, nặng 96 g.

> [!vi-du] Ví dụ 6
> Hoà tan hoàn toàn 7,8 g hỗn hợp Mg và Al bằng dung dịch HCl dư, thu được 9,916 L khí H~2~ (điều kiện chuẩn). Tính khối lượng mỗi kim loại và khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> Đặt x = n(Mg), y = n(Al). Một phương trình theo khối lượng, một phương trình theo bảo toàn electron: Mg nhường 2e, Al nhường 3e.

> [!goi-y] Gợi ý 2
> Khối lượng muối: không cần viết từng phương trình, dùng m(muối) = m(kim loại) + 71 · n(H~2~).

> [!loi-giai] Lời giải
> n(H~2~) = 9,916 : 24,79 = 0,4 mol.
>
> Hệ: 24x + 27y = 7,8 và 2x + 3y = 2 · 0,4 = 0,8 → x = 0,1; y = 0,2.
>
> m(Mg) = 0,1 · 24 = **2,4 g**, m(Al) = 0,2 · 27 = **5,4 g**.
>
> m(muối) = 7,8 + 71 · 0,4 = **36,2 g** (kiểm tra: 0,1 · 95 + 0,2 · 133,5 = 36,2 g ✓).

**b) Với dung dịch H~2~SO~4~ đặc**

Trong H~2~SO~4~ đặc, chất oxi hoá không còn là H^+^ mà là **S^+6^** trong gốc SO~4~^2−^. S^+6^ oxi hoá mạnh hơn H^+^ rất nhiều, nên **hầu hết kim loại (trừ Pt, Au)**, kể cả Cu, Ag, đều bị oxi hoá. S^+6^ bị khử xuống số oxi hoá thấp hơn, thường là **SO~2~** (S^+4^). **Không tạo H~2~**.

=> Cu + 2H~2~SO~4~(đặc) → CuSO~4~ + SO~2~ + 2H~2~O    (t°)

Trong phản ứng này, Cu^0^ → Cu^+2^ (nhường 2e), S^+6^ → S^+4^ (nhận 2e). Một nửa lượng H~2~SO~4~ làm chất oxi hoá, nửa còn lại tạo muối.

**Sắt với H~2~SO~4~ đặc, nóng, dư** (mở rộng ngoài SGK, rất hay gặp trong đề): vì chất oxi hoá mạnh, sắt lên mức **+3**:

=> 2Fe + 6H~2~SO~4~(đặc) → Fe~2~(SO~4~)~3~ + 3SO~2~ + 6H~2~O    (t°)

> [!ghi-nho] Thụ động hoá
> **HNO~3~ đặc, nguội** và **H~2~SO~4~ đặc, nguội** làm **thụ động hoá Al, Fe, Cr**: một lớp oxide rất mỏng, bền tạo ra trên bề mặt, ngăn kim loại phản ứng tiếp. Vì vậy người ta chở H~2~SO~4~ đặc, HNO~3~ đặc bằng thùng sắt hoặc thùng nhôm.

**Tính nhanh** (kim loại + H~2~SO~4~ đặc tạo SO~2~): mỗi SO~2~ nhận 2e, nên bảo toàn electron giống hệt với H~2~ ở acid loãng, chỉ thay n(H~2~) bằng n(SO~2~). Cụ thể xem Dạng 1.

> [!em-co-biet] Kim loại với HNO~3~ (mở rộng ngoài SGK)
> SGK lớp 12 chỉ nêu HNO~3~ đặc, nguội làm thụ động Al, Fe, Cr. Ở lớp 11 em đã biết HNO~3~ cũng là chất oxi hoá mạnh: hầu hết kim loại (trừ Au, Pt) tan trong HNO~3~, N^+5^ bị khử thành NO~2~ (acid đặc) hoặc NO (acid loãng)…, **không tạo H~2~**. Bài toán cũng giải bằng bảo toàn electron như với H~2~SO~4~ đặc.

> [!bay]
> - Fe + HCl, H~2~SO~4~ loãng → **muối Fe(II)**. Fe + H~2~SO~4~ đặc, nóng, dư → **muối Fe(III)** (ngoài SGK).
> - Cu **không** tan trong HCl, H~2~SO~4~ loãng nhưng **tan** trong H~2~SO~4~ đặc, nóng.
> - Al, Fe, Cr **không tan** trong H~2~SO~4~ đặc, **nguội** (thụ động hoá), nhưng vẫn tan trong H~2~SO~4~ **loãng**.
> - Kim loại + H~2~SO~4~ đặc **không** sinh ra H~2~.

> [!vi-du] Ví dụ 7
> Đun nóng 6,4 g Cu với dung dịch H~2~SO~4~ đặc, dư. Tính thể tích khí SO~2~ (điều kiện chuẩn) và khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> Cu nhường 2e, S^+6^ nhận 2e để thành SO~2~. Vậy n(SO~2~) so với n(Cu) thế nào?

> [!goi-y] Gợi ý 2
> Muối duy nhất là CuSO~4~ (M = 160).

> [!loi-giai] Lời giải
> n(Cu) = 6,4 : 64 = 0,1 mol. Bảo toàn electron: 2 · 0,1 = 2 · n(SO~2~) → n(SO~2~) = 0,1 mol.
>
> V(SO~2~) = 0,1 · 24,79 = **2,479 L**. m(CuSO~4~) = 0,1 · 160 = **16 g**.

### 2.4. Tác dụng với dung dịch muối

**Kim loại hoạt động mạnh hơn** có thể đẩy **kim loại hoạt động yếu hơn** ra khỏi dung dịch muối của nó:

=> Cu + 2AgNO~3~ → Cu(NO~3~)~2~ + 2Ag

**Thí nghiệm** (SGK tr. 93, tóm tắt): thả một đinh sắt đã làm sạch dầu mỡ vào cốc chứa dung dịch CuSO~4~ 1 M. Sau khoảng 5 phút lấy đinh ra. Quan sát:

- Trên bề mặt đinh sắt có một lớp **kim loại màu đỏ** (Cu) bám vào.
- Màu **xanh** của dung dịch nhạt dần (ion Cu^2+^ giảm).

=> Fe + CuSO~4~ → FeSO~4~ + Cu

=> Fe + Cu^2+^ → Fe^2+^ + Cu

**Giải thích bằng E°:** E°(Fe^2+^/Fe) = −0,44 V < E°(Cu^2+^/Cu) = +0,340 V. Chất khử của cặp có E° nhỏ (Fe) phản ứng với chất oxi hoá của cặp có E° lớn (Cu^2+^), đúng quy tắc α (Bài 15). Phản ứng ngược lại (Cu + Fe^2+^) không xảy ra.

**Điều kiện** để kim loại M đẩy được kim loại X ra khỏi dung dịch muối:

- M đứng **trước** X trong dãy điện hoá (E° của M nhỏ hơn).
- M **không** phải kim loại tác dụng mạnh với nước (Na, K, Ca, Ba…). Các kim loại này phản ứng với **nước trước**, tạo base, rồi base mới phản ứng với muối.
- Muối của X phải tan trong nước.

> [!bay]
> - Na cho vào dung dịch CuSO~4~: 2Na + 2H~2~O → 2NaOH + H~2~, rồi 2NaOH + CuSO~4~ → Cu(OH)~2~↓ (xanh) + Na~2~SO~4~. **Không** có Cu.
> - Fe vào dung dịch muối Cu^2+^, Ag^+^ tạo **Fe^2+^** (không phải Fe^3+^) khi Fe còn dư.
> - Cu **có** phản ứng với dung dịch FeCl~3~ (Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^) nhưng không tạo ra Fe (xem Bài 15, mục 3.3).

**Thanh kim loại tăng hay giảm khối lượng?** Khi nhúng thanh M vào dung dịch muối, một phần M **tan ra**, kim loại X **bám vào** thanh. Vậy:

=> Δm(thanh) = m(X bám vào) − m(M tan ra)

Δm > 0: thanh tăng khối lượng. Δm < 0: thanh giảm khối lượng.

![Hình 4. Đinh sắt trong dung dịch CuSO₄: cứ 1 mol Fe (56 g) tan ra thì 1 mol Cu (64 g) bám vào, thanh nặng thêm 8 g](thanh-sat.svg)

> [!vi-du] Ví dụ 8
> Nhúng một thanh sắt vào dung dịch CuSO~4~. Sau một thời gian lấy thanh sắt ra, rửa nhẹ, làm khô, cân lại thấy khối lượng thanh tăng 1,2 g so với ban đầu. Giả sử toàn bộ Cu sinh ra bám vào thanh sắt. Tính khối lượng Cu đã bám vào và khối lượng Fe đã tan.

> [!goi-y] Gợi ý 1
> Gọi số mol Fe phản ứng là a. Theo phương trình, số mol Cu tạo thành cũng là a.

> [!goi-y] Gợi ý 2
> Δm = 64a − 56a = 8a.

> [!loi-giai] Lời giải
> 8a = 1,2 → a = 0,15 mol.
>
> m(Cu bám vào) = 0,15 · 64 = **9,6 g**. m(Fe tan) = 0,15 · 56 = **8,4 g**.

## Dạng bài thi hay gặp

### Dạng 1. Kim loại tác dụng với acid: bảo toàn electron, khối lượng muối

**Nhận biết:** đề cho kim loại (hoặc hỗn hợp) tác dụng với HCl, H~2~SO~4~ loãng (tạo H~2~) hoặc H~2~SO~4~ đặc (tạo SO~2~). Hỏi khối lượng kim loại, khối lượng muối, thể tích khí, hoặc tìm tên kim loại.

**Phương pháp:**

1. Xác định chất oxi hoá: H^+^ (acid loãng, tạo H~2~) hay S^+6^ (H~2~SO~4~ đặc, tạo SO~2~). Kim loại nào phản ứng, kim loại nào không (Cu với acid loãng, Al/Fe/Cr với acid đặc nguội).
2. Xác định hoá trị trong muối: Fe → **+2** với acid loãng, **+3** với H~2~SO~4~ đặc nóng dư (ngoài SGK).
3. Bảo toàn electron: Σ(n~KL~ × hoá trị) = 2n(H~2~) hoặc 2n(SO~2~). Khối lượng muối: m(kim loại phản ứng) + 71 hoặc 96 nhân số mol khí (mục 2.3).
4. Tìm kim loại chưa biết: n(M) = 2n(khí) : n, rồi M = m : n(M). Thử n = 1, 2, 3.

> [!vi-du] Ví dụ 9
> Hoà tan hoàn toàn 5,4 g kim loại M bằng dung dịch H~2~SO~4~ loãng, dư, thu được 7,437 L khí H~2~ (điều kiện chuẩn). Xác định M và tính khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> Chưa biết hoá trị thì gọi là n. Bảo toàn electron: n(M) · n = 2 · n(H~2~).

> [!goi-y] Gợi ý 2
> Lập M theo n, rồi thử n = 1, 2, 3 xem giá trị nào cho một kim loại có thật.

> [!loi-giai] Lời giải
> n(H~2~) = 7,437 : 24,79 = 0,3 mol → n(M) = 0,6 : n.
>
> M = 5,4 : (0,6 : n) = 9n. Với n = 3 thì M = 27: **M là Al**. (n = 1 cho 9, n = 2 cho 18, không có kim loại phù hợp.)
>
> m(muối) = 5,4 + 96 · 0,3 = **34,2 g** (đúng bằng 0,1 mol Al~2~(SO~4~)~3~ · 342).

> [!vi-du] Ví dụ 10 (vận dụng)
> Hỗn hợp X gồm Fe và Cu. Cho m gam X tác dụng với dung dịch H~2~SO~4~ loãng, dư, thu được 2,479 L H~2~. Cũng m gam X đó cho tác dụng với dung dịch H~2~SO~4~ đặc, nóng, dư, thu được 6,1975 L SO~2~ (sản phẩm khử duy nhất). Các thể tích đo ở điều kiện chuẩn. Tính m và khối lượng muối trong thí nghiệm thứ hai.

> [!goi-y] Gợi ý 1
> Với acid loãng, kim loại nào không phản ứng? Từ n(H~2~) suy ra ngay n(Fe).

> [!goi-y] Gợi ý 2
> Với H~2~SO~4~ đặc nóng, Fe nhường **3e**, Cu nhường 2e. Bảo toàn electron để tìm n(Cu).

> [!loi-giai] Lời giải
> Thí nghiệm 1: chỉ Fe phản ứng, Fe → Fe^2+^. n(Fe) = n(H~2~) = 2,479 : 24,79 = 0,1 mol.
>
> Thí nghiệm 2: n(SO~2~) = 6,1975 : 24,79 = 0,25 mol. Bảo toàn electron: 3 · 0,1 + 2 · n(Cu) = 2 · 0,25 → n(Cu) = 0,1 mol.
>
> m = 0,1 · 56 + 0,1 · 64 = **12 g**.
>
> m(muối) = 12 + 96 · 0,25 = **36 g** (gồm 0,05 mol Fe~2~(SO~4~)~3~ là 20 g và 0,1 mol CuSO~4~ là 16 g).

> [!bay]
> - Dùng 22,4 L/mol thay vì **24,79 L/mol** (điều kiện chuẩn theo SGK mới), trừ khi đề cho điều kiện khác.
> - Với H~2~SO~4~ đặc, **nguội**, phần Al, Fe, Cr trong hỗn hợp không phản ứng (bước 1).

### Dạng 2. Kim loại tác dụng với dung dịch muối: tăng giảm khối lượng, thứ tự phản ứng

**Nhận biết:** "nhúng thanh kim loại vào dung dịch muối… khối lượng thanh tăng/giảm", hoặc "cho bột kim loại vào dung dịch chứa hai muối… thu được chất rắn".

**Phương pháp:**

1. Thanh kim loại: gọi số mol kim loại tan là a, viết Δm theo a. Ví dụ: Fe + Cu^2+^ thì Δm = +8a. Zn + Cu^2+^ thì Δm = 64a − 65a = **−a** (thanh **giảm**). Cu + 2Ag^+^ thì Δm = 2 · 108a − 64a = +152a.
2. **Thứ tự phản ứng** (khi có nhiều ion hoặc nhiều kim loại): ion có **tính oxi hoá mạnh nhất** (E° lớn nhất) bị khử **trước**. Kim loại **khử mạnh nhất** phản ứng **trước**. Ví dụ dung dịch có Ag^+^ và Cu^2+^ thì Ag^+^ bị khử trước.
3. Lập bảng "phản ứng lần lượt" theo số mol, xem chất nào hết trước. Chất rắn sau phản ứng gồm kim loại bị đẩy ra và kim loại còn dư (nếu có).

> [!vi-du] Ví dụ 11
> Cho 2,4 g bột Mg vào 200 mL dung dịch chứa AgNO~3~ 0,25 M và Cu(NO~3~)~2~ 0,5 M. Sau khi các phản ứng xảy ra hoàn toàn, thu được m gam chất rắn. Tính m.

> [!goi-y] Gợi ý 1
> Tính số mol: Mg, Ag^+^, Cu^2+^. Ion nào có tính oxi hoá mạnh hơn sẽ phản ứng với Mg trước?

> [!goi-y] Gợi ý 2
> Mg + 2Ag^+^ → Mg^2+^ + 2Ag hết Ag^+^ trước. Mg còn lại bao nhiêu thì khử tiếp Cu^2+^. So sánh với lượng Cu^2+^ có trong dung dịch.

> [!loi-giai] Lời giải
> n(Mg) = 0,1 mol; n(Ag^+^) = 0,05 mol; n(Cu^2+^) = 0,1 mol.
>
> Lần 1: Mg + 2Ag^+^ → Mg^2+^ + 2Ag. Ag^+^ hết, dùng 0,025 mol Mg, tạo 0,05 mol Ag.
>
> Lần 2: Mg còn 0,075 mol. Mg + Cu^2+^ → Mg^2+^ + Cu. Cu^2+^ có 0,1 mol > 0,075 nên Mg hết, tạo 0,075 mol Cu.
>
> m = 0,05 · 108 + 0,075 · 64 = 5,4 + 4,8 = **10,2 g**.

> [!bay]
> - Đừng mặc định "có kim loại bám vào là thanh nặng lên": thanh Zn trong CuSO~4~ **giảm** khối lượng.
> - Công thức Δm chỉ đúng khi kim loại sinh ra bám hết vào thanh. Đề không nói thì phải đọc kĩ dữ kiện.

### Dạng 3. Đúng/Sai thí nghiệm, đếm số phản ứng xảy ra

**Nhận biết:** đề liệt kê nhiều thí nghiệm "cho kim loại X vào dung dịch Y", hỏi có bao nhiêu thí nghiệm xảy ra phản ứng (hoặc tạo kim loại, tạo khí). Hoặc mô tả một thí nghiệm SGK (đinh sắt trong CuSO~4~, Zn với H~2~SO~4~, Mg cháy…) rồi cho 4 ý Đúng/Sai.

**Phương pháp:** soát từng thí nghiệm theo bảng "Tính chất hoá học" ở phần Tóm tắt (hoặc Hình 3). Bốn chỗ hay bị gài:

1. Kim loại kiềm, kiềm thổ mạnh gặp dung dịch muối thì phản ứng với **nước** trước.
2. Al, Fe, Cr **không** phản ứng với H~2~SO~4~ đặc, **nguội**.
3. Cặp Fe^3+^/Fe^2+^ nằm **giữa** Cu và Ag: Cu khử được Fe^3+^, Ag thì không.
4. Hg + S xảy ra ngay ở nhiệt độ thường. Au, Ag, Pt không cháy trong oxygen.

> [!vi-du] Ví dụ 12
> Thực hiện các thí nghiệm sau ở nhiệt độ thường (trừ khi ghi đun nóng):
>
> (1) Cho Cu vào dung dịch HCl. (2) Cho Fe vào dung dịch CuSO~4~. (3) Cho Ag vào dung dịch FeCl~3~. (4) Cho Cu vào dung dịch FeCl~3~. (5) Cho Al vào dung dịch H~2~SO~4~ đặc, nguội. (6) Cho Zn vào dung dịch H~2~SO~4~ loãng. (7) Đốt dây Fe trong khí Cl~2~. (8) Rắc bột S lên Hg.
>
> Có bao nhiêu thí nghiệm xảy ra phản ứng hoá học?

> [!goi-y] Gợi ý 1
> Đi lần lượt theo danh sách kiểm tra. Với (3) và (4) cần so E°(Fe^3+^/Fe^2+^) = +0,771 V với E° của Ag và Cu.

> [!goi-y] Gợi ý 2
> (5) là trường hợp thụ động hoá. (8) là phản ứng đặc biệt của thuỷ ngân.

> [!loi-giai] Lời giải
> (1) Không: E°(Cu^2+^/Cu) > 0.
>
> (2) Có: Fe + Cu^2+^ → Fe^2+^ + Cu.
>
> (3) Không: E°(Ag^+^/Ag) = +0,799 V > +0,771 V.
>
> (4) Có: Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^.
>
> (5) Không: Al bị thụ động hoá.
>
> (6) Có: Zn + 2H^+^ → Zn^2+^ + H~2~.
>
> (7) Có: 2Fe + 3Cl~2~ → 2FeCl~3~.
>
> (8) Có: Hg + S → HgS.
>
> Có **5** thí nghiệm xảy ra phản ứng.

> [!vi-du] Ví dụ 13 (Đúng/Sai)
> Một học sinh thả đinh sắt đã làm sạch vào cốc đựng dung dịch CuSO~4~ 1 M, sau 5 phút lấy đinh ra. Xét các phát biểu:
>
> a) Trên đinh sắt có lớp kim loại màu đỏ bám vào.
>
> b) Màu xanh của dung dịch đậm dần lên.
>
> c) Trong phản ứng, Fe bị khử thành Fe^2+^.
>
> d) Nếu thay đinh sắt bằng mẩu Na thì cũng thu được Cu bám trên mẩu Na.

> [!goi-y] Gợi ý 1
> Màu xanh của dung dịch là do ion nào? Ion đó tăng hay giảm?

> [!goi-y] Gợi ý 2
> Fe nhường electron thì "bị oxi hoá" hay "bị khử"? Na gặp nước thì sao?

> [!loi-giai] Lời giải
> a) **Đúng**: Cu màu đỏ bám vào đinh.
>
> b) **Sai**: Cu^2+^ (màu xanh) bị khử dần, nên màu xanh **nhạt** dần.
>
> c) **Sai**: Fe nhường electron, là chất khử, **bị oxi hoá** thành Fe^2+^.
>
> d) **Sai**: Na phản ứng với nước trước, tạo NaOH, rồi tạo kết tủa Cu(OH)~2~ màu xanh. Không có Cu bám vào.

## Tóm tắt

**Tính chất vật lí**

| Tính chất | Nguyên nhân | Kim loại tiêu biểu, ứng dụng |
|---|---|---|
| Dẻo | Các lớp ion trượt lên nhau, electron tự do vẫn giữ chúng lại | Au, Ag, Al, Cu, Sn. Dây, lá, giấy nhôm |
| Dẫn điện | Electron tự do chuyển dời có hướng (cực âm → cực dương) | Ag > Cu > Au > Al. Dây điện Cu, Al |
| Dẫn nhiệt | Electron tự do truyền động năng qua va chạm | Nồi, chảo, tản nhiệt |
| Ánh kim | Electron tự do phản xạ ánh sáng nhìn thấy | Trang sức, gương |
| Khối lượng riêng | Khác nhau tuỳ kim loại | Nhẹ nhất Li (0,534), nặng nhất Os (22,6). Mốc 5 g/cm^3^ |
| Nhiệt độ nóng chảy | Khác nhau tuỳ kim loại | Thấp nhất Hg (−39 °C), cao nhất W (3 410 °C) |
| Độ cứng | Khác nhau tuỳ kim loại | Cứng nhất Cr, mềm nhất kim loại kiềm |

**Tính chất hoá học: tính khử, M → M^n+^ + ne**

| Tác nhân | Điều kiện | Sản phẩm, ví dụ |
|---|---|---|
| O~2~, Cl~2~, S | Hầu hết kim loại (Au, Ag, Pt không cháy trong O~2~) | 4Al + 3O~2~ → 2Al~2~O~3~. 2Fe + 3Cl~2~ → 2FeCl~3~. Fe + S → FeS. Hg + S → HgS (nhiệt độ thường) |
| H~2~O | E° < −0,414 V. Thực tế: Li, Na, K, Ca, Ba | 2Na + 2H~2~O → 2NaOH + H~2~ |
| HCl, H~2~SO~4~ loãng | E° < 0 (trước H) | Muối + H~2~. Fe → Fe^2+^ |
| H~2~SO~4~ đặc | Trừ Au, Pt. Al, Fe, Cr thụ động khi nguội | Muối + SO~2~ + H~2~O. Fe → Fe^3+^ (đặc, nóng, dư; ngoài SGK) |
| Dung dịch muối | Kim loại đứng trước ion đứng sau, không phải kim loại tan trong nước | Fe + CuSO~4~ → FeSO~4~ + Cu |

**Công thức tính nhanh**

- Bảo toàn electron: Σ(n~KL~ × hoá trị) = 2n(H~2~) = 2n(SO~2~).
- m(muối chloride) = m(KL) + 71n(H~2~).
- m(muối sulfate) = m(KL) + 96n(H~2~) hoặc m(KL) + 96n(SO~2~).
- Thanh kim loại: Δm = m(bám vào) − m(tan ra). Fe/Cu^2+^: +8 g mỗi mol Fe; Zn/Cu^2+^: −1 g mỗi mol Zn.
- Thứ tự: ion oxi hoá mạnh nhất phản ứng trước với kim loại khử mạnh nhất.
- Thể tích khí ở điều kiện chuẩn: V = n · 24,79 L.
