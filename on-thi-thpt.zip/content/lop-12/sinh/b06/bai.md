---
title: Thực hành: Tách chiết DNA
thoi-gian: 25 phút
muc-tieu:
  - Thực hành tách chiết được DNA từ mẫu vật sống (gan gà, gan lợn hoặc mô thực vật) bằng dụng cụ và hoá chất đơn giản.
  - Giải thích được nguyên lí của thí nghiệm: mỗi bước, mỗi hoá chất phá bỏ "lớp" nào bao quanh DNA và vì sao DNA kết tủa được trong cồn.
  - Biết cách chọn mẫu vật, nhận ra và khắc phục các lỗi thường gặp làm thí nghiệm thất bại.
  - Đọc, giải thích được kết quả thí nghiệm, dự đoán kết quả khi thay đổi một bước, và viết được báo cáo thực hành.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. DNA nằm sâu bên trong **mô → tế bào → nhân**, lại quấn quanh **protein**. Tách chiết DNA là lần lượt **bóc từng lớp** ấy rồi làm DNA **kết tủa** để nhìn thấy.
> 2. **Nghiền/xay** phá mô, tách rời tế bào. **Nước rửa bát** (chất tẩy rửa) hoà tan **lipid**, phá **màng tế bào và màng nhân**.
> 3. **Nước dứa tươi** chứa enzyme **protease**, cắt các **protein** (như histone) bám vào DNA thành amino acid, đoạn peptide nhỏ.
> 4. **Cồn ethanol lạnh** rót nhẹ theo thành ống tạo lớp trên. Ethanol "giành" nước mạnh hơn DNA nên DNA **kết tủa** thành sợi **trắng đục** ở lớp cồn. Quấn nhẹ bằng đũa để lấy ra.
> 5. Kết tủa **chủ yếu là DNA** (có lẫn RNA), nhận biết bằng **diphenylamine** khi đun nóng cho **màu xanh lam**. Nên dùng **mô động vật** (gan) vì giàu DNA, dễ nghiền.

> [!nen-tang] Nhớ lại Bài 1 và lớp 10
> - DNA là **đại phân tử** rất dài gồm hai mạch polynucleotide, "xương sống" **đường – phosphate** ở ngoài. Nhóm phosphate mang **điện tích âm**, làm DNA rất **ưa nước** (tan trong nước). Xem Bài 1, mục 1.1–1.3.
> - Ở tế bào nhân thực, DNA nằm trong **nhân**, quấn quanh các protein **histone** tạo thành nhiễm sắc thể (sẽ học kĩ ở Bài 7).
> - Màng tế bào và màng nhân đều có khung là **lớp kép phospholipid** (một loại lipid).
> - **Enzyme** là protein: hoạt động mạnh ở nhiệt độ thích hợp, bị **biến tính, mất hoạt tính** khi bị đun nóng.

Bài 5 (mục 4) đã cho em bảng tóm tắt "mỗi bước để làm gì". Bài này đi sâu hơn: **vì sao** mỗi hoá chất làm được việc của nó, chuyện gì xảy ra nếu **bỏ hoặc làm sai** một bước, và cách **đọc kết quả** như một người làm thí nghiệm thật.

## 1. Mục đích và ý tưởng chung

**Mục đích** (SGK tr. 32): tự tay tách được DNA từ mẫu vật sống và **nhìn thấy** DNA bằng mắt thường.

Nghe có vẻ lạ: một phân tử DNA chỉ rộng **2 nm**, kính hiển vi quang học cũng không thấy được. Bí quyết là ta không nhìn **một** phân tử, mà gom **hàng chục tỉ** phân tử DNA từ hàng trăm triệu tế bào lại, cho chúng **kết tụ** thành một khối. Giống như một sợi tơ nhện rất khó thấy, nhưng cả cuộn tơ thì nhìn rõ.

Muốn vậy, ta phải giải quyết ba việc:

| Việc cần làm | Trở ngại | Cách giải quyết |
|---|---|---|
| Đưa DNA ra khỏi tế bào | DNA bị "nhốt" trong mô, sau màng tế bào, sau màng nhân | Nghiền mẫu + chất tẩy rửa |
| Tách DNA khỏi protein | DNA quấn chặt quanh histone và nhiều protein khác | Enzyme protease (nước dứa) |
| Gom DNA lại để nhìn thấy | DNA tan đều trong nước, không thấy được | Cồn ethanol lạnh làm DNA kết tủa |

![Hình 1. Tách chiết DNA là bóc dần từng "lớp vỏ" bao quanh DNA](hinh-1-boc-tach.svg)

## 2. Chuẩn bị

### 2.1. Dụng cụ, hoá chất

| Nhóm | Cụ thể (theo SGK tr. 32) | Dùng để |
|---|---|---|
| Nghiền mẫu | Chày, cối sứ hoặc máy xay | Phá vỡ mô |
| Lọc | Giấy lọc, phễu lọc | Bỏ cặn, lấy dịch trong |
| Chứa, khuấy | Ống nghiệm thuỷ tinh, giá ống nghiệm, que tre hoặc đũa thuỷ tinh | Đựng dịch, khuấy nhẹ, quấn lấy DNA |
| Hoá chất | Nước rửa chén bát (chất tẩy rửa), dứa tươi, cồn ethanol **lạnh** 70–95% | Phá màng, cắt protein, kết tủa DNA |
| Mẫu vật | Gan gà, gan lợn, hoặc mô động vật, thực vật tươi bất kì | Nguồn DNA |

Tất cả đều là đồ dùng trong bếp, trừ cồn. Đó cũng là điều thú vị: tách DNA không cần máy móc đắt tiền.

### 2.2. Chọn mẫu vật — vì sao gan là lựa chọn tốt?

SGK khuyên dùng **gan gà hoặc gan lợn**. Lí do:

- **Giàu tế bào có nhân.** Mô gan gồm các tế bào xếp sát nhau, ít chất nền giữa các tế bào, nên mỗi gam gan chứa rất nhiều nhân, tức rất nhiều DNA.
- **Mềm, dễ nghiền.** Tế bào động vật không có thành tế bào, xay vài chục giây là nát.
- **Không có sắc tố gây nhiễu** như diệp lục.

Mô **thực vật** khó hơn vì:

- chứa **nhiều nước** (không bào lớn), nên cùng một khối lượng thì **ít DNA hơn**. SGK gợi ý dùng khoảng **50 g** mẫu thực vật so với khoảng **5 g** gan.
- có **thành cellulose** cứng, khó nghiền vỡ hơn.
- lá xanh có **diệp lục** và sắc tố khác, cần loại bỏ, nếu không kết tủa bị nhuộm màu, khó quan sát.

> [!bay] Mẫu vật "bẫy" trong đề
> - **Máu người, máu lợn, máu bò** (động vật có vú): hồng cầu trưởng thành **không có nhân**, nên phần lớn tế bào trong máu không có DNA. Lượng DNA chỉ đến từ bạch cầu, rất ít. Ngược lại, hồng cầu của **gà, vịt, cá, ếch** **có nhân**, nên máu gà vẫn tách được DNA.
> - "Mô nhiều nước, mọng" không có nghĩa là nhiều DNA. Lượng DNA phụ thuộc **số nhân tế bào** trong mẫu chứ không phụ thuộc độ mọng.

## 3. Nguyên lí — vì sao tách được DNA?

### 3.1. Phá mô, phá màng: giải phóng DNA

**Nghiền, xay** phá vỡ cấu trúc mô, làm các tế bào tách rời nhau và một phần tế bào bị vỡ. Diện tích tiếp xúc với hoá chất tăng lên rất nhiều.

**Chất tẩy rửa** (nước rửa bát) có phân tử gồm **đầu ưa nước** và **đuôi kị nước**, giống xà phòng (xem Hoá học 12, Bài 2). Đuôi kị nước "chui" vào lớp kép phospholipid, xé màng thành các hạt nhỏ hoà tan trong nước, giống hệt cách nước rửa bát làm tan váng mỡ trên đĩa. Kết quả: **màng tế bào và màng nhân bị phá**, mọi thứ trong nhân, gồm DNA, tràn ra **dịch chiết**.

### 3.2. Cắt protein: giải phóng DNA khỏi histone

Ra khỏi nhân rồi, DNA vẫn đang quấn chặt quanh **histone** và dính với nhiều protein khác (protein điều hoà, enzyme phiên mã…). Nếu để nguyên, khi kết tủa DNA sẽ kéo theo cả đống protein, thu được khối lợn cợn chứ không phải sợi DNA.

**Nước dứa tươi** chứa enzyme **protease** (tên riêng là bromelain). Protease cắt **liên kết peptide**, chia chuỗi polypeptide thành **amino acid và đoạn peptide nhỏ**. Các mảnh nhỏ này tan trong nước, không kết tủa theo DNA. Sau bước này, trong dịch chủ yếu còn lại các đại phân tử **DNA và RNA**.

> [!bay]
> Protease cắt **protein**, không cắt DNA. DNA vẫn nguyên là chuỗi dài. Đề hay cài: "nước dứa có enzyme cắt DNA thành các đoạn ngắn". Sai, enzyme cắt DNA là **nuclease** (hay DNase), và ta lại muốn **hạn chế** loại enzyme này.

### 3.3. Kết tủa DNA bằng cồn

Đây là bước "phép màu", cũng là chỗ đề thi hỏi nhiều nhất.

- **Vì sao DNA tan trong nước?** "Xương sống" phosphate mang điện âm, được các phân tử nước bao quanh, "ôm" lấy. Nhờ lớp vỏ nước đó, các sợi DNA tách rời nhau, phân tán đều, không nhìn thấy.
- **Ethanol làm gì?** Ethanol có **ái lực với nước mạnh hơn** DNA (SGK tr. 33). Khi gặp cồn, nước bị cồn "giành" đi, DNA mất lớp vỏ nước, các phân tử bị **đẩy sát lại gần nhau** và **kết tụ** thành khối **trắng đục**. DNA **không tan trong ethanol**.
- **Vì sao DNA ở lớp trên?** Ethanol **nhẹ hơn nước**, nên khi rót nhẹ nó nổi thành **lớp trong suốt** phía trên dịch chiết. DNA ở chỗ tiếp xúc giữa hai lớp gặp cồn thì kết tủa và **đi lên lớp cồn** (mở rộng: các bọt khí nhỏ mắc trong sợi DNA cũng giúp nó nổi).
- **Vì sao phải dùng cồn lạnh?** (SGK chỉ yêu cầu cồn lạnh, phần giải thích dưới đây là mở rộng.) Nhiệt độ thấp làm DNA **càng khó tan**, kết tủa nhanh và nhiều hơn. Lạnh còn làm **chậm hoạt động của enzyme nuclease** (enzyme phân giải DNA) có sẵn trong tế bào, giữ DNA ít bị cắt vụn.

![Hình 2. Ống nghiệm ở bước cuối: DNA kết tủa ở lớp cồn phía trên và được quấn lên đũa](hinh-2-ong-nghiem.svg)

> [!em-co-biet]
> Nhiều quy trình ở nước ngoài thêm một chút **muối ăn** vào dịch chiết. Ion Na^+^ bám vào nhóm phosphate tích điện âm, làm "dịu" lực đẩy giữa các mạch DNA, nhờ đó DNA kết tụ dễ hơn khi gặp cồn. SGK không dùng muối, nhưng thêm muối là một cách **cải tiến** hợp lí.

> [!vi-du] Ví dụ 1
> Một tế bào người (lưỡng bội) chứa khoảng 6,4×10^9^ cặp nucleotide. Biết mỗi cặp nucleotide dài 0,34 nm, mỗi nucleotide có khối lượng khoảng 300 đvC, 1 đvC ≈ 1,66×10^-24^ g.
>
> a) Nếu nối toàn bộ DNA của một tế bào thành một sợi thì dài bao nhiêu mét?
>
> b) Khối lượng DNA trong một tế bào là bao nhiêu picogram (1 pg = 10^-12^ g)?
>
> c) Cần khoảng bao nhiêu tế bào để thu được 1 mg DNA, lượng vừa đủ để nhìn thấy?

> [!goi-y] Gợi ý 1
> Dùng công thức ở Bài 1: L = số cặp × 0,34 nm. Đổi 1 m = 10^9^ nm.

> [!goi-y] Gợi ý 2
> Số nucleotide = 2 × số cặp. Khối lượng = số nucleotide × 300 đvC, rồi đổi sang gam.

> [!loi-giai] Lời giải
>
> a) L = 6,4×10^9^ × 0,34 = 2,176×10^9^ nm ≈ **2,2 m**.
>
>
> b) Số nucleotide = 1,28×10^10^. Khối lượng = 1,28×10^10^ × 300 × 1,66×10^-24^ ≈ 6,4×10^-12^ g = **6,4 pg**.
>
>
> c) 10^-3^ g : 6,4×10^-12^ g ≈ **1,6×10^8^ tế bào** (khoảng 160 triệu tế bào).
>
> Ý nghĩa: sợi DNA dài hơn 2 m gói trong nhân rộng vài micromet nên rất **mảnh và dễ đứt** khi khuấy mạnh. Một tế bào chỉ có vài picogram DNA, vì vậy phải dùng **cả gam mô** (hàng trăm triệu tế bào) mới thấy được kết tủa.

## 4. Cách tiến hành và "vì sao" của từng bước

Quy trình dưới đây theo SGK tr. 33 với mẫu gan gà. Cột thứ ba là điều quan trọng nhất để em hiểu và làm đúng.

| Bước | Thao tác (tóm tắt) | Vì sao làm như vậy |
|---|---|---|
| 1 | Nghiền kĩ khoảng **5 g gan** trong cối (hoặc xay 30–60 giây), thêm khoảng **150 mL nước lạnh**, khuấy đều. Gọt 1/4 quả dứa, nghiền, ép lấy nước | Phá mô, tách rời tế bào. Nước **lạnh** giảm hoạt động của nuclease. Nước dứa phải **tươi** để protease còn hoạt tính |
| 2 | Lọc dịch gan xay qua phễu có giấy lọc, lấy dịch trong | Bỏ các mảnh mô, mô liên kết chưa vỡ. Dịch trong giúp nhìn rõ kết tủa ở cuối |
| 3 | Cho dịch lọc vào ống nghiệm cùng **30 mL nước rửa bát pha loãng**, khuấy đều, để yên **5–10 phút** | Chất tẩy rửa hoà tan lipid, phá màng tế bào và màng nhân. Để yên cho chất tẩy rửa **kịp tác dụng** |
| 4 | Rót hỗn hợp sang ống mới chỉ khoảng **1/3 đến 1/2 ống**, thêm **5 mL nước dứa**, khuấy **nhẹ**, để yên khoảng **10 phút** | Protease cắt protein bám DNA, cần thời gian để enzyme làm việc. Khuấy nhẹ để DNA **không bị đứt vụn**. Chừa chỗ cho lớp cồn |
| 5 | Rót **từ từ cồn ethanol lạnh theo thành ống** đến gần đầy. Sau ít phút, kết tủa trắng nổi lên ở lớp cồn. **Xoay nhẹ** đũa để DNA quấn vào rồi nhấc ra | Rót theo thành để cồn **nổi thành lớp riêng**, không trộn lẫn. DNA kết tủa ở lớp cồn. DNA đã kết tủa rất **dễ gãy**, xoay mạnh sẽ vỡ vụn, không quấn được |

> [!meo] Nhớ thứ tự bằng câu "Xay – Lọc – Tẩy – Dứa – Cồn"
> Thứ tự đi **từ ngoài vào trong**: phá mô → phá màng → phá protein → gom DNA. Không thể đảo: nếu cho nước dứa trước khi phá màng thì protease không vào được nhân để gặp histone, còn cho cồn trước thì DNA chưa ra khỏi tế bào để mà kết tủa.

> [!vi-du] Ví dụ 2
> Một bạn làm thí nghiệm nhưng ghi thiếu thứ tự các thao tác: (a) để yên 10 phút sau khi thêm nước dứa; (b) xay gan với nước lạnh; (c) rót nhẹ cồn lạnh theo thành ống; (d) lọc lấy dịch trong; (e) thêm nước rửa bát, để yên 5–10 phút; (g) xoay nhẹ đũa thuỷ tinh lấy kết tủa. Hãy sắp xếp lại và cho biết thao tác nào giúp **giải phóng DNA khỏi nhân**.

> [!goi-y] Gợi ý 1
> Đi "từ ngoài vào trong": mô → tế bào → nhân → protein → DNA.

> [!goi-y] Gợi ý 2
> Màng nhân được cấu tạo từ chất gì? Hoá chất nào hoà tan được chất đó?

> [!loi-giai] Lời giải
> Thứ tự đúng: **b → d → e → a → c → g**.
>
> Thao tác giải phóng DNA khỏi nhân là **(e)**: chất tẩy rửa hoà tan lớp phospholipid của màng tế bào và **màng nhân**. Thao tác (a) chỉ tách DNA khỏi protein, khi đó DNA đã ra khỏi nhân rồi.

## 5. Kết quả và cách giải thích

### 5.1. Kết quả mong đợi

Sau vài phút kể từ lúc rót cồn, ở **ranh giới** giữa dịch chiết và lớp cồn xuất hiện các **sợi, búi trắng đục** hơi nhầy, dần nổi lên **lớp cồn**. Quấn đũa thuỷ tinh, em kéo được một búi giống sợi bông ướt hoặc nước mũi. Đó là **DNA kết tủa** (SGK tr. 34, Hình 6.1).

Giải thích kết quả gồm ba ý: (1) chất tẩy rửa và protease đã giải phóng DNA khỏi màng và protein, (2) ethanol giành nước nên DNA kết tủa, (3) ethanol nhẹ hơn nên DNA tập trung ở lớp trên.

### 5.2. Kết tủa có thật là DNA không?

Kết tủa **chủ yếu là DNA**, nhưng có thể lẫn một ít **RNA** (cũng là nucleic acid, cũng kết tủa trong cồn) và mảnh protein chưa cắt hết. Để khẳng định, có thể dùng **diphenylamine**: đun nóng kết tủa với thuốc thử này, nếu có DNA sẽ tạo phức **màu xanh lam** (SGK tr. 33). Thuốc thử phản ứng với đường **deoxyribose**, nên đặc trưng cho DNA, còn RNA (đường ribose) không cho màu này. Do không đủ thời gian, bài thực hành không làm bước nhận biết này.

> [!bay]
> - Nhận biết DNA bằng diphenylamine cần **đun nóng**. Màu là **xanh lam**, không phải tím (màu tím là phản ứng biuret đặc trưng cho protein).
> - Kết tủa từ thí nghiệm này **không phải DNA tinh khiết**. Đề cho phát biểu "kết tủa thu được là DNA tinh khiết 100%" là **sai**.

### 5.3. So sánh kết quả giữa các nhóm

SGK gợi ý mỗi nhóm làm với **một loại mẫu vật** để so sánh mô nào cho nhiều DNA hơn. Muốn so sánh công bằng, phải quy về **cùng một đơn vị**, ví dụ khối lượng kết tủa trên **1 gam** mẫu.

> [!vi-du] Ví dụ 3
> Bốn nhóm học sinh dùng cùng quy trình, thu được kết tủa ướt như sau (số liệu giả định):
>
> | Nhóm | Mẫu vật | Khối lượng mẫu (g) | Kết tủa ướt (mg) |
> |---|---|---|---|
> | 1 | Gan gà | 5 | 20 |
> | 2 | Gan lợn | 5 | 18 |
> | 3 | Chuối chín | 50 | 15 |
> | 4 | Lá cải bó xôi | 50 | 6 |
>
>
> a) Tính khối lượng kết tủa trên 1 g mẫu của mỗi nhóm.
>
> b) Lượng kết tủa trên 1 g gan gà gấp bao nhiêu lần chuối (làm tròn đến hàng đơn vị)?
>
> c) Nhóm 4 nhận thấy kết tủa có màu xanh nhạt. Giải thích và đề xuất cách khắc phục.

> [!goi-y] Gợi ý 1
> Chia kết tủa cho khối lượng mẫu. Đừng so sánh trực tiếp 20 mg với 15 mg vì khối lượng mẫu khác nhau gấp 10 lần.

> [!goi-y] Gợi ý 2
> Lá xanh chứa sắc tố gì? Sắc tố đó có tan trong cồn không?

> [!loi-giai] Lời giải
>
> a) Gan gà 20 : 5 = **4 mg/g**. Gan lợn 18 : 5 = **3,6 mg/g**. Chuối 15 : 50 = **0,3 mg/g**. Cải bó xôi 6 : 50 = **0,12 mg/g**.
>
>
> b) 4 : 0,3 ≈ 13,3 → khoảng **13 lần**. Mô gan giàu tế bào có nhân, ít nước, còn quả chuối nhiều nước và chất dự trữ.
>
>
> c) Kết tủa lẫn **diệp lục** (và sắc tố khác) của lá. Cần **loại bỏ sắc tố** trước khi tách chiết (theo lưu ý SGK), hoặc chọn mô thực vật **không có màu xanh** như quả, củ, mầm đậu.

## 6. Lỗi thường gặp và cách cải tiến

| Hiện tượng | Nguyên nhân có thể | Cách khắc phục |
|---|---|---|
| Không thấy kết tủa, hoặc rất ít | Nghiền chưa kĩ, quá ít mẫu, chưa đủ thời gian cho chất tẩy rửa tác dụng | Xay kĩ hơn, tăng lượng mẫu, để yên đủ 5–10 phút |
| Kết tủa lợn cợn, không thành sợi | Protein chưa bị cắt hết: nước dứa không tươi, đã đun nóng, hoặc để chưa đủ thời gian | Dùng nước dứa **tươi**, để đủ 10 phút |
| Kết tủa vụn, không quấn được | Khuấy, lắc quá mạnh làm DNA đứt thành đoạn ngắn. Hoặc mẫu để lâu, DNA bị nuclease phân giải | Khuấy nhẹ, xoay đũa nhẹ. Dùng mẫu tươi, giữ lạnh |
| Cồn hoà lẫn vào dịch, không thấy lớp riêng | Rót cồn quá nhanh, rót thẳng vào giữa ống | Nghiêng ống, rót **từ từ theo thành ống** |
| Kết tủa ít dù làm đúng | Cồn không lạnh, hoặc cồn quá loãng | Để cồn trong ngăn đá trước vài giờ. Dùng cồn 70–95% |
| Kết tủa có màu | Sắc tố của mô thực vật | Loại sắc tố, hoặc chọn mẫu không có màu |

> [!ung-dung]
> Các bước bạn vừa làm chính là **phiên bản đơn giản** của quy trình tách chiết DNA trong phòng thí nghiệm thật: ở đó người ta dùng dung dịch đệm phá màng (chứa chất tẩy rửa), enzyme **proteinase K** thay cho nước dứa, rồi kết tủa DNA bằng ethanol hoặc isopropanol lạnh. DNA tách chiết là nguyên liệu cho mọi kĩ thuật sau đó: **xét nghiệm PCR** chẩn đoán bệnh, **giám định DNA** xác định huyết thống, pháp y, và bước đầu tiên của **công nghệ DNA tái tổ hợp** (Bài 5).

> [!vi-du] Ví dụ 4
> Hãy dự đoán kết quả và giải thích trong mỗi trường hợp sau (các điều kiện khác giữ như quy trình SGK):
>
> a) Quên thêm nước rửa bát.
>
> b) Nước dứa được đun sôi 5 phút rồi để nguội trước khi dùng.
>
> c) Thay cồn lạnh bằng nước cất lạnh.

> [!goi-y] Gợi ý 1
> Mỗi hoá chất phá một "lớp vỏ". Thiếu hoá chất nào thì lớp nào còn nguyên?

> [!goi-y] Gợi ý 2
> Protease là protein. Protein bị đun sôi thì sao? DNA có tan trong nước không?

> [!loi-giai] Lời giải
>
> a) Màng tế bào và màng nhân phần lớn **không bị phá**, DNA vẫn bị giữ trong nhân, không ra được dịch chiết (bước lọc đã làm trước đó, nên tế bào còn nguyên vẫn nằm trong dịch nhưng DNA không thoát ra). Hầu như **không thu được kết tủa** DNA.
>
>
> b) Protease trong nước dứa bị **biến tính do nhiệt**, mất hoạt tính. Protein vẫn bám vào DNA, kết tủa (nếu có) **ít, lợn cợn, lẫn nhiều protein**, khó quấn thành sợi.
>
>
> c) DNA **tan trong nước**, nên thêm nước chỉ làm dịch loãng ra, **không có kết tủa**. Chính ethanol (chất giành nước, DNA không tan) mới làm DNA kết tủa.

## 7. Trả lời câu hỏi thu hoạch và báo cáo

Các câu hỏi ở mục Thu hoạch (SGK tr. 34), trả lời ngắn gọn bằng lời của em:

**a) Vì sao dùng nước rửa chén bát hay dung dịch tẩy rửa?** Để **hoà tan lipid** của màng tế bào và màng nhân, phá màng, giải phóng DNA ra dịch chiết.

**b) Vì sao cần nước dứa? Có thể thay bằng gì?** Nước dứa tươi chứa **protease**, cắt các protein (histone…) bám vào DNA. Có thể thay bằng dung dịch có protease khác: nước ép **đu đủ xanh** (papain), nước ép **kiwi**, bột làm mềm thịt có chứa enzyme, hoặc dung dịch enzyme protease bán sẵn. **Không** dùng nước dứa đóng hộp đã tiệt trùng bằng nhiệt, vì enzyme đã bị biến tính.

**c) Vì sao cần cồn ethanol?** Ethanol **giành nước** mạnh hơn DNA, DNA **không tan** trong ethanol nên **kết tủa**. Ethanol nhẹ hơn nước nên tạo lớp riêng phía trên, DNA kết tủa tập trung ở đó, dễ quan sát và lấy ra.

**d) Cải tiến gì để kết quả tốt hơn?** Khắc phục các lỗi ở bảng mục 6. Có thể thêm chút muối ăn, và kiểm tra kết tủa bằng diphenylamine nếu có điều kiện.

> [!ghi-nho] Báo cáo thực hành gồm 3 phần
> 1. **Mục đích**: tách chiết DNA từ mẫu vật sống (nêu rõ mẫu vật nhóm dùng).
> 2. **Kết quả và giải thích**: mô tả kết tủa (màu, hình dạng, lượng, vị trí trong ống), kèm ảnh chụp. Giải thích theo ba ý ở mục 5.1. So sánh với nhóm khác nếu có.
> 3. **Trả lời câu hỏi** a), b), c), d) như trên.

## Dạng bài thi hay gặp

> [!ghi-nho] Chìa khoá chung
> Nhớ "mỗi hoá chất phá một lớp": **xay** → mô; **chất tẩy rửa** → lipid màng; **protease (dứa)** → protein; **cồn lạnh** → làm DNA kết tủa. Thiếu hoặc hỏng thứ nào thì lớp đó còn nguyên.

### Dạng 1. Vai trò của hoá chất, thao tác

*Nhận biết:* "mục đích của việc…", "chất nào có vai trò…", "vì sao phải dùng cồn lạnh / rót theo thành ống / khuấy nhẹ".

*Phương pháp:*
1. Xác định thao tác đó nằm ở giai đoạn nào: phá mô, phá màng, cắt protein hay kết tủa.
2. Gắn với đối tượng bị tác động: lipid, protein, nước.
3. Loại các phương án gán sai đối tượng (ví dụ "nước rửa bát cắt protein", "cồn hoà tan màng").

> [!vi-du] Ví dụ 5
> Trong thí nghiệm tách chiết DNA, xét các phát biểu: (1) cồn ethanol được rót nhanh vào giữa ống để trộn đều với dịch chiết. (2) Nước lạnh giúp hạn chế hoạt động của enzyme phân giải DNA. (3) Protease trong nước dứa cắt DNA thành đoạn ngắn để dễ kết tủa. (4) Kết tủa trắng đục tập trung ở lớp cồn phía trên. Có bao nhiêu phát biểu đúng?

> [!goi-y] Gợi ý 1
> Cồn cần nằm thành **lớp riêng** hay trộn đều?

> [!goi-y] Gợi ý 2
> Protease tác động lên loại phân tử nào?

> [!loi-giai] Lời giải
> (1) Sai: rót **từ từ theo thành ống** để cồn tạo lớp riêng phía trên. (2) Đúng. (3) Sai: protease cắt **protein**, không cắt DNA. (4) Đúng: ethanol nhẹ hơn nước nên nằm trên, DNA kết tủa ở đó.
>
> Có **2** phát biểu đúng.

*Bẫy:* nhầm "kết tủa" với "hoà tan". DNA **tan trong nước** và **kết tủa trong cồn**, chứ không "tan trong cồn".

### Dạng 2. Dự đoán kết quả khi thay đổi thí nghiệm

*Nhận biết:* đề mô tả một nhóm làm khác quy trình (bỏ bước, đun nóng, đổi mẫu, dùng cồn ấm…) và hỏi kết quả.

*Phương pháp:*
1. Tìm bước bị thay đổi, xác định "lớp vỏ" nào không bị phá hoặc điều kiện nào không đạt.
2. Suy ra: DNA không ra được, ra nhưng lẫn protein, bị đứt vụn, hay không kết tủa.
3. Với mẫu vật, kiểm tra tế bào có **nhân** không và mô có giàu tế bào không.

> [!vi-du] Ví dụ 6
> Hai nhóm dùng cùng quy trình chuẩn. Nhóm X dùng 5 g máu lợn, nhóm Y dùng 5 g máu gà. Nhóm nào thu được nhiều DNA hơn? Vì sao?

> [!goi-y] Gợi ý 1
> Phần lớn tế bào trong máu là hồng cầu. Hồng cầu của lợn và của gà khác nhau ở điểm nào?

> [!loi-giai] Lời giải
> **Nhóm Y** (máu gà) thu được nhiều hơn hẳn. Hồng cầu của chim **có nhân**, nên mỗi hồng cầu đều chứa DNA. Hồng cầu trưởng thành của thú (lợn) **không có nhân**, DNA trong máu lợn chỉ đến từ bạch cầu, số lượng ít hơn rất nhiều.

*Bẫy:* "máu có nhiều tế bào nên nhiều DNA" là sai với động vật có vú.

### Dạng 3. Đọc bảng số liệu, tính toán liên quan

*Nhận biết:* bảng lượng kết tủa của nhiều nhóm, hoặc câu tính chiều dài, khối lượng DNA trong tế bào (gắn với công thức Bài 1).

*Phương pháp:*
1. So sánh lượng DNA phải quy về **cùng khối lượng mẫu** (mg/g), như Ví dụ 3.
2. Tính chiều dài: L = số cặp × 0,34 nm. Khối lượng: số nucleotide × 300 đvC × 1,66×10^-24^ g. Cẩn thận **số cặp** hay **số nucleotide** (gấp đôi), như Ví dụ 1.
3. Đổi đơn vị cẩn thận: 1 m = 10^9^ nm, 1 mg = 10^-3^ g, 1 pg = 10^-12^ g.

*Bẫy:* đề cho "số cặp nucleotide" mà nhân 300 đvC trực tiếp (quên nhân 2). So sánh lượng kết tủa thô của các mẫu có khối lượng khác nhau.

## Tóm tắt

| Bước | Hoá chất, thao tác | Tác động lên | Lưu ý |
|---|---|---|---|
| 1. Phá mô | Nghiền, xay với nước lạnh | Mô → tế bào rời | Lạnh: hạn chế nuclease |
| 2. Lọc | Giấy lọc, phễu | Bỏ cặn | Dịch trong để dễ quan sát |
| 3. Phá màng | Nước rửa bát (chất tẩy rửa) | **Lipid** màng tế bào, màng nhân | Để yên 5–10 phút |
| 4. Cắt protein | Nước dứa **tươi** (protease) | **Protein** bám DNA (histone…) | Không đun nóng, để yên 10 phút, khuấy nhẹ |
| 5. Kết tủa | Cồn ethanol **lạnh** rót theo thành ống | DNA mất nước → kết tủa trắng đục ở lớp cồn | Xoay đũa nhẹ, DNA dễ gãy |
| Nhận biết | Diphenylamine, đun nóng | Đường deoxyribose của DNA | Màu **xanh lam** |

**Chọn mẫu:** gan gà, gan lợn (giàu DNA, dễ nghiền) khoảng 5 g. Mô thực vật khoảng 50 g, nhiều nước, có thành cellulose, sắc tố cần loại. Máu thú không phù hợp (hồng cầu không nhân), máu chim dùng được.

**Ba câu "vì sao" phải thuộc:** chất tẩy rửa hoà tan **lipid** · protease cắt **protein** · ethanol **giành nước**, DNA không tan nên **kết tủa**, cồn nhẹ nên DNA ở **lớp trên**.
