---
title: Quan niệm của Darwin về chọn lọc tự nhiên và hình thành loài
thoi-gian: 35 phút
muc-tieu:
  - Nêu được ba bước trong phương pháp Darwin dùng để xây dựng học thuyết (quan sát thu thập dữ liệu, đề xuất giả thuyết, kiểm chứng giả thuyết) và lấy được ví dụ cho từng bước.
  - Trình bày được các quan sát của Darwin về biến dị cá thể, đặc điểm thích nghi, khả năng sinh sản vượt mức và chọn lọc nhân tạo.
  - Giải thích được chọn lọc tự nhiên là gì và vì sao nó làm tăng dần tần số các cá thể mang đặc điểm thích nghi qua các thế hệ.
  - Giải thích được quá trình hình thành loài mới từ một tổ tiên chung theo quan niệm "hậu duệ có biến đổi" của Darwin.
  - Vận dụng quan niệm của Darwin giải thích các hiện tượng thực tế như vi khuẩn kháng thuốc kháng sinh, sâu hại kháng thuốc trừ sâu.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Darwin xây dựng học thuyết theo đúng quy trình khoa học: **quan sát, thu thập dữ liệu → đề xuất giả thuyết → kiểm chứng giả thuyết** bằng thực nghiệm.
> 2. Hai quan sát then chốt: các cá thể cùng loài **khác nhau** ở một số đặc điểm di truyền (**biến dị cá thể**), và sinh vật **sinh ra nhiều con hơn** số mà môi trường nuôi nổi, nên chỉ một phần sống sót và sinh sản.
> 3. Con người dùng **chọn lọc nhân tạo** (giữ lại biến dị mình thích, loại bỏ biến dị không muốn) tạo ra nhiều giống từ một dạng ban đầu, ví dụ nhiều giống cải từ cải hoang dại.
> 4. **Chọn lọc tự nhiên**: biến dị di truyền nào giúp cá thể **sống sót và sinh sản tốt hơn** thì tần số cá thể mang nó **tăng dần** qua các thế hệ. Kết quả là quần thể có đặc điểm **thích nghi**.
> 5. Theo thời gian, mỗi nhóm con cháu thích nghi với một môi trường riêng, tích lũy khác biệt và trở thành **loài mới**. Mọi loài là **"hậu duệ có biến đổi"** của một tổ tiên chung, sơ đồ tiến hóa có dạng **cây phân nhánh**.

> [!nen-tang] Nhớ lại trước khi học
> - **Biến dị di truyền** là những biến đổi truyền được cho đời sau (đột biến gene ở Bài 4, biến dị tổ hợp do sinh sản hữu tính ở Bài 8–11, đột biến nhiễm sắc thể ở Bài 12). Thường biến (Bài 16) chỉ là biến đổi kiểu hình do môi trường, **không** di truyền.
> - **Bằng chứng tiến hóa** (Bài 19): hóa thạch, cấu trúc tương đồng, các bằng chứng tế bào học và phân tử đều cho thấy các loài có **chung tổ tiên**. Bài này trả lời câu hỏi tiếp theo: **cơ chế nào** làm các loài biến đổi và tách ra từ tổ tiên chung?
> - **Quần thể** là tập hợp các cá thể cùng loài, cùng sống trong một khu vực, giao phối được với nhau.

Mở đầu bài, SGK đặt một câu hỏi rất đời thường: vì sao dùng thuốc kháng sinh lâu dài lại dễ khiến vi khuẩn gây bệnh trở nên kháng thuốc (SGK tr. 101)? Câu trả lời nằm ngay trong ý tưởng lớn nhất của sinh học: **chọn lọc tự nhiên** (xem mục 3.4). Bài này cũng cho em thấy **Darwin đã làm khoa học như thế nào**, đó chính là yêu cầu cần đạt của bài.

## 1. Phương pháp nghiên cứu của Darwin (tổng quan)

Charles Darwin (1809 – 1882) là nhà tự nhiên học người Anh. Ông được xem là một trong những người đặt nền móng cho **quy trình nghiên cứu khoa học** mà các nhà khoa học tự nhiên vẫn dùng đến ngày nay (SGK tr. 101). Quy trình gồm ba bước nối tiếp nhau. Ba mục tiếp theo của bài đi lần lượt qua từng bước, đúng như mục I, II, III của SGK.

![Hình 1. Ba bước trong phương pháp nghiên cứu của Darwin, kèm ví dụ cho từng bước](hinh-1-phuong-phap.svg)

**Vì sao phải có bước 3?** Một giả thuyết dù nghe hợp lí đến đâu cũng chỉ là "phỏng đoán có cơ sở". Chỉ khi các **dự đoán** rút ra từ nó được thực nghiệm xác nhận, giả thuyết mới đáng tin. Nếu thực nghiệm cho kết quả ngược lại, ta phải sửa hoặc bỏ giả thuyết. Darwin hiểu rất rõ điều này, nên ông dành nhiều năm thu thập bằng chứng và tự làm thí nghiệm trước khi công bố (mục 4).

> [!bay]
> - **Giả thuyết** khác **kết luận**. "Cây nắp ấm có lẽ bắt côn trùng để bù thiếu nitrogen" là giả thuyết. "Cây nắp ấm chỉ tiêu thụ dung dịch protein" là kết quả thí nghiệm.
> - Đề hay cho một đoạn mô tả rồi hỏi "đây là bước nào". Hãy tìm **động từ**: *nhận thấy, ghi chép, thu mẫu* → quan sát; *cho rằng, đưa ra giả thuyết, có thể là do* → giả thuyết; *làm thí nghiệm, ngâm, nhỏ, đo, kiểm tra* → kiểm chứng.

## 2. Quan sát các đặc điểm di truyền và biến dị

### 2.1. Quan sát các loài sinh vật trong tự nhiên

Năm 1831, Darwin tham gia đoàn thám hiểm vòng quanh thế giới trên tàu **Beagle**, kéo dài **5 năm**. Ông thu thập hàng nghìn mẫu động vật, thực vật. Kho dữ liệu này là nền móng cho học thuyết của ông sau này (SGK tr. 101).

Từ những gì quan sát được, Darwin rút ra bốn nhận xét quan trọng.

**(1) Họ hàng càng gần thì càng giống nhau.** Con cùng bố mẹ giống nhau nhiều, các cá thể cùng loài giống nhau nhiều. Darwin cho rằng sinh vật giống nhau nhiều vì chúng có **chung tổ tiên**. (Đây cũng là ý chính của Bài 19.)

**(2) Nhưng không có hai cá thể giống hệt nhau.** Ngay cả con cùng một cặp bố mẹ vẫn khác nhau và khác bố mẹ ở một số đặc điểm. Darwin gọi những khác biệt đó là **biến dị cá thể**. Thời Darwin chưa ai biết gene, nhiễm sắc thể hay đột biến là gì. Ông chỉ thấy biến dị tồn tại và truyền được cho đời sau, chứ chưa giải thích được nó **sinh ra như thế nào** và **di truyền theo cơ chế nào**.

**(3) Sinh vật có những đặc điểm thích nghi.** Ví dụ nổi tiếng là các loài chim sẻ trên **quần đảo Galapagos**, cách đất liền Nam Mỹ khoảng 900 km (SGK tr. 101–102):

- Chim trên các đảo giống chim ở **vùng đất liền gần nhất** (Nam Mỹ) hơn là giống chim ở những nơi xa khác dù có **cùng vĩ độ**, tức là khí hậu tương tự. Darwin suy ra chim trên đảo có **nguồn gốc từ đất liền** Nam Mỹ.
- Các loài chim sẻ trên đảo giống nhau ở nhiều đặc điểm, nhưng khác nhau ở **kích thước, hình dạng mỏ**. Đảo nhiều cây cho hạt to thì chim có mỏ **ngắn, dày, khỏe** để tách vỏ hạt. Đảo nhiều côn trùng thì chim có mỏ **mảnh, dài** để bắt sâu bọ (SGK Hình 20.1).

Darwin gọi những biến dị giúp sinh vật **sống sót và sinh sản tốt hơn** trong môi trường của nó (như các kiểu mỏ trên) là **đặc điểm thích nghi**. Ông còn thấy đặc điểm thích nghi ở rất nhiều sinh vật khác như hoa lan, côn trùng.

> [!vi-du] Ví dụ 1
> Vì sao Darwin cho rằng hình dạng mỏ của chim sẻ trên quần đảo Galapagos là đặc điểm thích nghi? Một hòn đảo chỉ có cây cho hạt nhỏ, vỏ mềm thì em dự đoán chim ở đó có mỏ như thế nào so với chim ở đảo nhiều hạt to, vỏ cứng?

> [!goi-y] Gợi ý 1
> Đặc điểm thích nghi phải mang lại lợi ích gì cho con vật? Mỏ liên quan đến hoạt động sống nào?

> [!goi-y] Gợi ý 2
> Mỏ to, dày cần cho việc gì? Nếu thức ăn không đòi hỏi việc đó, mỏ to có còn lợi thế không?

> [!loi-giai] Lời giải
> Mỗi kiểu mỏ **khớp với loại thức ăn** phổ biến trên đảo: mỏ dày, khỏe tách được vỏ hạt cứng, mỏ mảnh, dài bắt được côn trùng. Chim có kiểu mỏ phù hợp sẽ kiếm được nhiều thức ăn hơn, nên **sống sót và sinh sản tốt hơn**. Đó chính là định nghĩa đặc điểm thích nghi.
>
> Ở đảo chỉ có hạt nhỏ, vỏ mềm, mỏ to, nặng không còn lợi thế (lại tốn năng lượng để nuôi). Ta dự đoán chim ở đó có mỏ **nhỏ, mảnh hơn**, thuận tiện nhặt hạt nhỏ.

**(4) Sinh vật sinh ra rất nhiều con, nhưng chỉ ít con sống được đến lúc trưởng thành.** Mỗi loài có khả năng sinh ra số con **vượt xa** số cá thể mà nguồn sống của môi trường (thức ăn, chỗ ở…) nuôi được. Vì vậy, phần lớn con non chết trước khi kịp sinh sản. Chỉ một số ít sống sót đến tuổi trưởng thành và sinh sản (SGK tr. 102).

> [!vi-du] Ví dụ 2
> Một loài cá biển, mỗi con cái đẻ tổng cộng khoảng 8 000 trứng trong suốt đời. Qua nhiều năm, số lượng cá thể của quần thể gần như không đổi. Trung bình, cứ 8 000 trứng của một cặp bố mẹ thì có bao nhiêu con sống sót đến khi sinh sản? Tỉ lệ đó là bao nhiêu phần trăm?

> [!goi-y] Gợi ý 1
> Số lượng quần thể không đổi nghĩa là mỗi cặp bố mẹ, khi chết đi, được thay thế bằng đúng bao nhiêu cá thể trưởng thành?

> [!goi-y] Gợi ý 2
> Một cặp bố mẹ gồm 2 cá thể. Muốn quần thể không tăng không giảm thì con cháu chỉ cần "thay chỗ" 2 cá thể đó.

> [!loi-giai] Lời giải
> Bước 1: Quần thể ổn định nên trung bình mỗi cặp bố mẹ chỉ để lại **2** con sống đến tuổi sinh sản, thay thế cho chính chúng.
>
> Bước 2: Tỉ lệ sống sót = 2 : 8 000 × 100% = **0,025%**.
>
> Kết luận: gần như toàn bộ trứng và cá con bị chết. Ai sống sót không phải hoàn toàn do may rủi: cá thể nào có biến dị giúp kiếm mồi, trốn kẻ thù tốt hơn thì có cơ hội cao hơn. Đây chính là "cửa hẹp" để chọn lọc tự nhiên hoạt động.

### 2.2. Quan sát các giống vật nuôi và cây trồng

Darwin quan sát kĩ cách những người chăn nuôi, trồng trọt tạo giống. Trong cùng một giống, khi thấy cá thể có **biến dị ưa thích**, người ta giữ nó lại, cho nhân giống riêng. Chỉ sau một số thế hệ, đã có thể tạo ra **giống mới** (SGK tr. 102). Darwin gọi cách tạo giống này là **chọn lọc nhân tạo**.

Hai ví dụ trong SGK:

- Nhiều giống **bồ câu** khác hẳn nhau (bồ câu đuôi quạt, bồ câu diều…) đều được chọn lọc từ **bồ câu núi** hoang dại.
- Nhiều loại rau rất khác nhau được chọn lọc từ cùng một loài **cải hoang dại** (*Brassica oleracea*). Mỗi giống là kết quả chọn lọc theo **một bộ phận** mà con người muốn dùng (SGK tr. 103, Hình 20.2).

![Hình 2. Chọn lọc nhân tạo theo các bộ phận khác nhau tạo ra nhiều giống rau từ loài cải hoang dại Brassica oleracea](hinh-2-cai-hoang-dai.svg)

| Giống rau | Bộ phận được chọn lọc (to ra, phát triển mạnh) |
|---|---|
| Bắp cải | Chồi ngọn |
| Cải Brussel | Chồi bên |
| Su hào | Thân |
| Súp lơ trắng | Cụm hoa |
| Bông cải xanh (súp lơ xanh) | Thân và hoa |
| Cải xoăn | Lá |

**Vì sao chọn lọc nhân tạo làm được điều đó?** Có hai điều kiện:

1. **Phải có biến dị cá thể** để chọn. Nếu mọi cây cải giống hệt nhau thì người trồng không có gì để chọn.
2. **Biến dị phải di truyền được**. Cây có chồi ngọn to được giữ lại, con của nó cũng có xu hướng chồi ngọn to. Lặp lại qua nhiều thế hệ, đặc điểm này được **tích lũy** ngày càng rõ.

Chọn lọc nhân tạo có hai mặt: **giữ lại, nhân giống** biến dị có lợi cho con người, và **loại bỏ** biến dị không mong muốn. Động lực là **nhu cầu của con người**, nên giống tạo ra thích hợp với con người, chứ không nhất thiết có lợi cho chính sinh vật.

> [!ung-dung] Ứng dụng (ngoài SGK)
> Các giống gà siêu trứng đẻ rất nhiều trứng nhưng khó sống sót nếu thả ngoài tự nhiên: chúng phù hợp với **nhu cầu con người**, không phải với môi trường hoang dã.

### 2.3. Tóm tắt các quan sát của Darwin

SGK gói các quan sát lại thành hai ý (SGK tr. 103):

> [!ghi-nho] Hai quan sát nền tảng
> 1. Các cá thể trong cùng quần thể giống nhau ở nhiều đặc điểm, nhưng vẫn **khác nhau ở một số đặc điểm di truyền** (biến dị cá thể).
> 2. Các loài thường sinh ra **số con nhiều hơn** số cá thể mà môi trường có thể nuôi dưỡng.

Ghép hai quan sát với nhau, ta suy ra ngay: vì không đủ nguồn sống cho tất cả, các cá thể phải **cạnh tranh** với nhau. Vì các cá thể khác nhau, **không phải ai cũng có cơ hội như nhau**. Đây là bước đệm để Darwin đề xuất giả thuyết ở mục 3.

> [!em-co-biet] Mở rộng, ngoài SGK
> Ý "sinh nhiều hơn mức môi trường nuôi nổi" được Darwin gợi ra một phần từ sách về dân số của Thomas Malthus (dân số tăng nhanh hơn lương thực).

## 3. Giả thuyết chọn lọc tự nhiên giải thích quá trình hình thành loài

### 3.1. Từ chọn lọc nhân tạo đến chọn lọc tự nhiên

Darwin lập luận theo kiểu so sánh: con người chỉ cần chọn lọc qua một số thế hệ đã tạo được giống mới, và từ một loài cải hoang dại đã tạo ra cả loạt giống rau. Vậy trong tự nhiên, suốt hàng triệu năm, liệu có một quá trình **tương tự** mà không cần con người không? Ông cho rằng **có**, và gọi đó là **chọn lọc tự nhiên** (SGK tr. 103–104).

Lập luận của Darwin có thể viết thành chuỗi logic sau:

| Cơ sở (quan sát) | Suy luận |
|---|---|
| Quần thể luôn sẵn có biến dị di truyền | Các cá thể khác nhau về khả năng sống sót, sinh sản |
| Sinh ra nhiều con hơn môi trường nuôi nổi | Chỉ một phần nhỏ sống sót và sinh sản |
| Biến dị di truyền được cho đời con | Cá thể sống sót, sinh sản nhiều truyền biến dị có lợi cho nhiều con hơn |
| Lặp lại qua nhiều thế hệ | **Tần số cá thể mang biến dị có lợi tăng dần** → quần thể thích nghi |

> [!ghi-nho] Chọn lọc tự nhiên (theo Darwin)
> Là quá trình tự nhiên làm **tăng dần tần số các cá thể mang đặc điểm thích nghi** qua các thế hệ. Những biến dị di truyền làm tăng khả năng **sống sót** và **sinh sản** của sinh vật sẽ ngày càng phổ biến trong quần thể ở các thế hệ sau.

Chọn lọc tự nhiên **không chỉ** làm sinh vật thích nghi với môi trường, mà còn làm **xuất hiện các loài mới** từ một tổ tiên chung (mục 3.3).

So sánh hai kiểu chọn lọc:

| | Chọn lọc nhân tạo | Chọn lọc tự nhiên |
|---|---|---|
| Ai/cái gì "chọn" | Con người | Điều kiện môi trường (thức ăn, khí hậu, kẻ thù, bệnh…) |
| Nguyên liệu | Biến dị cá thể di truyền | Biến dị cá thể di truyền |
| Tiêu chí giữ lại | Có lợi cho **nhu cầu con người** | Giúp sinh vật **sống sót và sinh sản** tốt hơn |
| Kết quả | Nhiều giống vật nuôi, cây trồng từ một dạng ban đầu | Sinh vật thích nghi với môi trường, hình thành loài mới |
| Thời gian | Tương đối ngắn | Rất dài |

> [!bay]
> - Chọn lọc tự nhiên **không tạo ra** biến dị. Nó chỉ **giữ lại, nhân lên** những biến dị **đã có sẵn** trong quần thể và đào thải những biến dị bất lợi.
> - Câu kiểu "môi trường thay đổi **làm cho** sinh vật biến đổi để thích nghi" hay "con vật **cố gắng** sử dụng cơ quan nên cơ quan phát triển và truyền cho con" **không phải** quan niệm của Darwin. Đề thi rất hay dùng các câu này làm phương án nhiễu. (Ngoài SGK: đây là lối giải thích kiểu Lamarck, một nhà khoa học trước Darwin.)
> - Đặc điểm do **thường biến** (không di truyền) dù có lợi cũng **không** được chọn lọc tích lũy qua các thế hệ.

### 3.2. Đặc điểm thích nghi: hiểu cho đúng

Một đặc điểm được gọi là **thích nghi** khi nó giúp sinh vật mang nó **sống sót và sinh sản tốt hơn** trong một môi trường nhất định (SGK tr. 102, 104). Có ba chữ cần chú ý:

1. **Sống sót** — sống được đến tuổi sinh sản.
2. **Sinh sản** — để lại nhiều con cháu. Đây là "điểm số cuối cùng" của chọn lọc tự nhiên. Một con vật sống rất lâu nhưng không sinh con thì biến dị của nó không truyền được cho ai.
3. **Trong một môi trường nhất định** — mỏ dày, khỏe là thích nghi ở đảo nhiều hạt cứng, nhưng không có lợi ở đảo nhiều côn trùng.

Vì vậy, muốn biết một đặc điểm có thích nghi hay không, **không thể chỉ đo tỉ lệ sống sót**. Phải xét cả số con mà cá thể mang đặc điểm đó để lại (SGK tr. 105, Luyện tập 2).

> [!vi-du] Ví dụ 3
> Ở một loài thằn lằn có hai kiểu hình màu da: kiểu X và kiểu Y. Theo dõi trong cùng một môi trường: 80% cá thể X sống đến tuổi sinh sản, mỗi cá thể X sống sót sinh trung bình 3 con. Chỉ 60% cá thể Y sống đến tuổi sinh sản, nhưng mỗi cá thể Y sống sót sinh trung bình 5 con. Bạn An kết luận: "X thích nghi hơn vì sống sót tốt hơn". Kết luận đó đúng hay sai?

> [!goi-y] Gợi ý 1
> Chọn lọc tự nhiên "chấm điểm" sinh vật bằng gì: số năm sống, hay số con cháu để lại?

> [!goi-y] Gợi ý 2
> Tính số con trung bình mà **một cá thể mới sinh** của mỗi kiểu để lại = tỉ lệ sống sót × số con của cá thể sống sót.

> [!loi-giai] Lời giải
> Bước 1: Kiểu X: 0,8 × 3 = **2,4** con trên mỗi cá thể mới sinh.
>
> Bước 2: Kiểu Y: 0,6 × 5 = **3,0** con trên mỗi cá thể mới sinh.
>
> Bước 3: Kiểu Y để lại nhiều con hơn, nên qua các thế hệ tần số kiểu Y sẽ **tăng**. Y mới là kiểu thích nghi hơn. Kết luận của An **sai** vì chỉ xét sống sót, bỏ quên khả năng sinh sản.

### 3.3. "Hậu duệ có biến đổi" và sự hình thành loài mới

Trong cuốn sách **Nguồn gốc các loài**, Darwin dùng cụm từ **"hậu duệ có biến đổi"** để giải thích sự tiến hóa của toàn bộ sinh giới (SGK tr. 104). Ý nghĩa:

- Đời con mang những đặc điểm của bố mẹ, **nhưng luôn có thêm biến dị di truyền**. Vì vậy, con cháu không bao giờ là bản sao y hệt của tổ tiên.
- Mỗi loại biến dị có thể giúp cá thể thích nghi với **một kiểu môi trường** nhất định.
- Nếu các nhóm con cháu của cùng một tổ tiên sống ở những **môi trường khác nhau**, chọn lọc tự nhiên ở mỗi nơi giữ lại **những biến dị khác nhau**. Qua rất nhiều thế hệ, khác biệt tích lũy đủ lớn, mỗi nhóm trở thành **một loài mới**.
- Nhóm nào không thích nghi được với môi trường thì bị đào thải, **tuyệt chủng**.

Darwin phác họa ý tưởng này bằng một sơ đồ **cây phân nhánh** (SGK tr. 104, Hình 20.3): gốc cây là tổ tiên chung, mỗi lần rẽ nhánh là một lần một nhóm tách thành hai hướng tiến hóa, mỗi đầu nhánh là một loài. Đầu nhánh vươn tới hiện tại là loài **còn sống**, đầu nhánh dừng giữa chừng là loài **đã tuyệt chủng**.

![Hình 3. Sơ đồ tiến hóa phân nhánh theo ý tưởng "hậu duệ có biến đổi": các loài hiện nay (A–E) cùng bắt nguồn từ một tổ tiên chung, nhiều nhánh đã tuyệt chủng (vẽ giản lược)](hinh-3-cay-phan-nhanh.svg)

**Đọc sơ đồ:**

- Hai loài có **điểm rẽ nhánh chung gần nhất** càng gần hiện tại thì càng **họ hàng gần**. Trong Hình 3, D và E tách nhau muộn nhất nên gần nhau nhất, còn A tách khỏi nhóm sớm nhất.
- Có nhiều nhánh tận cùng bằng dấu ×: đó là loài tuyệt chủng. Theo Darwin, tuyệt chủng là chuyện **bình thường**, xảy ra với những loài không thích nghi được.
- Các loài chim sẻ Galapagos chính là "cành cây" như vậy: từ một nhóm tổ tiên bay từ đất liền ra, trên mỗi đảo chọn lọc giữ lại kiểu mỏ hợp với thức ăn ở đó, lâu dần thành nhiều loài.

> [!vi-du] Ví dụ 4
> Dựa vào Hình 3, hãy cho biết: (a) Có bao nhiêu loài còn sống và bao nhiêu loài đã tuyệt chủng được vẽ? (b) Loài C có họ hàng gần với loài B hay loài D hơn?

> [!goi-y] Gợi ý 1
> Đầu nhánh có tên chữ cái ở hàng "hiện tại" là loài còn sống. Đầu nhánh có dấu × là loài tuyệt chủng. Đếm từng loại.

> [!goi-y] Gợi ý 2
> Đi ngược từ C và từ B xuống gốc, xem chúng gặp nhau ở điểm rẽ nhánh nào. Làm tương tự với C và D. Điểm gặp nào **gần hiện tại hơn**?

> [!loi-giai] Lời giải
> (a) Có **5** loài còn sống (A, B, C, D, E) và **4** loài tuyệt chủng (4 dấu ×).
>
> (b) C và D có chung điểm rẽ nhánh (tổ tiên chung) gần hiện tại hơn so với C và B, vì B tách khỏi nhóm (C, D, E) từ sớm hơn. Vậy C **họ hàng gần D hơn**.

### 3.4. Giải thích hiện tượng vi khuẩn kháng thuốc (trả lời câu hỏi mở đầu)

Áp dụng đúng chuỗi lập luận của Darwin:

1. **Biến dị có sẵn.** Trong một quần thể vi khuẩn rất lớn, có sẵn một số ít tế bào mang biến dị di truyền giúp chịu được thuốc kháng sinh. Biến dị này **có từ trước**, không phải do thuốc tạo ra.
2. **Chọn lọc.** Khi dùng kháng sinh, phần lớn vi khuẩn không có biến dị kháng thuốc bị giết. Các tế bào kháng thuốc sống sót.
3. **Sinh sản và di truyền.** Vi khuẩn sống sót sinh sản rất nhanh, truyền đặc điểm kháng thuốc cho thế hệ sau.
4. **Tích lũy.** Dùng thuốc càng **lâu dài, lặp lại**, chọn lọc diễn ra càng nhiều lần, tần số vi khuẩn kháng thuốc càng tăng. Cuối cùng gần như cả quần thể kháng thuốc, thuốc mất tác dụng.

![Hình 4. Mỗi đợt dùng kháng sinh giết phần lớn vi khuẩn không kháng thuốc, vi khuẩn kháng thuốc sống sót và sinh sản, nên tỉ lệ kháng thuốc tăng dần qua các đợt (số liệu theo Ví dụ 5)](hinh-4-khang-thuoc.svg)

> [!vi-du] Ví dụ 5
> Một quần thể vi khuẩn ban đầu có 1% tế bào kháng thuốc. Mỗi đợt dùng kháng sinh giết 90% số tế bào không kháng thuốc, còn tế bào kháng thuốc không bị ảnh hưởng. Sau mỗi đợt, vi khuẩn còn sống sinh sản lại với tốc độ như nhau (tỉ lệ giữa hai loại không đổi trong lúc sinh sản). Tính tỉ lệ phần trăm tế bào kháng thuốc sau đợt thứ nhất và sau đợt thứ hai (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Giả sử ban đầu có 1 000 tế bào cho dễ tính: bao nhiêu tế bào kháng, bao nhiêu không kháng?

> [!goi-y] Gợi ý 2
> Sau mỗi đợt, số tế bào không kháng chỉ còn 10%. Số tế bào kháng giữ nguyên. Tỉ lệ = số kháng : tổng số còn lại.

> [!loi-giai] Lời giải
> Bước 1: Ban đầu có 10 tế bào kháng, 990 tế bào không kháng.
>
> Bước 2 (đợt 1): không kháng còn 990 × 0,1 = 99. Tỉ lệ kháng = 10 : (10 + 99) × 100% ≈ **9,2%**.
>
> Bước 3 (đợt 2): sinh sản không làm đổi tỉ lệ, nên coi như còn 10 kháng và 99 không kháng. Đợt 2 giết 90% không kháng → còn 9,9. Tỉ lệ kháng = 10 : (10 + 9,9) × 100% ≈ **50,3%**.
>
> Kết luận: chỉ sau 2 đợt, tỉ lệ kháng thuốc đã từ 1% lên khoảng một nửa. Đợt thứ ba sẽ đẩy lên khoảng 91%.

> [!ung-dung] Ứng dụng thực tế
> - **Dùng kháng sinh đúng chỉ định, đủ liều, đủ thời gian** theo đơn của bác sĩ. Tự ý dùng kháng sinh khi không cần (ví dụ cảm cúm do virus) chỉ tạo thêm "đợt chọn lọc" cho vi khuẩn kháng thuốc.
> - Trong nông nghiệp, phun **một loại thuốc trừ sâu liên tục** nhiều năm cũng dẫn tới quần thể sâu kháng thuốc theo đúng cơ chế trên. Vì vậy người ta khuyên **luân phiên** các loại thuốc có cơ chế khác nhau và kết hợp biện pháp sinh học.

## 4. Kiểm chứng giả thuyết

Dù đã phác thảo học thuyết chọn lọc tự nhiên từ lâu, Darwin **chưa vội công bố**. Ông dành nhiều năm tìm thêm bằng chứng và tự làm thí nghiệm kiểm chứng (SGK tr. 104). Hai thí nghiệm tiêu biểu trong SGK:

### 4.1. Thí nghiệm ngâm hạt trong nước biển

- **Câu hỏi:** cây trên các đảo xa đất liền từ đâu tới?
- **Giả thuyết:** hạt cây từ đất liền trôi theo nước biển ra đảo, rồi nảy mầm.
- **Dự đoán:** nếu giả thuyết đúng, hạt của nhiều loài phải **còn nảy mầm được** sau khi ngâm lâu trong nước biển.
- **Thí nghiệm:** Darwin ngâm nhiều loại hạt giống trong nước biển trong thời gian dài, rồi kiểm tra khả năng nảy mầm.
- **Kết quả:** hạt của nhiều loài vẫn nảy mầm được sau thời gian dài ngâm nước biển.
- **Kết luận:** ủng hộ giả thuyết cây trên đảo được phát tán từ đất liền.

### 4.2. Thí nghiệm với cây nắp ấm

- **Quan sát:** cây nắp ấm có lá biến đổi thành "chiếc bình" bắt côn trùng. Chúng thường sống ở nơi **đất nghèo nitrogen**.
- **Giả thuyết:** cấu trúc lá bắt côn trùng là **đặc điểm thích nghi** giúp cây lấy thêm nitrogen từ con mồi, bù cho đất nghèo nitrogen.
- **Dự đoán:** nếu đúng, cây sẽ "tiêu thụ" chất **chứa nitrogen** (protein), còn chất không chứa nitrogen thì không.
- **Thí nghiệm:** nhỏ vào lá nắp ấm các dung dịch khác nhau: nước đường, lipid, protein.
- **Kết quả:** cây chỉ tiêu thụ **protein**, đúng như dự đoán.

**Vì sao thí nghiệm này thiết kế hay?** Đường và chất béo (lipid) chủ yếu chỉ gồm C, H, O, còn protein có thêm **N**. Ba dung dịch giống như ba "nhóm" so sánh: nếu cây tiêu thụ cả ba thì có thể cây chỉ cần chất dinh dưỡng nói chung. Việc cây **chỉ chọn protein** cho thấy thứ cây cần chính là **nitrogen**, khớp chính xác với giả thuyết.

> [!nen-tang]
> Đường và chất béo gồm C, H, O. Protein gồm C, H, O, **N** (thường có thêm S). Cây cần nitrogen để tổng hợp protein, nucleic acid, thường lấy từ đất dưới dạng NH~4~^+^ và NO~3~^-^ (Sinh học 11).

> [!vi-du] Ví dụ 6
> Một học sinh muốn kiểm chứng giả thuyết: "Màu lông trắng giúp thỏ ở vùng tuyết tránh được chim săn mồi tốt hơn màu lông nâu". Em hãy (a) nêu một dự đoán rút ra từ giả thuyết, (b) mô tả ngắn một thí nghiệm kiểm chứng an toàn (không dùng động vật thật).

> [!goi-y] Gợi ý 1
> Nếu giả thuyết đúng, trên nền tuyết, con mồi màu nào sẽ bị kẻ săn mồi phát hiện **ít hơn**?

> [!goi-y] Gợi ý 2
> Có thể dùng **mô hình** thỏ bằng đất nặn hai màu, đặt trên nền trắng, và cần một nhóm đối chứng trên nền khác.

> [!loi-giai] Lời giải
> (a) Dự đoán: trên nền tuyết trắng, mô hình thỏ màu trắng bị chim tấn công **ít hơn** mô hình màu nâu.
>
> (b) Thí nghiệm: đặt xen kẽ ngẫu nhiên số lượng bằng nhau mô hình đất nặn màu trắng và màu nâu trên nền trắng, sau một thời gian đếm số mô hình có vết mỏ chim ở mỗi màu. Làm thêm trên nền nâu để đối chứng: nếu ở nền nâu kết quả **đảo ngược**, giả thuyết càng được củng cố.

### 4.3. Darwin và Wallace

Cùng thời với Darwin, nhà tự nhiên học **Alfred Russel Wallace** cũng **độc lập** đi đến ý tưởng chọn lọc tự nhiên và gửi bản thảo cho Darwin góp ý (SGK tr. 104). Dù cả hai cùng phát hiện ra cơ chế này, học thuyết vẫn mang tên Darwin, vì Darwin đã đưa ra được **khối lượng bằng chứng khoa học rất lớn** để ủng hộ nó.

Bài học ở đây: trong khoa học, một ý tưởng có giá trị nhất khi đi kèm **bằng chứng kiểm chứng**.

## 5. Darwin đã giải thích được gì và chưa giải thích được gì? (tổng hợp, mở rộng)

SGK chỉ nói ngắn rằng Darwin "chưa biết về cơ chế di truyền và biến dị" (SGK tr. 101). Bảng dưới tổng hợp lại để em không nhầm "quan niệm của Darwin" với kiến thức hiện đại khi làm bài.

| Darwin đã nêu được | Darwin chưa giải thích được |
|---|---|
| Biến dị cá thể là nguyên liệu cho chọn lọc | Biến dị **phát sinh** do đâu (thời đó chưa biết đột biến) |
| Biến dị di truyền được cho đời sau | Biến dị **di truyền theo cơ chế nào** (chưa biết gene, nhiễm sắc thể) |
| Chọn lọc tự nhiên giữ lại cá thể thích nghi, đào thải cá thể kém thích nghi → quần thể thích nghi | — |
| Các loài là hậu duệ có biến đổi của tổ tiên chung, tiến hóa theo kiểu phân nhánh | — |

Những chỗ còn thiếu này được **học thuyết tiến hóa tổng hợp hiện đại** bổ sung vào khoảng những năm 1930, khi kết nối học thuyết của Darwin với di truyền học (SGK tr. 106). Em sẽ học ở Bài 21: tiến hóa lúc đó được hiểu là sự thay đổi **tần số allele** và **tần số kiểu gene** của quần thể.

> [!bay] Từ khóa phân biệt khi làm bài
> Theo **Darwin**, nguyên liệu là **biến dị cá thể**, kết quả là quần thể thích nghi và **loài mới**. Phát biểu có "allele", "tần số allele", "đột biến gene", "vốn gene" là cách nói của **thuyết tổng hợp hiện đại** (Bài 21), không phải của Darwin.

## Dạng bài thi hay gặp

### Dạng 1. Nhận diện bước trong phương pháp nghiên cứu của Darwin

*Nhận biết:* đề mô tả một việc Darwin (hoặc một nhà khoa học, một học sinh) đã làm, hỏi đó là bước quan sát, đề xuất giả thuyết hay kiểm chứng. Có thể hỏi thứ tự đúng của các bước.

*Phương pháp:*
1. Ghi nhận hiện tượng, thu mẫu, so sánh → **quan sát**.
2. Câu mang tính giải thích, phỏng đoán ("cho rằng", "có thể do") → **giả thuyết**.
3. Chủ động tạo điều kiện, làm thí nghiệm, so sánh kết quả với dự đoán → **kiểm chứng**.
4. Thứ tự luôn là quan sát → giả thuyết → kiểm chứng.

> [!vi-du] Ví dụ 7
> Cho các việc sau: (1) Darwin ghi chép rằng chim trên quần đảo Galapagos giống chim ở Nam Mỹ hơn chim ở nơi khác có cùng vĩ độ. (2) Darwin cho rằng cấu trúc lá của cây nắp ấm giúp cây thích nghi với đất nghèo nitrogen. (3) Darwin nhỏ dung dịch nước đường, lipid, protein vào lá cây nắp ấm. (4) Darwin nhận thấy con cùng bố mẹ vẫn khác nhau ở một số đặc điểm. (5) Darwin ngâm hạt giống trong nước biển rồi kiểm tra khả năng nảy mầm. Có bao nhiêu việc thuộc bước kiểm chứng giả thuyết?

> [!goi-y] Gợi ý 1
> Việc nào là chủ động **làm thí nghiệm**?

> [!goi-y] Gợi ý 2
> "Ghi chép", "nhận thấy" là quan sát. "Cho rằng" là giả thuyết.

> [!loi-giai] Lời giải
> - (1), (4): quan sát.
> - (2): đề xuất giả thuyết.
> - (3), (5): làm thí nghiệm kiểm chứng.
>
> Có **2** việc thuộc bước kiểm chứng.

*Bẫy:* nhầm giả thuyết với quan sát khi câu có chữ "nhận thấy … nên cho rằng". Hãy tách câu: phần "nhận thấy" là quan sát, phần "cho rằng" là giả thuyết.

### Dạng 2. Phát biểu đúng/sai về quan niệm của Darwin

*Nhận biết:* các phát biểu về nguyên liệu, cơ chế, kết quả của chọn lọc tự nhiên "theo Darwin", hoặc về chọn lọc nhân tạo.

*Phương pháp:* đối chiếu với 4 ý cốt lõi.
1. Nguyên liệu: **biến dị cá thể di truyền được**, có sẵn trong quần thể.
2. Chọn lọc **không tạo ra** biến dị, chỉ giữ lại và nhân lên biến dị có lợi.
3. Tiêu chí: khả năng **sống sót và sinh sản**.
4. Kết quả: quần thể thích nghi, các loài mới hình thành từ **tổ tiên chung** theo kiểu **phân nhánh**.

Gặp từ "allele", "tần số allele", "đột biến" thì cảnh giác: đó là ngôn ngữ của thuyết hiện đại.

> [!vi-du] Ví dụ 8
> Xét phát biểu: "Theo Darwin, hươu cao cổ có cổ dài vì tổ tiên chúng thường xuyên vươn cổ ăn lá trên cao, cổ dài dần ra và đặc điểm này truyền cho con cháu". Phát biểu này đúng hay sai? Nếu sai, hãy giải thích lại theo Darwin.

> [!goi-y] Gợi ý 1
> Theo Darwin, biến dị cổ dài có sẵn trong quần thể từ trước, hay do con vật "luyện tập" mà có?

> [!goi-y] Gợi ý 2
> Hãy giải thích theo đủ 4 bước: biến dị có sẵn → chọn lọc → sinh sản, di truyền → tích lũy.

> [!loi-giai] Lời giải
> Phát biểu **sai**: đó là lối giải thích "dùng nhiều thì phát triển rồi truyền cho con", không phải của Darwin.
>
> Theo Darwin: trong quần thể hươu tổ tiên đã sẵn có **biến dị cá thể** về chiều dài cổ. Khi thức ăn thấp khan hiếm, những con cổ dài hơn với tới lá cao, **sống sót và sinh sản tốt hơn**, truyền đặc điểm cổ dài cho con. Những con cổ ngắn bị đào thải dần. Qua rất nhiều thế hệ, tần số cá thể cổ dài tăng dần, hình thành loài hươu cao cổ.

*Bẫy:* "Chọn lọc tự nhiên tạo ra biến dị có lợi" (sai). "Chọn lọc nhân tạo dựa trên lợi ích của sinh vật" (sai, dựa trên nhu cầu con người). "Đặc điểm thích nghi là đặc điểm giúp sinh vật sống lâu hơn" (thiếu, phải có sinh sản).

### Dạng 3. Giải thích sự hình thành đặc điểm thích nghi trong thực tế

*Nhận biết:* vi khuẩn kháng thuốc, sâu kháng thuốc trừ sâu, chuột kháng thuốc diệt chuột, bướm đổi màu theo nền… Hỏi giải thích, hoặc cho các bước bị xáo trộn, yêu cầu sắp xếp.

*Phương pháp:* luôn trình bày theo khung 4 bước: **biến dị có sẵn → môi trường chọn lọc (đào thải cá thể không thích nghi) → cá thể thích nghi sống sót, sinh sản, di truyền → tích lũy qua nhiều thế hệ, tần số tăng dần**.

Lời giải mẫu chính là mục 3.4 (vi khuẩn kháng kháng sinh): đổi "vi khuẩn" thành "sâu", "kháng sinh" thành "thuốc trừ sâu" là em có ngay lời giải cho sâu kháng thuốc.

*Bẫy:* đặt "thuốc làm sâu biến đổi thành kháng thuốc" lên đầu. Nhầm rằng quần thể sâu kháng thuốc do **từng con** sâu dần dần quen thuốc.

### Dạng 4. Bài tập số liệu về chọn lọc

*Nhận biết:* cho tỉ lệ sống sót, số con, hoặc tỉ lệ ban đầu của các kiểu hình, hỏi tỉ lệ sau một hay vài thế hệ chọn lọc, hoặc so sánh mức thích nghi.

*Phương pháp:*
1. Chọn một số cá thể ban đầu "đẹp" (100 hoặc 1 000) để dễ tính.
2. Với mỗi kiểu hình: số còn lại = số ban đầu × tỉ lệ sống sót (× số con nếu có).
3. Tỉ lệ kiểu hình sau chọn lọc = số của kiểu đó : tổng số còn lại.
4. Lặp lại cho thế hệ tiếp theo nếu đề yêu cầu.
5. So sánh mức thích nghi: dùng **tỉ lệ sống sót × số con** (Ví dụ 3), không dùng riêng tỉ lệ sống sót.

> [!vi-du] Ví dụ 9
> Một quần thể bướm sống trên thân cây sẫm màu gồm 70% bướm màu sáng và 30% bướm màu sẫm. Chim ăn bướm làm chết 50% bướm sáng và 10% bướm sẫm trước khi chúng sinh sản. Hai loại bướm sống sót sinh số con như nhau, và con có màu giống bố mẹ. Tính tỉ lệ phần trăm bướm sẫm ở thế hệ con (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Giả sử có 100 con bướm: 70 sáng, 30 sẫm. Mỗi loại còn lại bao nhiêu sau khi bị chim ăn?

> [!goi-y] Gợi ý 2
> Số con như nhau, màu giống bố mẹ, nên tỉ lệ ở thế hệ con bằng tỉ lệ trong số bướm sống sót.

> [!loi-giai] Lời giải
> Bước 1: Sáng còn 70 × 0,5 = 35. Sẫm còn 30 × 0,9 = 27.
>
> Bước 2: Tỉ lệ sẫm ở thế hệ con = 27 : (35 + 27) × 100% = 27 : 62 × 100% ≈ **43,5%**.
>
> Kết luận: chỉ sau một thế hệ, tỉ lệ bướm sẫm tăng từ 30% lên khoảng 43,5%. Trên thân cây sẫm, màu sẫm là đặc điểm thích nghi.

*Bẫy:* tính tỉ lệ trên **tổng ban đầu** (27 : 100 = 27%) thay vì trên **tổng số sống sót**. Quên rằng nếu số con khác nhau thì phải nhân thêm số con.

> [!meo]
> Bài nhiều đợt chọn lọc với tỉ lệ sống sót cố định: sau n đợt, tỉ số (kiểu có lợi : kiểu bất lợi) bằng tỉ số ban đầu nhân với (tỉ lệ sống của kiểu có lợi : tỉ lệ sống của kiểu bất lợi)^n^. Ở Ví dụ 5: tỉ số ban đầu 1 : 99, mỗi đợt nhân 10, sau 2 đợt là 100 : 99, tức kháng thuốc ≈ 50,3%.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Phương pháp của Darwin | Quan sát, thu thập dữ liệu → đề xuất giả thuyết → kiểm chứng bằng thực nghiệm |
| Quan sát trong tự nhiên | Chuyến đi tàu Beagle (1831, 5 năm). Biến dị cá thể. Chim sẻ Galapagos có mỏ thích nghi với thức ăn. Sinh sản vượt mức, chỉ ít con sống sót |
| Quan sát vật nuôi, cây trồng | Chọn lọc nhân tạo: giữ biến dị ưa thích, loại biến dị không muốn. Bồ câu từ bồ câu núi. 6 giống rau từ cải hoang dại |
| Chọn lọc tự nhiên | Biến dị di truyền làm tăng sống sót và sinh sản → tần số cá thể mang nó tăng dần qua các thế hệ |
| Đặc điểm thích nghi | Giúp sống sót **và** sinh sản tốt hơn trong một môi trường nhất định |
| Hình thành loài | "Hậu duệ có biến đổi": các nhóm con cháu thích nghi với môi trường khác nhau → loài mới. Tiến hóa phân nhánh, nhiều loài tuyệt chủng |
| Kiểm chứng | Ngâm hạt trong nước biển (hạt vẫn nảy mầm). Cây nắp ấm chỉ tiêu thụ protein |
| Wallace | Độc lập phát hiện chọn lọc tự nhiên. Học thuyết mang tên Darwin vì ông có rất nhiều bằng chứng |
| Hạn chế | Chưa biết nguyên nhân phát sinh biến dị và cơ chế di truyền → được bổ sung ở thuyết tổng hợp (Bài 21) |

**Ba câu then chốt:**
- Chọn lọc tự nhiên **không tạo ra** biến dị, nó **chọn** trong số biến dị có sẵn.
- Thích nghi = sống sót **và** sinh sản tốt hơn.
- Mọi loài là **hậu duệ có biến đổi** của tổ tiên chung, tiến hóa theo **cây phân nhánh**.
