---
title: Học thuyết tiến hóa tổng hợp hiện đại
thoi-gian: 55 phút
muc-tieu:
  - Nêu được khái niệm tiến hóa nhỏ và vì sao quần thể là đơn vị tiến hóa nhỏ.
  - Trình bày và so sánh được năm nhân tố tiến hóa: đột biến, phiêu bạt di truyền, dòng gene, chọn lọc tự nhiên, giao phối không ngẫu nhiên.
  - Tính được sự thay đổi tần số allele do phiêu bạt, dòng gene, chọn lọc trong trường hợp đơn giản.
  - Phát biểu được khái niệm đặc điểm thích nghi, cơ chế hình thành và tính hợp lí tương đối của nó, có ví dụ.
  - Phát biểu được khái niệm loài sinh học, giải thích được cơ chế hình thành loài khác khu vực và cùng khu vực địa lí.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Tiến hóa nhỏ** là sự thay đổi **tần số allele và tần số kiểu gene** của **quần thể** qua các thế hệ. Quần thể là **đơn vị tiến hóa nhỏ**, cá thể thì không.
> 2. Có **5 nhân tố tiến hóa**: đột biến, phiêu bạt di truyền, dòng gene, chọn lọc tự nhiên (đều đổi tần số allele) và giao phối không ngẫu nhiên (chỉ đổi tần số kiểu gene).
> 3. **Chọn lọc tự nhiên** là nhân tố **duy nhất** làm thay đổi tần số allele **theo một hướng xác định**, nên là nhân tố duy nhất tạo ra **đặc điểm thích nghi**.
> 4. Thích nghi chỉ **hợp lí tương đối**: chọn lọc chỉ chọn trong những biến dị có sẵn, mỗi đặc điểm có lợi mặt này thì bất lợi mặt khác, và chỉ có lợi trong một môi trường nhất định.
> 5. **Loài sinh học** cách li sinh sản với nhóm khác. Loài mới hình thành khi dòng gene bị ngăn cản (thường do **cách li địa lí**) và vốn gene phân hóa đến mức cách li sinh sản, hoặc rất nhanh nhờ **lai xa và đa bội hóa** ở thực vật.

> [!nen-tang] Nhớ lại từ Bài 18
> - Vốn gene của quần thể được mô tả bằng **tần số allele** và **tần số kiểu gene**: với x AA + y Aa + z aa thì p = x + y/2.
> - **Hardy – Weinberg**: quần thể lớn, ngẫu phối, không đột biến, không chọn lọc, không di – nhập gene thì tần số allele và kiểu gene không đổi.

## 1. Khái niệm tiến hóa nhỏ

### 1.1. Học thuyết tiến hóa tổng hợp ra đời thế nào?

Darwin (Bài 20) giải thích thích nghi và hình thành loài bằng chọn lọc tự nhiên, nhưng chưa giải thích được **biến dị sinh ra từ đâu** và **di truyền theo cơ chế nào**. Khoảng **những năm 1930**, các nhà khoa học đã **kết nối** thuyết chọn lọc tự nhiên của Darwin với **di truyền học hiện đại** và nhiều ngành khoa học khác. Kết quả là **học thuyết tiến hóa tổng hợp hiện đại** (SGK tr. 106).

Bảng so sánh sau (tổng hợp, ngoài SGK) giúp em không nhầm hai cách nói khi làm bài:

| | Darwin (Bài 20) | Thuyết tiến hóa tổng hợp |
|---|---|---|
| Nguồn biến dị | Biến dị cá thể di truyền được, chưa rõ nguồn gốc và cơ chế di truyền | Đột biến và biến dị tổ hợp (giải thích bằng gene, NST) |
| Chọn lọc tác động lên | Từng cá thể | Kiểu hình của cá thể, nhưng **kết quả** là thay đổi vốn gene của **quần thể** (đơn vị tiến hóa nhỏ) |
| Nhân tố tiến hóa | Chọn lọc tự nhiên | Năm nhân tố: đột biến, phiêu bạt di truyền, dòng gene, chọn lọc tự nhiên, giao phối không ngẫu nhiên |
| Cách mô tả tiến hóa | Tần số **cá thể** mang biến dị có lợi tăng dần | Tần số **allele, kiểu gene** của quần thể thay đổi |

### 1.2. Tiến hóa nhỏ và đơn vị tiến hóa nhỏ

Theo thuyết tiến hóa tổng hợp, **tiến hóa nhỏ** là quá trình **thay đổi tần số allele và tần số kiểu gene của quần thể** từ thế hệ này sang thế hệ khác. Quá trình này diễn ra ở quy mô **quần thể**, kết quả cuối cùng là hình thành **loài mới** (tiến hóa trên loài là tiến hóa lớn, Bài 22).

**Vì sao quần thể là đơn vị tiến hóa nhỏ?**

- Các quần thể cùng loài sống ở môi trường khác nhau nên mỗi quần thể có **vốn gene riêng**, tồn tại **lâu dài** qua nhiều thế hệ để tích lũy thay đổi.
- Các cá thể trong quần thể giao phối với nhau nên allele được truyền và tổ hợp lại trong cả quần thể.

**Vì sao cá thể không phải đơn vị tiến hóa?** Mỗi cá thể mang **một kiểu gene cố định** suốt đời và không tồn tại qua nhiều thế hệ. Cái thay đổi qua thời gian là **tỉ lệ** các kiểu gene trong cả nhóm, tức là ở cấp quần thể.

> [!bay]
> "Chọn lọc tự nhiên tác động lên cá thể nên cá thể là đơn vị tiến hóa" là **sai**. Chọn lọc tác động **trực tiếp** lên kiểu hình cá thể, nhưng **kết quả** (tần số allele thay đổi) chỉ thấy ở **quần thể**. Loài cũng không phải đơn vị tiến hóa nhỏ, vì loài gồm nhiều quần thể ít trao đổi gene với nhau.

## 2. Các nhân tố tiến hóa

**Nhân tố tiến hóa** là những nhân tố làm **thay đổi tần số allele và/hoặc tần số kiểu gene** của quần thể (SGK tr. 106). Tần số allele đổi thì tần số kiểu gene đổi theo, nhưng giao phối không ngẫu nhiên chỉ đổi tần số kiểu gene mà **không** đổi tần số allele.

Cách dễ nhớ: mỗi nhân tố là **một điều kiện Hardy – Weinberg bị phá vỡ**.

| Điều kiện Hardy – Weinberg | Khi bị phá vỡ → nhân tố tiến hóa |
|---|---|
| Không có đột biến | **Đột biến** |
| Quần thể có kích thước lớn | **Phiêu bạt di truyền** (quần thể nhỏ) |
| Quần thể cách li, không di – nhập gene | **Dòng gene** |
| Các cá thể sống và sinh sản như nhau | **Chọn lọc tự nhiên** |
| Ngẫu phối | **Giao phối không ngẫu nhiên** |

> [!bay] Tên gọi mới và cũ
> SGK mới dùng **phiêu bạt di truyền** (sách cũ: "các yếu tố ngẫu nhiên") và **dòng gene** (sách cũ: "di – nhập gene"). Đề thi có thể dùng cả hai cách gọi.
> Còn **ngẫu phối** thì **không** phải nhân tố tiến hóa, vì nó giữ nguyên tần số allele và kiểu gene.

### 2.1. Đột biến

**Đột biến gene** làm xuất hiện **allele mới**, hoặc biến allele này thành allele khác (A → a hoặc a → A), nên làm thay đổi tần số allele của quần thể.

**Đột biến làm thay đổi tần số allele rất chậm.** Tần số đột biến tự nhiên của một gene chỉ khoảng 10^−6^ đến 10^−4^ mỗi thế hệ. Ví dụ, allele A có tần số 0,8 và bị đột biến thành a với tần số 10^−4^ thì sau một thế hệ, tần số A chỉ còn 0,8 × (1 − 0,0001) = 0,79992. Gần như không đổi.

**Nhưng đột biến lại cực kì quan trọng**, vì **mỗi cá thể có rất nhiều gene** và **quần thể có rất nhiều cá thể**. Ước lượng (số liệu giả định): mỗi giao tử mang 2 × 10^4^ gene, mỗi gene đột biến với tần số 10^−5^, thì mỗi giao tử mang trung bình 0,2 đột biến mới. Quần thể 10^5^ cá thể (2 × 10^5^ giao tử tạo nên chúng) sẽ có khoảng **40 000** đột biến mới mỗi thế hệ.

Như vậy, đột biến liên tục **làm phong phú vốn gene**, cung cấp **nguồn nguyên liệu sơ cấp** cho tiến hóa. Từ các allele đột biến, giao phối tạo ra vô số **biến dị tổ hợp** (nguyên liệu thứ cấp).

### 2.2. Phiêu bạt di truyền

**Phiêu bạt di truyền** là sự thay đổi tần số allele của quần thể do các **yếu tố ngẫu nhiên** gây ra (SGK tr. 107). Yếu tố ngẫu nhiên có thể là bão, lũ lụt, hỏa hoạn, động đất... làm chết các cá thể **bất kể** chúng mang gene có lợi hay có hại.

Hình dung túi bi có 70% bi xanh: bốc 50 viên thì tỉ lệ xanh gần 70%, nhưng bốc 5 viên rất có thể chỉ được 2 xanh. Mẫu càng nhỏ, tỉ lệ càng "lệch". Những cá thể sống sót sau thiên tai chính là một "mẫu bốc ngẫu nhiên" từ quần thể cũ.

**Đặc điểm:** thay đổi tần số allele **không theo hướng xác định**, có thể **đột ngột, rất mạnh**; có thể làm **mất hẳn** một allele (kể cả allele có lợi), nên làm **giảm đa dạng di truyền**. Quần thể **càng nhỏ**, tác động **càng mạnh**.

**Hai tình huống điển hình** (SGK tr. 107, Hình 21.1):

1. **Hiệu ứng kẻ sáng lập** (ngoài tên gọi SGK): một **nhóm nhỏ** cá thể phát tán đến nơi mới và lập nên quần thể mới. Nhóm nhỏ này "tình cờ" mang tần số allele khác quần thể gốc.
2. **Hiệu ứng thắt cổ chai** (ngoài tên gọi SGK): thiên tai làm chết **hàng loạt**, chỉ còn **một số ít** sống sót. Quần thể sau đó phục hồi kích thước nhưng vốn gene đã khác.

![Hình 1. Phiêu bạt di truyền: mỗi lần quần thể bị "thu nhỏ" (phát tán ra đảo, thiên tai), tần số allele thay đổi ngẫu nhiên và có thể mất hẳn một allele](hinh-1-phieu-bat.svg)

> [!vi-du] Ví dụ 1
> Một quần thể hoa có 1 000 cây: 490 cây AA, 420 cây Aa, 90 cây aa. Một trận lũ quét làm chết gần hết, chỉ còn 10 cây sống sót gồm 1 cây AA, 4 cây Aa, 5 cây aa (khả năng sống sót không liên quan đến kiểu gene). Tính tần số allele A trước và sau lũ. Nhân tố tiến hóa nào đã tác động?

> [!goi-y] Gợi ý 1
> Tổng số allele = 2 × số cây. Đếm số allele A: cây AA góp 2, cây Aa góp 1.

> [!goi-y] Gợi ý 2
> Khả năng sống sót "không liên quan đến kiểu gene" nghĩa là không có chọn lọc. Thay đổi tần số allele xảy ra một cách ngẫu nhiên, đột ngột thì đó là nhân tố nào?

> [!loi-giai] Lời giải
> Bước 1: Trước lũ, số allele A = 490 × 2 + 420 = 1 400 trên tổng 2 000 allele → p = **0,7**.
>
> Bước 2: Sau lũ, số allele A = 1 × 2 + 4 = 6 trên tổng 20 allele → p = **0,3**.
>
> Bước 3: Tần số allele A giảm từ 0,7 xuống 0,3 chỉ sau một trận lũ, và việc sống sót là may rủi, không phụ thuộc kiểu gene. Đây là tác động của **phiêu bạt di truyền**.
>
> Nhận xét: allele A không hề "kém thích nghi" mà vẫn giảm mạnh. Đó là điểm khác cơ bản với chọn lọc tự nhiên.

> [!ung-dung]
> Quần thể của các loài quý hiếm còn rất ít cá thể (như voọc mũi hếch) dễ bị phiêu bạt di truyền làm mất allele. Vì vậy, các chương trình bảo tồn cố gắng **tăng số lượng cá thể** và trao đổi cá thể giữa các khu bảo tồn.

### 2.3. Dòng gene

**Dòng gene** (di – nhập gene) là sự di chuyển allele **vào** hoặc **ra khỏi** quần thể nhờ sự di chuyển của các **cá thể hữu thụ** hoặc **giao tử** của chúng (ví dụ hạt phấn bay theo gió sang quần thể khác).

Dòng gene thay đổi tần số allele **không theo một hướng xác định**. Mức độ thay đổi phụ thuộc hai yếu tố (SGK tr. 107):

1. **Sự chênh lệch tần số allele** giữa quần thể cho và quần thể nhận: chênh lệch càng lớn, thay đổi càng mạnh.
2. **Hệ số nhập cư m**: tỉ số giữa **số cá thể nhập cư** và **tổng số cá thể của quần thể nhận sau khi nhập cư**. m càng lớn, thay đổi càng mạnh.

**Công thức tính (mở rộng, rất hay dùng trong đề thi).** Sau khi nhập cư, quần thể mới gồm hai phần: phần (1 − m) là cá thể cũ với tần số p, phần m là cá thể nhập cư với tần số P. Tần số allele mới là **trung bình có trọng số**:

$$p' = (1-m)\,p + m\,P \quad\Longleftrightarrow\quad \Delta p = p' - p = m\,(P - p)$$

Công thức thứ hai thể hiện đúng hai yếu tố SGK nêu: **m** và **chênh lệch (P − p)**.

> [!vi-du] Ví dụ 2
> Một quần thể chuột trên đảo có 900 con, tần số allele A là 0,2. Có 100 con chuột từ đất liền (tần số allele A là 0,8) theo thuyền lên đảo và hòa nhập vào quần thể. Tính hệ số nhập cư và tần số allele A của quần thể trên đảo sau nhập cư.

> [!goi-y] Gợi ý 1
> Mẫu số của m là tổng số cá thể **sau** khi nhập cư: 900 + 100.

> [!goi-y] Gợi ý 2
> p' = (1 − m) × 0,2 + m × 0,8. 

> [!loi-giai] Lời giải
> Bước 1: m = 100/(900 + 100) = **0,1** (lấy 100/900 ≈ 0,11 là sai mẫu số).
>
> Bước 2: p' = 0,9 × 0,2 + 0,1 × 0,8 = 0,18 + 0,08 = **0,26**.
>
> Kiểm tra bằng cách đếm: (360 + 160)/2 000 = 0,26.

Khi mang **allele mới** vào, dòng gene **làm tăng** đa dạng di truyền của quần thể nhận. Mặt khác, dòng gene làm vốn gene các quần thể **giống nhau dần**, nên **cản trở** sự phân hóa thành loài mới (mục 4.2).

### 2.4. Chọn lọc tự nhiên

Dưới góc nhìn của thuyết tiến hóa tổng hợp, **chọn lọc tự nhiên** là quá trình **làm tăng dần** tần số allele và kiểu gene quy định **đặc điểm thích nghi**, đồng thời **làm giảm dần** tần số allele và kiểu gene quy định đặc điểm **không thích nghi** (SGK tr. 107–108).

**Chọn lọc tác động vào đâu?** Các yếu tố môi trường (tác nhân chọn lọc: kẻ thù, khí hậu, thức ăn, kháng sinh...) tác động **trực tiếp lên kiểu hình** của cá thể. Cá thể có kiểu hình sống sót và sinh sản tốt hơn để lại nhiều con hơn, qua đó chọn lọc **gián tiếp** làm thay đổi tần số kiểu gene và allele của quần thể.

**Vì sao chọn lọc chống kiểu hình trội làm đổi tần số allele nhanh hơn chống kiểu hình lặn?** (SGK hỏi đúng ý này.)

- Allele **trội** biểu hiện ra kiểu hình cả ở thể dị hợp Aa, nên chọn lọc "nhìn thấy" **mọi** allele A. Nếu kiểu hình trội gây chết trước tuổi sinh sản, allele A bị loại **ngay sau một thế hệ**.
- Allele **lặn** chỉ biểu hiện ở thể đồng hợp aa. Phần lớn allele a "ẩn" trong cá thể Aa, nhất là khi a đã hiếm, nên tần số a giảm **rất chậm** và **không bị loại hết** chỉ bằng chọn lọc.

**Cách tính khi chọn lọc loại bỏ hoàn toàn kiểu gene aa** (mở rộng, ngoài SGK). Quần thể ngẫu phối có tần số allele a là q (cấu trúc p^2^ AA : 2pq Aa : q^2^ aa), các cá thể aa chết hoặc không sinh sản được. Chỉ còn AA và Aa sinh sản, nên tần số allele a mới (q~mới~, viết gọn là q') là:

$$q' = \frac{pq}{p^2 + 2pq} = \frac{q}{1+q}$$

Lặp lại qua n thế hệ (mỗi thế hệ ngẫu phối rồi loại aa):

$$q_n = \frac{q_0}{1 + n\,q_0}$$

Vì sao? Lấy nghịch đảo: 1/q~mới~ = (1 + q)/q = 1/q + 1. Mỗi thế hệ, 1/q **tăng thêm đúng 1**, nên sau n thế hệ 1/q~n~ = 1/q~0~ + n.

![Hình 2. Chọn lọc chống kiểu hình trội loại allele A chỉ sau 1 thế hệ, còn chọn lọc chống kiểu hình lặn làm tần số allele a giảm rất chậm (xuất phát cùng tần số 0,5)](hinh-2-chon-loc.svg)

> [!vi-du] Ví dụ 3
> Một quần thể thú ngẫu phối có cấu trúc 0,25 AA : 0,5 Aa : 0,25 aa. Allele a ở trạng thái đồng hợp gây chết trước tuổi sinh sản.
>
> a) Tính tần số allele a ở F~1~ và tỉ lệ cá thể aa mới sinh ở F~1~.
>
> b) Sau bao nhiêu thế hệ thì tần số allele a giảm xuống 0,1?
>
> c) Nếu thay vào đó, kiểu hình **trội** (AA và Aa) gây chết trước tuổi sinh sản thì tần số allele A ở F~1~ là bao nhiêu?

> [!goi-y] Gợi ý 1
> Bỏ aa, chia lại 0,25 AA và 0,5 Aa cho tổng 0,75 rồi tính q.

> [!goi-y] Gợi ý 2
> Câu b: nhớ "1/q tăng thêm 1 mỗi thế hệ".

> [!loi-giai] Lời giải
>
> a) Cá thể sinh sản: AA = 0,25/0,75 = 1/3; Aa = 0,5/0,75 = 2/3. Tần số a = (2/3)/2 = **1/3** (đúng bằng q/(1 + q) = 0,5/1,5). Ngẫu phối → F~1~ có aa = (1/3)^2^ = **1/9** ≈ 11,1%.
>
> b) 1/q~0~ = 2, cần 1/q~n~ = 10. Mỗi thế hệ tăng 1 nên n = 10 − 2 = **8 thế hệ**.
>
> c) Chỉ cá thể aa sinh sản → F~1~ toàn aa, tần số A = **0**.
>
> So sánh b và c: cùng xuất phát từ 0,5, chọn lọc chống allele trội loại hết A sau 1 thế hệ, chống allele lặn cần 8 thế hệ mới đưa a xuống 0,1.

**Áp lực chọn lọc.** Môi trường thay đổi càng mạnh (áp lực chọn lọc càng cao) thì tần số allele thay đổi càng nhanh. Đề thi (mở rộng) hay cho áp lực chọn lọc dưới dạng **giá trị thích nghi tương đối** (w) của từng kiểu gene, ví dụ w(aa) = 0,6 nghĩa là cá thể aa để lại số con bằng 60% cá thể AA (xem Dạng 2).

**Chọn lọc tự nhiên và đa dạng di truyền.** Vì đẩy tần số allele **theo một hướng**, chọn lọc thường làm **giảm** đa dạng di truyền (nghèo vốn gene). Tuy nhiên, khi **cá thể dị hợp thích nghi nhất**, chọn lọc giữ lại thể dị hợp nên **duy trì** được cả hai allele.

> [!em-co-biet] Hồng cầu hình liềm và sốt rét
> Người đồng hợp về allele hồng cầu hình liềm (HbS) thiếu máu nặng, người đồng hợp bình thường dễ chết vì sốt rét, còn người **dị hợp** thiếu máu nhẹ và **kháng sốt rét** tốt. Ở vùng nhiều sốt rét, chọn lọc ưu tiên người dị hợp nên allele HbS vẫn duy trì ở tần số khá cao.

### 2.5. Giao phối không ngẫu nhiên

**Giao phối không ngẫu nhiên** gồm hai kiểu:

- **Giao phối cận huyết** (giao phối gần, tự thụ phấn): các cá thể có họ hàng gần giao phối với nhau. Họ hàng càng gần, đồng hợp tăng càng nhanh. Em đã học cách tính ở Bài 18 (mục 3).
- **Giao phối có lựa chọn**: cá thể chọn bạn tình theo kiểu hình, thường là chọn cá thể có kiểu hình **giống mình** (ví dụ cây cao giao phấn chủ yếu với cây cao, cây thấp với cây thấp).

Cả hai kiểu đều **không làm thay đổi tần số allele** nhưng làm thay đổi **tần số kiểu gene** theo hướng **tăng đồng hợp, giảm dị hợp**. Vì vậy, giao phối không ngẫu nhiên **luôn làm giảm** sự đa dạng di truyền của quần thể.

**Vì sao vẫn là nhân tố tiến hóa?** Vì nó làm thay đổi tần số kiểu gene. Ngoài ra, khi tăng đồng hợp, allele lặn có hại "lộ ra" ở kiểu hình aa, tạo điều kiện cho chọn lọc tự nhiên đào thải.

> [!vi-du] Ví dụ 4
> Người ta theo dõi cấu trúc di truyền của một quần thể thực vật qua 3 thế hệ:
>
> | Thế hệ | AA | Aa | aa |
> |---|---|---|---|
> | F~1~ | 0,36 | 0,48 | 0,16 |
> | F~2~ | 0,48 | 0,24 | 0,28 |
> | F~3~ | 0,54 | 0,12 | 0,34 |
>
> Quần thể đang chịu tác động chủ yếu của nhân tố tiến hóa nào?

> [!goi-y] Gợi ý 1
> Tính tần số allele A ở cả ba thế hệ. Có thay đổi không?

> [!goi-y] Gợi ý 2
> Tần số allele không đổi, nhưng tỉ lệ dị hợp thay đổi theo quy luật gì?

> [!loi-giai] Lời giải
> Bước 1: p(F~1~) = 0,36 + 0,24 = 0,6; p(F~2~) = 0,48 + 0,12 = 0,6; p(F~3~) = 0,54 + 0,06 = 0,6. Tần số allele **không đổi**.
>
> Bước 2: Dị hợp giảm một nửa mỗi thế hệ (0,48 → 0,24 → 0,12), hai loại đồng hợp tăng đều nhau.
>
> Kết luận: quần thể chịu tác động của **giao phối không ngẫu nhiên** (đúng kiểu tự thụ phấn).

### 2.6. So sánh năm nhân tố tiến hóa

| Nhân tố | Đổi tần số allele? | Có hướng xác định? | Ảnh hưởng đến đa dạng di truyền | Ghi nhớ thêm |
|---|---|---|---|---|
| Đột biến | Có, rất chậm | Không | Tăng (tạo allele mới) | Nguyên liệu sơ cấp |
| Phiêu bạt di truyền | Có, có thể rất mạnh, đột ngột | Không | Giảm | Mạnh ở quần thể nhỏ, có thể loại cả allele có lợi |
| Dòng gene | Có | Không | Có thể tăng (mang allele mới vào) | Phụ thuộc m và chênh lệch tần số |
| Chọn lọc tự nhiên | Có | **Có** | Thường giảm (có khi duy trì) | **Duy nhất** tạo thích nghi |
| Giao phối không ngẫu nhiên | **Không** (chỉ đổi kiểu gene) | Tăng đồng hợp | Luôn giảm | Gồm cận huyết và có lựa chọn |

> [!bay]
> - "Nhân tố có thể làm **xuất hiện allele mới** trong quần thể" có **hai** đáp án đúng: đột biến (tạo allele mới thật sự) và dòng gene (mang allele từ quần thể khác vào). Đọc kĩ đề hỏi "tạo ra" hay "làm xuất hiện trong quần thể".
> - Chọn lọc tự nhiên **không tạo ra** kiểu gene thích nghi, nó chỉ **sàng lọc và giữ lại** những kiểu gene đã có.

## 3. Hình thành đặc điểm thích nghi

### 3.1. Khái niệm

**Đặc điểm thích nghi** là đặc điểm **di truyền** giúp sinh vật **tăng khả năng sống sót và khả năng sinh sản** trong một môi trường nhất định (SGK tr. 108). Ví dụ: màu lông trắng của gấu Bắc Cực, gai xương rồng, tính kháng thuốc của vi khuẩn khi môi trường có kháng sinh.

**Đo mức độ thích nghi bằng gì?** Bằng **giá trị thích nghi**: tổng số con mà cá thể sinh ra trong suốt đời và **sống sót được đến khi sinh sản**. Cá thể để lại nhiều con (sống đến tuổi sinh sản) hơn là cá thể thích nghi hơn.

> [!bay]
> - Thích nghi **không** đo bằng tuổi thọ hay sức khỏe. Cây vân sam sống hàng trăm, hàng nghìn năm nhưng nếu chỉ để lại số cây con bằng một cây sống một năm thì hai cây **thích nghi như nhau** (SGK tr. 108).
> - Đặc điểm thích nghi phải **di truyền được**. Một con chó được huấn luyện tránh xe cộ không phải là "đặc điểm thích nghi" theo nghĩa tiến hóa.

### 3.2. Cơ chế hình thành đặc điểm thích nghi

Cơ chế gồm ba bước (SGK tr. 108):

1. **Đột biến** xuất hiện ngẫu nhiên, **trước** khi môi trường thay đổi, cung cấp nguyên liệu.
2. **Chọn lọc tự nhiên giữ lại** những cá thể mang đột biến làm tăng khả năng sống sót và sinh sản.
3. Qua các thế hệ, số cá thể mang đột biến có lợi **tăng dần** đến khi **phổ biến** trong quần thể.

**Ví dụ (SGK tr. 109):** ngay khi môi trường **chưa có** penicillin, một số rất ít vi khuẩn đã ngẫu nhiên mang đột biến kháng thuốc. Khi có penicillin, chúng sống sót và sinh sản nhanh. Khi **hầu hết** vi khuẩn đều kháng thuốc thì tính kháng penicillin mới là đặc điểm thích nghi.

Vì vậy, **chọn lọc tự nhiên là nhân tố tiến hóa duy nhất** làm một đặc điểm trở nên phổ biến *vì nó có lợi* (tạo đặc điểm thích nghi). Phiêu bạt cũng có thể làm một allele phổ biến, nhưng do may rủi.

> [!vi-du] Ví dụ 5
> Một bạn học sinh nói: "Thuốc trừ sâu đã gây ra đột biến kháng thuốc ở sâu tơ, nên phun thuốc càng nhiều thì sâu càng kháng thuốc." Câu nói này sai ở đâu? Hãy giải thích đúng vì sao sâu tơ ở ruộng phun thuốc nhiều năm lại kháng thuốc mạnh.

> [!goi-y] Gợi ý 1
> Allele kháng thuốc có sẵn trong quần thể **trước** hay **sau** khi phun thuốc?

> [!goi-y] Gợi ý 2
> Thuốc trừ sâu đóng vai trò gì: tác nhân gây đột biến hay tác nhân chọn lọc?

> [!loi-giai] Lời giải
> Sai ở chỗ coi thuốc là **nguyên nhân gây đột biến**. Đột biến kháng thuốc đã xuất hiện **ngẫu nhiên** trong quần thể sâu từ trước, với tần số rất thấp.
>
> Thuốc trừ sâu là **tác nhân chọn lọc**: giết sâu mẫn cảm, còn sâu mang allele kháng thuốc sống sót và sinh sản. Mỗi lần phun là một lần chọn lọc, tần số allele kháng tăng dần, sau nhiều năm hầu hết sâu đều kháng thuốc. Phun càng nhiều thì **áp lực chọn lọc** càng mạnh nên quần thể kháng thuốc hình thành càng nhanh, chứ không phải thuốc tạo ra nhiều đột biến hơn.

> [!ung-dung]
> Vì vậy chỉ **dùng kháng sinh khi cần và theo đúng chỉ định**: dùng bừa bãi tạo áp lực chọn lọc liên tục, làm vi khuẩn kháng thuốc phổ biến. Trong nông nghiệp, người ta **luân phiên** các loại thuốc trừ sâu để làm chậm quá trình này.

### 3.3. Tính tương đối của đặc điểm thích nghi

Mọi đặc điểm thích nghi chỉ **hợp lí tương đối**. Có ba lí do chính (SGK tr. 109):

1. **Chọn lọc chỉ chọn trong những biến dị có sẵn.** Chọn lọc không thể "thiết kế" cấu trúc mới hoàn hảo, nó chỉ giữ lại biến dị **tốt nhất trong số những gì đang có**. Ví dụ dơi có xương chi trước giống thú khác, nên chọn lọc chỉ giữ lại những cá thể có màng da nối các ngón chi trước để bay, chứ không thể tạo ra cánh lông vũ như chim.
2. **Đặc điểm thích nghi là sự dung hòa.** Một đặc điểm có lợi mặt này thường bất lợi mặt khác. Ví dụ chim công đực có bộ lông sặc sỡ hấp dẫn con cái (tăng sinh sản) nhưng cũng dễ bị kẻ săn mồi phát hiện (giảm sống sót).
3. **Chỉ có lợi trong một môi trường nhất định.** Khi môi trường thay đổi, đặc điểm từng có lợi có thể trở nên vô dụng hoặc có hại. Ví dụ vi khuẩn kháng thuốc có thể sinh trưởng chậm hơn vi khuẩn thường khi môi trường **không có** kháng sinh.

Vì vậy, chọn lọc tự nhiên **không thể** tạo ra một loài sinh vật thích nghi với **mọi** điều kiện môi trường.

> [!bay]
> Câu hỏi "ví dụ nào thể hiện tính tương đối của thích nghi": chọn ví dụ có **hai mặt** hoặc **đổi môi trường thì hết có lợi** (bướm màu sáng khó bị phát hiện trên thân cây sáng màu nhưng dễ bị chim bắt khi thân cây bị muội than làm sẫm). Ví dụ chỉ nói một mặt có lợi ("gấu Bắc Cực có lông dày giữ ấm") là ví dụ về **đặc điểm thích nghi**, không phải tính tương đối.

## 4. Loài và cơ chế hình thành loài

### 4.1. Khái niệm loài sinh học và cách li sinh sản

Có nhiều khái niệm về loài, nhưng được dùng nhiều nhất là **khái niệm loài sinh học** của nhà tiến hóa học **Ernst Mayr**. Diễn đạt lại (SGK tr. 109):

*Loài sinh học là một hoặc một nhóm quần thể gồm các cá thể **có khả năng giao phối với nhau trong tự nhiên**, sinh ra **đời con hữu thụ**, và **cách li sinh sản** với các nhóm quần thể khác.*

**Cách li sinh sản** là những đặc điểm sinh học **ngăn cản** các cá thể giao phối với nhau dù sống cùng nơi, hoặc có giao phối nhưng **không sinh ra đời con hữu thụ**. Ví dụ ngựa cái lai với lừa đực sinh ra con la khỏe mạnh nhưng **bất thụ**, nên ngựa và lừa là hai loài khác nhau.

**Các dạng cách li sinh sản (mở rộng, ngoài SGK, đề thi hay hỏi).** Người ta chia theo mốc **hợp tử**:

| Cách li trước hợp tử (ngăn tạo hợp tử) | Cách li sau hợp tử (có hợp tử nhưng con lai không hữu thụ) |
|---|---|
| **Nơi ở**: sống cùng vùng nhưng khác sinh cảnh nên ít gặp nhau | Hợp tử lai **chết** sớm hoặc con lai sức sống kém |
| **Tập tính**: khác tiếng kêu, điệu múa, mùi... nên không nhận ra bạn tình | Con lai sống được nhưng **bất thụ** (con la) |
| **Mùa vụ**: ra hoa, sinh sản vào thời gian khác nhau | Con lai F~1~ hữu thụ nhưng F~2~ trở đi suy thoái |
| **Cơ học**: cấu tạo cơ quan sinh sản không tương hợp | |
| **Giao tử**: tinh trùng không thụ tinh được với trứng | |

> [!vi-du] Ví dụ 6
> Xét các trường hợp sau:
>
> (1) Hai loài ếch sống chung một ao nhưng một loài sinh sản vào đầu mùa mưa, loài kia vào cuối mùa mưa.
>
> (2) Lai cừu với dê tạo được hợp tử nhưng hợp tử chết ngay ở giai đoạn phôi sớm.
>
> (3) Hai loài đom đóm phát sáng theo nhịp khác nhau, con cái chỉ đáp lại nhịp của con đực cùng loài.
>
> (4) Ngựa vằn lai với ngựa nhà sinh ra con lai bất thụ.
> Trường hợp nào là cách li trước hợp tử, trường hợp nào là cách li sau hợp tử?

> [!goi-y] Gợi ý 1
> Hỏi: đã tạo được **hợp tử** chưa? Chưa giao phối hoặc giao phối mà không thụ tinh được → trước hợp tử.

> [!loi-giai] Lời giải
> - (1): cách li **mùa vụ**, (3): cách li **tập tính** → đều là cách li **trước hợp tử**.
> - (2): có hợp tử nhưng chết, (4): con lai sống nhưng bất thụ → đều là cách li **sau hợp tử**.


### 4.2. Hình thành loài khác khu vực địa lí

**Điều kiện tiên quyết** để cách li sinh sản xuất hiện là phải có **trở ngại ngăn cản dòng gene** giữa các quần thể (SGK tr. 110), vì dòng gene liên tục "trộn đều" vốn gene khiến các quần thể không thể khác biệt đủ nhiều. Dòng gene bị ngăn cản càng triệt để và càng lâu thì khả năng hình thành loài mới càng cao.

Trong tự nhiên, trở ngại triệt để nhất thường là **cách li địa lí**: núi, sông, biển, sa mạc chia cắt quần thể. Vì vậy, **phần lớn** loài mới được hình thành theo con đường **khác khu vực địa lí**.

**Các bước của quá trình** (xem Hình 3):

1. Quần thể gốc bị chia cắt bởi trở ngại địa lí (hoặc một nhóm cá thể di cư ra đảo xa) → **dòng gene bị ngăn cản**.
2. Ở mỗi quần thể, các **nhân tố tiến hóa** (đột biến, phiêu bạt di truyền, chọn lọc tự nhiên...) tác động **độc lập**, trong điều kiện môi trường khác nhau → **vốn gene phân hóa** dần.
3. Khác biệt vốn gene **càng nhiều** và **càng lâu** thì càng dễ xuất hiện các trở ngại sinh học ngăn cản thụ tinh hoặc tạo con lai hữu thụ, tức **cách li sinh sản**. Các trở ngại này thường xuất hiện **một cách ngẫu nhiên**.
4. Khi đã cách li sinh sản → **loài mới**. Dù trở ngại địa lí mất đi, hai nhóm gặp lại cũng không trao đổi gene được nữa.

![Hình 3. Hình thành loài khác khu vực địa lí: trở ngại địa lí ngăn dòng gene, các nhân tố tiến hóa phân hóa vốn gene, cuối cùng xuất hiện cách li sinh sản](hinh-3-khac-khu-vuc.svg)

> [!bay]
> - Ngăn cản dòng gene (cách li địa lí) là điều kiện **cần nhưng chưa đủ**. Cách li địa lí **không trực tiếp** tạo ra kiểu gene mới hay biến đổi cơ thể sinh vật, chính các **nhân tố tiến hóa** làm vốn gene phân hóa.
> - Hai quần thể khác nhau về hình thái nhưng vẫn giao phối sinh con hữu thụ thì vẫn **cùng loài**.
> - Con đường này **chậm**, qua rất nhiều thế hệ, gặp ở cả động vật lẫn thực vật.

### 4.3. Hình thành loài cùng khu vực địa lí

Khi các quần thể sống **cùng một khu vực**, dòng gene giữa chúng xảy ra thường xuyên, nên cách li sinh sản **khó** xuất hiện hơn. Nhưng một khi đã xuất hiện, loài mới hình thành **rất nhanh**, có khi chỉ sau **một vài thế hệ** (SGK tr. 110).

Con đường điển hình là **đa bội hóa** (xem lại Bài 12 về đột biến số lượng NST):

**a) Tự đa bội.** Trong quần thể cây lưỡng bội (2n), đột biến tạo ra cây tứ bội (4n). Nếu cây 4n sinh sản được, tạo ra quần thể 4n, thì đó là **loài mới**. Vì sao? Cây 4n lai với cây 2n cho con lai **tam bội (3n)**, mà cây 3n **bất thụ** (khi giảm phân, các NST không chia đều được thành giao tử cân bằng). Vậy giữa 4n và 2n đã có **cách li sinh sản sau hợp tử**.

**b) Lai xa kết hợp đa bội hóa (thể song nhị bội).** Hai loài thực vật có họ hàng gần lai với nhau:

- Con lai mang **bộ NST đơn bội của hai loài** (n~A~ + n~B~). Các NST không có cặp tương đồng, không tiếp hợp được khi giảm phân → con lai **bất thụ**.
- Nếu con lai được **đa bội hóa** (gấp đôi bộ NST) thành 2n~A~ + 2n~B~, mỗi NST đều có cặp tương đồng → giảm phân bình thường → **hữu thụ**. Đây là **loài mới**, cách li sinh sản với cả hai loài bố mẹ.

**Ví dụ lúa mì hiện đại** (SGK Hình 21.3) hình thành qua **hai lần** lai xa và đa bội hóa.

![Hình 4. Lúa mì hiện đại Triticum aestivum (6n = 42) hình thành qua hai lần lai xa và đa bội hóa. Mỗi chữ A, B, D là một bộ NST đơn bội 7 chiếc](hinh-4-lua-mi.svg)

Đọc Hình 4 theo hai bước: lúa mì hoang dại AA (n = 7) lai với cỏ dại BB (n = 7) cho con lai AB (14 NST) bất thụ, đa bội hóa thành *T. turgidum* AABB (28 NST); loài này lai với cỏ dại DD (n = 7) cho con lai ABD (21 NST) bất thụ, đa bội hóa thành *T. aestivum* AABBDD (42 NST).

> [!bay]
> - Con lai xa **chưa** đa bội hóa là **bất thụ**, chưa phải loài mới. Loài mới chỉ xuất hiện **sau** khi đa bội hóa.
> - Thể song nhị bội 2n~A~ + 2n~B~ khác thể tứ bội 4n: song nhị bội mang **hai bộ NST lưỡng bội của hai loài khác nhau**.
> - Hình thành loài cùng khu vực địa lí **hay gặp ở thực vật** hơn động vật (SGK tr. 110). Lí do (ngoài SGK): nhiều loài cây tự thụ phấn hoặc sinh sản sinh dưỡng được nên cây đa bội đầu tiên vẫn nhân lên thành quần thể, còn ở động vật đa bội thường gây rối loạn xác định giới tính và gây chết.

> [!ung-dung]
> **Dưa hấu tam bội không hạt** được tạo bằng cách lai cây 4n với cây 2n: con lai 3n bất thụ nên hầu như không có hạt. Đây cũng là minh chứng cho cách li sinh sản giữa thể 4n và thể 2n.

## Dạng bài thi hay gặp

### Dạng 1. Đọc bảng số liệu, nhận diện nhân tố tiến hóa

*Nhận biết:* bảng cấu trúc di truyền qua nhiều thế hệ, hỏi "quần thể chịu tác động của nhân tố nào".

*Phương pháp:*
1. Tính tần số allele ở từng thế hệ.
2. Tần số allele **không đổi**, dị hợp giảm, đồng hợp tăng → **giao phối không ngẫu nhiên**.
3. Tần số allele **đổi dần theo một hướng**, kiểu hình nào đó giảm đều qua các thế hệ → **chọn lọc tự nhiên**.
4. Tần số allele **đổi đột ngột, mạnh** (thường kèm số lượng cá thể giảm mạnh hoặc thiên tai), không theo hướng thích nghi → **phiêu bạt di truyền**.
5. Có cá thể từ nơi khác đến, tần số allele "kéo" về phía quần thể cho → **dòng gene**.

> [!vi-du] Ví dụ 7
> Theo dõi hai quần thể của cùng một loài thực vật qua 4 thế hệ:
>
> | Thế hệ | Quần thể I (AA : Aa : aa) | Quần thể II (AA : Aa : aa) |
> |---|---|---|
> | F~1~ | 0,25 : 0,50 : 0,25 | 0,25 : 0,50 : 0,25 |
> | F~2~ | 0,36 : 0,48 : 0,16 | 0,25 : 0,50 : 0,25 |
> | F~3~ | 0,49 : 0,42 : 0,09 | 0,64 : 0,32 : 0,04 |
> | F~4~ | 0,64 : 0,32 : 0,04 | 0,64 : 0,32 : 0,04 |
>
> Mỗi quần thể chịu tác động chủ yếu của nhân tố tiến hóa nào? (Biết rằng giữa F~2~ và F~3~ của quần thể II có một trận hỏa hoạn lớn.)

> [!goi-y] Gợi ý 1
> Tính p(A) của từng thế hệ ở mỗi quần thể.

> [!goi-y] Gợi ý 2
> Quần thể I: p tăng dần hay tăng vọt? Quần thể II: p thay đổi ở đâu, có liên quan đến sự kiện nào?

> [!loi-giai] Lời giải
> Quần thể I: p = 0,5 → 0,6 → 0,7 → 0,8. Tần số A **tăng dần theo một hướng**, aa giảm dần (0,25 → 0,04) → **chọn lọc tự nhiên** đào thải dần kiểu hình lặn.
>
> Quần thể II: p = 0,5 → 0,5 → 0,8 → 0,8. Tần số allele **nhảy vọt** đúng sau trận hỏa hoạn rồi lại ổn định → **phiêu bạt di truyền**.
>
> Lưu ý: đến F~4~ hai quần thể có **cùng cấu trúc** nhưng do hai nhân tố khác nhau, nên phải nhìn **cách** tần số thay đổi.

*Bẫy:* thấy tỉ lệ dị hợp giảm là vội kết luận "giao phối không ngẫu nhiên". Phải tính tần số allele trước: nếu allele đổi thì không phải giao phối không ngẫu nhiên.

### Dạng 2. Tính tần số allele sau dòng gene hoặc chọn lọc

*Nhận biết:* "nhập cư", "hệ số nhập cư", "chết trước tuổi sinh sản", "giá trị thích nghi". Đây là dạng mở rộng ngoài SGK.

*Phương pháp:*
1. **Dòng gene:** tính m (mẫu số là tổng **sau** nhập cư), rồi p' = (1 − m)p + mP. Nếu nhập cư lặp lại mỗi thế hệ với cùng m: chênh lệch (p − P) nhân với (1 − m) sau mỗi thế hệ.
2. **Chọn lọc loại hết aa** (quần thể ngẫu phối): q~mới~ = q/(1 + q). Nếu đề cho cấu trúc **không cân bằng** x AA : y Aa : z aa thì bỏ aa, chia lại: q~mới~ = (y/2)/(x + y).
3. **Chọn lọc theo giá trị thích nghi** w~AA~, w~Aa~, w~aa~: nhân tần số mỗi kiểu gene với w, chia cho tổng, rồi tính lại p, q.

> [!vi-du] Ví dụ 8
>
> a) Một quần thể cá trong hồ có tần số allele A là 0,3. Mỗi thế hệ, có cá từ sông (tần số A là 0,9) theo kênh dẫn vào hồ, với hệ số nhập cư không đổi m = 0,1. Tính tần số allele A của quần thể hồ sau 2 thế hệ nhập cư (làm tròn đến hàng phần trăm).
>
> b) Một quần thể thực vật ngẫu phối đang cân bằng có tần số allele a là 0,5. Giá trị thích nghi của các kiểu gene là w(AA) = w(Aa) = 1 và w(aa) = 0,6. Tính tần số allele a ở thế hệ sau (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
>
> a) Áp dụng p' = 0,9p + 0,1 × 0,9 hai lần. Hoặc nhận xét: khoảng cách đến 0,9 giảm còn 90% sau mỗi thế hệ.

> [!goi-y] Gợi ý 2
>
> b) Cấu trúc ban đầu 0,25 : 0,5 : 0,25. Nhân với w: 0,25 : 0,5 : 0,15. Tổng mới là bao nhiêu?

> [!loi-giai] Lời giải
>
> a) Thế hệ 1: p~1~ = 0,9 × 0,3 + 0,1 × 0,9 = 0,36. Thế hệ 2: p~2~ = 0,9 × 0,36 + 0,09 = 0,414 ≈ **0,41**.
>
> Cách nhanh: khoảng cách ban đầu 0,9 − 0,3 = 0,6, sau 2 thế hệ còn 0,6 × 0,9^2^ = 0,486 → p~2~ = 0,9 − 0,486 = 0,414.
>
> b) Sau chọn lọc: AA 0,25 × 1 = 0,25; Aa 0,5 × 1 = 0,5; aa 0,25 × 0,6 = 0,15. Tổng = 0,9.
> Tần số a = (0,5/2 + 0,15)/0,9 = 0,4/0,9 = 4/9 ≈ **0,44**. Allele a giảm từ 0,5 xuống 0,44 sau một thế hệ.

*Bẫy:* quên chia lại cho tổng sau chọn lọc (0,9 hoặc 1 − q^2^).

### Dạng 3. Đếm NST trong hình thành loài bằng lai xa và đa bội hóa

*Nhận biết:* "lai xa", "song nhị bội", "đa bội hóa", "thể tứ bội lai với thể lưỡng bội".

*Phương pháp:*
1. Giao tử của loài lưỡng bội có n NST. Con lai xa có n~A~ + n~B~ NST (bất thụ).
2. Song nhị bội: 2n~A~ + 2n~B~, giao tử n~A~ + n~B~.
3. 4n × 2n → giao tử 2n và n → con lai 3n, bất thụ.
4. Muốn khẳng định là loài mới: phải hữu thụ **và** cách li sinh sản với loài bố mẹ.

> [!vi-du] Ví dụ 9
> Loài thực vật X có 2n = 14, loài Y có 2n = 20. Lai X với Y được con lai F~1~, sau đó đa bội hóa F~1~ thành loài mới Z. Loài Z lai trở lại với loài X thì con lai có bao nhiêu NST và có hữu thụ không?

> [!goi-y] Gợi ý 1
> Tính bộ NST của Z: 2n~X~ + 2n~Y~. Giao tử của Z và giao tử của X lần lượt có bao nhiêu NST?

> [!goi-y] Gợi ý 2
> Con lai Z × X có 2 bộ NST của X và chỉ 1 bộ NST của Y. Giảm phân có bình thường không?

> [!loi-giai] Lời giải
> Bước 1: F~1~ có 7 + 10 = 17 NST (bất thụ). Z có 14 + 20 = **34 NST**, giao tử của Z có 17 NST (7 của X + 10 của Y).
>
> Bước 2: Giao tử của X có 7 NST. Con lai Z × X có 17 + 7 = **24 NST**.
>
> Bước 3: Trong 24 NST, 10 NST của Y không có chiếc tương đồng, nên giảm phân rối loạn, con lai **bất thụ**. Điều này chứng tỏ Z đã **cách li sinh sản** với X (tương tự với Y), nên Z là loài mới.

*Bẫy:* tính con lai F~1~ = 14 + 20 = 34 (cộng bộ 2n). Con lai nhận **giao tử** (n) của mỗi bên nên chỉ có 7 + 10 = 17.

## Tóm tắt

**Năm nhân tố tiến hóa:** bảng so sánh ở mục 2.6 (nên học thuộc).

**Sơ đồ ý chính:**

- **Thích nghi** = đột biến (nguyên liệu) + chọn lọc tự nhiên (giữ lại, nhân lên); chỉ hợp lí **tương đối**.
- **Khác khu vực địa lí**: cách li địa lí → ngăn dòng gene → nhân tố tiến hóa phân hóa vốn gene → cách li sinh sản → loài mới (chậm, phổ biến).
- **Cùng khu vực địa lí**: đa bội hóa, lai xa + đa bội hóa → cách li sinh sản ngay (nhanh, chủ yếu ở thực vật).

**Công thức cần thuộc:**

- Hệ số nhập cư: m = số nhập cư / tổng sau nhập cư.
- Dòng gene (mở rộng): p' = (1 − m)p + mP.
- Loại hết aa (mở rộng): q~mới~ = q/(1 + q); sau n thế hệ q~n~ = q~0~/(1 + nq~0~).
- Chọn lọc theo giá trị thích nghi: nhân tần số kiểu gene với w, chia cho tổng, tính lại p, q.
- Lai xa: con lai n~A~ + n~B~ (bất thụ); song nhị bội 2n~A~ + 2n~B~ (hữu thụ, loài mới).
