---
title: Di truyền học quần thể
thoi-gian: 50 phút
muc-tieu:
  - Phát biểu được khái niệm quần thể dưới góc độ di truyền học và khái niệm di truyền học quần thể, lấy được ví dụ.
  - Trình bày được các đặc trưng di truyền của quần thể (vốn gene, tần số allele, tần số kiểu gene) và tính được chúng từ số liệu.
  - Nêu được cấu trúc di truyền của quần thể ngẫu phối, mô tả được trạng thái cân bằng di truyền.
  - Trình bày được định luật Hardy – Weinberg, điều kiện nghiệm đúng, và vận dụng để kiểm tra trạng thái cân bằng, tính tần số allele, kiểu gene, xác suất mắc bệnh.
  - Phân tích được cấu trúc di truyền của quần thể tự thụ phấn, giao phối gần và tính được thành phần kiểu gene sau n thế hệ tự thụ phấn.
  - Giải thích được các vấn đề thực tiễn: cấm kết hôn họ hàng gần, thoái hoá giống khi cho cây giao phấn tự thụ phấn hoặc cho động vật giao phối gần.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Quần thể** là nhóm cá thể cùng loài, cùng khu vực, cùng thời điểm, **giao phối được với nhau**. Mỗi quần thể có một **vốn gene** riêng.
> 2. Đặc trưng di truyền của quần thể là **tần số allele** (p, q) và **tần số kiểu gene**. Với cấu trúc x AA + y Aa + z aa: **p = x + y/2**, q = 1 − p.
> 3. **Định luật Hardy – Weinberg**: quần thể ngẫu phối, đủ lớn, không đột biến, không chọn lọc, không di – nhập gene thì tần số allele và kiểu gene **không đổi qua các thế hệ**, với cấu trúc **p^2^ AA + 2pq Aa + q^2^ aa = 1**.
> 4. Quần thể chưa cân bằng chỉ cần **một thế hệ ngẫu phối** (gene trên NST thường, tần số allele hai giới như nhau) là đạt cân bằng.
> 5. **Tự thụ phấn, giao phối gần**: dị hợp giảm một nửa mỗi thế hệ tự thụ (Aa = y/2^n^), đồng hợp tăng, **tần số allele không đổi** → allele lặn có hại dễ đồng hợp → **thoái hoá**.

> [!nen-tang] Nhớ lại từ Bài 8
> - Mỗi gene nằm ở một locus. Ở sinh vật lưỡng bội, mỗi cá thể mang **2 allele** của một gene (AA, Aa hoặc aa).
> - Khi giảm phân, mỗi giao tử chỉ nhận **một** allele: AA → 100% A, aa → 100% a, Aa → ½A : ½a.
> - Thụ tinh là sự kết hợp **ngẫu nhiên** giữa giao tử đực và giao tử cái. Xác suất để hai sự kiện độc lập cùng xảy ra bằng **tích** xác suất của chúng.
>
> Ở các bài trước, em xét **một cặp bố mẹ** cụ thể. Bài này "phóng to" ra **cả một quần thể** gồm hàng nghìn cá thể giao phối với nhau. Công cụ vẫn là xác suất, chỉ thay "giao tử của một cây" bằng "giao tử của cả quần thể".

## 1. Quần thể và các đặc trưng di truyền của quần thể

### 1.1. Quần thể là gì?

Dưới góc độ di truyền học, **quần thể** là một tập hợp cá thể **cùng loài**, sống trong **cùng một khu vực địa lí**, vào **cùng một thời điểm**, và có khả năng **giao phối với nhau** để sinh ra thế hệ sau (SGK tr. 91).

Ví dụ: đàn voi ở Vườn quốc gia Yok Đôn, quần thể cây thông ba lá trên một quả đồi ở Đà Lạt, quần thể cá chép trong một hồ.

Điều quan trọng là chữ **"giao phối với nhau"**: các cá thể trong quần thể **chia sẻ chung một vốn gene**, gene của cá thể này có thể truyền sang con cháu chung với cá thể khác. Hai đàn cá chép ở hai hồ cách xa nhau là **hai quần thể**, dù cùng loài.

**Vì sao các quần thể cùng loài lại khác nhau về di truyền?**

- Một quần thể mới thường được hình thành từ **một nhóm nhỏ** cá thể di cư đến nơi ở mới, hoặc do quần thể ban đầu bị **chia cắt** bởi núi, sông, biển...
- Nhóm cá thể "tách ra" là ngẫu nhiên, nên ngay từ đầu mỗi nhóm mang **những allele với tỉ lệ khác nhau**.
- Sau đó, mỗi quần thể sống trong điều kiện môi trường riêng, ít trao đổi gene với nhau, nên sự khác biệt được **duy trì**.

**Di truyền học quần thể** là lĩnh vực nghiên cứu **tần số các allele, tần số các kiểu gene** trong quần thể và **những yếu tố làm thay đổi** chúng qua các thế hệ.

> [!bay]
> Một nhóm cá thể chỉ là quần thể khi **đủ cả** các điều kiện: cùng loài, cùng nơi, cùng lúc, giao phối được với nhau. "Các con cá trong một chợ cá" hay "các cây trong một vườn bách thảo gồm nhiều loài" **không** phải quần thể.

### 1.2. Vốn gene, tần số allele và tần số kiểu gene

**Vốn gene** là tập hợp **tất cả các allele** của **tất cả các gene** trong mọi cá thể của quần thể, tại một thời điểm xác định. Em hình dung vốn gene như một "kho" chứa mọi phiên bản gene mà quần thể đang có.

Để mô tả vốn gene bằng con số, ta dùng hai đại lượng (SGK tr. 92):

| Đại lượng | Định nghĩa | Cách tính |
|---|---|---|
| Tần số allele | Tỉ lệ một loại allele trên **tổng số allele** của gene đó trong quần thể | số allele A ÷ tổng số allele |
| Tần số kiểu gene | Tỉ lệ số cá thể có một kiểu gene trên **tổng số cá thể** | số cá thể AA ÷ tổng số cá thể |

Người ta thường kí hiệu **p** là tần số allele trội (A), **q** là tần số allele lặn (a). Gene có hai allele thì **p + q = 1**.

**Vì sao tổng số allele bằng 2 lần số cá thể?** Vì sinh vật lưỡng bội có hai bản sao của mỗi gene (một từ bố, một từ mẹ). Quần thể có N cá thể thì có **2N** allele của gene đó. Cá thể AA góp 2 allele A, cá thể Aa góp 1 allele A và 1 allele a, cá thể aa góp 2 allele a.

![Hình 1. Đếm allele trong một quần thể nhỏ 10 cá thể: 20 allele, trong đó 12 allele A và 8 allele a](hinh-1-dem-allele.svg)

Ở Hình 1: 4 AA, 4 Aa, 2 aa. Số allele A = 4 × 2 + 4 = 12. Tổng số allele = 10 × 2 = 20. Vậy p = 12/20 = 0,6 và q = 0,4.

**Cách tính nhanh từ tần số kiểu gene.** Nếu quần thể có cấu trúc **x AA + y Aa + z aa = 1** (x, y, z là tần số kiểu gene), thì:

$$p = x + \frac{y}{2}, \qquad q = z + \frac{y}{2} = 1 - p$$

Vì sao? Toàn bộ allele của cá thể AA là A (đóng góp x), còn cá thể Aa chỉ có **một nửa** allele là A (đóng góp y/2). Ở Hình 1: p = 0,4 + 0,4/2 = 0,6. Khớp với cách đếm.

> [!vi-du] Ví dụ 1
> Một quần thể cây hoa có 400 cây: 180 cây AA (hoa đỏ), 140 cây Aa (hoa hồng), 80 cây aa (hoa trắng). Tính tần số các kiểu gene và tần số mỗi allele.

> [!goi-y] Gợi ý 1
> Tần số kiểu gene: chia số cây mỗi kiểu gene cho 400.

> [!goi-y] Gợi ý 2
> Tổng số allele là 400 × 2 = 800. Mỗi cây AA có 2 allele A, mỗi cây Aa có 1 allele A. Hoặc dùng p = x + y/2.

> [!loi-giai] Lời giải
> Bước 1: Tần số kiểu gene: AA = 180/400 = 0,45; Aa = 140/400 = 0,35; aa = 80/400 = 0,20.
>
> Bước 2: Số allele A = 180 × 2 + 140 = 500. Tổng số allele = 800. p(A) = 500/800 = **0,625**.
>
> Bước 3: q(a) = 1 − 0,625 = **0,375**.
>
> Kiểm tra bằng công thức: p = 0,45 + 0,35/2 = 0,625. Đúng.

> [!bay]
> - Tần số allele **khác** tần số kiểu gene. Ở Ví dụ 1, tần số AA là 0,45 nhưng tần số allele A là 0,625. Đề hay cho "tỉ lệ cây hoa trắng" rồi hỏi "tần số allele a", em không được lấy luôn 0,20.
> - Khi đếm allele, nhớ **nhân 2** số cá thể đồng hợp, và chia cho **2N** chứ không phải N.

**Đa dạng di truyền.** Quần thể có **nhiều loại allele** và **tỉ lệ cá thể dị hợp cao** được gọi là quần thể **đa dạng di truyền** (đa hình di truyền). Quần thể càng đa dạng thì càng có nhiều "phương án dự phòng" khi môi trường thay đổi: thế nào cũng có một số cá thể mang tổ hợp gene thích nghi được, nên quần thể **dễ thích nghi** hơn.

> [!ung-dung]
> Các ngân hàng hạt giống và chương trình bảo tồn cố gắng giữ **nhiều quần thể khác nhau** của cùng một loài cây trồng (giống lúa địa phương, lúa hoang). Mỗi quần thể giữ một phần vốn gene riêng, có thể chứa allele kháng bệnh hay chịu hạn mà giống hiện đại đã mất.

## 2. Quần thể ngẫu phối và định luật Hardy – Weinberg

### 2.1. Quần thể ngẫu phối

**Quần thể ngẫu phối** là quần thể trong đó các cá thể giao phối với nhau **hoàn toàn ngẫu nhiên**: cá thể có kiểu gene nào cũng có cơ hội giao phối với cá thể có kiểu gene bất kì, không có "ưu tiên". Ví dụ ở cây ngô, hạt phấn được gió mang đi ngẫu nhiên đến các cây khác, nên sự thụ tinh về cơ bản là ngẫu nhiên.

Đặc điểm của quần thể ngẫu phối:

- **Rất đa dạng di truyền**: mỗi thế hệ, các allele lại được tổ hợp theo cách mới, tạo ra vô số biến dị tổ hợp.
- Allele đột biến mới xuất hiện thường **nằm ở trạng thái dị hợp**. Vì vậy, allele lặn có hại **ít khi** gặp nhau để thành đồng hợp và biểu hiện ra kiểu hình.
- Nếu không có yếu tố nào khác tác động, sinh sản hữu tính và ngẫu phối **không làm thay đổi** tần số allele và tần số kiểu gene. Đó chính là nội dung của định luật Hardy – Weinberg.

### 2.2. Định luật Hardy – Weinberg

Năm 1908, nhà toán học người Anh **G. H. Hardy** và bác sĩ người Đức **W. Weinberg** độc lập tìm ra định luật này.

**Nội dung (diễn đạt lại):** *Nếu quần thể ngẫu phối, có kích thước lớn, không xảy ra đột biến, các cá thể có khả năng sống và sinh sản như nhau, và quần thể được cách li với các quần thể khác, thì tần số allele và tần số các kiểu gene của quần thể được giữ ổn định từ thế hệ này sang thế hệ khác.*

Quần thể có tần số allele và kiểu gene không đổi qua các thế hệ như vậy được gọi là đang ở **trạng thái cân bằng Hardy – Weinberg** (cân bằng di truyền). Khi đó, cấu trúc di truyền của quần thể thoả mãn:

$$(p+q)^2 = p^2 + 2pq + q^2 = 1$$

với **p^2^** là tần số kiểu gene AA, **2pq** là tần số Aa, **q^2^** là tần số aa.

**Vì sao lại là p^2^, 2pq, q^2^? Hãy nghĩ theo "bể giao tử".** Trong quần thể ngẫu phối, mọi giao tử của tất cả cá thể như được đổ chung vào một bể lớn. Tỉ lệ giao tử mang A trong bể **bằng tần số allele A**, tức p (vì mỗi giao tử nhận ngẫu nhiên một trong hai allele của cá thể). Thụ tinh ngẫu nhiên giống như bốc ngẫu nhiên một giao tử đực và một giao tử cái từ bể:

- Bốc được A và A: xác suất p × p = **p^2^** → AA.
- Bốc được a và a: q × q = **q^2^** → aa.
- Bốc được một A, một a: có **hai cách** (đực A – cái a, hoặc đực a – cái A) → pq + qp = **2pq** → Aa.

![Hình 2. Bảng tổ hợp giao tử của quần thể ngẫu phối có p = 0,7 và q = 0,3: diện tích mỗi ô bằng tần số kiểu gene](hinh-2-hardy-weinberg.svg)

Ở Hình 2, với p = 0,7 và q = 0,3: AA = 0,49; Aa = 2 × 0,21 = 0,42; aa = 0,09. Tổng bằng 1.

**Vì sao tần số allele không đổi ở thế hệ sau?** Tính lại p ở thế hệ con: p' = p^2^ + 2pq/2 = p^2^ + pq = p(p + q) = **p**. Allele chỉ được "xáo bài" chứ không mất đi hay sinh thêm. Vì tần số allele không đổi, bể giao tử của thế hệ sau giống hệt, nên tần số kiểu gene cũng giữ nguyên mãi.

**Một thế hệ ngẫu phối là đủ.** Nếu gene nằm trên NST thường và tần số allele ở giao tử đực và giao tử cái như nhau, thì một quần thể **chưa cân bằng** chỉ cần **một lần ngẫu phối** là đạt trạng thái cân bằng. Lí do: thế hệ con chỉ phụ thuộc vào tần số allele (bể giao tử) của bố mẹ, chứ không phụ thuộc bố mẹ có cấu trúc kiểu gene thế nào.

> [!vi-du] Ví dụ 2
> Một quần thể thực vật giao phấn ở thế hệ xuất phát (P) có cấu trúc 0,6 AA : 0,2 Aa : 0,2 aa. Quần thể P có đang cân bằng di truyền không? Giả sử quần thể thoả mãn các điều kiện của định luật Hardy – Weinberg, hãy xác định cấu trúc di truyền ở F~1~ và F~2~.

> [!goi-y] Gợi ý 1
> Tính p, q của P. Nếu P cân bằng thì tần số AA phải bằng p^2^. So sánh xem có bằng không.

> [!goi-y] Gợi ý 2
> Sau một thế hệ ngẫu phối, F~1~ có cấu trúc p^2^ : 2pq : q^2^ với chính p, q của P. F~1~ đã cân bằng thì F~2~ thế nào?

> [!loi-giai] Lời giải
> Bước 1: p(A) = 0,6 + 0,2/2 = 0,7; q(a) = 0,3.
>
> Bước 2: Nếu cân bằng, tần số AA phải là 0,7^2^ = 0,49, nhưng P có 0,6. Vậy **P chưa cân bằng**.
>
> Bước 3: F~1~ = 0,7^2^ AA : 2 × 0,7 × 0,3 Aa : 0,3^2^ aa = **0,49 AA : 0,42 Aa : 0,09 aa** (đã cân bằng).
>
> Bước 4: Tần số allele ở F~1~ vẫn là p = 0,49 + 0,21 = 0,7, nên F~2~ giữ nguyên **0,49 AA : 0,42 Aa : 0,09 aa**.

**Kiểm tra nhanh một quần thể có cân bằng không.** Với cấu trúc x AA + y Aa + z aa, quần thể cân bằng khi và chỉ khi:

$$x \cdot z = \left(\frac{y}{2}\right)^2$$

Vì sao? Ở trạng thái cân bằng, x = p^2^, z = q^2^, y/2 = pq, nên x · z = p^2^q^2^ = (pq)^2^ = (y/2)^2^. Ví dụ 2: 0,6 × 0,2 = 0,12, còn (0,2/2)^2^ = 0,01. Khác nhau, nên chưa cân bằng.

> [!bay]
> - Quần thể **toàn Aa** (x = z = 0, y = 1): x · z = 0 nhưng (y/2)^2^ = 0,25 → **không** cân bằng (SGK tr. 93 hỏi đúng ý này).
> - Quần thể **toàn AA** hoặc **toàn aa**: x · z = 0 = (y/2)^2^ → **cân bằng** (p = 1 hoặc q = 1, ngẫu phối thì đời con vẫn y hệt).
> - Quần thể "**toàn kiểu hình trội**": chưa kết luận được ngay. Nếu toàn AA thì cân bằng. Nếu có cả AA lẫn Aa (không có aa) thì x · z = 0 nhưng y > 0 → **không** cân bằng.

> [!bay] Tần số allele ở hai giới khác nhau
> SGK nói rõ điều kiện "tần số allele ở giao tử đực và giao tử cái như nhau". Nếu khác nhau (ví dụ quần thể mới thả thêm nhiều con đực từ nơi khác), thì **một** thế hệ ngẫu phối chưa đủ. Ví dụ ♂ có p = 0,6, ♀ có p = 0,8:
> - F~1~: AA = 0,6 × 0,8 = 0,48; aa = 0,4 × 0,2 = 0,08; Aa = 1 − 0,48 − 0,08 = 0,44 → chưa cân bằng (0,48 × 0,08 ≠ 0,22^2^).
> - Tần số allele ở F~1~ (hai giới như nhau) là p = (0,6 + 0,8)/2 = 0,7, nên F~2~ mới cân bằng: 0,49 AA : 0,42 Aa : 0,09 aa.

### 2.3. Điều kiện nghiệm đúng và ý nghĩa của định luật

Năm điều kiện (dễ nhớ theo sơ đồ chương 4, SGK tr. 96), kèm lí do tại sao thiếu điều kiện thì tần số thay đổi:

| Điều kiện | Nếu không thoả mãn thì sao? |
|---|---|
| Quần thể có kích thước **lớn** | Quần thể nhỏ: tần số allele dao động ngẫu nhiên, có allele mất đi chỉ do "rủi ro" |
| **Ngẫu phối** | Tự thụ phấn, giao phối gần, giao phối có chọn lọc làm thay đổi tần số kiểu gene (mục 3) |
| **Không có đột biến** | Đột biến biến allele này thành allele khác → tần số allele đổi |
| Các cá thể có sức sống, khả năng sinh sản **như nhau** (không có chọn lọc tự nhiên) | Kiểu gene nào sống sót, sinh sản kém hơn thì allele của nó giảm dần |
| Quần thể **cách li**, không có di – nhập gene | Cá thể nhập cư mang allele với tần số khác vào quần thể |

Trong thực tế, hiếm quần thể thoả mãn hoàn toàn năm điều kiện, nên định luật là một **mô hình lí tưởng**. Nhưng chính nhờ có "mốc chuẩn" này, khi thấy quần thể **lệch khỏi** cân bằng, ta biết có nhân tố nào đó đang tác động (em sẽ học các nhân tố tiến hoá ở Bài 21).

**Ý nghĩa thực tiễn.** Khi quần thể cân bằng, chỉ cần biết tỉ lệ một kiểu gene là suy ra được tất cả. Thường gặp nhất: biết **tỉ lệ người mắc bệnh di truyền lặn** (kiểu gene aa, nhận ra qua kiểu hình) → q = √(tỉ lệ aa) → p → tỉ lệ người mang allele bệnh (Aa), rồi tính xác suất sinh con mắc bệnh cho một cặp vợ chồng.

> [!vi-du] Ví dụ 3
> Ở một quần thể người đang cân bằng di truyền, bệnh bạch tạng (do allele lặn a trên NST thường) gặp ở 1 trong 10 000 người. Tính tần số allele a và tỉ lệ người bình thường nhưng mang allele bệnh.

> [!goi-y] Gợi ý 1
> Người bạch tạng có kiểu gene aa, tần số là q^2^. Từ q^2^ suy ra q.

> [!goi-y] Gợi ý 2
> Người bình thường mang allele bệnh có kiểu gene Aa, tần số 2pq.

> [!loi-giai] Lời giải
> Bước 1: q^2^ = 1/10 000 = 0,0001 → q = √0,0001 = **0,01**.
>
> Bước 2: p = 1 − 0,01 = 0,99.
>
> Bước 3: Tần số Aa = 2 × 0,99 × 0,01 = **0,0198**, tức khoảng 1/50 người.
>
> Nhận xét: cứ 1 người bệnh thì có khoảng 198 người mang allele bệnh mà không biết. Allele lặn có hại "ẩn" chủ yếu ở người dị hợp.

> [!meo] Bấm máy Casio fx-580VN X
> Lấy căn: `√` `0,0001` `=` → 0,01. Tính 2pq: `2` × `0,99` × `0,01` `=` → 0,0198. Muốn kiểm tra cân bằng với số lẻ, nhập x × z rồi so với (y ÷ 2)^2^ ngay trên máy.

### 2.4. Mở rộng hay gặp trong đề thi (ngoài SGK)

SGK chỉ xét gene có **hai allele** nằm trên **NST thường**. Đề thi tốt nghiệp và đề thi chọn học sinh giỏi thường mở rộng thêm hai trường hợp sau. Nguyên lí "bể giao tử" vẫn y như cũ.

**a) Gene có nhiều allele.** Gene có 3 allele với tần số p, q, r (p + q + r = 1) thì quần thể cân bằng có cấu trúc là khai triển của (p + q + r)^2^ = 1:

$$p^2 + q^2 + r^2 + 2pq + 2pr + 2qr = 1$$

Ví dụ hệ nhóm máu ABO: allele I^A^ (tần số p), I^B^ (q), I^O^ (r). I^A^ và I^B^ đồng trội, cả hai trội hoàn toàn so với I^O^.

| Nhóm máu | Kiểu gene | Tần số khi cân bằng |
|---|---|---|
| A | I^A^I^A^, I^A^I^O^ | p^2^ + 2pr |
| B | I^B^I^B^, I^B^I^O^ | q^2^ + 2qr |
| AB | I^A^I^B^ | 2pq |
| O | I^O^I^O^ | r^2^ |

Số loại kiểu gene của một gene có **n allele** trên NST thường là **n(n + 1)/2**: n kiểu đồng hợp và n(n − 1)/2 kiểu dị hợp. Ví dụ: 3 allele → 6 kiểu gene, 4 allele → 10 kiểu gene.

**b) Gene trên vùng không tương đồng của NST X** (xem lại Bài 10). Con đực (XY) chỉ có một allele, nên **tỉ lệ con đực mang tính trạng lặn = q**. Con cái (XX) có hai allele, nên con cái lặn chiếm **q^2^**, con cái dị hợp chiếm 2pq. Ví dụ ở một quần thể người cân bằng, 8% nam bị mù màu → q = 0,08, nữ bị mù màu chỉ khoảng 0,08^2^ = 0,0064 (0,64%). Đó là lí do bệnh này "gần như chỉ gặp ở nam".

> [!em-co-biet] Vì sao hôn nhân họ hàng gần làm tăng nguy cơ? (ngoài SGK)
> Hai anh chị em con chú con bác có chung ông bà, nên con của họ có xác suất khoảng **1/16** nhận được **hai bản sao của cùng một allele** của ông hoặc bà. Với một bệnh lặn có q = 0,01, xác suất con bị bệnh tăng từ q^2^ = 0,0001 lên khoảng q^2^ + (1/16)pq ≈ 0,00072, tức **gấp khoảng 7 lần**. Bệnh càng hiếm thì mức tăng càng lớn.

## 3. Quần thể tự thụ phấn và quần thể giao phối gần

### 3.1. Khái niệm

**Quần thể giao phối gần** (giao phối cận huyết) là quần thể mà các cá thể **có quan hệ họ hàng gần** (giống nhau nhiều về kiểu gene) thường giao phối với nhau. Ở động vật gọi là giao phối gần, ở thực vật là **tự thụ phấn**.

**Tự thụ phấn** ở thực vật (và tự thụ tinh ở một số động vật lưỡng tính bậc thấp) là **trường hợp đặc biệt** và mạnh nhất của giao phối cận huyết, vì "bố" và "mẹ" chính là một cá thể, nên có **cùng một kiểu gene**.

### 3.2. Đặc trưng di truyền

Hãy theo dõi một quần thể ngô ở thế hệ xuất phát (G~0~) gồm **toàn cây Aa**, cho tự thụ phấn qua nhiều thế hệ (SGK Bảng 18.2, tr. 94).

**Vì sao dị hợp giảm một nửa mỗi thế hệ?** Mỗi kiểu gene tự thụ phấn riêng:

- AA × AA → 100% AA. Đồng hợp sinh ra đồng hợp.
- aa × aa → 100% aa.
- Aa × Aa → ¼ AA : ½ Aa : ¼ aa. Chỉ **một nửa** con của cây dị hợp còn dị hợp, nửa kia "rơi" sang đồng hợp, chia đều cho AA và aa.

Không có đường nào "quay ngược" từ đồng hợp sang dị hợp, nên dị hợp cứ giảm mãi:

| Thế hệ | AA | Aa | aa |
|---|---|---|---|
| G~0~ | 0 | 1 | 0 |
| G~1~ | 1/4 | 1/2 | 1/4 |
| G~2~ | 3/8 | 1/4 | 3/8 |
| G~3~ | 7/16 | 1/8 | 7/16 |
| G~n~ | $\dfrac{1-(1/2)^n}{2}$ | $(1/2)^n$ | $\dfrac{1-(1/2)^n}{2}$ |

![Hình 3. Quần thể toàn Aa tự thụ phấn qua 4 thế hệ: phần dị hợp (giữa) giảm một nửa mỗi thế hệ, hai phần đồng hợp tăng dần, tần số allele A luôn bằng 0,5](hinh-3-tu-thu-phan.svg)

**Công thức tổng quát.** Thế hệ xuất phát có cấu trúc **x AA + y Aa + z aa = 1**, tự thụ phấn qua **n** thế hệ:

$$\text{Aa} = \frac{y}{2^n}$$

$$\text{AA} = x + \frac{y - \dfrac{y}{2^n}}{2}, \qquad \text{aa} = z + \frac{y - \dfrac{y}{2^n}}{2}$$

Đọc công thức bằng lời: phần dị hợp **mất đi** là y − y/2^n^, phần này **chia đôi** cho AA và aa.

**Tần số allele không đổi.** Thử với G~3~ ở bảng trên: p = 7/16 + (1/8)/2 = 7/16 + 1/16 = 1/2, bằng đúng G~0~. Giao phối cận huyết chỉ **sắp xếp lại** allele từ dạng dị hợp sang dạng đồng hợp, không làm mất allele nào.

> [!vi-du] Ví dụ 4
> Một quần thể thực vật tự thụ phấn có thế hệ xuất phát: 0,4 AA : 0,4 Aa : 0,2 aa. Xác định cấu trúc di truyền sau 3 thế hệ tự thụ phấn và chứng tỏ tần số allele không đổi.

> [!goi-y] Gợi ý 1
> Tính Aa trước: y/2^n^ với y = 0,4 và n = 3.

> [!goi-y] Gợi ý 2
> Phần dị hợp mất đi là 0,4 − Aa mới, chia đôi rồi cộng vào AA và aa ban đầu.

> [!loi-giai] Lời giải
> Bước 1: Aa = 0,4/2^3^ = 0,4/8 = **0,05**.
>
> Bước 2: Phần dị hợp mất đi = 0,4 − 0,05 = 0,35, mỗi bên đồng hợp nhận 0,175.
>
> Bước 3: AA = 0,4 + 0,175 = **0,575**; aa = 0,2 + 0,175 = **0,375**.
>
> Kiểm tra: 0,575 + 0,05 + 0,375 = 1. Tần số A ở G~3~ = 0,575 + 0,05/2 = 0,6, bằng tần số A ở G~0~ = 0,4 + 0,4/2 = 0,6.

**Giao phối gần ở động vật** (anh chị em, bố mẹ với con) cũng làm **giảm dị hợp, tăng đồng hợp**, nhưng chậm hơn tự thụ phấn. Mức độ thay đổi phụ thuộc vào **mức độ giống nhau về kiểu gene** giữa bố và mẹ: càng gần họ hàng, đồng hợp tăng càng nhanh. Tần số allele cũng **không đổi**.

> [!bay]
> - Tự thụ phấn, giao phối gần **không** làm thay đổi **tần số allele**, chỉ thay đổi **tần số kiểu gene**. Đề hay cài "tự thụ phấn làm giảm tần số allele lặn" → **sai**.
> - Quần thể tự thụ phấn **không** tiến tới cân bằng Hardy – Weinberg. Dù đã có p, q, em **không** được áp p^2^ : 2pq : q^2^ cho quần thể tự thụ phấn.
> - Kết quả cuối cùng của tự thụ phấn kéo dài: quần thể gồm **các dòng thuần** AA và aa, với tỉ lệ AA → p, aa → q.

### 3.3. Ứng dụng thực tiễn

**Thoái hoá giống (suy thoái cận huyết).** Ở quần thể giao phấn và động vật giao phối ngẫu nhiên, nhiều allele lặn có hại vẫn "nấp" ở trạng thái dị hợp. Khi cho tự thụ phấn hoặc giao phối gần, tỉ lệ đồng hợp tăng nhanh, nên các allele lặn có hại **gặp nhau thành đồng hợp** và biểu hiện ra. Hậu quả: con cháu giảm sức sống, sinh trưởng chậm, giảm khả năng sinh sản, năng suất và chất lượng kém, nhiều quái thai, dị tật. Vì vậy:

- Trong chăn nuôi, cần **tránh cho các con vật cùng đàn** (cùng bố mẹ) giao phối với nhau, nên định kì đổi con đực giống giữa các trại.
- Ở người, kết hôn trong cùng dòng họ làm tăng tỉ lệ mắc bệnh di truyền lặn, tăng tỉ lệ tử vong ở trẻ. Vì thế **Luật Hôn nhân và Gia đình** của nước ta **cấm kết hôn giữa những người có họ trong phạm vi ba đời** (SGK tr. 94).

**Mặt có lợi.** Các nhà chọn giống chủ động cho tự thụ phấn, giao phối gần để **tạo dòng thuần chủng** mang gene mong muốn, sau đó lai các dòng thuần khác nhau để tìm tổ hợp có **ưu thế lai** cao (xem Bài 16).

> [!vi-du] Ví dụ 5
> Vì sao cây ngô (giao phấn nhờ gió) bị bắt buộc tự thụ phấn liên tục thì thoái hoá, còn cây đậu hà lan tự thụ phấn nghiêm ngặt từ hàng nghìn năm nay lại không bị thoái hoá?

> [!goi-y] Gợi ý 1
> Ở ngô giao phấn, allele lặn có hại thường ở trạng thái nào? Tự thụ phấn làm tỉ lệ trạng thái đó thay đổi ra sao?

> [!goi-y] Gợi ý 2
> Ở đậu hà lan, quần thể đã gồm toàn dòng thuần từ rất lâu. Nếu một dòng mang allele lặn có hại ở trạng thái đồng hợp thì chọn lọc tự nhiên đã làm gì với dòng đó?

> [!loi-giai] Lời giải
> Ngô là cây giao phấn, quần thể có tỉ lệ dị hợp cao, chứa nhiều allele lặn có hại ẩn trong dị hợp. Khi ép tự thụ phấn, dị hợp giảm một nửa mỗi thế hệ, allele lặn có hại chuyển sang đồng hợp và biểu hiện → thoái hoá.
>
> Đậu hà lan tự thụ phấn qua rất nhiều thế hệ, nên quần thể **đã là các dòng thuần đồng hợp** từ lâu. Những dòng đồng hợp về allele có hại đã bị **chọn lọc tự nhiên đào thải** từ trước. Các dòng còn lại mang tổ hợp gene không gây hại, nên tự thụ phấn tiếp cũng không làm xuất hiện thêm kiểu gene có hại → không thoái hoá.

> [!ung-dung]
> Giống ngô lai F~1~ cho năng suất rất cao, nhưng nông dân **không nên** lấy hạt F~1~ làm giống vụ sau. Cây F~2~ có tỉ lệ dị hợp giảm, ưu thế lai giảm, lại phân li nhiều kiểu hình khác nhau, nên năng suất giảm rõ rệt.

## Dạng bài thi hay gặp

> [!ghi-nho] Chìa khoá chung
> - Đầu tiên luôn đọc kĩ: quần thể **ngẫu phối** hay **tự thụ phấn / giao phối gần**? Hai loại dùng công thức khác hẳn nhau.
> - Bất kể loại nào: **p = x + y/2**.
> - Ngẫu phối (đủ điều kiện): sau 1 thế hệ → p^2^ : 2pq : q^2^.
> - Tự thụ phấn n thế hệ: Aa = y/2^n^, phần mất đi chia đôi cho AA và aa.

### Dạng 1. Tính tần số allele, kiểm tra trạng thái cân bằng

*Nhận biết:* cho số lượng hoặc tỉ lệ các kiểu gene (thường là tính trạng trội không hoàn toàn hay đồng trội, nhìn kiểu hình biết kiểu gene), hỏi p, q và "quần thể có cân bằng không".

*Phương pháp:*
1. Đổi số lượng thành tần số kiểu gene x, y, z (chia cho tổng số cá thể).
2. Tính p = x + y/2, q = 1 − p.
3. Kiểm tra: x · z có bằng (y/2)^2^ không, hoặc so sánh x với p^2^.

> [!vi-du] Ví dụ 6
> Ở bò, allele R (lông đỏ) và r (lông trắng) trội không hoàn toàn, Rr có lông lang đỏ trắng. Một đàn bò gồm 169 con lông đỏ, 182 con lông lang và 49 con lông trắng. Đàn bò có đang cân bằng di truyền không?

> [!goi-y] Gợi ý 1
> Tổng số con là 400. Kiểu hình cho biết luôn kiểu gene: đỏ RR, lang Rr, trắng rr.

> [!goi-y] Gợi ý 2
> Tính x, y, z rồi so sánh x · z với (y/2)^2^.

> [!loi-giai] Lời giải
> Bước 1: x = 169/400 = 0,4225; y = 182/400 = 0,455; z = 49/400 = 0,1225.
>
> Bước 2: p(R) = 0,4225 + 0,455/2 = 0,65; q(r) = 0,35.
>
> Bước 3: x · z = 0,4225 × 0,1225 ≈ 0,05176; (y/2)^2^ = 0,2275^2^ ≈ 0,05176. Bằng nhau.
>
> Kết luận: đàn bò **đang cân bằng** (đúng bằng 0,65^2^ : 2 × 0,65 × 0,35 : 0,35^2^).

*Bẫy:* tính p bằng "số con lông đỏ chia tổng" (0,4225) là nhầm tần số kiểu gene với tần số allele.

### Dạng 2. Quần thể cân bằng: từ kiểu hình lặn suy ra cấu trúc, tính xác suất

*Nhận biết:* "quần thể đang cân bằng di truyền", cho tỉ lệ kiểu hình lặn (thường là tỉ lệ người bị bệnh), hỏi tỉ lệ dị hợp, xác suất cặp vợ chồng bình thường sinh con bị bệnh.

*Phương pháp:*
1. q = √(tỉ lệ kiểu hình lặn), p = 1 − q. **Chỉ được lấy căn khi quần thể cân bằng.**
2. Cấu trúc: p^2^ AA : 2pq Aa : q^2^ aa.
3. Người **bình thường** đã biết không phải aa, nên xác suất người đó là Aa:

$$\frac{2pq}{p^2 + 2pq} = \frac{2q}{1+q}$$

4. Xác suất con bị bệnh = P(bố Aa) × P(mẹ Aa) × 1/4.

> [!vi-du] Ví dụ 7
> Một quần thể người đang cân bằng di truyền có 4% người mắc một bệnh do allele lặn trên NST thường. Một cặp vợ chồng đều bình thường, không có họ hàng với nhau, đều thuộc quần thể này. Tính xác suất họ sinh con đầu lòng bị bệnh.

> [!goi-y] Gợi ý 1
> q^2^ = 0,04 → q bằng bao nhiêu? Cấu trúc quần thể thế nào?

> [!goi-y] Gợi ý 2
> Người bình thường thuộc nhóm AA hoặc Aa. Trong nhóm đó, Aa chiếm bao nhiêu? Chỉ khi **cả hai** là Aa mới có thể sinh con aa.

> [!loi-giai] Lời giải
> Bước 1: q = √0,04 = 0,2; p = 0,8. Cấu trúc: 0,64 AA : 0,32 Aa : 0,04 aa.
>
> Bước 2: Trong số người bình thường (0,64 + 0,32 = 0,96), người Aa chiếm 0,32/0,96 = **1/3**.
>
> Bước 3: Xác suất con đầu lòng bị bệnh = 1/3 × 1/3 × 1/4 = **1/36** ≈ 0,028.

*Bẫy:* lấy luôn 2pq = 0,32 làm xác suất người bình thường mang allele bệnh. Sai, vì đã biết người đó bình thường nên phải chia cho p^2^ + 2pq.

### Dạng 3. Quần thể tự thụ phấn qua n thế hệ

*Nhận biết:* "tự thụ phấn", "tự phối", "giao phối cận huyết" qua n thế hệ. Có ba kiểu hỏi: tính cấu trúc sau n thế hệ, tìm n, tìm cấu trúc ban đầu.

*Phương pháp:*
1. Xuôi: Aa~n~ = y/2^n^. AA~n~ = x + (y − Aa~n~)/2. aa~n~ = z + (y − Aa~n~)/2.
2. Tìm n: y/Aa~n~ = 2^n^ → n.
3. Ngược: y = Aa~n~ × 2^n^, rồi x = AA~n~ − (y − Aa~n~)/2.
4. Nếu đề cho tự thụ phấn vài thế hệ **rồi chuyển sang ngẫu phối**: tần số allele không đổi suốt quá trình tự thụ, nên dùng luôn p của thế hệ xuất phát, ngẫu phối 1 thế hệ → p^2^ : 2pq : q^2^.

> [!vi-du] Ví dụ 8
> Một quần thể thực vật tự thụ phấn bắt buộc. Sau 3 thế hệ tự thụ phấn, quần thể có cấu trúc 0,525 AA : 0,05 Aa : 0,425 aa. Xác định cấu trúc di truyền của thế hệ xuất phát.

> [!goi-y] Gợi ý 1
> Mỗi thế hệ dị hợp giảm một nửa. Qua 3 thế hệ, dị hợp giảm bao nhiêu lần? Từ 0,05 suy ngược lại y.

> [!goi-y] Gợi ý 2
> Phần dị hợp đã mất là y − 0,05, chia đôi cho AA và aa. Lấy AA hiện tại trừ đi phần được cộng thêm.

> [!loi-giai] Lời giải
> Bước 1: y = 0,05 × 2^3^ = **0,4**.
>
> Bước 2: Phần dị hợp mất đi = 0,4 − 0,05 = 0,35, mỗi bên đồng hợp được cộng 0,175.
>
> Bước 3: x = 0,525 − 0,175 = **0,35**; z = 0,425 − 0,175 = **0,25**.
>
> Kết luận: thế hệ xuất phát 0,35 AA : 0,4 Aa : 0,25 aa. Kiểm tra: p = 0,35 + 0,2 = 0,55 = 0,525 + 0,025.

*Bẫy:* chia AA, aa cho 2^n^ như dị hợp. Đồng hợp không giảm mà **tăng**.

### Dạng 4. Gene nhiều allele (mở rộng, ngoài SGK)

*Nhận biết:* nhóm máu ABO, màu lông do dãy allele trội lặn (A~1~ > A~2~ > A~3~), "số loại kiểu gene tối đa".

*Phương pháp:*
1. Bắt đầu từ allele **lặn nhất**: r = √(tỉ lệ kiểu hình lặn nhất).
2. Dùng mẹo **gộp**: các kiểu gene có kiểu hình "lặn nhất" và "lặn nhì" (với ABO: nhóm O và nhóm A) cộng lại là (p + r)^2^, vì chúng chỉ gồm allele I^A^ và I^O^.
3. Số kiểu gene tối đa của gene có n allele trên NST thường: n(n + 1)/2. Nhiều gene trên các NST khác nhau: **nhân** lại.

> [!vi-du] Ví dụ 9
> Một quần thể người đang cân bằng di truyền về hệ nhóm máu ABO có 40% người nhóm máu A và 9% người nhóm máu O. Tính tần số các allele I^A^, I^B^, I^O^ và tỉ lệ người nhóm máu B, nhóm máu AB.

> [!goi-y] Gợi ý 1
> Nhóm O là I^O^I^O^ → r^2^ = 0,09.

> [!goi-y] Gợi ý 2
> Nhóm A + nhóm O = p^2^ + 2pr + r^2^ = (p + r)^2^. Tính p + r rồi suy ra p.

> [!loi-giai] Lời giải
> Bước 1: r^2^ = 0,09 → r = **0,3**.
>
> Bước 2: (p + r)^2^ = 0,40 + 0,09 = 0,49 → p + r = 0,7 → p = **0,4**.
>
> Bước 3: q = 1 − 0,4 − 0,3 = **0,3**.
>
> Bước 4: Nhóm B = q^2^ + 2qr = 0,09 + 0,18 = **0,27**; nhóm AB = 2pq = **0,24**. Kiểm tra: 0,40 + 0,27 + 0,24 + 0,09 = 1.

*Bẫy:* giải hệ phương trình bậc hai từ p^2^ + 2pr = 0,40 rất mất thời gian. Dùng mẹo gộp (p + r)^2^ chỉ cần một phép khai căn.

## Tóm tắt

| | Quần thể ngẫu phối | Quần thể tự thụ phấn, giao phối gần |
|---|---|---|
| Tần số allele | Không đổi (nếu đủ điều kiện Hardy – Weinberg) | Không đổi |
| Tần số kiểu gene | Không đổi khi đã cân bằng: p^2^ : 2pq : q^2^ | Dị hợp giảm (y/2^n^), đồng hợp tăng |
| Đa dạng di truyền | Cao, nhiều dị hợp | Thấp, chủ yếu các dòng thuần |
| Allele lặn có hại | Ẩn trong dị hợp | Dễ đồng hợp → thoái hoá giống |
| Ý nghĩa | Giải thích sự ổn định của quần thể, tính tần số allele bệnh | Tạo dòng thuần; cơ sở cấm kết hôn họ hàng gần |

**Công thức cần thuộc:**

- p = x + y/2; q = 1 − p.
- Cân bằng: x · z = (y/2)^2^ (tương đương x = p^2^, y = 2pq, z = q^2^).
- Từ kiểu hình lặn (khi cân bằng): q = √(tỉ lệ aa).
- Người bình thường mang allele bệnh: 2pq/(p^2^ + 2pq) = 2q/(1 + q).
- Tự thụ phấn n thế hệ: Aa = y/2^n^; AA = x + (y − y/2^n^)/2; aa = z + (y − y/2^n^)/2.
- 3 allele: (p + q + r)^2^ = 1. Số kiểu gene với n allele: n(n + 1)/2.

**Năm điều kiện của định luật Hardy – Weinberg:** quần thể lớn, ngẫu phối, không đột biến, không chọn lọc (sức sống và sinh sản như nhau), không di – nhập gene.
