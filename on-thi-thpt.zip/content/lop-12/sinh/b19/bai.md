---
title: Các bằng chứng tiến hóa
thoi-gian: 40 phút
muc-tieu:
  - Nêu được hóa thạch là gì, hình thành như thế nào và vì sao hóa thạch là bằng chứng trực tiếp của tiến hóa.
  - Giải thích được hai cách xác định tuổi hóa thạch (theo lớp đất đá và theo đồng vị phóng xạ), nêu được ưu điểm và hạn chế của bằng chứng hóa thạch.
  - Phân biệt được cấu trúc tương đồng, cấu trúc thoái hóa và cấu trúc tương tự, lấy được ví dụ và cho biết mỗi loại nói lên điều gì về nguồn gốc các loài.
  - Trình bày được các bằng chứng tế bào học và sinh học phân tử cho thấy mọi sinh vật có chung tổ tiên.
  - Đọc được bảng số liệu so sánh trình tự amino acid / nucleotide để suy ra mức độ họ hàng giữa các loài.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Bằng chứng tiến hóa** là những chứng cứ cho thấy các loài sinh vật hiện nay được hình thành từ các loài trước đó và có **chung tổ tiên**.
> 2. **Hóa thạch** là bằng chứng **trực tiếp**: cho biết loài nào đã từng sống, sống **khi nào** (tuổi lớp đá, đồng vị phóng xạ), **ở đâu**, và có các **dạng trung gian** nối hai nhóm sinh vật.
> 3. **Giải phẫu so sánh**: cấu trúc **tương đồng** (cùng nguồn gốc, có thể khác chức năng) và cấu trúc **thoái hóa** chứng tỏ các loài có chung tổ tiên. Cấu trúc **tương tự** (giống chức năng, khác nguồn gốc) **không** chứng minh họ hàng.
> 4. **Tế bào học**: mọi sinh vật đều cấu tạo từ tế bào, tế bào đều có màng, tế bào chất, vùng nhân/nhân và các quá trình chuyển hóa cơ bản giống nhau.
> 5. **Sinh học phân tử**: mọi loài dùng DNA, mã di truyền gần như chung, protein từ 20 loại amino acid. Hai loài **càng ít khác biệt** về trình tự nucleotide / amino acid thì **họ hàng càng gần**.

> [!nen-tang] Nhớ lại trước khi học
> - **Tiến hóa** là quá trình biến đổi các đặc điểm di truyền của quần thể sinh vật qua các thế hệ, dẫn tới hình thành loài mới. Hai loài có **chung tổ tiên** nghĩa là trong quá khứ chúng cùng bắt nguồn từ một loài.
> - **Học thuyết tế bào** (Sinh học 10): mọi sinh vật được cấu tạo từ tế bào, tế bào là đơn vị cơ bản của sự sống, tế bào mới chỉ sinh ra từ tế bào có trước.
> - **Mã di truyền** (Bài 1 – 3): mã bộ ba, có **tính phổ biến** (hầu hết các loài dùng chung một bộ mã, chỉ có vài ngoại lệ). Đột biến gene làm thay đổi trình tự nucleotide, có thể làm đổi amino acid trong protein.
> - **DNA ti thể** di truyền theo dòng mẹ (Bài 15).

Tiến hóa diễn ra trong hàng triệu năm, không ai "xem tận mắt" được. Vậy dựa vào đâu ta khẳng định cá voi có tổ tiên sống trên cạn, hay người và tinh tinh có họ hàng gần? Câu trả lời: các nhà khoa học **ghép nhiều loại chứng cứ độc lập** với nhau, giống như thám tử ghép dấu vân tay, nhân chứng và camera. Bài này giới thiệu các loại chứng cứ chính theo thứ tự của SGK (SGK tr. 97–100): hóa thạch, giải phẫu so sánh, tế bào học và sinh học phân tử. Bảng so sánh bốn loại nằm ở mục 4.

## 1. Bằng chứng hóa thạch

### 1.1. Hóa thạch là gì và hình thành như thế nào?

**Hóa thạch** là di tích của sinh vật sống trong quá khứ còn được lưu giữ lại trong đất đá. Có nhiều dạng:

- **Phần cứng** còn lại: xương, răng, vỏ ốc, vỏ sò.
- **Xác nguyên vẹn** được bảo quản tự nhiên: côn trùng trong **hổ phách** (nhựa cây hóa đá), voi ma mút trong **băng tuyết** vùng cực.
- **Dấu vết**: dấu chân, dấu lá, hình dạng cơ thể in trên lớp đá.
- **Sinh vật hóa đá**: xác sinh vật bị các lớp **trầm tích** (bùn, cát lắng đọng) vùi lấp. Chất hữu cơ phân hủy dần và được thay thế từng chút bởi calcium cùng các khoáng chất khác, nhưng **hình dạng, cấu trúc** vẫn được giữ nguyên. Thân cây hóa đá là ví dụ điển hình (SGK tr. 98, Hình 19.1a).

**Vì sao không phải sinh vật nào chết đi cũng thành hóa thạch?** Bình thường xác bị vi khuẩn, nấm phân giải hết. Muốn thành hóa thạch, xác phải được **vùi lấp nhanh** và cách li khỏi không khí (dưới bùn đáy hồ, đáy biển, trong nhựa cây, trong băng), để quá trình phân hủy chậm lại hoặc dừng hẳn. Điều kiện này hiếm gặp, nên phần lớn sinh vật trong quá khứ **không để lại hóa thạch**.

> [!bay]
> - Hóa thạch **không chỉ là "xương hóa đá"**. Côn trùng trong hổ phách, voi ma mút trong băng, dấu chân khủng long đều là hóa thạch.
> - Sinh vật có **phần cứng** (xương, vỏ) dễ thành hóa thạch hơn sinh vật thân mềm (sứa, giun). Vì vậy kho hóa thạch **thiên lệch**, không phản ánh đầy đủ thế giới sống xưa.

### 1.2. Xác định tuổi của hóa thạch

Muốn dùng hóa thạch để "đọc lịch sử", trước hết phải biết hóa thạch **bao nhiêu tuổi**. Có hai cách bổ sung cho nhau.

**Cách 1 — Dựa vào vị trí trong các lớp đất đá (tuổi tương đối).** Trầm tích lắng đọng từng lớp, lớp sau phủ lên lớp trước. Vì vậy, ở nơi các lớp đất đá **ổn định, không bị xáo trộn**, lớp càng nằm **sâu** thì càng **cổ**, hóa thạch trong đó cũng càng cổ.

![Hình 1. Lớp đất đá càng sâu càng cổ: xếp hóa thạch theo độ sâu cho biết thứ tự xuất hiện của các nhóm sinh vật](hinh-1-dia-tang.svg)

Cách này chỉ cho biết hóa thạch nào **cổ hơn** hóa thạch nào, chưa cho con số cụ thể. Nếu lớp đá bị uốn nếp, đứt gãy do vận động địa chất thì thứ tự có thể bị đảo lộn.

**Cách 2 — Dựa vào đồng vị phóng xạ (tuổi tuyệt đối).** Một số nguyên tố có dạng **đồng vị phóng xạ**, tự phân rã thành nguyên tố khác với tốc độ **không đổi**, không phụ thuộc nhiệt độ hay áp suất. Thời gian để một nửa lượng đồng vị phân rã gọi là **chu kì bán rã**. Đo lượng đồng vị còn lại trong hóa thạch (hoặc trong lớp đá bao quanh hóa thạch), ta tính được thời gian đã trôi qua. Đồng vị phóng xạ giống như một chiếc "đồng hồ cát" tự nhiên.

![Hình 2. Sau mỗi chu kì bán rã, lượng đồng vị phóng xạ còn lại giảm một nửa](hinh-2-ban-ra.svg)

> [!em-co-biet] Mở rộng, ngoài SGK
> - **Carbon-14** (C-14) có chu kì bán rã khoảng **5 730 năm**. Khi còn sống, sinh vật liên tục lấy carbon từ môi trường nên tỉ lệ C-14 trong cơ thể ổn định. Khi chết, việc lấy carbon dừng lại, C-14 chỉ còn phân rã. C-14 dùng cho mẫu có nguồn gốc sinh vật, tuổi đến khoảng 50 000 năm.
> - Hóa thạch hàng triệu năm thì xác định tuổi qua **lớp đá núi lửa** kẹp trên và dưới nó, bằng các đồng vị bán rã rất chậm như kali-40 (chu kì bán rã khoảng 1,25 tỉ năm).
> - Sau n chu kì bán rã, lượng còn lại là (1/2)^n^: còn 50% là qua 1 chu kì, còn 25% là 2 chu kì, còn 12,5% là 3 chu kì.

### 1.3. Hóa thạch cho ta biết những gì?

Khi xếp các hóa thạch thành dãy từ **già nhất đến trẻ nhất**, ta thấy:

1. **Sinh vật đã từng tồn tại** rồi tuyệt chủng (khủng long, voi ma mút) — điều mà các loài hiện nay không thể cho biết.
2. **Thứ tự xuất hiện**: các lớp đá cổ nhất chỉ có sinh vật đơn giản (vi khuẩn, tảo). Càng lên lớp trẻ càng xuất hiện các nhóm phức tạp hơn (cá → lưỡng cư → bò sát → chim, thú). Thế giới sống **biến đổi theo thời gian**, đúng như thuyết tiến hóa dự đoán. Ví dụ, hóa thạch tế bào nhân thực có thành tế bào giống tảo hiện nay được tìm thấy trong đá có tuổi khoảng **1,8 tỉ năm** (SGK tr. 98).
3. **Phân bố** của loài trong quá khứ: tìm thấy hóa thạch ở đâu thì biết loài từng sống ở đó. Đây chính là câu trả lời cho câu hỏi mở đầu bài của SGK.
4. **Dạng trung gian (chuyển tiếp)** giữa hai nhóm sinh vật — bằng chứng rất thuyết phục:
   - **Chim đầu tiên *Archaeopteryx*** (SGK tr. 97–98, Hình 19.1b), sống cách đây khoảng 165 triệu năm (theo SGK). Nó có **lông vũ, cánh** như chim, nhưng vẫn còn **hàm có răng** và **đuôi có các đốt sống** như bò sát. Theo SGK, chim đầu tiên được tiến hóa từ một nhóm bò sát còn răng thuộc **khủng long ăn thịt**.
   - **Cá voi, cá heo**: hóa thạch cho thấy chúng tiến hóa từ một loài **thú móng guốc sống trên cạn**. Các dạng hóa thạch trung gian cho thấy chi sau nhỏ dần, cơ thể ngày càng thích nghi với đời sống dưới nước.

> [!vi-du] Ví dụ 1
> Ở một vách núi có các lớp trầm tích nằm ngang, không bị xáo trộn. Từ trên xuống, nhà khoa học ghi nhận: lớp I có hóa thạch thú; lớp II có hóa thạch bò sát; lớp III có hóa thạch cá; lớp IV chỉ có hóa thạch tảo đơn bào. Lớp đá núi lửa nằm ngay dưới lớp II được xác định bằng đồng vị phóng xạ có tuổi 230 triệu năm. Có thể kết luận gì về (a) thứ tự xuất hiện các nhóm sinh vật và (b) tuổi của hóa thạch bò sát ở lớp II?

> [!goi-y] Gợi ý 1
> Lớp nào lắng đọng trước? Ở nơi không bị xáo trộn, lớp sâu hơn hình thành trước.

> [!goi-y] Gợi ý 2
> Lớp II phủ **lên trên** lớp đá 230 triệu năm. Vậy lớp II hình thành trước hay sau thời điểm đó?

> [!loi-giai] Lời giải
> (a) Thứ tự từ cổ đến trẻ là IV → III → II → I, nên các nhóm xuất hiện theo trình tự: tảo đơn bào → cá → bò sát → thú. Sinh vật đơn giản xuất hiện trước, sinh vật phức tạp xuất hiện sau.
>
> (b) Lớp II nằm trên lớp đá 230 triệu năm nên hình thành **sau** lớp đá đó. Hóa thạch bò sát ở lớp II có tuổi **nhỏ hơn 230 triệu năm**. Muốn biết chính xác hơn cần một lớp đá núi lửa nằm trên lớp II để "kẹp" khoảng tuổi.

> [!vi-du] Ví dụ 2 (mở rộng — tính tuổi bằng C-14)
> Một mẩu xương động vật tìm thấy trong hang có lượng C-14 chỉ còn bằng 12,5% so với xương của động vật đang sống. Biết chu kì bán rã của C-14 là 5 730 năm. Mẩu xương này có tuổi khoảng bao nhiêu năm?

> [!goi-y] Gợi ý 1
> 12,5% là bao nhiêu phần của 100%? Viết dưới dạng $(1/2)^n$.

> [!goi-y] Gợi ý 2
> Mỗi chu kì bán rã lượng C-14 giảm một nửa: 100% → 50% → 25% → 12,5%. Đã qua mấy chu kì?

> [!loi-giai] Lời giải
> Bước 1: 12,5% = 1/8 = (1/2)^3^ → đã qua **3 chu kì bán rã**.
>
> Bước 2: Tuổi = 3 × 5 730 = **17 190 năm** (khoảng 17 nghìn năm).
>
> Bẫy: đề cho tỉ lệ **đã phân rã** (ví dụ "đã phân rã 75%") thì phải đổi ra tỉ lệ **còn lại** (25%) trước khi tính.

### 1.4. Ưu điểm và hạn chế của bằng chứng hóa thạch

| Ưu điểm | Hạn chế |
|---|---|
| Là bằng chứng **trực tiếp**: thấy tận mắt sinh vật xưa | **Không đầy đủ**: phần lớn sinh vật không thành hóa thạch, nhiều hóa thạch bị phá hủy hoặc chưa được tìm thấy |
| Xác định được **tuổi**, cho biết sinh vật nào xuất hiện **trước, sau** | Thiên về sinh vật có **phần cứng**; sinh vật thân mềm, vi sinh vật ít để lại dấu vết |
| Cho biết **loài đã tuyệt chủng** và **phân bố** của loài trong quá khứ | Thường chỉ còn hình dạng bên ngoài, khó biết sinh lí, tập tính, vật chất di truyền |
| Có **dạng trung gian** nối các nhóm sinh vật | Không cho biết trực tiếp mức độ họ hàng giữa các loài **đang sống** |

> [!bay]
> Đề thi hay hỏi "bằng chứng nào là **trực tiếp**". Chỉ có **hóa thạch**. Giải phẫu so sánh, tế bào học, sinh học phân tử đều là bằng chứng **gián tiếp** (suy luận từ sinh vật hiện nay).

## 2. Bằng chứng giải phẫu so sánh

Ý tưởng chính: nếu các loài có chung tổ tiên, chúng phải **thừa hưởng** những đặc điểm cấu tạo từ tổ tiên đó, dù ngày nay sống rất khác nhau. So sánh cấu tạo cơ thể các loài sẽ thấy "dấu vết gia đình" này.

### 2.1. Cấu trúc tương đồng

**Cấu trúc tương đồng** (cơ quan tương đồng) là những đặc điểm giống nhau giữa các loài do **cùng thừa hưởng các gene từ tổ tiên chung**. Chúng có **cùng nguồn gốc** (cùng phát triển từ một cơ quan ở tổ tiên), dù hiện nay có thể làm **chức năng khác nhau**.

Ví dụ kinh điển: **chi trước của các loài có xương sống bốn chi** (SGK tr. 98, Hình 19.2). Tay người dùng để cầm nắm, chân mèo để chạy, vây cá voi để bơi, chân ngựa để phi, cánh dơi và cánh chim để bay. Chức năng khác hẳn nhau, nhưng bên trong đều gồm **cùng các loại xương, xếp theo cùng một trình tự**: xương cánh → xương trụ và xương quay → xương cổ bàn → xương bàn → xương ngón.

![Hình 3. Sơ đồ chi trước của người, cá voi, dơi và chim: cùng các loại xương, cùng thứ tự sắp xếp, chỉ khác hình dạng và tỉ lệ (vẽ giản lược)](hinh-3-chi-truoc.svg)

**Vì sao điều này chứng minh chung tổ tiên?** Nếu mỗi loài được "thiết kế riêng" cho chức năng của nó, thì vây bơi và cánh bay chẳng có lí do gì phải dùng cùng một bộ xương. Cách giải thích hợp lí duy nhất: tổ tiên chung đã có bộ xương chi trước như vậy, các loài con cháu **thừa hưởng** rồi **biến đổi** hình dạng, tỉ lệ để thích nghi với các điều kiện sống khác nhau.

Một ví dụ khác: **hươu cao cổ** có cổ dài gấp nhiều lần cổ người, nhưng cũng chỉ có **7 đốt sống cổ**, giống người, chuột, cá voi và hầu hết các loài thú. Cổ dài ra do mỗi đốt sống dài ra chứ không phải do thêm đốt. Điều đó cho thấy các loài thú tiến hóa từ một tổ tiên chung có 7 đốt sống cổ.

> [!em-co-biet] Mở rộng, ngoài SGK
> - Một số cặp cấu trúc tương đồng hay gặp trong đề thi: **tuyến nọc độc của rắn** và **tuyến nước bọt của người** (đều là tuyến tiêu hóa ở miệng); **gai xương rồng** và **tua cuốn của đậu hà lan** (đều do **lá** biến đổi thành); **ruột thừa ở người** và **manh tràng ở thỏ**.
> - Các cấu trúc tương đồng phản ánh **tiến hóa phân li**: từ một dạng tổ tiên, các nhánh con cháu tỏa ra nhiều hướng, cùng một cơ quan biến đổi theo nhiều cách khác nhau.

### 2.2. Cấu trúc thoái hóa

**Cấu trúc thoái hóa** là cấu trúc **không còn chức năng rõ ràng** (hoặc chỉ còn chức năng rất nhỏ), nhưng rất giống một cấu trúc **có chức năng** ở loài tổ tiên. Thường chúng tiêu giảm, kích thước nhỏ.

| Sinh vật | Cấu trúc thoái hóa | Ở tổ tiên / loài họ hàng nó là |
|---|---|---|
| Người | Ruột thừa | Manh tràng lớn giúp tiêu hóa cellulose (như ở thỏ) |
| Người | Lông trên bề mặt cơ thể | Bộ lông dày giữ nhiệt (như ở các loài thú khác) |
| Cá voi | Xương chậu và xương chi sau nhỏ, nằm sâu trong cơ thể | Chân sau của tổ tiên bốn chân sống trên cạn |
| Một số loài rắn (trăn) | Mấu xương nhỏ, không còn chức năng | Chi sau của tổ tiên bò sát có chân |

**Vì sao cấu trúc thoái hóa là bằng chứng tiến hóa?** Một cơ quan "vô dụng" chỉ có thể giải thích được nếu nó là **di sản** từ tổ tiên, nơi nó từng có ích. Khi điều kiện sống thay đổi, cơ quan không còn được dùng, không còn chịu áp lực chọn lọc để duy trì, nên tiêu giảm dần qua nhiều thế hệ nhưng chưa mất hẳn.

Ví dụ: mấu xương nhỏ ở trăn chứng tỏ **tổ tiên của rắn là bò sát có chân**, sau đó chi tiêu giảm dần khi chúng thích nghi với lối sống bò trườn, chui rúc.

> [!ghi-nho]
> Cấu trúc thoái hóa **cũng là một loại cấu trúc tương đồng**: ruột thừa người tương đồng với manh tràng thỏ, xương chi sau cá voi tương đồng với chân sau của thú trên cạn.

### 2.3. Cấu trúc tương tự

**Cấu trúc tương tự** là những đặc điểm giống nhau giữa các loài nhưng **không phải** do thừa hưởng gene từ tổ tiên chung, mà do các loài sống trong **môi trường giống nhau**, chịu tác động chọn lọc giống nhau nên hình thành những đặc điểm giống nhau. Chúng có **chức năng giống nhau** nhưng **nguồn gốc khác nhau**.

Ví dụ (câu hỏi của SGK tr. 99): **cánh chim** và **cánh chuồn chuồn** đều để bay, nhưng:

- cánh chim là **chi trước** biến đổi, có xương bên trong, phủ lông vũ;
- cánh chuồn chuồn là **nếp gấp của lớp vỏ cơ thể**, mỏng, có gân, không có xương.

Hai loại cánh hình thành **độc lập**, không cùng nguồn gốc → đây là cấu trúc **tương tự**, không phải tương đồng.

> [!em-co-biet] Mở rộng, ngoài SGK
> - Các cặp cấu trúc tương tự hay gặp: **mang cá** và **mang tôm**; **chân chuột chũi** và **chân dế dũi** (cùng để đào đất); **gai xương rồng** (do lá biến đổi) và **gai hoa hồng** (do lớp biểu bì của thân mọc ra); **củ khoai lang** (rễ phình to) và **củ khoai tây** (thân phình to).
> - Cấu trúc tương tự phản ánh **tiến hóa đồng quy**: các loài khác nguồn gốc, sống trong điều kiện giống nhau nên "hội tụ" về hình dạng giống nhau.

**Tổng hợp — phân biệt ba loại cấu trúc:**

| | Tương đồng | Thoái hóa | Tương tự |
|---|---|---|---|
| Nguồn gốc | Cùng nguồn gốc | Cùng nguồn gốc (là một dạng tương đồng) | **Khác** nguồn gốc |
| Chức năng hiện nay | Có thể khác nhau | Không còn hoặc rất mờ nhạt | Giống nhau |
| Nguyên nhân giống nhau | Thừa hưởng gene từ tổ tiên chung | Di sản của tổ tiên | Môi trường sống giống nhau |
| Chứng minh chung tổ tiên? | **Có** | **Có** | **Không** |

> [!meo] Cách phân loại nhanh một cặp cơ quan
> Đừng nhìn chức năng trước, hãy hỏi **"chúng phát triển từ bộ phận nào?"**.
> - Cùng bộ phận gốc (cùng là chi trước, cùng là lá, cùng là tuyến ở miệng) → **tương đồng**, dù chức năng khác.
> - Khác bộ phận gốc nhưng cùng chức năng → **tương tự**.
> - Không còn chức năng ở loài đang xét → **thoái hóa** (và tương đồng với cơ quan có chức năng ở loài khác).

> [!bay]
> - "Cùng chức năng" **không** có nghĩa là tương đồng. Cánh chim – cánh bướm cùng để bay nhưng là **tương tự**.
> - "Khác chức năng" **không** có nghĩa là tương tự. Tay người – vây cá voi khác chức năng nhưng là **tương đồng**.
> - Cánh dơi và cánh chim: **xét như chi trước** (bộ xương bên trong) thì tương đồng, vì cùng là chi trước của động vật có xương sống bốn chi. SGK (Hình 19.2) dùng chính chi trước của dơi và chim làm ví dụ tương đồng. Nếu đề hỏi "cánh dơi và cánh **bướm/ong**" thì mới là tương tự.

> [!vi-du] Ví dụ 3
> Cho các cặp cấu trúc: (1) vây ngực cá voi và chân trước ngựa; (2) cánh dơi và cánh bướm; (3) gai xương rồng và tua cuốn đậu hà lan; (4) mang cá và mang tôm; (5) xương chậu tiêu giảm ở cá voi và xương chậu ở chó. Những cặp nào là cấu trúc tương đồng?

> [!goi-y] Gợi ý 1
> Với từng cặp, hỏi: hai cấu trúc phát triển từ **cùng một bộ phận** ở tổ tiên hay không?

> [!goi-y] Gợi ý 2
> Bướm là côn trùng, không có xương. Tôm là giáp xác, mang tôm và mang cá phát triển từ những phần khác nhau của cơ thể. Gai xương rồng và tua cuốn đậu đều là lá biến đổi.

> [!loi-giai] Lời giải
> - (1) Đều là chi trước của thú → **tương đồng**.
> - (2) Cánh dơi là chi trước có xương, cánh bướm là nếp vỏ cơ thể → **tương tự**.
> - (3) Đều do lá biến đổi → **tương đồng**.
> - (4) Cùng chức năng hô hấp, khác nguồn gốc → **tương tự**.
> - (5) Xương chậu cá voi là cấu trúc thoái hóa, cùng nguồn gốc với xương chậu chó → **tương đồng**.
>
> Kết luận: các cặp tương đồng là **(1), (3), (5)**.

## 3. Bằng chứng tế bào học và sinh học phân tử

Hóa thạch và giải phẫu so sánh rất hữu ích với động vật, thực vật lớn. Nhưng làm sao so sánh một con người với một vi khuẩn, hay một cây lúa với một con nấm men? Khi đó ta phải "nhìn sâu" hơn, xuống cấp độ **tế bào** và **phân tử**.

### 3.1. Bằng chứng tế bào học

Ở cấp độ tế bào, mọi sinh vật trên Trái Đất có những điểm chung rất cơ bản:

- **Đều được cấu tạo từ tế bào**: sinh vật đơn bào gồm một tế bào, sinh vật đa bào gồm nhiều tế bào.
- **Tế bào có cấu trúc giống nhau**: đều có **màng tế bào** (màng sinh chất), **tế bào chất** (có ribosome) và **vùng nhân** (ở tế bào nhân sơ) hoặc **nhân** (ở tế bào nhân thực).
- **Các hoạt động chuyển hóa vật chất và năng lượng cơ bản giống nhau**: ví dụ mọi tế bào đều dùng ATP làm "đồng tiền năng lượng", đều phân giải đường để lấy năng lượng qua những giai đoạn giống nhau.
- Tế bào mới chỉ được tạo ra từ tế bào có trước bằng cách **phân chia tế bào**.

**Vì sao đây là bằng chứng chung nguồn gốc?** Có vô số cách có thể "thiết kế" một sinh vật. Việc mọi sinh vật, từ vi khuẩn đến cây cối, con người, đều dùng **cùng một kiểu đơn vị cấu tạo** và **cùng các con đường chuyển hóa cơ bản** chỉ được giải thích hợp lí nếu tất cả bắt nguồn từ một tổ tiên chung đã có những đặc điểm đó.

> [!bay]
> Điểm khác nhau giữa tế bào nhân sơ và nhân thực (có/không có màng nhân, có/không có bào quan có màng) phản ánh **sự phân hóa** trong quá trình tiến hóa, không phủ nhận chung nguồn gốc. Đề thi hay hỏi đây là bằng chứng của chung nguồn gốc hay của sự khác biệt: các **điểm giống** chứng minh **chung nguồn gốc**.

### 3.2. Bằng chứng sinh học phân tử

Đây là loại bằng chứng mạnh nhất hiện nay, vì nó cho phép **đo** mức độ họ hàng bằng con số.

**(a) Điểm chung ở cấp phân tử của mọi sinh vật:**

- Đều có các thành phần hóa học cơ bản như nhau (nucleic acid, protein, carbohydrate, lipid).
- Vật chất di truyền đều là **DNA**.
- **Mã di truyền** về cơ bản **dùng chung** cho mọi loài (tính phổ biến). Nhờ vậy, gene insulin của người chuyển vào vi khuẩn vẫn được dịch mã thành đúng insulin của người.
- Protein ở hầu hết các loài đều được cấu tạo từ **20 loại amino acid**.

**(b) Mức độ giống nhau cho biết mức độ họ hàng.** Khi hai loài tách ra từ một tổ tiên chung, mỗi nhánh tự **tích lũy đột biến** riêng theo thời gian. Thời gian tách nhau càng lâu, số khác biệt tích lũy càng nhiều. Vì vậy:

> [!ghi-nho]
> Các loài có họ hàng **càng gần** thì trình tự nucleotide của gene và trình tự amino acid của protein **càng giống nhau** (càng ít khác biệt).

SGK minh họa bằng **cytochrome c**, một protein tham gia hô hấp tế bào có ở hầu hết sinh vật (SGK tr. 99, Bảng 19.1). Số amino acid khác biệt so với cytochrome c của người:

![Hình 4. Số amino acid khác biệt trong cytochrome c của một số loài so với người (số liệu theo Bảng 19.1 SGK tr. 99)](hinh-4-cytochrome.svg)

Đọc biểu đồ:

- **Tinh tinh: 0 khác biệt** → họ hàng gần người nhất. Hai loài mới tách khỏi tổ tiên chung chưa lâu, thời gian chưa đủ để đột biến tạo khác biệt ở protein này.
- Khỉ Rhesus (1) → các loài thú khác như thỏ (9), bò (10) → chim bồ câu (12) → lưỡng cư ễnh ương (18) → côn trùng ruồi giấm (25) → nấm men (40): **càng xa người trong phân loại, khác biệt càng nhiều**.
- Thứ tự này **khớp** với thứ tự rút ra từ hóa thạch và giải phẫu so sánh. Ba loại bằng chứng độc lập cho cùng một kết quả là điều rất thuyết phục.
- Ngay cả nấm men cũng có cytochrome c giống người ở phần lớn vị trí (cytochrome c của người dài 104 amino acid, nấm men chỉ khác 40), chứng tỏ người và nấm cũng có chung tổ tiên, dù rất xa xưa.

> [!bay]
> - Bảng cho **số khác biệt**, không phải số giống nhau: số **càng nhỏ** thì họ hàng **càng gần**. Đừng đọc ngược.
> - Bảng chỉ so sánh **từng loài với người**. Muốn kết luận về họ hàng giữa thỏ và bò, cần số liệu so sánh trực tiếp thỏ với bò.

**(c) Phân tử "lật tẩy" họ hàng bị che khuất.** Đôi khi hình thái khác nhau nhưng phân tử cho thấy chung nguồn gốc. Ví dụ ở **cá băng** vùng Nam Cực (họ Channichthyidae): máu chúng trong suốt vì **không có hemoglobin**. Nhưng trong hệ gene của chúng vẫn còn **gene hemoglobin bị đột biến mất chức năng**. Gene "hỏng" này là dấu vết chứng tỏ cá băng tiến hóa từ loài cá **có hemoglobin**, giống như cấu trúc thoái hóa nhưng ở cấp phân tử. (Nước Nam Cực rất lạnh, hòa tan nhiều oxygen, nên cá băng vẫn sống được khi mất hemoglobin.)

**(d) Truy tìm nguồn gốc trong cùng một loài.** So sánh trình tự **DNA ti thể** của các chủng tộc người khắp thế giới cho thấy các quần thể ở **châu Phi** có mức đa dạng DNA ti thể cao nhất và các dòng ở châu lục khác đều "mọc ra" từ các dòng châu Phi. Kết luận: loài người hiện đại xuất hiện ở châu Phi rồi di cư đến các châu lục khác.

> [!em-co-biet] Mở rộng, ngoài SGK: vì sao chọn DNA ti thể?
> - DNA ti thể di truyền **theo dòng mẹ**, không trộn lẫn với DNA của bố qua thụ tinh, nên "lưu vết" dòng họ rất rõ.
> - Mỗi tế bào có nhiều ti thể, nhiều bản sao DNA ti thể → dễ thu mẫu, kể cả từ xương cổ.
> - DNA ti thể tích lũy đột biến khá nhanh → phân biệt được cả các quần thể tách nhau chưa lâu.

> [!vi-du] Ví dụ 4
> Cytochrome c của người gồm 104 amino acid. Theo Bảng 19.1 (SGK tr. 99), cytochrome c của bò khác người 10 amino acid, của ễnh ương khác người 18 amino acid.
> (a) Tính tỉ lệ phần trăm amino acid giống nhau giữa người và bò (làm tròn đến hàng phần mười).
> (b) Từ số liệu, người có họ hàng gần với bò hay với ễnh ương hơn? Điều này có phù hợp với phân loại không?

> [!goi-y] Gợi ý 1
> Số vị trí giống = tổng số amino acid − số vị trí khác.

> [!goi-y] Gợi ý 2
> Số khác biệt càng nhỏ thì họ hàng càng gần. Người, bò thuộc lớp nào? Ễnh ương thuộc lớp nào?

> [!loi-giai] Lời giải
> (a) Số vị trí giống = 104 − 10 = 94. Tỉ lệ giống = 94 : 104 × 100% ≈ **90,4%**.
>
> (b) Bò khác người 10, ễnh ương khác người 18 → người **gần bò hơn**. Phù hợp với phân loại: người và bò cùng thuộc lớp Thú, còn ễnh ương thuộc lớp Lưỡng cư, tách khỏi nhánh của thú từ lâu hơn.

> [!ung-dung] Ứng dụng (ngoài SGK)
> So sánh trình tự DNA giúp xác định nguồn gốc giống cây trồng, vật nuôi, truy tìm nguồn lây của virus, và phân loại lại những sinh vật có hình thái dễ gây nhầm lẫn (ví dụ cá voi có họ hàng gần với hà mã, khớp với hóa thạch cho thấy tổ tiên cá voi là thú móng guốc).

## 4. Các bằng chứng bổ sung cho nhau

Không loại bằng chứng nào "một mình đủ cả". Sức thuyết phục của thuyết tiến hóa đến từ chỗ **nhiều loại bằng chứng độc lập cùng chỉ về một hướng**.

| | Hóa thạch | Giải phẫu so sánh | Tế bào học | Sinh học phân tử |
|---|---|---|---|---|
| Trực tiếp / gián tiếp | Trực tiếp | Gián tiếp | Gián tiếp | Gián tiếp |
| Cho biết thời gian? | Có (tuổi) | Không | Không | Ước tính được |
| Áp dụng cho mọi sinh vật? | Không (thiếu nhiều nhóm) | Chủ yếu sinh vật đa bào | Có | **Có** |
| Đo mức độ họ hàng? | Hạn chế | Định tính | Rất thô | **Định lượng** |

**Bằng chứng nào xác định được mối quan hệ họ hàng và nguồn gốc của mọi loài đang sống?** (SGK tr. 100, Luyện tập 2). Đó là **bằng chứng sinh học phân tử** (kết hợp tế bào học). Lí do: mọi sinh vật, kể cả vi khuẩn không có xương, không để lại hóa thạch, đều có DNA và protein. So sánh trình tự cho con số cụ thể về mức độ giống nhau, từ đó xếp được tất cả các loài vào một "cây gia đình" chung.

## Dạng bài thi hay gặp

### Dạng 1. Phân loại cấu trúc tương đồng / thoái hóa / tương tự

*Nhận biết:* cho một hoặc nhiều cặp cơ quan, hỏi cặp nào tương đồng, cặp nào tương tự, hoặc đếm số cặp.

*Phương pháp:*
1. Với mỗi cặp, xác định **bộ phận gốc** của từng cấu trúc (chi trước, lá, thân, rễ, tuyến miệng, vỏ cơ thể…).
2. Cùng bộ phận gốc → tương đồng. Khác bộ phận gốc nhưng cùng chức năng → tương tự.
3. Cấu trúc tiêu giảm, mất chức năng → thoái hóa (cũng là tương đồng).

> [!vi-du] Ví dụ 5
> Cho các cặp cấu trúc: (1) cánh chim và cánh ong; (2) tay người và cánh dơi; (3) gai xương rồng và gai hoa hồng; (4) tuyến nọc độc của rắn và tuyến nước bọt của người; (5) chân chuột chũi và chân dế dũi; (6) ruột thừa ở người và manh tràng ở thỏ. Có bao nhiêu cặp là cấu trúc tương tự?

> [!goi-y] Gợi ý 1
> Tìm cặp nào gồm một động vật có xương sống và một côn trùng: đó gần như chắc chắn là tương tự.

> [!goi-y] Gợi ý 2
> Gai xương rồng do lá biến đổi, gai hoa hồng do biểu bì thân mọc ra.

> [!loi-giai] Lời giải
> - Tương tự: (1) chim – ong; (3) lá – biểu bì thân; (5) thú – côn trùng.
> - Tương đồng: (2), (4), (6) (trong đó ruột thừa là cấu trúc thoái hóa).
>
> Có **3** cặp tương tự.

*Bẫy:* phân loại theo chức năng thay vì nguồn gốc; quên rằng cấu trúc thoái hóa cũng được tính là tương đồng.

### Dạng 2. Nhận diện loại bằng chứng và ý nghĩa

*Nhận biết:* cho một mô tả (tìm thấy xương trong đá, so sánh protein, mọi tế bào đều có màng…), hỏi đó là bằng chứng gì, chứng minh điều gì.

*Phương pháp:* nhìn **đối tượng** được nghiên cứu.
- Di tích trong đất đá, hổ phách, băng → **hóa thạch** (trực tiếp).
- Cấu tạo cơ quan, xương, đốt sống của loài đang sống → **giải phẫu so sánh**.
- Màng, tế bào chất, nhân, chuyển hóa tế bào → **tế bào học**.
- DNA, mã di truyền, amino acid, trình tự → **sinh học phân tử**.

> [!vi-du] Ví dụ 6
> Các nhà khoa học nhận thấy gene quy định một loại enzyme ở người và ở chuột có trình tự nucleotide giống nhau 85%, còn ở người và gà giống nhau 75%. Đây là loại bằng chứng gì? Kết luận nào có thể rút ra?

> [!goi-y] Gợi ý 1
> Đối tượng được so sánh là trình tự nucleotide.

> [!goi-y] Gợi ý 2
> Mức giống nhau cao hơn → họ hàng gần hơn.

> [!loi-giai] Lời giải
> Đây là **bằng chứng sinh học phân tử**. Vì người – chuột giống nhau nhiều hơn người – gà, nên người có họ hàng **gần chuột hơn gà**. Cả ba loài vẫn giống nhau ở phần lớn trình tự, chứng tỏ chúng có chung tổ tiên.

*Bẫy:* coi "giống nhau về chức năng" là bằng chứng chung nguồn gốc. Đề cũng hay cài ý "hóa thạch là bằng chứng gián tiếp" hoặc "sinh học phân tử là bằng chứng trực tiếp" — **sai**.

### Dạng 3. Đọc bảng số liệu phân tử, suy ra quan hệ họ hàng

*Nhận biết:* bảng số khác biệt (hoặc % giống nhau) về amino acid / nucleotide giữa các loài, hỏi loài nào gần nhất, xa nhất, sắp xếp thứ tự, hoặc tính % giống.

*Phương pháp:*
1. Xác định bảng cho **số khác biệt** hay **mức giống nhau** (đọc kĩ tiêu đề cột).
2. Khác biệt càng ít (giống càng nhiều) → họ hàng càng gần.
3. Tính % giống = (tổng số vị trí − số vị trí khác) : tổng số vị trí × 100%.
4. Với bảng so sánh từng cặp nhiều loài: hai loài có khác biệt **nhỏ nhất** là cặp gần nhau nhất, tách nhau **muộn nhất**.

> [!vi-du] Ví dụ 7
> So sánh một đoạn gene dài 200 nucleotide giữa bốn loài giả định P, Q, R, S, người ta đếm được số nucleotide khác nhau giữa từng cặp:
>
> | | P | Q | R |
> |---|---|---|---|
> | Q | 6 | | |
> | R | 20 | 18 | |
> | S | 31 | 30 | 28 |
>
> (a) Hai loài nào có họ hàng gần nhau nhất? (b) Loài nào tách ra khỏi nhóm sớm nhất? (c) Tính tỉ lệ % nucleotide giống nhau giữa P và R.

> [!goi-y] Gợi ý 1
> Tìm ô có số nhỏ nhất trong bảng.

> [!goi-y] Gợi ý 2
> Loài tách ra sớm nhất là loài khác nhiều nhất với **tất cả** các loài còn lại.

> [!loi-giai] Lời giải
> (a) Ô nhỏ nhất là 6 → **P và Q** gần nhau nhất.
>
> (b) S khác P, Q, R lần lượt 31, 30, 28, đều lớn hơn mọi khác biệt còn lại → **S** tách ra sớm nhất. Tiếp theo đến R (khác P, Q khoảng 18–20), cuối cùng P và Q mới tách nhau. Cây họ hàng: S tách trước, rồi R, rồi P – Q.
>
> (c) P – R khác 20 nucleotide → giống 200 − 20 = 180 → 180 : 200 × 100% = **90%**.

*Bẫy:* đọc nhầm "số khác biệt" thành "số giống nhau"; so sánh hai loài qua trung gian (thỏ khác người 9, bò khác người 10 không có nghĩa là thỏ khác bò 1).

## Tóm tắt

| Bằng chứng | Nội dung chính | Ví dụ tiêu biểu |
|---|---|---|
| Hóa thạch (trực tiếp) | Di tích sinh vật trong đất đá. Tuổi xác định theo lớp đất đá và đồng vị phóng xạ. Cho thấy sinh vật xuất hiện, biến đổi theo thời gian, có dạng trung gian | *Archaeopteryx* (chim – bò sát); cá voi từ thú móng guốc trên cạn; tế bào nhân thực 1,8 tỉ năm |
| Giải phẫu so sánh | Tương đồng (cùng nguồn gốc) và thoái hóa chứng minh chung tổ tiên. Tương tự (khác nguồn gốc, cùng chức năng) không chứng minh họ hàng | Chi trước người – mèo – cá voi – dơi – chim; 7 đốt sống cổ; ruột thừa; xương chi sau cá voi |
| Tế bào học | Mọi sinh vật cấu tạo từ tế bào, có màng, tế bào chất, vùng nhân/nhân, chuyển hóa cơ bản giống nhau | Vi khuẩn, nấm, thực vật, động vật đều dùng ATP |
| Sinh học phân tử | DNA, mã di truyền chung, 20 amino acid. Trình tự càng giống → họ hàng càng gần | Cytochrome c: tinh tinh 0, nấm men 40 khác biệt; gene hemoglobin hỏng ở cá băng; DNA ti thể → người từ châu Phi |

**Ba câu then chốt:**
- Tương đồng → **cùng nguồn gốc**; tương tự → **cùng chức năng**.
- Ít khác biệt phân tử → **họ hàng gần**.
- Hóa thạch là bằng chứng **trực tiếp**; sinh học phân tử áp dụng được cho **mọi loài**.
