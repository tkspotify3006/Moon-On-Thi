/* =========================================================
   onthi.js — Bộ đề ôn thi NHẬP RIÊNG trên máy (không nằm trên GitHub)
   - Người dùng chọn file .json bộ đề → lưu trong localStorage của máy này.
   - Luyện theo mức/phần, thi thử có bấm giờ, câu sai tự vào Ôn tập.
   Khóa câu hỏi trong Store: "<môn>/@<mã-bộ-đề>#<mã-câu>"
     ví dụ "nam-1/vat-ly/@ly-sinh-on-tap#m1p1-01"
     → lọc theo môn ở trang Ôn tập vẫn đúng (bắt đầu bằng "nam-1/vat-ly/").
   Định dạng file: xem HUONG-DAN-NOI-DUNG.md, mục "Bộ đề ôn thi".
   ========================================================= */
(function () {
  const C = window.Content;
  const { esc, mdInline } = C;
  const KEY = 'onThiThpt.banks';
  const view = () => document.getElementById('view');
  const LETTERS = 'ABCDEFGH';

  /* ---------------- Lưu trữ bộ đề ---------------- */
  let banks = {};
  try { banks = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { banks = {}; }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(banks)); return true; } catch (e) { return false; }
  }

  // Bộ đề là file người dùng tự chọn → chỉ cho phép thẻ <sub> <sup> <br>, chặn link Markdown
  const safe = s => String(s ?? '')
    .replace(/<(?!\/?(?:sub|sup)>|br\s*\/?>)/gi, '&lt;')
    .replace(/\]\(/g, ']​(');

  function validate(b) {
    if (!b || b.kind !== 'hocy-bank' || !Array.isArray(b.questions)) throw new Error('File không phải bộ đề ôn thi của app');
    if (!/^[a-z0-9-]{1,40}$/.test(b.id || '')) throw new Error('Mã bộ đề không hợp lệ');
    const subject = /^[a-z0-9-]+\/[a-z0-9-]+$/.test(b.subject || '') ? b.subject : 'khac/khac';
    const qs = [], seen = new Set();
    for (const q of b.questions) {
      if (!q || typeof q.id !== 'string' || seen.has(q.id) || !/^[\w.-]{1,40}$/.test(q.id)) continue;
      if (!Array.isArray(q.options) || q.options.length < 2 || q.options.length > 8) continue;
      if (!Number.isInteger(q.answer) || q.answer < 0 || q.answer >= q.options.length) continue;
      seen.add(q.id);
      const item = {
        id: q.id, group: String(q.group || 'chung'), n: q.n, type: 'mcq',
        level: [1, 2, 3].includes(q.level) ? q.level : undefined,
        levelLabel: q.levelLabel ? String(q.levelLabel).slice(0, 20) : undefined,
        q: safe(q.q), options: q.options.map(safe), answer: q.answer,
        explain: q.explain ? safe(q.explain) : '', warn: q.warn ? safe(q.warn) : ''
      };
      if (q.see && /^[a-z0-9-]+\/[a-z0-9-]+\/[a-z0-9-]+$/.test(q.see.lesson || '')) item.see = { lesson: q.see.lesson, h: /^[a-z0-9-]*$/.test(q.see.h || '') ? q.see.h : '' };
      qs.push(item);
    }
    if (!qs.length) throw new Error('Bộ đề không có câu hỏi hợp lệ');
    const groups = [];
    for (const q of qs) {
      let g = groups.find(x => x.id === q.group);
      if (!g) {
        const src = (b.groups || []).find(x => x && x.id === q.group) || {};
        g = { id: q.group, title: String(src.title || q.group).slice(0, 80), level: src.level || q.level || 0, count: 0 };
        groups.push(g);
      }
      g.count++;
    }
    return {
      kind: 'hocy-bank', id: b.id, subject,
      title: String(b.title || b.id).slice(0, 80), short: String(b.short || b.title || b.id).slice(0, 30),
      note: b.note ? String(b.note).slice(0, 400) : '', version: String(b.version || '').slice(0, 20),
      groups, questions: qs, importedAt: Date.now()
    };
  }

  const Banks = {
    list: () => Object.values(banks).sort((a, b) => a.title.localeCompare(b.title, 'vi')),
    get: id => banks[id],
    add(raw) {
      const b = validate(raw);
      const replaced = !!banks[b.id];
      const old = banks[b.id];
      banks[b.id] = b;
      if (!save()) { if (old) banks[b.id] = old; else delete banks[b.id]; throw new Error('Bộ nhớ máy không đủ để lưu bộ đề'); }
      return { bank: b, replaced };
    },
    remove(id) { delete banks[id]; save(); },
    key: (b, q) => `${b.subject}/@${b.id}#${q.id}`,
    // trả về câu hỏi cho trang Ôn tập; null nếu khóa không thuộc bộ đề
    item(key) {
      const m = key.match(/\/@([a-z0-9-]+)#(.+)$/);
      if (!m) return undefined;              // không phải câu của bộ đề
      const b = banks[m[1]]; if (!b) return null; // bộ đề đã bị xóa khỏi máy
      const q = b.questions.find(x => x.id === m[2]); if (!q) return null;
      return { key, q, lesson: { title: b.short }, href: `#/on-thi/${b.id}` };
    }
  };
  window.Banks = Banks;

  /* ---------------- Tiện ích ---------------- */
  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  const itemsOf = (b, qs) => qs.map(q => ({ key: Banks.key(b, q), q, lesson: { title: b.short } }));
  function stat(b, qs) {
    let done = 0, ok = 0, review = 0;
    for (const q of qs) {
      const r = Store.q(Banks.key(b, q));
      if (r && r.seen) { done++; if (r.lastResult === 'dung') ok++; }
      if (Store.inReview(r)) review++;
    }
    return { done, ok, review, total: qs.length };
  }
  const LEVEL_NAMES = { 1: 'Mức độ 1', 2: 'Bậc 2', 3: 'Mức độ 3' };
  function levelsOf(b) {
    const lv = [...new Set(b.groups.map(g => g.level || 0))].sort();
    return lv.map(l => ({ l, name: b.groups.find(g => (g.level || 0) === l).title.split(' — ')[0] || LEVEL_NAMES[l] || 'Khác' }));
  }

  async function readFile(input) {
    const f = input.files[0]; if (!f) return;
    try {
      const { bank, replaced } = Banks.add(JSON.parse(await f.text()));
      App.toast(`${replaced ? 'Đã cập nhật' : 'Đã nhập'} bộ đề: ${bank.questions.length} câu`);
      const target = '#/on-thi/' + bank.id;
      if (location.hash === target) route(['on-thi', bank.id], new URLSearchParams()); else location.hash = target;
    } catch (err) {
      App.toast('Không nhập được: ' + (err instanceof SyntaxError ? 'file hỏng hoặc không phải .json' : err.message));
    }
    input.value = '';
  }

  const importBtn = (label, cls = 'btn') =>
    `<label class="${cls}" style="cursor:pointer">${label}<input type="file" accept="application/json,.json" data-import hidden></label>`;
  function wireImport() { view().querySelectorAll('[data-import]').forEach(i => i.onchange = () => readFile(i)); }

  /* ---------------- Màn hình: danh sách bộ đề ---------------- */
  function list() {
    App.setTop('Ôn thi theo đề cương', '#/on-tap');
    const bs = Banks.list();
    view().innerHTML = `
      ${bs.length ? `<ul class="lesson-list">${bs.map(b => {
        const s = stat(b, b.questions);
        return `<li><a class="lesson-item ready" href="#/on-thi/${b.id}">
          <span class="num">${s.total}</span>
          <span class="grow"><div class="t">${esc(b.title)}</div>
          <div class="s">Đã làm ${s.done}/${s.total} câu · đúng ${s.ok}${s.review ? ` · ${s.review} câu đang ôn` : ''}</div></span></a></li>`;
      }).join('')}</ul>` : `<div class="card empty">Chưa có bộ đề nào trên máy này.</div>`}
      <div class="stack" style="margin-top:16px">${importBtn(bs.length ? 'Nhập / cập nhật bộ đề (.json)' : 'Nhập bộ đề (.json)', 'btn primary block')}</div>
      <div class="card small" style="margin-top:16px">
        <p style="margin-top:0"><b>Bộ đề lưu riêng trên máy này</b>, không đưa lên mạng — phù hợp với tài liệu ôn tập lưu hành nội bộ.</p>
        <p>Cách nhập: chép file bộ đề (đuôi <code>.json</code>) vào điện thoại (Zalo, email, Drive…), bấm <b>Nhập bộ đề</b> rồi chọn file. Nhập lại file mới cùng bộ đề sẽ cập nhật mà <b>vẫn giữ tiến độ</b>.</p>
        <p style="margin-bottom:0" class="muted">Đổi máy hoặc xóa dữ liệu trình duyệt thì cần nhập lại file bộ đề (tiến độ khôi phục bằng file sao lưu ở Cài đặt).</p>
      </div>`;
    wireImport();
  }

  /* ---------------- Màn hình: tổng quan một bộ đề ---------------- */
  function overview(b) {
    App.setTop(b.short, '#/on-thi');
    const all = stat(b, b.questions);
    const nWarn = b.questions.filter(q => q.warn).length;
    const levels = levelsOf(b);
    const st = Store.settings();
    const examN = st.examN || 50, examT = st.examT !== false;
    view().innerHTML = `
      <div class="card stack">
        <div><b>${esc(b.title)}</b>${b.version ? ` <span class="chip">${esc(b.version)}</span>` : ''}</div>
        ${b.note ? `<div class="small muted">${mdInline(b.note)}</div>` : ''}
        <div class="bar"><i style="width:${(all.done / all.total) * 100}%"></i></div>
        <div class="small muted">Đã làm ${all.done}/${all.total} câu · đúng ở lần làm gần nhất ${all.ok}</div>
      </div>
      <div class="stats" style="margin-top:12px">
        <div class="stat"><b>${all.total}</b><span>Câu hỏi</span></div>
        <div class="stat"><b>${all.done}</b><span>Đã làm</span></div>
        <div class="stat"><b>${all.review}</b><span>Đang ôn (sai)</span></div>
      </div>

      <div class="section-title">Thi thử</div>
      <div class="card stack">
        <div class="row"><span class="grow small"><b>Số câu</b></span>
          <div class="seg" id="exN">${[20, 30, 50, 100].map(n => `<button data-v="${n}" aria-pressed="${examN === n}">${n}</button>`).join('')}</div></div>
        <div class="row"><span class="grow small"><b>Mức độ</b></span>
          <div class="row" id="exL">${levels.length > 1 ? `<button class="chip" data-v="" aria-pressed="true">Tất cả</button>` : ''}${levels.map(x => `<button class="chip" data-v="${x.l}" aria-pressed="${levels.length === 1}">${esc(x.name)}</button>`).join('')}</div></div>
        <label class="row small" style="cursor:pointer"><input type="checkbox" id="exT" ${examT ? 'checked' : ''} style="width:18px;height:18px;accent-color:var(--accent)"> Bấm giờ (1 phút/câu, hết giờ tự nộp)</label>
        <button class="btn primary block" id="exGo">Bắt đầu thi thử</button>
        <div class="small muted">Đề rút ngẫu nhiên theo tỉ lệ từng phần, trộn thứ tự đáp án. Chỉ chấm khi nộp bài; câu sai tự vào Ôn tập.</div>
      </div>

      <div class="section-title">Luyện theo phần</div>
      ${all.review ? `<a class="btn block" style="margin-bottom:10px" href="#/on-thi/${b.id}/luyen?loai=sai">Ôn ${all.review} câu đang sai của bộ đề</a>` : ''}
      ${nWarn ? `<a class="btn block" style="margin-bottom:10px" href="#/on-thi/${b.id}/luyen?loai=canhbao">⚠ ${nWarn} câu đề có vấn đề — nên hỏi lại giảng viên</a>` : ''}
      ${levels.map(x => {
        const gs = b.groups.filter(g => (g.level || 0) === x.l);
        return `<ul class="lesson-list" style="margin-bottom:10px">${gs.map(g => {
          const qs = b.questions.filter(q => q.group === g.id);
          const s = stat(b, qs);
          const notOk = s.total - s.ok;
          return `<li><div class="lesson-item ${s.done === s.total && s.ok === s.total ? 'done' : 'ready'}">
            <a class="num" href="#/on-thi/${b.id}/luyen?g=${encodeURIComponent(g.id)}" style="text-decoration:none" aria-hidden="true" tabindex="-1">${s.ok === s.total ? '✓' : s.total}</a>
            <a class="grow" href="#/on-thi/${b.id}/luyen?g=${encodeURIComponent(g.id)}" style="text-decoration:none;color:inherit">
              <div class="t">${esc(g.title)}</div>
              <div class="s">${s.total} câu · đã làm ${s.done} · đúng ${s.ok}</div>
              <div class="bar" style="margin-top:6px"><i style="width:${(s.ok / s.total) * 100}%"></i></div></a>
            ${s.done && notOk ? `<a class="chip accent" href="#/on-thi/${b.id}/luyen?g=${encodeURIComponent(g.id)}&loai=chua" title="Chỉ làm các câu chưa đúng">${notOk} chưa đúng</a>` : ''}
          </div></li>`;
        }).join('')}</ul>`;
      }).join('')}

      <div class="section-title">Quản lý</div>
      <div class="card">
        <div class="setting"><div class="l"><b>Cập nhật bộ đề</b><div class="small muted">Chọn file bộ đề mới (giữ nguyên tiến độ).</div></div>${importBtn('Chọn file')}</div>
        <div class="setting"><div class="l"><b>Xóa bộ đề khỏi máy</b><div class="small muted">Tiến độ đã làm vẫn giữ lại.</div></div><button class="btn" id="rm" style="color:var(--bad)">Xóa</button></div>
      </div>`;
    wireImport();
    const v = view();
    v.querySelectorAll('#exN button').forEach(x => x.onclick = () => {
      v.querySelectorAll('#exN button').forEach(y => y.setAttribute('aria-pressed', y === x)); Store.setSetting('examN', +x.dataset.v);
    });
    v.querySelectorAll('#exL button').forEach(x => x.onclick = () => {
      v.querySelectorAll('#exL button').forEach(y => y.setAttribute('aria-pressed', y === x));
    });
    v.querySelector('#exT').onchange = e => Store.setSetting('examT', e.target.checked);
    v.querySelector('#exGo').onclick = () => {
      const n = +(v.querySelector('#exN [aria-pressed="true"]') || {}).dataset?.v || 50;
      const sel = v.querySelector('#exL [aria-pressed="true"]');
      const lv = sel ? sel.dataset.v : '';
      location.hash = `#/on-thi/${b.id}/thi?n=${n}${lv ? '&lv=' + lv : ''}${v.querySelector('#exT').checked ? '&gio=1' : ''}`;
    };
    v.querySelector('#rm').onclick = e => {
      const btn = e.currentTarget;
      if (btn.dataset.confirm) { Banks.remove(b.id); App.toast('Đã xóa bộ đề khỏi máy'); location.hash = '#/on-thi'; }
      else { btn.dataset.confirm = 1; btn.textContent = 'Bấm lần nữa để xóa'; }
    };
  }

  /* ---------------- Luyện tập (dùng màn hình quiz chung) ---------------- */
  function practice(b, params) {
    const g = params.get('g'), loai = params.get('loai');
    let qs = g ? b.questions.filter(q => q.group === g) : b.questions;
    if (loai === 'chua') qs = qs.filter(q => (Store.q(Banks.key(b, q)) || {}).lastResult !== 'dung');
    if (loai === 'sai') qs = qs.filter(q => Store.inReview(Store.q(Banks.key(b, q))));
    if (loai === 'canhbao') qs = qs.filter(q => q.warn);
    const grp = g && b.groups.find(x => x.id === g);
    const title = loai === 'sai' ? 'Ôn câu sai — ' + b.short : loai === 'canhbao' ? 'Câu cần hỏi lại giảng viên' : (grp ? grp.title : b.short) + (loai === 'chua' ? ' (câu chưa đúng)' : '');
    App.setTop(title, '#/on-thi/' + b.id);
    if (!qs.length) { view().innerHTML = `<div class="empty">Không còn câu nào ở đây. <a href="#/on-thi/${b.id}">Quay lại</a></div>`; return; }
    Quiz.run(view(), itemsOf(b, qs), { title, mode: loai === 'sai' ? 'review' : 'lesson', backHref: '#/on-thi/' + b.id, backText: 'Về bộ đề', showExplain: true });
  }

  /* ---------------- Thi thử ---------------- */
  let examTimer = null;
  function stopExam() { if (examTimer) { clearInterval(examTimer); examTimer = null; } }

  function pickExam(b, n, lv) {
    const pool = b.questions.filter(q => !lv || String(q.level || 0) === lv);
    if (n >= pool.length) return shuffle(pool);
    // chia theo tỉ lệ số câu từng phần (làm tròn kiểu "phần dư lớn nhất")
    const byG = new Map();
    for (const q of pool) { if (!byG.has(q.group)) byG.set(q.group, []); byG.get(q.group).push(q); }
    const parts = [...byG.entries()].map(([g, qs]) => { const exact = n * qs.length / pool.length; return { qs, k: Math.floor(exact), rem: exact % 1 }; });
    let left = n - parts.reduce((s, p) => s + p.k, 0);
    parts.slice().sort((a, b2) => b2.rem - a.rem).forEach(p => { if (left > 0 && p.k < p.qs.length) { p.k++; left--; } });
    return shuffle(parts.flatMap(p => shuffle(p.qs).slice(0, p.k)));
  }

  function exam(b, params) {
    stopExam();
    const tok = App.seq;
    const n = Math.max(5, Math.min(200, +params.get('n') || 50));
    const lv = params.get('lv') || '';
    const timed = params.get('gio') === '1';
    const qs = pickExam(b, n, lv);
    const items = qs.map(q => ({ q, key: Banks.key(b, q), perm: shuffle(q.options.map((_, k) => k)), pick: null }));
    const limit = timed ? items.length * 60 : 0;
    const t0 = Date.now();
    let i = 0, submitted = false;
    App.setTop(`Thi thử · ${items.length} câu`, '#/on-thi/' + b.id);

    const fmt = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
    function tick() {
      if (tok !== App.seq) return stopExam();
      const el = document.getElementById('exTime'); if (!el) return;
      const used = Math.floor((Date.now() - t0) / 1000);
      if (limit) {
        const left = Math.max(0, limit - used);
        el.textContent = '⏱ ' + fmt(left); el.classList.toggle('bad', left <= 60);
        if (!left) { App.toast('Hết giờ — đã tự nộp bài'); submit(); }
      } else el.textContent = '⏱ ' + fmt(used);
    }

    function show() {
      const it = items[i], q = it.q;
      const answered = items.filter(x => x.pick !== null).length;
      view().innerHTML = `
        <div class="quiz-top">
          <span class="small muted" style="font-variant-numeric:tabular-nums">Câu ${i + 1}/${items.length}</span>
          <div class="bar"><i style="width:${(answered / items.length) * 100}%"></i></div>
          <span class="chip" id="exTime" style="font-variant-numeric:tabular-nums"></span>
        </div>
        <div class="qcard">
          <div class="q-meta">${q.levelLabel ? `<span class="chip">${esc(q.levelLabel)}</span>` : ''}</div>
          <div class="q-text">${C.mdBlock(q.q)}</div>
          <div class="opts">${it.perm.map((orig, k) => `
            <button class="opt" data-orig="${orig}" aria-pressed="${it.pick === orig}"><span class="key">${LETTERS[k]}</span><span>${mdInline(q.options[orig])}</span></button>`).join('')}</div>
          <div class="quiz-actions">
            <button class="btn" id="prev" ${i === 0 ? 'disabled' : ''}>← Câu trước</button>
            ${i + 1 < items.length ? '<button class="btn primary" id="next">Câu sau →</button>' : '<button class="btn primary" id="sub2">Nộp bài</button>'}
          </div>
        </div>
        <details class="card exam-nav" style="margin-top:12px" ${items.length <= 30 ? 'open' : ''}>
          <summary class="small"><b>Bảng câu hỏi</b> · đã làm ${answered}/${items.length}</summary>
          <div class="exam-grid">${items.map((x, k) => `<button data-k="${k}" class="${x.pick !== null ? 'done' : ''}${k === i ? ' cur' : ''}" aria-label="Câu ${k + 1}${x.pick !== null ? ', đã làm' : ''}">${k + 1}</button>`).join('')}</div>
        </details>
        <button class="btn block" id="sub" style="margin-top:12px">Nộp bài</button>`;
      tick();
      const v = view();
      v.querySelectorAll('.opt').forEach(btn => btn.onclick = () => {
        it.pick = +btn.dataset.orig;
        v.querySelectorAll('.opt').forEach(x => x.setAttribute('aria-pressed', x === btn));
        const cell = v.querySelector(`.exam-grid [data-k="${i}"]`); if (cell) cell.classList.add('done');
        const done = items.filter(x => x.pick !== null).length;
        v.querySelector('.quiz-top .bar i').style.width = (done / items.length) * 100 + '%';
        v.querySelector('.exam-nav summary').innerHTML = `<b>Bảng câu hỏi</b> · đã làm ${done}/${items.length}`;
      });
      const go = k => { i = k; show(); window.scrollTo(0, 0); };
      v.querySelector('#prev').onclick = () => go(i - 1);
      const nx = v.querySelector('#next'); if (nx) nx.onclick = () => go(i + 1);
      v.querySelectorAll('.exam-grid button').forEach(x => x.onclick = () => go(+x.dataset.k));
      const ask = e => {
        const left = items.filter(x => x.pick === null).length;
        const btn = e.currentTarget;
        if (left && !btn.dataset.confirm) { btn.dataset.confirm = 1; btn.textContent = `Còn ${left} câu chưa làm — bấm lần nữa để nộp`; return; }
        submit();
      };
      v.querySelector('#sub').onclick = ask;
      const s2 = v.querySelector('#sub2'); if (s2) s2.onclick = ask;
    }

    function submit() {
      if (submitted) return; submitted = true; stopExam();
      const used = Math.floor((Date.now() - t0) / 1000);
      let right = 0;
      const byLv = {};
      for (const it of items) {
        it.correct = it.pick === it.q.answer;
        if (it.correct) right++;
        Store.record(it.key, { correct: it.correct, unsure: false });
        const L = it.q.levelLabel || 'Khác';
        byLv[L] = byLv[L] || { r: 0, t: 0 }; byLv[L].t++; if (it.correct) byLv[L].r++;
      }
      App.updateDuePill();
      const pct = Math.round((right / items.length) * 100);
      const score10 = Math.round((right / items.length) * 100) / 10;
      const wrong = items.filter(x => !x.correct);
      const hist = Store.settings().examHist || [];
      hist.unshift({ at: Date.now(), bank: b.id, n: items.length, right });
      Store.setSetting('examHist', hist.slice(0, 20));
      const msg = pct >= 80 ? 'Rất tốt!' : pct >= 65 ? 'Khá — ôn lại các câu sai là chắc.' : pct >= 50 ? 'Đạt — cần ôn thêm.' : 'Chưa đạt — luyện lại từng phần nhé.';
      view().innerHTML = `
        <div class="card stack" style="text-align:center">
          <div class="muted small">Kết quả thi thử · ${esc(b.short)}</div>
          <div class="result-score">${String(score10).replace('.', ',')}<span style="font-size:1.1rem"> / 10</span></div>
          <div>${right}/${items.length} câu đúng (${pct}%) · ${esc(msg)}</div>
          <div class="small muted">Thời gian làm: ${fmt(used)}${limit ? ` / ${fmt(limit)}` : ''}</div>
        </div>
        ${Object.keys(byLv).length > 1 ? `<div class="stats" style="margin-top:12px;grid-template-columns:repeat(${Math.min(3, Object.keys(byLv).length)},1fr)">${Object.entries(byLv).map(([k, x]) => `<div class="stat"><b>${x.r}/${x.t}</b><span>${esc(k)}</span></div>`).join('')}</div>` : ''}
        <div class="stack" style="margin-top:14px">
          ${wrong.length ? `<button class="btn primary block" id="redo">Làm lại ${wrong.length} câu sai</button>` : ''}
          <a class="btn block" href="#/on-thi/${b.id}">Về bộ đề</a>
        </div>
        ${wrong.length ? `<div class="section-title">Các câu sai (${wrong.length}) — đã vào Ôn tập</div>
        <div class="card"><ul class="wrong-list">${wrong.map(it => `
          <li><div>${mdInline(it.q.q)}</div>
            <div class="small" style="margin-top:4px">Bạn chọn: ${it.pick === null ? '<i>bỏ trống</i>' : `<span style="color:var(--bad)">${mdInline(it.q.options[it.pick])}</span>`}</div>
            <div class="small">Đáp án: <b style="color:var(--ok)">${mdInline(it.q.options[it.q.answer])}</b></div>
            ${it.q.explain ? `<div class="small muted" style="margin-top:4px">${mdInline(it.q.explain)}</div>` : ''}
            ${it.q.warn ? `<div class="small warn-note">⚠ ${mdInline(it.q.warn)}</div>` : ''}
            ${it.q.see ? `<button class="linkish small" data-see="${it.q.see.lesson}|${it.q.see.h}">📖 Xem lý thuyết</button>` : ''}
          </li>`).join('')}</ul></div>` : ''}`;
      const redo = view().querySelector('#redo');
      if (redo) redo.onclick = () => {
        App.setTop('Làm lại câu sai', '#/on-thi/' + b.id);
        Quiz.run(view(), wrong.map(it => ({ key: it.key, q: it.q, lesson: { title: b.short } })), { title: 'Làm lại câu sai', mode: 'review', backHref: '#/on-thi/' + b.id, backText: 'Về bộ đề', showExplain: true });
      };
      view().querySelectorAll('[data-see]').forEach(x => x.onclick = () => { const [l, h] = x.dataset.see.split('|'); Theory.open(l, h); });
      window.scrollTo(0, 0);
    }

    examTimer = setInterval(tick, 1000);
    show();
  }

  /* ---------------- Khung xem lý thuyết (không rời khỏi bài đang làm) ---------------- */
  const Theory = {
    async open(lessonKey, h) {
      Theory.close();
      const sheet = document.createElement('div');
      sheet.className = 'sheet-wrap'; sheet.id = 'theory';
      sheet.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="Lý thuyết liên quan">
        <div class="sheet-head"><b class="grow" id="thTitle">Đang tải…</b><button class="icon-btn" id="thClose" aria-label="Đóng">✕</button></div>
        <div class="sheet-body prose" id="thBody"><div class="loading">Đang tải lý thuyết…</div></div></div>`;
      document.body.appendChild(sheet);
      document.body.classList.add('no-scroll');
      sheet.onclick = e => { if (e.target === sheet) Theory.close(); };
      sheet.querySelector('#thClose').onclick = Theory.close;
      Theory._esc = e => { if (e.key === 'Escape') Theory.close(); };
      document.addEventListener('keydown', Theory._esc);
      sheet.querySelector('#thClose').focus();
      try {
        await C.loadCatalog();
        const l = C.findLesson(lessonKey);
        if (!l || !l.ready) throw new Error('Chưa có bài');
        const doc = await C.loadLesson(l);
        if (!document.getElementById('theory')) return;
        const wrap = document.createElement('div'); wrap.innerHTML = doc.html;
        // id tiêu đề do renderLesson gán: tìm mục, lấy tới tiêu đề cùng cấp kế tiếp
        let head = h && wrap.querySelector('#' + CSS.escape(h));
        let html = '';
        if (head) {
          const lvl = +head.tagName[1];
          const parts = [`<h${lvl}>${head.innerHTML}</h${lvl}>`];
          for (let n = head.nextElementSibling; n; n = n.nextElementSibling) {
            if (/^H[1-6]$/.test(n.tagName) && +n.tagName[1] <= lvl) break;
            parts.push(n.outerHTML);
          }
          html = parts.join('');
        } else html = wrap.innerHTML;
        sheet.querySelector('#thTitle').textContent = l.title;
        sheet.querySelector('#thBody').innerHTML = html.replace(/\sid="m-[^"]*"/g, '') +
          `<p style="margin-top:20px"><a class="btn block" href="#/bai/${l.key}${head ? '?h=' + h : ''}">Mở cả bài “${esc(l.title)}”</a></p>`;
        sheet.querySelector('#thBody a.btn').onclick = () => Theory.close();
      } catch (err) {
        sheet.querySelector('#thTitle').textContent = 'Lý thuyết';
        sheet.querySelector('#thBody').innerHTML = `<div class="empty">Không tải được lý thuyết (${esc(err.message)}).</div>`;
      }
    },
    close() {
      const s = document.getElementById('theory');
      if (s) s.remove();
      document.body.classList.remove('no-scroll');
      if (Theory._esc) document.removeEventListener('keydown', Theory._esc);
    }
  };
  window.Theory = Theory;

  /* ---------------- Định tuyến #/on-thi/... ---------------- */
  function route(seg, params) {
    stopExam(); Theory.close();
    if (seg.length === 1) return list();
    const b = Banks.get(seg[1]);
    if (!b) {
      App.setTop('Ôn thi theo đề cương', '#/on-thi');
      view().innerHTML = `<div class="empty">Bộ đề này chưa có trên máy. <a href="#/on-thi">Nhập bộ đề</a></div>`;
      return;
    }
    if (seg.length === 2) return overview(b);
    if (seg[2] === 'luyen') return practice(b, params);
    if (seg[2] === 'thi') return exam(b, params);
    Views.notFound();
  }

  window.OnThi = { route, stopExam };
})();
