/* =========================================================
   content.js — đọc mục lục, bài học (Markdown), quiz (JSON)
   Quy ước thư mục:  content/<năm>/<môn>/<mã-bài>/bai.md
                                              /quiz.json
                                              /*.svg (hình)
   ========================================================= */
(function () {
  const cache = new Map();
  let catalog = null, catalogP = null;

  async function getText(url) {
    if (cache.has(url)) return cache.get(url);
    const p = fetch(url).then(r => { if (!r.ok) throw new Error(r.status + ' ' + url); return r.text(); });
    cache.set(url, p);
    p.catch(() => cache.delete(url));
    return p;
  }
  async function getJSON(url) { return JSON.parse(await getText(url)); }

  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* Bỏ dấu tiếng Việt để tìm kiếm */
  const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase();

  const slug = s => 'm-' + norm(s).replace(/<[^>]+>/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60);

  /* ---- Ký hiệu hóa học gọn:  H~2~O  →  H₂O ;  Fe^3+^  →  Fe³⁺ ---- */
  function chem(md) {
    // không đụng vào khối code ``` và `code`
    return md.split(/(```[\s\S]*?```|`[^`\n]*`)/g).map((part, i) => {
      if (i % 2) return part;
      // Dấu so sánh < > trong chữ: đổi thành thực thể HTML để marked không hiểu nhầm là thẻ
      // (lỗi của marked: "a < b … **đậm** … c > d" làm hỏng chữ đậm). Giữ nguyên ">" đầu dòng (khung trích dẫn).
      part = part.split('\n').map(line => {
        const pre = line.match(/^(\s*>)*\s*/)[0];
        const rest = line.slice(pre.length)
          .replace(/<(?![a-zA-Z\/!])/g, '&lt;')
          .replace(/(^|\s)>(?=[\s\d≈~(−-])/g, '$1&gt;');
        return pre + rest;
      }).join('\n');
      return part
        // không có khoảng trắng bên trong → "khoảng ~5 và ~7" không bị biến thành chỉ số
        .replace(/(?<=[^\s(\/~=≈,:;–-])~([^~\s]{1,15})~(?!~)/g, '<sub>$1</sub>')  // chỉ số dưới phải dính vào ký tự đứng trước (H~2~O); "~5" đứng sau dấu cách là "khoảng"
        .replace(/(?<![\^\[])\^([^\^\s\]]{1,15})\^/g, '<sup>$1</sup>')
        .replace(/~/g, '&#126;');  // dấu ~ còn lại (nghĩa "khoảng") giữ nguyên, không để marked hiểu là gạch ngang
    }).join('');
  }

  /* ---- frontmatter đơn giản (key: value, danh sách "- ...") ---- */
  function frontmatter(md) {
    const m = md.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
    if (!m) return { meta: {}, body: md };
    const meta = {}; let curKey = null;
    for (const line of m[1].split(/\r?\n/)) {
      const li = line.match(/^\s*-\s+(.*)$/);
      const kv = line.match(/^([\w-]+):\s*(.*)$/);
      if (li && curKey) { (meta[curKey] = Array.isArray(meta[curKey]) ? meta[curKey] : []).push(li[1]); }
      else if (kv) { curKey = kv[1]; meta[curKey] = kv[2] === '' ? [] : kv[2]; }
    }
    return { meta, body: md.slice(m[0].length) };
  }

  const CALLOUTS = {
    'ghi-nho': 'Ghi nhớ', 'ung-dung': 'Ứng dụng thực tế', 'bay': 'Bẫy hay gặp', 'vi-du': 'Ví dụ',
    'nen-tang': 'Kiến thức nền cần nhớ', 'meo': 'Mẹo làm bài', 'em-co-biet': 'Em có biết',
    'goi-y': 'Gợi ý', 'loi-giai': 'Lời giải'
  };
  // khung bấm để mở (gợi ý từng nấc, lời giải)
  const FOLD = new Set(['goi-y', 'loi-giai']);

  /* ---- Công thức Toán (KaTeX):  $...$  trong dòng,  $$...$$  riêng một dòng ----
     Tách công thức ra trước khi xử lý Markdown/chỉ số hóa học, rồi ghép lại sau. */
  const MATH_RE = /\$\$([\s\S]+?)\$\$|(?<![\\\w$])\$(?=\S)((?:\\\$|[^$\n])+?)(?<=\S)\$(?![\w$])/g;
  function mathOut(s) {
    const store = [];
    s = String(s ?? '').replace(MATH_RE, (m, d, i) => { store.push({ tex: d ?? i, display: d != null }); return `\uE000${store.length - 1}\uE001`; });
    return { s, store };
  }
  function mathIn(html, store) {
    if (!store.length) return html;
    return html.replace(/\uE000(\d+)\uE001/g, (m, k) => {
      const x = store[+k];
      if (!window.katex) return esc(x.tex);
      try { return katex.renderToString(x.tex, { displayMode: x.display, throwOnError: false, output: 'html', strict: false }); }
      catch (e) { return `<code>${esc(x.tex)}</code>`; }
    });
  }

  // Công thức trong dòng quá dài so với màn hình điện thoại → cho cuộn ngang riêng công thức đó
  function fitMath(root) {
    if (!root) return;
    const W = root.getBoundingClientRect().width;
    root.querySelectorAll('.katex').forEach(k => {
      if (k.closest('.katex-display') || k.parentElement.classList.contains('math-scroll')) return;
      if (k.getBoundingClientRect().width > W - 8) {
        const w = document.createElement('span'); w.className = 'math-scroll';
        k.replaceWith(w); w.appendChild(k);
      }
    });
  }

  function mdInline(s) { const m = mathOut(s); return mathIn(window.marked.parseInline(chem(m.s)), m.store); }

  /* Chuyển Markdown → HTML và hậu xử lý (callout, id tiêu đề, hình SVG) */
  async function renderLesson(md, baseUrl) {
    const { meta, body } = frontmatter(md);
    const mo = mathOut(body);
    const html = mathIn(window.marked.parse(chem(mo.s), { gfm: true, breaks: false }), mo.store);
    const wrap = document.createElement('div');
    // đổi src → data-src để trình duyệt không tải ảnh sai đường dẫn trước khi xử lý
    wrap.innerHTML = html.replace(/<img([^>]*?)\ssrc=/g, '<img$1 data-src=');

    // Callout:  > [!ghi-nho] Tiêu đề tùy chọn
    wrap.querySelectorAll('blockquote').forEach(bq => {
      const first = bq.firstElementChild;
      if (!first || first.tagName !== 'P') return;
      const m = first.innerHTML.match(/^\[!([\w-]+)\][ \t]*([^\n]*?)(?:\n|<br>|$)/);
      if (!m) return;
      const type = m[1];
      // tiêu đề: chỉ giữ thẻ sub/sup (chỉ số hóa học), bỏ thẻ khác
      const title = m[2].replace(/<(?!\/?su[bp]>)[^>]*>/g, '').trim() || CALLOUTS[type] || type;
      first.innerHTML = first.innerHTML.slice(m[0].length).trim();
      if (!first.innerHTML) first.remove();
      if (FOLD.has(type)) {
        const d = document.createElement('details');
        d.className = 'callout fold ' + type;
        d.innerHTML = `<summary class="callout-title">${title}</summary>` + bq.innerHTML;
        bq.replaceWith(d); return;
      }
      const div = document.createElement('div');
      div.className = 'callout ' + type;
      div.innerHTML = `<div class="callout-title">${title}</div>` + bq.innerHTML;
      bq.replaceWith(div);
    });

    // Phương trình: đoạn bắt đầu bằng "=>" được canh giữa
    wrap.querySelectorAll('p').forEach(p => {
      if (p.innerHTML.startsWith('=&gt;')) { p.innerHTML = p.innerHTML.slice(5).trim(); p.className = 'eq'; }
    });

    // id cho tiêu đề
    const toc = []; const used = new Set();
    wrap.querySelectorAll('h2, h3').forEach(h => {
      let id = slug(h.textContent) || 'muc'; while (used.has(id)) id += '-1'; used.add(id);
      h.id = id;
      if (h.tagName === 'H2') toc.push({ id, text: h.textContent });
    });

    // Hình: ảnh .svg được nhúng trực tiếp để đổi màu theo giao diện sáng/tối
    const imgs = [...wrap.querySelectorAll('img')];
    await Promise.all(imgs.map(async img => {
      const src = img.getAttribute('data-src') || '';
      const url = /^(https?:|data:|\/)/.test(src) ? src : baseUrl + src;
      const fig = document.createElement('figure');
      const cap = img.getAttribute('alt');
      if (/\.svg$/i.test(src)) {
        try { fig.innerHTML = await getText(url); } catch (e) { fig.innerHTML = `<p class="muted">[Không tải được hình ${esc(src)}]</p>`; }
      } else {
        img.removeAttribute('data-src'); img.setAttribute('src', url); img.setAttribute('loading', 'lazy'); fig.appendChild(img.cloneNode());
      }
      if (cap) fig.insertAdjacentHTML('beforeend', `<figcaption>${cap.replace(/<(?!\/?su[bp]>)/g, '&lt;')}</figcaption>`);
      const parent = img.parentElement;
      if (parent && parent.tagName === 'P' && parent.childNodes.length === 1) parent.replaceWith(fig);
      else img.replaceWith(fig);
    }));

    return { meta, html: wrap.innerHTML, toc };
  }

  /* ---- Mục lục ---- */
  function loadCatalog() { return catalogP || (catalogP = _loadCatalog().catch(e => { catalogP = null; throw e; })); }
  async function _loadCatalog() {
    const cat = await getJSON('content/catalog.json');
    // gắn thông tin tiện tra cứu
    for (const y of cat.years) for (const s of y.subjects) {
      s.year = y.id; s.lessons = [];
      for (const part of s.parts || []) for (const l of part.lessons) {
        l.part = part.title; l.subject = s.id; l.year = y.id;
        l.key = `${y.id}/${s.id}/${l.id}`;
        l.base = `content/${l.key}/`;
        s.lessons.push(l);
      }
    }
    catalog = cat;
    return catalog;
  }

  function findSubject(yearId, subjectId) {
    const y = catalog.years.find(y => y.id === yearId);
    return y && y.subjects.find(s => s.id === subjectId);
  }
  function findLesson(key) {
    const [y, s, l] = key.split('/');
    const subj = findSubject(y, s);
    return subj && subj.lessons.find(x => x.id === l);
  }
  function allLessons() { return catalog.years.flatMap(y => y.subjects.flatMap(s => s.lessons)); }

  async function loadLesson(lesson) {
    const md = await getText(lesson.base + 'bai.md');
    return renderLesson(md, lesson.base);
  }
  async function loadQuiz(lesson) {
    try { return await getJSON(lesson.base + 'quiz.json'); }
    catch (e) { return { questions: [] }; }
  }

  /* ---- Chỉ mục tra cứu (xây khi mở trang Tra cứu) ---- */
  let index = null, indexP = null;
  function buildIndex() { return indexP || (indexP = _buildIndex().catch(e => { indexP = null; throw e; })); }
  async function _buildIndex() {
    await loadCatalog();
    const docs = [];
    const lessons = allLessons();
    for (const l of lessons) docs.push({ lesson: l, subj: findSubject(l.year, l.subject), head: l.title, anchor: '', text: l.title, kind: 'bai' });
    // tải song song (tối đa 6 bài một lúc) để nhanh cả khi có hàng trăm bài
    const ready = lessons.filter(l => l.ready);
    let k = 0;
    async function worker() {
      while (k < ready.length) {
        const l = ready[k++];
        try {
          const md = await getText(l.base + 'bai.md');
          const { body } = frontmatter(md);
          for (const p of body.split(/^(?=#{2,3}\s)/m)) {
            const hm = p.match(/^#{2,3}\s+(.*)/);
            const head = hm ? hm[1].replace(/[*_`~^]/g, '').trim() : l.title;
            const plain = p.replace(/^#{2,3}.*$/m, '').replace(/<[^>]+>/g, ' ').replace(/!\[[^\]]*\]\([^)]*\)/g, '')
              .replace(/[>*_`|#~^$\\{}]|\[!\w[\w-]*\]|:?-{3,}:?|=>/g, ' ').replace(/\s+/g, ' ').trim();
            docs.push({ lesson: l, subj: findSubject(l.year, l.subject), head, anchor: hm ? slug(head) : '', text: plain, kind: 'muc' });
          }
        } catch (e) { /* bỏ qua bài lỗi mạng */ }
      }
    }
    await Promise.all(Array.from({ length: Math.min(6, ready.length) }, worker));
    for (const d of docs) d.n = norm(d.head + ' ' + d.text);
    index = docs;
    return docs;
  }

  function search(query) {
    if (!index) return [];
    const terms = norm(query).split(/\s+/).filter(t => t.length > 0);
    if (!terms.length) return [];
    const out = [];
    for (const d of index) {
      if (!terms.every(t => d.n.includes(t))) continue;
      const nh = norm(d.head);
      let score = terms.reduce((s, t) => s + (nh.includes(t) ? 5 : 0) + d.n.split(t).length - 1, 0);
      // ưu tiên khớp trọn từ ("the" không nên xếp trên "theo")
      score += terms.filter(t => new RegExp('(^|[^a-z0-9])' + t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '([^a-z0-9]|$)').test(d.n)).length * 4;
      if (d.kind === 'bai') score += 3;
      out.push({ d, score });
    }
    return out.sort((a, b) => b.score - a.score).slice(0, 40).map(x => x.d);
  }

  function snippet(text, query, len = 160) {
    const terms = norm(query).split(/\s+/).filter(Boolean);
    const n = norm(text);
    let pos = Math.max(0, n.indexOf(terms[0]));
    const start = Math.max(0, pos - 50);
    let s = text.slice(start, start + len);
    // tô sáng (so khớp không dấu, cùng độ dài vì NFD đã gộp lại theo ký tự)
    let out = '', i = 0; const ns = norm(s);
    const marks = [];
    for (const t of terms) { let p = ns.indexOf(t); while (p >= 0) { marks.push([p, p + t.length]); p = ns.indexOf(t, p + t.length); } }
    marks.sort((a, b) => a[0] - b[0]);
    for (const [a, b] of marks) { if (a < i) continue; out += esc(s.slice(i, a)) + '<mark>' + esc(s.slice(a, b)) + '</mark>'; i = b; }
    out += esc(s.slice(i));
    return (start > 0 ? '…' : '') + out + (start + len < text.length ? '…' : '');
  }

  window.Content = { fitMath, loadCatalog, findSubject, findLesson, allLessons, loadLesson, loadQuiz, buildIndex, search, snippet, mdInline, esc, norm, getText, get catalog() { return catalog; } };
})();
