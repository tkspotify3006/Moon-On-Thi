/* =========================================================
   store.js — lưu tiến độ học & thuật toán ôn tập (Leitner)
   Mọi dữ liệu nằm trong localStorage của trình duyệt.
   ========================================================= */
(function () {
  const KEY = 'onThiThpt.v1';
  const DAY = 86400000;
  // Khoảng cách ôn (ngày) theo hộp. Lên hộp 5 = "đã thuộc".
  const INTERVALS = { 1: 1, 2: 3, 3: 7, 4: 14 };
  const MASTER_BOX = 5;

  // Hạn ôn tính tròn theo NGÀY (0 giờ sáng), để câu học tối nay sẽ đến hạn từ sáng hôm sau
  function dueIn(days) {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    return d.getTime() + days * DAY;
  }

  function blank() {
    return { v: 1, q: {}, l: {}, settings: { theme: 'auto', fs: 16 }, last: null };
  }
  let db = blank();
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) db = Object.assign(blank(), JSON.parse(raw));
  } catch (e) { /* bộ nhớ không khả dụng: chạy tạm trong RAM */ }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) {}
  }

  const Store = {
    DAY, MASTER_BOX,
    get db() { return db; },

    /* ---------- câu hỏi ----------
       key = "nam-1/hoa-hoc/hc-08b#hc08b-001"
       Trạng thái: box 0 = chưa cần ôn; 1..4 = đang ôn; mastered = đã thuộc */
    q(key) { return db.q[key]; },

    record(key, { correct, unsure }) {
      const now = Date.now();
      const r = db.q[key] || { box: 0, right: 0, wrong: 0, unsure: 0, seen: 0 };
      r.seen++; r.last = now;
      if (!correct) {
        r.wrong++; r.box = 1; r.mastered = false; r.due = dueIn(1); r.lastResult = 'sai';
      } else if (unsure) {
        r.right++; r.unsure++; r.mastered = false;
        r.box = Math.max(1, Math.min(r.box || 1, 2)); r.due = dueIn(INTERVALS[r.box]); r.lastResult = 'chua-chac';
      } else {
        r.right++; r.lastResult = 'dung';
        // Chỉ lên hộp khi câu ĐÃ ĐẾN HẠN — làm lại nhiều lần trong ngày không "học vẹt" lên thuộc được
        if (r.box > 0 && !r.mastered && (r.due == null || r.due <= now)) {
          r.box++;
          if (r.box >= MASTER_BOX) { r.mastered = true; r.due = null; }
          else r.due = dueIn(INTERVALS[r.box]);
        }
      }
      db.q[key] = r; save();
      return r;
    },

    toggleFlag(key) {
      const r = db.q[key] || { box: 0, right: 0, wrong: 0, unsure: 0, seen: 0 };
      r.flag = !r.flag; db.q[key] = r; save();
      return r.flag;
    },

    /* câu đang trong hàng ôn (đã từng sai / chưa chắc, chưa thuộc) */
    inReview(r) { return r && r.box > 0 && !r.mastered; },
    isDue(r, now = Date.now()) { return Store.inReview(r) && (r.due == null || r.due <= now); },

    reviewKeys(filter = 'due', subjectPrefix = '') {
      const now = Date.now();
      return Object.entries(db.q)
        .filter(([k]) => !subjectPrefix || k.startsWith(subjectPrefix))
        .filter(([, r]) => filter === 'due' ? Store.isDue(r, now)
          : filter === 'all' ? Store.inReview(r)
          : filter === 'flag' ? r.flag
          : filter === 'mastered' ? r.mastered : false)
        .sort((a, b) => (a[1].due || 0) - (b[1].due || 0))
        .map(([k]) => k);
    },

    counts(subjectPrefix = '') {
      const now = Date.now();
      let due = 0, review = 0, mastered = 0, flag = 0;
      for (const [k, r] of Object.entries(db.q)) {
        if (subjectPrefix && !k.startsWith(subjectPrefix)) continue;
        if (Store.isDue(r, now)) due++;
        if (Store.inReview(r)) review++;
        if (r.mastered) mastered++;
        if (r.flag) flag++;
      }
      return { due, review, mastered, flag };
    },

    /* ---------- bài học ---------- */
    lesson(lkey) { return db.l[lkey] || {}; },
    markRead(lkey, val = true) {
      db.l[lkey] = Object.assign({}, db.l[lkey], { read: val, readAt: Date.now() }); save();
    },
    saveScore(lkey, pct) {
      const l = Object.assign({ attempts: 0, best: 0 }, db.l[lkey]);
      l.attempts++; l.best = Math.max(l.best || 0, pct); l.lastScore = pct; l.lastAt = Date.now();
      db.l[lkey] = l; save();
    },
    setLast(lkey) { db.last = lkey; save(); },

    /* ---------- cài đặt & sao lưu ---------- */
    settings() { return db.settings; },
    setSetting(k, v) { db.settings[k] = v; save(); },
    exportJSON() { return JSON.stringify(Object.assign({ exportedAt: new Date().toISOString() }, db), null, 1); },
    importJSON(text) {
      const data = JSON.parse(text);
      if (!data || typeof data !== 'object' || !data.q || typeof data.q !== 'object') throw new Error('File không đúng định dạng sao lưu');
      const b = blank();
      db = { v: 1, q: data.q, l: data.l && typeof data.l === 'object' ? data.l : {},
        settings: Object.assign(b.settings, data.settings || {}), last: data.last || null };
      save();
    },
    reset() { db = blank(); save(); }
  };
  window.Store = Store;
})();
