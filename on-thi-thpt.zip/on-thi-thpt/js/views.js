/* =========================================================
   views.js — các màn hình: Trang chủ, Môn, Bài học, Quiz,
   Ôn tập, Tra cứu, Cài đặt
   ========================================================= */
(function () {
  const C = window.Content;
  const { esc, mdInline } = C;
  const view = () => document.getElementById('view');

  function fmtDue(ts) {
    if (!ts) return '';
    const d = Math.ceil((ts - Date.now()) / Store.DAY);
    return d <= 0 ? 'đến hạn' : d === 1 ? 'ôn ngày mai' : `ôn sau ${d} ngày`;
  }

  // nút dạng link; khi không có gì để ôn thì hiển thị nút bị vô hiệu (không bấm được kể cả bằng bàn phím)
  const btnLink = (href, text, enabled, cls) => enabled
    ? `<a class="${cls}" href="${href}">${text}</a>` : `<button class="${cls}" disabled>${text}</button>`;

  function subjectProgress(s) {
    const ready = s.lessons.filter(l => l.ready);
    const read = ready.filter(l => Store.lesson(l.key).read).length;
    return { total: s.lessons.length, ready: ready.length, read };
  }

  /* ---------------- Trang chủ ---------------- */
  async function home() {
    const tok = App.seq;
    const cat = await C.loadCatalog();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    App.setTop(cat.appTitle, null);
    const c = Store.counts();
    const last = Store.db.last && C.findLesson(Store.db.last);
    view().innerHTML = `
      <section class="hero">
        <h1>${esc(cat.appTitle)}</h1>
        <p>${esc(cat.appSubtitle)}</p>
        <div class="row">
          ${c.due ? `<a class="btn" href="#/on-tap/phien?loc=due">Ôn ${c.due} câu đến hạn</a>` : ''}
          ${last ? `<a class="btn" href="#/bai/${last.key}">Tiếp tục: ${esc(last.title)}</a>` : ''}
        </div>
      </section>
      <div class="stats" style="margin-top:12px">
        <a class="stat" href="#/on-tap" style="text-decoration:none;color:inherit"><b>${c.due}</b><span>Đến hạn ôn</span></a>
        <a class="stat" href="#/on-tap" style="text-decoration:none;color:inherit"><b>${c.review}</b><span>Đang ôn (sai / chưa chắc)</span></a>
        <div class="stat"><b>${c.mastered}</b><span>Đã thuộc</span></div>
      </div>
      ${cat.years.map(y => `
        <div class="section-title">${esc(y.title)}</div>
        <div class="subjects">
          ${y.subjects.map(s => {
            const p = subjectProgress(s);
            return `<a class="subject" href="#/mon/${y.id}/${s.id}" style="--c:${s.color}">
              <h3>${esc(s.title)}</h3>
              <div class="meta">${p.total ? `${p.ready}/${p.total} bài đã có nội dung · đã học ${p.read}` : 'Đang soạn'}</div>
              <div class="bar"><i style="width:${p.total ? (p.read / p.total) * 100 : 0}%"></i></div>
            </a>`;
          }).join('')}
        </div>`).join('')}
      <p class="small muted" style="margin-top:24px">Bài học soạn theo chương trình GDPT 2018, bám sách Kết nối tri thức với cuộc sống, có ghi số trang SGK để đối chiếu. Phát hiện sai sót? Ghi lại và gửi cho người soạn.</p>`;
  }

  /* ---------------- Danh sách bài của một môn ---------------- */
  async function subject(yearId, subjectId) {
    const tok = App.seq;
    await C.loadCatalog();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    const s = C.findSubject(yearId, subjectId);
    if (!s) return notFound();
    App.setTop(s.title, '#/');
    const p = subjectProgress(s);
    const sb = window.Banks ? Banks.list().filter(b => b.subject === `${yearId}/${subjectId}`) : [];
    let n = 0;
    view().innerHTML = `
      <div class="stack">
        <p class="book-note">Sách: ${esc(s.book)}</p>
        ${p.total ? `<div class="row small muted"><span class="grow">Đã học ${p.read}/${p.ready} bài có nội dung</span><span>${p.total} bài</span></div>
        <div class="bar"><i style="width:${(p.read / p.total) * 100}%;background:${s.color}"></i></div>` : ''}
        ${sb.map(b => `<a class="btn block" href="#/on-thi/${b.id}">📝 Ôn thi: ${esc(b.title)}</a>`).join('')}
      </div>
      ${s.parts.length ? s.parts.map(part => `
        <div class="section-title">${esc(part.title)}</div>
        <ul class="lesson-list">
          ${part.lessons.map(l => {
            n++;
            const st = Store.lesson(l.key);
            const cls = st.read ? 'done' : l.ready ? 'ready' : 'locked';
            const sub = [l.pages ? `tr. ${l.pages}` : '', !l.ready ? 'Đang soạn' : '', st.best != null && st.attempts ? `Quiz cao nhất ${st.best}%` : ''].filter(Boolean).join(' · ');
            const inner = `<span class="num">${st.read ? '✓' : n}</span><span class="grow"><div class="t">${esc(l.title)}</div><div class="s">${esc(sub)}</div></span>`;
            return `<li>${l.ready ? `<a class="lesson-item ${cls}" href="#/bai/${l.key}">${inner}</a>` : `<div class="lesson-item ${cls}">${inner}</div>`}</li>`;
          }).join('')}
        </ul>`).join('') : `<div class="card empty" style="margin-top:16px">Môn này đang được soạn.</div>`}`;
  }

  /* ---------------- Bài học ---------------- */
  async function lesson(key, anchor) {
    const tok = App.seq;
    await C.loadCatalog();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    const l = C.findLesson(key);
    if (!l || !l.ready) return notFound();
    const s = C.findSubject(l.year, l.subject);
    App.setTop(l.title, `#/mon/${l.year}/${l.subject}`);
    const [doc, quiz] = await Promise.all([C.loadLesson(l), C.loadQuiz(l)]);
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    Store.setLast(key);
    const st = Store.lesson(key);
    const nq = (quiz.questions || []).length;
    const idx = s.lessons.indexOf(l);
    const next = s.lessons.slice(idx + 1).find(x => x.ready);
    const goals = doc.meta['muc-tieu'];
    view().innerHTML = `
      <article>
        <header class="lesson-head">
          <span class="chip" style="background:${s.color};color:#fff">${esc(s.title)}</span>
          <h1>${esc(doc.meta.title || l.title)}</h1>
          <div class="small muted">${l.pages ? `SGK tr. ${esc(l.pages)}` : ''}${doc.meta['thoi-gian'] ? ` · Đọc khoảng ${esc(doc.meta['thoi-gian'])}` : ''}</div>
        </header>
        ${Array.isArray(goals) && goals.length ? `<div class="objectives" style="margin-top:14px"><b>Mục tiêu bài học</b><ul>${goals.map(g => `<li>${mdInline(g)}</li>`).join('')}</ul></div>` : ''}
        ${doc.toc.length > 1 ? `<nav class="toc" aria-label="Mục lục bài">${doc.toc.map(t => `<a href="#/bai/${key}?h=${t.id}" data-h="${t.id}">${esc(t.text)}</a>`).join('')}</nav>` : ''}
        <div class="prose">${doc.html}</div>
        <section class="lesson-end card stack">
          <label class="row" style="cursor:pointer"><input type="checkbox" id="read" ${st.read ? 'checked' : ''} style="width:20px;height:20px;accent-color:var(--accent)"> <b>Tôi đã học xong bài này</b></label>
          ${nq ? `<a class="btn primary block" href="#/quiz/${key}">Làm quiz (${nq} câu)${st.attempts ? ` · cao nhất ${st.best}%` : ''}</a>` : '<p class="muted small">Bài này chưa có câu hỏi.</p>'}
          ${next ? `<a class="btn block" href="#/bai/${next.key}">Bài tiếp: ${esc(next.title)} →</a>` : ''}
        </section>
      </article>`;
    C.fitMath(view().querySelector('.prose'));
    view().querySelectorAll('details.fold').forEach(d => d.addEventListener('toggle', () => { if (d.open) C.fitMath(d); }));
    // nút "Hỏi Gemini" dưới mỗi ví dụ: gửi kèm đề ví dụ + các gợi ý/lời giải ngay sau nó
    // hình rộng hơn màn hình điện thoại: nhắc vuốt ngang
    view().querySelectorAll('.prose figure').forEach(f => {
      if (f.scrollWidth > f.clientWidth + 4) f.insertAdjacentHTML('beforeend', '<span class="swipe-hint">← vuốt ngang để xem hết hình →</span>');
    });
    view().querySelector('#read').onchange = e => { Store.markRead(key, e.target.checked); App.toast(e.target.checked ? 'Đã đánh dấu học xong' : 'Bỏ đánh dấu'); };
    // mục lục cuộn mượt, không đổi lịch sử
    view().querySelectorAll('.toc a').forEach(a => a.onclick = e => {
      e.preventDefault(); const el = document.getElementById(a.dataset.h); if (el) el.scrollIntoView({ behavior: 'smooth' });
    });
    if (anchor) { const el = document.getElementById(anchor); if (el) setTimeout(() => el.scrollIntoView(), 50); }
  }

  /* ---------------- Quiz của bài ---------------- */
  async function quiz(key) {
    const tok = App.seq;
    await C.loadCatalog();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    const l = C.findLesson(key);
    if (!l) return notFound();
    App.setTop('Quiz: ' + l.title, `#/bai/${key}`);
    const data = await C.loadQuiz(l);
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    const items = (data.questions || []).map(q => ({ key: `${key}#${q.id}`, q, lesson: l }));
    if (!items.length) { view().innerHTML = '<div class="empty">Chưa có câu hỏi.</div>'; return; }
    Quiz.run(view(), items, {
      title: l.title, mode: 'lesson', backHref: `#/bai/${key}`,
      onFinish: r => Store.saveScore(key, r.pct)
    });
  }

  /* ---------------- Ôn tập ---------------- */
  async function loadReviewItems(keys) {
    const byLesson = new Map();
    const items = [];
    for (const k of keys) {
      // câu của bộ đề nhập riêng (khóa có "/@")
      const bi = window.Banks ? Banks.item(k) : undefined;
      if (bi !== undefined) { if (bi) items.push(bi); continue; }
      const lk = k.split('#')[0]; if (!byLesson.has(lk)) byLesson.set(lk, []); byLesson.get(lk).push(k);
    }
    await Promise.all([...byLesson.keys()].map(async lk => {
      const l = C.findLesson(lk); if (!l) return;
      const data = await C.loadQuiz(l);
      const map = new Map((data.questions || []).map(q => [q.id, q]));
      for (const k of byLesson.get(lk)) { const q = map.get(k.split('#')[1]); if (q) items.push({ key: k, q, lesson: l }); }
    }));
    const order = new Map(keys.map((k, i) => [k, i]));
    return items.sort((a, b) => order.get(a.key) - order.get(b.key));
  }

  async function review(params) {
    const tok = App.seq;
    const cat = await C.loadCatalog();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    App.setTop('Ôn tập', null);
    const subj = params.get('mon') || '';
    const prefix = subj ? subj + '/' : '';
    const c = Store.counts(prefix);
    const subjects = cat.years.flatMap(y => y.subjects.filter(s => s.lessons.some(l => l.ready)).map(s => ({ id: `${y.id}/${s.id}`, title: s.title })));
    const tab = params.get('xem') || 'all';
    const keys = Store.reviewKeys(tab, prefix);
    const items = await loadReviewItems(keys);
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    const banks = window.Banks ? Banks.list() : [];
    const link = (extra) => `#/on-tap/phien?loc=${extra}${subj ? '&mon=' + encodeURIComponent(subj) : ''}`;
    view().innerHTML = `
      <div class="stats">
        <div class="stat"><b>${c.due}</b><span>Đến hạn hôm nay</span></div>
        <div class="stat"><b>${c.review}</b><span>Đang ôn</span></div>
        <div class="stat"><b>${c.mastered}</b><span>Đã thuộc</span></div>
      </div>
      <div class="stack" style="margin-top:14px">
        ${btnLink(link('due'), `Ôn ${c.due} câu đến hạn`, c.due, 'btn primary block')}
        <div class="row">
          ${btnLink(link('all'), `Ôn tất cả câu sai (${c.review})`, c.review, 'btn grow')}
          ${btnLink(link('flag'), `Câu đánh dấu (${c.flag})`, c.flag, 'btn grow')}
        </div>
      </div>
      ${subjects.length > 1 ? `<div class="row" style="margin-top:14px">
        <button class="chip" data-mon="" aria-pressed="${!subj}">Tất cả môn</button>
        ${subjects.map(s => `<button class="chip" data-mon="${s.id}" aria-pressed="${subj === s.id}">${esc(s.title)}</button>`).join('')}
      </div>` : ''}
      <div class="section-title">Ôn thi theo đề cương</div>
      <a class="lesson-item ready card" href="#/on-thi" style="padding:12px 14px">
        <span class="num">📝</span><span class="grow"><div class="t">${banks.length ? banks.map(b => esc(b.short)).join(', ') : 'Nhập bộ đề ôn thi'}</div>
        <div class="s">${banks.length ? 'Luyện theo phần · thi thử có bấm giờ' : 'Bộ câu hỏi ôn tập của trường, lưu riêng trên máy'}</div></span><span aria-hidden="true">›</span></a>
      <div class="section-title">Sổ câu sai</div>
      <div class="row" style="margin-bottom:8px">
        ${[['all', 'Đang ôn'], ['flag', 'Đánh dấu'], ['mastered', 'Đã thuộc']].map(([k, t]) => `<button class="chip" data-xem="${k}" aria-pressed="${tab === k}">${t}</button>`).join('')}
      </div>
      <div class="card">
        ${items.length ? items.map(it => {
          const r = Store.q(it.key) || {};
          const tags = [
            r.wrong ? `<span class="chip bad">Sai ${r.wrong} lần</span>` : '',
            r.unsure ? `<span class="chip warn">Chưa chắc ${r.unsure}</span>` : '',
            r.flag ? '<span class="chip warn">★</span>' : '',
            r.mastered ? '<span class="chip ok">Đã thuộc</span>' : r.due ? `<span class="chip">${fmtDue(r.due)}</span>` : ''
          ].join('');
          return `<div class="review-item">
            <div class="row">${tags}</div>
            <div class="q">${mdInline(it.q.q)}</div>
            <div class="small muted">Đáp án: ${Quiz.answerText(it.q)} · <a href="${it.href || '#/bai/' + it.lesson.key}">${esc(it.lesson.title)}</a></div>
          </div>`;
        }).join('') : `<div class="empty">${tab === 'all' ? 'Chưa có câu nào cần ôn. Làm quiz cuối mỗi bài — câu sai hoặc "chưa chắc" sẽ tự vào đây.' : 'Trống.'}</div>`}
      </div>
      <p class="small muted" style="margin-top:12px">Cách ôn: câu sai hoặc đoán mò được hỏi lại sau 1 ngày → 3 → 7 → 14 ngày. Trả lời đúng 4 lần liên tiếp = "Đã thuộc". Sai lần nào thì quay lại từ đầu.</p>`;
    view().querySelectorAll('[data-mon]').forEach(b => b.onclick = () => { location.hash = '#/on-tap?mon=' + encodeURIComponent(b.dataset.mon) + '&xem=' + tab; });
    view().querySelectorAll('[data-xem]').forEach(b => b.onclick = () => { location.hash = '#/on-tap?xem=' + b.dataset.xem + (subj ? '&mon=' + encodeURIComponent(subj) : ''); });
  }

  async function reviewSession(params) {
    const tok = App.seq;
    await C.loadCatalog();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    App.setTop('Phiên ôn tập', '#/on-tap');
    const loc = params.get('loc') || 'due';
    const subj = params.get('mon') || '';
    const keys = Store.reviewKeys(loc, subj ? subj + '/' : '').slice(0, 30);
    const items = await loadReviewItems(keys);
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    if (!items.length) { view().innerHTML = '<div class="empty">Không có câu nào để ôn. <a href="#/on-tap">Quay lại</a></div>'; return; }
    Quiz.run(view(), items, { title: 'Phiên ôn tập', mode: 'review' });
  }

  /* ---------------- Tra cứu ---------------- */
  async function search(params) {
    const tok = App.seq;
    App.setTop('Tra cứu', null);
    const q0 = params.get('q') || '';
    view().innerHTML = `
      <input class="searchbox" id="q" type="search" aria-label="Tìm trong tất cả bài học" placeholder="Tìm: glucosid, maltose, điện thế nghỉ…" value="${esc(q0)}" autocomplete="off">
      <div class="small muted" style="margin:8px 2px">Gõ không dấu cũng được.</div>
      <div class="card" id="hits"><div class="empty">Đang chuẩn bị chỉ mục…</div></div>`;
    const input = view().querySelector('#q');
    const hits = view().querySelector('#hits');
    await C.buildIndex();
    if (tok !== App.seq) return; // người dùng đã chuyển trang khác
    const go = () => {
      const q = input.value.trim();
      history.replaceState(null, '', '#/tra-cuu' + (q ? '?q=' + encodeURIComponent(q) : ''));
      if (!q) { hits.innerHTML = '<div class="empty">Nhập từ khóa để tìm trong tất cả bài học.</div>'; return; }
      const res = C.search(q);
      hits.innerHTML = res.length ? res.map(d => {
        const href = d.lesson.ready ? `#/bai/${d.lesson.key}${d.anchor ? '?h=' + d.anchor : ''}` : `#/mon/${d.lesson.year}/${d.lesson.subject}`;
        return `<a class="hit" href="${href}">
          <div class="h">${esc(d.head)}${d.lesson.ready ? '' : ' <span class="chip">Đang soạn</span>'}</div>
          <div class="small hit-subj" style="--c:${d.subj.color}">${esc(d.subj.title)} › ${esc(d.lesson.title)}</div>
          ${d.kind === 'muc' ? `<div class="p">${C.snippet(d.text, q)}</div>` : ''}
        </a>`;
      }).join('') : '<div class="empty">Không tìm thấy. Thử từ khóa khác.</div>';
    };
    let t; input.oninput = () => { clearTimeout(t); t = setTimeout(go, 150); };
    go(); input.focus();
  }

  /* ---------------- Cài đặt ---------------- */
  async function settings() {
    App.setTop('Cài đặt', null);
    const st = Store.settings();
    view().innerHTML = `
      <div class="card">
        <div class="setting"><div class="l"><b>Giao diện</b></div>
          <div class="seg" id="theme">${[['auto', 'Tự động'], ['light', 'Sáng'], ['dark', 'Tối']].map(([k, t]) => `<button data-v="${k}" aria-pressed="${st.theme === k}">${t}</button>`).join('')}</div></div>
        <div class="setting"><div class="l"><b>Cỡ chữ</b></div>
          <div class="seg" id="fs">${[[15, 'Nhỏ'], [16, 'Vừa'], [18, 'Lớn']].map(([k, t]) => `<button data-v="${k}" aria-pressed="${+st.fs === k}">${t}</button>`).join('')}</div></div>
      </div>
      <div class="section-title">Dữ liệu học tập</div>
      <div class="card">
        <div class="setting"><div class="l"><b>Sao lưu tiến độ</b><div class="small muted">Tải file .json về máy (để chuyển sang điện thoại/máy khác).</div></div><button class="btn" id="export">Tải về</button></div>
        <div class="setting"><div class="l"><b>Khôi phục</b><div class="small muted">Chọn file sao lưu đã tải.</div></div><label class="btn">Chọn file<input type="file" id="import" accept="application/json,.json" hidden></label></div>
        <div class="setting"><div class="l"><b>Dùng không cần mạng</b><div class="small muted">Tải sẵn toàn bộ bài học vào máy.</div></div><button class="btn" id="offline">Tải về</button></div>
        <div class="setting"><div class="l"><b>Xóa toàn bộ tiến độ</b><div class="small muted">Không thể hoàn tác.</div></div><button class="btn" id="reset" style="color:var(--bad)">Xóa</button></div>
      </div>
      <div class="section-title">Giới thiệu</div>
      <div class="card small">
        <p style="margin-top:0">Ứng dụng học bài và ôn thi tốt nghiệp THPT môn Toán, Hóa học, Sinh học lớp 12. Nội dung được biên soạn lại (không sao chép nguyên văn) theo chương trình GDPT 2018, bám sách Kết nối tri thức với cuộc sống, mỗi bài ghi số trang SGK để đối chiếu.</p>
        <p class="muted" style="margin-bottom:0">Tiến độ học lưu ngay trên thiết bị này, không gửi đi đâu. Phiên bản ${App.VERSION}.</p>
      </div>`;
    const v = view();
    v.querySelectorAll('#theme button').forEach(b => b.onclick = () => { Store.setSetting('theme', b.dataset.v); App.applySettings(); settings(); });
    v.querySelectorAll('#fs button').forEach(b => b.onclick = () => { Store.setSetting('fs', +b.dataset.v); App.applySettings(); settings(); });
    v.querySelector('#export').onclick = () => {
      const blob = new Blob([Store.exportJSON()], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
      const d = new Date(), p2 = n => String(n).padStart(2, '0'); // ngày theo giờ máy (không lệch ngày do UTC)
      a.download = `on-thi-thpt-${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}.json`; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    };
    v.querySelector('#import').onchange = async e => {
      const f = e.target.files[0]; if (!f) return;
      try { Store.importJSON(await f.text()); App.applySettings(); App.updateDuePill(); App.toast('Đã khôi phục tiến độ'); settings(); }
      catch (err) { App.toast('Lỗi: ' + err.message); }
    };
    v.querySelector('#reset').onclick = () => {
      const b = v.querySelector('#reset');
      if (b.dataset.confirm) { Store.reset(); App.applySettings(); App.toast('Đã xóa tiến độ'); settings(); }
      else { b.dataset.confirm = 1; b.textContent = 'Bấm lần nữa để xóa'; }
    };
    v.querySelector('#offline').onclick = async e => {
      const b = e.currentTarget; b.disabled = true; b.textContent = 'Đang tải…';
      try {
        await C.loadCatalog();
        const urls = [];
        for (const l of C.allLessons().filter(l => l.ready)) {
          urls.push(l.base + 'bai.md', l.base + 'quiz.json');
          const md = await C.getText(l.base + 'bai.md');
          for (const m of md.matchAll(/!\[[^\]]*\]\(([^)\s]+)\)/g)) if (!/^https?:/.test(m[1])) urls.push(l.base + m[1]);
        }
        if (!navigator.serviceWorker || !navigator.serviceWorker.controller) {
          b.disabled = false; b.textContent = 'Thử lại';
          App.toast('Chế độ offline chưa sẵn sàng — hãy tải lại trang rồi thử lại'); return;
        }
        const res = await Promise.all(urls.map(u => fetch(u, { cache: 'reload' }).then(r => r.ok).catch(() => false)));
        const ok = res.filter(Boolean).length;
        b.textContent = ok === urls.length ? 'Đã tải xong' : 'Thử lại'; b.disabled = ok === urls.length;
        App.toast(ok === urls.length ? `Đã lưu ${ok} tệp để dùng offline` : `Lưu được ${ok}/${urls.length} tệp — kiểm tra mạng rồi thử lại`);
      } catch (err) { b.disabled = false; b.textContent = 'Thử lại'; }
    };
  }

  function notFound() {
    App.setTop('Không tìm thấy', '#/');
    view().innerHTML = '<div class="empty">Không tìm thấy nội dung. <a href="#/">Về trang chủ</a></div>';
  }

  window.Views = { home, subject, lesson, quiz, review, reviewSession, search, settings, notFound };
})();
