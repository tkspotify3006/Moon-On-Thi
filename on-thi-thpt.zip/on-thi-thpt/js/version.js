/* Phiên bản ứng dụng — SỬA Ở MỘT CHỖ NÀY khi cập nhật giao diện/code (sw.js cũng đọc file này). */
self.APP_VERSION = '0.4.0';
