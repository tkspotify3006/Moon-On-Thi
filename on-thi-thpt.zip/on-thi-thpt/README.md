# Ôn thi THPT — Toán · Hóa học · Sinh học (lớp 12)

Ứng dụng web (PWA) để **học bài lớp 12 và ôn thi tốt nghiệp THPT – xét tuyển đại học** (khối B00). Bài học bám SGK bộ **Kết nối tri thức với cuộc sống** (chương trình GDPT 2018).

- Miễn phí, chạy trên **GitHub Pages**. Không cần máy chủ, không cần đăng nhập.
- Cài được lên điện thoại như một app; dùng được khi không có mạng.
- Tiến độ học lưu ngay trên máy, không gửi đi đâu.

## Chức năng

| Phần | Nội dung |
|---|---|
| **Học** | Bài giảng theo đúng thứ tự SGK: giảng từ trực quan đến công thức, ví dụ mẫu có **gợi ý từng nấc** (bấm để mở) trước lời giải, khung *Ghi nhớ*, *Bẫy hay gặp*, *Mẹo làm bài*, *Kiến thức nền lớp 10–11*, phần **Dạng bài thi hay gặp**. Công thức Toán hiển thị chuẩn (KaTeX). |
| **Luyện tập** | Cuối mỗi bài: đúng **3 dạng câu của đề thi tốt nghiệp** — 4 lựa chọn, Đúng/Sai 4 ý (báo điểm theo thang 0,1 / 0,25 / 0,5 / 1), trả lời ngắn (gõ đáp số). Mỗi câu có lời giải. |
| **Ôn tập** | Câu sai hoặc "chưa chắc" tự vào sổ ôn, hỏi lại sau 1 → 3 → 7 → 14 ngày. Nhập được **bộ đề riêng** (đề thi thử của trường…) lưu trên máy, luyện theo phần và thi thử bấm giờ. |
| **Tra cứu** | Tìm nhanh trong tất cả bài, gõ không dấu cũng được. |

## Đưa lên GitHub (làm một lần)

GitHub chỉ cho tải lên dưới 100 file mỗi lần, nên ta **chỉ tải lên 1 file zip**, GitHub tự giải nén và đăng app.

1. Tạo repository **Public** mới (ví dụ `on-thi-thpt`).
2. **Add file → Upload files** → kéo file `on-thi-thpt.zip` (để nguyên, không giải nén) → **Commit changes**.
3. **Add file → Create new file** → ô tên gõ đúng `.github/workflows/deploy.yml` → dán nội dung file `deploy.yml` → **Commit changes**.
4. **Settings → Pages** → mục *Source* chọn **GitHub Actions**.
5. Vào tab **Actions**: nếu chưa chạy thì chọn **Dang app tu file zip → Run workflow**. Chờ dấu ✓ xanh (1–2 phút). App chạy tại `https://<tên-tài-khoản>.github.io/<tên-repo>/`.

**Cập nhật về sau:** Upload files → kéo file zip mới **cùng tên** `on-thi-thpt.zip` (ghi đè) → Commit. App tự cập nhật.

## Thêm / sửa nội dung

Xem **[HUONG-DAN-NOI-DUNG.md](HUONG-DAN-NOI-DUNG.md)**. Kiểm tra trước khi đăng: `node scripts/kiem-tra.mjs` (kiểm cả công thức KaTeX).

## Cấu trúc

```
index.html, style.css, sw.js, manifest.webmanifest
js/            app.js (điều hướng) · views.js (màn hình) · quiz.js (câu hỏi) · store.js (tiến độ, ôn tập) · content.js (Markdown, KaTeX) · onthi.js (bộ đề riêng)
vendor/        marked (Markdown) · katex (công thức)
content/       catalog.json + lop-12/<toan|hoa|sinh>/<bài>/{bai.md, quiz.json, *.svg}
scripts/       kiem-tra.mjs · BRIEF-SOAN-BAI.md (quy chuẩn soạn bài)
```

## Bản quyền nội dung

Bài học được **biên soạn lại**, không sao chép nguyên văn SGK; ví dụ và câu hỏi tự đặt. Có ghi số trang SGK để học sinh đối chiếu. **Không đưa file PDF sách lên repository công khai.**
