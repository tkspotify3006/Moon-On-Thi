---
title: Phương trình mặt cầu
thoi-gian: 45 phút
muc-tieu:
  - Hiểu mặt cầu là tập hợp các điểm cách tâm một khoảng bằng bán kính; nhận biết điểm nằm trong, nằm ngoài, thuộc mặt cầu
  - Nhận biết phương trình mặt cầu ở cả hai dạng (tâm – bán kính và dạng khai triển) cùng điều kiện để một phương trình là phương trình mặt cầu
  - Xác định tâm và bán kính mặt cầu khi biết phương trình
  - Lập phương trình mặt cầu khi biết tâm và bán kính, biết đường kính, biết tâm và một điểm thuộc mặt cầu, biết tâm và mặt phẳng tiếp xúc
  - Vận dụng phương trình mặt cầu vào bài toán thực tiễn (vùng phủ sóng, trạm radar, tọa độ và khoảng cách trên Trái Đất, quả bóng…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mặt cầu tâm $I$, bán kính $R$ là tập hợp các điểm $M$ có $IM=R$. Trong: $IM<R$; ngoài: $IM>R$.
> 2. Tâm $I(a;\,b;\,c)$, bán kính $R$: $(x-a)^2+(y-b)^2+(z-c)^2=R^2$ — **đổi dấu** để đọc tâm, **lấy căn** để ra bán kính.
> 3. Dạng khai triển $x^2+y^2+z^2-2ax-2by-2cz+d=0$ là mặt cầu **khi và chỉ khi** $a^2+b^2+c^2-d>0$. Khi đó tâm $I(a;\,b;\,c)$, $R=\sqrt{a^2+b^2+c^2-d}$.
> 4. Lập phương trình = **tìm tâm và bán kính**: đường kính $AB$ → tâm là trung điểm, $R=\frac{AB}{2}$; qua điểm $A$ → $R=IA$; tiếp xúc mặt phẳng $(P)$ → $R=d(I,(P))$.
> 5. Thực tế: vùng phủ sóng, radar là **khối cầu** ($IM\le R$); Trái Đất là mặt cầu $x^2+y^2+z^2=1$ (1 đơn vị = 6 371 km).

Ở lớp 10 em đã viết phương trình đường tròn: $(x-a)^2+(y-b)^2=R^2$. Bài này làm đúng việc đó nhưng **trong không gian**: thêm một tọa độ $z$, đường tròn thành **mặt cầu**. Mặt cầu có mặt khắp nơi trong đời sống: quả bóng, giọt nước, vùng phủ sóng của một trạm phát, và cả… Trái Đất. Cuối bài, em sẽ hiểu ứng dụng bản đồ trên điện thoại tính khoảng cách giữa hai thành phố như thế nào (SGK tr. 54).

> [!nen-tang] Cần nhớ từ lớp 10 và Bài 8
> - Khoảng cách hai điểm: $AB=\sqrt{(x_B-x_A)^2+(y_B-y_A)^2+(z_B-z_A)^2}$.
> - Trung điểm $M$ của $AB$: $M\left(\dfrac{x_A+x_B}{2};\,\dfrac{y_A+y_B}{2};\,\dfrac{z_A+z_B}{2}\right)$.
> - Đường tròn tâm $I(a;\,b)$, bán kính $R$ trong mặt phẳng $Oxy$: $(x-a)^2+(y-b)^2=R^2$.
> - Hằng đẳng thức: $x^2-2ax=(x-a)^2-a^2$ — dùng để "gom" về bình phương.

## 1. Phương trình mặt cầu

### 1.1. Mặt cầu là gì?

Hãy tưởng tượng em buộc một quả bóng nhỏ vào đầu sợi dây dài $R$, giữ chặt đầu kia tại một điểm $I$ rồi quay sợi dây (căng thẳng) theo **mọi hướng** trong không gian. Quả bóng vạch ra một mặt "tròn đều" bao quanh $I$ — đó là **mặt cầu**.

> [!ghi-nho] Định nghĩa (SGK tr. 54)
> Mặt cầu tâm $I$, bán kính $R$ ($R>0$) là tập hợp các điểm $M$ trong không gian sao cho $IM=R$.
> - $M$ **nằm trong** mặt cầu nếu $IM<R$.
> - $M$ **nằm ngoài** mặt cầu nếu $IM>R$.
> - Đoạn thẳng nối hai giao điểm của mặt cầu với một đường thẳng đi qua tâm là một **đường kính**. Đường kính có trung điểm là tâm và dài $2R$.

![Hình 1. Mặt cầu tâm I, bán kính R: M thuộc mặt cầu (IM = R), N nằm trong (IN < R), P nằm ngoài (IP > R); AB là một đường kính](h1-mat-cau.svg)

Phân biệt hai từ hay bị dùng lẫn:
- **Mặt cầu** chỉ là cái **vỏ** (các điểm có $IM=R$).
- **Khối cầu** là vỏ **cùng toàn bộ phần ruột** bên trong (các điểm có $IM\le R$).

Quả bóng bay là hình ảnh của mặt cầu; viên bi sắt đặc là hình ảnh của khối cầu. Khi đề nói "vùng phủ sóng", "phạm vi theo dõi của radar", ta đang nói tới **khối cầu**.

### 1.2. Phương trình mặt cầu khi biết tâm và bán kính

Trong không gian $Oxyz$, cho mặt cầu $(S)$ tâm $I(a;\,b;\,c)$, bán kính $R$. Lấy điểm $M(x;\,y;\,z)$ bất kì. Ta có:

$$M\in(S)\iff IM=R\iff IM^2=R^2.$$

Ta **bình phương** để bỏ dấu căn (hai vế đều không âm nên bình phương không làm thay đổi gì). Viết $IM^2$ bằng tọa độ là xong:

> [!ghi-nho] Phương trình mặt cầu (SGK tr. 54)
> Mặt cầu $(S)$ tâm $I(a;\,b;\,c)$, bán kính $R$ có phương trình
> $$(x-a)^2+(y-b)^2+(z-c)^2=R^2.$$

Hệ quả trực tiếp (SGK tr. 55): với điểm $M(x_0;\,y_0;\,z_0)$, đặt $T=(x_0-a)^2+(y_0-b)^2+(z_0-c)^2$ (chính là $IM^2$), thì:
- $T<R^2$: $M$ nằm **trong** mặt cầu;
- $T=R^2$: $M$ **thuộc** mặt cầu;
- $T>R^2$: $M$ nằm **ngoài** mặt cầu.

**Cách đọc tâm và bán kính:** trong mỗi ngoặc là "$x$ **trừ** hoành độ tâm". Gặp $(y+2)^2$ thì viết lại là $\big(y-(-2)\big)^2$, nên tung độ tâm là $-2$. Vế phải là $R^2$, nên $R$ là **căn** của vế phải.

> [!vi-du] Ví dụ 1
> Cho mặt cầu $(S):(x+2)^2+(y-1)^2+(z-3)^2=9$.
>
> a) Xác định tâm và bán kính của $(S)$.
>
> b) Mỗi điểm sau nằm trong, nằm ngoài hay thuộc $(S)$: $A(0;\,2;\,1)$, $B(1;\,1;\,1)$, $C(-1;\,0;\,2)$, gốc tọa độ $O$?

> [!goi-y] Gợi ý 1
> a) $(x+2)^2=\big(x-(-2)\big)^2$. Vế phải $9=3^2$.

> [!goi-y] Gợi ý 2
> b) Thay tọa độ từng điểm vào **vế trái**, rồi so kết quả với $R^2=9$.

> [!loi-giai] Lời giải
> a) Tâm $I(-2;\,1;\,3)$, bán kính $R=\sqrt9=3$.
>
> b) Thay vào vế trái:
> - $A$: $(0+2)^2+(2-1)^2+(1-3)^2=4+1+4=9=R^2$ → $A$ **thuộc** $(S)$.
> - $B$: $9+0+4=13>9$ → $B$ nằm **ngoài** $(S)$.
> - $C$: $1+1+1=3<9$ → $C$ nằm **trong** $(S)$.
> - $O$: $4+1+9=14>9$ → $O$ nằm **ngoài** $(S)$.

> [!bay] Ba lỗi hay gặp khi đọc phương trình
> 1. **Giữ nguyên dấu** khi đọc tâm: từ $(x+2)^2$ viết tâm có hoành độ $+2$ — sai, phải là $-2$.
> 2. **Quên lấy căn**: thấy vế phải bằng $9$ liền ghi $R=9$ — sai, $R=3$. Ngược lại, khi **lập** phương trình với $R=3$ phải viết vế phải là $9$, không phải $3$.
> 3. Thiếu một biến: $(x-1)^2+y^2+(z+4)^2=5$ vẫn là mặt cầu, tâm có **tung độ bằng 0**: $I(1;\,0;\,-4)$.

### 1.3. Lập phương trình mặt cầu

Muốn viết phương trình mặt cầu, ta chỉ cần **hai thứ: tâm $I$ và bán kính $R$** (hoặc $R^2$). Mọi bài "lập phương trình mặt cầu" đều quy về việc tìm hai thứ này.

| Đề cho | Tâm $I$ | Bán kính $R$ |
|---|---|---|
| Tâm và bán kính | có sẵn | có sẵn |
| Tâm $I$ và một điểm $A$ thuộc mặt cầu | có sẵn | $R=IA$ |
| Đường kính $AB$ | trung điểm của $AB$ | $R=\dfrac{AB}{2}$ |
| Tâm $I$ và mặt phẳng $(P)$ tiếp xúc | có sẵn | $R=d\big(I,(P)\big)$ |

Vì sao đường kính cho tâm là trung điểm? Hai đầu đường kính nằm "đối xứng" qua tâm (Hình 1), nên tâm chính là trung điểm của đoạn nối chúng, và đoạn đó gồm hai bán kính.

> [!vi-du] Ví dụ 2
> Viết phương trình mặt cầu $(S)$ trong mỗi trường hợp:
>
> a) $(S)$ có tâm $I(1;\,-2;\,0)$ và đi qua điểm $A(3;\,0;\,1)$.
>
> b) $(S)$ có đường kính $AB$ với $A(2;\,-1;\,4)$ và $B(0;\,3;\,-2)$.

> [!goi-y] Gợi ý 1
> a) Điểm $A$ nằm trên mặt cầu thì $IA$ chính là bán kính. Thực ra ta chỉ cần $R^2=IA^2$, khỏi phải lấy căn.

> [!goi-y] Gợi ý 2
> b) Tâm $J$ là trung điểm $AB$. Bán kính $R=\frac{AB}{2}$, nên $R^2=\frac{AB^2}{4}$.

> [!loi-giai] Lời giải
> a) $R^2=IA^2=(3-1)^2+(0+2)^2+(1-0)^2=4+4+1=9$. Vậy $(S):(x-1)^2+(y+2)^2+z^2=9$.
>
> b) Tâm $J\left(\frac{2+0}{2};\,\frac{-1+3}{2};\,\frac{4-2}{2}\right)=(1;\,1;\,1)$.
> $AB^2=(0-2)^2+(3+1)^2+(-2-4)^2=4+16+36=56$, nên $R^2=\frac{56}{4}=14$.
> Vậy $(S):(x-1)^2+(y-1)^2+(z-1)^2=14$.

> [!meo] Làm việc với $R^2$, đừng vội lấy căn
> Phương trình chỉ cần $R^2$. Ở Ví dụ 2b, nếu tính $AB=\sqrt{56}=2\sqrt{14}$, rồi $R=\sqrt{14}$, rồi bình phương lại thì vừa lâu vừa dễ sai. Nhớ: $R^2=\dfrac{AB^2}{4}$.

**Mặt cầu tiếp xúc với mặt phẳng.** Đặt một quả bóng lên mặt bàn: quả bóng và mặt bàn chỉ **chạm nhau tại đúng một điểm** $H$, và tâm quả bóng nằm **ngay phía trên** điểm chạm, tức là $IH$ vuông góc với mặt bàn. Ta nói mặt cầu **tiếp xúc** với mặt phẳng. Khi đó bán kính bằng khoảng cách từ tâm đến mặt phẳng: $R=IH=d\big(I,(P)\big)$. Công thức khoảng cách từ điểm đến mặt phẳng em đã học ở **Bài 14, mục 6** (SGK tr. 38). Dạng bài này ứng với Bài tập 5.27 (SGK tr. 59).

![Hình 2. Mặt cầu tiếp xúc với mặt phẳng (P) tại H: IH vuông góc với (P) và R = IH = d(I, (P))](h2-tiep-xuc.svg)

> [!vi-du] Ví dụ 3
> Cho điểm $I(1;\,2;\,-1)$ và mặt phẳng $(P):2x+y-2z+3=0$.
>
> a) Viết phương trình mặt cầu $(S)$ tâm $I$, có bán kính bằng khoảng cách từ $I$ đến $(P)$.
>
> b) (Mở rộng) Tìm tọa độ điểm $H$ là chân đường vuông góc hạ từ $I$ xuống $(P)$ — đó là điểm "chạm" của $(S)$ và $(P)$.

> [!goi-y] Gợi ý 1
> a) $d\big(I,(P)\big)=\dfrac{\lvert Ax_0+By_0+Cz_0+D\rvert}{\sqrt{A^2+B^2+C^2}}$ với $\vec n=(2;\,1;\,-2)$.

> [!goi-y] Gợi ý 2
> b) $\overrightarrow{IH}$ cùng phương với $\vec n$, nên $H=(1+2k;\,2+k;\,-1-2k)$. Thay vào phương trình $(P)$ để tìm $k$.

> [!loi-giai] Lời giải
> a) $R=d\big(I,(P)\big)=\dfrac{\lvert2\cdot1+2-2\cdot(-1)+3\rvert}{\sqrt{4+1+4}}=\dfrac{9}{3}=3$.
> Vậy $(S):(x-1)^2+(y-2)^2+(z+1)^2=9$.
>
> b) Thay $H$ vào $(P)$: $2(1+2k)+(2+k)-2(-1-2k)+3=0\iff 9+9k=0\iff k=-1$.
> Vậy $H(-1;\,1;\,1)$. Kiểm tra: $IH^2=4+1+4=9=R^2$ ✓.

> [!bay]
> Khoảng cách luôn có **trị tuyệt đối** ở tử và **căn** ở mẫu. Quên trị tuyệt đối có thể ra "bán kính âm". Quên căn ở mẫu ($\frac{9}{9}=1$) cho ra mặt cầu quá nhỏ, không chạm tới $(P)$.

### 1.4. Phương trình mặt cầu dạng khai triển

Khai triển phương trình $(x-a)^2+(y-b)^2+(z-c)^2=R^2$ ta được
$$\begin{aligned}&x^2+y^2+z^2-2ax-2by-2cz\\&\qquad+\underbrace{a^2+b^2+c^2-R^2}_{d}=0.\end{aligned}$$

Đề thi rất hay cho mặt cầu ở **dạng khai triển** này. Đi ngược lại thì sao: một phương trình bất kì có dạng $x^2+y^2+z^2-2ax-2by-2cz+d=0$ có luôn là mặt cầu không? Ta "gom" lại thành bình phương:

$$\begin{aligned}&(x-a)^2+(y-b)^2+(z-c)^2\\&\qquad=a^2+b^2+c^2-d.\end{aligned}$$

Vế trái là $IM^2$ với $I(a;\,b;\,c)$, luôn $\ge0$. Có ba khả năng cho vế phải:
- **Dương**: đặt vế phải $=R^2$ → mặt cầu tâm $I$, bán kính $R$.
- **Bằng 0**: chỉ có đúng **một điểm** $M\equiv I$ thỏa mãn → không phải mặt cầu.
- **Âm**: không có điểm nào thỏa mãn (tổng bình phương không thể âm) → không phải mặt cầu.

> [!ghi-nho] Nhận xét (SGK tr. 56)
> Phương trình $x^2+y^2+z^2-2ax-2by-2cz+d=0$ là phương trình mặt cầu **khi và chỉ khi** $a^2+b^2+c^2-d>0$.
> Khi đó mặt cầu có tâm $I(a;\,b;\,c)$ và bán kính $R=\sqrt{a^2+b^2+c^2-d}$.

> [!meo] Đọc tâm thật nhanh
> Tọa độ tâm = **hệ số của $x$, $y$, $z$ chia cho $-2$**. Ví dụ $x^2+y^2+z^2+4x-6y+2z-2=0$: hệ số là $4$, $-6$, $2$, chia cho $-2$ được $I(-2;\,3;\,-1)$. Còn $d$ là **hằng số tự do, giữ nguyên dấu** ($d=-2$).

> [!vi-du] Ví dụ 4
> Chứng minh phương trình $x^2+y^2+z^2+4x-6y+2z-2=0$ là phương trình mặt cầu. Tìm tâm và bán kính.

> [!goi-y] Gợi ý 1
> So với dạng $-2ax$: $-2a=4\Rightarrow a=-2$. Tương tự tìm $b$, $c$. Hằng số tự do là $d=-2$.

> [!goi-y] Gợi ý 2
> Hoặc gom trực tiếp: $x^2+4x=(x+2)^2-4$, $y^2-6y=(y-3)^2-9$, $z^2+2z=(z+1)^2-1$.

> [!loi-giai] Lời giải
> **Cách 1 (công thức).** $a=-2$, $b=3$, $c=-1$, $d=-2$.
> $a^2+b^2+c^2-d=4+9+1-(-2)=16>0$ nên đây là mặt cầu, tâm $I(-2;\,3;\,-1)$, $R=\sqrt{16}=4$.
>
> **Cách 2 (gom bình phương).** $(x+2)^2-4+(y-3)^2-9+(z+1)^2-1-2=0$, tức là
> $(x+2)^2+(y-3)^2+(z+1)^2=16$. Cùng kết quả.

> [!vi-du] Ví dụ 5
> Phương trình nào dưới đây là phương trình mặt cầu? Nếu là mặt cầu, hãy tìm tâm và bán kính.
>
> a) $x^2+y^2+z^2-2x+4y+2z+10=0$.
>
> b) $2x^2+2y^2+2z^2-4x+8z-10=0$.
>
> c) $x^2+2y^2+z^2-2x+4z-1=0$.
>
> d) $x^2+y^2+z^2-4x+2y+5=0$.

> [!goi-y] Gợi ý 1
> Trước khi tính, kiểm tra **hình thức**: hệ số của $x^2$, $y^2$, $z^2$ phải **bằng nhau** (và không có số hạng $xy$, $yz$, $zx$). Nếu cả ba hệ số đều bằng $k\ne1$ thì chia hai vế cho $k$.

> [!goi-y] Gợi ý 2
> Sau đó tính $a^2+b^2+c^2-d$ và xét dấu.

> [!loi-giai] Lời giải
> a) $a=1$, $b=-2$, $c=-1$, $d=10$: $1+4+1-10=-4<0$ → **không** phải mặt cầu.
>
> b) Chia hai vế cho 2: $x^2+y^2+z^2-2x+4z-5=0$. $a=1$, $b=0$, $c=-2$, $d=-5$: $1+0+4+5=10>0$ → mặt cầu tâm $I(1;\,0;\,-2)$, $R=\sqrt{10}$.
>
> c) Hệ số của $y^2$ là 2, khác hệ số của $x^2$, $z^2$ → **không** phải mặt cầu.
>
> d) $a=2$, $b=-1$, $c=0$, $d=5$: $4+1+0-5=0$ → phương trình chỉ có một nghiệm là điểm $(2;\,-1;\,0)$ → **không** phải mặt cầu.

> [!bay] Bốn bẫy kinh điển của dạng khai triển
> 1. **Quên chia** khi hệ số $x^2,y^2,z^2$ là 2, 3…: đọc thẳng từ $2x^2+2y^2+2z^2-4x+\ldots$ sẽ ra tâm sai.
> 2. **Nhầm dấu $d$**: $d$ là hằng số tự do **ở vế trái** khi vế phải bằng $0$. Với "$\ldots-5=0$" thì $d=-5$, nên $-d=+5$.
> 3. Kết luận "là mặt cầu" khi $a^2+b^2+c^2-d=0$ — sai, khi đó chỉ là **một điểm**.
> 4. Số mũ khác 2 (như $x^3$) hay có số hạng tích $xy$ → không phải mặt cầu, khỏi tính.

## 2. Một số ứng dụng của phương trình mặt cầu trong thực tiễn

### 2.1. Vùng phủ sóng, trạm radar

Một thiết bị phát sóng (trạm wifi, cột 5G, đài radar…) đặt tại điểm $I$ phát tín hiệu **đều theo mọi hướng** và xa tối đa $R$. Vậy vùng nhận được tín hiệu là **khối cầu** tâm $I$, bán kính $R$; ranh giới của nó là mặt cầu $(x-a)^2+(y-b)^2+(z-c)^2=R^2$. Câu hỏi "điểm $M$ có nhận được sóng không?" chính là câu hỏi "$M$ có nằm trong (hoặc trên) mặt cầu không?" (xem Bài tập 5.30, SGK tr. 59).

> [!vi-du] Ví dụ 6
> Chọn hệ $Oxyz$ có đơn vị là kilômét, mặt đất là mặt phẳng $(Oxy)$. Một trạm radar đặt tại $I(5;\,3;\,0)$ theo dõi được mọi vật thể cách nó không quá 10 km.
>
> a) Viết phương trình mặt cầu là ranh giới vùng theo dõi của radar.
>
> b) Hai chiếc flycam đang ở $M(11;\,9;\,5)$ và $N(12;\,9;\,4)$. Radar có theo dõi được chiếc nào?

> [!goi-y] Gợi ý 1
> Ranh giới: mặt cầu tâm $I$, $R=10$, nên vế phải là $100$.

> [!goi-y] Gợi ý 2
> So $IM^2$, $IN^2$ với $100$ — không cần lấy căn.

> [!loi-giai] Lời giải
> a) $(x-5)^2+(y-3)^2+z^2=100$.
>
> b) $IM^2=6^2+6^2+5^2=97<100$ → $M$ ở trong vùng theo dõi (cách radar $\sqrt{97}\approx9{,}85$ km).
> $IN^2=7^2+6^2+4^2=101>100$ → $N$ nằm ngoài, radar **không** theo dõi được (cách $\approx10{,}05$ km).

> [!ung-dung] Vì sao so sánh bình phương lại "an toàn"?
> Khoảng cách là số không âm, nên $IM<R\iff IM^2<R^2$. Làm việc với bình phương giúp tránh căn thức và tránh sai số làm tròn. Ở Ví dụ 6, hai khoảng cách $9{,}85$ và $10{,}05$ rất sát 10. Nếu làm tròn sớm đến hàng đơn vị (đều thành 10) em sẽ không phân biệt được.

### 2.2. Trái Đất trong hệ tọa độ — vĩ độ, kinh độ

**Mô hình.** Trong toán học, ta coi bề mặt Trái Đất là mặt cầu bán kính khoảng 6 371 km (SGK tr. 57). Chọn hệ $Oxyz$ như sau:
- $O$ là **tâm** Trái Đất, 1 đơn vị dài ứng với 6 371 km. Khi đó bề mặt Trái Đất có phương trình $x^2+y^2+z^2=1$.
- Tia $Oz$ đi qua **cực Bắc**, mặt phẳng $(Oxy)$ là mặt phẳng **xích đạo**.
- Tia $Ox$ đi qua giao điểm của **kinh tuyến gốc** (qua Greenwich, London) với xích đạo, tia $Oy$ cắt xích đạo ở **bán cầu Đông**.

**Vĩ độ, kinh độ** (SGK tr. 57). Vị trí $P$ trên mặt đất được ghi bằng hai góc:
- **Vĩ độ** $\alpha$ (từ $0^\circ$ đến $90^\circ$): góc giữa $OP$ và mặt phẳng xích đạo, kèm chữ $N$ (bán cầu Bắc) hoặc $S$ (bán cầu Nam).
- **Kinh độ** $\beta$ (từ $0^\circ$ đến $180^\circ$): góc "quay" từ kinh tuyến gốc sang kinh tuyến qua $P$, kèm chữ $E$ (bán cầu Đông) hoặc $W$ (bán cầu Tây).

Ví dụ: Hà Nội ở khoảng $21^\circ N$, $106^\circ E$ (cách xích đạo $21^\circ$ về phía bắc, cách kinh tuyến gốc $106^\circ$ về phía đông).

**Từ vĩ độ – kinh độ sang tọa độ.** Gọi $H$ là hình chiếu vuông góc của $P$ xuống mặt phẳng xích đạo. Vì $OP=1$ và góc giữa $OP$ với mặt phẳng xích đạo là $\alpha$:
- chiều cao $PH=\sin\alpha$, nên $z=\sin\alpha$;
- $OH=\cos\alpha$, và $OH$ hợp với $Ox$ góc $\beta$ nên (giống tọa độ trên đường tròn lượng giác) $x=OH\cos\beta$, $y=OH\sin\beta$.

![Hình 3. Vị trí P có vĩ độ α°N và kinh độ β°E: P(cos α cos β; cos α sin β; sin α)](h3-trai-dat.svg)

> [!ghi-nho] Tọa độ của một vị trí trên mặt đất (SGK tr. 57)
> Với $0<\alpha<90$, $0<\beta<180$:
> - vị trí $\alpha^\circ N,\ \beta^\circ E$ có tọa độ $\big(\cos\alpha^\circ\cos\beta^\circ;\ \cos\alpha^\circ\sin\beta^\circ;\ \sin\alpha^\circ\big)$;
> - vị trí $\alpha^\circ N,\ \beta^\circ W$ có tọa độ $\big(\cos\alpha^\circ\cos\beta^\circ;\ -\cos\alpha^\circ\sin\beta^\circ;\ \sin\alpha^\circ\big)$.
>
> Kiểm tra: $x^2+y^2+z^2=\cos^2\alpha(\cos^2\beta+\sin^2\beta)+\sin^2\alpha=1$ ✓ — điểm đúng là nằm trên mặt đất.

**Khoảng cách trên mặt đất.** Đường đi ngắn nhất trên mặt đất từ $P$ đến $Q$ là **cung nhỏ $PQ$ của đường tròn tâm $O$** đi qua $P$, $Q$ (đường tròn lớn, bán kính bằng bán kính Trái Đất). Độ dài cung này tính theo góc ở tâm $\widehat{POQ}$, mà góc này lại tính được bằng **tích vô hướng** (Bài 8):

$$\cos\widehat{POQ}=\frac{\overrightarrow{OP}\cdot\overrightarrow{OQ}}{\lvert\overrightarrow{OP}\rvert\cdot\lvert\overrightarrow{OQ}\rvert}=\overrightarrow{OP}\cdot\overrightarrow{OQ}$$

(mẫu số bằng 1 vì $OP=OQ=1$).

Sau đó: độ dài cung $=\dfrac{\widehat{POQ}}{360^\circ}\cdot2\pi\cdot6\,371$ (km).

> [!vi-du] Ví dụ 7
> Coi Hà Nội ở vị trí $P$: $21^\circ N$, $106^\circ E$ và Singapore ở vị trí $Q$: $1^\circ N$, $104^\circ E$. Tính khoảng cách trên mặt đất giữa hai thành phố (làm tròn đến hàng đơn vị, đơn vị km).

> [!goi-y] Gợi ý 1
> Viết $\overrightarrow{OP}=(\cos21^\circ\cos106^\circ;\ \cos21^\circ\sin106^\circ;\ \sin21^\circ)$, tương tự cho $\overrightarrow{OQ}$, rồi nhân vô hướng.

> [!goi-y] Gợi ý 2
> Có $\cos\widehat{POQ}$ rồi bấm $\cos^{-1}$ (máy để chế độ độ) ra góc, rồi nhân $\dfrac{2\pi\cdot6\,371}{360}$.

> [!loi-giai] Lời giải
> $\overrightarrow{OP}\approx(-0{,}2573;\ 0{,}8974;\ 0{,}3584)$, $\overrightarrow{OQ}\approx(-0{,}2419;\ 0{,}9701;\ 0{,}0175)$.
>
> $\cos\widehat{POQ}=\overrightarrow{OP}\cdot\overrightarrow{OQ}\approx0{,}9391$, suy ra $\widehat{POQ}\approx20{,}095^\circ$.
>
> Khoảng cách $\approx\dfrac{20{,}095}{360}\cdot2\pi\cdot6\,371\approx2\,234$ km.
>
> (Khoảng cách thực tế giữa hai thành phố vào khoảng 2 200 km. Sai khác nhỏ là do ta lấy tọa độ tròn số độ và coi Trái Đất là hình cầu.)

> [!meo] Bấm máy Casio fx-580VN X
> Để máy ở chế độ **độ (D)**. Có thể bấm thẳng một biểu thức:
> $\cos^{-1}\!\big(\cos21\cos106\cos1\cos104+\cos21\sin106\cos1\sin104+\sin21\sin1\big)\times\pi\times6371\div180$.
> Bấm một lần, **không làm tròn giữa chừng**, sẽ ra $\approx2\,234{,}47$.

> [!bay]
> 1. Quên đổi góc sang radian khi tính cung: độ dài cung $=R\cdot\varphi$ chỉ đúng khi $\varphi$ đo bằng **radian**. Nếu $\varphi$ đo bằng độ thì dùng $\frac{\varphi}{360}\cdot2\pi R$.
> 2. Hai nơi **cùng vĩ độ** (ví dụ cùng $30^\circ N$): đi dọc theo vĩ tuyến **không** phải đường ngắn nhất, vì vĩ tuyến là đường tròn nhỏ hơn đường tròn lớn. Đường ngắn nhất vẫn là cung của đường tròn tâm $O$.
> 3. Vị trí ở bán cầu Tây ($W$) thì tung độ **mang dấu âm**.

> [!em-co-biet] GPS và mặt cầu (SGK tr. 59–60)
> Máy thu GPS đo được khoảng cách từ nó tới nhiều vệ tinh (nhờ thời gian tín hiệu bay với vận tốc ánh sáng). Biết khoảng cách $r_1$ tới vệ tinh $A$ nghĩa là máy thu nằm trên **mặt cầu** tâm $A$ bán kính $r_1$. Có ba vệ tinh là có ba mặt cầu, thêm phương trình mặt đất $x^2+y^2+z^2=1$. Khi **trừ vế theo vế** hai phương trình mặt cầu, các số hạng $x^2,y^2,z^2$ triệt tiêu, chỉ còn phương trình **bậc nhất** — nhờ vậy giải ra tọa độ máy thu khá dễ, rồi đổi sang vĩ độ, kinh độ. Ở mỗi thời điểm, mỗi vị trí trên mặt đất luôn "nhìn thấy" ít nhất 4 vệ tinh GPS.

## Dạng bài thi hay gặp

### Dạng 1. Tìm tâm, bán kính — nhận biết phương trình mặt cầu (có tham số)

- **Nhận biết:** "xác định tâm và bán kính", "phương trình nào là phương trình mặt cầu", "tìm $m$ để phương trình là phương trình mặt cầu / để bán kính bằng…".
- **Phương pháp:**
  1. Kiểm tra hình thức: hệ số $x^2,y^2,z^2$ bằng nhau (chia cho hệ số chung nếu khác 1), không có số hạng $xy,yz,zx$.
  2. Đọc $a,b,c$ = hệ số của $x,y,z$ chia cho $-2$; $d$ = hằng số tự do.
  3. Điều kiện mặt cầu: $a^2+b^2+c^2-d>0$; bán kính $R=\sqrt{a^2+b^2+c^2-d}$.
- **Bẫy:** dấu của $d$; điều kiện là "$>0$" chứ không phải "$\ge0$".

> [!vi-du] Ví dụ 8
> Cho phương trình $x^2+y^2+z^2-2mx+4y-2z+m+5=0$ ($m$ là tham số).
>
> a) Tìm $m$ để phương trình là phương trình mặt cầu.
>
> b) Tìm $m$ để đó là mặt cầu có bán kính bằng $\sqrt6$.

> [!goi-y] Gợi ý 1
> $a=m$, $b=-2$, $c=1$, $d=m+5$.

> [!goi-y] Gợi ý 2
> a) Giải bất phương trình bậc hai $m^2+4+1-(m+5)>0$. b) Giải $m^2-m=6$.

> [!loi-giai] Lời giải
> a) $a^2+b^2+c^2-d=m^2+4+1-m-5=m^2-m$. Điều kiện $m^2-m>0\iff m(m-1)>0\iff m<0$ hoặc $m>1$.
>
> b) $R^2=m^2-m=6\iff m^2-m-6=0\iff m=3$ hoặc $m=-2$. Cả hai đều thỏa mãn điều kiện ở câu a (vì $R^2=6>0$).

### Dạng 2. Vị trí của điểm đối với mặt cầu

- **Nhận biết:** "điểm $M$ nằm trong/ngoài/thuộc mặt cầu", "vị trí nào thuộc vùng phủ sóng".
- **Phương pháp:** tìm tâm $I$, $R$ → tính $IM^2$ → so với $R^2$. Với mặt cầu dạng khai triển có cách nhanh hơn: thay tọa độ $M$ vào **vế trái** $x^2+y^2+z^2-2ax-2by-2cz+d$. Kết quả chính là $IM^2-R^2$, nên **âm** → trong, **bằng 0** → thuộc, **dương** → ngoài.
- **Bẫy:** so $IM$ với $R^2$ (lệch "bậc"); quên rằng "vùng phủ sóng" bao gồm cả các điểm bên trong.

> [!vi-du] Ví dụ 9
> Cho mặt cầu $(S):(x-1)^2+y^2+(z+2)^2=4$ và điểm $M(4;\,4;\,-2)$.
>
> a) Chứng tỏ $M$ nằm ngoài $(S)$.
>
> b) (Mở rộng) Tìm khoảng cách ngắn nhất và dài nhất từ $M$ đến một điểm của $(S)$.

> [!goi-y] Gợi ý 1
> $I(1;\,0;\,-2)$, $R=2$. Tính $IM$.

> [!goi-y] Gợi ý 2
> b) Kẻ đường thẳng $MI$, cắt mặt cầu tại hai điểm. Điểm gần $M$ cách $M$ một đoạn $IM-R$, điểm xa cách $IM+R$.

> [!loi-giai] Lời giải
> a) $IM^2=9+16+0=25>4$ nên $M$ nằm ngoài $(S)$, $IM=5$.
>
> b) Với mọi điểm $N\in(S)$, bất đẳng thức tam giác cho $IM-IN\le MN\le IM+IN$, tức là $3\le MN\le7$. Dấu bằng xảy ra tại hai giao điểm của đường thẳng $MI$ với $(S)$. Vậy ngắn nhất là $3$, dài nhất là $7$.

### Dạng 3. Lập phương trình mặt cầu

- **Nhận biết:** đề cho "đường kính $AB$", "tâm $I$ và đi qua $A$", "tâm $I$, tiếp xúc với $(P)$", "tâm thuộc trục $Ox$ và đi qua $A$, $B$"…
- **Phương pháp:** dùng bảng ở mục 1.3. Nếu **tâm chưa biết** nhưng nằm trên một trục: gọi tâm là $(t;\,0;\,0)$ (trên $Ox$) hoặc $(0;\,t;\,0)$, $(0;\,0;\,t)$. Điều kiện "đi qua $A$, $B$" cho $IA^2=IB^2$ → phương trình bậc nhất theo $t$.
- **Bẫy:** đường kính mà lấy $R=AB$; lấy trung điểm thành $\frac12\overrightarrow{AB}$; tiếp xúc mặt phẳng tọa độ: tiếp xúc $(Oxy)$ thì $R=\lvert z_I\rvert$, tiếp xúc $(Oyz)$ thì $R=\lvert x_I\rvert$, tiếp xúc $(Oxz)$ thì $R=\lvert y_I\rvert$.

> [!vi-du] Ví dụ 10
> Viết phương trình mặt cầu có tâm nằm trên trục $Ox$ và đi qua hai điểm $A(1;\,2;\,0)$, $B(3;\,0;\,2)$.

> [!goi-y] Gợi ý 1
> Gọi tâm $I(t;\,0;\,0)$. Mặt cầu đi qua $A$ và $B$ nên $IA=IB$.

> [!goi-y] Gợi ý 2
> $IA^2=(1-t)^2+4$, $IB^2=(3-t)^2+4$.

> [!loi-giai] Lời giải
> $IA^2=IB^2\iff(1-t)^2+4=(3-t)^2+4\iff1-2t=9-6t\iff t=2$.
> Tâm $I(2;\,0;\,0)$, $R^2=IA^2=1+4=5$. Vậy $(S):(x-2)^2+y^2+z^2=5$.

### Dạng 4. Bài toán thực tế (Đúng/Sai hoặc trả lời ngắn)

- **Nhận biết:** quả bóng, bể cầu, vùng phủ sóng, radar, Trái Đất, GPS…
- **Phương pháp:** đọc kĩ hệ trục và đơn vị → xác định **tâm** và **bán kính** của vật hình cầu (thường nhờ điều kiện tiếp xúc: chạm sàn thì cao độ tâm bằng $R$) → dịch câu hỏi thành "so $IM^2$ với $R^2$" hoặc "khoảng cách".
- **Bẫy:** đường kính và bán kính; đơn vị (cm, m, km); làm tròn sớm.

![Hình 4. Quả bóng bán kính 11 cm nằm ở góc phòng, tiếp xúc với sàn và hai bức tường; tâm I(11; 11; 11)](h4-qua-bong.svg)

> [!vi-du] Ví dụ 11 (Đúng/Sai)
> Một quả bóng có đường kính 22 cm nằm ở góc phòng, tiếp xúc với sàn nhà và hai bức tường vuông góc. Chọn hệ $Oxyz$ (đơn vị cm) có $O$ là góc phòng, sàn là mặt phẳng $(Oxy)$, hai bức tường là $(Oxz)$ và $(Oyz)$, $Oz$ hướng lên. Xét các mệnh đề:
>
> a) Tâm quả bóng là $I(11;\,11;\,11)$.
>
> b) Mặt quả bóng có phương trình $(x-11)^2+(y-11)^2+(z-11)^2=121$.
>
> c) Khoảng cách từ góc phòng $O$ đến điểm gần nhất trên quả bóng nhỏ hơn 8 cm.
>
> d) Điểm $M(19;\,17;\,4)$ nằm bên trong quả bóng.

> [!goi-y] Gợi ý 1
> Bán kính $11$ cm. Quả bóng chạm sàn $(Oxy)$ nên cao độ tâm bằng $R$. Chạm hai tường nên hoành độ, tung độ tâm cũng bằng $R$.

> [!goi-y] Gợi ý 2
> c) Như Dạng 2: khoảng cách ngắn nhất từ $O$ (nằm ngoài) đến mặt cầu là $OI-R$.

> [!loi-giai] Lời giải
> a) **Đúng** — khoảng cách từ $I$ đến ba mặt phẳng $(Oxy)$, $(Oxz)$, $(Oyz)$ là $\lvert z_I\rvert$, $\lvert y_I\rvert$, $\lvert x_I\rvert$ và đều bằng $R=11$. Tâm nằm trong phòng nên các tọa độ dương.
>
> b) **Đúng** — $R^2=11^2=121$.
>
> c) **Sai** — $OI=\sqrt{3\cdot11^2}=11\sqrt3\approx19{,}05$, nên khoảng cách ngắn nhất là $11\sqrt3-11\approx8{,}05$ cm, lớn hơn 8 cm.
>
> d) **Sai** — $IM^2=8^2+6^2+(-7)^2=64+36+49=149>121$, nên $M$ nằm ngoài quả bóng.

## Tóm tắt

| Nội dung | Công thức – cách làm |
|---|---|
| Định nghĩa | $(S)=\{M:\ IM=R\}$; trong: $IM<R$; ngoài: $IM>R$ |
| Dạng tâm – bán kính | $(x-a)^2+(y-b)^2+(z-c)^2=R^2$, tâm $I(a;\,b;\,c)$ |
| Dạng khai triển | $x^2+y^2+z^2-2ax-2by-2cz+d=0$ |
| Điều kiện là mặt cầu | $a^2+b^2+c^2-d>0$ |
| Tâm, bán kính (khai triển) | $I(a;\,b;\,c)$, $R=\sqrt{a^2+b^2+c^2-d}$ |
| Đường kính $AB$ | tâm = trung điểm $AB$, $R^2=\dfrac{AB^2}{4}$ |
| Tâm $I$, qua $A$ | $R^2=IA^2$ |
| Tâm $I$, tiếp xúc $(P)$ | $R=d\big(I,(P)\big)$ (Bài 14) |
| Vị trí điểm $M$ | so $IM^2$ với $R^2$ |
| Vị trí $\alpha^\circ N,\ \beta^\circ E$ | $(\cos\alpha\cos\beta;\ \cos\alpha\sin\beta;\ \sin\alpha)$ trên $x^2+y^2+z^2=1$ |
| Khoảng cách trên mặt đất | $\cos\widehat{POQ}=\overrightarrow{OP}\cdot\overrightarrow{OQ}$; cung $=\dfrac{\widehat{POQ}}{360}\cdot2\pi\cdot6\,371$ km |

**Sơ đồ tư duy khi gặp đề:** thấy phương trình → **đưa về tâm và bán kính**; đề bắt lập phương trình → **đi tìm tâm và bán kính**; hỏi điểm trong/ngoài → **so $IM^2$ với $R^2$**; bài thực tế → chọn đúng tâm, bán kính, đơn vị rồi quay về ba ý trên.
