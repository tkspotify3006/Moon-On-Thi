---
title: Ứng dụng hình học của tích phân
thoi-gian: 50 phút
muc-tieu:
  - Hiểu vì sao diện tích hình phẳng giới hạn bởi đồ thị $y=f(x)$, trục hoành và hai đường thẳng $x=a$, $x=b$ là $\int_a^b\lvert f(x)\rvert\,dx$, và biết "phá" dấu giá trị tuyệt đối bằng cách chia khoảng theo nghiệm
  - Tính được diện tích hình phẳng giới hạn bởi hai đồ thị (có hoặc không có đường thẳng $x=a$, $x=b$), kể cả khi hai đồ thị cắt nhau nhiều lần
  - Hiểu ý tưởng "cắt lát" và dùng công thức $V=\int_a^b S(x)\,dx$ để tính thể tích vật thể khi biết diện tích thiết diện $S(x)$
  - Tính được thể tích khối tròn xoay sinh ra khi quay hình phẳng quanh trục $Ox$: $V=\pi\int_a^b f^2(x)\,dx$
  - Giải các bài toán thực tế: cổng parabol, đường hầm, bồn chứa, bình, thặng dư tiêu dùng…
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Diện tích giữa đồ thị $y=f(x)$, trục $Ox$, $x=a$, $x=b$: $S=\int_a^b\lvert f(x)\rvert\,dx$ — có **trị tuyệt đối** vì phần nằm dưới trục cho tích phân âm.
> 2. Diện tích giữa hai đồ thị: $S=\int_a^b\lvert f(x)-g(x)\rvert\,dx$ — "**trên trừ dưới**", không quan tâm miền nằm trên hay dưới $Ox$.
> 3. Phá trị tuyệt đối: giải $f(x)=0$ (hoặc $f(x)=g(x)$), chia $[a;b]$ theo các nghiệm, trên mỗi đoạn lấy trị tuyệt đối của tích phân rồi cộng lại.
> 4. Thể tích vật thể: $V=\int_a^b S(x)\,dx$, với $S(x)$ là diện tích mặt cắt vuông góc với $Ox$ tại $x$.
> 5. Khối tròn xoay (quay quanh $Ox$): mặt cắt là hình tròn bán kính $\lvert f(x)\rvert$, nên $V=\pi\int_a^b f^2(x)\,dx$ — nhớ **$\pi$** và **bình phương**.

Từ cấp 2 em đã biết diện tích hình chữ nhật, tam giác, hình tròn; thể tích hình hộp, hình chóp, hình cầu. Nhưng diện tích "mặt cổng" hình parabol là bao nhiêu? Một chiếc bình có thành cong thì chứa được mấy lít nước? Những hình như vậy không có công thức sẵn. Tích phân cho ta **một phương pháp chung**: cắt hình thành vô số dải (hoặc lát) thật mỏng, tính từng dải rồi cộng lại. Nhờ đó em vừa tính được hình "lạ", vừa **chứng minh lại** được các công thức quen thuộc như $V_{\text{nón}}=\frac13\pi r^2h$.

> [!nen-tang] Nhắc lại Bài 12 (Tích phân)
> - Công thức Newton – Leibniz: nếu $F$ là một nguyên hàm của $f$ trên $[a;b]$ thì $\int_a^b f(x)\,dx=F(b)-F(a)$, viết gọn $F(x)\Big|_a^b$.
> - Khi $f(x)\ge0$ trên $[a;b]$, $\int_a^b f(x)\,dx$ là **diện tích hình thang cong** dưới đồ thị.
> - Tách đoạn: $\int_a^b f\,dx=\int_a^c f\,dx+\int_c^b f\,dx$; hằng số đưa ra ngoài; tích phân của tổng bằng tổng các tích phân.
> - Bảng nguyên hàm (Bài 11): $\int x^\alpha dx=\frac{x^{\alpha+1}}{\alpha+1}+C$ ($\alpha\ne-1$), $\int\frac1x\,dx=\ln\lvert x\rvert+C$, $\int e^x dx=e^x+C$, $\int\sin x\,dx=-\cos x+C$, $\int\cos x\,dx=\sin x+C$.

## 1. Ứng dụng tích phân để tính diện tích hình phẳng

### 1.1. Hình phẳng giới hạn bởi một đồ thị, trục hoành và hai đường thẳng $x=a$, $x=b$

**Vì sao phải có trị tuyệt đối?** Ở Bài 12, khi $f(x)\ge0$, tích phân $\int_a^b f(x)\,dx$ chính là diện tích phần nằm dưới đồ thị. Nhưng nếu đồ thị đi **xuống dưới** trục hoành thì $f(x)<0$, các "dải mỏng" có chiều cao âm, nên tích phân cho ra số **âm**. Diện tích thì không bao giờ âm. Cách sửa đơn giản: thay chiều cao $f(x)$ bằng $\lvert f(x)\rvert$ — phần dưới trục được "lật" lên trên mà diện tích không đổi.

> [!ghi-nho] Công thức (SGK tr. 19)
> Cho $f(x)$ liên tục trên $[a;b]$ ($a<b$). Diện tích $S$ của hình phẳng giới hạn bởi đồ thị $y=f(x)$, trục hoành và hai đường thẳng $x=a$, $x=b$ là
> $$S=\int_a^b\lvert f(x)\rvert\,dx.$$

**Cách tính (phá trị tuyệt đối):**
1. Giải $f(x)=0$, giữ lại các nghiệm nằm **trong** khoảng $(a;b)$, giả sử là $c_1<c_2<\dots$
2. Trên mỗi đoạn nhỏ, $f(x)$ không đổi dấu, nên $\int\lvert f\rvert\,dx=\left\lvert\int f\,dx\right\rvert$.
3. Cộng các kết quả lại.

Nếu $f(x)$ **không đổi dấu** trên cả $[a;b]$ thì làm gọn: $S=\left\lvert\int_a^b f(x)\,dx\right\rvert$.

> [!vi-du] Ví dụ 1
> Tính diện tích hình phẳng giới hạn bởi đồ thị hàm số $y=x^3+1$, trục hoành và hai đường thẳng $x=0$, $x=2$.

> [!goi-y] Gợi ý 1
> Trên $[0;2]$, $x^3+1$ có đổi dấu không?

> [!goi-y] Gợi ý 2
> $x^3+1\ge1>0$ nên bỏ được trị tuyệt đối. Nguyên hàm của $x^3+1$ là $\frac{x^4}{4}+x$.

> [!loi-giai] Lời giải
> Vì $x^3+1>0$ trên $[0;2]$ nên
> $$\begin{aligned}S&=\int_0^2(x^3+1)\,dx=\left(\frac{x^4}{4}+x\right)\Bigg|_0^2\\&=4+2=6.\end{aligned}$$

Ví dụ tiếp theo cho thấy vì sao **không được** bỏ trị tuyệt đối một cách vô tư.

> [!vi-du] Ví dụ 2
> Tính diện tích $S$ của hình phẳng giới hạn bởi đồ thị $y=x^2-2x$, trục hoành và hai đường thẳng $x=-1$, $x=3$. So sánh $S$ với $\int_{-1}^3(x^2-2x)\,dx$.

> [!goi-y] Gợi ý 1
> $x^2-2x=0\iff x=0$ hoặc $x=2$ — cả hai đều nằm trong $(-1;3)$. Vậy chia thành 3 đoạn: $[-1;0]$, $[0;2]$, $[2;3]$.

> [!goi-y] Gợi ý 2
> Một nguyên hàm: $F(x)=\frac{x^3}{3}-x^2$. Tính $F(-1)$, $F(0)$, $F(2)$, $F(3)$ một lần rồi dùng lại.

> [!loi-giai] Lời giải
> $F(-1)=-\frac43$, $F(0)=0$, $F(2)=-\frac43$, $F(3)=0$.
> - $\int_{-1}^0 f\,dx=0-\left(-\frac43\right)=\frac43$ (phần trên trục).
> - $\int_0^2 f\,dx=-\frac43-0=-\frac43$ (phần dưới trục).
> - $\int_2^3 f\,dx=0-\left(-\frac43\right)=\frac43$ (phần trên trục).
>
> Vậy $S=\frac43+\frac43+\frac43=4$.
> Trong khi đó $\int_{-1}^3 f\,dx=F(3)-F(-1)=\frac43$ — phần dưới trục đã **triệt tiêu** một phần trên trục.

![Hình 1. Phần nằm dưới trục hoành cho tích phân âm; diện tích phải cộng trị tuyệt đối của từng mảnh](h1-dien-tich-truc-hoanh.svg)

> [!bay]
> Đề hỏi **diện tích** mà em bấm thẳng $\int_{-1}^3(x^2-2x)\,dx$ sẽ ra $\frac43$ — đúng là một phương án nhiễu kinh điển. Luôn hỏi: "đồ thị có cắt trục hoành **bên trong** đoạn không?"

**Khi đề không cho $x=a$, $x=b$.** "Hình phẳng giới hạn bởi đồ thị và trục hoành" thì hai cận chính là **nghiệm nhỏ nhất và lớn nhất** của $f(x)=0$ (hai chỗ đồ thị "chạm" trục để khép kín miền).

> [!vi-du] Ví dụ 3
> Tính diện tích hình phẳng giới hạn bởi đồ thị $y=x^3-4x$ và trục hoành.

> [!goi-y] Gợi ý 1
> $x^3-4x=x(x-2)(x+2)=0\iff x\in\{-2;0;2\}$. Miền gồm hai mảnh: $[-2;0]$ và $[0;2]$.

> [!goi-y] Gợi ý 2
> $y=x^3-4x$ là hàm lẻ, đồ thị đối xứng qua gốc $O$, nên hai mảnh có diện tích bằng nhau.

> [!loi-giai] Lời giải
> Trên $[0;2]$, $x^3-4x\le0$, nên mảnh này có diện tích
> $$\begin{aligned}\int_0^2(4x-x^3)\,dx&=\left(2x^2-\frac{x^4}{4}\right)\Bigg|_0^2\\&=8-4=4.\end{aligned}$$
> Mảnh trên $[-2;0]$ đối xứng nên cũng bằng $4$. Vậy $S=8$.
> (Nếu bấm $\int_{-2}^2(x^3-4x)\,dx$ em sẽ được $0$ — rõ ràng vô lí với một diện tích.)

> [!meo] Bấm máy Casio fx-580VN X để soát kết quả
> Phím $\int_\square^\square$ tính được tích phân xác định. Với diện tích, gõ **Abs** (SHIFT + hyp) bọc ngoài hàm: $\int_{-1}^{3}\lvert X^2-2X\rvert\,dX$ → máy cho $4$. Dùng để **kiểm tra**; khi làm tự luận hoặc khi có tham số vẫn phải chia khoảng bằng tay.

### 1.2. Hình phẳng giới hạn bởi hai đồ thị và hai đường thẳng $x=a$, $x=b$

**Ý tưởng "dải mỏng".** Cắt hình phẳng bằng những đường thẳng đứng sát nhau. Tại hoành độ $x$, dải mỏng có chiều rộng rất nhỏ $dx$ và chiều cao là **khoảng cách giữa hai đồ thị**: $\lvert f(x)-g(x)\rvert$. Cộng mọi dải từ $a$ đến $b$ chính là lấy tích phân.

Điều hay: nếu tịnh tiến cả hai đồ thị lên trên hay xuống dưới, khoảng cách $\lvert f(x)-g(x)\rvert$ không đổi. Vì vậy công thức **không phụ thuộc** miền nằm trên hay dưới trục hoành — chỉ cần "đường trên trừ đường dưới".

![Hình 2. Hình phẳng giữa y = x + 2 và y = x²: mỗi dải mỏng cao (x + 2) − x²](h2-giua-hai-do-thi.svg)

> [!ghi-nho] Công thức (SGK tr. 21)
> Cho $f(x)$, $g(x)$ liên tục trên $[a;b]$. Diện tích hình phẳng giới hạn bởi đồ thị $y=f(x)$, $y=g(x)$ và hai đường thẳng $x=a$, $x=b$ là
> $$S=\int_a^b\lvert f(x)-g(x)\rvert\,dx.$$
> Nếu $f(x)-g(x)$ không đổi dấu trên $[a;b]$ thì $S=\left\lvert\int_a^b\big[f(x)-g(x)\big]dx\right\rvert$.

Công thức ở mục 1.1 là trường hợp riêng với $g(x)=0$ (trục hoành chính là đồ thị $y=0$).

**Các bước:**
1. Giải phương trình hoành độ giao điểm $f(x)=g(x)$.
2. Nếu đề **không** cho $x=a$, $x=b$: hai cận là nghiệm nhỏ nhất và lớn nhất.
3. Nếu có nghiệm nằm **trong** $(a;b)$: chia đoạn tại đó, trên mỗi đoạn xác định đồ thị nào ở trên (thử một điểm), rồi cộng.

> [!vi-du] Ví dụ 4
> Tính diện tích hình phẳng giới hạn bởi parabol $y=x^2$ và đường thẳng $y=x+2$.

> [!goi-y] Gợi ý 1
> Đề không cho $x=a$, $x=b$ → tìm hoành độ giao điểm: $x^2=x+2$.

> [!goi-y] Gợi ý 2
> Thử $x=0$ (nằm giữa hai nghiệm): đường thẳng cho $2$, parabol cho $0$ → đường thẳng ở **trên**.

> [!loi-giai] Lời giải
> $x^2-x-2=0\iff x=-1$ hoặc $x=2$. Trên $[-1;2]$, $x+2\ge x^2$ nên
> $$\begin{aligned}S&=\int_{-1}^2(x+2-x^2)\,dx\\&=\left(\frac{x^2}{2}+2x-\frac{x^3}{3}\right)\Bigg|_{-1}^2.\end{aligned}$$
> Tại $x=2$: $2+4-\frac83=\frac{10}3$. Tại $x=-1$: $\frac12-2+\frac13=-\frac76$.
> Vậy $S=\frac{10}{3}+\frac76=\frac92$.

> [!meo] Diện tích giữa parabol và đường thẳng (mở rộng, ngoài SGK)
> Nếu $f(x)-g(x)=a x^2+bx+c$ có hai nghiệm $x_1<x_2$ thì diện tích giữa chúng là
> $$S=\frac{\lvert a\rvert\,(x_2-x_1)^3}{6}.$$
> Ở Ví dụ 4: $a=-1$, $x_2-x_1=3$, $S=\frac{27}{6}=\frac92$ ✓. Dùng để **đoán nhanh** đáp án trắc nghiệm.

> [!vi-du] Ví dụ 5
> Tính diện tích hình phẳng giới hạn bởi đồ thị hai hàm số $y=x^3$, $y=x$ và hai đường thẳng $x=-1$, $x=2$.

> [!goi-y] Gợi ý 1
> $x^3-x=x(x-1)(x+1)=0\iff x\in\{-1;0;1\}$. Trong $(-1;2)$ có hai nghiệm $0$ và $1$ → chia thành $[-1;0]$, $[0;1]$, $[1;2]$.

> [!goi-y] Gợi ý 2
> Đặt $h(x)=x^3-x$, một nguyên hàm là $H(x)=\frac{x^4}{4}-\frac{x^2}{2}$. Trên mỗi đoạn $[\alpha;\beta]$ tính $\lvert H(\beta)-H(\alpha)\rvert$.

> [!loi-giai] Lời giải
> $H(-1)=-\frac14$, $H(0)=0$, $H(1)=-\frac14$, $H(2)=4-2=2$.
> - Trên $[-1;0]$: $\lvert 0-(-\tfrac14)\rvert=\frac14$.
> - Trên $[0;1]$: $\lvert -\tfrac14-0\rvert=\frac14$.
> - Trên $[1;2]$: $\lvert 2-(-\tfrac14)\rvert=\frac94$.
>
> Vậy $S=\frac14+\frac14+\frac94=\frac{11}4$.

> [!bay] Hai lỗi hay gặp
> 1. Quên nghiệm nằm **giữa** đoạn: viết $S=\left\lvert\int_{-1}^2(x^3-x)\,dx\right\rvert=\frac94$ — sai, vì hai mảnh đầu triệt tiêu nhau.
> 2. Lấy cả nghiệm nằm **ngoài** $[a;b]$ làm điểm chia. Chỉ chia tại nghiệm thuộc $(a;b)$.

> [!ung-dung] Thặng dư tiêu dùng và thặng dư sản xuất (SGK tr. 22)
> Trong kinh tế, **hàm cầu** $p=D(x)$ (giá người mua chấp nhận khi cần $x$ sản phẩm) giảm dần, **hàm cung** $p=S(x)$ tăng dần. Chúng cắt nhau tại **điểm cân bằng** $(x_0;\,p_0)$.
> - **Thặng dư tiêu dùng** = diện tích giữa đường cầu và đường ngang $p=p_0$, từ $x=0$ đến $x_0$: phần "lợi" của người mua (họ sẵn sàng trả cao hơn giá thị trường).
> - **Thặng dư sản xuất** = diện tích giữa đường ngang $p=p_0$ và đường cung.
>
> Ví dụ: cầu $p=10-0{,}4x$, cung $p=0{,}1x+5$. Cân bằng: $10-0{,}4x=0{,}1x+5\iff x_0=10$, $p_0=6$.
> Thặng dư tiêu dùng $=\int_0^{10}(10-0{,}4x-6)\,dx=40-20=20$.
> Thặng dư sản xuất $=\int_0^{10}(6-0{,}1x-5)\,dx=10-5=5$.

## 2. Ứng dụng tích phân để tính thể tích vật thể

### 2.1. Thể tích của vật thể khi biết diện tích mặt cắt

**Ý tưởng "thái lát".** Hãy nghĩ đến ổ bánh mì được thái thành những lát rất mỏng vuông góc với trục $Ox$. Lát tại vị trí $x$ có mặt cắt diện tích $S(x)$ và độ dày $dx$, nên thể tích lát xấp xỉ $S(x)\cdot dx$ (như một tấm phẳng). Cộng tất cả các lát từ $x=a$ đến $x=b$ ta được thể tích — và "cộng vô số lát mỏng" chính là tích phân.

![Hình 3. Cắt vật thể bởi mặt phẳng vuông góc với Ox tại x, được mặt cắt có diện tích S(x)](h3-the-tich-thiet-dien.svg)

> [!ghi-nho] Công thức (SGK tr. 22)
> Vật thể nằm giữa hai mặt phẳng vuông góc với $Ox$ tại $x=a$ và $x=b$. Mặt phẳng vuông góc với $Ox$ tại điểm có hoành độ $x$ ($a\le x\le b$) cắt vật thể theo mặt cắt có diện tích $S(x)$, với $S(x)$ liên tục trên $[a;b]$. Khi đó
> $$V=\int_a^b S(x)\,dx.$$

**Kiểm tra với hình quen thuộc.**
- *Lăng trụ* đáy diện tích $B$, cao $h$: mọi mặt cắt song song đáy đều bằng đáy, $S(x)=B$, nên $V=\int_0^h B\,dx=Bh$ ✓.
- *Hình chóp* đáy diện tích $B$, cao $h$: đặt đỉnh tại $O$, trục $Ox$ vuông góc với đáy. Mặt cắt tại $x$ là hình **đồng dạng** với đáy, tỉ số $\frac xh$, nên diện tích bằng $B\cdot\frac{x^2}{h^2}$. Do đó
$$V=\int_0^h\frac{B}{h^2}x^2\,dx=\frac{B}{h^2}\cdot\frac{h^3}{3}=\frac13Bh.$$
Đây chính là lí do của số $\frac13$ "bí ẩn" trong công thức thể tích hình chóp!

> [!vi-du] Ví dụ 6
> Một vật thể nằm giữa hai mặt phẳng $x=0$ và $x=4$. Mặt cắt của vật thể bởi mặt phẳng vuông góc với $Ox$ tại điểm có hoành độ $x$ ($0\le x\le4$) là một tam giác đều cạnh $2\sqrt x$. Tính thể tích vật thể (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Tam giác đều cạnh $c$ có diện tích $\frac{\sqrt3}{4}c^2$.

> [!goi-y] Gợi ý 2
> $S(x)=\frac{\sqrt3}{4}\cdot(2\sqrt x)^2=\sqrt3\,x$.

> [!loi-giai] Lời giải
> $S(x)=\frac{\sqrt3}{4}\cdot4x=\sqrt3\,x$, nên
> $$\begin{aligned}V&=\int_0^4\sqrt3\,x\,dx=\sqrt3\cdot\frac{x^2}{2}\Bigg|_0^4\\&=8\sqrt3\approx13{,}9.\end{aligned}$$

> [!bay]
> Công thức $V=\int_a^b S(x)\,dx$ **không** có $\pi$. Số $\pi$ chỉ xuất hiện khi mặt cắt là **hình tròn** (khối tròn xoay ở mục 2.2). Đừng "thêm $\pi$ theo thói quen".

### 2.2. Thể tích khối tròn xoay

Quay hình phẳng giới hạn bởi đồ thị $y=f(x)$, trục hoành và hai đường thẳng $x=a$, $x=b$ một vòng quanh trục $Ox$, ta được một **khối tròn xoay**. Cắt khối này bởi mặt phẳng vuông góc với $Ox$ tại $x$: điểm $(x;\,f(x))$ trên đồ thị quay thành một **đường tròn** tâm trên $Ox$, bán kính $\lvert f(x)\rvert$. Vậy mặt cắt là hình tròn, diện tích
$$S(x)=\pi f^2(x).$$
Áp dụng công thức của mục 2.1 là xong.

![Hình 4. Quay hình phẳng dưới y = 4 − x² quanh Ox; mặt cắt tại x là hình tròn bán kính f(x)](h4-khoi-tron-xoay.svg)

> [!ghi-nho] Công thức (SGK tr. 24)
> Cho $f(x)$ liên tục, không âm trên $[a;b]$. Thể tích khối tròn xoay sinh ra khi quay hình phẳng giới hạn bởi đồ thị $y=f(x)$, trục hoành và hai đường thẳng $x=a$, $x=b$ quanh trục $Ox$ là
> $$V=\pi\int_a^b f^2(x)\,dx.$$

SGK phát biểu cho $f(x)\ge0$. Nếu $f$ có chỗ âm thì công thức vẫn đúng (mở rộng): phần đồ thị nằm dưới trục khi quay vẫn cho hình tròn bán kính $\lvert f(x)\rvert$, diện tích $\pi f^2(x)$. Vì $f^2(x)\ge0$ nên ở đây **không cần** chia khoảng hay trị tuyệt đối.

> [!vi-du] Ví dụ 7
> Tính thể tích khối tròn xoay sinh ra khi quay hình phẳng giới hạn bởi parabol $y=4-x^2$ và trục hoành quanh trục $Ox$.

> [!goi-y] Gợi ý 1
> Cận: $4-x^2=0\iff x=\pm2$.

> [!goi-y] Gợi ý 2
> Khai triển $(4-x^2)^2=16-8x^2+x^4$ trước khi lấy nguyên hàm. Có thể dùng tính đối xứng: tích phân từ $-2$ đến $2$ bằng hai lần tích phân từ $0$ đến $2$.

> [!loi-giai] Lời giải
> $$\begin{aligned}V&=\pi\int_{-2}^2(16-8x^2+x^4)\,dx\\&=2\pi\left(16x-\frac{8x^3}{3}+\frac{x^5}{5}\right)\Bigg|_0^2.\end{aligned}$$
> Tại $x=2$: $32-\frac{64}{3}+\frac{32}{5}=\frac{480-320+96}{15}=\frac{256}{15}$.
> Vậy $V=2\pi\cdot\frac{256}{15}=\frac{512\pi}{15}\approx107{,}2$.

> [!bay] Ba lỗi kinh điển
> 1. Quên $\pi$: ra $\frac{512}{15}$.
> 2. Quên bình phương: $\pi\int_{-2}^2(4-x^2)\,dx=\frac{32\pi}{3}$ — đó là "$\pi\times$ diện tích", không phải thể tích.
> 3. Bình phương sai: $(4-x^2)^2\ne16-x^4$. Phải khai triển đủ $16-8x^2+x^4$.

**Chứng minh lại công thức khối nón, nón cụt, khối cầu.**
- *Khối nón* bán kính đáy $r$, chiều cao $h$: quay tam giác vuông dưới đường thẳng $y=\frac rh x$, $0\le x\le h$:
$$V=\pi\int_0^h\frac{r^2}{h^2}x^2\,dx=\frac13\pi r^2h.$$
- *Khối cầu* bán kính $R$: quay nửa hình tròn dưới $y=\sqrt{R^2-x^2}$, $-R\le x\le R$:
$$V=\pi\int_{-R}^R(R^2-x^2)\,dx=\frac43\pi R^3.$$
Lưu ý $\left(\sqrt{R^2-x^2}\right)^2=R^2-x^2$ — căn "biến mất" khi bình phương, nên tích phân rất dễ (SGK tr. 25).

> [!vi-du] Ví dụ 8
> Quay hình thang giới hạn bởi đường thẳng $y=\frac x2+1$, trục hoành và hai đường thẳng $x=0$, $x=4$ quanh trục $Ox$.
>
> a) Khối tròn xoay nhận được là khối gì? Nêu bán kính hai đáy và chiều cao.
>
> b) Tính thể tích của nó bằng tích phân.

> [!goi-y] Gợi ý 1
> Tại $x=0$ bán kính là $f(0)=1$; tại $x=4$ bán kính là $f(4)=3$.

> [!goi-y] Gợi ý 2
> $\left(\frac x2+1\right)^2=\frac{x^2}{4}+x+1$.

> [!loi-giai] Lời giải
> a) Khối **nón cụt** có bán kính hai đáy $1$ và $3$, chiều cao $4$.
>
> b) $V=\pi\int_0^4\left(\frac{x^2}{4}+x+1\right)dx=\pi\left(\frac{x^3}{12}+\frac{x^2}{2}+x\right)\Bigg|_0^4$.
> Ta được $V=\pi\left(\frac{16}{3}+8+4\right)=\frac{52\pi}{3}$.
> Kiểm tra bằng công thức nón cụt $V=\frac{\pi h}{3}(R^2+Rr+r^2)=\frac{4\pi}{3}\cdot13=\frac{52\pi}{3}$ ✓.

> [!em-co-biet]
> Ý tưởng "cắt lát rồi cộng" có từ thời Archimedes (thế kỉ III TCN): ông đã tìm ra diện tích dưới parabol và thể tích khối cầu bằng cách "cân" các lát mỏng. Nhà toán học Ý Cavalieri (thế kỉ XVII) phát biểu: *hai vật thể có mọi mặt cắt tương ứng bằng nhau thì thể tích bằng nhau* — chính là hệ quả của công thức $V=\int_a^b S(x)\,dx$.

## Dạng bài thi hay gặp

### Dạng 1. Diện tích khi đồ thị cho trong hình

- **Nhận biết:** đề vẽ đồ thị $y=f(x)$ (không cho công thức), cho biết các giao điểm với $Ox$, hỏi "công thức nào tính diện tích phần tô màu" hoặc cho sẵn vài tích phân/diện tích để tính cái còn lại.
- **Phương pháp:** đọc giao điểm → trên mỗi đoạn, phần **trên** trục thì $\lvert\int f\rvert=\int f$, phần **dưới** trục thì $\lvert\int f\rvert=-\int f$ → viết $S$ thành tổng/hiệu các tích phân.
- **Bẫy:** viết $S=\int_a^b f(x)\,dx$ cho cả miền; đổi dấu nhầm phần nằm dưới trục.

> [!vi-du] Ví dụ 9
> Hàm số $y=f(x)$ liên tục trên $[-3;4]$, đồ thị cắt trục hoành tại ba điểm có hoành độ $-3$, $1$, $4$; trên $(-3;1)$ đồ thị nằm **trên** trục hoành, trên $(1;4)$ đồ thị nằm **dưới** trục hoành. Biết phần hình phẳng bên trái có diện tích $6$, phần bên phải có diện tích $4$.
>
> a) Viết công thức tính diện tích $S$ của toàn bộ hình phẳng giới hạn bởi đồ thị và trục hoành theo các tích phân của $f$.
>
> b) Tính $\int_{-3}^4 f(x)\,dx$.

> [!goi-y] Gợi ý 1
> Phần dưới trục: $\int_1^4 f(x)\,dx<0$ và bằng **trừ** diện tích.

> [!goi-y] Gợi ý 2
> $\int_{-3}^4 f=\int_{-3}^1 f+\int_1^4 f$.

> [!loi-giai] Lời giải
> a) $S=\int_{-3}^1 f(x)\,dx-\int_1^4 f(x)\,dx$.
>
> b) $\int_{-3}^1 f\,dx=6$, $\int_1^4 f\,dx=-4$, nên $\int_{-3}^4 f(x)\,dx=6+(-4)=2$ (khác với diện tích $S=10$).

### Dạng 2. Hình phẳng giới hạn bởi nhiều đường

- **Nhận biết:** đề cho ba đường trở lên, ví dụ một đường cong, một đường thẳng và trục hoành; không có $x=a$, $x=b$.
- **Phương pháp:** phác hình → tìm **tất cả** các giao điểm đôi một → xem "đường trên" và "đường dưới" có thay đổi không. Nếu đường trên (hoặc dưới) đổi ở một hoành độ $c$ thì tách thành hai tích phân tại $c$.
- **Bẫy:** dùng một tích phân duy nhất $\int\lvert f-g\rvert$ mà quên trục hoành cũng là một biên.

> [!vi-du] Ví dụ 10
> Tính diện tích hình phẳng giới hạn bởi đồ thị $y=\sqrt x$, đường thẳng $y=2-x$ và trục hoành.

> [!goi-y] Gợi ý 1
> Giao điểm: $\sqrt x=2-x\iff x=1$ (điểm $(1;1)$); $\sqrt x$ cắt $Ox$ tại $x=0$; đường thẳng cắt $Ox$ tại $x=2$.

> [!goi-y] Gợi ý 2
> Biên dưới luôn là $Ox$. Biên trên: từ $0$ đến $1$ là $y=\sqrt x$, từ $1$ đến $2$ là $y=2-x$.

> [!loi-giai] Lời giải
> $$S=\int_0^1\sqrt x\,dx+\int_1^2(2-x)\,dx.$$
> $\int_0^1 x^{\frac12}dx=\frac23x^{\frac32}\Big|_0^1=\frac23$; $\int_1^2(2-x)\,dx=\frac12$ (tam giác vuông cạnh $1$, $1$).
> Vậy $S=\frac23+\frac12=\frac76$.

### Dạng 3. Thể tích khối tròn xoay (kể cả miền giữa hai đồ thị)

- **Nhận biết:** "quay hình phẳng… quanh trục $Ox$". Nếu hình phẳng nằm **giữa hai đồ thị** $0\le g(x)\le f(x)$ thì khối có "lỗ rỗng" ở giữa.
- **Phương pháp (mở rộng, ngoài SGK):** với điều kiện $0\le g(x)\le f(x)$ trên $[a;b]$, mặt cắt là **hình vành khăn** (hình tròn lớn bán kính $f$ bỏ đi hình tròn nhỏ bán kính $g$), diện tích $\pi f^2-\pi g^2$. Theo công thức $V=\int_a^b S(x)\,dx$ của SGK, ta được
$$V=\pi\int_a^b\big[f^2(x)-g^2(x)\big]dx.$$
Đây cũng chính là **hiệu thể tích** hai khối tròn xoay do $y=f(x)$ và $y=g(x)$ sinh ra — cách nghĩ này chỉ dùng công thức trong SGK.
- **Bẫy:** viết $\pi\int_a^b\big[f(x)-g(x)\big]^2dx$ — sai, vì $(f-g)^2\ne f^2-g^2$. Công thức vành khăn chỉ dùng khi miền nằm **hẳn một phía** trục $Ox$ và không chứa trục $Ox$ bên trong; nếu miền nằm dưới trục ($f\le g\le0$) thì đổi vai trò: bán kính ngoài là $\lvert f\rvert$, trong là $\lvert g\rvert$.

> [!vi-du] Ví dụ 11
> Hình phẳng giới hạn bởi parabol $y=x^2$ và đường thẳng $y=2x$ quay quanh trục $Ox$. Tính thể tích khối tròn xoay tạo thành.

> [!goi-y] Gợi ý 1
> Giao điểm: $x^2=2x\iff x=0$ hoặc $x=2$. Trên $[0;2]$, $2x\ge x^2\ge0$.

> [!goi-y] Gợi ý 2
> Bán kính ngoài $2x$, bán kính trong $x^2$. $V=\pi\int_0^2(4x^2-x^4)\,dx$.

> [!loi-giai] Lời giải
> $$\begin{aligned}V&=\pi\left(\frac{4x^3}{3}-\frac{x^5}{5}\right)\Bigg|_0^2\\&=\pi\left(\frac{32}{3}-\frac{32}{5}\right)=\frac{64\pi}{15}.\end{aligned}$$
> (Nếu dùng nhầm $\pi\int_0^2(2x-x^2)^2dx$ sẽ ra $\frac{16\pi}{15}$ — một phương án nhiễu quen thuộc.)

### Dạng 4. Bài toán thực tế (thường là Đúng–Sai hoặc trả lời ngắn)

- **Nhận biết:** cổng/vòm/cửa sổ hình parabol, đường hầm, bồn chứa, bình hoa, chi tiết máy, mặt cắt sông…
- **Phương pháp:** (1) **chọn hệ trục** khéo (thường đặt đỉnh parabol trên $Oy$, hoặc trục đối xứng của bình trùng $Ox$); (2) viết phương trình đường biên từ các số đo đã cho; (3) dùng công thức diện tích/thể tích; (4) đổi đơn vị, làm tròn ở **bước cuối**.
- **Mẹo (ngoài SGK, chỉ để kiểm tra):** diện tích hình parabol (giới hạn bởi parabol và dây cung vuông góc trục đối xứng) $=\frac23\times\text{đáy}\times\text{cao}$.
- **Bẫy:** quên đổi m³ sang lít ($1\text{ m}^3=1000$ lít); làm tròn sớm.

> [!vi-du] Ví dụ 12
> Một cổng có dạng parabol, chân cổng rộng $6$ m, đỉnh cổng cao $4{,}5$ m so với mặt đất. Người ta làm một cửa ra vào hình chữ nhật rộng $2$ m, cao $2{,}5$ m chính giữa cổng; phần còn lại của mặt cổng lắp kính với giá $1{,}2$ triệu đồng/m².
>
> a) Chọn hệ trục có $Ox$ là mặt đất, $Oy$ là trục đối xứng của cổng. Viết phương trình parabol.
>
> b) Tính số tiền lắp kính (đơn vị triệu đồng).

> [!goi-y] Gợi ý 1
> Parabol có đỉnh $(0;\,4{,}5)$ và đi qua $(\pm3;\,0)$, dạng $y=4{,}5-kx^2$.

> [!goi-y] Gợi ý 2
> Diện tích mặt cổng $=\int_{-3}^3 y\,dx$; trừ đi diện tích cửa $2\cdot2{,}5$.

> [!loi-giai] Lời giải
> a) $0=4{,}5-9k\Rightarrow k=\frac12$, vậy $y=4{,}5-\frac{x^2}{2}$.
>
> b) Diện tích mặt cổng:
> $$\begin{aligned}&\int_{-3}^3\left(4{,}5-\frac{x^2}{2}\right)dx\\&=\left(4{,}5x-\frac{x^3}{6}\right)\Bigg|_{-3}^3=18\ (\text{m}^2).\end{aligned}$$
> (Kiểm tra bằng mẹo: $\frac23\cdot6\cdot4{,}5=18$ ✓.) Diện tích kính: $18-5=13$ m². Số tiền: $13\cdot1{,}2=15{,}6$ triệu đồng.

## Tóm tắt

| Bài toán | Công thức | Lưu ý |
|---|---|---|
| Diện tích dưới đồ thị ${y=f(x)}$ | ${S=\int_a^b\lvert f(x)\rvert\,dx}$ | chia đoạn tại nghiệm của ${f(x)=0}$ trong $(a;b)$ |
| Giữa hai đồ thị | ${S=\int_a^b\lvert f(x)-g(x)\rvert\,dx}$ | không cho $a$, $b$ → lấy nghiệm của $f=g$ |
| Không đổi dấu | ${S=\left\lvert\int_a^b(f-g)\,dx\right\rvert}$ | chỉ khi không có nghiệm bên trong |
| Thể tích theo mặt cắt | ${V=\int_a^b S(x)\,dx}$ | không có $\pi$ |
| Khối tròn xoay quanh $Ox$ | ${V=\pi\int_a^b f^2(x)\,dx}$ | có $\pi$, có bình phương |
| Quay miền giữa $0\le g\le f$ | ${V=\pi\int_a^b(f^2-g^2)\,dx}$ | không phải $\pi\int(f-g)^2$ |
| Parabol và dây cung | ${S=\frac23\cdot\text{đáy}\cdot\text{cao}}$ | mẹo kiểm tra nhanh |

**Sơ đồ khi gặp đề:** *diện tích* → tìm giao điểm → chia đoạn → "trên trừ dưới" → cộng trị tuyệt đối. *Thể tích* → mặt cắt là hình gì? Hình tròn → $\pi f^2$; vành khăn → $\pi(f^2-g^2)$; hình khác → tự tính $S(x)$ rồi lấy $\int S(x)\,dx$. *Thực tế* → chọn trục, viết phương trình biên, tính, đổi đơn vị, làm tròn cuối cùng.
