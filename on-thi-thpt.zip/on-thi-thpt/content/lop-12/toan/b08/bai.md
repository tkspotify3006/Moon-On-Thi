---
title: Biểu thức tọa độ của các phép toán vectơ
thoi-gian: 45 phút
muc-tieu:
  - Tính được tọa độ của tổng, hiệu hai vectơ và tích của một số với một vectơ trong không gian Oxyz
  - Nhận biết hai vectơ cùng phương, ba điểm thẳng hàng bằng tọa độ
  - Tìm tọa độ trung điểm đoạn thẳng, trọng tâm tam giác, đỉnh thứ tư của hình bình hành
  - Tính tích vô hướng bằng tọa độ; từ đó tính độ dài, khoảng cách hai điểm, góc giữa hai vectơ và kiểm tra hai vectơ vuông góc
  - Vận dụng tọa độ vectơ vào bài toán thực tế (chuyển động thẳng đều, dây cáp, lực, camera…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Cộng, trừ, nhân số với vectơ: **làm riêng từng tọa độ** — $\vec a\pm\vec b=(x\pm x';\,y\pm y';\,z\pm z')$, $k\vec a=(kx;\,ky;\,kz)$.
> 2. Trung điểm = **trung bình cộng** tọa độ 2 đầu mút; trọng tâm = **trung bình cộng** tọa độ 3 đỉnh.
> 3. Tích vô hướng: **nhân cặp tương ứng rồi cộng** — $\vec a\cdot\vec b=xx'+yy'+zz'$ (ra một **số**, không phải vectơ).
> 4. Độ dài $\lvert\vec a\rvert=\sqrt{x^2+y^2+z^2}$; khoảng cách $AB=\sqrt{(x_B-x_A)^2+(y_B-y_A)^2+(z_B-z_A)^2}$.
> 5. $\cos(\vec a,\vec b)=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$; vuông góc $\Leftrightarrow \vec a\cdot\vec b=0$.

Ở Bài 7, em đã biết gắn cho mỗi điểm, mỗi vectơ một bộ ba số $(x;\,y;\,z)$. Bài này trả lời câu hỏi tiếp theo: **khi đã có tọa độ, ta làm phép toán vectơ thế nào cho nhanh?** Câu trả lời rất "dễ chịu": mọi phép toán vectơ quy về cộng, trừ, nhân các con số. Nhờ vậy, những bài hình không gian khó vẽ (tính góc, chứng minh vuông góc, tìm điểm…) trở thành bài **tính toán**.

> [!nen-tang] Nhắc lại Bài 7
> - Hệ tọa độ $Oxyz$ có ba vectơ đơn vị $\vec i=(1;0;0)$, $\vec j=(0;1;0)$, $\vec k=(0;0;1)$, đôi một vuông góc.
> - $\vec a=(x;\,y;\,z)\Leftrightarrow \vec a=x\vec i+y\vec j+z\vec k$.
> - Điểm $M(x;\,y;\,z)\Leftrightarrow \overrightarrow{OM}=(x;\,y;\,z)$.
> - $\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$ — **"cuối trừ đầu"**.
> - Hai vectơ bằng nhau $\Leftrightarrow$ ba tọa độ tương ứng bằng nhau.

## 1. Tọa độ của tổng, hiệu hai vectơ và tích của một số với một vectơ

### 1.1. Công thức — và vì sao lại "làm riêng từng tọa độ"

Cho $\vec a=(x;\,y;\,z)$ và $\vec b=(x';\,y';\,z')$. Viết theo $\vec i,\vec j,\vec k$:

$$\begin{aligned}\vec a+\vec b&=(x\vec i+y\vec j+z\vec k)+(x'\vec i+y'\vec j+z'\vec k)\\&=(x+x')\vec i+(y+y')\vec j+(z+z')\vec k.\end{aligned}$$

Ta chỉ việc **gom các số đứng trước cùng một vectơ đơn vị** — giống như gom "hạng tử đồng dạng" trong đại số. Trừ và nhân với số cũng vậy. Kết quả:

> [!ghi-nho] Công thức (SGK tr. 67)
> Với $\vec a=(x;\,y;\,z)$, $\vec b=(x';\,y';\,z')$ và số thực $k$:
> $$\begin{aligned}\vec a+\vec b&=(x+x';\,y+y';\,z+z')\\ \vec a-\vec b&=(x-x';\,y-y';\,z-z')\\ k\vec a&=(kx;\,ky;\,kz)\end{aligned}$$
> Đặc biệt, vectơ đối: $-\vec a=(-x;\,-y;\,-z)$.

Hình dung trực quan: đi theo $\vec a$ rồi đi tiếp theo $\vec b$ thì quãng dịch chuyển theo **hướng Ox** là $x+x'$, theo **hướng Oy** là $y+y'$, theo **hướng Oz** là $z+z'$ — ba hướng độc lập, không "lẫn" vào nhau.

> [!vi-du] Ví dụ 1
> Cho $\vec a=(3;\,-1;\,2)$ và $\vec b=(1;\,4;\,-2)$. Tìm tọa độ của $\vec a+\vec b$, $\vec a-\vec b$ và $2\vec a-3\vec b$.

> [!goi-y] Gợi ý 1
> Làm riêng từng tọa độ. Với $2\vec a-3\vec b$: tính $2\vec a$ và $3\vec b$ trước, rồi trừ.

> [!goi-y] Gợi ý 2
> Cẩn thận dấu: $-1-4=-5$; $-1\cdot 2-4\cdot 3=-2-12$.

> [!loi-giai] Lời giải
> - $\vec a+\vec b=(3+1;\,-1+4;\,2-2)=(4;\,3;\,0)$.
> - $\vec a-\vec b=(3-1;\,-1-4;\,2-(-2))=(2;\,-5;\,4)$.
> - $2\vec a=(6;\,-2;\,4)$, $3\vec b=(3;\,12;\,-6)$ nên $2\vec a-3\vec b=(6-3;\,-2-12;\,4+6)=(3;\,-14;\,10)$.

> [!bay]
> Trừ một số âm: $2-(-2)=4$, **không phải** $0$. Phần lớn lỗi sai ở dạng này là lỗi dấu — viết rõ từng phép tính trong ngoặc trước khi bấm máy.

### 1.2. Hai vectơ cùng phương — ba điểm thẳng hàng

Ở lớp 11 (và Bài 6), $\vec a$ cùng phương với $\vec b\ne\vec 0$ khi và chỉ khi có số $k$ để $\vec a=k\vec b$. Viết bằng tọa độ:

$\vec a$ cùng phương với $\vec b$ ($\vec b\ne\vec 0$) khi và chỉ khi có số $k$ sao cho

$$x=kx',\quad y=ky',\quad z=kz'.$$

Nói gọn: **ba tọa độ tỉ lệ với nhau theo cùng một hệ số $k$**. Khi các tọa độ của $\vec b$ đều khác $0$, có thể viết $\dfrac{x}{x'}=\dfrac{y}{y'}=\dfrac{z}{z'}$.

Ứng dụng quan trọng: **$A,B,C$ thẳng hàng $\iff \overrightarrow{AB}$ và $\overrightarrow{AC}$ cùng phương.**

> [!vi-du] Ví dụ 2
> a) Tìm $m,n$ để $\vec a=(2;\,-3;\,m)$ cùng phương với $\vec b=(-4;\,n;\,2)$.
>
> b) Ba điểm $A(1;\,2;\,-1)$, $B(2;\,-1;\,3)$, $C(4;\,-7;\,11)$ có thẳng hàng không?

> [!goi-y] Gợi ý 1
> a) Tọa độ thứ nhất của cả hai vectơ đều đã biết số → dùng nó để tìm $k$ trước.

> [!goi-y] Gợi ý 2
> b) Tính $\overrightarrow{AB}$, $\overrightarrow{AC}$ rồi xem có phải $\overrightarrow{AC}=k\overrightarrow{AB}$ không.

> [!loi-giai] Lời giải
> a) $\vec a=k\vec b$: từ $2=k\cdot(-4)$ ta được $k=-\dfrac12$. Khi đó $-3=-\dfrac12 n\Rightarrow n=6$ và $m=-\dfrac12\cdot 2=-1$. Vậy $m=-1$, $n=6$.
>
> b) $\overrightarrow{AB}=(1;\,-3;\,4)$, $\overrightarrow{AC}=(3;\,-9;\,12)=3\overrightarrow{AB}$. Hai vectơ cùng phương, chung điểm $A$ nên $A,B,C$ **thẳng hàng**.

> [!bay]
> Đừng dùng "tỉ số" khi có tọa độ bằng $0$. Ví dụ $\vec a=(0;\,2;\,4)$ và $\vec b=(1;\,1;\,2)$: nếu chỉ so $\frac{2}{1}$ và $\frac{4}{2}$ thì tưởng cùng phương, nhưng $0=k\cdot 1$ buộc $k=0$, mâu thuẫn — **không** cùng phương. Hãy luôn kiểm tra đủ **cả ba** tọa độ với **cùng một** $k$.

### 1.3. Trung điểm, trọng tâm, đỉnh hình bình hành

Vì sao trung điểm là "trung bình cộng"? Với $M$ là trung điểm $AB$ thì $\overrightarrow{OM}=\dfrac12\big(\overrightarrow{OA}+\overrightarrow{OB}\big)$; tọa độ của $\overrightarrow{OA}$, $\overrightarrow{OB}$ chính là tọa độ của $A$, $B$. Với trọng tâm $G$ của tam giác $ABC$: $\overrightarrow{OG}=\dfrac13\big(\overrightarrow{OA}+\overrightarrow{OB}+\overrightarrow{OC}\big)$. Áp dụng 1.1 là ra ngay.

> [!ghi-nho] Công thức (SGK tr. 68)
> - Trung điểm $M$ của $AB$: $M\left(\dfrac{x_A+x_B}{2};\,\dfrac{y_A+y_B}{2};\,\dfrac{z_A+z_B}{2}\right)$.
> - Trọng tâm $G$ của tam giác $ABC$:
>
> $$G\left(\dfrac{x_A+x_B+x_C}{3};\,\dfrac{y_A+y_B+y_C}{3};\,\dfrac{z_A+z_B+z_C}{3}\right)$$

![Hình 1. Trung điểm M và trọng tâm G: tọa độ là trung bình cộng tọa độ các đầu mút / các đỉnh](h1-trung-diem-trong-tam.svg)

> [!vi-du] Ví dụ 3
> Cho $A(2;\,-1;\,3)$, $B(4;\,3;\,-1)$, $C(-3;\,1;\,4)$.
>
> a) Tìm tọa độ trung điểm $M$ của $AB$ và trọng tâm $G$ của tam giác $ABC$.
>
> b) (Bài toán ngược) Cho thêm $G'(1;\,0;\,2)$. Tìm điểm $C'$ để tam giác $ABC'$ có trọng tâm $G'$.

> [!goi-y] Gợi ý 1
> a) Cộng tọa độ rồi chia 2 (trung điểm), chia 3 (trọng tâm).

> [!goi-y] Gợi ý 2
> b) Từ công thức trọng tâm: $x_A+x_B+x_{C'}=3x_{G'}$, suy ra $x_{C'}=3x_{G'}-x_A-x_B$. Tương tự cho $y$, $z$.

> [!loi-giai] Lời giải
> a) $M\left(\frac{2+4}{2};\,\frac{-1+3}{2};\,\frac{3-1}{2}\right)=(3;\,1;\,1)$.
> $G\left(\frac{2+4-3}{3};\,\frac{-1+3+1}{3};\,\frac{3-1+4}{3}\right)=(1;\,1;\,2)$.
>
> b) $C'=(3\cdot1-2-4;\ 3\cdot0+1-3;\ 3\cdot2-3+1)=(-3;\,-2;\,4)$.

**Đỉnh thứ tư của hình bình hành.** $ABCD$ là hình bình hành $\iff \overrightarrow{AB}=\overrightarrow{DC}$. Viết theo tọa độ: $B-A=C-D$, tức là

$$\boxed{A+C=B+D}$$

Nghĩa là: tổng tọa độ của hai đỉnh đối diện này bằng tổng tọa độ của hai đỉnh đối diện kia. Điều này cũng chính là "hai đường chéo $AC$, $BD$ có chung trung điểm". Từ đó $D=A+C-B$ (cộng, trừ theo từng tọa độ).

![Hình 2. Hình bình hành ABCD: hai đường chéo có chung trung điểm I, nên A + C = B + D](h2-hinh-binh-hanh.svg)

> [!vi-du] Ví dụ 4
> Cho $A(1;\,0;\,2)$, $B(3;\,-1;\,4)$, $C(2;\,3;\,-1)$. Tìm $D$ để $ABCD$ là hình bình hành và tìm tâm $I$ của nó.

> [!goi-y] Gợi ý 1
> Thứ tự đỉnh là $A\to B\to C\to D$: đỉnh đối diện của $A$ là $C$, của $B$ là $D$.

> [!goi-y] Gợi ý 2
> $D=A+C-B$; tâm $I$ là trung điểm $AC$.

> [!loi-giai] Lời giải
> $D=(1+2-3;\ 0+3-(-1);\ 2+(-1)-4)=(0;\,4;\,-3)$.
> Kiểm tra: $\overrightarrow{AB}=(2;\,-1;\,2)$ và $\overrightarrow{DC}=(2;\,-1;\,2)$ — bằng nhau ✓.
> Tâm $I$ là trung điểm $AC$: $I\left(\frac32;\,\frac32;\,\frac12\right)$.

> [!bay] Thứ tự đỉnh
> "Hình bình hành $ABCD$" và "hình bình hành $ABDC$" là **khác nhau**. Với $ABDC$ thì $A$ đối diện $D$, nên $D=B+C-A$. Đề thi rất hay đặt phương án nhiễu là đáp số của thứ tự đỉnh sai. Nếu đề chỉ nói "bốn điểm $A,B,C,D$ là bốn đỉnh của một hình bình hành" thì có **ba** khả năng cho $D$.

> [!meo] Bấm máy Casio fx-580VN X
> Vào **MENU → 5 (Vectơ)**, khai báo VctA, VctB, VctC là 3 vectơ tọa độ của $A,B,C$ (chọn kích thước 3). Ở màn hình tính, gõ VctA + VctC − VctB rồi **=** là ra ngay tọa độ $D$. Cách này cũng dùng tốt cho trọng tâm: (VctA + VctB + VctC) ÷ 3.

## 2. Biểu thức tọa độ của tích vô hướng

> [!nen-tang] Tích vô hướng (Bài 6)
> $\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b)$. Hệ quả: $\vec a\cdot\vec a=\lvert\vec a\rvert^2$; $\vec a\perp\vec b\iff \vec a\cdot\vec b=0$. Tích vô hướng có tính giao hoán, phân phối với phép cộng.

### 2.1. Công thức tích vô hướng

Vì $\vec i,\vec j,\vec k$ dài $1$ và đôi một vuông góc nên
$$\vec i\cdot\vec i=\vec j\cdot\vec j=\vec k\cdot\vec k=1,$$
$$\vec i\cdot\vec j=\vec j\cdot\vec k=\vec k\cdot\vec i=0.$$

Nhân $\vec a=x\vec i+y\vec j+z\vec k$ với $\vec b=x'\vec i+y'\vec j+z'\vec k$ (khai triển như nhân hai đa thức) sẽ có 9 số hạng, nhưng **6 số hạng "chéo" bằng 0**, chỉ còn 3 số hạng "cùng tên":

> [!ghi-nho] Công thức (SGK tr. 69)
> $$\vec a\cdot\vec b=xx'+yy'+zz'.$$
> Hệ quả:
> - $\vec a\perp\vec b\iff xx'+yy'+zz'=0$.
> - $\lvert\vec a\rvert=\sqrt{\vec a\cdot\vec a}=\sqrt{x^2+y^2+z^2}$.
> - Với $\vec a,\vec b\ne\vec 0$: $\cos(\vec a,\vec b)=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$, tức là
>
> $$\cos(\vec a,\vec b)=\dfrac{xx'+yy'+zz'}{\sqrt{x^2+y^2+z^2}\,\sqrt{x'^2+y'^2+z'^2}}$$

**Dấu của tích vô hướng cho biết ngay loại góc** (vì mẫu số luôn dương):

![Hình 3. Dấu của tích vô hướng quyết định góc giữa hai vectơ là nhọn, vuông hay tù](h3-dau-tich-vo-huong.svg)

> [!vi-du] Ví dụ 5
> a) Cho $\vec a=(2;\,-1;\,3)$ và $\vec b=(1;\,4;\,-2)$. Tính $\vec a\cdot\vec b$, $\lvert\vec a\rvert$, $\lvert\vec b\rvert$ và góc $(\vec a,\vec b)$ (làm tròn đến hàng phần mười của độ).
>
> b) Tìm $m$ để $\vec u=(m;\,2;\,-1)$ vuông góc với $\vec v=(3;\,m;\,4)$.

> [!goi-y] Gợi ý 1
> a) Nhân cặp tương ứng rồi cộng: $2\cdot1+(-1)\cdot4+3\cdot(-2)$. Trước khi tính $\cos$, nhìn dấu tích vô hướng để đoán góc nhọn hay tù.

> [!goi-y] Gợi ý 2
> b) Vuông góc $\iff$ tích vô hướng bằng $0$ → được phương trình bậc nhất theo $m$.

> [!loi-giai] Lời giải
> a) $\vec a\cdot\vec b=2-4-6=-8<0$ → góc tù.
> $\lvert\vec a\rvert=\sqrt{4+1+9}=\sqrt{14}$, $\lvert\vec b\rvert=\sqrt{1+16+4}=\sqrt{21}$.
> $\cos(\vec a,\vec b)=\dfrac{-8}{\sqrt{14}\cdot\sqrt{21}}=\dfrac{-8}{7\sqrt6}\approx-0{,}4666$, suy ra $(\vec a,\vec b)\approx117{,}8^\circ$.
>
> b) $\vec u\cdot\vec v=3m+2m-4=5m-4=0\iff m=\dfrac45$.

> [!bay] Ba lỗi kinh điển
> 1. Viết $\vec a\cdot\vec b=(2;\,-4;\,-6)$ — **sai**: tích vô hướng là **một số**, phải cộng ba tích lại.
> 2. Tính $\lvert\vec a\rvert=\sqrt{2-1+3}$ — quên bình phương; bình phương số âm luôn dương: $(-1)^2=1$.
> 3. $(\vec a+\vec b)^2$ là **số** $\lvert\vec a+\vec b\rvert^2$: tính tọa độ $\vec a+\vec b$ trước, rồi cộng bình phương các tọa độ.

### 2.2. Khoảng cách giữa hai điểm — góc trong tam giác

Độ dài đoạn $AB$ là độ dài vectơ $\overrightarrow{AB}$:

$$AB=\sqrt{(x_B-x_A)^2+(y_B-y_A)^2+(z_B-z_A)^2}.$$

Đây chính là định lí Pythagore "hai lần": đi theo đáy (theo $x$ và $y$) rồi đi lên (theo $z$). Riêng $OA=\sqrt{x_A^2+y_A^2+z_A^2}$.

Muốn tính **góc $\widehat{BAC}$ của tam giác**, dùng hai vectơ **cùng xuất phát từ đỉnh $A$**: $\cos\widehat{BAC}=\cos\big(\overrightarrow{AB},\overrightarrow{AC}\big)$.

> [!vi-du] Ví dụ 6
> Cho $A(1;\,0;\,1)$, $B(2;\,2;\,3)$, $C(3;\,-1;\,1)$.
>
> a) Chứng minh tam giác $ABC$ vuông tại $A$.
>
> b) Tính chu vi và diện tích tam giác $ABC$.
>
> c) Tính góc $\widehat{ABC}$ (làm tròn đến hàng phần mười của độ).

> [!goi-y] Gợi ý 1
> a) Vuông tại $A$ $\iff \overrightarrow{AB}\cdot\overrightarrow{AC}=0$.

> [!goi-y] Gợi ý 2
> b) Tam giác vuông tại $A$ thì diện tích $=\frac12 AB\cdot AC$. c) Góc tại $B$ → dùng $\overrightarrow{BA}$ và $\overrightarrow{BC}$.

> [!loi-giai] Lời giải
> a) $\overrightarrow{AB}=(1;\,2;\,2)$, $\overrightarrow{AC}=(2;\,-1;\,0)$, $\overrightarrow{AB}\cdot\overrightarrow{AC}=2-2+0=0$ → $AB\perp AC$, tam giác vuông tại $A$.
>
> b) $AB=\sqrt{1+4+4}=3$, $AC=\sqrt{4+1+0}=\sqrt5$, $\overrightarrow{BC}=(1;\,-3;\,-2)$ nên $BC=\sqrt{14}$ (kiểm tra: $9+5=14$ ✓).
> Chu vi $=3+\sqrt5+\sqrt{14}\approx8{,}98$; diện tích $S=\frac12\cdot3\cdot\sqrt5=\frac{3\sqrt5}{2}\approx3{,}35$.
>
> c) $\overrightarrow{BA}=(-1;\,-2;\,-2)$, $\overrightarrow{BC}=(1;\,-3;\,-2)$, $\overrightarrow{BA}\cdot\overrightarrow{BC}=-1+6+4=9$.
> $\cos\widehat{ABC}=\dfrac{9}{3\sqrt{14}}=\dfrac{3}{\sqrt{14}}\approx0{,}8018$ → $\widehat{ABC}\approx36{,}7^\circ$.

> [!bay] Góc tại đỉnh nào thì vectơ xuất phát từ đỉnh đó
> Nếu dùng $\overrightarrow{AB}$ và $\overrightarrow{BC}$ (một vectơ "đi vào" $B$, một vectơ "đi ra" khỏi $B$) để tính góc $B$, em sẽ được góc **bù** $180^\circ-36{,}7^\circ=143{,}3^\circ$ — một phương án nhiễu rất hay gặp.

> [!meo] Kiểm tra nhanh bằng máy tính
> Trong chế độ Vectơ của fx-580VN X: **Abs(VctA)** cho độ dài, mục **tích vô hướng** (Dot) trong OPTN cho $\vec a\cdot\vec b$. Có tích vô hướng và hai độ dài rồi thì bấm $\cos^{-1}\!\left(\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\,\lvert\vec b\rvert}\right)$ ở chế độ **độ (D)** là ra góc. Dùng để **soát lại** kết quả, còn khi làm bài vẫn nên viết đủ công thức.

## 3. Vận dụng tọa độ vectơ vào bài toán thực tiễn

Bí quyết chung cho mọi bài thực tế: **(1) chọn (hoặc đọc) hệ trục, (2) viết tọa độ các điểm quan trọng, (3) dịch câu hỏi thành phép toán vectơ** — "dịch chuyển" là vectơ, "khoảng cách" là độ dài, "góc" là $\cos$ qua tích vô hướng.

### 3.1. Chuyển động thẳng đều

Vật đi thẳng với vận tốc không đổi thì **vectơ dịch chuyển tỉ lệ với thời gian**: đi được $\overrightarrow{AB}$ trong $t_1$ thì trong $t_2$ tiếp theo đi được $\dfrac{t_2}{t_1}\overrightarrow{AB}$ (cùng hướng).

> [!vi-du] Ví dụ 7
> Một flycam bay thẳng với vận tốc không đổi. Trong hệ tọa độ có đơn vị mét, lúc 8 giờ 00 phút nó ở $A(0;\,0;\,50)$, lúc 8 giờ 02 phút nó ở $B(120;\,160;\,80)$.
>
> a) Tìm vị trí $C$ của flycam lúc 8 giờ 05 phút.
>
> b) Tính tốc độ của flycam (m/phút, làm tròn đến hàng đơn vị).

> [!goi-y] Gợi ý 1
> Từ $B$ đến $C$ mất 3 phút, từ $A$ đến $B$ mất 2 phút → $\overrightarrow{BC}=\dfrac32\overrightarrow{AB}$.

> [!goi-y] Gợi ý 2
> Tốc độ = quãng đường $AB$ chia cho 2 phút.

> [!loi-giai] Lời giải
> a) $\overrightarrow{AB}=(120;\,160;\,30)$, $\overrightarrow{BC}=\frac32\overrightarrow{AB}=(180;\,240;\,45)$.
> Gọi $C(x;\,y;\,z)$: $x-120=180$, $y-160=240$, $z-80=45$ → $C(300;\,400;\,125)$.
>
> b) $AB=\sqrt{120^2+160^2+30^2}=\sqrt{40\,900}\approx202{,}24$ (m). Tốc độ $\approx\dfrac{202{,}24}{2}\approx101$ m/phút.

### 3.2. Độ dài dây cáp và góc giữa hai dây

> [!vi-du] Ví dụ 8
> Một cột ăng-ten thẳng đứng cao 12 m, chân cột đặt tại gốc $O$. Chọn hệ $Oxyz$ (đơn vị mét) với mặt đất là $(Oxy)$ và $Oz$ hướng lên. Đỉnh cột $S$ được giữ bởi hai dây cáp căng thẳng, neo xuống đất tại $A(5;\,0;\,0)$ và $B(0;\,9;\,0)$.
>
> a) Tính độ dài mỗi dây cáp.
>
> b) Tính góc giữa hai dây cáp tại đỉnh cột (làm tròn đến hàng đơn vị của độ).

![Hình 4. Cột ăng-ten OS và hai dây cáp SA, SB trong hệ Oxyz](h4-cot-ang-ten.svg)

> [!goi-y] Gợi ý 1
> Đỉnh cột: $S(0;\,0;\,12)$. Độ dài dây $SA$ là $\lvert\overrightarrow{SA}\rvert$.

> [!goi-y] Gợi ý 2
> Góc giữa hai dây tại $S$ là góc giữa $\overrightarrow{SA}$ và $\overrightarrow{SB}$ (cùng xuất phát từ $S$).

> [!loi-giai] Lời giải
> a) $\overrightarrow{SA}=(5;\,0;\,-12)$ → $SA=\sqrt{25+144}=13$ m; $\overrightarrow{SB}=(0;\,9;\,-12)$ → $SB=\sqrt{81+144}=15$ m.
>
> b) $\overrightarrow{SA}\cdot\overrightarrow{SB}=0+0+144=144$, nên $\cos\widehat{ASB}=\dfrac{144}{13\cdot15}=\dfrac{48}{65}\approx0{,}7385$ → $\widehat{ASB}\approx42^\circ$.

> [!ung-dung] Công của một lực
> Trong Vật lí, lực $\vec F$ (N) làm vật dời theo vectơ $\vec d$ (m) thì công $A=\vec F\cdot\vec d$ (J) — chính là **tích vô hướng**! Ví dụ (trục $Oz$ thẳng đứng, sàn là $(Oxy)$) lực $\vec F=(30;\,40;\,20)$ kéo thùng hàng trượt trên sàn từ $O(0;0;0)$ tới $(5;\,2;\,0)$ thì $A=30\cdot5+40\cdot2+20\cdot0=230$ J. Phần lực theo phương thẳng đứng ($20$ N) không sinh công vì vật không dịch chuyển theo phương đó. Còn **hợp lực** của nhiều lực là **tổng** các vectơ lực — cộng theo từng tọa độ.

> [!em-co-biet]
> Ngoài tích vô hướng (cho ra một số), Toán học còn có **tích có hướng** $[\vec a,\vec b]$ cho ra một **vectơ** vuông góc với cả $\vec a$ và $\vec b$; nó dùng để tính diện tích, thể tích và lập phương trình mặt phẳng. SGK Toán 12 Kết nối tri thức không học tích có hướng trong bài này; em sẽ gặp ý tưởng "vectơ vuông góc với hai vectơ" ở chương Phương trình mặt phẳng (Tập hai).

## Dạng bài thi hay gặp

### Dạng 1. Tìm tọa độ điểm thỏa một đẳng thức vectơ

- **Nhận biết:** đề cho hình bình hành, trọng tâm, hoặc đẳng thức như $\overrightarrow{MA}+2\overrightarrow{MB}=\vec 0$, $\overrightarrow{AB}+\overrightarrow{CM}=\vec 0$.
- **Phương pháp:** gọi $M(x;\,y;\,z)$ → viết mỗi vectơ theo tọa độ → cho **từng tọa độ** hai vế bằng nhau → giải 3 phương trình bậc nhất.
- **Bẫy:** viết ngược chiều vectơ ($\overrightarrow{MA}=A-M$ chứ không phải $M-A$); thứ tự đỉnh hình bình hành.

> [!vi-du] Ví dụ 9
> Cho $A(1;\,-2;\,3)$, $B(4;\,1;\,0)$. Tìm điểm $M$ thỏa $\overrightarrow{MA}+2\overrightarrow{MB}=\vec 0$.

> [!goi-y] Gợi ý 1
> $\overrightarrow{MA}=(1-x;\,-2-y;\,3-z)$, $\overrightarrow{MB}=(4-x;\,1-y;\,-z)$.

> [!goi-y] Gợi ý 2
> Hoành độ: $(1-x)+2(4-x)=0$. Làm tương tự cho tung độ, cao độ. (Nhanh hơn: $M=\dfrac{A+2B}{3}$.)

> [!loi-giai] Lời giải
> $1-x+8-2x=0\Rightarrow x=3$; $\ -2-y+2-2y=0\Rightarrow y=0$; $\ 3-z-2z=0\Rightarrow z=1$. Vậy $M(3;\,0;\,1)$ — điểm nằm trên đoạn $AB$, gần $B$ hơn (vì $MA=2MB$).

### Dạng 2. Điểm nằm trên trục / mặt phẳng tọa độ thỏa điều kiện

- **Nhận biết:** "$M$ thuộc trục $Oz$", "$N$ thuộc mặt phẳng $(Oxy)$", kèm điều kiện vuông góc, thẳng hàng, cách đều.
- **Phương pháp:** dùng dạng tọa độ đặc biệt — trên $Ox$: $(x;0;0)$, $Oy$: $(0;y;0)$, $Oz$: $(0;0;z)$; trên $(Oxy)$: $(x;y;0)$, $(Oyz)$: $(0;y;z)$, $(Oxz)$: $(x;0;z)$ → còn 1–2 ẩn → dịch điều kiện thành phương trình.
  - Vuông góc → tích vô hướng $=0$. Thẳng hàng → hai vectơ cùng phương. Cách đều $MA=MB$ → $MA^2=MB^2$ (bình phương để khỏi căn).
- **Bẫy:** nhầm "thuộc trục $Oz$" (hai tọa độ bằng 0) với "thuộc mặt phẳng $(Oxy)$" (cao độ bằng 0).

> [!vi-du] Ví dụ 10
> Cho $A(1;\,2;\,-1)$, $B(3;\,0;\,2)$, $C(2;\,-1;\,1)$.
>
> a) Tìm $M$ thuộc trục $Oz$ sao cho $BM\perp AC$.
>
> b) Tìm $N$ thuộc mặt phẳng $(Oxy)$ sao cho $A,B,N$ thẳng hàng.

> [!goi-y] Gợi ý 1
> a) $M(0;\,0;\,t)$, điều kiện $\overrightarrow{BM}\cdot\overrightarrow{AC}=0$.

> [!goi-y] Gợi ý 2
> b) $N(x;\,y;\,0)$, điều kiện $\overrightarrow{AN}=k\overrightarrow{AB}$; cao độ cho ngay $k$.

> [!loi-giai] Lời giải
> a) $\overrightarrow{BM}=(-3;\,0;\,t-2)$, $\overrightarrow{AC}=(1;\,-3;\,2)$. $\ -3+0+2(t-2)=0\iff t=\dfrac72$. Vậy $M\left(0;\,0;\,\dfrac72\right)$.
>
> b) $\overrightarrow{AB}=(2;\,-2;\,3)$, $\overrightarrow{AN}=(x-1;\,y-2;\,1)$. Cao độ: $1=3k\Rightarrow k=\dfrac13$. Khi đó $x-1=\dfrac23\Rightarrow x=\dfrac53$; $y-2=-\dfrac23\Rightarrow y=\dfrac43$. Vậy $N\left(\dfrac53;\,\dfrac43;\,0\right)$.

### Dạng 3. Góc, độ dài có tham số

- **Nhận biết:** "tìm $m$ để góc giữa hai vectơ bằng $60^\circ$", "để $\lvert\vec u\rvert=3$", "để góc tù".
- **Phương pháp:** viết $\cos$ (hoặc độ dài) theo $m$ → lập phương trình → **bình phương hai vế khi cả hai vế cùng dấu** → đối chiếu điều kiện.
- **Bẫy:** góc tù $\iff \vec a\cdot\vec b<0$ **và** hai vectơ không ngược hướng (nếu ngược hướng thì góc bằng $180^\circ$ — đó là góc bẹt, **không** phải góc tù). Khi bình phương, nhớ thử lại dấu của $\cos$.

> [!vi-du] Ví dụ 11
> Tìm $m>0$ để góc giữa $\vec u=(1;\,1;\,0)$ và $\vec v=(1;\,0;\,m)$ bằng $60^\circ$.

> [!goi-y] Gợi ý 1
> $\vec u\cdot\vec v=1$, $\lvert\vec u\rvert=\sqrt2$, $\lvert\vec v\rvert=\sqrt{1+m^2}$.

> [!goi-y] Gợi ý 2
> Giải $\dfrac{1}{\sqrt2\cdot\sqrt{1+m^2}}=\dfrac12$.

> [!loi-giai] Lời giải
> $\sqrt{2(1+m^2)}=2\iff 2+2m^2=4\iff m^2=1$. Vì $m>0$ nên $m=1$.

### Dạng 4. Bài toán thực tế (thường là Đúng–Sai hoặc trả lời ngắn có làm tròn)

- **Nhận biết:** camera, flycam, máy bay, khinh khí cầu, đèn treo trong phòng, dây cáp, lực…
- **Phương pháp:** đọc kỹ đơn vị và hướng các trục → viết tọa độ → dùng đúng công cụ (vectơ dịch chuyển, độ dài, $\cos$). Chỉ làm tròn ở **bước cuối cùng**.
- **Bẫy:** làm tròn sớm ở giữa bài khiến đáp số lệch; nhầm góc tại đỉnh; quên đổi đơn vị (phút ↔ giờ).

> [!vi-du] Ví dụ 12
> Một phòng có sàn là mặt phẳng $(Oxy)$, $Oz$ hướng lên, đơn vị mét. Camera đặt ở $C(0;\,0;\,3)$ (góc trần) và hướng thẳng về điểm $I(4;\,3;\,0)$ trên sàn. Camera quan sát được mọi điểm $P$ sao cho góc giữa $\overrightarrow{CI}$ và $\overrightarrow{CP}$ không quá $30^\circ$.
>
> a) Tính khoảng cách từ camera đến chiếc đèn bàn ở $P(6;\,4;\,1)$ (làm tròn đến hàng phần mười).
>
> b) Camera có nhìn thấy đèn bàn $P$ không? Có nhìn thấy điểm $Q(8;\,0;\,0)$ không?

> [!goi-y] Gợi ý 1
> $\overrightarrow{CP}=(6;\,4;\,-2)$, $\overrightarrow{CI}=(4;\,3;\,-3)$.

> [!goi-y] Gợi ý 2
> Tính góc $\big(\overrightarrow{CI},\overrightarrow{CP}\big)$ và $\big(\overrightarrow{CI},\overrightarrow{CQ}\big)$ rồi so với $30^\circ$.

> [!loi-giai] Lời giải
> a) $CP=\sqrt{36+16+4}=\sqrt{56}\approx7{,}5$ m.
>
> b) $\overrightarrow{CI}\cdot\overrightarrow{CP}=24+12+6=42$, $CI=\sqrt{34}$, nên $\cos=\dfrac{42}{\sqrt{34}\cdot\sqrt{56}}\approx0{,}9625$ → góc $\approx15{,}7^\circ<30^\circ$: **nhìn thấy** $P$.
> $\overrightarrow{CQ}=(8;\,0;\,-3)$, $\overrightarrow{CI}\cdot\overrightarrow{CQ}=32+0+9=41$, $CQ=\sqrt{73}$, $\cos=\dfrac{41}{\sqrt{34}\cdot\sqrt{73}}\approx0{,}8230$ → góc $\approx34{,}6^\circ>30^\circ$: **không** nhìn thấy $Q$.

### Dạng 5. Gắn hệ trục vào hình chóp, hình hộp để tính độ dài, góc (SGK tr. 69)

- **Nhận biết:** đề cho hình chóp/hình hộp có **ba cạnh đôi một vuông góc tại một đỉnh** (ví dụ $SA\perp(ABCD)$ với $ABCD$ là hình chữ nhật, hình vuông), hỏi độ dài, vuông góc, góc giữa hai đường.
- **Phương pháp:** đặt gốc $O$ tại đỉnh có ba cạnh vuông góc, ba tia $Ox, Oy, Oz$ dọc ba cạnh đó → viết tọa độ các đỉnh (như Bài 7) → dùng tích vô hướng.
- **Bẫy:** đặt nhầm đỉnh đối diện (đỉnh $C$ của đáy có **hai** tọa độ khác 0); quên rằng góc giữa hai **đường thẳng** lấy $\lvert\cos\rvert$ (luôn $\le 90^\circ$).

> [!vi-du] Ví dụ 13 (Đúng/Sai)
> Cho hình chóp $S.ABCD$ có đáy là hình vuông cạnh 2, $SA\perp(ABCD)$ và $SA=3$. Chọn hệ $Oxyz$ có $O\equiv A$, các tia $Ox, Oy, Oz$ lần lượt chứa $B$, $D$, $S$. Xét các mệnh đề:
>
> a) $C(2;\,2;\,0)$.
>
> b) $SC=\sqrt{17}$.
>
> c) $\overrightarrow{SC}\perp\overrightarrow{BD}$.
>
> d) Góc giữa hai vectơ $\overrightarrow{SB}$ và $\overrightarrow{AC}$ bằng $60^\circ$.

> [!goi-y] Gợi ý 1
> $A(0;0;0)$, $B(2;0;0)$, $D(0;2;0)$, $S(0;0;3)$. Đỉnh $C$ có hình chiếu lên $Ox$, $Oy$ lần lượt là $B$, $D$.

> [!goi-y] Gợi ý 2
> c) và d): tính tích vô hướng rồi dùng công thức $\cos$.

> [!loi-giai] Lời giải
> a) **Đúng** — $\overrightarrow{AC}=\overrightarrow{AB}+\overrightarrow{AD}=(2;\,2;\,0)$.
>
> b) **Đúng** — $\overrightarrow{SC}=(2;\,2;\,-3)$, $SC=\sqrt{4+4+9}=\sqrt{17}$.
>
> c) **Đúng** — $\overrightarrow{BD}=(-2;\,2;\,0)$, $\overrightarrow{SC}\cdot\overrightarrow{BD}=-4+4+0=0$.
>
> d) **Sai** — $\overrightarrow{SB}=(2;\,0;\,-3)$, $\overrightarrow{SB}\cdot\overrightarrow{AC}=4$, $\cos=\dfrac{4}{\sqrt{13}\cdot2\sqrt2}\approx0{,}392$ → góc $\approx66{,}9^\circ$.

## Tóm tắt

Với $\vec a=(x;\,y;\,z)$, $\vec b=(x';\,y';\,z')$; viết "$A+B$" nghĩa là cộng tọa độ tương ứng của hai điểm.

| Nội dung | Công thức |
|---|---|
| Tổng, hiệu | $\vec a\pm\vec b=(x\pm x';\,y\pm y';\,z\pm z')$ |
| Nhân với số | $k\vec a=(kx;\,ky;\,kz)$ |
| Cùng phương ($\vec b\ne\vec 0$) | $\vec a=k\vec b$: $x=kx'$, $y=ky'$, $z=kz'$ |
| Thẳng hàng | $\overrightarrow{AB}$, $\overrightarrow{AC}$ cùng phương |
| Trung điểm $M$ của $AB$ | $M=\dfrac{A+B}{2}$ (từng tọa độ) |
| Trọng tâm $G$ của $ABC$ | $G=\dfrac{A+B+C}{3}$ (từng tọa độ) |
| Hình bình hành $ABCD$ | $A+C=B+D$, tức $D=A+C-B$ |
| Tích vô hướng | $\vec a\cdot\vec b=xx'+yy'+zz'$ |
| Vuông góc | $xx'+yy'+zz'=0$ |
| Độ dài | $\lvert\vec a\rvert=\sqrt{x^2+y^2+z^2}$ |
| Khoảng cách | $AB=\lvert\overrightarrow{AB}\rvert$ (căn của tổng bình phương các hiệu tọa độ) |
| Góc | $\cos(\vec a,\vec b)=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$ |

**Sơ đồ tư duy khi gặp đề:** đề hỏi *điểm* → gọi tọa độ, lập phương trình theo từng tọa độ; đề hỏi *độ dài/khoảng cách* → căn tổng bình phương; đề hỏi *góc / vuông góc* → tích vô hướng; đề *thực tế* → chọn trục, viết tọa độ, rồi quay về ba ý trên.
