---
title: Ứng dụng đạo hàm để giải quyết một số vấn đề liên quan đến thực tiễn
thoi-gian: 50 phút
muc-tieu:
  - Hiểu đạo hàm là tốc độ thay đổi tức thời của một đại lượng; phân biệt với tốc độ thay đổi trung bình
  - Dùng đạo hàm để tính vận tốc, gia tốc; xét khi nào vật đi lên/đi xuống, tăng tốc/giảm tốc
  - Hiểu và tính được tốc độ phản ứng, tốc độ tăng trưởng quần thể, chi phí biên, doanh thu biên, lợi nhuận biên
  - Lập hàm số cho một bài toán thực tế (hình học, quãng đường – chi phí, kinh tế) rồi khảo sát để tìm giá trị lớn nhất, nhỏ nhất
  - Lập hàm cầu, hàm doanh thu, hàm lợi nhuận và tìm giá bán tối ưu
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Tốc độ thay đổi trung bình** của $y=f(x)$ trên $[x_1;x_2]$ là $\dfrac{f(x_2)-f(x_1)}{x_2-x_1}$; **tốc độ thay đổi tức thời** tại $x_0$ là **đạo hàm** $f'(x_0)$.
> 2. Vị trí $s(t)$ → vận tốc $v(t)=s'(t)$ → gia tốc $a(t)=v'(t)=s''(t)$. Vật **tăng tốc** khi $v$ và $a$ **cùng dấu**, **giảm tốc** khi trái dấu.
> 3. Kinh tế: chi phí biên $C'(x)$, doanh thu $R(x)=x\cdot p(x)$, lợi nhuận $P(x)=R(x)-C(x)$; "biên" = đạo hàm, $C'(x)\approx C(x+1)-C(x)$.
> 4. Bài toán tối ưu: **chọn ẩn → điều kiện → lập hàm một biến → tìm GTLN/GTNN → trả lời đúng câu hỏi** (xem thêm Bài 2).
> 5. Đọc kỹ câu hỏi: hỏi **giá trị lớn nhất** của $f$ hay **tốc độ lớn nhất** (GTLN của $f'$)? hỏi $x$ hay hỏi $f(x)$? đơn vị gì, làm tròn thế nào?

Bốn bài đầu của chương đã cho em một "bộ đồ nghề" hoàn chỉnh: đạo hàm, chiều biến thiên, cực trị, giá trị lớn nhất – nhỏ nhất, tiệm cận. Bài này là lúc **mang bộ đồ nghề ra đời thật**. Có hai loại câu hỏi:

- **"Thay đổi nhanh hay chậm?"** — xe đang chạy bao nhiêu km/h, quần thể vi khuẩn tăng bao nhiêu con mỗi giờ, sản xuất thêm một sản phẩm tốn thêm bao nhiêu tiền. Câu trả lời là **đạo hàm**.
- **"Tốt nhất là bao nhiêu?"** — rào đất thế nào cho tốn ít lưới nhất, đặt giá vé bao nhiêu cho doanh thu lớn nhất. Câu trả lời là **giá trị lớn nhất, nhỏ nhất** của một hàm số do em tự lập ra.

Trong đề thi tốt nghiệp, đây là nguồn chính của các câu **trả lời ngắn** vận dụng và câu **Đúng/Sai** về một mô hình thực tế.

> [!nen-tang] Cần nhớ từ lớp 11 và Bài 1, Bài 2
> - Đạo hàm: $(x^n)'=nx^{n-1}$; $(e^{kx})'=ke^{kx}$; $(\sqrt u)'=\dfrac{u'}{2\sqrt u}$; $\left(\dfrac uv\right)'=\dfrac{u'v-uv'}{v^2}$; $\left(\dfrac{a}{v}\right)'=-\dfrac{a\,v'}{v^2}$.
> - Ý nghĩa vật lí (lớp 11): $v(t)=s'(t)$ là vận tốc tức thời, $a(t)=v'(t)$ là gia tốc tức thời.
> - $f'>0$ trên một khoảng thì $f$ đồng biến, $f'<0$ thì nghịch biến (Bài 1).
> - Trên đoạn: so sánh giá trị tại điểm tới hạn và hai đầu mút; trên khoảng: lập bảng biến thiên (Bài 2).

## 1. Tốc độ thay đổi của một đại lượng

### 1.1. Từ "trung bình" đến "tức thời"

Hãy nghĩ đến một cốc trà vừa rót. Lúc đầu trà rất nóng và nguội đi nhanh; về sau nhiệt độ gần bằng nhiệt độ phòng nên nguội rất chậm. Vậy "trà nguội nhanh cỡ nào" là câu hỏi **phụ thuộc vào thời điểm**.

Cho đại lượng $y=f(x)$. Khi $x$ thay đổi từ $x_1$ đến $x_2$, ta có độ thay đổi $\Delta x=x_2-x_1$ và $\Delta y=f(x_2)-f(x_1)$.

> [!ghi-nho] Tốc độ thay đổi (SGK tr. 33)
> - **Tốc độ thay đổi trung bình** của $y$ đối với $x$ trên đoạn $[x_1;x_2]$:
> $$\frac{\Delta y}{\Delta x}=\frac{f(x_2)-f(x_1)}{x_2-x_1}.$$
> - **Tốc độ thay đổi tức thời** của $y$ đối với $x$ tại $x_1$ là giới hạn của tỉ số trên khi $x_2\to x_1$, tức là **đạo hàm** $f'(x_1)$.

**Vì sao đạo hàm lại là "tức thời"?** Tốc độ trung bình chỉ cho biết **cả đoạn** thay đổi trung bình bao nhiêu — giống như vận tốc trung bình của cả chuyến đi. Muốn biết "ngay lúc này" thì ta thu đoạn $[x_1;x_2]$ lại thật ngắn: tỉ số $\dfrac{\Delta y}{\Delta x}$ tiến dần đến một số, và số đó chính là $f'(x_1)$. Trên đồ thị, tỉ số $\dfrac{\Delta y}{\Delta x}$ là **hệ số góc của cát tuyến** $AB$; khi $B$ chạy về $A$, cát tuyến quay thành **tiếp tuyến** tại $A$ (Hình 1).

![Hình 1. Tốc độ trung bình là hệ số góc của cát tuyến AB; tốc độ tức thời là hệ số góc của tiếp tuyến tại A](h1-cat-tuyen-tiep-tuyen.svg)

> [!ghi-nho] Đọc dấu và độ lớn của đạo hàm
> - $f'(x_0)>0$: đại lượng **đang tăng**; $f'(x_0)<0$: **đang giảm**.
> - $\lvert f'(x_0)\rvert$ càng lớn thì đại lượng thay đổi **càng nhanh**.
> - Đơn vị của $f'$ = (đơn vị của $y$) / (đơn vị của $x$): °C/phút, m/s, con/giờ, nghìn đồng/sản phẩm…

> [!vi-du] Ví dụ 1
> Nhiệt độ của một cốc trà sau $t$ phút kể từ khi rót là $T(t)=25+70e^{-0{,}1t}$ (°C).
>
> a) Tính tốc độ thay đổi trung bình của nhiệt độ trong 10 phút đầu.
>
> b) Tính tốc độ thay đổi tức thời của nhiệt độ tại $t=0$ và tại $t=10$. Nhận xét.

> [!goi-y] Gợi ý 1
> a) Tính $T(0)$ và $T(10)$, rồi lấy $\dfrac{T(10)-T(0)}{10-0}$.

> [!goi-y] Gợi ý 2
> b) $\left(e^{-0{,}1t}\right)'=-0{,}1e^{-0{,}1t}$, nên $T'(t)=-7e^{-0{,}1t}$.

> [!loi-giai] Lời giải
> a) $T(0)=25+70=95$ °C; $T(10)=25+70e^{-1}\approx50{,}75$ °C. Tốc độ thay đổi trung bình:
> $$\frac{T(10)-T(0)}{10}\approx\frac{50{,}75-95}{10}\approx-4{,}42$$
> (°C/phút).
>
> b) $T'(t)=-7e^{-0{,}1t}$, nên $T'(0)=-7$ °C/phút và $T'(10)=-7e^{-1}\approx-2{,}58$ °C/phút.
>
> **Nhận xét:** đạo hàm luôn âm — trà luôn nguội đi. Lúc mới rót, trà nguội với tốc độ $7$ °C/phút; sau 10 phút chỉ còn khoảng $2{,}58$ °C/phút. Tốc độ trung bình $-4{,}42$ nằm giữa hai số đó, nhưng **không** cho biết lúc nào nguội nhanh, lúc nào nguội chậm.

> [!bay]
> "Tốc độ thay đổi **tại** thời điểm $t=10$" là $T'(10)$; còn "tốc độ thay đổi **trong** 10 phút đầu" là tốc độ trung bình $\dfrac{T(10)-T(0)}{10}$. Hai câu hỏi chỉ khác nhau một chữ, và đề thi hay dùng đáp số của câu này làm phương án nhiễu cho câu kia.

### 1.2. Trong vật lí: vận tốc và gia tốc

Nếu $s=s(t)$ là vị trí của một vật chuyển động trên một đường thẳng (đã chọn chiều dương) thì:

$$v(t)=s'(t),\qquad a(t)=v'(t)=s''(t),$$

trong đó $v(t)$ là **vận tốc**, $a(t)$ là **gia tốc** tại thời điểm $t$.

- $v>0$: vật đi theo **chiều dương**; $v<0$: đi theo chiều âm; $v$ **đổi dấu** tại $t_0$: vật **đổi chiều** chuyển động tại $t_0$.
- **Tốc độ** là $\lvert v\rvert$ (luôn không âm), còn vận tốc có dấu.

> [!vi-du] Ví dụ 2
> Một quả bóng được ném thẳng đứng lên trên từ độ cao $1{,}5$ m. Bỏ qua sức cản không khí, độ cao của bóng sau $t$ giây là $h(t)=1{,}5+19{,}6t-4{,}9t^2$ (m), chiều dương hướng lên.
>
> a) Tìm vận tốc và gia tốc của bóng tại thời điểm $t$. Tính vận tốc sau 1 giây.
>
> b) Khi nào bóng lên cao nhất? Độ cao lớn nhất là bao nhiêu?
>
> c) Khi nào bóng chạm đất, và vận tốc lúc đó là bao nhiêu (làm tròn đến hàng phần trăm)?

> [!goi-y] Gợi ý 1
> b) Ở điểm cao nhất, bóng **dừng lại một khoảnh khắc** trước khi rơi: $v(t)=0$.

> [!goi-y] Gợi ý 2
> c) Chạm đất nghĩa là $h(t)=0$; lấy nghiệm dương.

> [!loi-giai] Lời giải
> a) $v(t)=h'(t)=19{,}6-9{,}8t$ (m/s); $a(t)=v'(t)=-9{,}8$ (m/s²). Sau 1 giây: $v(1)=9{,}8$ m/s.
>
> b) $v(t)=0\iff t=2$. Với $0\le t<2$ thì $v>0$ (bóng đi lên), với $t>2$ thì $v<0$ (bóng rơi xuống). Vậy bóng cao nhất tại $t=2$ s, với $h(2)=1{,}5+39{,}2-19{,}6=21{,}1$ m.
>
> c) $h(t)=0\iff 4{,}9t^2-19{,}6t-1{,}5=0$, nghiệm dương $t\approx4{,}08$ s. Vận tốc lúc đó $v\approx19{,}6-9{,}8\cdot4{,}075\approx-20{,}34$ m/s. Dấu âm cho biết bóng đang đi **xuống**; tốc độ chạm đất khoảng $20{,}34$ m/s.

> [!meo]
> Gia tốc $a=-9{,}8$ m/s² không đổi chính là **gia tốc trọng trường** $g$ (dấu âm vì chiều dương hướng lên). Mọi bài "ném thẳng đứng" đều có dạng $h(t)=h_0+v_0t-4{,}9t^2$: $h_0$ là độ cao ban đầu, $v_0$ là vận tốc ban đầu, và điểm cao nhất ở $t=\dfrac{v_0}{9{,}8}$.

**Tăng tốc hay giảm tốc?** Đây là chỗ học sinh hay nhầm nhất (SGK Bài tập 1.26 tr. 40). Vật **tăng tốc** nghĩa là **tốc độ** $\lvert v\rvert$ tăng — không phải là $v$ tăng. Hãy nghĩ thế này: gia tốc là "lực đẩy" của vận tốc.

- Nếu $a$ **cùng dấu** với $v$: "đẩy cùng chiều đang đi" → tốc độ tăng → **tăng tốc** (nhanh dần).
- Nếu $a$ **trái dấu** với $v$: "đẩy ngược chiều đang đi" → tốc độ giảm → **giảm tốc** (chậm dần).

> [!vi-du] Ví dụ 3
> Một chất điểm chuyển động trên trục số với vị trí $s(t)=2t^3-15t^2+24t$ (m), $t\ge0$ tính bằng giây.
>
> a) Khi nào chất điểm đi theo chiều dương, khi nào đi theo chiều âm?
>
> b) Khi nào chất điểm tăng tốc, khi nào giảm tốc?
>
> c) Tính quãng đường chất điểm đi được trong 5 giây đầu.

> [!goi-y] Gợi ý 1
> $v(t)=6t^2-30t+24=6(t-1)(t-4)$; $a(t)=12t-30$ đổi dấu tại $t=2{,}5$. Lập một bảng dấu chung cho cả $v$ và $a$.

> [!goi-y] Gợi ý 2
> c) Vật đổi chiều tại $t=1$ và $t=4$, nên quãng đường phải **cộng từng chặng**: $\lvert s(1)-s(0)\rvert+\lvert s(4)-s(1)\rvert+\lvert s(5)-s(4)\rvert$.

> [!loi-giai] Lời giải
> a) $v(t)=6(t-1)(t-4)$: $v>0$ trên $[0;1)$ và $(4;+\infty)$ → đi theo chiều dương; $v<0$ trên $(1;4)$ → đi theo chiều âm.
>
> b) Ghép dấu của $v$ và $a$ (Hình 2):
>
> | Khoảng | $(0;1)$ | $(1;2{,}5)$ | $(2{,}5;4)$ | $(4;+\infty)$ |
> |:-:|:-:|:-:|:-:|:-:|
> | Dấu $v$ | $+$ | $-$ | $-$ | $+$ |
> | Dấu $a$ | $-$ | $-$ | $+$ | $+$ |
> | Kết luận | giảm tốc | tăng tốc | giảm tốc | tăng tốc |
>
> c) $s(0)=0$, $s(1)=11$, $s(4)=-16$, $s(5)=-5$. Quãng đường: $11+27+11=49$ m.

![Hình 2. Ghép dấu của vận tốc và gia tốc: cùng dấu thì tăng tốc, trái dấu thì giảm tốc](h2-tang-giam-toc.svg)

> [!bay] Quãng đường khác độ dịch chuyển
> $s(5)-s(0)=-5$ chỉ là **độ dịch chuyển** (vị trí cuối so với vị trí đầu). Vì vật đã quay đầu hai lần nên **quãng đường** thật là $49$ m. Phương án nhiễu "$5$ m" luôn có mặt trong đề.

### 1.3. Trong hóa học và sinh học

- Nếu $C=C(t)$ là nồng độ một chất trong phản ứng tại thời điểm $t$ thì $C'(t)$ cho biết nồng độ đó thay đổi nhanh thế nào — đó là **tốc độ phản ứng tức thời** (SGK tr. 33).
- Nếu $P=P(t)$ là số cá thể của một quần thể thì $P'(t)$ là **tốc độ tăng trưởng tức thời** của quần thể.

> [!bay] Dấu trong hóa học
> Với **chất tham gia**, nồng độ giảm nên $C'(t)<0$. Ở Hóa học 10, tốc độ phản ứng được quy ước là số **dương**, nên khi tính theo chất tham gia người ta lấy $-C'(t)$. Câu hỏi "nồng độ thay đổi với tốc độ bao nhiêu" thì cứ tính $C'(t)$ và đọc dấu: âm nghĩa là đang giảm.

> [!vi-du] Ví dụ 4
> Số lượng một quần thể vi khuẩn trong môi trường nuôi cấy (nghìn con) sau $t$ giờ được mô hình hóa bởi
> $$P(t)=\frac{60}{1+5e^{-0{,}4t}},\quad t\ge0.$$
> a) Ban đầu có bao nhiêu vi khuẩn? Tốc độ tăng trưởng ban đầu là bao nhiêu?
>
> b) Chứng tỏ quần thể luôn tăng. Về lâu dài số vi khuẩn thế nào?

> [!goi-y] Gợi ý 1
> Dùng $\left(\dfrac{a}{v}\right)'=-\dfrac{a\,v'}{v^2}$ với $v=1+5e^{-0{,}4t}$, $v'=-2e^{-0{,}4t}$.

> [!goi-y] Gợi ý 2
> b) Khi $t\to+\infty$ thì $e^{-0{,}4t}\to0$.

> [!loi-giai] Lời giải
> a) $P(0)=\dfrac{60}{6}=10$ nghìn con.
> $$P'(t)=-\frac{60\cdot(-2e^{-0{,}4t})}{(1+5e^{-0{,}4t})^2}=\frac{120e^{-0{,}4t}}{(1+5e^{-0{,}4t})^2},$$
> nên $P'(0)=\dfrac{120}{36}=\dfrac{10}{3}\approx3{,}33$ nghìn con/giờ.
>
> b) $P'(t)>0$ với mọi $t\ge0$ nên quần thể **luôn tăng**. Nhưng $\lim\limits_{t\to+\infty}P(t)=\dfrac{60}{1+0}=60$: số vi khuẩn tăng dần, tiến sát $60$ nghìn con mà không vượt quá — đó là "sức chứa" của môi trường (đồ thị có tiệm cận ngang $P=60$, xem Bài 3).

> [!em-co-biet] Đường cong hình chữ S
> Mô hình $P(t)=\dfrac{K}{1+be^{-rt}}$ gọi là **mô hình logistic** — em sẽ gặp lại nó ở Sinh học 12 (tăng trưởng quần thể trong môi trường có giới hạn). Quần thể tăng **nhanh nhất** đúng lúc đạt **một nửa sức chứa** $\dfrac K2$; với Ví dụ 4, đó là khi $P=30$, tức $5e^{-0{,}4t}=1$, $t=\dfrac{\ln5}{0{,}4}\approx4{,}02$ giờ. SGK tr. 34 có một ví dụ ngược lại: biết $P(0)$ và $P'(0)$, tìm các hệ số của mô hình.

### 1.4. Trong kinh tế: chi phí biên

Gọi $C(x)$ là tổng chi phí để sản xuất $x$ đơn vị hàng. Đạo hàm $C'(x)$ gọi là **chi phí biên**.

**Vì sao chi phí biên lại "xấp xỉ chi phí làm thêm một sản phẩm"?** Chi phí để làm sản phẩm thứ $x+1$ là $C(x+1)-C(x)$. Đây chính là tốc độ thay đổi trung bình trên đoạn $[x;x+1]$ (vì $\Delta x=1$). Khi $x$ là số lớn (hàng trăm, hàng nghìn), đoạn dài $1$ là rất ngắn so với $x$, nên tốc độ trung bình đó gần bằng tốc độ tức thời:

$$C(x+1)-C(x)\approx C'(x).$$

Lí do ta dùng $C'(x)$ thay vì tính hiệu: đạo hàm là một **công thức** gọn, dễ khảo sát (tăng, giảm, nhỏ nhất…).

> [!vi-du] Ví dụ 5
> Chi phí (nghìn đồng) để một xưởng sản xuất $x$ chiếc ghế gỗ là
> $$C(x)=20\,000+150x-0{,}4x^2+0{,}002x^3.$$
> a) Tìm hàm chi phí biên. Tính $C'(100)$ và nêu ý nghĩa.
>
> b) Tính chi phí thực tế để làm chiếc ghế thứ $101$ và so sánh với $C'(100)$.

> [!goi-y] Gợi ý 1
> $C'(x)=150-0{,}8x+0{,}006x^2$.

> [!goi-y] Gợi ý 2
> b) Chiếc ghế thứ $101$ tốn $C(101)-C(100)$.

> [!loi-giai] Lời giải
> a) $C'(x)=150-0{,}8x+0{,}006x^2$; $C'(100)=150-80+60=130$ (nghìn đồng/chiếc). Ý nghĩa: khi đã làm $100$ chiếc, làm thêm **một** chiếc nữa tốn khoảng $130$ nghìn đồng.
>
> b) $C(101)-C(100)=150-0{,}4\cdot(101^2-100^2)+0{,}002\cdot(101^3-100^3)=150-80{,}4+60{,}602=130{,}202$ nghìn đồng — rất gần $C'(100)=130$.

> [!bay] Chi phí biên khác chi phí trung bình
> - **Chi phí biên** $C'(x)$: tiền làm **thêm một** sản phẩm.
> - **Chi phí trung bình** $\overline{C}(x)=\dfrac{C(x)}{x}$: tổng tiền **chia đều** cho mỗi sản phẩm (đã gồm cả chi phí cố định).
>
> Ở Ví dụ 5: $C(100)=33\,000$ nên chi phí trung bình là $330$ nghìn đồng/chiếc, trong khi chi phí biên chỉ $130$ nghìn đồng/chiếc.

> [!ung-dung]
> Doanh nghiệp so sánh chi phí biên với giá bán: nếu làm thêm một sản phẩm tốn ít hơn giá bán được thì nên làm thêm. Ở mục 2.3, em sẽ thấy các khái niệm "biên" khác: **doanh thu biên** $R'(x)$, **lợi nhuận biên** $P'(x)$.

## 2. Một vài bài toán tối ưu hóa đơn giản

### 2.1. Quy trình giải

Bài toán tối ưu hóa là tìm cách làm cho một đại lượng **lớn nhất** (diện tích, thể tích, lợi nhuận) hoặc **nhỏ nhất** (chi phí, thời gian, vật liệu). Phần toán (tìm GTLN, GTNN) em đã làm thành thạo ở Bài 2. Cái khó thật sự là **dịch đề bài bằng lời thành một hàm số**.

> [!ghi-nho] Quy trình (SGK tr. 36–37)
> 1. **Xác định đại lượng $Q$** cần làm lớn nhất / nhỏ nhất; viết $Q$ theo các đại lượng khác trong bài (vẽ hình nếu có thể).
> 2. **Chọn một ẩn $x$** (ghi đơn vị), biểu diễn các đại lượng khác theo $x$ để $Q=Q(x)$ chỉ còn **một biến**. Tìm **miền giá trị thực tế** của $x$.
> 3. **Tìm GTLN hoặc GTNN** của $Q(x)$ trên miền đó (quy tắc đoạn hoặc bảng biến thiên) rồi **kết luận** theo đúng câu hỏi.

Ở Bài 2 (mục 3) em đã gặp: hộp không nắp từ tấm bìa, lon hình trụ tốn ít vật liệu nhất, giá trà sữa cho lợi nhuận lớn nhất. Bài này bổ sung thêm các tình huống mới.

> [!meo] Mẹo chọn ẩn
> - Có **hai** kích thước và **một** ràng buộc (diện tích cho trước, thể tích cho trước, chu vi cho trước…) → dùng ràng buộc để rút kích thước này theo kích thước kia.
> - Bài đường đi / dây cáp → đặt $x$ là **khoảng cách từ một điểm cố định đến điểm "rẽ"**, rồi dùng định lí Pythagore.
> - Bài giá bán → đặt $x$ là **số lần** tăng/giảm giá, hoặc đặt **giá bán** $p$ làm ẩn rồi lập hàm cầu.

### 2.2. Tối ưu trong hình học: rào đất, kéo cáp

> [!vi-du] Ví dụ 6
> Một trang trại muốn rào một khu đất hình chữ nhật có diện tích $600$ m², rồi dựng thêm một hàng rào ở giữa, song song với một cạnh, để chia khu đất thành hai chuồng. Hỏi phải chọn các kích thước thế nào để tổng chiều dài hàng rào là nhỏ nhất?

> [!goi-y] Gợi ý 1
> Gọi $x$ (m) là chiều dài cạnh **vuông góc** với hàng rào giữa, $y$ (m) là cạnh **song song** với hàng rào giữa. Có mấy đoạn dài $x$, mấy đoạn dài $y$?

> [!goi-y] Gợi ý 2
> Hai đoạn dài $x$ và **ba** đoạn dài $y$: $L=2x+3y$, với $xy=600$.

> [!loi-giai] Lời giải
> Gọi $x$, $y$ (m) như gợi ý, $x>0$, $y>0$, $xy=600$ nên $y=\dfrac{600}{x}$. Tổng chiều dài rào:
> $$L(x)=2x+3\cdot\frac{600}{x}=2x+\frac{1800}{x},\quad x>0.$$
> $L'(x)=2-\dfrac{1800}{x^2}$; $L'(x)=0\iff x^2=900\iff x=30$ (vì $x>0$).
>
> | $x$ | $0$ | | $30$ | | $+\infty$ |
> |:-:|:-:|:-:|:-:|:-:|:-:|
> | $L'$ | | $-$ | $0$ | $+$ | |
> | $L$ | $+\infty$ | $\searrow$ | $120$ | $\nearrow$ | $+\infty$ |
>
> Vậy chọn $x=30$ m, $y=20$ m; tổng chiều dài rào nhỏ nhất là $120$ m.

> [!em-co-biet]
> Ở lời giải trên, khi tối ưu thì $2x=3y=60$: tổng rào chia **đều** cho hai "hướng". Đây không phải ngẫu nhiên — với $L=ax+\dfrac{b}{x}$, bất đẳng thức Cauchy cho $L\ge2\sqrt{ab}$, dấu bằng khi $ax=\dfrac bx$ (hai số hạng bằng nhau).

> [!vi-du] Ví dụ 7
> Một con sông thẳng rộng $1$ km. Trạm điện $A$ nằm trên một bờ; nhà máy $B$ nằm trên bờ bên kia, cách điểm $C$ (điểm đối diện $A$) $4$ km dọc theo bờ. Người ta kéo cáp điện từ $A$ băng qua sông theo đường thẳng tới điểm $D$ trên bờ bên kia (nằm giữa $C$ và $B$), rồi đi dọc bờ từ $D$ đến $B$ (Hình 3). Chi phí kéo cáp dưới nước là $50$ triệu đồng/km, trên bờ là $30$ triệu đồng/km. Tìm vị trí $D$ để chi phí nhỏ nhất.

![Hình 3. Cáp đi từ A chéo qua sông đến D, rồi chạy dọc bờ đến B; đặt CD = x](h3-cap-qua-song.svg)

> [!goi-y] Gợi ý 1
> Đặt $CD=x$ (km), $0\le x\le4$. Tam giác $ACD$ vuông tại $C$ nên $AD=\sqrt{1+x^2}$; còn $DB=4-x$.

> [!goi-y] Gợi ý 2
> $f(x)=50\sqrt{1+x^2}+30(4-x)$. Giải $f'(x)=0$: $\dfrac{50x}{\sqrt{1+x^2}}=30$, bình phương khi hai vế cùng không âm.

> [!loi-giai] Lời giải
> Chi phí: $f(x)=50\sqrt{1+x^2}+30(4-x)$ (triệu đồng), $x\in[0;4]$.
>
> $f'(x)=\dfrac{50x}{\sqrt{1+x^2}}-30$; $f'(x)=0\iff 5x=3\sqrt{1+x^2}\iff\begin{cases}x\ge0\\25x^2=9+9x^2\end{cases}\iff x=\dfrac34$.
>
> So sánh: $f(0)=50+120=170$; $f\!\left(\tfrac34\right)=50\cdot\tfrac54+30\cdot\tfrac{13}{4}=62{,}5+97{,}5=160$; $f(4)=50\sqrt{17}\approx206{,}2$.
>
> Vậy chọn $D$ cách $C$ một khoảng $0{,}75$ km (cách $B$ $3{,}25$ km); chi phí nhỏ nhất là $160$ triệu đồng.

> [!bay]
> Hai phương án "dễ nghĩ" — kéo thẳng sang $C$ rồi chạy dọc bờ ($170$ triệu), hoặc kéo chéo thẳng tới $B$ ($\approx206$ triệu) — đều **không** tối ưu. Và nhớ: đề hỏi **vị trí $D$** thì trả lời $x$ (hoặc $DB$, tùy đề), đề hỏi **chi phí** thì trả lời $f(x)$. Bài Luyện tập 2 (SGK tr. 38) chèo thuyền rồi chạy bộ là cùng mô hình, chỉ thay "chi phí mỗi km" bằng "thời gian mỗi km" $=\dfrac{1}{\text{vận tốc}}$.

### 2.3. Tối ưu trong kinh tế: hàm cầu, doanh thu, lợi nhuận

> [!ghi-nho] Các hàm kinh tế (SGK tr. 38)
> - **Hàm cầu** (hàm giá) $p=p(x)$: giá bán mỗi đơn vị khi bán được $x$ đơn vị. Thường là hàm **giảm** (muốn bán nhiều thì phải hạ giá).
> - **Hàm doanh thu** $R(x)=x\cdot p(x)$; **doanh thu biên** $R'(x)$.
> - **Hàm lợi nhuận** $P(x)=R(x)-C(x)$; **lợi nhuận biên** $P'(x)$.

**Lập hàm cầu tuyến tính từ "cứ … thì …".** Câu "cứ giảm giá $a$ đồng thì bán thêm $b$ sản phẩm" nghĩa là số sản phẩm thay đổi **tỉ lệ** với giá → $x$ là **hàm bậc nhất** của $p$. Chỉ cần một điểm $(p_0;x_0)$ và hệ số góc $-\dfrac ba$:

$$x=x_0+\frac{b}{a}(p_0-p).$$

> [!vi-du] Ví dụ 8
> Một bể bơi bán vé $40$ nghìn đồng/lượt thì trung bình mỗi ngày có $600$ lượt khách. Khảo sát cho thấy cứ giảm giá vé $5$ nghìn đồng thì mỗi ngày có thêm $120$ lượt khách.
>
> a) Lập hàm cầu (số lượt khách $x$ theo giá vé $p$). Giá vé bao nhiêu thì doanh thu mỗi ngày lớn nhất?
>
> b) Mỗi lượt khách tốn $10$ nghìn đồng chi phí (nước, điện, hóa chất). Giá vé bao nhiêu thì lợi nhuận lớn nhất?

> [!goi-y] Gợi ý 1
> Giảm $1$ nghìn đồng thì thêm $\dfrac{120}{5}=24$ lượt: $x=600+24(40-p)=1560-24p$. Điều kiện: $p>0$ và $x\ge0$, tức $0<p\le65$.

> [!goi-y] Gợi ý 2
> a) $R(p)=p(1560-24p)$. b) Lợi nhuận $=$ (giá vé $-$ chi phí mỗi lượt) $\times$ số lượt $=(p-10)(1560-24p)$.

> [!loi-giai] Lời giải
> a) Hàm cầu $x=1560-24p$, $0<p\le65$. Doanh thu $R(p)=1560p-24p^2$; $R'(p)=1560-48p=0\iff p=32{,}5$.
> $R'(p)>0$ khi $p<32{,}5$ và $R'(p)<0$ khi $p>32{,}5$, nên doanh thu lớn nhất khi giá vé là $32{,}5$ nghìn đồng (khi đó có $780$ lượt khách, doanh thu $25\,350$ nghìn đồng/ngày).
>
> b) $P(p)=(p-10)(1560-24p)=-24p^2+1800p-15\,600$; $P'(p)=-48p+1800=0\iff p=37{,}5$. Tương tự, $P$ đạt lớn nhất tại $p=37{,}5$: lợi nhuận $27{,}5\cdot660=18\,150$ nghìn đồng/ngày.

> [!bay] Doanh thu lớn nhất ≠ lợi nhuận lớn nhất
> Khi có chi phí theo mỗi sản phẩm, giá tối ưu cho **lợi nhuận** cao hơn giá tối ưu cho **doanh thu** ($37{,}5$ so với $32{,}5$): bán thêm khách ở giá quá thấp thì phần chi phí "ăn" hết tiền thu. Đọc kỹ đề hỏi doanh thu hay lợi nhuận. Bài toán sân vận động mở đầu bài (SGK tr. 33, giải ở tr. 38–39) là dạng a) của ví dụ này.

**Chi phí trung bình nhỏ nhất.** Sản xuất càng nhiều thì chi phí cố định được "chia" cho nhiều sản phẩm hơn, nhưng sản xuất quá nhiều thì chi phí biến đổi lại tăng nhanh. Vì vậy chi phí trung bình $\overline C(x)=\dfrac{C(x)}{x}$ thường có một giá trị nhỏ nhất.

> [!vi-du] Ví dụ 9
> Chi phí sản xuất $x$ hộp trà thảo mộc mỗi tháng là $C(x)=0{,}01x^2+20x+4900$ (nghìn đồng). Hỏi mỗi tháng nên sản xuất bao nhiêu hộp để chi phí trung bình mỗi hộp là nhỏ nhất? Tính chi phí trung bình nhỏ nhất đó.

> [!goi-y] Gợi ý 1
> $\overline C(x)=\dfrac{C(x)}{x}=0{,}01x+20+\dfrac{4900}{x}$, $x>0$.

> [!goi-y] Gợi ý 2
> $\overline C'(x)=0{,}01-\dfrac{4900}{x^2}$.

> [!loi-giai] Lời giải
> $\overline C'(x)=0{,}01-\dfrac{4900}{x^2}=0\iff x^2=490\,000\iff x=700$. $\overline C'$ đổi dấu từ âm sang dương tại $x=700$ (và $\overline C\to+\infty$ ở hai đầu), nên chi phí trung bình nhỏ nhất là
> $$\overline C(700)=7+20+7=34$$
> (nghìn đồng/hộp).

> [!em-co-biet]
> Ở Ví dụ 9, chi phí biên tại $x=700$ là $C'(700)=0{,}02\cdot700+20=34$ — **đúng bằng** chi phí trung bình nhỏ nhất. Đây là quy luật chung trong kinh tế học: chi phí trung bình nhỏ nhất đạt tại mức sản xuất mà **chi phí biên bằng chi phí trung bình**.

> [!ung-dung] Đạo hàm trong đời thực
> - Đồng hồ tốc độ trên xe máy hiển thị **đạo hàm** của quãng đường theo thời gian.
> - Bác sĩ theo dõi huyết áp, nồng độ thuốc giảm **nhanh hay chậm** (SGK Luyện tập 1, tr. 36).
> - Cơ sở sản xuất tính chi phí biên để quyết định có nên nhận thêm đơn hàng.
> - Nhà máy tính chi phí loại bỏ $x\%$ chất ô nhiễm (SGK Ví dụ 4, tr. 35): hàm chi phí tăng mãi khi $x\to100$ nên **không thể** loại bỏ hoàn toàn — xem thêm tiệm cận đứng ở Bài 3.

## Dạng bài thi hay gặp

### Dạng 1. Tính tốc độ thay đổi / vận tốc / gia tốc từ hàm cho sẵn (trả lời ngắn)

- **Nhận biết:** đề cho hàm vị trí, độ cao, dân số, chi phí…; hỏi "vận tốc tại…", "gia tốc tại…", "tốc độ thay đổi tại…", "vận tốc lớn nhất", "chi phí biên".
- **Phương pháp:** tính đạo hàm đúng bậc ($s'$ cho vận tốc, $s''$ cho gia tốc) → thế số. Hỏi "vận tốc **lớn nhất**" thì khảo sát hàm $v(t)$ (dùng $v'=a$) trên miền thời gian của đề.
- **Bẫy:** nhầm "tại thời điểm" với "trong khoảng"; nhầm vận tốc lớn nhất với quãng đường lớn nhất; quên miền $t$ (ví dụ "trong 10 giây đầu").

> [!vi-du] Ví dụ 10
> Một ô tô chạy thử trên đường thẳng, quãng đường đi được sau $t$ giây là $s(t)=-\dfrac13t^3+6t^2$ (m), $0\le t\le10$.
>
> a) Tính gia tốc của xe tại $t=2$.
>
> b) Trong 10 giây đó, vận tốc lớn nhất của xe là bao nhiêu m/s?

> [!goi-y] Gợi ý 1
> $v(t)=s'(t)=-t^2+12t$, $a(t)=v'(t)=-2t+12$.

> [!goi-y] Gợi ý 2
> b) Tìm GTLN của $v(t)$ trên đoạn $[0;10]$: so sánh $v(0)$, $v(6)$, $v(10)$.

> [!loi-giai] Lời giải
> a) $a(2)=-4+12=8$ m/s².
>
> b) $v'(t)=-2t+12=0\iff t=6$. $v(0)=0$, $v(6)=-36+72=36$, $v(10)=-100+120=20$. Vận tốc lớn nhất là $36$ m/s (đạt tại $t=6$ s). Đáp số trả lời ngắn: **36**.

### Dạng 2. Đúng/Sai về một mô hình thực tế

- **Nhận biết:** một hàm số mô tả hiện tượng (mực nước, dân số, lợi nhuận, nhiệt độ…) kèm bốn ý: tăng/giảm, giá trị lớn nhất/nhỏ nhất, tốc độ tại một thời điểm, khi nào thay đổi nhanh nhất.
- **Phương pháp:** tính $f'$, $f''$ một lần; lập **bảng giá trị** tại các điểm tới hạn và hai đầu mút; dùng lại cho cả bốn ý.
- **Bẫy:** "giảm nhanh nhất" là tìm GTNN của $f'$ (số âm nhất), không phải GTNN của $f$; quên so sánh với giá trị ở đầu mút.

> [!vi-du] Ví dụ 11 (Đúng/Sai)
> Lượng nước trong một hồ chứa sau $t$ tháng kể từ đầu năm là $V(t)=t^3-15t^2+48t+200$ (triệu m³), $0\le t\le10$. Xét các mệnh đề:
>
> a) Lượng nước giảm trong khoảng thời gian từ tháng thứ 2 đến tháng thứ 8.
>
> b) Trong 10 tháng đó, lượng nước nhiều nhất là vào thời điểm $t=10$.
>
> c) Tại thời điểm $t=5$, lượng nước đang giảm với tốc độ $27$ triệu m³/tháng.
>
> d) Lượng nước giảm nhanh nhất tại thời điểm $t=5$.

> [!goi-y] Gợi ý 1
> $V'(t)=3t^2-30t+48=3(t-2)(t-8)$. Tính $V(0)$, $V(2)$, $V(8)$, $V(10)$.

> [!goi-y] Gợi ý 2
> d) Tốc độ thay đổi là $V'(t)$; "giảm nhanh nhất" là lúc $V'(t)$ **âm nhất**, tức GTNN của $V'(t)$ trên $[0;10]$. Dùng $V''(t)=6t-30$.

> [!loi-giai] Lời giải
> a) **Đúng** — $V'(t)<0$ trên $(2;8)$.
>
> b) **Sai** — $V(0)=200$, $V(2)=244$, $V(8)=136$, $V(10)=180$: nhiều nhất là $244$ triệu m³ tại $t=2$.
>
> c) **Đúng** — $V'(5)=75-150+48=-27$: đang giảm, tốc độ $27$ triệu m³/tháng.
>
> d) **Đúng** — $V''(t)=6t-30=0\iff t=5$; $V'(0)=48$, $V'(5)=-27$, $V'(10)=48$. GTNN của $V'$ trên $[0;10]$ là $-27$ tại $t=5$.

### Dạng 3. Tối ưu hình học, đường đi (trả lời ngắn có làm tròn)

- **Nhận biết:** hàng rào, cửa sổ, bể, hộp, dây cáp, đường ống, chèo thuyền rồi chạy bộ…
- **Phương pháp:** vẽ hình, đặt ẩn, dùng ràng buộc rút về một biến → điều kiện của ẩn → khảo sát. **Giữ giá trị chính xác** (căn, $\pi$) đến bước cuối mới làm tròn.
- **Bẫy:** làm tròn sớm; trả lời nhầm đại lượng (đề hỏi bán kính, em lại trả lời diện tích); quên điều kiện của ẩn.

> [!vi-du] Ví dụ 12
> Một ô cửa sổ gồm phần dưới là hình chữ nhật, phần trên là nửa hình tròn có đường kính bằng chiều rộng hình chữ nhật (Hình 4). Chu vi cả khung cửa (không tính cạnh chung) là $4$ m. Tìm bán kính nửa hình tròn để cửa có diện tích lớn nhất (nhận được nhiều ánh sáng nhất). Tính diện tích đó (làm tròn đến hàng phần trăm).

![Hình 4. Cửa sổ: hình chữ nhật rộng 2r, cao h, phía trên là nửa hình tròn bán kính r](h4-cua-so.svg)

> [!goi-y] Gợi ý 1
> Gọi bán kính $r$, chiều cao phần chữ nhật $h$. Chu vi gồm: đáy $2r$, hai cạnh đứng $2h$, cung nửa tròn $\pi r$. Vậy $2r+2h+\pi r=4$.

> [!goi-y] Gợi ý 2
> Rút $h=\dfrac{4-(2+\pi)r}{2}$ rồi thay vào $S=2rh+\dfrac{\pi r^2}{2}$.

> [!loi-giai] Lời giải
> Điều kiện $r>0$, $h>0$, tức $0<r<\dfrac{4}{2+\pi}$.
> $$S(r)=2r\cdot\frac{4-(2+\pi)r}{2}+\frac{\pi r^2}{2}$$
> $$=4r-\left(2+\frac\pi2\right)r^2.$$
> Đây là hàm bậc hai có hệ số $r^2$ âm. $S'(r)=4-(4+\pi)r=0\iff r=\dfrac{4}{4+\pi}\approx0{,}56$ m (thuộc miền điều kiện). $S'$ đổi dấu từ dương sang âm tại đó, nên
> $$S_{\max}=S\!\left(\frac{4}{4+\pi}\right)=\frac{8}{4+\pi}\approx1{,}12\ \text{m}^2.$$
> Thú vị: khi đó $h=\dfrac{4}{4+\pi}=r$ — chiều cao phần chữ nhật bằng bán kính.

### Dạng 4. Giá bán – số lượng (kinh tế)

- **Nhận biết:** "cứ tăng (giảm) giá … thì bớt (thêm) … khách / sản phẩm / phòng"; hỏi giá bán, doanh thu hay lợi nhuận lớn nhất.
- **Phương pháp:** đặt $x$ là **số lần** tăng (giảm) giá → giá mới, số lượng mới theo $x$ → doanh thu $=$ giá $\times$ số lượng, lợi nhuận $=$ (giá $-$ chi phí mỗi đơn vị) $\times$ số lượng → khảo sát.
- **Bẫy:** trả lời $x$ (số lần tăng) thay cho giá bán; quên điều kiện số lượng không âm; khi đại lượng phải là **số nguyên** (số phòng, số người) mà nghiệm không nguyên thì so sánh hai số nguyên kề bên.

> [!vi-du] Ví dụ 13
> Một homestay có $20$ phòng. Với giá $500$ nghìn đồng/phòng/đêm thì luôn kín phòng. Cứ tăng giá thêm $50$ nghìn đồng thì có thêm $1$ phòng bị trống. Mỗi phòng có khách tốn $100$ nghìn đồng chi phí dọn dẹp, điện nước. Chủ homestay nên đặt giá bao nhiêu để lợi nhuận mỗi đêm là lớn nhất?

> [!goi-y] Gợi ý 1
> Gọi $x$ là số lần tăng giá ($0\le x\le20$). Giá: $500+50x$; số phòng có khách: $20-x$.

> [!goi-y] Gợi ý 2
> Lợi nhuận $L(x)=(500+50x-100)(20-x)=(400+50x)(20-x)$.

> [!loi-giai] Lời giải
> $L(x)=-50x^2+600x+8000$, $x\in[0;20]$. $L'(x)=-100x+600=0\iff x=6$.
> $L(0)=8000$; $L(6)=700\cdot14=9800$; $L(20)=0$.
>
> Vậy nên đặt giá $500+50\cdot6=800$ nghìn đồng/đêm (có $14$ phòng có khách), lợi nhuận lớn nhất $9\,800$ nghìn đồng mỗi đêm. Đáp số "giá bán" là **800**, không phải $6$.

## Tóm tắt

| Đại lượng | Công thức | Ý nghĩa |
|---|---|---|
| Tốc độ thay đổi trung bình | $\dfrac{f(x_2)-f(x_1)}{x_2-x_1}$ | Hệ số góc cát tuyến |
| Tốc độ thay đổi tức thời | $f'(x_0)$ | Hệ số góc tiếp tuyến |
| Vận tốc, gia tốc | $v=s'$, $a=v'=s''$ | $v$, $a$ cùng dấu: tăng tốc; trái dấu: giảm tốc |
| Tăng trưởng, tốc độ phản ứng | $P'(t)$, $C'(t)$ | Dấu cho biết tăng hay giảm |
| Chi phí biên | $C'(x)\approx C(x+1)-C(x)$ | Tiền làm thêm 1 sản phẩm |
| Chi phí trung bình | $\overline C(x)=\dfrac{C(x)}{x}$ | Nhỏ nhất khi $C'(x)=\overline C(x)$ |
| Doanh thu, lợi nhuận | $R=x\cdot p(x)$, $P=R-C$ | $R'$, $P'$: doanh thu biên, lợi nhuận biên |
| Bài toán tối ưu | Đại lượng $Q$ → ẩn $x$ + điều kiện → $Q(x)$ → GTLN/GTNN | Trả lời đúng đại lượng được hỏi |

**Sơ đồ tư duy khi gặp đề:** đề hỏi *"nhanh/chậm, tại thời điểm"* → đạo hàm rồi thế số; *"lớn nhất/nhỏ nhất"* của đại lượng → khảo sát hàm đó; *"tăng/giảm nhanh nhất"* → khảo sát **đạo hàm** (dùng đạo hàm cấp hai); đề *bằng lời* → tự lập hàm theo ba bước, nhớ điều kiện của ẩn.
