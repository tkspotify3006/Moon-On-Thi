---
title: Phương trình đường thẳng trong không gian
thoi-gian: 55 phút
muc-tieu:
  - Hiểu vectơ chỉ phương của đường thẳng; biết một đường thẳng được xác định bởi một điểm và một vectơ chỉ phương
  - Nhận biết phương trình tham số, phương trình chính tắc của đường thẳng; đọc ra một điểm, một vectơ chỉ phương và kiểm tra một điểm có thuộc đường thẳng không
  - Viết phương trình đường thẳng đi qua một điểm và biết vectơ chỉ phương, đi qua hai điểm, đi qua một điểm và vuông góc với một mặt phẳng, song song với một đường thẳng cho trước
  - Nhận biết hai đường thẳng vuông góc bằng tích vô hướng của hai vectơ chỉ phương
  - Xét vị trí tương đối của hai đường thẳng (song song, trùng nhau, cắt nhau, chéo nhau) bằng tích có hướng hoặc bằng hệ phương trình
  - Vận dụng vào bài toán thực tiễn (tầm nhìn bị che, đường bay của drone, tia laser, cáp treo, nút giao thông khác mức…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Đường thẳng được "chốt" bởi **một điểm** $M_0(x_0;\,y_0;\,z_0)$ và **một hướng** — vectơ chỉ phương $\vec u=(a;\,b;\,c)\ne\vec 0$.
> 2. Phương trình tham số: $x=x_0+at$, $y=y_0+bt$, $z=z_0+ct$ — mỗi số $t$ cho đúng một điểm của đường thẳng.
> 3. Phương trình chính tắc (khi $a,b,c$ đều khác 0): $\dfrac{x-x_0}{a}=\dfrac{y-y_0}{b}=\dfrac{z-z_0}{c}$.
> 4. Vuông góc $\iff\vec u_1\cdot\vec u_2=0$. Song song/trùng $\iff[\vec u_1,\vec u_2]=\vec 0$ (xét thêm một điểm).
> 5. $[\vec u_1,\vec u_2]\ne\vec 0$: cắt nhau nếu $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=0$, chéo nhau nếu tích đó khác $0$.

Ở Bài 14, mặt phẳng được "chốt" bằng một điểm và một hướng **vuông góc** với nó (vectơ pháp tuyến). Đường thẳng thì ngược lại, dễ hình dung hơn: nó được chốt bằng một điểm và một hướng **dọc theo** nó. Hãy nghĩ tới một chiếc drone bay thẳng đều: biết nó xuất phát ở đâu và mỗi giây dịch chuyển một vectơ bao nhiêu, em biết ngay nó ở đâu vào bất kì lúc nào. Đó chính là **phương trình tham số** của đường thẳng.

Câu hỏi mở đầu (sẽ giải ở Ví dụ 8): mắt người quan sát ở $M$, vật ở $N$, giữa hai điểm có một tấm bìa tròn nằm trên mặt sàn $(Oxy)$. Tấm bìa có che khuất vật không? Em sẽ thấy câu hỏi "trông rất hình học" này chỉ còn là **giải một phương trình bậc nhất ẩn $t$**.

> [!nen-tang] Nhắc lại cần dùng (Bài 8, Bài 14)
> - $\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$ — "cuối trừ đầu".
> - $\vec a$ cùng phương $\vec b\ne\vec 0$ $\iff$ có số $k$ để $\vec a=k\vec b$ (ba tọa độ tỉ lệ cùng một $k$).
> - Tích vô hướng $\vec a\cdot\vec b=xx'+yy'+zz'$; $\vec a\perp\vec b\iff\vec a\cdot\vec b=0$.
> - Tích có hướng $[\vec u,\vec v]$ vuông góc với cả $\vec u$ và $\vec v$; $[\vec u,\vec v]=\vec 0\iff\vec u,\vec v$ cùng phương (mẹo "che cột", Bài 14).
> - Mặt phẳng $Ax+By+Cz+D=0$ có VTPT $\vec n=(A;\,B;\,C)$.

## 1. Phương trình đường thẳng

### 1.1. Vectơ chỉ phương của đường thẳng

Qua một điểm $M$ cho trước, có bao nhiêu đường thẳng **song song (hoặc trùng)** với giá của một vectơ $\vec u\ne\vec 0$? Chỉ có **một** (tiên đề Euclid). Còn đường thẳng qua $M$ **vuông góc** với giá của $\vec u$ thì có vô số — chúng nằm kín cả một mặt phẳng. Vì vậy, để chốt một đường thẳng, ta cần một vectơ chạy **dọc** theo nó.

> [!ghi-nho] Định nghĩa (SGK tr. 41)
> Vectơ $\vec u\ne\vec 0$ là **vectơ chỉ phương** (viết tắt VTCP) của đường thẳng $\Delta$ nếu giá của $\vec u$ **song song hoặc trùng** với $\Delta$.
> - Biết một điểm thuộc $\Delta$ và một VTCP thì $\Delta$ hoàn toàn xác định.
> - Nếu $\vec u$ là VTCP thì $k\vec u$ (với $k\ne0$) cũng là VTCP.

![Hình 1. Đường thẳng Δ qua M₀, có vectơ chỉ phương u. Mỗi điểm M của Δ ứng với một số t sao cho M₀M = t·u](h1-vtcp.svg)

So sánh với Bài 14 để khỏi lẫn:

| | Mặt phẳng | Đường thẳng |
|---|---|---|
| Vectơ đặc trưng | VTPT $\vec n$, **vuông góc** với mặt phẳng | VTCP $\vec u$, **dọc theo** đường thẳng |
| Chốt bằng | 1 điểm + $\vec n$ | 1 điểm + $\vec u$ |
| Không duy nhất | $k\vec n$ cũng là VTPT | $k\vec u$ cũng là VTCP |

> [!vi-du] Ví dụ 1
> Cho $A(1;\,-1;\,2)$ và $B(3;\,2;\,-1)$.
>
> a) Trong các vectơ $\vec u_1=(4;\,6;\,-6)$, $\vec u_2=(-2;\,-3;\,3)$, $\vec u_3=(2;\,3;\,3)$, $\vec u_4=(1;\,1{,}5;\,-1{,}5)$, vectơ nào là VTCP của đường thẳng $AB$?
>
> b) Chỉ ra một VTCP của một đường thẳng song song với trục $Oz$.

> [!goi-y] Gợi ý 1
> $\overrightarrow{AB}$ là một VTCP của đường thẳng $AB$. Tính nó trước.

> [!goi-y] Gợi ý 2
> Vectơ nào **tỉ lệ** với $\overrightarrow{AB}$ (cả ba tọa độ cùng một hệ số $k$) thì là VTCP.

> [!loi-giai] Lời giải
> a) $\overrightarrow{AB}=(2;\,3;\,-3)$.
> - $\vec u_1=2\overrightarrow{AB}$ ✓.
> - $\vec u_2=-\overrightarrow{AB}$ ✓ (ngược chiều vẫn được).
> - $\vec u_3=(2;\,3;\,3)$: hai tọa độ đầu ứng với $k=1$ nhưng tọa độ cuối ứng với $k=-1$ ✗.
> - $\vec u_4=\frac12\overrightarrow{AB}$ ✓.
>
> Vậy $\vec u_1,\vec u_2,\vec u_4$ là VTCP của $AB$.
>
> b) Trục $Oz$ có VTCP $\vec k=(0;\,0;\,1)$, nên mọi đường thẳng song song với $Oz$ cũng nhận $\vec k$ làm VTCP.

### 1.2. Phương trình tham số

Quay lại chiếc drone: xuất phát từ $M_0(x_0;\,y_0;\,z_0)$, mỗi giây dịch chuyển đúng vectơ $\vec u=(a;\,b;\,c)$. Sau $t$ giây, nó dịch chuyển $t\vec u$, nên vị trí $M(x;\,y;\,z)$ thỏa $\overrightarrow{M_0M}=t\vec u$, tức là
$$x-x_0=at,\quad y-y_0=bt,\quad z-z_0=ct.$$
Cho $t$ chạy khắp $\mathbb R$ (kể cả $t$ âm — "thời điểm trước khi xuất phát"), điểm $M$ quét hết đường thẳng. Ngược lại, điểm $M$ thuộc đường thẳng thì $\overrightarrow{M_0M}$ cùng phương với $\vec u$, nên luôn viết được $\overrightarrow{M_0M}=t\vec u$.

> [!ghi-nho] Phương trình tham số (SGK tr. 42)
> Đường thẳng $\Delta$ qua $M_0(x_0;\,y_0;\,z_0)$, có VTCP $\vec u=(a;\,b;\,c)$:
> $$\begin{cases}x=x_0+at\\y=y_0+bt\\z=z_0+ct\end{cases}\qquad(t\in\mathbb R).$$
> - Số đứng **một mình** là tọa độ điểm $M_0$; **hệ số của $t$** là tọa độ VTCP.
> - Mỗi giá trị của $t$ cho đúng một điểm thuộc $\Delta$ và ngược lại.

**Kiểm tra điểm $P$ có thuộc $\Delta$ không:** thay tọa độ $P$ vào cả ba phương trình, giải $t$ từ một phương trình rồi thử hai phương trình còn lại. Thuộc $\Delta$ khi và chỉ khi **cùng một giá trị $t$** thỏa cả ba.

> [!vi-du] Ví dụ 2
> Cho đường thẳng $\Delta:\begin{cases}x=2-t\\y=-1+3t\\z=4\end{cases}$
>
> a) Chỉ ra một điểm thuộc $\Delta$ và một VTCP của $\Delta$.
>
> b) Hai điểm $A(0;\,5;\,4)$ và $B(1;\,2;\,5)$ có thuộc $\Delta$ không?
>
> c) Tìm điểm thuộc $\Delta$ có tung độ bằng $8$.

> [!goi-y] Gợi ý 1
> Viết đầy đủ: $x=2+(-1)t$, $y=-1+3t$, $z=4+0t$. Phương trình $z=4$ "không có $t$", nghĩa là hệ số của $t$ bằng $0$.

> [!goi-y] Gợi ý 2
> b) Từ phương trình của $x$ tìm $t$, rồi thử vào $y$ và $z$.

> [!loi-giai] Lời giải
> a) Ứng với $t=0$: $M_0(2;\,-1;\,4)\in\Delta$. VTCP $\vec u=(-1;\,3;\,0)$.
>
> b) Với $A$: $2-t=0\Rightarrow t=2$, khi đó $y=-1+6=5$ ✓ và $z=4$ ✓. Vậy $A\in\Delta$.
> Với $B$: $2-t=1\Rightarrow t=1$, $y=-1+3=2$ ✓ nhưng $z=4\ne5$ ✗. Vậy $B\notin\Delta$.
>
> c) $-1+3t=8\Rightarrow t=3$, điểm cần tìm là $(-1;\,8;\,4)$.

> [!bay] Ba lỗi hay gặp
> - Đọc VTCP từ số đứng một mình, ví dụ ghi $\vec u=(2;\,-1;\,4)$ — đó là **điểm**, không phải VTCP.
> - Phương trình $z=4$ (thiếu $t$) thì tọa độ thứ ba của VTCP là $0$, chứ không phải $4$.
> - Kiểm tra điểm chỉ thử một hoặc hai phương trình. Điểm $B$ ở trên thỏa $x$ và $y$ nhưng **không** thuộc $\Delta$.

**Phương trình tham số không duy nhất.** Đổi điểm $M_0$ (lấy điểm khác trên $\Delta$) hoặc đổi VTCP (nhân với $k\ne0$) đều cho một hệ khác nhưng vẫn là cùng một đường thẳng. Chẳng hạn $\Delta$ ở Ví dụ 2 cũng có phương trình $x=s$, $y=5-3s$, $z=4$ (qua $A(0;\,5;\,4)$, VTCP $(1;\,-3;\,0)$). Vì vậy, gặp câu trắc nghiệm "phương trình nào là phương trình của $\Delta$", đừng tìm phương án "giống hệt" — hãy kiểm tra **VTCP cùng phương** và **một điểm thuộc $\Delta$**.

> [!vi-du] Ví dụ 3 (drone bay thẳng đều)
> Chọn hệ $Oxyz$ (đơn vị mét, $Oz$ hướng thẳng lên). Một drone cất cánh từ $A(10;\,-5;\,0)$ và bay thẳng đều, mỗi giây dịch chuyển vectơ $\vec v=(2;\,1;\,3)$.
>
> a) Viết tọa độ của drone sau $t$ giây.
>
> b) Khi drone ở độ cao $45$ m, nó ở vị trí nào?
>
> c) Drone có bay qua điểm $C(30;\,5;\,30)$ không? Qua điểm $D(26;\,3;\,25)$ không?

> [!goi-y] Gợi ý 1
> Vị trí sau $t$ giây là $A+t\vec v$. "Độ cao" là cao độ $z$.

> [!goi-y] Gợi ý 2
> c) Tìm $t$ từ phương trình của $x$, rồi thử $y$ và $z$.

> [!loi-giai] Lời giải
> a) $x=10+2t$, $y=-5+t$, $z=3t$ (với $t\ge0$).
>
> b) $3t=45\Rightarrow t=15$, vị trí $(40;\,10;\,45)$.
>
> c) Với $C$: $10+2t=30\Rightarrow t=10$, $y=5$ ✓, $z=30$ ✓. Drone qua $C$ lúc $t=10$ s.
> Với $D$: $10+2t=26\Rightarrow t=8$, $y=3$ ✓ nhưng $z=24\ne25$. Drone **không** qua $D$ (nó bay thấp hơn $D$ đúng $1$ m tại vị trí đó).

### 1.3. Phương trình chính tắc

Từ $x=x_0+at$, $y=y_0+bt$, $z=z_0+ct$, nếu $a,b,c$ **đều khác 0** thì ta rút được $t$ từ cả ba phương trình:
$$t=\frac{x-x_0}{a}=\frac{y-y_0}{b}=\frac{z-z_0}{c}.$$
Khử $t$ đi, ta được một dạng gọn hơn. Ý nghĩa: ba tọa độ của $\overrightarrow{M_0M}$ **tỉ lệ** với ba tọa độ của $\vec u$ — đúng là "cùng phương".

> [!ghi-nho] Phương trình chính tắc (SGK tr. 43)
> Đường thẳng $\Delta$ qua $M_0(x_0;\,y_0;\,z_0)$, có VTCP $\vec u=(a;\,b;\,c)$ với $a,b,c$ **đều khác 0**:
> $$\frac{x-x_0}{a}=\frac{y-y_0}{b}=\frac{z-z_0}{c}.$$
> Tử số cho tọa độ điểm (**đổi dấu**), mẫu số cho tọa độ VTCP.

**Chuyển ngược lại dạng tham số:** đặt cả ba phân số bằng $t$.

> [!vi-du] Ví dụ 4
> Cho $\Delta:\dfrac{x+2}{3}=\dfrac{y-1}{-2}=\dfrac{z}{4}$.
>
> a) Chỉ ra một điểm và một VTCP của $\Delta$, rồi viết phương trình tham số của $\Delta$.
>
> b) Điểm $E(4;\,-3;\,8)$ có thuộc $\Delta$ không?

> [!goi-y] Gợi ý 1
> Viết $x+2=x-(-2)$ và $z=z-0$.

> [!goi-y] Gợi ý 2
> b) Thay tọa độ $E$ vào ba phân số, xem ba giá trị có bằng nhau không.

> [!loi-giai] Lời giải
> a) $\Delta$ qua $M_0(-2;\,1;\,0)$, VTCP $\vec u=(3;\,-2;\,4)$. Đặt ba phân số bằng $t$:
> $$\begin{cases}x=-2+3t\\y=1-2t\\z=4t\end{cases}$$
> b) $\dfrac{4+2}{3}=2$, $\dfrac{-3-1}{-2}=2$, $\dfrac84=2$. Ba giá trị bằng nhau (cùng $t=2$) nên $E\in\Delta$.

> [!bay] Đọc phương trình chính tắc "chưa chuẩn"
> Đề hay cho dạng $d:\dfrac{1-x}{2}=\dfrac{y+3}{1}=\dfrac{2z-4}{6}$. Phải đưa về dạng chuẩn "$x$, $y$, $z$ có hệ số 1 trên tử" rồi mới đọc:
> - $\dfrac{1-x}{2}=\dfrac{x-1}{-2}$ (đổi dấu cả tử và mẫu);
> - $\dfrac{2z-4}{6}=\dfrac{z-2}{3}$ (chia cả tử và mẫu cho 2).
>
> Vậy $d$ qua $(1;\,-3;\,2)$, VTCP $(-2;\,1;\,3)$ — **không phải** $(2;\,1;\,6)$.

> [!vi-du] Ví dụ 5
> a) Viết phương trình tham số và phương trình chính tắc của đường thẳng qua $M(3;\,0;\,-2)$, có VTCP $\vec u=(1;\,-4;\,2)$.
>
> b) Làm lại với đường thẳng qua $N(1;\,2;\,-1)$, có VTCP $\vec v=(2;\,0;\,-1)$.

> [!goi-y] Gợi ý 1
> Thay thẳng vào hai công thức, chú ý $z-(-2)=z+2$, $y-0=y$.

> [!goi-y] Gợi ý 2
> b) VTCP có một tọa độ bằng $0$. Phương trình chính tắc cần điều kiện gì?

> [!loi-giai] Lời giải
> a) Tham số: $x=3+t$, $y=-4t$, $z=-2+2t$. Chính tắc: $\dfrac{x-3}{1}=\dfrac{y}{-4}=\dfrac{z+2}{2}$.
>
> b) Tham số: $x=1+2t$, $y=2$, $z=-1-t$. Vì tọa độ thứ hai của $\vec v$ bằng $0$ nên đường thẳng này **không có** phương trình chính tắc (không thể chia cho $0$).

> [!meo] Khi nào dùng dạng nào?
> - **Tham số**: dùng khi cần **lấy điểm** trên đường thẳng ("điểm $M\in\Delta$" thì đặt $M(x_0+at;\,y_0+bt;\,z_0+ct)$), tìm giao điểm, bài chuyển động. Dạng này **luôn** viết được.
> - **Chính tắc**: gọn, hay xuất hiện trong đề, kiểm tra điểm thuộc nhanh (ba phân số bằng nhau).

### 1.4. Lập phương trình đường thẳng

Mọi bài lập phương trình đường thẳng đều quy về **một khuôn**: tìm **một điểm** và **một VTCP**. Cái khó chỉ là đọc ra VTCP từ dữ kiện.

**Qua hai điểm phân biệt $A$, $B$.** Đường thẳng $AB$ nhận $\overrightarrow{AB}$ làm VTCP.

> [!ghi-nho] Đường thẳng qua hai điểm (SGK tr. 44)
> Qua $A_1(x_1;\,y_1;\,z_1)$ và $A_2(x_2;\,y_2;\,z_2)$, VTCP $\overrightarrow{A_1A_2}=(x_2-x_1;\,y_2-y_1;\,z_2-z_1)$:
> - Tham số: $x=x_1+(x_2-x_1)t$, $y=y_1+(y_2-y_1)t$, $z=z_1+(z_2-z_1)t$.
> - Nếu $x_1\ne x_2$, $y_1\ne y_2$, $z_1\ne z_2$, chính tắc: $\dfrac{x-x_1}{x_2-x_1}=\dfrac{y-y_1}{y_2-y_1}=\dfrac{z-z_1}{z_2-z_1}$.

Với dạng tham số này, $t=0$ cho điểm $A_1$, $t=1$ cho điểm $A_2$, và $0<t<1$ cho các điểm **nằm giữa** $A_1$ và $A_2$. Ý này rất có ích ở Ví dụ 8.

> [!vi-du] Ví dụ 6
> Cho $A(-1;\,2;\,3)$, $B(1;\,-2;\,4)$, $C(3;\,-6;\,5)$.
>
> a) Viết phương trình tham số và chính tắc của đường thẳng $AB$.
>
> b) Ba điểm $A,B,C$ có thẳng hàng không?

> [!goi-y] Gợi ý 1
> $\overrightarrow{AB}=(2;\,-4;\,1)$, lấy điểm đi qua là $A$.

> [!goi-y] Gợi ý 2
> b) $A,B,C$ thẳng hàng $\iff C$ thuộc đường thẳng $AB$.

> [!loi-giai] Lời giải
> a) Tham số: $x=-1+2t$, $y=2-4t$, $z=3+t$. Chính tắc: $\dfrac{x+1}{2}=\dfrac{y-2}{-4}=\dfrac{z-3}{1}$.
>
> b) Thay $C$: $\dfrac{3+1}{2}=2$, $\dfrac{-6-2}{-4}=2$, $\dfrac{5-3}{1}=2$. Cùng bằng $2$ nên $C\in AB$: ba điểm **thẳng hàng** (và $C$ ứng với $t=2$, nằm ngoài đoạn $AB$, về phía $B$).

**Qua một điểm và vuông góc với một mặt phẳng.** Đường thẳng $\Delta\perp(P)$ và giá của $\vec n_P$ cũng vuông góc với $(P)$, nên chúng song song hoặc trùng nhau. Do đó **VTPT của $(P)$ là VTCP của $\Delta$** (SGK tr. 44).

**Qua một điểm và song song với đường thẳng $d$.** Hai đường song song có cùng hướng, nên $\Delta$ nhận **VTCP của $d$** làm VTCP.

> [!vi-du] Ví dụ 7
> Cho điểm $M(3;\,1;\,-2)$ và mặt phẳng $(P):2x-y+2z+8=0$.
>
> a) Viết phương trình tham số của đường thẳng $\Delta$ đi qua $M$ và vuông góc với $(P)$.
>
> b) Viết phương trình đường thẳng $d$ đi qua gốc $O$ và song song với $\Delta$.

> [!goi-y] Gợi ý 1
> a) $\vec n_P=(2;\,-1;\,2)$ là VTCP của $\Delta$.

> [!goi-y] Gợi ý 2
> b) $d\parallel\Delta$ nên dùng lại VTCP của $\Delta$, chỉ đổi điểm đi qua.

> [!loi-giai] Lời giải
> a) $\Delta:\ x=3+2t$, $y=1-t$, $z=-2+2t$.
>
> b) $d:\ x=2t$, $y=-t$, $z=2t$, hay chính tắc $\dfrac x2=\dfrac{y}{-1}=\dfrac z2$. ($O\notin\Delta$ vì $3+2t=0$ cho $t=-\frac32$ nhưng khi đó $y=\frac52\ne0$, nên $d$ thật sự song song chứ không trùng $\Delta$.)

> [!bay]
> "Vuông góc với mặt phẳng" thì lấy **VTPT** làm VTCP. Nhiều bạn nhớ nhầm sang "song song với mặt phẳng" — trường hợp đó VTCP phải **vuông góc** với VTPT, không lấy thẳng VTPT được (xem Dạng 1).

### 1.5. Giao điểm của đường thẳng và mặt phẳng

Đây là kĩ thuật SGK dùng ở Vận dụng 1 (SGK tr. 45) và là dạng bài thi rất phổ biến. Ý tưởng: điểm chung $I$ vừa thuộc $\Delta$ (nên có dạng $I(x_0+at;\,y_0+bt;\,z_0+ct)$), vừa thuộc mặt phẳng (nên thỏa phương trình mặt phẳng).

> [!ghi-nho] Cách tìm giao điểm của $\Delta$ và $(P)$
> 1. Viết $\Delta$ dưới dạng tham số.
> 2. Thay $x,y,z$ theo $t$ vào phương trình $(P)$, được một phương trình **bậc nhất** ẩn $t$.
> 3. Giải ra $t$, thay lại vào phương trình tham số để có tọa độ giao điểm.

![Hình 2. Mắt M, vật N và tấm bìa tròn tâm O bán kính 1,5 trên mặt phẳng (Oxy): đường thẳng MN cắt (Oxy) tại D nằm trong tấm bìa và nằm giữa M, N](h2-tam-nhin.svg)

> [!vi-du] Ví dụ 8 (tấm bìa có che tầm nhìn không?)
> Trong hệ $Oxyz$, mắt người quan sát ở $M(2;\,-1;\,4)$, vật cần quan sát ở $N(-2;\,3;\,-4)$. Một tấm bìa hình tròn tâm $O$, bán kính $1{,}5$, nằm trong mặt phẳng $(Oxy)$. Tấm bìa có che khuất vật đối với người quan sát không?

> [!goi-y] Gợi ý 1
> Ánh sáng từ $N$ tới mắt đi theo **đoạn thẳng** $MN$. Tìm giao điểm $D$ của đường thẳng $MN$ với $(Oxy):z=0$.

> [!goi-y] Gợi ý 2
> Tấm bìa che khi và chỉ khi $D$ **nằm trong tấm bìa** ($OD\le1{,}5$) **và** $D$ **nằm giữa** $M$ và $N$.

> [!loi-giai] Lời giải
> $\overrightarrow{MN}=(-4;\,4;\,-8)$, chọn VTCP gọn $\vec u=(-1;\,1;\,-2)$ (nên $\overrightarrow{MN}=4\vec u$). Đường thẳng $MN$: $x=2-t$, $y=-1+t$, $z=4-2t$.
> - $M$ ứng với $t=0$, $N$ ứng với $t=4$.
> - Giao với $z=0$: $4-2t=0\Rightarrow t=2$, nên $D(0;\,1;\,0)$.
> - $0<2<4$ nên $D$ nằm giữa $M$ và $N$ (thực ra là trung điểm $MN$).
> - $OD=\sqrt{0+1+0}=1<1{,}5$ nên $D$ nằm trong tấm bìa.
>
> Kết luận: tấm bìa **che khuất** vật.

**Ba khả năng (mở rộng, ngoài SGK).** Phương trình ẩn $t$ ở bước 2 luôn có dạng $pt+q=0$:

| Phương trình $pt+q=0$ | Vị trí của $\Delta$ và $(P)$ | Dấu hiệu vectơ |
|---|---|---|
| Có đúng 1 nghiệm ($p\ne0$) | cắt nhau tại 1 điểm | $\vec u\cdot\vec n\ne0$ |
| Vô nghiệm ($p=0$, $q\ne0$) | song song | $\vec u\cdot\vec n=0$, điểm của $\Delta$ không thuộc $(P)$ |
| Vô số nghiệm ($p=q=0$) | $\Delta$ nằm trong $(P)$ | $\vec u\cdot\vec n=0$, điểm của $\Delta$ thuộc $(P)$ |

Vì sao $p=\vec u\cdot\vec n$? Vì hệ số của $t$ sau khi thay là $Aa+Bb+Cc$. Nó bằng $0$ đúng khi VTCP **vuông góc** với VTPT, tức là đường thẳng "chạy dọc" mặt phẳng.

> [!vi-du] Ví dụ 9 (mở rộng)
> Cho $d:\ x=1+t$, $y=2-t$, $z=3+2t$. Xét vị trí tương đối của $d$ với mỗi mặt phẳng sau (nếu cắt, tìm giao điểm):
> $(\alpha):x+y+z-8=0$; $(\beta):x+y-5=0$; $(\gamma):x+y-3=0$.

> [!goi-y] Gợi ý 1
> Thay $x=1+t$, $y=2-t$, $z=3+2t$ vào từng phương trình rồi thu gọn.

> [!goi-y] Gợi ý 2
> Với $(\beta)$, $(\gamma)$: $x+y=(1+t)+(2-t)=3$, không còn $t$.

> [!loi-giai] Lời giải
> - $(\alpha)$: $(1+t)+(2-t)+(3+2t)-8=2t-2=0\Rightarrow t=1$. Cắt nhau tại $(2;\,1;\,5)$.
> - $(\beta)$: $3-5=-2=0$ vô lí, vô nghiệm. $d\parallel(\beta)$.
> - $(\gamma)$: $3-3=0$ đúng với mọi $t$. $d$ **nằm trong** $(\gamma)$.

> [!ung-dung] Hình chiếu vuông góc của một điểm lên mặt phẳng (mở rộng, ngoài SGK)
> Ghép 1.4 với 1.5: muốn tìm chân đường vuông góc $H$ hạ từ $M$ xuống $(P)$, ta viết đường thẳng qua $M$ nhận $\vec n_P$ làm VTCP rồi tìm giao điểm với $(P)$. Ở Ví dụ 7: thay $x=3+2t$, $y=1-t$, $z=-2+2t$ vào $(P)$ được $9t+9=0$, $t=-1$, nên $H(1;\,2;\,-4)$. Kiểm tra: $MH=\sqrt{4+1+4}=3$, đúng bằng $d(M,(P))=\frac{\lvert6-1-4+8\rvert}{3}=3$ tính theo công thức Bài 14 ✓.

## 2. Hai đường thẳng vuông góc

Ở lớp 11, góc giữa hai đường thẳng trong không gian bằng góc giữa hai đường thẳng **cùng đi qua một điểm** và lần lượt song song với chúng. Hai VTCP chính là "đại diện hướng" của hai đường thẳng, nên:

> [!ghi-nho] Điều kiện vuông góc (SGK tr. 45)
> $\Delta_1$, $\Delta_2$ có VTCP $\vec u_1=(a_1;\,b_1;\,c_1)$, $\vec u_2=(a_2;\,b_2;\,c_2)$. Khi đó
> $$\Delta_1\perp\Delta_2\iff\vec u_1\cdot\vec u_2=0\iff a_1a_2+b_1b_2+c_1c_2=0.$$

Lưu ý: trong không gian, "vuông góc" **không** đòi hỏi hai đường thẳng phải gặp nhau. Hai đường thẳng vuông góc có thể cắt nhau, cũng có thể **chéo nhau** (như một cạnh đáy và một cạnh bên không chung đỉnh của hình lập phương).

> [!vi-du] Ví dụ 10
> a) Chứng minh $d_1:\ x=1+2t$, $y=-t$, $z=3+t$ vuông góc với $d_2:\dfrac{x-2}{1}=\dfrac{y+1}{3}=\dfrac{z}{1}$.
>
> b) Tìm $m$ để $d_1$ vuông góc với $d_3:\dfrac{x-1}{m}=\dfrac{y+2}{m+2}=\dfrac{z-1}{3}$.

> [!goi-y] Gợi ý 1
> $\vec u_1=(2;\,-1;\,1)$, $\vec u_2=(1;\,3;\,1)$, $\vec u_3=(m;\,m+2;\,3)$.

> [!goi-y] Gợi ý 2
> b) Giải $\vec u_1\cdot\vec u_3=0$, rồi kiểm tra mẫu số của $d_3$ khác $0$.

> [!loi-giai] Lời giải
> a) $\vec u_1\cdot\vec u_2=2\cdot1+(-1)\cdot3+1\cdot1=0$ nên $d_1\perp d_2$.
>
> b) $\vec u_1\cdot\vec u_3=2m-(m+2)+3=m+1=0\iff m=-1$. Khi đó $\vec u_3=(-1;\,1;\,3)$, các mẫu số đều khác $0$ ✓. Vậy $m=-1$.
>
> (Ở mục 3 em sẽ thấy $d_1$ và $d_2$ thực ra **chéo nhau** — vuông góc mà không cắt nhau.)

> [!ung-dung] Kiểm tra thanh giằng vuông góc
> Kĩ sư thiết kế giàn giáo, khung nhà thép bằng phần mềm 3D. Mỗi thanh được lưu bằng tọa độ hai đầu mút, tức là một đoạn thẳng có VTCP $\overrightarrow{AB}$. Lệnh "kiểm tra vuông góc" của phần mềm chính là tính $\overrightarrow{AB}\cdot\overrightarrow{CD}$ và so với $0$.

## 3. Vị trí tương đối giữa hai đường thẳng

Trong mặt phẳng, hai đường thẳng chỉ có thể song song, trùng nhau hoặc cắt nhau. Trong không gian có thêm khả năng thứ tư: **chéo nhau** — không song song mà cũng không gặp nhau (như hai con đường ở nút giao thông khác mức: một đường đi trên cầu vượt, một đường đi bên dưới).

![Hình 3. Bốn vị trí tương đối của hai đường thẳng trong không gian và dấu hiệu nhận biết](h3-vi-tri.svg)

### 3.1. Cách xét bằng tích có hướng (SGK)

Cho $\Delta_1$ qua $A_1$, VTCP $\vec u_1$; $\Delta_2$ qua $A_2$, VTCP $\vec u_2$.

**Bước 1: hai đường có cùng hướng không?** Tính $[\vec u_1,\vec u_2]$.
- Nếu $[\vec u_1,\vec u_2]=\vec 0$ ($\vec u_1,\vec u_2$ cùng phương), hai đường thẳng **song song hoặc trùng**. Kiểm tra một điểm: $A_1\in\Delta_2$ thì trùng, $A_1\notin\Delta_2$ thì song song.

**Bước 2: nếu không cùng hướng, chúng có "cùng nằm trong một mặt phẳng" không?** Vectơ $\vec n=[\vec u_1,\vec u_2]$ vuông góc với cả hai hướng, nên mặt phẳng $(Q)$ qua $A_1$ nhận $\vec n$ làm VTPT chứa trọn $\Delta_1$ và song song với hướng của $\Delta_2$.
- Nếu $\overrightarrow{A_1A_2}\cdot\vec n=0$ thì $A_2$ cũng nằm trên $(Q)$, nên $\Delta_2$ nằm trong $(Q)$. Hai đường thẳng cùng nằm trong một mặt phẳng, không song song, nên **cắt nhau**.
- Nếu $\overrightarrow{A_1A_2}\cdot\vec n\ne0$ thì $\Delta_2$ nằm ngoài $(Q)$ (song song với $(Q)$), không thể gặp $\Delta_1$ nằm trong $(Q)$. Hai đường thẳng **chéo nhau**.

> [!ghi-nho] Vị trí tương đối của hai đường thẳng (SGK tr. 46)
> - $\Delta_1\parallel\Delta_2\iff\vec u_1$ cùng phương $\vec u_2$ và $A_1\notin\Delta_2$.
> - $\Delta_1\equiv\Delta_2\iff\vec u_1$ cùng phương $\vec u_2$ và $A_1\in\Delta_2$.
> - $\Delta_1$ cắt $\Delta_2\iff[\vec u_1,\vec u_2]\ne\vec 0$ và $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=0$.
> - $\Delta_1$ chéo $\Delta_2\iff\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]\ne0$.

> [!vi-du] Ví dụ 11 (song song hay trùng?)
> Cho $d_1:\dfrac{x-1}{2}=\dfrac{y+1}{-1}=\dfrac{z-3}{2}$, $d_2:\ x=3+4s$, $y=-2-2s$, $z=5+4s$ và $d_3:\ x=2s$, $y=1-s$, $z=1+2s$. Xét vị trí tương đối của $d_1$ với $d_2$ và của $d_1$ với $d_3$.

> [!goi-y] Gợi ý 1
> $\vec u_1=(2;\,-1;\,2)$, $\vec u_2=(4;\,-2;\,4)$, $\vec u_3=(2;\,-1;\,2)$. Có cùng phương không?

> [!goi-y] Gợi ý 2
> Lấy $A_1(1;\,-1;\,3)\in d_1$, thử xem $A_1$ có thuộc $d_2$, $d_3$ không.

> [!loi-giai] Lời giải
> $\vec u_2=2\vec u_1$, $\vec u_3=\vec u_1$, nên ba VTCP cùng phương.
> - $A_1\in d_2$? $3+4s=1\Rightarrow s=-\frac12$, $y=-2+1=-1$ ✓, $z=5-2=3$ ✓. Vậy $d_1\equiv d_2$.
> - $A_1\in d_3$? $2s=1\Rightarrow s=\frac12$, $y=1-\frac12=\frac12\ne-1$ ✗. Vậy $d_1\parallel d_3$.

> [!vi-du] Ví dụ 12 (cắt nhau, tìm giao điểm)
> Cho $\Delta_1:\ x=1+t$, $y=-1+2t$, $z=2-t$ và $\Delta_2:\ x=1+s$, $y=5-s$, $z=-4+2s$. Chứng minh $\Delta_1$ và $\Delta_2$ cắt nhau và tìm giao điểm.

> [!goi-y] Gợi ý 1
> $A_1(1;\,-1;\,2)$, $\vec u_1=(1;\,2;\,-1)$; $A_2(1;\,5;\,-4)$, $\vec u_2=(1;\,-1;\,2)$. Tính $[\vec u_1,\vec u_2]$ bằng mẹo che cột.

> [!goi-y] Gợi ý 2
> Tìm giao điểm: giải hệ $1+t=1+s$, $-1+2t=5-s$ (hai phương trình, hai ẩn), rồi thử phương trình thứ ba.

> [!loi-giai] Lời giải
> $[\vec u_1,\vec u_2]=\big(2\cdot2-(-1)(-1);\ (-1)\cdot1-1\cdot2;\ 1\cdot(-1)-1\cdot2\big)=(3;\,-3;\,-3)\ne\vec 0$.
> $\overrightarrow{A_1A_2}=(0;\,6;\,-6)$, $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=0-18+18=0$. Vậy $\Delta_1$ cắt $\Delta_2$.
>
> Giao điểm: từ $1+t=1+s$ có $t=s$, thay vào $-1+2t=5-t$ được $t=2$, $s=2$. Thử $z$: $2-2=0$ và $-4+4=0$ ✓. Giao điểm $I(3;\,3;\,0)$.

### 3.2. Cách xét bằng hệ phương trình

SGK (tr. 47) còn nêu một cách khác: viết hai đường thẳng dạng tham số với **hai tham số khác tên** $t$ và $s$, rồi xét hệ (*) gồm ba phương trình "$x$ bằng $x$, $y$ bằng $y$, $z$ bằng $z$".

| Hệ (*) ẩn $t,s$ | Vị trí |
|---|---|
| Có nghiệm duy nhất | cắt nhau (nghiệm cho luôn giao điểm) |
| Có vô số nghiệm | trùng nhau |
| Vô nghiệm và $\vec u_1,\vec u_2$ cùng phương | song song |
| Vô nghiệm và $\vec u_1,\vec u_2$ không cùng phương | chéo nhau |

> [!bay] Dùng chung một tham số
> Nếu hai đường thẳng đều viết bằng chữ $t$, phải **đổi tên** một tham số thành $s$ trước khi lập hệ. Giải hệ $x_1(t)=x_2(t)$… với **cùng** $t$ là đi tìm "hai vật chuyển động gặp nhau **cùng lúc**", một câu hỏi khác hẳn (xem Ví dụ 14).

> [!vi-du] Ví dụ 13 (chéo nhau)
> Xét vị trí tương đối của $\Delta_1:\ x=t$, $y=1+t$, $z=2-t$ và $\Delta_2:\dfrac{x-2}{1}=\dfrac{y}{-1}=\dfrac{z-1}{2}$ bằng cả hai cách.

> [!goi-y] Gợi ý 1
> Cách 1: $A_1(0;\,1;\,2)$, $\vec u_1=(1;\,1;\,-1)$; $A_2(2;\,0;\,1)$, $\vec u_2=(1;\,-1;\,2)$.

> [!goi-y] Gợi ý 2
> Cách 2: $\Delta_2$ dạng tham số $x=2+s$, $y=-s$, $z=1+2s$. Giải hai phương trình đầu, thử phương trình thứ ba.

> [!loi-giai] Lời giải
> **Cách 1.** $[\vec u_1,\vec u_2]=\big(1\cdot2-(-1)(-1);\ (-1)\cdot1-1\cdot2;\ 1\cdot(-1)-1\cdot1\big)=(1;\,-3;\,-2)\ne\vec 0$.
> $\overrightarrow{A_1A_2}=(2;\,-1;\,-1)$, tích vô hướng $2+3+2=7\ne0$. Vậy $\Delta_1$, $\Delta_2$ **chéo nhau**.
>
> **Cách 2.** Hệ $t=2+s$, $1+t=-s$, $2-t=1+2s$. Từ hai phương trình đầu: $1+2+s=-s\Rightarrow s=-\frac32$, $t=\frac12$. Thử phương trình ba: $2-\frac12=\frac32$ còn $1+2\cdot\left(-\frac32\right)=-2$, khác nhau. Hệ vô nghiệm, VTCP không cùng phương, nên chéo nhau ✓.

Quay lại Ví dụ 10: $d_1$ qua $(1;\,0;\,3)$, $d_2$ qua $(2;\,-1;\,0)$, $[\vec u_1,\vec u_2]=(-4;\,-1;\,7)$, và $(1;\,-1;\,-3)\cdot(-4;\,-1;\,7)=-4+1-21=-24\ne0$. Vậy hai đường thẳng đó vuông góc nhưng **chéo nhau**.

> [!vi-du] Ví dụ 14 (hai drone có va chạm không?)
> Hai drone bay thẳng đều cùng xuất phát lúc $t=0$ (đơn vị mét, giây). Drone 1 từ $A(0;\,0;\,10)$ với vectơ vận tốc $\vec v_1=(3;\,4;\,1)$; drone 2 từ $B(21;\,17;\,9)$ với $\vec v_2=(-2;\,1;\,2)$.
>
> a) Hai đường bay có cắt nhau không? Nếu có, tìm giao điểm.
>
> b) Hai drone có va chạm không?

> [!goi-y] Gợi ý 1
> a) Đường bay 1: $(3t;\,4t;\,10+t)$; đường bay 2: $(21-2s;\,17+s;\,9+2s)$. Giải hệ ẩn $t,s$.

> [!goi-y] Gợi ý 2
> b) Va chạm nghĩa là **cùng một thời điểm** ở **cùng một chỗ**: cần $t=s$.

> [!loi-giai] Lời giải
> a) Hệ: $3t=21-2s$, $4t=17+s$, $10+t=9+2s$. Từ phương trình hai: $s=4t-17$, thay vào phương trình một: $3t=21-8t+34\Rightarrow t=5$, $s=3$. Thử phương trình ba: $10+5=15$, $9+6=15$ ✓.
> Hai đường bay **cắt nhau** tại $P(15;\,20;\,15)$.
>
> b) Drone 1 tới $P$ lúc $t=5$ s, drone 2 tới $P$ lúc $t=3$ s. Không cùng lúc nên **không va chạm** (drone 2 đi qua giao điểm trước 2 giây).

> [!ung-dung] Nút giao thông khác mức
> Trên bản thiết kế, nếu trục của hai con đường **cắt nhau** thì xe phải gặp nhau ở cùng một điểm, cần đèn tín hiệu hoặc vòng xuyến. Nếu hai trục **chéo nhau**, chúng không có điểm chung: một đường đi trên cầu vượt, một đường đi dưới, gọi là nút giao **khác mức** (SGK tr. 49). Người thiết kế kiểm tra đúng bằng dấu của $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$.

## Dạng bài thi hay gặp

### Dạng 1. Lập phương trình đường thẳng: "đề cho gì thì VTCP là gì?"

- **Nhận biết:** "phương trình đường thẳng $\Delta$ là…", "$\Delta:\frac{x-a}{m}=\ldots$, tính…".
- **Phương pháp:** tìm điểm đi qua và VTCP theo bảng, thay công thức, rồi thử lại.

| Đề cho | VTCP của $\Delta$ |
|---|---|
| Qua hai điểm $A$, $B$ | $\overrightarrow{AB}$ |
| Song song với đường thẳng $d$ | $\vec u_d$ |
| Vuông góc với mặt phẳng $(P)$ | $\vec n_P$ |
| Song song với trục $Ox$ / $Oy$ / $Oz$ | $\vec i$ / $\vec j$ / $\vec k$ |
| Vuông góc với hai đường thẳng $d_1$, $d_2$ | $[\vec u_1,\vec u_2]$ |
| Song song với $(P)$ và vuông góc với $d$ | $[\vec n_P,\vec u_d]$ |
| Song song với cả $(P)$ và $(Q)$ (cùng phương giao tuyến) | $[\vec n_P,\vec n_Q]$ |

**Vì sao dùng tích có hướng?** $\Delta\parallel(P)$ nghĩa là $\vec u\perp\vec n_P$; $\Delta\perp d$ nghĩa là $\vec u\perp\vec u_d$. Cần một vectơ **vuông góc với cả hai** — đó đúng là việc tích có hướng làm.

- **Bẫy:** "song song với $(P)$" mà lấy $\vec n_P$ làm VTCP (sai — đó là "vuông góc"). Quên kiểm tra điểm đi qua không nằm trên $(P)$ (nếu nằm trên thì $\Delta$ nằm trong $(P)$, không song song).

> [!vi-du] Ví dụ 15
> Viết phương trình đường thẳng $\Delta$ đi qua $A(1;\,0;\,-1)$, song song với mặt phẳng $(P):x+2y-z+3=0$ và vuông góc với đường thẳng $d:\dfrac{x+1}{2}=\dfrac{y-3}{1}=\dfrac{z}{-1}$.

> [!goi-y] Gợi ý 1
> $\vec n_P=(1;\,2;\,-1)$, $\vec u_d=(2;\,1;\,-1)$. VTCP của $\Delta$ vuông góc với cả hai.

> [!goi-y] Gợi ý 2
> Tính $[\vec n_P,\vec u_d]$ và rút gọn dấu.

> [!loi-giai] Lời giải
> $[\vec n_P,\vec u_d]=\big(2\cdot(-1)-(-1)\cdot1;\ (-1)\cdot2-1\cdot(-1);\ 1\cdot1-2\cdot2\big)=(-1;\,-1;\,-3)$, chọn $\vec u=(1;\,1;\,3)$.
> $\Delta:\ x=1+t$, $y=t$, $z=-1+3t$.
> Thử lại: $\vec u\cdot\vec n_P=1+2-3=0$ ✓, $\vec u\cdot\vec u_d=2+1-3=0$ ✓, và $A\notin(P)$ vì $1+0+1+3=5\ne0$, nên $\Delta$ đúng là song song với $(P)$.

### Dạng 2. Giao điểm, hình chiếu, điểm đối xứng

Giao điểm của đường thẳng với mặt phẳng là kĩ thuật SGK dùng ở Vận dụng 1. Hình chiếu và điểm đối xứng là phần **mở rộng, ngoài SGK**, ghép từ các kĩ thuật trong bài; dạng này hay gặp trong đề thi nên em nên luyện.

- **Nhận biết:** "tọa độ giao điểm của $d$ và $(P)$", "hình chiếu vuông góc của $A$ lên $(P)$ / lên $d$", "điểm đối xứng của $A$ qua $(P)$". Đáp số thường hỏi dạng "$a+b+c$".
- **Phương pháp:**
  - Giao điểm: thế tham số vào mặt phẳng (mục 1.5).
  - Hình chiếu $H$ của $A$ lên $(P)$ (mở rộng): đường thẳng qua $A$, VTCP $\vec n_P$, giao với $(P)$.
  - Điểm đối xứng $A'$ qua $(P)$ (mở rộng): $H$ là trung điểm $AA'$, nên $A'=2H-A$ (từng tọa độ).
  - Hình chiếu $H$ của $A$ lên đường thẳng $d$ (mở rộng): đặt $H$ theo tham số của $d$, giải $\overrightarrow{AH}\cdot\vec u_d=0$.
- **Bẫy:** lấy nhầm $H$ làm $A'$; quên nhân 2 khi tính $A'=2H-A$; khi tìm hình chiếu lên đường thẳng $d$, nhân $\overrightarrow{AH}$ với một vectơ khác thay vì với VTCP $\vec u_d$.

> [!vi-du] Ví dụ 16 (mở rộng)
> a) Tìm điểm $A'$ đối xứng với $A(3;\,-1;\,2)$ qua mặt phẳng $(P):x+2y-2z+12=0$.
>
> b) Tìm hình chiếu vuông góc $H$ của $B(2;\,0;\,-1)$ lên đường thẳng $d:\ x=1+2t$, $y=-1+t$, $z=2-t$, rồi tính khoảng cách từ $B$ đến $d$ (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> a) Đường thẳng qua $A$, VTCP $(1;\,2;\,-2)$: $x=3+t$, $y=-1+2t$, $z=2-2t$. Thế vào $(P)$.

> [!goi-y] Gợi ý 2
> b) $H(1+2t;\,-1+t;\,2-t)$, $\overrightarrow{BH}=(2t-1;\,t-1;\,3-t)$. Giải $\overrightarrow{BH}\cdot(2;\,1;\,-1)=0$.

> [!loi-giai] Lời giải
> a) $(3+t)+2(-1+2t)-2(2-2t)+12=9t+9=0\Rightarrow t=-1$, hình chiếu $H(2;\,-3;\,4)$.
> $A'=2H-A=(4-3;\,-6+1;\,8-2)=(1;\,-5;\,6)$.
>
> b) $2(2t-1)+(t-1)-(3-t)=6t-6=0\Rightarrow t=1$, nên $H(3;\,0;\,1)$.
> $BH=\sqrt{1^2+0^2+2^2}=\sqrt5\approx2{,}24$. Đó là khoảng cách từ $B$ đến $d$.

### Dạng 3. Vị trí tương đối có tham số (Đúng/Sai)

- **Nhận biết:** hai đường thẳng chứa tham số $m$; các ý hỏi song song, vuông góc, cắt nhau, chéo nhau.
- **Phương pháp:** vuông góc giải $\vec u_1\cdot\vec u_2=0$. Song song: giải $\vec u_2=k\vec u_1$ rồi **kiểm tra điểm**. Cắt nhau: giải $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=0$ rồi **loại** giá trị làm $[\vec u_1,\vec u_2]=\vec 0$.
- **Bẫy:** "vuông góc" bị hiểu thành "cắt nhau"; quên loại giá trị $m$ làm hai VTCP cùng phương khi xét cắt nhau.

> [!vi-du] Ví dụ 17 (Đúng/Sai)
> Cho $d_1:\ x=1+t$, $y=2t$, $z=-1+t$ và $d_2:\ x=3+ms$, $y=1+4s$, $z=2+2s$. Xét các mệnh đề:
>
> a) Khi $m=2$ thì $d_1\parallel d_2$.
>
> b) Khi $m=-10$ thì $d_1\perp d_2$.
>
> c) Khi $m=-10$ thì $d_1$ và $d_2$ cắt nhau.
>
> d) Có đúng một giá trị của $m$ để $d_1$ và $d_2$ cắt nhau.

> [!goi-y] Gợi ý 1
> $A_1(1;\,0;\,-1)$, $\vec u_1=(1;\,2;\,1)$; $A_2(3;\,1;\,2)$, $\vec u_2=(m;\,4;\,2)$.

> [!goi-y] Gợi ý 2
> Tính $[\vec u_1,\vec u_2]$ theo $m$ và $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$.

> [!loi-giai] Lời giải
> a) **Đúng.** $m=2$: $\vec u_2=(2;\,4;\,2)=2\vec u_1$. Thử $A_1\in d_2$: $3+2s=1\Rightarrow s=-1$, $y=1-4=-3\ne0$. Vậy song song.
>
> b) **Đúng.** $\vec u_1\cdot\vec u_2=m+8+2=m+10=0\iff m=-10$.
>
> c) **Sai.** $[\vec u_1,\vec u_2]=(2\cdot2-1\cdot4;\ 1\cdot m-1\cdot2;\ 1\cdot4-2m)=(0;\,m-2;\,4-2m)$, $\overrightarrow{A_1A_2}=(2;\,1;\,3)$, tích vô hướng bằng $(m-2)+3(4-2m)=10-5m$. Với $m=-10$ nó bằng $60\ne0$: chéo nhau (vuông góc nhưng không cắt).
>
> d) **Sai.** $10-5m=0\iff m=2$, nhưng $m=2$ làm $[\vec u_1,\vec u_2]=\vec 0$ (song song). Vậy **không có** $m$ nào để hai đường thẳng cắt nhau: với mọi $m\ne2$ chúng chéo nhau.

### Dạng 4. Bài toán thực tế: đường bay, tia sáng, cáp treo

- **Nhận biết:** vật chuyển động thẳng đều, tia laser/tia nắng, dây cáp… kèm hệ trục và đơn vị.
- **Phương pháp:** (1) Lập phương trình tham số, nếu được thì chọn **tham số chính là thời gian**: vị trí $=$ điểm xuất phát $+\,t\cdot$vectơ vận tốc. (2) Dịch câu hỏi: "chạm đất/chạm tường" là giao với mặt phẳng; "ở độ cao $h$" là giải $z=h$; "gần nhất" là hình chiếu vuông góc. (3) Làm tròn ở bước cuối.
- **Bẫy:** dùng VTCP đã rút gọn rồi lại coi tham số là thời gian (sai tốc độ), hoặc quên điều kiện $t\ge0$ hoặc $t$ nằm trong khoảng thời gian chuyển động.

![Hình 4. Cáp treo thẳng từ ga A lên ga B; đỉnh tháp T cách cáp gần nhất tại H, TH vuông góc với AB](h4-cap-treo.svg)

> [!vi-du] Ví dụ 18 (cáp treo)
> Chọn hệ $Oxyz$ (đơn vị mét, $Oz$ hướng thẳng lên). Một tuyến cáp treo căng thẳng từ ga dưới $A(0;\,0;\,0)$ lên ga trên $B(800;\,600;\,750)$. Cabin chạy đều với tốc độ $5$ m/s, xuất phát từ $A$ lúc $t=0$.
>
> a) Tính chiều dài tuyến cáp và viết tọa độ cabin sau $t$ giây.
>
> b) Sau bao lâu cabin lên tới độ cao $450$ m?
>
> c) Đỉnh một tháp viễn thông ở $T(400;\,300;\,250)$. Tính khoảng cách ngắn nhất từ đỉnh tháp đến cáp, và cabin đi qua điểm gần tháp nhất vào lúc nào.

> [!goi-y] Gợi ý 1
> a) $AB=\sqrt{800^2+600^2+750^2}$. Mỗi giây cabin đi $5$ m dọc $\overrightarrow{AB}$, tức là dịch chuyển $\frac{5}{AB}\overrightarrow{AB}$.

> [!goi-y] Gợi ý 2
> c) Điểm gần nhất là hình chiếu $H$ của $T$ lên đường thẳng $AB$. Dùng VTCP gọn $(16;\,12;\,15)$, đặt $H(16k;\,12k;\,15k)$ và giải $\overrightarrow{TH}\cdot(16;\,12;\,15)=0$.

> [!loi-giai] Lời giải
> a) $AB=\sqrt{640\,000+360\,000+562\,500}=\sqrt{1\,562\,500}=1250$ m. Vectơ dịch chuyển mỗi giây: $\frac{5}{1250}(800;\,600;\,750)=(3{,}2;\,2{,}4;\,3)$. Tọa độ cabin: $x=3{,}2t$, $y=2{,}4t$, $z=3t$ với $0\le t\le250$.
>
> b) $3t=450\Rightarrow t=150$ s ($2$ phút $30$ giây).
>
> c) $\overrightarrow{TH}\cdot(16;\,12;\,15)=16(16k-400)+12(12k-300)+15(15k-250)=625k-13\,750=0\Rightarrow k=22$. $H(352;\,264;\,330)$, $\overrightarrow{TH}=(-48;\,-36;\,80)$, $TH=\sqrt{2304+1296+6400}=100$ m.
> Cabin ở $H$ khi $3t=330$, tức $t=110$ s.
> (Chú ý: điểm trên cáp **ngay phía trên** tháp là $(400;\,300;\,375)$, cao hơn đỉnh tháp $125$ m. Khoảng cách ngắn nhất $100$ m nhỏ hơn, vì nó đo theo phương vuông góc với cáp chứ không theo phương thẳng đứng.)

> [!em-co-biet] Đồ họa máy tính "bắn tia"
> Hình ảnh trong game và phim hoạt hình 3D hiện đại được tạo bằng kĩ thuật **dò tia** (ray tracing): với mỗi điểm ảnh, máy tính dựng một tia $x=x_0+at$, $y=y_0+bt$, $z=z_0+ct$ ($t>0$) từ "mắt" đi qua điểm ảnh đó, rồi tìm giao điểm gần nhất của tia với hàng triệu mặt phẳng nhỏ tạo nên vật thể — đúng phép thế tham số vào phương trình mặt phẳng em vừa học, lặp lại hàng tỉ lần mỗi giây.

## Tóm tắt

Với $\Delta$ qua $M_0(x_0;\,y_0;\,z_0)$, VTCP $\vec u=(a;\,b;\,c)$; $\Delta_1$ qua $A_1$, VTCP $\vec u_1$; $\Delta_2$ qua $A_2$, VTCP $\vec u_2$.

| Nội dung | Công thức / cách làm |
|---|---|
| VTCP | $\vec u\ne\vec 0$, giá song song hoặc trùng $\Delta$; $k\vec u$ cũng là VTCP |
| Tham số | $x=x_0+at$, $y=y_0+bt$, $z=z_0+ct$ |
| Chính tắc ($abc\ne0$) | $\frac{x-x_0}{a}=\frac{y-y_0}{b}=\frac{z-z_0}{c}$ |
| Qua $A$, $B$ | VTCP $\overrightarrow{AB}$ |
| Vuông góc $(P)$ | VTCP $\vec n_P$ |
| Song song $d$ | VTCP $\vec u_d$ |
| Giao với $(P)$ | thế tham số vào $(P)$, giải $t$ |
| Vuông góc | $\vec u_1\cdot\vec u_2=0$ |
| Song song / trùng | $[\vec u_1,\vec u_2]=\vec 0$; $A_1\notin\Delta_2$ / $A_1\in\Delta_2$ |
| Cắt nhau | $[\vec u_1,\vec u_2]\ne\vec 0$ và $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]=0$ |
| Chéo nhau | $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]\ne0$ |

**Sơ đồ tư duy:** đề hỏi *phương trình đường thẳng* → tìm **điểm + VTCP** (trực tiếp, hoặc tích có hướng của hai vectơ mà VTCP phải vuông góc) → thay công thức → thử lại. Đề hỏi *điểm thuộc / giao điểm* → dùng dạng tham số, giải $t$. Đề hỏi *vị trí hai đường thẳng* → tính $[\vec u_1,\vec u_2]$: bằng $\vec 0$ thì thử một điểm (song song/trùng); khác $\vec 0$ thì xét dấu $\overrightarrow{A_1A_2}\cdot[\vec u_1,\vec u_2]$ (cắt/chéo).
