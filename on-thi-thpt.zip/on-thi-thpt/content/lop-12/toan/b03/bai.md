---
title: Đường tiệm cận của đồ thị hàm số
thoi-gian: 45 phút
muc-tieu:
  - Hiểu định nghĩa tiệm cận ngang, tiệm cận đứng, tiệm cận xiên qua giới hạn, và nhận ra hình ảnh của chúng trên đồ thị
  - Tìm được các tiệm cận của hàm phân thức bậc nhất/bậc nhất và bậc hai/bậc nhất (kể cả khi phải rút gọn, có căn)
  - Tìm hệ số $a$, $b$ của tiệm cận xiên bằng giới hạn hoặc bằng phép chia đa thức
  - Đọc và đếm tiệm cận từ đồ thị, bảng biến thiên; giải bài có tham số đơn giản
  - Giải thích ý nghĩa thực tế của tiệm cận (nồng độ, chi phí trung bình, giới hạn chi phí…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Tiệm cận ngang** $y=y_0$: $\lim\limits_{x\to+\infty}f(x)=y_0$ hoặc $\lim\limits_{x\to-\infty}f(x)=y_0$ — đồ thị "nằm sát" một đường nằm ngang khi $x$ chạy rất xa.
> 2. **Tiệm cận đứng** $x=x_0$: **ít nhất một** giới hạn một bên $\lim\limits_{x\to x_0^{+}}f(x)$, $\lim\limits_{x\to x_0^{-}}f(x)$ bằng $+\infty$ hoặc $-\infty$ — đồ thị "vọt lên/lao xuống" sát một đường thẳng đứng.
> 3. **Tiệm cận xiên** $y=ax+b$ ($a\ne0$): $\lim\big[f(x)-(ax+b)\big]=0$ khi $x\to+\infty$ hoặc $x\to-\infty$; tìm bằng $a=\lim\dfrac{f(x)}{x}$, $b=\lim\big[f(x)-ax\big]$.
> 4. Hàm $y=\dfrac{ax+b}{cx+d}$ ($c\ne0$, $ad-bc\ne0$): TCĐ $x=-\dfrac dc$, TCN $y=\dfrac ac$. Hàm bậc hai/bậc nhất: **chia đa thức** $\Rightarrow$ phần thương bậc nhất là TCX.
> 5. Mẫu bằng 0 **chưa chắc** có TCĐ: phải kiểm tra giới hạn (rút gọn được thì có thể mất tiệm cận).

Pha một cốc trà thảo mộc nóng $95^\circ\text{C}$ rồi để trên bàn trong phòng $25^\circ\text{C}$. Nhiệt độ cốc trà sau $t$ phút có thể mô tả bởi $T(t)=25+70e^{-0{,}1t}$. Trà nguội dần, nhưng nguội mãi cũng **không xuống dưới** $25^\circ\text{C}$: khi $t\to+\infty$ thì $e^{-0{,}1t}\to0$ nên $T(t)\to25$. Trên đồ thị, đường cong càng về bên phải càng "ép sát" đường nằm ngang $T=25$ mà không chạm. Đường thẳng mà đồ thị tiến sát vô hạn như thế gọi là **đường tiệm cận**. Bài này học ba loại: ngang, đứng và xiên.

> [!nen-tang] Giới hạn hàm số (Toán 11) — cần thuộc trước khi học
> - $\lim\limits_{x\to\pm\infty}\dfrac{c}{x^k}=0$ (với $k>0$). Phân thức khi $x\to\pm\infty$: **chia cả tử và mẫu cho lũy thừa cao nhất của $x$ ở mẫu**.
> - **Giới hạn một bên:** $x\to x_0^{+}$ nghĩa là $x$ tiến về $x_0$ từ **bên phải** ($x>x_0$); $x\to x_0^{-}$ là từ **bên trái** ($x<x_0$).
> - **Quy tắc "số khác 0 chia cho số dần về 0":** nếu $\lim u(x)=L\ne0$ và $\lim v(x)=0$ thì $\lim\dfrac{u}{v}$ là $+\infty$ hoặc $-\infty$; **dấu** bằng dấu của $L$ nhân dấu của $v(x)$ (khi $x$ ở gần $x_0$).
> - $\sqrt{x^2}=\lvert x\rvert$: khi $x\to-\infty$ thì $\sqrt{x^2}=-x$.

## 1. Đường tiệm cận ngang

### 1.1. Từ hình ảnh đến định nghĩa

Xét $f(x)=\dfrac{4x-1}{2x+3}$. Lấy điểm $M(x;\,f(x))$ trên đồ thị và gọi $H$ là hình chiếu của $M$ lên đường thẳng $y=2$. Khi đó $MH=\lvert f(x)-2\rvert$. Biến đổi:

$$f(x)-2=\frac{4x-1-2(2x+3)}{2x+3}=\frac{-7}{2x+3}.$$

Khi $x$ rất lớn (ví dụ $x=1000$) thì $MH=\dfrac{7}{2003}\approx0{,}0035$ — gần như bằng $0$. Nghĩa là càng đi xa về bên phải, điểm $M$ càng **dính sát** đường $y=2$. Điều tương tự xảy ra khi $x\to-\infty$.

![Hình 1. Đồ thị y = (4x − 1)/(2x + 3): khi x → ±∞, khoảng cách MH từ đồ thị đến đường y = 2 dần về 0](h1-tiem-can-ngang.svg)

> [!ghi-nho] Định nghĩa (SGK tr. 20)
> Đường thẳng $y=y_0$ là **đường tiệm cận ngang** (gọi tắt: tiệm cận ngang, TCN) của đồ thị hàm số $y=f(x)$ nếu
> $$\lim_{x\to+\infty}f(x)=y_0$$
> hoặc
> $$\lim_{x\to-\infty}f(x)=y_0.$$

Chú ý chữ **"hoặc"**: chỉ cần **một phía** ($+\infty$ hoặc $-\infty$) có giới hạn hữu hạn là đủ. Vì có hai phía nên một đồ thị có **nhiều nhất 2** tiệm cận ngang.

**Cách tìm:** tính hai giới hạn $\lim\limits_{x\to+\infty}f(x)$ và $\lim\limits_{x\to-\infty}f(x)$. Giới hạn nào là một **số** thì cho một TCN.

> [!vi-du] Ví dụ 1
> Tìm tiệm cận ngang của đồ thị hàm số $y=\dfrac{4x-1}{2x+3}$.

> [!goi-y] Gợi ý 1
> Chia cả tử và mẫu cho $x$.

> [!goi-y] Gợi ý 2
> $\dfrac{1}{x}\to0$ và $\dfrac{3}{x}\to0$ khi $x\to\pm\infty$.

> [!loi-giai] Lời giải
> $$\lim_{x\to+\infty}\frac{4x-1}{2x+3}=\lim_{x\to+\infty}\frac{4-\frac1x}{2+\frac3x}=\frac42=2.$$
> Tương tự $\lim\limits_{x\to-\infty}f(x)=2$. Vậy đồ thị có **một** tiệm cận ngang là $y=2$.

> [!meo] Nhìn hệ số là ra
> Với $y=\dfrac{ax+b}{cx+d}$ thì TCN là $y=\dfrac{a}{c}$ — **tỉ số hai hệ số của $x$**. Tổng quát với phân thức đa thức: bậc tử **nhỏ hơn** bậc mẫu → TCN $y=0$; bậc tử **bằng** bậc mẫu → TCN $y=$ tỉ số hai hệ số cao nhất; bậc tử **lớn hơn** bậc mẫu → **không có** TCN.

### 1.2. Khi có căn: hai phía có thể khác nhau

> [!vi-du] Ví dụ 2
> Tìm các tiệm cận ngang của đồ thị hàm số $y=\dfrac{\sqrt{4x^2+1}}{x+3}$.

> [!goi-y] Gợi ý 1
> Đưa $x$ ra khỏi căn: $\sqrt{4x^2+1}=\sqrt{x^2}\cdot\sqrt{4+\frac{1}{x^2}}=\lvert x\rvert\sqrt{4+\frac{1}{x^2}}$.

> [!goi-y] Gợi ý 2
> Khi $x\to+\infty$ thì $\lvert x\rvert=x$; khi $x\to-\infty$ thì $\lvert x\rvert=-x$. Phải tính **riêng** hai giới hạn.

> [!loi-giai] Lời giải
> - $x\to+\infty$: $\dfrac{x\sqrt{4+\frac1{x^2}}}{x\left(1+\frac3x\right)}\to\dfrac{\sqrt4}{1}=2$.
> - $x\to-\infty$: $\dfrac{-x\sqrt{4+\frac1{x^2}}}{x\left(1+\frac3x\right)}\to-2$.
>
> Vậy đồ thị có **hai** tiệm cận ngang: $y=2$ và $y=-2$.

> [!bay] Quên dấu trừ khi $x\to-\infty$
> Nếu viết $\sqrt{4x^2+1}\approx2x$ cho cả hai phía, em sẽ chỉ tìm được $y=2$ và bỏ sót $y=-2$. Trong đề trắc nghiệm, "chỉ có $y=2$" là phương án nhiễu rất hay gặp. Có căn bậc hai chứa $x^2$ → **luôn tách hai phía**.

> [!ung-dung] Ý nghĩa của tiệm cận ngang
> TCN cho biết **giá trị "lâu dài"** của một đại lượng: nhiệt độ cốc trà tiến tới nhiệt độ phòng, nồng độ chất trong bể tiến tới nồng độ của dung dịch bơm vào, chi phí trung bình mỗi sản phẩm tiến tới chi phí biến đổi khi sản xuất rất nhiều (xem Dạng 4).

## 2. Đường tiệm cận đứng

### 2.1. Từ hình ảnh đến định nghĩa

Với $f(x)=\dfrac{4x-1}{2x+3}$ ở trên, mẫu bằng 0 khi $x=-1{,}5$. Cho $x$ tiến sát $-1{,}5$ từ bên phải (chẳng hạn $x=-1{,}499$): tử $\approx-7$, mẫu $=0{,}002$, nên $f(x)\approx-3500$. Càng sát $-1{,}5$, $f(x)$ càng âm "vô hạn" và đồ thị lao xuống, bám sát đường thẳng đứng $x=-1{,}5$ (Hình 1). Đường thẳng đứng này là **tiệm cận đứng**.

> [!ghi-nho] Định nghĩa (SGK tr. 21)
> Đường thẳng $x=x_0$ là **đường tiệm cận đứng** (gọi tắt: tiệm cận đứng, TCĐ) của đồ thị hàm số $y=f(x)$ nếu **ít nhất một** trong các điều kiện sau được thỏa mãn:
> $$\lim_{x\to x_0^{+}}f(x)=+\infty;\qquad \lim_{x\to x_0^{-}}f(x)=-\infty;$$
> $$\lim_{x\to x_0^{+}}f(x)=-\infty;\qquad \lim_{x\to x_0^{-}}f(x)=+\infty.$$

Bốn điều kiện ứng với bốn hình ảnh: tiến tới $x_0$ từ bên trái hay bên phải, đồ thị vọt lên hay lao xuống. Chỉ cần **một** trong bốn là đủ.

![Hình 2. Bốn trường hợp của tiệm cận đứng x = x₀: chỉ cần một phía của x₀ có giới hạn vô cực](h2-bon-truong-hop-tcd.svg)

**Cách tìm (với hàm phân thức):**
1. Tìm các giá trị $x_0$ làm **mẫu bằng 0** (đó là "ứng viên").
2. Với mỗi $x_0$, tính giới hạn một bên. Nếu **tử khác 0** tại $x_0$ thì chắc chắn được $\pm\infty$ → có TCĐ. Nếu **tử cũng bằng 0** thì phải rút gọn rồi tính lại — có thể **không** có TCĐ.

> [!vi-du] Ví dụ 3
> Tìm tiệm cận đứng và tiệm cận ngang của đồ thị hàm số $y=\dfrac{x+4}{2-x}$. Xác định rõ $\lim\limits_{x\to2^{-}}y$ và $\lim\limits_{x\to2^{+}}y$.

> [!goi-y] Gợi ý 1
> Mẫu bằng 0 khi $x=2$; tại đó tử bằng $6\ne0$.

> [!goi-y] Gợi ý 2
> Khi $x\to2^{-}$ thì $x<2$ nên $2-x>0$ (dần về $0$ từ phía dương). Khi $x\to2^{+}$ thì $2-x<0$.

> [!loi-giai] Lời giải
> - $\lim\limits_{x\to2^{-}}(x+4)=6>0$ và $2-x\to0^{+}$ nên $\lim\limits_{x\to2^{-}}y=+\infty$.
> - $\lim\limits_{x\to2^{+}}(x+4)=6>0$ và $2-x\to0^{-}$ nên $\lim\limits_{x\to2^{+}}y=-\infty$.
>
> Vậy TCĐ là $x=2$. Còn $\lim\limits_{x\to\pm\infty}\dfrac{x+4}{2-x}=\dfrac{1}{-1}=-1$ nên TCN là $y=-1$ (chú ý hệ số của $x$ ở mẫu là $-1$, không phải $2$).

### 2.2. Mẫu bằng 0 nhưng không có tiệm cận đứng

> [!vi-du] Ví dụ 4
> Tìm các tiệm cận đứng của đồ thị hàm số $y=\dfrac{x^2-x-2}{x^2-4}$.

> [!goi-y] Gợi ý 1
> Mẫu bằng 0 tại $x=2$ và $x=-2$. Thử thay $x=2$ vào tử xem sao.

> [!goi-y] Gợi ý 2
> Phân tích: $x^2-x-2=(x-2)(x+1)$, $x^2-4=(x-2)(x+2)$.

> [!loi-giai] Lời giải
> Với $x\ne\pm2$: $y=\dfrac{(x-2)(x+1)}{(x-2)(x+2)}=\dfrac{x+1}{x+2}$.
> - Tại $x=2$: $\lim\limits_{x\to2}y=\dfrac{3}{4}$ — một **số hữu hạn**, nên $x=2$ **không** là TCĐ (đồ thị chỉ "thủng" một điểm).
> - Tại $x=-2$: tử $x+1\to-1\ne0$, mẫu $x+2\to0$ nên giới hạn một bên là vô cực: $x=-2$ **là** TCĐ.
>
> Vậy đồ thị có đúng **một** tiệm cận đứng $x=-2$ (và TCN $y=1$).

> [!bay] "Mẫu bằng 0 là có tiệm cận đứng" — sai!
> Luôn thử thay $x_0$ vào **tử**. Tử cũng bằng 0 → có nhân tử chung $(x-x_0)$ → rút gọn rồi mới kết luận. Đây là bẫy số 1 trong câu "đếm số tiệm cận". Ngoài ra, với hàm có căn, $x_0$ phải nằm ở **mép** tập xác định (có điểm của tập xác định ở sát $x_0$), không thì không xét giới hạn được.

> [!ung-dung] Tiệm cận đứng và "cái giá của sự hoàn hảo"
> Chi phí để lọc bỏ $p\%$ bụi mịn khỏi khí thải một nhà máy thường được mô hình bằng hàm dạng $C(p)=\dfrac{k\,p}{100-p}$ ($k>0$, $0\le p<100$). Khi $p\to100^{-}$ thì $C(p)\to+\infty$: đường $p=100$ là TCĐ. Ý nghĩa: lọc được 90%, 99% còn làm được, nhưng **lọc sạch 100% thì chi phí lớn vô hạn** — không thể thực hiện (SGK tr. 22 có tình huống cùng ý tưởng).

> [!em-co-biet]
> Không chỉ hàm phân thức mới có TCĐ. Hàm $y=\log_2 x$ (lớp 11) có $\lim\limits_{x\to0^{+}}\log_2x=-\infty$, nên trục tung $x=0$ là tiệm cận đứng của nó. Còn hàm mũ $y=2^x$ có $\lim\limits_{x\to-\infty}2^x=0$, nên trục hoành $y=0$ là tiệm cận ngang.

## 3. Đường tiệm cận xiên

### 3.1. Từ hình ảnh đến định nghĩa

Có những đồ thị khi $x\to\pm\infty$ không tiến tới một đường nằm ngang mà **chạy song song sát** một đường thẳng **nghiêng**. Xét $f(x)=\dfrac{x^2+3x-1}{x+2}$. Chia tử cho mẫu:

$$f(x)=x+1-\frac{3}{x+2}.$$

Phần $-\dfrac{3}{x+2}$ dần về $0$ khi $x\to\pm\infty$, nên với $x$ rất lớn (về độ lớn) thì $f(x)\approx x+1$: đồ thị gần như trùng với đường thẳng $y=x+1$. Hiệu $f(x)-(x+1)$ chính là "khoảng cách theo phương thẳng đứng" giữa đồ thị và đường thẳng — hiệu này dần về $0$.

![Hình 3. Đồ thị y = (x² + 3x − 1)/(x + 2) có tiệm cận xiên y = x + 1 và tiệm cận đứng x = −2](h3-tiem-can-xien.svg)

> [!ghi-nho] Định nghĩa (SGK tr. 23)
> Đường thẳng $y=ax+b$ ($a\ne0$) là **đường tiệm cận xiên** (gọi tắt: tiệm cận xiên, TCX) của đồ thị hàm số $y=f(x)$ nếu
> $$\lim_{x\to+\infty}\big[f(x)-(ax+b)\big]=0$$
> hoặc
> $$\lim_{x\to-\infty}\big[f(x)-(ax+b)\big]=0.$$

### 3.2. Cách tìm $a$ và $b$ — và vì sao

Giả sử $y=ax+b$ là TCX khi $x\to+\infty$, tức là $f(x)=ax+b+\varepsilon(x)$ với $\varepsilon(x)\to0$.

- Chia hai vế cho $x$: $\dfrac{f(x)}{x}=a+\dfrac bx+\dfrac{\varepsilon(x)}{x}\to a$. Vậy **$a$ là "độ dốc" lâu dài** của đồ thị.
- Trừ đi $ax$: $f(x)-ax=b+\varepsilon(x)\to b$.

> [!ghi-nho] Công thức tìm tiệm cận xiên (SGK tr. 24)
> $$a=\lim_{x\to+\infty}\frac{f(x)}{x},\qquad b=\lim_{x\to+\infty}\big[f(x)-ax\big]$$
> (hoặc tính với $x\to-\infty$). Nếu cả hai giới hạn là **số hữu hạn** và $a\ne0$ thì $y=ax+b$ là TCX.
> - Nếu $a=0$: đó là TCN $y=b$, không phải TCX.
> - Nếu $\dfrac{f(x)}{x}\to\pm\infty$ (hoặc $b$ không hữu hạn): **không có** TCX ở phía đó.

> [!vi-du] Ví dụ 5
> Tìm các tiệm cận của đồ thị hàm số $y=\dfrac{x^2+3x-1}{x+2}$ bằng **hai cách**: dùng công thức giới hạn và chia đa thức.

> [!goi-y] Gợi ý 1
> Cách 1: $\dfrac{f(x)}{x}=\dfrac{x^2+3x-1}{x^2+2x}$; sau đó tính $f(x)-x$ và quy đồng.

> [!goi-y] Gợi ý 2
> Cách 2: chia $x^2+3x-1$ cho $x+2$ được thương $x+1$, dư $-3$.

> [!loi-giai] Lời giải
> **Cách 1.** $a=\lim\limits_{x\to\pm\infty}\dfrac{x^2+3x-1}{x^2+2x}=1$;
> $$b=\lim_{x\to\pm\infty}\left[\frac{x^2+3x-1}{x+2}-x\right]$$
> $$=\lim_{x\to\pm\infty}\frac{x-1}{x+2}=1.$$
> **Cách 2.** $y=x+1-\dfrac{3}{x+2}$ và $\lim\limits_{x\to\pm\infty}\big[y-(x+1)\big]=\lim\limits_{x\to\pm\infty}\dfrac{-3}{x+2}=0$.
>
> Cả hai cách cho TCX $y=x+1$. Ngoài ra mẫu bằng 0 tại $x=-2$, tử tại đó bằng $4-6-1=-3\ne0$ nên $x=-2$ là TCĐ. Đồ thị không có TCN (vì $\lim\limits_{x\to\pm\infty}y=\pm\infty$).

> [!meo] Hàm bậc hai/bậc nhất: chia đa thức là nhanh nhất
> Hàm phân thức có tử bậc hai, mẫu bậc nhất luôn viết được thành $y=(\alpha x+\beta)+\dfrac{r}{mx+n}$. Nếu $r\ne0$: TCX $y=\alpha x+\beta$ và TCĐ $x=-\dfrac nm$. Dùng **chia Horner** (lớp 10) khi mẫu dạng $x-c$ cho đỡ nhầm dấu.

> [!bay] Ba lỗi hay gặp với tiệm cận xiên
> 1. Tính $b=\lim\big[f(x)-x\big]$ khi $a=3$ — phải trừ đúng $ax$, tức $f(x)-3x$.
> 2. Lấy TCX là "thương" nhưng chia sai dấu: kiểm tra lại bằng cách nhân ngược (thương × mẫu + dư = tử).
> 3. Nếu dư $r=0$ thì hàm số **thực chất là đường thẳng bị thủng một điểm** — không có TCĐ (đề có tham số hay cài trường hợp này).

### 3.3. Tiệm cận xiên trong bài toán thực tế

> [!vi-du] Ví dụ 6
> Một mảnh vườn hình chữ nhật có diện tích $64\ \text{m}^2$, một cạnh dài $x$ (m).
>
> a) Viết công thức chu vi $P(x)$.
>
> b) Tìm các tiệm cận của đồ thị $y=P(x)$ (với $x>0$) và nêu ý nghĩa thực tế.

> [!goi-y] Gợi ý 1
> Cạnh còn lại dài $\dfrac{64}{x}$ m.

> [!goi-y] Gợi ý 2
> $P(x)=2x+\dfrac{128}{x}$ có sẵn dạng "đường thẳng + phần dần về 0". Xét $x\to0^{+}$ và $x\to+\infty$.

> [!loi-giai] Lời giải
> a) $P(x)=2\left(x+\dfrac{64}{x}\right)=2x+\dfrac{128}{x}$, $x>0$.
>
> b) $\lim\limits_{x\to0^{+}}P(x)=+\infty$ → TCĐ $x=0$. $\lim\limits_{x\to+\infty}\big[P(x)-2x\big]=\lim\limits_{x\to+\infty}\dfrac{128}{x}=0$ → TCX $y=2x$.
>
> Ý nghĩa: nếu một cạnh **rất ngắn** thì cạnh kia rất dài, chu vi tăng vô hạn; nếu một cạnh **rất dài** thì cạnh kia gần bằng 0 và chu vi xấp xỉ $2x$ (gần như chỉ còn hai cạnh dài).

## 4. Đọc tiệm cận từ đồ thị và bảng biến thiên

Đề thi thường không cho công thức mà cho **hình**. Quy tắc đọc:

- **Đồ thị:** đường cong bám sát đường nằm ngang ở hai đầu → TCN; vọt lên/lao xuống bám sát đường thẳng đứng → TCĐ; chạy dọc theo đường nghiêng → TCX.
- **Bảng biến thiên (BBT):**
  - Ở cột $x=-\infty$ hoặc $x=+\infty$, hàng $y$ ghi **một số** $y_0$ → TCN $y=y_0$. Ghi $\pm\infty$ → không có TCN phía đó.
  - Tại $x_0$ có **vạch kép** (hàm không xác định) và ít nhất một bên ghi $+\infty$ hoặc $-\infty$ → TCĐ $x=x_0$.
  - Giá trị cực đại, cực tiểu ghi trong bảng **không** phải tiệm cận.

![Hình 4. Bảng biến thiên của hàm số y = f(x) xác định trên ℝ \ {2} (dùng cho Ví dụ 7 và Ví dụ 9)](h4-bang-bien-thien.svg)

> [!vi-du] Ví dụ 7
> Cho hàm số $y=f(x)$ có bảng biến thiên như Hình 4. Đồ thị hàm số có bao nhiêu đường tiệm cận (gồm cả ngang và đứng)?

> [!goi-y] Gợi ý 1
> Nhìn hai đầu $-\infty$, $+\infty$ của hàng $y$: hai số khác nhau.

> [!goi-y] Gợi ý 2
> Tại $x=2$ có vạch kép, hai bên là $-\infty$ và $+\infty$. Còn số $3$ tại $x=-1$ là gì?

> [!loi-giai] Lời giải
> - $\lim\limits_{x\to-\infty}f(x)=1$ → TCN $y=1$; $\lim\limits_{x\to+\infty}f(x)=-1$ → TCN $y=-1$.
> - $\lim\limits_{x\to2^{-}}f(x)=-\infty$ (và $\lim\limits_{x\to2^{+}}f(x)=+\infty$) → TCĐ $x=2$.
> - $3$ là giá trị cực đại, không phải tiệm cận.
>
> Tổng cộng **3** đường tiệm cận.

> [!bay] Đếm thiếu hoặc đếm thừa
> - Hai đầu là **cùng một số** (ví dụ cả hai đều là $1$) thì chỉ có **một** TCN, không phải hai.
> - Đừng đếm cực trị (số $3$) là tiệm cận; đừng quên TCN chỉ cần **một** phía.

## Dạng bài thi hay gặp

### Dạng 1. Tìm, đếm tiệm cận của hàm số cho bởi công thức

- **Nhận biết:** "Đồ thị hàm số … có bao nhiêu đường tiệm cận?", "Tiệm cận đứng/ngang/xiên là…".
- **Phương pháp:**
  1. Tìm **tập xác định** (có căn thì phải có điều kiện dưới căn).
  2. TCN: tính $\lim\limits_{x\to+\infty}$ và $\lim\limits_{x\to-\infty}$ (chỉ phía nào tập xác định "kéo dài" tới).
  3. TCĐ: với mỗi nghiệm của mẫu, thay vào tử; tử $=0$ thì rút gọn (nhân liên hợp nếu có căn) rồi tính lại.
  4. Hàm bậc hai/bậc nhất: chia đa thức để lấy TCX.
- **Bẫy:** mẫu bằng 0 nhưng tử cũng bằng 0; hàm có căn chỉ xác định một phía nên chỉ có một TCN; hai đầu cùng giới hạn chỉ tính một TCN.

> [!meo] Soát lại bằng máy tính cầm tay
> Nhập biểu thức $f(x)$ rồi dùng **CALC**: thay $x=10^{9}$ (và $x=-10^{9}$) — kết quả gần số nào thì đó là TCN. Thay $x=x_0+10^{-6}$ và $x=x_0-10^{-6}$ — kết quả có độ lớn rất lớn (cỡ $10^5$ trở lên) thì $x=x_0$ là TCĐ; kết quả là một số "bình thường" thì không phải. Chỉ dùng để **kiểm tra**, vì $x$ quá lớn có thể làm máy báo lỗi hoặc làm tròn sai với biểu thức có căn.

> [!vi-du] Ví dụ 8
> Đồ thị hàm số $y=\dfrac{\sqrt{x+3}-2}{x^2-1}$ có bao nhiêu đường tiệm cận?

> [!goi-y] Gợi ý 1
> Tập xác định: $x\ge-3$, $x\ne\pm1$. Vì $x$ không thể tiến tới $-\infty$, chỉ xét $x\to+\infty$.

> [!goi-y] Gợi ý 2
> Tại $x=1$, tử $\sqrt4-2=0$. Nhân liên hợp: $\sqrt{x+3}-2=\dfrac{x-1}{\sqrt{x+3}+2}$.

> [!loi-giai] Lời giải
> - $x\to+\infty$: tử tăng như $\sqrt x$, mẫu như $x^2$, nên $y\to0$ → TCN $y=0$.
> - Với $x\ne\pm1$: $y=\dfrac{x-1}{(x-1)(x+1)(\sqrt{x+3}+2)}=\dfrac{1}{(x+1)(\sqrt{x+3}+2)}$.
>   - $x\to1$: $y\to\dfrac{1}{2\cdot4}=\dfrac18$ (hữu hạn) → $x=1$ **không** là TCĐ.
>   - $x\to-1$: tử $\to1$, mẫu $\to0$ → $x=-1$ **là** TCĐ.
>
> Vậy đồ thị có **2** đường tiệm cận: $y=0$ và $x=-1$.

### Dạng 2. Tiệm cận của hàm hợp, đọc từ bảng biến thiên

- **Nhận biết:** cho BBT (hoặc đồ thị) của $f(x)$, hỏi số tiệm cận của $y=\dfrac{1}{f(x)-k}$, $y=\dfrac{1}{f(x)}$…
- **Phương pháp:**
  1. **TCĐ** của $\dfrac{1}{f(x)-k}$: tại các nghiệm của $f(x)=k$ (đếm bằng cách kẻ đường ngang $y=k$ cắt BBT), và xét thêm các điểm $f$ không xác định.
  2. **TCN**: lấy giới hạn của $f$ ở $\pm\infty$ rồi thay vào: $f\to y_0\ne k$ thì $\dfrac{1}{f-k}\to\dfrac{1}{y_0-k}$; $f\to\pm\infty$ thì $\dfrac1{f-k}\to0$.
- **Bẫy:** tại điểm $f\to\pm\infty$ thì $\dfrac{1}{f-k}\to0$ — **hữu hạn**, nên đó **không** phải TCĐ của hàm mới.

> [!vi-du] Ví dụ 9
> Cho hàm số $y=f(x)$ có bảng biến thiên như Hình 4. Đồ thị hàm số $g(x)=\dfrac{1}{f(x)-2}$ có bao nhiêu đường tiệm cận?

> [!goi-y] Gợi ý 1
> Đếm số nghiệm của $f(x)=2$ trên từng khoảng $(-\infty;-1)$, $(-1;2)$, $(2;+\infty)$: so $2$ với các giá trị ở hai đầu mỗi mũi tên.

> [!goi-y] Gợi ý 2
> Khi $x\to2$ thì $f(x)\to\pm\infty$, vậy $g(x)\to\ ?$ Khi $x\to-\infty$ thì $f\to1$, $g\to\ ?$

> [!loi-giai] Lời giải
> **TCĐ.** Trên $(-\infty;-1)$, $f$ tăng từ $1$ lên $3$ → $f(x)=2$ có 1 nghiệm. Trên $(-1;2)$, $f$ giảm từ $3$ xuống $-\infty$ → 1 nghiệm. Trên $(2;+\infty)$, $f$ giảm từ $+\infty$ xuống $-1$ → 1 nghiệm. Tại mỗi nghiệm $x_i$, mẫu $f(x)-2\to0$ còn tử bằng $1$ → $g\to\pm\infty$: **3 TCĐ**. Tại $x=2$: $f\to\pm\infty$ nên $g\to0$, không phải TCĐ.
>
> **TCN.** $x\to-\infty$: $g\to\dfrac{1}{1-2}=-1$; $x\to+\infty$: $g\to\dfrac{1}{-1-2}=-\dfrac13$ → **2 TCN** $y=-1$, $y=-\dfrac13$.
>
> Tổng cộng **5** đường tiệm cận.

### Dạng 3. Bài toán có tham số

- **Nhận biết:** "Tìm $m$ để đồ thị có tiệm cận đứng", "…tiệm cận xiên đi qua điểm $A$", "…có đúng hai tiệm cận đứng".
- **Phương pháp:** viết tiệm cận theo $m$ (chia đa thức, tỉ số hệ số) → dịch điều kiện thành phương trình/bất phương trình → **loại** giá trị $m$ làm tử và mẫu có nghiệm chung (khi đó tiệm cận biến mất).
- **Bẫy:** quên điều kiện "phần dư khác 0" (hàm suy biến thành đường thẳng); với mẫu bậc hai, quên trường hợp nghiệm kép hoặc một nghiệm của mẫu trùng nghiệm của tử.

> [!vi-du] Ví dụ 10
> a) Tìm $m$ để tiệm cận xiên của đồ thị $y=\dfrac{x^2+mx-1}{x-1}$ đi qua điểm $A(2;\,5)$.
>
> b) Tìm tất cả các giá trị của $m$ để đồ thị $y=\dfrac{x-1}{x^2-2mx+4}$ có **đúng một** tiệm cận đứng.

> [!goi-y] Gợi ý 1
> a) Chia: $x^2+mx-1=(x-1)(x+m+1)+m$. Điều kiện để có tiệm cận: dư $m\ne0$.

> [!goi-y] Gợi ý 2
> b) "Đúng một TCĐ" xảy ra khi: mẫu có **nghiệm kép** (khác 1), **hoặc** mẫu có hai nghiệm phân biệt nhưng **một nghiệm là $x=1$** (bị tử "triệt tiêu").

> [!loi-giai] Lời giải
> a) Với $m\ne0$: $y=x+m+1+\dfrac{m}{x-1}$, TCX $y=x+m+1$. Qua $A(2;\,5)$: $5=2+m+1\iff m=2$ (thỏa $m\ne0$). Vậy $m=2$.
>
> b) Mẫu $x^2-2mx+4$ có $\Delta'=m^2-4$.
> - Nghiệm kép: $m^2=4\iff m=\pm2$, nghiệm $x=m\ne1$ → đúng một TCĐ ($x=2$ hoặc $x=-2$). Nhận.
> - Hai nghiệm phân biệt ($\lvert m\rvert>2$), một nghiệm là $1$: $1-2m+4=0\iff m=\dfrac52$. Khi đó mẫu $=x^2-5x+4=(x-1)(x-4)$, $y=\dfrac{1}{x-4}$ ($x\ne1$) → chỉ còn TCĐ $x=4$. Nhận.
> - Các trường hợp khác: vô nghiệm (0 TCĐ) hoặc hai nghiệm khác 1 (2 TCĐ).
>
> Vậy $m\in\left\{-2;\,2;\,\dfrac52\right\}$.

### Dạng 4. Bài toán thực tế (thường là Đúng–Sai hoặc trả lời ngắn)

- **Nhận biết:** chi phí trung bình, nồng độ khi pha trộn, số lượng sinh vật, chi phí xử lí ô nhiễm…
- **Phương pháp:** lập hàm số (thường là phân thức) → TCN cho **giá trị lâu dài/giới hạn**, TCĐ cho **ngưỡng không thể đạt** → trả lời câu hỏi bằng cách giải phương trình/bất phương trình.
- **Bẫy:** chỉ xét $x$ trong miền có nghĩa thực tế ($x>0$, $0\le p<100$…); nhầm "tiến tới" với "đạt được" — giá trị tiệm cận thường **không bao giờ đạt**.

> [!vi-du] Ví dụ 11 (Đúng/Sai)
> Một cơ sở sản xuất trà thảo mộc đóng hộp có chi phí làm $x$ hộp là $C(x)=25x+4000$ (nghìn đồng), gồm chi phí cố định $4000$ nghìn đồng và $25$ nghìn đồng cho mỗi hộp. Gọi $f(x)=\dfrac{C(x)}{x}$ là chi phí trung bình mỗi hộp ($x>0$). Xét các mệnh đề:
>
> a) $f(200)=45$ (nghìn đồng).
>
> b) $f(x)$ giảm khi $x$ tăng.
>
> c) Đồ thị $y=f(x)$ có tiệm cận ngang là $y=4000$.
>
> d) Để chi phí trung bình không vượt quá $30$ nghìn đồng/hộp, cần sản xuất ít nhất $160$ hộp.

> [!goi-y] Gợi ý 1
> $f(x)=25+\dfrac{4000}{x}$. Phần $\dfrac{4000}{x}$ là chi phí cố định "chia đều" cho mỗi hộp.

> [!goi-y] Gợi ý 2
> d) Giải $25+\dfrac{4000}{x}\le30$ với $x>0$.

> [!loi-giai] Lời giải
> a) **Đúng** — $f(200)=25+\dfrac{4000}{200}=25+20=45$.
>
> b) **Đúng** — $f'(x)=-\dfrac{4000}{x^2}<0$ với mọi $x>0$.
>
> c) **Sai** — $\lim\limits_{x\to+\infty}f(x)=25$ nên TCN là $y=25$: sản xuất càng nhiều, chi phí trung bình càng gần $25$ nghìn đồng (nhưng luôn lớn hơn $25$).
>
> d) **Sai** — $\dfrac{4000}{x}\le5\iff x\ge800$: cần ít nhất $800$ hộp.

## Tóm tắt

| Loại | Định nghĩa | Cách tìm nhanh |
|---|---|---|
| Tiệm cận ngang $y=y_0$ | $\lim\limits_{x\to+\infty}f(x)=y_0$ hoặc $\lim\limits_{x\to-\infty}f(x)=y_0$ | Phân thức: so bậc tử – mẫu; $\dfrac{ax+b}{cx+d}$ → $y=\dfrac ac$ |
| Tiệm cận đứng $x=x_0$ | Một trong các giới hạn một bên tại $x_0$ bằng $\pm\infty$ | Nghiệm của mẫu **mà tử khác 0** (sau khi rút gọn); $\dfrac{ax+b}{cx+d}$ → $x=-\dfrac dc$ |
| Tiệm cận xiên $y=ax+b$, $a\ne0$ | $\lim\big[f(x)-(ax+b)\big]=0$ khi $x\to+\infty$ hoặc $x\to-\infty$ | $a=\lim\dfrac{f(x)}{x}$, $b=\lim\big[f(x)-ax\big]$; bậc 2/bậc 1: chia đa thức |

**Hình ảnh:** TCN — đồ thị sát đường nằm ngang khi $x$ ra xa; TCĐ — đồ thị vọt lên/lao xuống sát đường thẳng đứng; TCX — đồ thị chạy sát đường nghiêng khi $x$ ra xa.

**Sơ đồ khi gặp đề:** tập xác định → giới hạn ở $\pm\infty$ (TCN hoặc TCX) → nghiệm của mẫu, kiểm tra tử (TCĐ) → đếm, **không** đếm trùng. Với BBT: nhìn **hai đầu** (TCN) và **vạch kép** (TCĐ). Bài thực tế: TCN là "giá trị lâu dài", TCĐ là "ngưỡng không thể vượt".
