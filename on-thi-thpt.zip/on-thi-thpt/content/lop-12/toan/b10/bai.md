---
title: Phương sai và độ lệch chuẩn
thoi-gian: 50 phút
muc-tieu:
  - Xác định được giá trị đại diện, số trung bình và tính được phương sai, độ lệch chuẩn của mẫu số liệu ghép nhóm bằng cả hai dạng công thức của SGK
  - Hiểu vì sao phương sai, độ lệch chuẩn đo mức độ phân tán của số liệu xung quanh số trung bình, và vì sao chúng chỉ là giá trị xấp xỉ cho mẫu số liệu gốc
  - Dùng phương sai, độ lệch chuẩn để so sánh độ phân tán (độ ổn định, độ đồng đều) của hai mẫu số liệu và đo độ rủi ro của phương án đầu tư
  - Biết khi nào không nên dùng độ lệch chuẩn để so sánh (trung bình khác nhau rất nhiều) và biết hệ số biến thiên $CV=\dfrac{s}{\bar x}$
  - Bấm máy tính cầm tay để tính nhanh số trung bình, phương sai, độ lệch chuẩn của mẫu ghép nhóm
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mỗi nhóm $[a_i;a_{i+1})$ được thay bằng **giá trị đại diện** $x_i=\dfrac{a_i+a_{i+1}}{2}$; số trung bình $\bar x=\dfrac{m_1x_1+\dots+m_kx_k}{n}$.
> 2. **Phương sai** $s^2=\dfrac{m_1(x_1-\bar x)^2+\dots+m_k(x_k-\bar x)^2}{n}$ — trung bình của **bình phương độ lệch** so với $\bar x$.
> 3. Dạng tính nhanh: $s^2=\dfrac{1}{n}\left(m_1x_1^2+\dots+m_kx_k^2\right)-\bar x^2$. **Độ lệch chuẩn** $s=\sqrt{s^2}$, cùng đơn vị với số liệu.
> 4. $s^2$, $s$ càng lớn → số liệu càng **phân tán** quanh trung bình (kém ổn định, kém đồng đều, **rủi ro** hơn). Chúng chỉ **xấp xỉ** phương sai, độ lệch chuẩn của mẫu gốc.
> 5. Chỉ so sánh độ lệch chuẩn khi hai mẫu **cùng đơn vị** và **trung bình không chênh nhau quá nhiều**; nếu không, dùng hệ số biến thiên $CV=\dfrac{s}{\bar x}$.

Ở Bài 9, em đo độ phân tán bằng khoảng biến thiên $R$ (chỉ nhìn **hai đầu mút**) và khoảng tứ phân vị $\Delta_Q$ (chỉ nhìn **nửa giữa**). Cả hai đều bỏ qua phần lớn thông tin trong bảng. Bài này học một thước đo dùng **tất cả** các nhóm: mỗi số liệu cách trung bình bao xa, rồi lấy "trung bình" của các khoảng cách đó. Đây là thước đo độ phân tán quan trọng nhất trong thống kê, khoa học, y học và tài chính — từ kiểm định một máy đo đến đánh giá độ rủi ro của một khoản đầu tư.

> [!nen-tang] Nhắc lại lớp 10–11
> - **Mẫu số liệu gốc** $x_1,x_2,\dots,x_n$ (lớp 10): số trung bình $\bar x=\dfrac{x_1+\dots+x_n}{n}$, phương sai $s^2=\dfrac{(x_1-\bar x)^2+\dots+(x_n-\bar x)^2}{n}$, độ lệch chuẩn $s=\sqrt{s^2}$.
> - **Mẫu số liệu ghép nhóm** (lớp 11, xem lại Bài 9): các nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$ với tần số $m_1,\dots,m_k$, cỡ mẫu $n=m_1+\dots+m_k$.
> - **Giá trị đại diện** của nhóm $[a_i;a_{i+1})$ là trung điểm $x_i=\dfrac{a_i+a_{i+1}}{2}$.
> - **Số trung bình** của mẫu ghép nhóm: $\bar x=\dfrac{m_1x_1+\dots+m_kx_k}{n}$ — coi như cả $m_i$ số liệu của nhóm thứ $i$ đều bằng $x_i$.

## 1. Phương sai và độ lệch chuẩn

### 1.1. Ý tưởng: đo khoảng cách đến số trung bình

Một máy đo nhiệt độ "tốt" là máy đo cùng một vật nhiều lần mà các kết quả **sát nhau**. Một ruộng lúa "ổn định" là ruộng mà năng suất các năm **không chênh lệch nhiều**. Trong cả hai trường hợp, câu hỏi là: *các số liệu nằm cách số trung bình $\bar x$ bao xa?*

Với mỗi số liệu $x$, hiệu $x-\bar x$ gọi là **độ lệch** của nó so với trung bình. Ta muốn lấy "trung bình các độ lệch", nhưng gặp ngay một rắc rối:

- Độ lệch có số dương (số liệu lớn hơn trung bình), có số âm (nhỏ hơn trung bình). **Tổng các độ lệch luôn bằng $0$** — chúng triệt tiêu nhau, nên trung bình độ lệch luôn bằng $0$, chẳng nói lên điều gì.
- Cách khắc phục: **bình phương** các độ lệch cho hết dấu âm (và độ lệch càng lớn càng bị "phạt" nặng), rồi mới lấy trung bình. Đó là **phương sai**.
- Phương sai có đơn vị là **bình phương** đơn vị số liệu (phút², kg², triệu đồng²…) — khó hình dung. Lấy **căn bậc hai** để trở lại đúng đơn vị: đó là **độ lệch chuẩn**.

Với mẫu ghép nhóm, ta không biết từng số liệu, nên làm như khi tính số trung bình: **coi mọi số liệu trong nhóm thứ $i$ đều bằng giá trị đại diện $x_i$**. Nhóm thứ $i$ có $m_i$ số liệu, mỗi số có độ lệch $x_i-\bar x$, nên đóng góp $m_i(x_i-\bar x)^2$ vào tổng bình phương độ lệch.

![Hình 1. Các giá trị đại diện và độ lệch của chúng so với số trung bình (số liệu Ví dụ 1). Nhóm càng xa trung bình và càng đông thì đóng góp vào phương sai càng nhiều](h1-do-lech.svg)

### 1.2. Định nghĩa và hai dạng công thức

> [!ghi-nho] Định nghĩa (SGK tr. 80)
> Cho mẫu số liệu ghép nhóm với các nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$, tần số $m_1,\dots,m_k$, cỡ mẫu $n=m_1+\dots+m_k$, giá trị đại diện $x_i=\dfrac{a_i+a_{i+1}}{2}$ và số trung bình $\bar x=\dfrac{m_1x_1+\dots+m_kx_k}{n}$.
> - **Phương sai** của mẫu số liệu ghép nhóm, kí hiệu $s^2$:
> $$s^2=\dfrac{m_1(x_1-\bar x)^2+\dots+m_k(x_k-\bar x)^2}{n}.$$
> - **Độ lệch chuẩn** của mẫu số liệu ghép nhóm, kí hiệu $s$, là căn bậc hai số học của phương sai: $s=\sqrt{s^2}$.

> [!ghi-nho] Nhận xét — dạng tính nhanh (SGK tr. 80)
> $$s^2=\dfrac{1}{n}\left(m_1x_1^2+\dots+m_kx_k^2\right)-\left(\bar x\right)^2.$$
> Đọc thành lời: **phương sai = trung bình của bình phương − bình phương của trung bình**.

**Vì sao hai dạng bằng nhau?** Khai triển $(x_i-\bar x)^2=x_i^2-2\bar x\,x_i+\bar x^2$, nhân với $m_i$ rồi cộng lại:
$$\sum m_i(x_i-\bar x)^2=\sum m_ix_i^2-2\bar x\sum m_ix_i+\bar x^2\sum m_i=\sum m_ix_i^2-2\bar x\cdot n\bar x+\bar x^2\cdot n=\sum m_ix_i^2-n\bar x^2.$$
Chia cho $n$ là được dạng tính nhanh. (Ở đây $\sum m_ix_i=n\bar x$ và $\sum m_i=n$.)

> [!ghi-nho] Mấy tính chất nên nhớ
> - $s^2\ge0$, $s\ge0$. $s=0$ khi và chỉ khi mọi số liệu đều rơi vào **cùng một nhóm** (không phân tán chút nào).
> - $s$ có **cùng đơn vị** với số liệu; $s^2$ có đơn vị là bình phương đơn vị đó.
> - **Cộng (trừ) cùng một số** vào mọi số liệu → $\bar x$ dịch theo, nhưng $s^2$, $s$ **không đổi** (cả đám chỉ "trượt" đi, không giãn ra).
> - **Nhân** mọi số liệu với $c$ → $s$ nhân với $\lvert c\rvert$, $s^2$ nhân với $c^2$.
> - **Nhân mọi tần số với cùng một số** (ví dụ gấp đôi tất cả) → $\bar x$, $s^2$, $s$ **không đổi** (tỉ lệ các nhóm vẫn như cũ).

> [!vi-du] Ví dụ 1
> Thời gian ngủ mỗi đêm của 40 học sinh lớp 12 được ghi lại như sau:
>
> | Thời gian ngủ (giờ) | [5; 6) | [6; 7) | [7; 8) | [8; 9) | [9; 10) |
> |---|---|---|---|---|---|
> | Số học sinh | 4 | 10 | 16 | 8 | 2 |
>
> Tính số trung bình, phương sai và độ lệch chuẩn của mẫu số liệu (làm tròn độ lệch chuẩn đến hàng phần trăm). Tính phương sai bằng **cả hai** dạng công thức để thấy chúng cho cùng kết quả.

> [!goi-y] Gợi ý 1
> Giá trị đại diện là trung điểm từng nhóm: $5{,}5;\ 6{,}5;\ 7{,}5;\ 8{,}5;\ 9{,}5$. Lập bảng tính có các cột $x_i$, $m_i$, $m_ix_i$.

> [!goi-y] Gợi ý 2
> $\bar x=\dfrac{294}{40}=7{,}35$. Dạng định nghĩa: thêm cột $x_i-\bar x$ và $m_i(x_i-\bar x)^2$. Dạng tính nhanh: thêm cột $m_ix_i^2$.

> [!loi-giai] Lời giải
> $n=4+10+16+8+2=40$. Lập bảng tính:
>
> | $x_i$ | $m_i$ | $m_ix_i$ | $x_i-\bar x$ | $m_i(x_i-\bar x)^2$ | $m_ix_i^2$ |
> |---|---|---|---|---|---|
> | 5,5 | 4 | 22 | −1,85 | 13,69 | 121 |
> | 6,5 | 10 | 65 | −0,85 | 7,225 | 422,5 |
> | 7,5 | 16 | 120 | 0,15 | 0,36 | 900 |
> | 8,5 | 8 | 68 | 1,15 | 10,58 | 578 |
> | 9,5 | 2 | 19 | 2,15 | 9,245 | 180,5 |
> | **Tổng** | **40** | **294** | | **41,1** | **2202** |
>
> **Số trung bình:** $\bar x=\dfrac{294}{40}=7{,}35$ (giờ).
>
> **Phương sai theo định nghĩa:** $s^2=\dfrac{41{,}1}{40}=1{,}0275$.
>
> **Phương sai theo dạng tính nhanh:** $s^2=\dfrac{2202}{40}-7{,}35^2=55{,}05-54{,}0225=1{,}0275$. Hai cách cho cùng kết quả.
>
> **Độ lệch chuẩn:** $s=\sqrt{1{,}0275}\approx1{,}01$ (giờ).
>
> Nghĩa là: thời gian ngủ của các bạn lệch khỏi mức trung bình $7{,}35$ giờ, tính "trung bình theo kiểu bình phương", khoảng $1$ giờ.

> [!meo] Bấm máy tính cầm tay — thống kê có tần số
> Tên mục và vị trí phím khác nhau đôi chút giữa các dòng máy (fx-580VN X, fx-880BTG…), em nên thử trước với máy của mình bằng Ví dụ 1. Các bước chung:
> 1. **Bật cột tần số** trong phần cài đặt (SETUP) của máy: tìm mục thống kê, chọn bật **tần số** (*Frequency*). Chỉ cần làm một lần.
> 2. **Vào chế độ thống kê một biến** (1-Variable) từ MENU.
> 3. **Nhập số liệu:** cột $x$ nhập **giá trị đại diện** $5{,}5;\ 6{,}5;\ \dots$; cột tần số (*Freq*) nhập **tần số** $4;\ 10;\ \dots$
> 4. **Đọc kết quả:** thoát màn hình nhập rồi chọn mục **tính toán thống kê một biến** (thường nằm trong OPTN). Máy hiện $\bar x$, $\sum x^2$, $\sigma^2_x$ (một số máy chỉ hiện $\sigma_x$), $\sigma_x$, $s_x$, $n$…
>
> Với Ví dụ 1 máy cho $\bar x=7{,}35$, $\sigma^2_x=1{,}0275$, $\sigma_x\approx1{,}0137$.
>
> **Chọn đúng kí hiệu:** phương sai $s^2$ của SGK là **$\sigma^2_x$** trên máy, độ lệch chuẩn $s$ là **$\sigma_x$** (chia cho $n$). Còn $s^2_x$, $s_x$ trên máy là đại lượng chia cho $n-1$ (xem Chú ý ở mục 1.3) — **không** phải đáp án của đề hỏi $s$.

> [!bay] Lỗi hay gặp khi bấm máy và tính tay
> - Đọc nhầm $s_x$ (chia $n-1$) thay vì $\sigma_x$ (chia $n$). Hai số này gần nhau nên rất dễ lọt vào phương án nhiễu.
> - Nhập **đầu mút** nhóm (5, 6, 7…) thay cho **giá trị đại diện** (5,5; 6,5; 7,5…).
> - Đề hỏi **phương sai** mà ghi độ lệch chuẩn (hoặc ngược lại). Hãy gạch chân chữ "phương sai"/"độ lệch chuẩn" trong đề.
> - Dạng tính nhanh: quên trừ $\bar x^2$, hoặc trừ $\bar x$ (chưa bình phương).
> - Với dạng tính nhanh, **làm tròn $\bar x$ quá sớm** có thể làm sai lệch rất nhiều khi số liệu lớn (vì $\frac1n\sum m_ix_i^2$ và $\bar x^2$ là hai số lớn gần bằng nhau). Giữ $\bar x$ chính xác hoặc dùng máy.
> - Máy cũng hiện $Q_1$, $Q_3$ — đó là tứ phân vị tính theo kiểu **mẫu gốc** (coi mọi số liệu bằng giá trị đại diện), **khác** với công thức nội suy của mẫu ghép nhóm ở Bài 9. Tứ phân vị của mẫu ghép nhóm phải tính tay.

> [!vi-du] Ví dụ 2
> Để kiểm tra độ ổn định của một nhiệt kế điện tử, kĩ thuật viên dùng nó đo nhiệt độ của một bình nước được giữ ở nhiệt độ không đổi 25 lần, được kết quả:
>
> | Nhiệt độ đo (°C) | [36,6; 36,7) | [36,7; 36,8) | [36,8; 36,9) | [36,9; 37,0) | [37,0; 37,1) |
> |---|---|---|---|---|---|
> | Số lần đo | 2 | 6 | 9 | 5 | 3 |
>
> Theo quy định, nếu độ lệch chuẩn của các lần đo lớn hơn $0{,}1$ °C thì nhiệt kế phải đem đi hiệu chuẩn lại. Nhiệt kế này có cần hiệu chuẩn không?

> [!goi-y] Gợi ý 1
> Giá trị đại diện: $36{,}65;\ 36{,}75;\ 36{,}85;\ 36{,}95;\ 37{,}05$ — các số này lớn và gần nhau. Nếu dùng dạng tính nhanh bằng tay, $\frac1n\sum m_ix_i^2$ và $\bar x^2$ đều xấp xỉ $1358$, trừ nhau ra một số rất nhỏ — rất dễ sai.

> [!goi-y] Gợi ý 2
> Mẹo: phương sai **không đổi** khi trừ cùng một số vào mọi số liệu. Đặt $y=x-36{,}85$ thì các giá trị đại diện mới chỉ là $-0{,}2;\ -0{,}1;\ 0;\ 0{,}1;\ 0{,}2$.

> [!loi-giai] Lời giải
> $n=25$. Đặt $y_i=x_i-36{,}85$: các giá trị $-0{,}2;\ -0{,}1;\ 0;\ 0{,}1;\ 0{,}2$ với tần số $2;6;9;5;3$.
>
> - $\bar y=\dfrac{2(-0{,}2)+6(-0{,}1)+0+5\cdot0{,}1+3\cdot0{,}2}{25}=\dfrac{0{,}1}{25}=0{,}004$, suy ra $\bar x=36{,}85+0{,}004=36{,}854$ (°C).
> - $\dfrac1n\sum m_iy_i^2=\dfrac{2\cdot0{,}04+6\cdot0{,}01+0+5\cdot0{,}01+3\cdot0{,}04}{25}=\dfrac{0{,}31}{25}=0{,}0124$.
> - $s^2=0{,}0124-0{,}004^2=0{,}012384$, nên $s=\sqrt{0{,}012384}\approx0{,}111$ (°C).
>
> Vì $s\approx0{,}111>0{,}1$ nên nhiệt kế **cần được hiệu chuẩn lại**. (Bấm máy trực tiếp với $x_i$ cũng ra $\sigma_x\approx0{,}1113$.)

> [!meo] Đổi biến để tính tay cho gọn
> Khi các giá trị đại diện lớn và cách đều nhau một khoảng $h$, đặt $u=\dfrac{x-c}{h}$ ($c$ là một giá trị đại diện ở giữa). Khi đó $u$ nhận các giá trị nguyên nhỏ $\dots,-2,-1,0,1,2,\dots$; tính $s_u$ rồi suy ra $s_x=h\cdot s_u$ và $\bar x=c+h\,\bar u$. Ở Ví dụ 2, với $c=36{,}85$, $h=0{,}1$: $u\in\{-2;-1;0;1;2\}$, $s_u^2=\dfrac{31}{25}-\left(\dfrac{1}{25}\right)^2=1{,}2384$, nên $s_x^2=0{,}01\cdot1{,}2384=0{,}012384$ — khớp kết quả trên.

### 1.3. Ý nghĩa của phương sai, độ lệch chuẩn

> [!ghi-nho] Ý nghĩa (SGK tr. 81)
> - Phương sai, độ lệch chuẩn của mẫu số liệu ghép nhóm là **giá trị xấp xỉ** cho phương sai, độ lệch chuẩn của mẫu số liệu gốc (vì ta đã thay mọi số liệu trong nhóm bằng giá trị đại diện).
> - Chúng đo **mức độ phân tán** của số liệu **xung quanh số trung bình**: $s^2$, $s$ càng lớn thì số liệu càng phân tán.

So với $R$ và $\Delta_Q$ ở Bài 9, độ lệch chuẩn **dùng thông tin của mọi nhóm**, nên phản ánh độ phân tán đầy đủ hơn. Đổi lại, vì có bình phương nên nó cũng **khá nhạy** với các nhóm nằm xa trung bình (giá trị bất thường làm $s$ tăng nhanh) — khi dữ liệu có giá trị bất thường, $\Delta_Q$ vẫn là lựa chọn "bền" hơn.

> [!ghi-nho] Chú ý (SGK tr. 81)
> Người ta còn dùng đại lượng chia cho $n-1$ thay vì chia cho $n$ để đo độ phân tán:
> $$\hat s^2=\dfrac{m_1(x_1-\bar x)^2+\dots+m_k(x_k-\bar x)^2}{n-1},\qquad \hat s=\sqrt{\hat s^2}.$$
> Trong chương trình và đề thi, khi nói "phương sai", "độ lệch chuẩn" của mẫu ghép nhóm mà không nói gì thêm thì dùng $s^2$, $s$ (chia cho $n$). Trên máy tính, $\hat s$ chính là $s_x$.

> [!vi-du] Ví dụ 3
> Một viện nghiên cứu trồng thử hai giống lúa X và Y, mỗi giống trên 30 thửa ruộng thí nghiệm có điều kiện như nhau. Năng suất thu được:
>
> | Năng suất (tạ/ha) | [50; 54) | [54; 58) | [58; 62) | [62; 66) | [66; 70) |
> |---|---|---|---|---|---|
> | Số thửa giống X | 2 | 6 | 14 | 6 | 2 |
> | Số thửa giống Y | 5 | 7 | 6 | 7 | 5 |
>
> So sánh năng suất trung bình và độ lệch chuẩn của hai giống. Nên khuyên nông dân chọn giống nào nếu muốn năng suất ổn định?

> [!goi-y] Gợi ý 1
> Hai dòng tần số đều **đối xứng** quanh nhóm giữa $[58;62)$ — đoán xem trung bình bằng bao nhiêu trước khi tính.

> [!goi-y] Gợi ý 2
> Giá trị đại diện $52;\ 56;\ 60;\ 64;\ 68$, đều bằng $60$ cộng/trừ $4$ hoặc $8$ nên dùng ngay dạng định nghĩa cho gọn.

> [!loi-giai] Lời giải
> **Trung bình:** do tần số đối xứng quanh $60$ nên $\bar x_X=\bar x_Y=60$ (tạ/ha). (Kiểm tra: $\frac{1}{30}(2\cdot52+6\cdot56+14\cdot60+6\cdot64+2\cdot68)=\frac{1800}{30}=60$.)
>
> **Giống X:** độ lệch các nhóm là $-8;-4;0;4;8$:
> $$s_X^2=\dfrac{2\cdot64+6\cdot16+14\cdot0+6\cdot16+2\cdot64}{30}=\dfrac{448}{30}\approx14{,}93,\quad s_X\approx3{,}86.$$
> **Giống Y:**
> $$s_Y^2=\dfrac{5\cdot64+7\cdot16+6\cdot0+7\cdot16+5\cdot64}{30}=\dfrac{864}{30}=28{,}8,\quad s_Y\approx5{,}37.$$
> (Đơn vị của độ lệch chuẩn: tạ/ha.)
>
> Hai giống có **cùng năng suất trung bình**, nhưng $s_X<s_Y$: năng suất của giống X **ít phân tán**, tức ổn định hơn. Nên khuyên chọn **giống X**.

![Hình 2. Cùng trung bình 60 tạ/ha nhưng giống Y "bè" hơn: khoảng từ x̄ − s đến x̄ + s của Y rộng hơn hẳn của X](h2-hai-giong-lua.svg)

> [!vi-du] Ví dụ 4
> Thời gian (phút) làm xong một bài tập của 12 học sinh là:
> $$12,\ 14,\ 15,\ 17,\ 18,\ 18,\ 19,\ 21,\ 22,\ 23,\ 25,\ 28.$$
> a) Ghép số liệu thành các nhóm $[10;15),[15;20),[20;25),[25;30)$.
>
> b) Tính độ lệch chuẩn của mẫu số liệu gốc và của mẫu số liệu ghép nhóm (làm tròn đến hàng phần trăm). Giá trị nào là chính xác, giá trị nào là xấp xỉ?

> [!goi-y] Gợi ý 1
> Cẩn thận đầu mút: $15$ thuộc nhóm $[15;20)$, không thuộc $[10;15)$; $25$ thuộc $[25;30)$.

> [!goi-y] Gợi ý 2
> Mẫu gốc: dùng công thức lớp 10 (hoặc máy tính với cột tần số tắt / tần số đều bằng 1).

> [!loi-giai] Lời giải
> a) Tần số các nhóm lần lượt là $2;\ 5;\ 3;\ 2$ (nhóm $[10;15)$ gồm $12,14$; nhóm $[15;20)$ gồm $15,17,18,18,19$; nhóm $[20;25)$ gồm $21,22,23$; nhóm $[25;30)$ gồm $25,28$).
>
> b) **Mẫu gốc:** $\bar x=\dfrac{232}{12}\approx19{,}33$; $s^2\approx20{,}06$; $s\approx4{,}48$ (phút) — giá trị **chính xác**.
>
> **Mẫu ghép nhóm:** giá trị đại diện $12{,}5;\ 17{,}5;\ 22{,}5;\ 27{,}5$; $\bar x=\dfrac{235}{12}\approx19{,}58$; $s^2=\dfrac{4875}{12}-\left(\dfrac{235}{12}\right)^2\approx22{,}74$; $s\approx4{,}77$ (phút) — giá trị **xấp xỉ**.
>
> Hai kết quả gần nhau nhưng không bằng nhau, vì khi ghép nhóm ta đã "kéo" mọi số liệu về trung điểm nhóm.

## 2. Sử dụng phương sai, độ lệch chuẩn đo độ rủi ro

### 2.1. Độ lệch chuẩn của lợi nhuận = thước đo rủi ro

Khi đầu tư, ai cũng muốn lợi nhuận **cao** và **đều đặn**. Một khoản đầu tư mà tháng lãi to, tháng lỗ nặng thì khó lường trước — người ta gọi là **rủi ro**. Trong tài chính, một cách đo độ rủi ro là dùng **độ lệch chuẩn của lợi nhuận**: độ lệch chuẩn càng lớn thì lợi nhuận càng dao động mạnh quanh mức trung bình, tức phương án đầu tư **càng rủi ro**.

> [!vi-du] Ví dụ 5
> Chị Mai bỏ cùng một số vốn vào hai phương án kinh doanh P và Q. Lợi nhuận (triệu đồng) mỗi tháng trong 36 tháng được thống kê như sau (số âm là lỗ):
>
> | Lợi nhuận (triệu đồng) | [−4; 0) | [0; 4) | [4; 8) | [8; 12) | [12; 16) |
> |---|---|---|---|---|---|
> | Số tháng theo phương án P | 2 | 6 | 20 | 6 | 2 |
> | Số tháng theo phương án Q | 8 | 5 | 10 | 5 | 8 |
>
> So sánh lợi nhuận trung bình và độ lệch chuẩn của hai phương án. Phương án nào rủi ro hơn?

> [!goi-y] Gợi ý 1
> Giá trị đại diện: $-2;\ 2;\ 6;\ 10;\ 14$. Chú ý giá trị đại diện âm — khi bình phương thì thành số dương.

> [!goi-y] Gợi ý 2
> Hai dòng tần số đều đối xứng quanh nhóm $[4;8)$. Độ lệch các nhóm so với $6$ là $-8;-4;0;4;8$.

> [!loi-giai] Lời giải
> **Trung bình:** $\bar x_P=\dfrac{2(-2)+6\cdot2+20\cdot6+6\cdot10+2\cdot14}{36}=\dfrac{216}{36}=6$; tương tự $\bar x_Q=\dfrac{8(-2)+5\cdot2+10\cdot6+5\cdot10+8\cdot14}{36}=\dfrac{216}{36}=6$ (triệu đồng).
>
> **Độ lệch chuẩn:**
> $$s_P^2=\dfrac{2\cdot64+6\cdot16+0+6\cdot16+2\cdot64}{36}=\dfrac{448}{36}\approx12{,}44,\quad s_P\approx3{,}53;$$
> $$s_Q^2=\dfrac{8\cdot64+5\cdot16+0+5\cdot16+8\cdot64}{36}=\dfrac{1184}{36}\approx32{,}89,\quad s_Q\approx5{,}73.$$
> Lợi nhuận trung bình như nhau ($6$ triệu đồng/tháng) nhưng $s_Q>s_P$, nên **phương án Q rủi ro hơn**. Bảng cũng cho thấy điều đó: Q có tới $8$ tháng lỗ, còn P chỉ có $2$ tháng.

![Hình 3. Hai phương án cùng lợi nhuận trung bình 6 triệu đồng/tháng; phương án Q có nhiều tháng ở hai đầu (kể cả vùng lỗ) nên độ lệch chuẩn lớn hơn](h3-dau-tu.svg)

### 2.2. Khi nào **không nên** so sánh bằng độ lệch chuẩn?

Độ lệch chuẩn đo độ phân tán theo **giá trị tuyệt đối**. Một khoản dao động $10$ triệu đồng là rất lớn với cửa hàng lãi trung bình $20$ triệu/tháng, nhưng chỉ là "muỗi" với công ty lãi trung bình $500$ triệu/tháng. Vì vậy:

> [!ghi-nho] Nhận xét (SGK tr. 83)
> **Không nên** dùng phương sai hay độ lệch chuẩn để so sánh độ rủi ro (độ phân tán) của hai mẫu khi **số trung bình của chúng khác nhau rất nhiều**. Tương tự, không so sánh trực tiếp $s$ của hai mẫu **khác đơn vị đo** (ví dụ chiều cao tính bằng cm và cân nặng tính bằng kg).

> [!em-co-biet] Hệ số biến thiên
> Trong những trường hợp đó, người ta dùng **hệ số biến thiên** (*Coefficient of Variation*)
> $$CV=\dfrac{s}{\bar x},$$
> thường viết dưới dạng phần trăm. $CV$ cho biết độ lệch chuẩn bằng **bao nhiêu phần trăm** của trung bình — một con số không có đơn vị, nên so sánh được giữa các mẫu có quy mô hay đơn vị khác nhau. $CV$ càng lớn thì độ phân tán tương đối càng lớn.

> [!vi-du] Ví dụ 6
> Doanh thu mỗi ngày (triệu đồng) trong 30 ngày của một quầy tạp hóa và của một siêu thị:
>
> | Doanh thu quầy tạp hóa | [2; 4) | [4; 6) | [6; 8) | [8; 10) | [10; 12) |
> |---|---|---|---|---|---|
> | Số ngày | 3 | 6 | 12 | 6 | 3 |
>
> | Doanh thu siêu thị | [100; 110) | [110; 120) | [120; 130) | [130; 140) | [140; 150) |
> |---|---|---|---|---|---|
> | Số ngày | 4 | 6 | 10 | 6 | 4 |
>
> a) Tính độ lệch chuẩn doanh thu của mỗi nơi (làm tròn đến hàng phần trăm).
>
> b) Có thể kết luận "doanh thu của siêu thị biến động mạnh hơn" chỉ dựa vào độ lệch chuẩn không? Dùng hệ số biến thiên để so sánh.

> [!goi-y] Gợi ý 1
> Cả hai bảng đều đối xứng nên trung bình là trung điểm của nhóm giữa: $7$ và $125$.

> [!goi-y] Gợi ý 2
> Trung bình chênh nhau gần $18$ lần — đây đúng là tình huống "trung bình khác nhau rất nhiều".

> [!loi-giai] Lời giải
> a) Quầy tạp hóa: $\bar x_1=7$, $s_1^2=\dfrac{3\cdot16+6\cdot4+0+6\cdot4+3\cdot16}{30}=\dfrac{144}{30}=4{,}8$, $s_1\approx2{,}19$ (triệu đồng).
>
> Siêu thị: $\bar x_2=125$, $s_2^2=\dfrac{4\cdot400+6\cdot100+0+6\cdot100+4\cdot400}{30}=\dfrac{4400}{30}\approx146{,}67$, $s_2\approx12{,}11$ (triệu đồng).
>
> b) $s_2$ lớn hơn $s_1$ khoảng $5{,}5$ lần, nhưng trung bình cũng lớn hơn khoảng $18$ lần, nên **không** thể kết luận chỉ từ độ lệch chuẩn. Tính hệ số biến thiên:
> $$CV_1=\dfrac{2{,}19}{7}\approx31{,}3\%,\qquad CV_2=\dfrac{12{,}11}{125}\approx9{,}7\%.$$
> So với mức trung bình của chính nó, doanh thu **quầy tạp hóa** mới là nơi biến động mạnh hơn.

> [!ung-dung] Độ lệch chuẩn quanh ta
> - **Y dược:** hàm lượng hoạt chất trong từng viên thuốc phải đều nhau — nhà sản xuất kiểm tra độ lệch chuẩn của hàm lượng theo lô. Kết quả xét nghiệm (đường huyết, cholesterol…) thường được báo kèm "khoảng tham chiếu", xây dựng từ trung bình và độ lệch chuẩn của nhóm người khỏe mạnh.
> - **Đo lường:** độ lệch chuẩn của nhiều lần đo lặp lại cho biết dụng cụ đo **chính xác** đến đâu (như Ví dụ 2).
> - **Thể thao, học tập:** vận động viên có thành tích ít dao động (độ lệch chuẩn nhỏ) là vận động viên **ổn định**; lớp có điểm độ lệch chuẩn nhỏ là lớp **đồng đều**.
> - **Tài chính:** quỹ đầu tư thường công bố độ lệch chuẩn của lợi suất để nhà đầu tư biết mức rủi ro.

## Dạng bài thi hay gặp

### Dạng 1. Tính số trung bình, phương sai, độ lệch chuẩn từ bảng ghép nhóm

- **Nhận biết:** bảng ghép nhóm + "phương sai (độ lệch chuẩn) của mẫu số liệu ghép nhóm bằng… (làm tròn…)". Thường là câu trả lời ngắn hoặc 4 lựa chọn.
- **Phương pháp:** (1) Tính $n$ và các giá trị đại diện $x_i$. (2) Tính $\bar x$. (3) Tính $s^2$ bằng một trong hai dạng (hoặc máy tính: đọc $\sigma^2_x$, $\sigma_x$). (4) Lấy căn nếu đề hỏi $s$, **làm tròn ở bước cuối**.
- **Bẫy:** dùng đầu mút thay giá trị đại diện; đọc $s_x$ thay vì $\sigma_x$; nhầm phương sai với độ lệch chuẩn; quên trừ $\bar x^2$.

> [!vi-du] Ví dụ 7
> Khối lượng (gam) của 50 quả cam trong một sọt:
>
> | Khối lượng (g) | [150; 160) | [160; 170) | [170; 180) | [180; 190) | [190; 200) |
> |---|---|---|---|---|---|
> | Số quả | 6 | 12 | 18 | 10 | 4 |
>
> Tính độ lệch chuẩn của mẫu số liệu ghép nhóm (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> Giá trị đại diện $155;\ 165;\ 175;\ 185;\ 195$. Tính $\bar x$ trước.

> [!goi-y] Gợi ý 2
> $\bar x=173{,}8$. Có thể đổi biến $u=\dfrac{x-175}{10}\in\{-2;-1;0;1;2\}$ cho nhẹ số.

> [!loi-giai] Lời giải
> $n=50$, $\bar x=\dfrac{6\cdot155+12\cdot165+18\cdot175+10\cdot185+4\cdot195}{50}=\dfrac{8690}{50}=173{,}8$ (g).
>
> $\dfrac1n\sum m_ix_i^2=\dfrac{1\,516\,450}{50}=30\,329$, nên $s^2=30\,329-173{,}8^2=30\,329-30\,206{,}44=122{,}56$.
>
> $s=\sqrt{122{,}56}\approx11{,}1$ (g).
>
> (Đổi biến: $\bar u=\dfrac{-12-12+0+10+8}{50}=-0{,}12$, $s_u^2=\dfrac{24+12+0+10+16}{50}-0{,}0144=1{,}2256$, $s_x=10\sqrt{1{,}2256}\approx11{,}1$ — cùng kết quả.)

### Dạng 2. So sánh độ phân tán (độ ổn định, độ rủi ro) của hai mẫu

- **Nhận biết:** hai dòng tần số trên cùng một bảng; hỏi "ổn định hơn", "đồng đều hơn", "rủi ro hơn", "phân tán hơn" **dựa trên độ lệch chuẩn**.
- **Phương pháp:** tính $\bar x$ và $s$ cho từng mẫu → kiểm tra hai trung bình có gần nhau không → mẫu có $s$ **nhỏ hơn** thì ổn định/đồng đều hơn; $s$ **lớn hơn** thì phân tán/rủi ro hơn. Nếu trung bình chênh nhau rất nhiều → dùng $CV$.
- **Bẫy:** "ổn định hơn" là $s$ **nhỏ** hơn, không phải lớn hơn; nhầm "trung bình cao hơn" với "phân tán hơn"; với thời gian chạy, **trung bình nhỏ** là chạy **nhanh** — đó là câu hỏi khác với "ổn định".

> [!vi-du] Ví dụ 8
> Thời gian chạy 100 m (giây) trong 20 lần tập của hai bạn An và Bình:
>
> | Thời gian (giây) | [12; 12,4) | [12,4; 12,8) | [12,8; 13,2) | [13,2; 13,6) |
> |---|---|---|---|---|
> | Số lần của An | 2 | 9 | 7 | 2 |
> | Số lần của Bình | 5 | 5 | 4 | 6 |
>
> Dựa vào độ lệch chuẩn, bạn nào có thành tích luyện tập ổn định hơn?

> [!goi-y] Gợi ý 1
> Giá trị đại diện $12{,}2;\ 12{,}6;\ 13{,}0;\ 13{,}4$. Dùng máy tính cho nhanh.

> [!goi-y] Gợi ý 2
> Trung bình của hai bạn chỉ chênh nhau $0{,}04$ giây, nên so sánh trực tiếp độ lệch chuẩn được.

> [!loi-giai] Lời giải
> **An:** $\bar x_A=\dfrac{2\cdot12{,}2+9\cdot12{,}6+7\cdot13+2\cdot13{,}4}{20}=12{,}78$; $s_A^2=\dfrac{3268{,}64}{20}-12{,}78^2=0{,}1036$; $s_A\approx0{,}32$ (giây).
>
> **Bình:** $\bar x_B=12{,}82$; $s_B^2=\dfrac{3291{,}36}{20}-12{,}82^2=0{,}2156$; $s_B\approx0{,}46$ (giây).
>
> Trung bình gần như nhau, còn $s_A<s_B$ nên **An có thành tích ổn định hơn**.

### Dạng 3. Đúng/Sai tổng hợp Bài 9 – Bài 10

- **Nhận biết:** một bảng thực tế và 4 mệnh đề về $R$, $Q_1$, $Q_3$, $\Delta_Q$, $\bar x$, $s^2$, $s$.
- **Phương pháp:** lập ngay hai dòng phụ: **tần số tích lũy** (cho tứ phân vị) và **giá trị đại diện** (cho trung bình, phương sai); bấm máy lấy $\bar x$, $\sigma_x$ một lần; kiểm tra từng ý.
- **Bẫy:** ý ghi "phương sai bằng…" nhưng con số lại là độ lệch chuẩn (hoặc ngược lại); ý ghi trung bình bằng **giá trị đại diện của nhóm giữa** (chỉ đúng khi bảng đối xứng); nhầm $\Delta_Q$ với $s$.

> [!vi-du] Ví dụ 9 (Đúng/Sai)
> Thời gian dùng mạng xã hội mỗi ngày của 40 học sinh:
>
> | Thời gian (phút) | [0; 30) | [30; 60) | [60; 90) | [90; 120) | [120; 150) |
> |---|---|---|---|---|---|
> | Số học sinh | 3 | 9 | 14 | 10 | 4 |
>
> a) Khoảng biến thiên của mẫu số liệu là $150$ phút.
>
> b) Số trung bình của mẫu số liệu là $75$ phút.
>
> c) Phương sai của mẫu số liệu xấp xỉ $32{,}44$.
>
> d) Khoảng tứ phân vị của mẫu số liệu lớn hơn độ lệch chuẩn của nó.

> [!goi-y] Gợi ý 1
> Giá trị đại diện $15;\ 45;\ 75;\ 105;\ 135$. Bảng **không** đối xứng ($3$ khác $4$, $9$ khác $10$).

> [!goi-y] Gợi ý 2
> Tần số tích lũy $3;\ 12;\ 26;\ 36;\ 40$; vị trí $\frac n4=10$, $\frac{3n}{4}=30$.

> [!loi-giai] Lời giải
> a) **Đúng** — $R=150-0=150$.
>
> b) **Sai** — $\bar x=\dfrac{3\cdot15+9\cdot45+14\cdot75+10\cdot105+4\cdot135}{40}=\dfrac{3090}{40}=77{,}25$ (phút).
>
> c) **Sai** — $s^2=\dfrac{280\,800}{40}-77{,}25^2=7020-5967{,}5625=1052{,}4375$. Số $32{,}44$ là **độ lệch chuẩn** $s\approx32{,}44$, không phải phương sai.
>
> d) **Đúng** — $Q_1=30+\dfrac{10-3}{9}\cdot30\approx53{,}33$; $Q_3=90+\dfrac{30-26}{10}\cdot30=102$; $\Delta_Q\approx48{,}67>32{,}44\approx s$.

### Dạng 4. Bài toán có tham số / ra quyết định thực tế

- **Nhận biết:** bảng có một tần số chưa biết kèm điều kiện về trung bình (hoặc cỡ mẫu); hoặc bài toán "có cần sửa máy / nên chọn phương án nào" so với một ngưỡng.
- **Phương pháp:** lập phương trình từ điều kiện $\bar x=\dfrac{\sum m_ix_i}{n}$ để tìm tần số; sau đó tính $s$ như Dạng 1; cuối cùng so với ngưỡng hoặc so sánh hai mẫu.
- **Bẫy:** quên rằng tần số chưa biết cũng nằm trong $n$ (mẫu số); làm tròn $s$ rồi mới so sánh với ngưỡng khi hai số rất sát nhau.

> [!vi-du] Ví dụ 10
> Số giờ tự học mỗi tuần của một nhóm học sinh được cho trong bảng, trong đó $m$ là số nguyên dương chưa biết:
>
> | Số giờ | [4; 6) | [6; 8) | [8; 10) | [10; 12) | [12; 14) |
> |---|---|---|---|---|---|
> | Số học sinh | 5 | $m$ | 12 | 6 | 2 |
>
> Biết số trung bình của mẫu số liệu ghép nhóm là $8{,}25$ giờ. Tính độ lệch chuẩn của mẫu số liệu (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> $n=25+m$; tổng $\sum m_ix_i=5\cdot5+7m+12\cdot9+6\cdot11+2\cdot13=225+7m$.

> [!goi-y] Gợi ý 2
> Giải $\dfrac{225+7m}{25+m}=8{,}25$.

> [!loi-giai] Lời giải
> $225+7m=8{,}25(25+m)=206{,}25+8{,}25m\Rightarrow1{,}25m=18{,}75\Rightarrow m=15$, nên $n=40$.
>
> $\sum m_ix_i^2=5\cdot25+15\cdot49+12\cdot81+6\cdot121+2\cdot169=125+735+972+726+338=2896$.
>
> $s^2=\dfrac{2896}{40}-8{,}25^2=72{,}4-68{,}0625=4{,}3375$, nên $s\approx2{,}08$ (giờ).

## Tóm tắt

Mẫu ghép nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$, tần số $m_1,\dots,m_k$, cỡ mẫu $n$.

| Nội dung | Công thức / Ghi nhớ |
|---|---|
| Giá trị đại diện | $x_i=\dfrac{a_i+a_{i+1}}{2}$ |
| Số trung bình | $\bar x=\dfrac{m_1x_1+\dots+m_kx_k}{n}$ |
| Phương sai (định nghĩa) | $s^2=\dfrac{m_1(x_1-\bar x)^2+\dots+m_k(x_k-\bar x)^2}{n}$ |
| Phương sai (tính nhanh) | $s^2=\dfrac1n\left(m_1x_1^2+\dots+m_kx_k^2\right)-\bar x^2$ |
| Độ lệch chuẩn | $s=\sqrt{s^2}$, cùng đơn vị với số liệu |
| Đại lượng chia $n-1$ | $\hat s^2=\dfrac{\sum m_i(x_i-\bar x)^2}{n-1}$ (máy: $s_x$); đề hỏi $s$ thì dùng $\sigma_x$ |
| Tính chất | Cộng cùng số vào số liệu: $s$ không đổi; nhân số liệu với $c$: $s$ nhân $\lvert c\rvert$; nhân mọi tần số cùng một số: $\bar x$, $s$ không đổi |
| Ý nghĩa | $s$ càng lớn → càng phân tán quanh $\bar x$ (kém ổn định, rủi ro hơn); là xấp xỉ của mẫu gốc |
| Đo rủi ro | Cùng trung bình: $s$ lớn hơn → rủi ro hơn. Trung bình chênh nhiều / khác đơn vị: dùng $CV=\dfrac{s}{\bar x}$ |
| So với Bài 9 | $R$: hai đầu mút; $\Delta_Q$: nửa giữa, bền với giá trị bất thường; $s$: dùng mọi nhóm, nhạy với giá trị xa trung bình |

**Sơ đồ khi gặp đề:** đọc bảng → tính $n$ → viết dòng giá trị đại diện → $\bar x$ → $s^2$ (định nghĩa hoặc tính nhanh, hoặc máy: $\sigma^2_x$) → $s$ → đọc kĩ đề hỏi $s^2$ hay $s$, làm tròn ở bước cuối → so sánh (cùng trung bình: $s$ nhỏ hơn = ổn định hơn; trung bình chênh nhiều: dùng $CV$).
