---
title: Phương trình mặt phẳng
thoi-gian: 55 phút
muc-tieu:
  - Hiểu vectơ pháp tuyến, cặp vectơ chỉ phương của mặt phẳng; tính được tích có hướng của hai vectơ và dùng nó để tìm vectơ pháp tuyến
  - Nhận biết phương trình tổng quát của mặt phẳng, đọc được vectơ pháp tuyến và kiểm tra một điểm có thuộc mặt phẳng hay không
  - Lập được phương trình mặt phẳng qua một điểm và biết vectơ pháp tuyến, qua một điểm và biết cặp vectơ chỉ phương, qua ba điểm không thẳng hàng, theo đoạn chắn
  - Nhận biết hai mặt phẳng vuông góc, song song, trùng nhau bằng vectơ pháp tuyến
  - Tính khoảng cách từ một điểm đến một mặt phẳng, khoảng cách giữa hai mặt phẳng song song
  - Vận dụng vào bài toán thực tiễn (mái nhà, tấm pin mặt trời, flycam bay trên sườn dốc, camera…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mặt phẳng được "định vị" bởi **một điểm** và **một hướng vuông góc** với nó — vectơ pháp tuyến $\vec n\ne\vec 0$.
> 2. Có hai vectơ $\vec u,\vec v$ không cùng phương "nằm dọc" mặt phẳng thì vectơ pháp tuyến là **tích có hướng** $\vec n=[\vec u,\vec v]$.
> 3. Qua $M_0(x_0;\,y_0;\,z_0)$, pháp tuyến $\vec n=(A;\,B;\,C)$: $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$, tức là $Ax+By+Cz+D=0$.
> 4. Vuông góc $\iff \vec n\cdot\vec n'=0$. Song song $\iff \vec n'=k\vec n$ và $D'\ne kD$.
> 5. Khoảng cách: $d(M,(P))=\dfrac{\lvert Ax_0+By_0+Cz_0+D\rvert}{\sqrt{A^2+B^2+C^2}}$.

Chương V mở đầu bằng một ý tưởng em đã gặp ở lớp 10: **dùng tọa độ để biến hình học thành đại số**. Ở lớp 10, đường thẳng trong mặt phẳng $Oxy$ có phương trình $ax+by+c=0$. Lên không gian $Oxyz$, "người anh em" của nó là **mặt phẳng** với phương trình $Ax+By+Cz+D=0$. Khi đã có phương trình, những câu hỏi như "điểm này có nằm trên mái nhà không?", "flycam đang cách sườn đồi bao xa?" chỉ còn là việc **thay số vào công thức**.

> [!nen-tang] Nhắc lại cần dùng (Bài 6, Bài 8 và lớp 11)
> - Với $\vec a=(x;\,y;\,z)$, $\vec b=(x';\,y';\,z')$: tích vô hướng $\vec a\cdot\vec b=xx'+yy'+zz'$.
> - $\vec a\perp\vec b\iff xx'+yy'+zz'=0$.
> - $\vec a$ cùng phương $\vec b\ne\vec 0$ $\iff$ có số $k$ để $\vec a=k\vec b$ (ba tọa độ tỉ lệ cùng một $k$).
> - $\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$ — "cuối trừ đầu".
> - Lớp 11: đường thẳng vuông góc với mặt phẳng khi nó vuông góc với **hai đường thẳng cắt nhau** nằm trong mặt phẳng đó, và khi ấy nó vuông góc với **mọi** đường thẳng nằm trong mặt phẳng.

## 1. Vectơ pháp tuyến và cặp vectơ chỉ phương của mặt phẳng

### 1.1. Vectơ pháp tuyến

Đặt một cuốn sách lên mặt bàn nằm ngang. Mặt bàn đẩy cuốn sách bằng một lực **thẳng đứng hướng lên** — vuông góc với mặt bàn. Trong Vật lí, lực ấy gọi là **phản lực pháp tuyến**. Chữ "pháp tuyến" nghĩa là "vuông góc với mặt". Toán học mượn đúng ý này.

> [!ghi-nho] Định nghĩa (SGK tr. 30)
> Vectơ $\vec n\ne\vec 0$ là **vectơ pháp tuyến** (viết tắt VTPT) của mặt phẳng $(\alpha)$ nếu giá của $\vec n$ vuông góc với $(\alpha)$.

![Hình 1. Vectơ pháp tuyến n vuông góc với mặt phẳng; cặp vectơ chỉ phương u, v nằm dọc mặt phẳng và n = [u, v]](h1-vtpt-vtcp.svg)

Hai điều cần nhớ:

- **Vì sao một điểm và một VTPT là đủ?** Qua một điểm cho trước chỉ có **đúng một** mặt phẳng vuông góc với một đường thẳng cho trước (kiến thức lớp 11). Nên biết điểm $M_0$ và $\vec n$ là "chốt" được mặt phẳng.
- **VTPT không duy nhất.** Kéo dài, thu ngắn hay đảo chiều $\vec n$ thì giá của nó vẫn vuông góc với mặt phẳng. Vì vậy $k\vec n$ (với $k\ne0$) cũng là VTPT. Ta thường chọn VTPT có tọa độ **nguyên, gọn nhất** cho dễ tính.

> [!vi-du] Ví dụ 1
> Trong không gian $Oxyz$, cho $A(2;\,-1;\,3)$ và $B(4;\,3;\,-1)$.
>
> a) Chỉ ra một VTPT của mặt phẳng trung trực của đoạn $AB$.
>
> b) Vectơ $\vec m=(-1;\,-2;\,2)$ có phải là VTPT của mặt phẳng đó không?
>
> c) Chỉ ra một VTPT của mặt phẳng tọa độ $(Oxy)$.

> [!goi-y] Gợi ý 1
> Mặt phẳng trung trực của $AB$ là mặt phẳng **vuông góc với $AB$** tại trung điểm. Vậy đường thẳng $AB$ vuông góc với nó.

> [!goi-y] Gợi ý 2
> b) Thử xem $\vec m$ có bằng $k\cdot\overrightarrow{AB}$ không. c) Trục nào vuông góc với mặt sàn $(Oxy)$?

> [!loi-giai] Lời giải
> a) $\overrightarrow{AB}=(2;\,4;\,-4)$ có giá vuông góc với mặt phẳng trung trực, nên là một VTPT. Gọn hơn, ta có thể lấy $\frac12\overrightarrow{AB}=(1;\,2;\,-2)$.
>
> b) $\vec m=(-1;\,-2;\,2)=-\frac12\overrightarrow{AB}$, cùng phương với $\overrightarrow{AB}$ và khác $\vec 0$, nên **có**, $\vec m$ cũng là một VTPT.
>
> c) Trục $Oz$ vuông góc với $(Oxy)$ nên $\vec k=(0;\,0;\,1)$ là một VTPT của $(Oxy)$.

### 1.2. Tích có hướng của hai vectơ

Bài toán đặt ra: biết hai vectơ $\vec u,\vec v$ nằm dọc theo mặt phẳng, làm sao tìm **một vectơ vuông góc với cả hai**? Nếu giải hệ $\vec n\cdot\vec u=0$, $\vec n\cdot\vec v=0$ thì khá mất công. SGK đưa ra sẵn một "công thức chế tạo" vectơ đó.

> [!ghi-nho] Định nghĩa tích có hướng (SGK tr. 30)
> Cho $\vec u=(a;\,b;\,c)$ và $\vec v=(a';\,b';\,c')$. Vectơ
> $$\vec n=(bc'-b'c;\ ca'-c'a;\ ab'-a'b)$$
> vuông góc với cả $\vec u$ và $\vec v$, gọi là **tích có hướng** của $\vec u$ và $\vec v$, kí hiệu $[\vec u,\vec v]$.

**Vì sao nó vuông góc với cả hai?** Kiểm tra trực tiếp bằng tích vô hướng:
$$[\vec u,\vec v]\cdot\vec u=a(bc'-b'c)+b(ca'-c'a)$$
$$+\,c(ab'-a'b).$$
Phá ngoặc được $abc'-ab'c+a'bc-abc'+ab'c-a'bc$ — các số hạng **triệt tiêu từng cặp**, còn lại $0$. Với $\vec v$ cũng vậy. Em không cần nhớ phép biến đổi này, chỉ cần tin rằng công thức luôn cho một vectơ vuông góc với cả hai.

**Cách nhớ bằng định thức cấp hai.** SGK kí hiệu $\begin{vmatrix} x & y\\ x' & y'\end{vmatrix}=xy'-x'y$ ("đường chéo chính trừ đường chéo phụ"). Khi đó
$$[\vec u,\vec v]=\left(\begin{vmatrix} b & c\\ b' & c'\end{vmatrix};\ \begin{vmatrix} c & a\\ c' & a'\end{vmatrix};\ \begin{vmatrix} a & b\\ a' & b'\end{vmatrix}\right).$$

![Hình 2. Mẹo "che cột" khi tính tích có hướng: viết u trên, v dưới; che lần lượt từng cột, lấy định thức của hai cột còn lại theo thứ tự vòng](h2-che-cot.svg)

Viết $\vec u$ ở dòng trên, $\vec v$ ở dòng dưới. Tọa độ thứ nhất: **che cột 1**, lấy định thức cột 2 – cột 3. Tọa độ thứ hai: **che cột 2**, lấy cột 3 – cột 1 (đi vòng, quay lại đầu). Tọa độ thứ ba: **che cột 3**, lấy cột 1 – cột 2.

> [!ghi-nho] Tính chất cần nhớ
> - $[\vec u,\vec v]$ vuông góc với cả $\vec u$ và $\vec v$.
> - $[\vec u,\vec v]=\vec 0\iff\vec u,\vec v$ **cùng phương**.
> - Đổi thứ tự thì đổi dấu: $[\vec v,\vec u]=-[\vec u,\vec v]$ (vẫn là VTPT, chỉ ngược chiều).

> [!vi-du] Ví dụ 2
> Cho $\vec u=(2;\,-1;\,3)$ và $\vec v=(1;\,4;\,-2)$. Tính $[\vec u,\vec v]$ rồi kiểm tra lại rằng nó vuông góc với $\vec u$ và $\vec v$.

> [!goi-y] Gợi ý 1
> Viết $\vec u$ trên, $\vec v$ dưới thành bảng $\begin{matrix} 2 & -1 & 3\\ 1 & 4 & -2\end{matrix}$. Che cột 1, còn định thức $\begin{vmatrix} -1 & 3\\ 4 & -2\end{vmatrix}$.

> [!goi-y] Gợi ý 2
> Tọa độ giữa: che cột 2, lấy **cột 3 rồi cột 1**: $\begin{vmatrix} 3 & 2\\ -2 & 1\end{vmatrix}$.

> [!loi-giai] Lời giải
> - Tọa độ 1: $(-1)(-2)-4\cdot3=2-12=-10$.
> - Tọa độ 2: $3\cdot1-(-2)\cdot2=3+4=7$.
> - Tọa độ 3: $2\cdot4-1\cdot(-1)=8+1=9$.
>
> Vậy $[\vec u,\vec v]=(-10;\,7;\,9)$. Kiểm tra: $(-10)\cdot2+7\cdot(-1)+9\cdot3=-20-7+27=0$ và $(-10)\cdot1+7\cdot4+9\cdot(-2)=-10+28-18=0$ ✓.

> [!bay] Tọa độ giữa hay sai dấu
> Nhiều bạn tính tọa độ giữa bằng định thức "cột 1 – cột 3" $\begin{vmatrix} a & c\\ a' & c'\end{vmatrix}=ac'-a'c$ — kết quả bị **ngược dấu**. Hoặc nhớ "đi vòng" (cột 3 rồi cột 1), hoặc nhớ "tọa độ giữa phải đổi dấu". Đề trắc nghiệm luôn có phương án nhiễu sai đúng ở chỗ này. Luôn **thử lại** bằng tích vô hướng: chỉ mất 10 giây.

> [!meo] Bấm máy Casio fx-580VN X
> Vào **MENU → Vectơ**, khai báo VctA $=\vec u$, VctB $=\vec v$ (kích thước 3). Ở màn hình tính, gõ **VctA × VctB** (phím nhân) rồi **=**: máy cho tích có hướng. (Tích vô hướng thì dùng lệnh **Dot** trong OPTN.) Thứ tự VctA, VctB phải đúng thứ tự $\vec u,\vec v$ — đổi chỗ là đổi dấu. Chỉ dùng máy để **soát lại**; khi làm tự luận vẫn viết đủ ba định thức.

### 1.3. Cặp vectơ chỉ phương của mặt phẳng

> [!ghi-nho] Định nghĩa (SGK tr. 31)
> - Hai vectơ $\vec u,\vec v$ là **cặp vectơ chỉ phương** (cặp VTCP) của mặt phẳng $(P)$ nếu chúng **không cùng phương** và có giá **nằm trong hoặc song song** với $(P)$.
> - Khi đó $[\vec u,\vec v]$ là một VTPT của $(P)$.

**Vì sao?** Giá của $[\vec u,\vec v]$ vuông góc với hai đường thẳng không song song cùng nằm "dọc" $(P)$, nên (theo lớp 11) nó vuông góc với $(P)$. Và vì $\vec u,\vec v$ không cùng phương nên $[\vec u,\vec v]\ne\vec 0$ — đủ điều kiện làm VTPT.

Điều kiện "không cùng phương" rất quan trọng: hai vectơ cùng phương chỉ cho **một** hướng, không đủ để giữ mặt phẳng (mặt phẳng có thể "xoay" quanh hướng đó như cánh cửa xoay quanh bản lề).

> [!vi-du] Ví dụ 3
> a) Mặt phẳng $(\alpha)$ song song với giá của hai vectơ $\vec u=(1;\,0;\,2)$ và $\vec v=(0;\,1;\,-1)$. Tìm một VTPT của $(\alpha)$.
>
> b) Hai vectơ $\vec p=(1;\,2;\,-1)$ và $\vec q=(-2;\,-4;\,2)$ có thể là cặp VTCP của một mặt phẳng không?

> [!goi-y] Gợi ý 1
> a) Tính $[\vec u,\vec v]$ và kiểm tra nó khác $\vec 0$.

> [!goi-y] Gợi ý 2
> b) Nhìn kĩ: $\vec q$ có liên hệ gì với $\vec p$?

> [!loi-giai] Lời giải
> a) $[\vec u,\vec v]=\big(0\cdot(-1)-2\cdot1;\ 2\cdot0-1\cdot(-1);\ 1\cdot1-0\cdot0\big)=(-2;\,1;\,1)\ne\vec 0$. Vậy $\vec n=(-2;\,1;\,1)$ là một VTPT của $(\alpha)$.
>
> b) $\vec q=-2\vec p$ nên hai vectơ cùng phương (khi đó $[\vec p,\vec q]=\vec 0$). Chúng **không** thể là cặp VTCP.

> [!ung-dung] Moment lực — vì sao cờ lê càng dài càng nhẹ tay
> Trong Vật lí, khi em tác dụng lực $\vec F$ vào cán cờ lê tại điểm $P$ để vặn con ốc ở $O$, tác dụng làm quay được đo bằng **moment lực** $\vec M=[\overrightarrow{OP},\vec F]$ (SGK tr. 31). Nếu cầm xa gấp đôi, tức $\overrightarrow{OP'}=2\overrightarrow{OP}$, thì mỗi tọa độ của tích có hướng đều nhân 2, nên moment cũng gấp đôi với cùng một lực. Muốn đỡ tốn sức: **cầm xa đầu ốc** và **đẩy vuông góc với cán**.

## 2. Phương trình tổng quát của mặt phẳng

### 2.1. Từ hình học sang đại số

Cho mặt phẳng $(\alpha)$ đi qua $M_0(x_0;\,y_0;\,z_0)$, có VTPT $\vec n=(A;\,B;\,C)$. Lấy một điểm bất kì $M(x;\,y;\,z)$.

- Nếu $M$ nằm trên $(\alpha)$ thì $\overrightarrow{M_0M}$ nằm "dọc" mặt phẳng, nên **vuông góc với $\vec n$**.
- Ngược lại, nếu $\overrightarrow{M_0M}\perp\vec n$ thì $M$ không thể "lệch" ra khỏi mặt phẳng.

Vậy $M\in(\alpha)\iff\vec n\cdot\overrightarrow{M_0M}=0\iff A(x-x_0)+B(y-y_0)+C(z-z_0)=0.$

Phá ngoặc ra một phương trình **bậc nhất** đối với $x,y,z$.

> [!ghi-nho] Phương trình tổng quát (SGK tr. 32)
> - Mỗi mặt phẳng đều có phương trình dạng $Ax+By+Cz+D=0$, với $A,B,C$ **không đồng thời bằng 0**.
> - Ngược lại, mỗi phương trình như vậy xác định một mặt phẳng nhận $\vec n=(A;\,B;\,C)$ làm VTPT.

Nói gọn: **hệ số của $x,y,z$ chính là tọa độ VTPT.** Còn $D$ quyết định mặt phẳng "nằm ở đâu" (đẩy song song lên xuống).

> [!vi-du] Ví dụ 4
> a) Trong các phương trình sau, phương trình nào là phương trình tổng quát của một mặt phẳng?
> (1) $2x-y+z^2=0$; (2) $\dfrac x2+\dfrac y3-z=1$; (3) $xy-z+1=0$; (4) $3x-z+2=0$.
>
> b) Với mặt phẳng $(\alpha):3x-z+2=0$, chỉ ra một VTPT và cho biết điểm nào trong hai điểm $A(1;\,5;\,5)$, $B(0;\,1;\,-2)$ thuộc $(\alpha)$.

> [!goi-y] Gợi ý 1
> a) Cần đúng dạng **bậc nhất**: không có $z^2$, không có tích $xy$. Phân số với hệ số là số thì vẫn được (nhân lên để khử mẫu).

> [!goi-y] Gợi ý 2
> b) Phương trình $3x-z+2=0$ **không có** $y$, nghĩa là hệ số của $y$ bằng $0$. Thay tọa độ từng điểm vào vế trái.

> [!loi-giai] Lời giải
> a) (1) có $z^2$, (3) có $xy$ — không phải bậc nhất. (2) nhân 6 được $3x+2y-6z-6=0$, là phương trình mặt phẳng. (4) cũng vậy. Vậy (2) và (4) là phương trình mặt phẳng.
>
> b) $(\alpha):3x+0y-1z+2=0$ nên $\vec n=(3;\,0;\,-1)$.
> Thay $A$: $3\cdot1-5+2=0$ nên $A\in(\alpha)$. Thay $B$: $3\cdot0-(-2)+2=4\ne0$ nên $B\notin(\alpha)$.

> [!bay] Đọc VTPT khi thiếu biến
> Với $3x-z+2=0$, VTPT là $(3;\,0;\,-1)$ chứ **không phải** $(3;\,-1;\,2)$. Phải đặt số vào **đúng vị trí** của $x$, $y$, $z$. Biến nào vắng mặt thì tọa độ đó bằng $0$. Hằng số $D$ **không** thuộc VTPT.

### 2.2. Một số mặt phẳng đặc biệt

Bảng dưới đây không có sẵn trong SGK (mở rộng), nhưng suy ra ngay từ cách đọc VTPT và việc thay tọa độ $O$:

| Phương trình | Đặc điểm | Lí do |
|---|---|---|
| $z=0$ | mặt phẳng $(Oxy)$ | VTPT $\vec k$, qua $O$ |
| $x=0$ | mặt phẳng $(Oyz)$ | VTPT $\vec i$, qua $O$ |
| $y=0$ | mặt phẳng $(Oxz)$ | VTPT $\vec j$, qua $O$ |
| $D=0$ | đi qua gốc $O$ | $O(0;0;0)$ thỏa mãn |
| Thiếu $x$ ($A=0$), $D\ne0$ | song song với trục $Ox$ | $\vec n\perp\vec i$ |
| Thiếu $x$ ($A=0$), $D=0$ | chứa trục $Ox$ | thêm: qua $O$ |
| Chỉ có $z$: $z=c$ | song song (hoặc trùng) $(Oxy)$ | VTPT cùng phương $\vec k$ |

> [!meo]
> "Thiếu biến nào thì song song (hoặc chứa) trục đó." Ví dụ $y-2z+4=0$ thiếu $x$ nên song song với $Ox$. Mặt phẳng "nằm ngang" ở độ cao $3$ là $z=3$, tức $z-3=0$.

## 3. Lập phương trình tổng quát của mặt phẳng

Mọi bài lập phương trình mặt phẳng đều quy về **một khuôn**: tìm **một điểm** và **một VTPT**, rồi thay vào $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$. Cái khó chỉ là tìm VTPT từ dữ kiện đề cho.

### 3.1. Qua một điểm và biết vectơ pháp tuyến

> [!ghi-nho] Công thức (SGK tr. 33)
> Mặt phẳng qua $M_0(x_0;\,y_0;\,z_0)$, VTPT $\vec n=(A;\,B;\,C)$:
> $$A(x-x_0)+B(y-y_0)+C(z-z_0)=0,$$
> tức là $Ax+By+Cz+D=0$ với $D=-(Ax_0+By_0+Cz_0)$.

> [!vi-du] Ví dụ 5
> a) Viết phương trình mặt phẳng qua $M(1;\,-2;\,3)$ và có VTPT $\vec n=(2;\,-1;\,4)$.
>
> b) Viết phương trình mặt phẳng qua $N(0;\,1;\,-1)$ và vuông góc với trục $Oz$.

> [!goi-y] Gợi ý 1
> a) Thay thẳng vào công thức, chú ý $y-(-2)=y+2$.

> [!goi-y] Gợi ý 2
> b) Vuông góc với $Oz$ thì VTPT là $\vec k=(0;\,0;\,1)$.

> [!loi-giai] Lời giải
> a) $2(x-1)-1\cdot(y+2)+4(z-3)=0\iff2x-y+4z-16=0$.
>
> b) $0(x-0)+0(y-1)+1\cdot(z+1)=0\iff z+1=0$. Đây là mặt phẳng "nằm ngang" ở độ cao $-1$.

> [!vi-du] Ví dụ 6 (tấm pin mặt trời)
> Một tấm pin mặt trời hoạt động tốt nhất khi tia nắng chiếu **vuông góc** với mặt tấm pin. Trong hệ $Oxyz$ (đơn vị mét), tâm tấm pin đặt tại $M(2;\,1;\,1)$, và vào buổi trưa tia nắng có hướng song song với vectơ $\vec u=(1;\,2;\,4)$. Viết phương trình mặt phẳng chứa tấm pin khi nó được chỉnh "đón nắng" tốt nhất.

> [!goi-y] Gợi ý 1
> Tia nắng vuông góc với tấm pin, nghĩa là $\vec u$ đóng vai trò gì đối với mặt phẳng tấm pin?

> [!goi-y] Gợi ý 2
> $\vec u$ là VTPT, mặt phẳng qua $M$.

> [!loi-giai] Lời giải
> $\vec u=(1;\,2;\,4)$ là VTPT, nên mặt phẳng là $1(x-2)+2(y-1)+4(z-1)=0\iff x+2y+4z-8=0$.

### 3.2. Qua một điểm và biết cặp vectơ chỉ phương

> [!ghi-nho] Các bước (SGK tr. 33)
> 1. Tìm VTPT $\vec n=[\vec u,\vec v]$.
> 2. Lập phương trình mặt phẳng qua điểm đã cho, có VTPT $\vec n$.

Những câu như "song song với trục $Oy$", "song song (hoặc chứa) đường thẳng $BC$" đều đang **ngầm cho một VTCP**: trục $Ox,Oy,Oz$ cho $\vec i,\vec j,\vec k$; đường thẳng $BC$ cho $\overrightarrow{BC}$.

> [!vi-du] Ví dụ 7
> Cho $A(1;\,0;\,-2)$, $B(2;\,1;\,0)$, $C(0;\,3;\,1)$. Viết phương trình mặt phẳng $(\alpha)$ đi qua $A$, đồng thời song song với trục $Ox$ và với đường thẳng $BC$.

> [!goi-y] Gợi ý 1
> Hai VTCP: $\vec i=(1;\,0;\,0)$ và $\overrightarrow{BC}$.

> [!goi-y] Gợi ý 2
> $\overrightarrow{BC}=(-2;\,2;\,1)$. Tính $[\vec i,\overrightarrow{BC}]$ bằng mẹo che cột.

> [!loi-giai] Lời giải
> $[\vec i,\overrightarrow{BC}]=\big(0\cdot1-0\cdot2;\ 0\cdot(-2)-1\cdot1;\ 1\cdot2-0\cdot(-2)\big)=(0;\,-1;\,2)$.
> Mặt phẳng qua $A(1;\,0;\,-2)$: $0(x-1)-1(y-0)+2(z+2)=0\iff -y+2z+4=0\iff y-2z-4=0$.
> Nhận xét: phương trình thiếu $x$ — đúng là song song với $Ox$ như đề yêu cầu ✓.

### 3.3. Qua ba điểm không thẳng hàng

Ba điểm không thẳng hàng $A,B,C$ cho sẵn cặp VTCP $\overrightarrow{AB},\overrightarrow{AC}$.

> [!ghi-nho] Các bước (SGK tr. 34)
> 1. Tính $\overrightarrow{AB}$, $\overrightarrow{AC}$.
> 2. VTPT $\vec n=[\overrightarrow{AB},\overrightarrow{AC}]$ (nếu ra $\vec 0$ thì ba điểm thẳng hàng — không xác định mặt phẳng).
> 3. Lập phương trình qua $A$ với VTPT $\vec n$.

> [!vi-du] Ví dụ 8
> Viết phương trình mặt phẳng $(ABC)$ với $A(1;\,2;\,0)$, $B(2;\,0;\,1)$, $C(0;\,1;\,3)$.

> [!goi-y] Gợi ý 1
> $\overrightarrow{AB}=(1;\,-2;\,1)$, $\overrightarrow{AC}=(-1;\,-1;\,3)$.

> [!goi-y] Gợi ý 2
> Tính tích có hướng, rồi có thể nhân với $-1$ cho đẹp.

> [!loi-giai] Lời giải
> $[\overrightarrow{AB},\overrightarrow{AC}]=\big((-2)\cdot3-1\cdot(-1);\ 1\cdot(-1)-3\cdot1;\ 1\cdot(-1)-(-1)\cdot(-2)\big)=(-5;\,-4;\,-3)\ne\vec 0$.
> Ba điểm không thẳng hàng, chọn $\vec n=(5;\,4;\,3)$.
> $(ABC):5(x-1)+4(y-2)+3(z-0)=0\iff5x+4y+3z-13=0$.
> Thử lại: $B$: $10+0+3-13=0$ ✓; $C$: $0+4+9-13=0$ ✓.

> [!meo] Trắc nghiệm: thử điểm thay vì giải
> Với câu 4 lựa chọn "phương trình mặt phẳng $(ABC)$ là…", em chỉ cần **thay tọa độ $A$, $B$, $C$** vào từng phương án — phương án nào thỏa cả ba điểm là đáp án. Thường chỉ cần thử 1–2 điểm là loại hết phương án sai.

> [!vi-du] Ví dụ 9 (vật chuyển động có nằm trong một mặt phẳng?)
> Một vật chuyển động trong không gian, tại thời điểm $t$ nó ở vị trí $M(1+\cos t;\ 2\sin t;\ \cos t-\sin t)$.
>
> a) Tìm vị trí $M_1,M_2,M_3$ lúc $t=0$, $t=\frac\pi2$, $t=\pi$ và viết phương trình mặt phẳng $(M_1M_2M_3)$.
>
> b) Vật có luôn chuyển động trong mặt phẳng đó không?

> [!goi-y] Gợi ý 1
> $\cos0=1,\ \sin0=0$; $\cos\frac\pi2=0,\ \sin\frac\pi2=1$; $\cos\pi=-1,\ \sin\pi=0$.

> [!goi-y] Gợi ý 2
> b) Thay $x=1+\cos t$, $y=2\sin t$, $z=\cos t-\sin t$ vào vế trái phương trình mặt phẳng, xem có luôn bằng $0$ với mọi $t$ không.

> [!loi-giai] Lời giải
> a) $M_1(2;\,0;\,1)$, $M_2(1;\,2;\,-1)$, $M_3(0;\,0;\,-1)$.
> $\overrightarrow{M_1M_2}=(-1;\,2;\,-2)$, $\overrightarrow{M_1M_3}=(-2;\,0;\,-2)$, tích có hướng bằng $(-4;\,2;\,4)$, chọn $\vec n=(2;\,-1;\,-2)$.
> Mặt phẳng: $2(x-2)-(y-0)-2(z-1)=0\iff2x-y-2z-2=0$.
>
> b) $2(1+\cos t)-2\sin t-2(\cos t-\sin t)-2=2+2\cos t-2\sin t-2\cos t+2\sin t-2=0$ với mọi $t$. Vậy vật **luôn** ở trong mặt phẳng $2x-y-2z-2=0$.

### 3.4. Phương trình mặt phẳng theo đoạn chắn

Khi mặt phẳng cắt ba trục tại $A(a;\,0;\,0)$, $B(0;\,b;\,0)$, $C(0;\,0;\,c)$ với $a,b,c\ne0$ (nên không đi qua $O$), có một công thức rất đẹp:

> [!ghi-nho] Phương trình theo đoạn chắn (SGK tr. 35)
> $$\frac xa+\frac yb+\frac zc=1.$$

![Hình 3. Mặt phẳng cắt ba trục tọa độ tại A(a; 0; 0), B(0; b; 0), C(0; 0; c)](h3-doan-chan.svg)

**Vì sao đúng?** Đây là phương trình bậc nhất (hệ số $\frac1a,\frac1b,\frac1c$ khác 0), nên nó là một mặt phẳng. Thay $A$: $\frac aa+0+0=1$ ✓; thay $B$, $C$ cũng đúng. Mà qua ba điểm không thẳng hàng chỉ có một mặt phẳng, nên đó chính là $(ABC)$.

> [!vi-du] Ví dụ 10
> Viết phương trình mặt phẳng đi qua $A(2;\,0;\,0)$, $B(0;\,-3;\,0)$, $C(0;\,0;\,6)$ dưới dạng tổng quát.

> [!goi-y] Gợi ý 1
> $a=2$, $b=-3$, $c=6$ (giữ nguyên dấu âm!).

> [!goi-y] Gợi ý 2
> Nhân hai vế với bội chung nhỏ nhất của $2,3,6$ là $6$.

> [!loi-giai] Lời giải
> $\dfrac x2+\dfrac y{-3}+\dfrac z6=1$. Nhân 6: $3x-2y+z=6\iff3x-2y+z-6=0$.

> [!bay]
> - Công thức đoạn chắn có vế phải bằng **1**, không phải $0$.
> - Khi chuyển sang dạng tổng quát, đừng quên chuyển số $1$ (đã nhân) sang vế trái: $3x-2y+z-6=0$.
> - Nếu mặt phẳng đi qua $O$ thì **không** dùng được đoạn chắn.

## 4. Điều kiện để hai mặt phẳng vuông góc với nhau

Ở lớp 11, góc giữa hai mặt phẳng bằng góc giữa hai đường thẳng lần lượt vuông góc với hai mặt phẳng đó. Hai đường thẳng "vuông góc với mặt phẳng" chính là giá của hai VTPT. Vậy: **hai mặt phẳng vuông góc khi và chỉ khi hai VTPT vuông góc.** Thử nghĩ tới bức tường và sàn nhà: VTPT của sàn hướng thẳng lên, VTPT của tường nằm ngang, đúng là vuông góc với nhau.

> [!ghi-nho] Điều kiện vuông góc (SGK tr. 36)
> Cho $(\alpha):Ax+By+Cz+D=0$ và $(\beta):A'x+B'y+C'z+D'=0$. Khi đó
> $$(\alpha)\perp(\beta)\iff\vec n\cdot\vec n'=0\iff AA'+BB'+CC'=0.$$
> Hệ quả: nếu $(\alpha)\perp(\beta)$ thì VTPT của mặt phẳng này có giá **song song hoặc nằm trong** mặt phẳng kia, tức là nó có thể làm **một VTCP** của mặt phẳng kia.

Hệ quả này rất hay dùng: muốn lập mặt phẳng $(P)$ vuông góc với $(Q)$, ta "mượn" $\vec n_Q$ làm một VTCP của $(P)$.

> [!vi-du] Ví dụ 11
> a) Chứng minh $(\alpha):2x+y-2z+1=0$ vuông góc với $(\beta):x+2y+2z-5=0$.
>
> b) Viết phương trình mặt phẳng $(P)$ đi qua $A(1;\,0;\,1)$, $B(2;\,1;\,-1)$ và vuông góc với $(Q):x-2y+z+3=0$.

> [!goi-y] Gợi ý 1
> a) Tính $\vec n_\alpha\cdot\vec n_\beta$.

> [!goi-y] Gợi ý 2
> b) $(P)$ chứa đường $AB$ nên nhận $\overrightarrow{AB}$ làm VTCP; $(P)\perp(Q)$ nên nhận $\vec n_Q$ làm VTCP thứ hai.

> [!loi-giai] Lời giải
> a) $\vec n_\alpha\cdot\vec n_\beta=2\cdot1+1\cdot2+(-2)\cdot2=0$, nên $(\alpha)\perp(\beta)$.
>
> b) $\overrightarrow{AB}=(1;\,1;\,-2)$, $\vec n_Q=(1;\,-2;\,1)$, không cùng phương.
> $[\overrightarrow{AB},\vec n_Q]=\big(1\cdot1-(-2)(-2);\ (-2)\cdot1-1\cdot1;\ 1\cdot(-2)-1\cdot1\big)=(-3;\,-3;\,-3)$, chọn $\vec n_P=(1;\,1;\,1)$.
> $(P):(x-1)+(y-0)+(z-1)=0\iff x+y+z-2=0$.
> Thử lại: $B$: $2+1-1-2=0$ ✓; $\vec n_P\cdot\vec n_Q=1-2+1=0$ ✓.

> [!ung-dung]
> Thợ xây kiểm tra tường có "thẳng đứng" không bằng dây dọi, đó chính là kiểm tra mặt tường **vuông góc** với mặt sàn. Trong bản vẽ 3D, phần mềm làm đúng phép tính $\vec n_{\text{tường}}\cdot\vec n_{\text{sàn}}=0$.

## 5. Điều kiện để hai mặt phẳng song song với nhau

Hai mặt phẳng song song (hoặc trùng nhau) thì "cùng hướng mặt", nên hai VTPT **cùng phương**. Nhưng cùng phương VTPT vẫn chưa đủ để biết chúng tách rời hay chồng khít lên nhau, phải xét thêm hệ số $D$.

> [!ghi-nho] Điều kiện song song, trùng nhau (SGK tr. 37)
> Với $(\alpha):Ax+By+Cz+D=0$ và $(\beta):A'x+B'y+C'z+D'=0$:
> - $(\alpha)\parallel(\beta)\iff$ có số $k$ để $A'=kA$, $B'=kB$, $C'=kC$ **và** $D'\ne kD$.
> - $(\alpha)\equiv(\beta)\iff$ có số $k\ne0$ để $A'=kA$, $B'=kB$, $C'=kC$, $D'=kD$.
> - Nếu hai VTPT **không** cùng phương thì hai mặt phẳng **cắt nhau**.

Nếu hai mặt phẳng song song, VTPT của mặt này cũng là VTPT của mặt kia. Vì thế "mặt phẳng qua $M$ và song song với $(Q)$" chỉ đơn giản là **giữ nguyên $A,B,C$ của $(Q)$, tính lại $D$**.

> [!vi-du] Ví dụ 12
> Cho $(\alpha):2x-y+2z-3=0$. Xét vị trí tương đối của $(\alpha)$ với:
> $(\beta):4x-2y+4z+1=0$; $(\gamma):-6x+3y-6z+9=0$; $(\delta):2x+y+2z-3=0$.
> Sau đó viết phương trình mặt phẳng qua $M(1;\,-1;\,2)$ và song song với $(\alpha)$.

> [!goi-y] Gợi ý 1
> So sánh các tỉ số $\frac{A'}A,\frac{B'}B,\frac{C'}C$ trước, rồi mới so $\frac{D'}D$.

> [!goi-y] Gợi ý 2
> Mặt phẳng song song với $(\alpha)$ có dạng $2x-y+2z+D=0$; thay $M$ để tìm $D$.

> [!loi-giai] Lời giải
> - $(\beta)$: $\frac42=\frac{-2}{-1}=\frac42=2$, còn $\frac{1}{-3}\ne2$. Vậy $(\alpha)\parallel(\beta)$.
> - $(\gamma)$: $\frac{-6}2=\frac3{-1}=\frac{-6}2=\frac9{-3}=-3$. Vậy $(\alpha)\equiv(\gamma)$ (chia $(\gamma)$ cho $-3$ là ra $(\alpha)$).
> - $(\delta)$: $\frac22=1$ nhưng $\frac1{-1}=-1$, VTPT không cùng phương, nên $(\alpha)$ và $(\delta)$ **cắt nhau**.
>
> Mặt phẳng cần tìm: $2x-y+2z+D=0$ qua $M$: $2+1+4+D=0\Rightarrow D=-7$. Đáp số $2x-y+2z-7=0$.

> [!bay]
> - Quên kiểm tra $D$: $(\gamma)$ có VTPT cùng phương với $(\alpha)$ nhưng là **trùng**, không phải song song.
> - Khi hệ số bằng $0$, đừng chia cho $0$. Hãy dùng dạng $A'=kA$, $B'=kB$, $C'=kC$ để kiểm tra.

> [!ung-dung] Điểm thi khối B00 và các mặt phẳng song song
> Biểu diễn kết quả thi của mỗi thí sinh khối B00 bằng điểm $(x;\,y;\,z)$ = (Toán, Hóa, Sinh). Mọi thí sinh có tổng điểm $27$ nằm trên mặt phẳng $x+y+z-27=0$; tổng $24$ nằm trên $x+y+z-24=0$… Các mặt phẳng này cùng VTPT $(1;\,1;\,1)$, khác $D$, nên **đôi một song song** — như những "tầng điểm chuẩn" xếp chồng lên nhau (theo ý tưởng Vận dụng 4, SGK tr. 37–38).

## 6. Khoảng cách từ một điểm đến một mặt phẳng

### 6.1. Công thức

Khoảng cách từ $M$ đến $(P)$ là độ dài đoạn $MN$, với $N$ là **hình chiếu vuông góc** của $M$ trên $(P)$ — đoạn ngắn nhất từ $M$ tới mặt phẳng.

![Hình 4. Flycam M bay trên sườn dốc (P): khoảng cách d(M, (P)) đo theo phương vuông góc với mặt dốc, khác với độ cao theo phương thẳng đứng](h4-khoang-cach.svg)

**Vì sao ra công thức?** (đi theo hướng dẫn ở SGK tr. 38) $\overrightarrow{MN}$ vuông góc với $(P)$ nên cùng phương với $\vec n=(A;\,B;\,C)$: $\overrightarrow{MN}=k\vec n$, tức $N(x_0+kA;\,y_0+kB;\,z_0+kC)$. Vì $N\in(P)$:
$$A(x_0+kA)+B(y_0+kB)+C(z_0+kC)+D=0\Rightarrow k=-\frac{Ax_0+By_0+Cz_0+D}{A^2+B^2+C^2}.$$
Khi đó $MN=\lvert k\rvert\cdot\lvert\vec n\rvert=\lvert k\rvert\sqrt{A^2+B^2+C^2}$, rút gọn ra:

> [!ghi-nho] Khoảng cách từ điểm đến mặt phẳng (SGK tr. 38)
> Với $M(x_0;\,y_0;\,z_0)$ và $(P):Ax+By+Cz+D=0$:
> $$d(M,(P))=\frac{\lvert Ax_0+By_0+Cz_0+D\rvert}{\sqrt{A^2+B^2+C^2}}.$$

Cách nhớ: **tử = thay tọa độ $M$ vào vế trái, lấy trị tuyệt đối**; **mẫu = độ dài VTPT**. Nếu $M\in(P)$ thì tử bằng $0$, khoảng cách bằng $0$ — hợp lí.

**Khoảng cách giữa hai mặt phẳng song song** bằng khoảng cách từ **một điểm bất kì** của mặt này đến mặt kia (hai mặt phẳng song song cách đều nhau ở mọi chỗ).

> [!vi-du] Ví dụ 13
> a) Tính khoảng cách từ $M(2;\,-1;\,3)$ đến $(P):2x-y+2z+4=0$.
>
> b) Chứng minh $(P_1):x+2y-2z+1=0$ và $(P_2):x+2y-2z-8=0$ song song, rồi tính khoảng cách giữa chúng.

> [!goi-y] Gợi ý 1
> a) Tử: $\lvert2\cdot2-(-1)+2\cdot3+4\rvert$. Mẫu: $\sqrt{4+1+4}$.

> [!goi-y] Gợi ý 2
> b) Chọn một điểm dễ trên $(P_1)$: cho $y=z=0$ thì $x=-1$.

> [!loi-giai] Lời giải
> a) $d(M,(P))=\dfrac{\lvert4+1+6+4\rvert}{\sqrt{4+1+4}}=\dfrac{15}{3}=5$.
>
> b) Hai mặt phẳng có cùng $A,B,C$ và $D$ khác nhau ($1\ne-8$) nên song song. Lấy $E(-1;\,0;\,0)\in(P_1)$:
> $d\big((P_1),(P_2)\big)=d(E,(P_2))=\dfrac{\lvert-1+0-0-8\rvert}{\sqrt{1+4+4}}=\dfrac93=3$.

> [!meo] Hai mặt phẳng song song cùng hệ số (mở rộng, ngoài SGK)
> Nếu $(P_1):Ax+By+Cz+D_1=0$ và $(P_2):Ax+By+Cz+D_2=0$ (**cùng** $A,B,C$) thì
> $$d\big((P_1),(P_2)\big)=\frac{\lvert D_1-D_2\rvert}{\sqrt{A^2+B^2+C^2}}.$$
> Công thức này chính là $d(E,(P_2))$ với $E$ là một điểm bất kì của $(P_1)$, rút gọn lại. Ở Ví dụ 13b: $\frac{\lvert1-(-8)\rvert}{3}=3$. Nếu hệ số chưa giống nhau (ví dụ $x+2y-2z+1=0$ và $2x+4y-4z+3=0$), phải **chia** cho cùng một số để đưa về cùng $A,B,C$ trước.

> [!bay] Ba lỗi hay gặp
> 1. Quên trị tuyệt đối, ra khoảng cách âm.
> 2. Phương trình chưa ở dạng "$\ldots=0$" (ví dụ $2x-y=3z-1$): phải chuyển hết sang một vế rồi mới đọc $A,B,C,D$.
> 3. Quên căn ở mẫu: chia cho $A^2+B^2+C^2$ thay vì $\sqrt{A^2+B^2+C^2}$.

## Dạng bài thi hay gặp

### Dạng 1. Lập phương trình mặt phẳng: "đề cho gì thì VTPT là gì?"

- **Nhận biết:** câu hỏi "phương trình mặt phẳng $(P)$ là…", "$(P):ax+by+cz+d=0$, tính $a+b+c+d$".
- **Phương pháp:** tìm điểm và VTPT theo bảng sau, rồi thay vào công thức.

| Đề cho | VTPT của $(P)$ |
|---|---|
| Vuông góc với đường $AB$ (kể cả mặt phẳng trung trực) | $\overrightarrow{AB}$ |
| Song song với $(Q)$ | $\vec n_Q$ |
| Vuông góc với trục $Ox$ / $Oy$ / $Oz$ | $\vec i$ / $\vec j$ / $\vec k$ |
| Qua ba điểm $A,B,C$ | $[\overrightarrow{AB},\overrightarrow{AC}]$ |
| Chứa $A,B$ và vuông góc với $(Q)$ | $[\overrightarrow{AB},\vec n_Q]$ |
| Vuông góc với hai mặt phẳng $(Q)$, $(R)$ | $[\vec n_Q,\vec n_R]$ |
| Song song với trục $Ox$ và vuông góc với $(Q)$ | $[\vec i,\vec n_Q]$ |
| Chứa trục $Ox$ và qua điểm $M$ | $[\vec i,\overrightarrow{OM}]$ |
| Cắt ba trục tại $(a;0;0),(0;b;0),(0;0;c)$ | dùng đoạn chắn |

- **Bẫy:** sai dấu tọa độ giữa của tích có hướng, quên đổi dấu khi thay tọa độ âm ($y-(-2)=y+2$). Bài "tính $a+b+c+d$" thường cho thêm điều kiện như "$a=1$" hoặc "$a,b,c$ nguyên tối giản" — phải chuẩn hóa đúng như đề.

> [!vi-du] Ví dụ 14
> Viết phương trình mặt phẳng $(P)$ đi qua $M(1;\,-1;\,2)$ và vuông góc với cả hai mặt phẳng $(Q):x+y-z+1=0$, $(R):2x-y+z-4=0$.

> [!goi-y] Gợi ý 1
> $(P)\perp(Q)$ nên $\vec n_Q$ là một VTCP của $(P)$. Tương tự với $\vec n_R$.

> [!goi-y] Gợi ý 2
> $\vec n_P=[\vec n_Q,\vec n_R]$ với $\vec n_Q=(1;\,1;\,-1)$, $\vec n_R=(2;\,-1;\,1)$.

> [!loi-giai] Lời giải
> $[\vec n_Q,\vec n_R]=\big(1\cdot1-(-1)(-1);\ (-1)\cdot2-1\cdot1;\ 1\cdot(-1)-1\cdot2\big)=(0;\,-3;\,-3)$, chọn $\vec n_P=(0;\,1;\,1)$.
> $(P):0(x-1)+(y+1)+(z-2)=0\iff y+z-1=0$.
> Thử lại: $\vec n_P\cdot\vec n_Q=0+1-1=0$ ✓; $\vec n_P\cdot\vec n_R=0-1+1=0$ ✓.

### Dạng 2. Vị trí tương đối của hai mặt phẳng có tham số

- **Nhận biết:** "tìm $m$ để $(P)\parallel(Q)$", "để $(P)\perp(Q)$", thường ở dạng Đúng/Sai.
- **Phương pháp:** vuông góc thì giải $AA'+BB'+CC'=0$ (một phương trình). Song song thì giải hệ $A'=kA$, $B'=kB$, $C'=kC$, rồi **kiểm tra** $D'\ne kD$.
- **Bẫy:** tìm được $m$ cho VTPT cùng phương nhưng hai mặt phẳng lại **trùng** nhau. "Cắt nhau" xảy ra với **mọi** $m$ làm VTPT không cùng phương, thường là vô số giá trị.

> [!vi-du] Ví dụ 15 (Đúng/Sai)
> Cho $(P):x+my+2z-1=0$ và $(Q):2x+4y+(m+2)z+3=0$ ($m$ là tham số). Xét các mệnh đề:
>
> a) Khi $m=2$ thì $(P)\parallel(Q)$.
>
> b) Khi $m=-1$ thì $(P)\perp(Q)$.
>
> c) Khi $m=2$, khoảng cách giữa $(P)$ và $(Q)$ bằng $\dfrac53$.
>
> d) Có đúng hai giá trị của $m$ để $(P)$ và $(Q)$ cắt nhau.

> [!goi-y] Gợi ý 1
> a) Thay $m=2$: $(P):x+2y+2z-1=0$, $(Q):2x+4y+4z+3=0$. So sánh tỉ số.

> [!goi-y] Gợi ý 2
> c) Chia $(Q)$ cho 2 để cùng hệ số với $(P)$ rồi dùng $\frac{\lvert D_1-D_2\rvert}{\sqrt{A^2+B^2+C^2}}$.

> [!loi-giai] Lời giải
> a) **Đúng.** $\frac21=\frac42=\frac42=2$ và $\frac3{-1}=-3\ne2$.
>
> b) **Đúng.** $\vec n_P\cdot\vec n_Q=2+4m+2(m+2)=6m+6=0\iff m=-1$.
>
> c) **Sai.** $(Q):x+2y+2z+\frac32=0$, nên $d=\dfrac{\lvert-1-\frac32\rvert}{3}=\dfrac56$. Con số $\frac53$ là do quên chia $D=3$ cho 2.
>
> d) **Sai.** VTPT cùng phương chỉ khi $\frac2{1}=\frac4m=\frac{m+2}{2}$, tức $m=2$. Vậy với **mọi** $m\ne2$ hai mặt phẳng đều cắt nhau — vô số giá trị.

### Dạng 3. Khoảng cách — tìm điểm, tìm tham số

- **Nhận biết:** "tìm $M$ thuộc trục $Oz$ cách đều $(P)$ và $(Q)$", "tìm $m$ để khoảng cách bằng 3".
- **Phương pháp:** đặt tọa độ điểm theo một ẩn (trên $Ox$: $(t;0;0)$…) → viết khoảng cách theo công thức → giải phương trình chứa trị tuyệt đối: $\lvert X\rvert=\lvert Y\rvert\iff X=Y$ hoặc $X=-Y$.
- **Bẫy:** chỉ xét một trường hợp của trị tuyệt đối nên mất nghiệm, hoặc không nhận ra một trường hợp vô nghiệm.

> [!vi-du] Ví dụ 16
> Tìm điểm $M$ thuộc trục $Oz$ cách đều hai mặt phẳng $(P):2x-y+2z-1=0$ và $(Q):x+2y-2z+5=0$.

> [!goi-y] Gợi ý 1
> $M(0;\,0;\,t)$. Hai mặt phẳng có VTPT cùng độ dài $3$, nên chỉ cần so sánh hai tử số.

> [!goi-y] Gợi ý 2
> Giải $\lvert2t-1\rvert=\lvert-2t+5\rvert$ theo hai trường hợp.

> [!loi-giai] Lời giải
> $d(M,(P))=\dfrac{\lvert2t-1\rvert}3$, $d(M,(Q))=\dfrac{\lvert-2t+5\rvert}3$.
> - $2t-1=-2t+5\iff t=\frac32$.
> - $2t-1=-(-2t+5)=2t-5\iff-1=-5$, vô nghiệm.
>
> Vậy có đúng một điểm: $M\left(0;\,0;\,\frac32\right)$.

### Dạng 4. Bài toán thực tế: mái nhà, sườn dốc, camera

- **Nhận biết:** đề mô tả mái nhà, sườn đồi, tấm pin, trần nhà, camera… kèm hệ trục và đơn vị.
- **Phương pháp:** (1) lập phương trình mặt phẳng (thường qua ba điểm cho sẵn). (2) Dịch câu hỏi: "cách bao xa" là khoảng cách điểm–mặt phẳng, "điểm trên mái ngay phía trên" là giữ $x,y$ rồi giải $z$, "vuông góc / song song" thì so VTPT. (3) Làm tròn ở bước cuối.
- **Bẫy:** nhầm **độ cao thẳng đứng** (hiệu cao độ) với **khoảng cách vuông góc** đến mặt nghiêng — hai đại lượng này chỉ bằng nhau khi mặt phẳng nằm ngang.

> [!vi-du] Ví dụ 17
> Chọn hệ $Oxyz$ (đơn vị mét), $Oz$ hướng thẳng lên. Một sườn dốc phẳng chứa ba cọc mốc $O(0;\,0;\,0)$, $A(40;\,0;\,10)$, $B(0;\,30;\,0)$. Một flycam đang ở $F(20;\,15;\,30)$.
>
> a) Viết phương trình mặt phẳng sườn dốc.
>
> b) Tính khoảng cách từ flycam đến sườn dốc và độ cao của flycam so với điểm trên dốc nằm ngay bên dưới nó (làm tròn đến hàng phần trăm).
>
> c) Quy định an toàn: flycam phải cách mặt dốc ít nhất $20$ m. Flycam hạ thẳng đứng thì hạ được tối đa bao nhiêu mét (làm tròn đến hàng phần trăm)?

> [!goi-y] Gợi ý 1
> a) $\overrightarrow{OA}=(40;\,0;\,10)$, $\overrightarrow{OB}=(0;\,30;\,0)$, rút gọn thành $(4;\,0;\,1)$ và $(0;\,1;\,0)$ trước khi tính tích có hướng.

> [!goi-y] Gợi ý 2
> c) Khi hạ thẳng đứng, flycam ở $(20;\,15;\,h)$. Giải $d\ge20$ với $h$ lớn hơn độ cao mặt dốc tại đó.

> [!loi-giai] Lời giải
> a) $[(4;\,0;\,1),(0;\,1;\,0)]=(0\cdot0-1\cdot1;\ 1\cdot0-4\cdot0;\ 4\cdot1-0\cdot0)=(-1;\,0;\,4)$. Mặt dốc qua $O$: $-x+4z=0\iff x-4z=0$.
>
> b) $d(F,\text{dốc})=\dfrac{\lvert20-4\cdot30\rvert}{\sqrt{1+16}}=\dfrac{100}{\sqrt{17}}\approx24{,}25$ m.
> Điểm trên dốc ngay dưới $F$ có $x=20$, nên $z=\frac{20}4=5$. Độ cao so với điểm đó: $30-5=25$ m. Khoảng cách vuông góc ($24{,}25$ m) **nhỏ hơn** độ cao thẳng đứng, đúng như Hình 4.
>
> c) Với $h>5$: $\dfrac{4h-20}{\sqrt{17}}\ge20\iff h\ge5+5\sqrt{17}\approx25{,}62$. Hạ được tối đa $30-25{,}62\approx4{,}38$ m.

> [!em-co-biet]
> Mặt phẳng là mặt "bậc nhất". Khi phương trình có $x^2,y^2,z^2$, ta được những mặt cong rất đẹp: mặt cầu (Bài 17), mặt ellipsoid hình quả trứng, mặt yên ngựa $z=\frac{x^2}{a^2}-\frac{y^2}{b^2}$ (dáng mái của một số nhà thi đấu), mặt hyperboloid một tầng (dáng tháp làm mát của nhà máy điện). Đó là thế giới của **hình học giải tích** (SGK tr. 40).

## Tóm tắt

Với $(\alpha):Ax+By+Cz+D=0$, $(\beta):A'x+B'y+C'z+D'=0$, $\vec u=(a;\,b;\,c)$, $\vec v=(a';\,b';\,c')$.

| Nội dung | Công thức / cách làm |
|---|---|
| VTPT | $\vec n\ne\vec 0$, giá vuông góc với mặt phẳng; $k\vec n$ cũng là VTPT |
| Tích có hướng | $[\vec u,\vec v]=(bc'-b'c;\ ca'-c'a;\ ab'-a'b)$ |
| Tính chất | $[\vec u,\vec v]\perp\vec u,\vec v$; bằng $\vec 0\iff$ cùng phương |
| Cặp VTCP $\vec u,\vec v$ | VTPT $\vec n=[\vec u,\vec v]$ |
| Đọc VTPT | $\vec n=(A;\,B;\,C)$, hệ số của $x,y,z$ |
| Qua $M_0$, VTPT $\vec n$ | $A(x-x_0)+B(y-y_0)+C(z-z_0)=0$ |
| Qua $A,B,C$ | $\vec n=[\overrightarrow{AB},\overrightarrow{AC}]$, qua $A$ |
| Đoạn chắn | $\frac xa+\frac yb+\frac zc=1$ |
| Vuông góc | $AA'+BB'+CC'=0$ |
| Song song | $(A';B';C')=k(A;B;C)$ và $D'\ne kD$ |
| Trùng nhau | $(A';B';C';D')=k(A;B;C;D)$ |
| Khoảng cách | $d=\dfrac{\lvert Ax_0+By_0+Cz_0+D\rvert}{\sqrt{A^2+B^2+C^2}}$ |
| Hai mặt song song, cùng hệ số | $d=\dfrac{\lvert D_1-D_2\rvert}{\sqrt{A^2+B^2+C^2}}$ |

**Sơ đồ tư duy:** đề hỏi *phương trình mặt phẳng* → tìm **điểm + VTPT** (VTPT trực tiếp, hoặc tích có hướng của hai VTCP) → thay công thức → thử lại. Đề hỏi *vị trí tương đối* → so hai VTPT (tích vô hướng $=0$ thì vuông góc; tỉ lệ thì xét thêm $D$). Đề hỏi *khoảng cách* → thay điểm vào vế trái, lấy trị tuyệt đối, chia độ dài VTPT.
