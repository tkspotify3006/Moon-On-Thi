---
title: Khảo sát sự biến thiên và vẽ đồ thị của hàm số
thoi-gian: 50 phút
muc-tieu:
  - Nắm sơ đồ tổng quát khảo sát hàm số — tập xác định, chiều biến thiên, cực trị, giới hạn và tiệm cận, bảng biến thiên, đồ thị
  - Khảo sát và vẽ được đồ thị hàm bậc ba, hàm phân thức $y=\dfrac{ax+b}{cx+d}$ và $y=\dfrac{ax^2+bx+c}{px+q}$
  - Nhận biết tâm đối xứng, trục đối xứng của đồ thị các hàm số trên và giải thích được vì sao có tính đối xứng đó
  - Nhận dạng hàm số và dấu các hệ số từ đồ thị hoặc bảng biến thiên
  - Dùng đồ thị để đếm số nghiệm của phương trình $f(x)=m$ và giải bài toán thực tế
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Sơ đồ khảo sát:** tập xác định → $y'$, xét dấu, cực trị → giới hạn, tiệm cận → bảng biến thiên → đồ thị (thêm giao điểm với hai trục, tâm đối xứng).
> 2. **Bậc ba** $y=ax^3+bx^2+cx+d$: nhánh phải đi lên nếu $a>0$, đi xuống nếu $a<0$; có 2 cực trị $\iff y'=0$ có 2 nghiệm phân biệt; **tâm đối xứng** có hoành độ $x=-\dfrac{b}{3a}$ (nghiệm của $y''=0$); không có tiệm cận.
> 3. **$y=\dfrac{ax+b}{cx+d}$**: không có cực trị; TCĐ $x=-\dfrac dc$, TCN $y=\dfrac ac$; tâm đối xứng là **giao điểm hai tiệm cận**.
> 4. **$y=\dfrac{ax^2+bx+c}{px+q}$**: viết thành $y=mx+n+\dfrac{r}{px+q}$; TCĐ và TCX; tâm đối xứng là giao điểm TCĐ và TCX.
> 5. **Số nghiệm của $f(x)=m$** = số giao điểm của đồ thị $y=f(x)$ với **đường thẳng nằm ngang** $y=m$.

Ở Bài 1, 2, 3 em đã có đủ "đồ nghề": đạo hàm cho biết hàm số **đi lên hay đi xuống** và **đỉnh, đáy** ở đâu; giới hạn cho biết đồ thị **đi về đâu** khi $x$ chạy ra xa hoặc tiến sát một điểm "cấm". Bài này ghép tất cả lại thành **một quy trình** để vẽ đồ thị một cách chắc chắn — và quan trọng hơn cho kì thi: **đọc ngược** từ đồ thị ra tính chất và công thức của hàm số.

Thử nghĩ về một xưởng đóng hộp trà thảo mộc. Chi phí làm $x$ hộp là $C(x)=4x+100$ (nghìn đồng): mỗi hộp tốn $4$ nghìn nguyên liệu, cộng $100$ nghìn chi phí cố định. Chi phí trung bình mỗi hộp là $f(x)=\dfrac{4x+100}{x}=4+\dfrac{100}{x}$. Làm càng nhiều thì $f(x)$ càng giảm, nhưng **không bao giờ xuống tới 4 nghìn**. Khảo sát hàm số giúp ta thấy điều đó bằng hình: đồ thị đi xuống và nằm sát dần đường thẳng $y=4$ (tiệm cận ngang). Ta sẽ quay lại ví dụ này ở mục 3.

## 1. Sơ đồ khảo sát hàm số

### 1.1. Các bước — và vì sao theo thứ tự đó

> [!ghi-nho] Sơ đồ khảo sát hàm số y = f(x) (SGK tr. 26)
> 1. **Tìm tập xác định** của hàm số.
> 2. **Khảo sát sự biến thiên:**
>    - Tính $y'$; tìm các điểm tại đó $y'=0$ hoặc $y'$ không xác định.
>    - Xét dấu $y'$ → các khoảng đồng biến, nghịch biến.
>    - Tìm cực trị.
>    - Tìm giới hạn tại vô cực, giới hạn vô cực và tiệm cận (nếu có).
>    - Lập **bảng biến thiên**.
> 3. **Vẽ đồ thị** dựa vào bảng biến thiên.

Thứ tự này không phải ngẫu nhiên:
- **Tập xác định trước tiên**, vì mọi bước sau chỉ có nghĩa trên tập đó. Phân thức có điểm "cấm" thì ở đó có thể có tiệm cận đứng và bảng biến thiên có **gạch đôi** $\Vert$.
- **Đạo hàm** cho "bộ khung": đồ thị lên ở đâu, xuống ở đâu, đỉnh/đáy ở đâu (xem Bài 1).
- **Giới hạn, tiệm cận** cho biết hai đầu đồ thị và những chỗ đồ thị "vọt lên/lao xuống" (xem Bài 3).
- **Bảng biến thiên** gom tất cả lại. Có bảng rồi thì vẽ đồ thị chỉ còn là "nối các mốc bằng nét cong mềm".

> [!ghi-nho] Chú ý khi vẽ đồ thị (SGK tr. 27)
> - Nên tìm thêm **điểm đặc biệt**: giao điểm với trục tung ($x=0$), với trục hoành ($y=0$) khi giải được dễ dàng.
> - Để ý **tính đối xứng** (tâm đối xứng, trục đối xứng) — vẽ xong một nửa là suy ra nửa kia.

> [!nen-tang] Hàm chẵn, hàm lẻ và tính đối xứng (lớp 10)
> - Hàm **chẵn** ($f(-x)=f(x)$): đồ thị nhận **trục $Oy$** làm trục đối xứng.
> - Hàm **lẻ** ($f(-x)=-f(x)$): đồ thị nhận **gốc $O$** làm tâm đối xứng.
> - Parabol $y=ax^2+bx+c$ có trục đối xứng $x=-\dfrac{b}{2a}$. Ví dụ $y=x^2-2x-3$ có trục đối xứng $x=1$ và đỉnh $(1;\,-4)$.

### 1.2. Tâm đối xứng — hiểu cho đúng

Điểm $I(x_0;\,y_0)$ là **tâm đối xứng** của đồ thị nếu với mỗi điểm $M$ trên đồ thị, điểm $M'$ đối xứng với $M$ qua $I$ cũng nằm trên đồ thị. Viết bằng công thức: với mọi $h$ (để $x_0\pm h$ thuộc tập xác định)
$$f(x_0+h)+f(x_0-h)=2y_0,$$
tức là **trung điểm** của $M(x_0+h;\,f(x_0+h))$ và $M'(x_0-h;\,f(x_0-h))$ luôn là $I$. Cách hiểu dễ nhớ: nếu ta **dời gốc tọa độ về $I$** thì hàm số trở thành hàm **lẻ**.

## 2. Khảo sát và vẽ đồ thị hàm số đa thức bậc ba

### 2.1. Một ví dụ đầy đủ

> [!vi-du] Ví dụ 1
> Khảo sát sự biến thiên và vẽ đồ thị của hàm số $y=x^3-3x^2+2$.

> [!goi-y] Gợi ý 1
> $y'=3x^2-6x=3x(x-2)$. Hệ số của $x^2$ trong $y'$ dương nên $y'$ âm **giữa** hai nghiệm, dương **ngoài** hai nghiệm.

> [!goi-y] Gợi ý 2
> Giới hạn tại vô cực của đa thức do **hạng tử bậc cao nhất** quyết định: $x^3\to+\infty$ khi $x\to+\infty$. Để tìm giao điểm với $Ox$, nhận thấy $x=1$ là một nghiệm của $x^3-3x^2+2=0$.

> [!loi-giai] Lời giải
> **1. Tập xác định:** $\mathbb R$.
>
> **2. Sự biến thiên.**
> - $y'=3x^2-6x$; $y'=0\iff x=0$ hoặc $x=2$.
> - $y'>0$ trên $(-\infty;\,0)$ và $(2;\,+\infty)$ → hàm số đồng biến trên mỗi khoảng đó; $y'<0$ trên $(0;\,2)$ → nghịch biến.
> - Cực đại tại $x=0$, $y_{CĐ}=2$; cực tiểu tại $x=2$, $y_{CT}=-2$.
> - $\lim\limits_{x\to-\infty}y=\lim\limits_{x\to-\infty}x^3\left(1-\dfrac3x+\dfrac{2}{x^3}\right)=-\infty$; $\lim\limits_{x\to+\infty}y=+\infty$.
> - Bảng biến thiên:
>
> $$\begin{array}{c|ccccccc} x & -\infty & & 0 & & 2 & & +\infty \\ \hline y' & & + & 0 & - & 0 & + & \\ \hline & & & 2 & & & & +\infty \\ y & & \nearrow & & \searrow & & \nearrow & \\ & -\infty & & & & -2 & & \end{array}$$
>
> **3. Đồ thị** (Hình 1).
> - Giao với $Oy$: $(0;\,2)$.
> - Giao với $Ox$: $x^3-3x^2+2=(x-1)(x^2-2x-2)=0\iff x=1$ hoặc $x=1\pm\sqrt3$.
> - Tâm đối xứng: $y''=6x-6=0\iff x=1$, $y(1)=0$ → $I(1;\,0)$.

![Hình 1. Đồ thị y = x³ − 3x² + 2: cực đại (0; 2), cực tiểu (2; −2), tâm đối xứng I(1; 0) là trung điểm của mọi cặp điểm M, M′ đối xứng](h1-bac-ba-vd1.svg)

Nhìn Hình 1 em thấy: điểm $I$ nằm **chính giữa** hai điểm cực trị (trung điểm của $(0;\,2)$ và $(2;\,-2)$ là $(1;\,0)$), và tại $I$ đồ thị đổi từ "cong xuống" sang "cong lên". Đây là điều luôn đúng với mọi hàm bậc ba có hai cực trị.

> [!ghi-nho] Đồ thị hàm số bậc ba (SGK tr. 27)
> Với $y=ax^3+bx^2+cx+d$ ($a\ne0$):
> - Có **tâm đối xứng** là điểm có hoành độ thỏa mãn $y''=0$, tức là $x_0=-\dfrac{b}{3a}$; tung độ $y_0=f(x_0)$.
> - **Không có tiệm cận.**

**Vì sao tâm đối xứng có hoành độ $-\dfrac{b}{3a}$?** Đặt $x=x_0+t$ với $x_0=-\dfrac{b}{3a}$. Khai triển $a(x_0+t)^3+b(x_0+t)^2+\dots$, hệ số của $t^2$ là $3ax_0+b=0$ — vừa đúng bị triệt tiêu! Nên
$$f(x_0+t)=at^3+kt+f(x_0)\quad(k\text{ là hằng số}).$$
Phần $at^3+kt$ là hàm **lẻ** theo $t$, do đó $f(x_0+t)+f(x_0-t)=2f(x_0)$: điểm $I(x_0;\,f(x_0))$ là tâm đối xứng. Với Ví dụ 1: $x=1+t$ cho $y=t^3-3t$ — đúng là hàm lẻ.

> [!meo] Tâm đối xứng = "trung điểm hai cực trị"
> Hàm bậc ba có hai cực trị thì tâm đối xứng là **trung điểm** của hai điểm cực trị, và hoành độ tâm bằng **trung bình cộng hai nghiệm của $y'$**: $x_0=\dfrac{x_1+x_2}{2}=-\dfrac{b}{3a}$. Đây là cách kiểm tra nhanh rất tiện.

### 2.2. Khi $y'=0$ có nghiệm kép hoặc vô nghiệm

> [!vi-du] Ví dụ 2
> Khảo sát sự biến thiên và vẽ đồ thị của hàm số $y=-x^3+3x^2-3x+2$.

> [!goi-y] Gợi ý 1
> $y'=-3x^2+6x-3=-3(x^2-2x+1)$. Em có nhận ra hằng đẳng thức không?

> [!goi-y] Gợi ý 2
> $y'=-3(x-1)^2\le0$, chỉ bằng $0$ tại **một** điểm. Theo Bài 1, hàm số vẫn nghịch biến trên cả $\mathbb R$ và **không có cực trị**.

> [!loi-giai] Lời giải
> **1.** Tập xác định $\mathbb R$.
>
> **2.** $y'=-3(x-1)^2\le0$ với mọi $x$, dấu bằng chỉ tại $x=1$ → hàm số **nghịch biến trên $\mathbb R$**, không có cực trị. $\lim\limits_{x\to-\infty}y=+\infty$, $\lim\limits_{x\to+\infty}y=-\infty$ (vì $a=-1<0$).
>
> $$\begin{array}{c|ccccc} x & -\infty & & 1 & & +\infty \\ \hline y' & & - & 0 & - & \\ \hline & +\infty & & & & \\ y & & \searrow & 1 & \searrow & \\ & & & & & -\infty \end{array}$$
>
> **3. Đồ thị.** Giao với $Oy$: $(0;\,2)$. Để ý $y=-(x-1)^3+1$, nên $y=0\iff(x-1)^3=1\iff x=2$: giao với $Ox$ là $(2;\,0)$. Tâm đối xứng: $y''=-6x+6=0\iff x=1$ → $I(1;\,1)$. Tại $I$ tiếp tuyến **nằm ngang** (vì $y'(1)=0$) nhưng đồ thị vẫn đi xuống — có dạng như cột giữa, hàng dưới của Hình 2.

> [!bay] Đạo hàm bằng 0 tại một điểm chưa chắc có cực trị
> Ở Ví dụ 2, $y'(1)=0$ nhưng $y'$ **không đổi dấu** qua $x=1$, nên $x=1$ **không** là điểm cực trị. Phương án "hàm số đạt cực đại tại $x=1$" là phương án nhiễu điển hình.

### 2.3. Sáu dạng đồ thị hàm bậc ba

Hình dạng đồ thị chỉ phụ thuộc vào **hai câu hỏi**: dấu của $a$ (nhánh phải đi lên hay đi xuống) và phương trình $y'=0$ có mấy nghiệm (có "đồi – thung" hay không).

![Hình 2. Sáu dạng đồ thị hàm bậc ba: hàng theo dấu của a, cột theo số nghiệm của y′ = 0](h2-sau-dang-bac-ba.svg)

| | $y'=0$ có 2 nghiệm phân biệt | $y'=0$ có nghiệm kép | $y'=0$ vô nghiệm |
|---|---|---|---|
| ${a>0}$ | lên – xuống – lên; **2 cực trị** | luôn đồng biến, có 1 chỗ "nằm ngang" | luôn đồng biến |
| ${a<0}$ | xuống – lên – xuống; **2 cực trị** | luôn nghịch biến, có 1 chỗ "nằm ngang" | luôn nghịch biến |

Với $y'=3ax^2+2bx+c$, số nghiệm do $\Delta'=b^2-3ac$ quyết định: $\Delta'>0$ → 2 cực trị; $\Delta'\le0$ → không có cực trị.

> [!meo] Nhớ dáng đồ thị bằng "tay phải"
> Nhánh **bên phải** của đồ thị bậc ba cùng hướng với dấu của $a$: $a>0$ → đi lên ("giơ tay phải lên"); $a<0$ → đi xuống. Khi đề cho một đồ thị và bốn công thức, loại ngay các phương án sai dấu $a$.

### 2.4. Đọc dấu các hệ số $a, b, c, d$ từ đồ thị

Đây là dạng **rất hay ra** trong đề. Mỗi hệ số có một "dấu hiệu" riêng trên đồ thị:

| Hệ số | Đọc từ đâu | Lí do |
|---|---|---|
| $a$ | nhánh bên phải đi lên ($a>0$) hay đi xuống ($a<0$) | $\lim\limits_{x\to+\infty}y$ cùng dấu $a$ |
| $d$ | đồ thị cắt $Oy$ phía trên ($d>0$), dưới ($d<0$) hay tại $O$ ($d=0$) | $y(0)=d$ |
| $c$ | **tích** hai hoành độ cực trị: $x_1x_2=\dfrac{c}{3a}$ | định lí Viète cho $y'=3ax^2+2bx+c$ |
| $b$ | **tổng** hai hoành độ cực trị: $x_1+x_2=-\dfrac{2b}{3a}$ (hoặc hoành độ tâm $-\dfrac{b}{3a}$) | định lí Viète |

Ngoài ra $c=y'(0)$: nếu tại giao điểm với $Oy$ đồ thị đang **đi lên** thì $c>0$, **đi xuống** thì $c<0$, đạt cực trị tại đó thì $c=0$.

> [!vi-du] Ví dụ 3
> Hình 3 là đồ thị của hàm số $y=ax^3+bx^2+cx+d$, có hai điểm cực trị tại $x=-1$ và $x=2$, cắt trục tung tại điểm có tung độ $-2$. Xác định dấu của $a$, $b$, $c$, $d$.

![Hình 3. Đồ thị hàm bậc ba dùng để đọc dấu các hệ số](h3-nhan-dang-dau.svg)

> [!goi-y] Gợi ý 1
> Nhánh phải đi xuống → dấu của $a$? Giao điểm với $Oy$ → $d$.

> [!goi-y] Gợi ý 2
> $x_1+x_2=-1+2=1$ và $x_1x_2=-2$. So với $-\dfrac{2b}{3a}$ và $\dfrac{c}{3a}$, nhớ rằng $a<0$ nên khi "khử" $a$ thì dấu đảo lại.

> [!loi-giai] Lời giải
> - Nhánh phải đi xuống nên $a<0$. Đồ thị cắt $Oy$ tại $(0;\,-2)$ nên $d=-2<0$.
> - $x_1x_2=\dfrac{c}{3a}=-2<0$; vì $3a<0$ nên $c>0$. (Kiểm tra bằng cách khác: tại $x=0$ đồ thị đang đi lên → $c=y'(0)>0$ ✓.)
> - $x_1+x_2=-\dfrac{2b}{3a}=1>0$ ⇒ $\dfrac{b}{a}<0$; vì $a<0$ nên $b>0$.
>
> Vậy $a<0$, $b>0$, $c>0$, $d<0$. (Hình 3 vẽ đúng hàm $y=-x^3+1{,}5x^2+6x-2$.)

> [!bay]
> Lỗi hay gặp nhất là quên rằng $a$ âm làm **đổi chiều** khi suy dấu $b$, $c$. Hãy viết rõ $\dfrac{c}{3a}<0$ rồi mới kết luận, đừng "nhẩm" luôn $c<0$.

## 3. Khảo sát và vẽ đồ thị hàm số phân thức hữu tỉ

### 3.1. Hàm số $y=\dfrac{ax+b}{cx+d}$ $(c\ne0,\ ad-bc\ne0)$

> [!nen-tang] Nhắc lại Bài 1 và Bài 3
> - $y'=\dfrac{ad-bc}{(cx+d)^2}$: dấu của $y'$ là dấu của $ad-bc$, **không đổi** trên từng khoảng → hàm số luôn đồng biến (hoặc luôn nghịch biến) trên **từng khoảng** xác định, **không có cực trị**.
> - TCĐ $x=-\dfrac dc$; TCN $y=\dfrac ac$.
> - Điều kiện $ad-bc\ne0$ để loại trường hợp tử, mẫu tỉ lệ (khi đó $y$ là hằng số, đồ thị là đường thẳng bị "khoét" một điểm).

> [!vi-du] Ví dụ 4
> Khảo sát sự biến thiên và vẽ đồ thị của hàm số $y=\dfrac{3x-1}{x+1}$.

> [!goi-y] Gợi ý 1
> Tập xác định có điểm "cấm" $x=-1$. Tính $ad-bc=3\cdot1-(-1)\cdot1$.

> [!goi-y] Gợi ý 2
> Tìm giới hạn một bên tại $x=-1$: tử dần về $3\cdot(-1)-1=-4<0$, còn mẫu $x+1$ dần về $0$ — từ phía nào thì mẫu dương, phía nào âm?

> [!loi-giai] Lời giải
> **1.** Tập xác định $\mathbb R\setminus\{-1\}$.
>
> **2.** $y'=\dfrac{4}{(x+1)^2}>0$ với mọi $x\ne-1$ → hàm số **đồng biến trên từng khoảng** $(-\infty;\,-1)$ và $(-1;\,+\infty)$; không có cực trị.
> - $\lim\limits_{x\to-1^-}y=+\infty$ (tử âm, mẫu âm), $\lim\limits_{x\to-1^+}y=-\infty$ → TCĐ $x=-1$.
> - $\lim\limits_{x\to\pm\infty}y=3$ → TCN $y=3$.
>
> $$\begin{array}{c|ccccc} x & -\infty & & -1 & & +\infty \\ \hline y' & & + & \Vert & + & \\ \hline & & & +\infty\;\Vert & & 3 \\ y & & \nearrow & \Vert & \nearrow & \\ & 3 & & \Vert\;-\infty & & \end{array}$$
>
> **3. Đồ thị** (Hình 4). Giao với $Oy$: $(0;\,-1)$; giao với $Ox$: $\left(\dfrac13;\,0\right)$. Tâm đối xứng là giao điểm hai tiệm cận $I(-1;\,3)$.

![Hình 4. Đồ thị y = (3x − 1)/(x + 1): hai nhánh nằm ở hai "góc" đối nhau qua I(−1; 3)](h4-phan-thuc-bac-nhat.svg)

**Vì sao giao điểm hai tiệm cận là tâm đối xứng?** Chia tử cho mẫu: $y=3-\dfrac{4}{x+1}$. Đặt $x=-1+t$: $y-3=-\dfrac4t$ — một hàm **lẻ** theo $t$. Vậy dời gốc về $I(-1;\,3)$, đồ thị trở thành đồ thị hàm lẻ, nên đối xứng qua $I$. Thử với hai điểm trên Hình 4: $M(1;\,1)$ và $M'(-3;\,5)$ có trung điểm đúng là $(-1;\,3)$.

> [!ghi-nho] Đồ thị hàm phân thức bậc nhất trên bậc nhất (SGK tr. 29)
> Với $y=\dfrac{ax+b}{cx+d}$ ($c\ne0$, $ad-bc\ne0$):
> - Nhận **giao điểm của tiệm cận đứng và tiệm cận ngang** làm tâm đối xứng.
> - Nhận **hai đường phân giác** của các góc tạo bởi hai tiệm cận làm trục đối xứng.
> - **Hai dạng:** $ad-bc>0$ (đồng biến) → hai nhánh nằm ở góc **trên-trái** và **dưới-phải** so với $I$ (như Hình 4); $ad-bc<0$ (nghịch biến) → hai nhánh ở góc **dưới-trái** và **trên-phải** (giống đồ thị $y=\frac1x$).

> [!vi-du] Ví dụ 5 (Bài toán thực tế)
> Trở lại xưởng trà ở đầu bài: chi phí trung bình mỗi hộp là $f(x)=\dfrac{4x+100}{x}$ (nghìn đồng), $x\ge1$. Khảo sát hàm số này và giải thích vì sao chi phí trung bình giảm khi làm thêm hộp nhưng luôn lớn hơn 4 nghìn đồng. Phải làm ít nhất bao nhiêu hộp để chi phí trung bình không quá 5 nghìn đồng?

> [!goi-y] Gợi ý 1
> $f'(x)=\dfrac{4\cdot0-100\cdot1}{x^2}$. Tính $\lim\limits_{x\to+\infty}f(x)$.

> [!goi-y] Gợi ý 2
> $f(x)=4+\dfrac{100}{x}$; giải bất phương trình $4+\dfrac{100}{x}\le5$.

> [!loi-giai] Lời giải
> $f'(x)=-\dfrac{100}{x^2}<0$ nên $f$ **nghịch biến** trên $[1;\,+\infty)$: làm càng nhiều, chi phí trung bình càng giảm. $f(1)=104$, $\lim\limits_{x\to+\infty}f(x)=4$ → đồ thị có TCN $y=4$, và vì $f(x)-4=\dfrac{100}{x}>0$ nên đồ thị luôn nằm **trên** đường $y=4$: chi phí trung bình luôn **lớn hơn** 4 nghìn đồng (phần chi phí cố định 100 nghìn được "chia nhỏ" nhưng không bao giờ biến mất).
>
> $4+\dfrac{100}{x}\le5\iff\dfrac{100}{x}\le1\iff x\ge100$. Cần làm ít nhất **100 hộp**.

### 3.2. Hàm số $y=\dfrac{ax^2+bx+c}{px+q}$ ($a\ne0$, $p\ne0$, tử không chia hết cho mẫu)

Bí quyết: **chia đa thức trước** để viết $y=mx+n+\dfrac{r}{px+q}$ ($r\ne0$). Dạng này cho ngay tiệm cận xiên $y=mx+n$ (Bài 3), và đạo hàm cũng gọn hơn.

> [!vi-du] Ví dụ 6
> Khảo sát sự biến thiên và vẽ đồ thị của hàm số $y=\dfrac{x^2-2x+2}{x-1}$.

> [!goi-y] Gợi ý 1
> $x^2-2x+2=(x-1)^2+1$. Chia cả hai phần cho $x-1$.

> [!goi-y] Gợi ý 2
> $y=x-1+\dfrac{1}{x-1}$ nên $y'=1-\dfrac{1}{(x-1)^2}=\dfrac{(x-1)^2-1}{(x-1)^2}=\dfrac{x(x-2)}{(x-1)^2}$.

> [!loi-giai] Lời giải
> **1.** Tập xác định $\mathbb R\setminus\{1\}$. Viết $y=x-1+\dfrac{1}{x-1}$.
>
> **2.** $y'=\dfrac{x(x-2)}{(x-1)^2}$; $y'=0\iff x=0$ hoặc $x=2$.
> - Đồng biến trên $(-\infty;\,0)$ và $(2;\,+\infty)$; nghịch biến trên $(0;\,1)$ và $(1;\,2)$.
> - Cực đại tại $x=0$, $y_{CĐ}=-2$; cực tiểu tại $x=2$, $y_{CT}=2$.
> - $\lim\limits_{x\to1^-}y=-\infty$, $\lim\limits_{x\to1^+}y=+\infty$ → TCĐ $x=1$.
> - $\lim\limits_{x\to\pm\infty}\big[y-(x-1)\big]=\lim\limits_{x\to\pm\infty}\dfrac{1}{x-1}=0$ → TCX $y=x-1$; $\lim\limits_{x\to-\infty}y=-\infty$, $\lim\limits_{x\to+\infty}y=+\infty$.
>
> $$\footnotesize\begin{array}{c|ccccccccc} x & -\infty & & 0 & & 1 & & 2 & & +\infty \\ \hline y' & & + & 0 & - & \Vert & - & 0 & + & \\ \hline & & & -2 & & \Vert{+\infty} & & & & +\infty \\ y & & \nearrow & & \searrow & \Vert & \searrow & & \nearrow & \\ & -\infty & & & & {-\infty}\Vert & & 2 & & \end{array}$$
>
> **3. Đồ thị** (Hình 5). Giao với $Oy$: $(0;\,-2)$ (cũng là điểm cực đại). Phương trình $x^2-2x+2=0$ vô nghiệm nên đồ thị **không cắt** $Ox$. Tâm đối xứng: giao điểm của TCĐ và TCX, $I(1;\,0)$.

![Hình 5. Đồ thị y = (x² − 2x + 2)/(x − 1) với TCĐ x = 1, TCX y = x − 1 và tâm đối xứng I(1; 0)](h5-bac-hai-bac-nhat.svg)

> [!bay] Giá trị cực đại nhỏ hơn giá trị cực tiểu!
> Ở Ví dụ 6, $y_{CĐ}=-2<y_{CT}=2$. Không có gì mâu thuẫn: cực đại chỉ là "đỉnh **địa phương**" (Bài 1), và hai điểm này nằm trên **hai nhánh khác nhau** của đồ thị. Phát biểu "giá trị cực đại luôn lớn hơn giá trị cực tiểu" là **sai** với hàm phân thức.

> [!ghi-nho] Đồ thị hàm phân thức bậc hai trên bậc nhất (SGK tr. 32)
> Với $y=\dfrac{ax^2+bx+c}{px+q}$ ($a\ne0$, $p\ne0$, tử không chia hết cho mẫu):
> - Nhận **giao điểm của tiệm cận đứng và tiệm cận xiên** làm tâm đối xứng.
> - Nhận hai đường phân giác của các góc tạo bởi hai tiệm cận này làm trục đối xứng.
> - Hoặc có **hai cực trị** (khi $y'=0$ có hai nghiệm, như Ví dụ 6), hoặc **không có cực trị** (khi $y'$ không đổi dấu, đồ thị hai nhánh cùng đi lên hoặc cùng đi xuống — xem SGK Ví dụ 5 tr. 31).

Vì sao? Với $y=mx+n+\dfrac{r}{px+q}$, đặt tâm $I$ là giao của $x=-\dfrac qp$ và $y=mx+n$. Đổi $x=x_0+t$: $y-y_0=mt+\dfrac{r}{pt}$ — tổng của hai hàm lẻ theo $t$, nên lẻ. Đúng như trường hợp bậc ba và bậc nhất/bậc nhất: **dời gốc về tâm, hàm thành hàm lẻ**.

> [!ung-dung] Pha loãng dung dịch
> Một bình chứa sẵn 20 lít nước sạch. Người ta rót thêm dung dịch nước muối nồng độ 50 g/l vào bình. Sau khi rót $x$ lít, nồng độ muối trong bình là $C(x)=\dfrac{50x}{20+x}$ (g/l). Hàm này đồng biến ($C'=\dfrac{1000}{(20+x)^2}>0$) và có TCN $C=50$: rót càng nhiều thì nồng độ càng gần 50 g/l nhưng **không bao giờ đạt** 50 g/l — vì lượng nước sạch ban đầu vẫn còn trong bình. Đồ thị kiểu $\frac{ax+b}{cx+d}$ xuất hiện ở mọi bài toán "trộn" và "trung bình".

## 4. Ứng dụng đồ thị: đếm số nghiệm của phương trình

Một khi đã có đồ thị (hoặc bảng biến thiên), em giải được một loại câu hỏi **rất hay ra**: phương trình $f(x)=m$ có bao nhiêu nghiệm?

**Ý tưởng:** nghiệm của $f(x)=m$ là hoành độ những điểm trên đồ thị $y=f(x)$ có tung độ bằng $m$. Đó chính là **giao điểm của đồ thị với đường thẳng nằm ngang $y=m$**. Cho đường thẳng ấy trượt lên xuống, đếm số giao điểm.

![Hình 6. Trượt đường thẳng y = m lên xuống và đếm số giao điểm với đồ thị y = x³ − 3x² + 2](h6-dem-nghiem.svg)

> [!vi-du] Ví dụ 7
> a) Tùy theo $m$, hãy cho biết số nghiệm của phương trình $x^3-3x^2+2=m$.
>
> b) Tìm $k$ để phương trình $x^3-3x^2-k=0$ có ba nghiệm phân biệt.

> [!goi-y] Gợi ý 1
> a) Dùng đồ thị Ví dụ 1 (Hình 6): giá trị cực đại $2$, giá trị cực tiểu $-2$ là hai mốc quan trọng.

> [!goi-y] Gợi ý 2
> b) Đưa về dạng "**hàm đã biết = hằng số**": $x^3-3x^2+2=k+2$.

> [!loi-giai] Lời giải
> a) Từ đồ thị (hoặc bảng biến thiên ở Ví dụ 1):
> - $m>2$ hoặc $m<-2$: **1 nghiệm**;
> - $m=2$ hoặc $m=-2$: **2 nghiệm** (đường thẳng tiếp xúc tại một điểm cực trị và cắt ở một điểm nữa);
> - $-2<m<2$: **3 nghiệm**.
>
> b) $x^3-3x^2-k=0\iff x^3-3x^2+2=k+2$. Theo a), có ba nghiệm phân biệt $\iff-2<k+2<2\iff-4<k<0$.

> [!vi-du] Ví dụ 8
> Cho hàm số $f(x)=\dfrac{x^2-2x+2}{x-1}$ (Ví dụ 6). Phương trình $2f(x)-3=0$ có bao nhiêu nghiệm? Phương trình $f(x)=3$ thì sao?

> [!goi-y] Gợi ý 1
> $2f(x)-3=0\iff f(x)=\dfrac32$. Xem trên bảng biến thiên: nhánh trái lấy những giá trị nào, nhánh phải lấy những giá trị nào?

> [!goi-y] Gợi ý 2
> Nhánh trái ($x<1$) có giá trị lớn nhất là $-2$; nhánh phải ($x>1$) có giá trị nhỏ nhất là $2$.

> [!loi-giai] Lời giải
> Từ bảng biến thiên: với $x<1$ thì $f(x)\le-2$; với $x>1$ thì $f(x)\ge2$. Đồ thị **không có điểm nào** có tung độ nằm trong khoảng $(-2;\,2)$.
> - $f(x)=\dfrac32$: vì $-2<\dfrac32<2$ nên phương trình **vô nghiệm**.
> - $f(x)=3$: đường $y=3$ không cắt nhánh trái, cắt nhánh phải tại **2 điểm** (một điểm trên $(1;\,2)$, một điểm trên $(2;\,+\infty)$). Phương trình có **2 nghiệm**. (Kiểm tra: $x^2-5x+5=0$ cho $x=\dfrac{5\pm\sqrt5}{2}$, cả hai đều lớn hơn 1.)

> [!bay] Đọc kĩ hệ số đứng trước hàm số
> Với $2f(x)-3=0$, phải chia: $f(x)=\dfrac32$, **không phải** $f(x)=3$. Đề thi rất hay cho $3f(x)+4=0$, $2f(x)=5$… và phương án nhiễu là số nghiệm của $f(x)=-4$ hay $f(x)=5$.

> [!meo] Kiểm tra bằng máy tính cầm tay
> Chế độ **Bảng giá trị (TABLE)** của máy tính cầm tay (như Casio fx-580VN X) lập được bảng giá trị $f(x)$ với $x$ chạy từ đầu đến cuối với bước nhảy tùy chọn. Nhìn chỗ $f(x)-m$ **đổi dấu** giữa hai dòng liên tiếp là biết có nghiệm nằm giữa — dùng để **soát** số nghiệm. (Tên mục có thể khác tùy máy; bước nhảy quá lớn có thể bỏ sót hai nghiệm gần nhau.)

## Dạng bài thi hay gặp

### Dạng 1. Nhận dạng hàm số từ đồ thị hoặc bảng biến thiên

- **Nhận biết:** "Đường cong trong hình là đồ thị của hàm số nào?", "Bảng biến thiên sau là của hàm số nào?" kèm 4 công thức.
- **Phương pháp (loại trừ nhanh):**
  1. Có tiệm cận hay không? Có TCĐ, TCN → phân thức $\frac{ax+b}{cx+d}$; có TCX → bậc hai/bậc nhất; không tiệm cận, hai đầu ra vô cực ngược nhau → bậc ba.
  2. Bậc ba: dấu của $a$ (nhánh phải); số cực trị; giao với $Oy$; vị trí cực trị.
  3. Phân thức: TCĐ $x=-\frac dc$, TCN $y=\frac ac$; đồng biến hay nghịch biến (dấu $ad-bc$); giao với $Oy$ là $\left(0;\,\frac bd\right)$.
- **Bẫy:** chỉ kiểm tra tiệm cận mà quên kiểm tra chiều biến thiên (hai hàm cùng tiệm cận nhưng một hàm đồng biến, một hàm nghịch biến).

> [!vi-du] Ví dụ 9
> Bảng biến thiên sau là của hàm số nào trong các hàm số $y=\dfrac{2x-3}{x+1}$; $y=\dfrac{2x+3}{x+1}$; $y=\dfrac{x-3}{x+1}$; $y=\dfrac{2x-3}{x-1}$?
>
> $$\begin{array}{c|ccccc} x & -\infty & & -1 & & +\infty \\ \hline y' & & + & \Vert & + & \\ \hline & & & +\infty\;\Vert & & 2 \\ y & & \nearrow & \Vert & \nearrow & \\ & 2 & & \Vert\;-\infty & & \end{array}$$

> [!goi-y] Gợi ý 1
> Đọc bảng: TCĐ $x=-1$ (gạch đôi), TCN $y=2$ (giới hạn ở hai đầu). Loại được hai hàm.

> [!goi-y] Gợi ý 2
> Hai hàm còn lại khác nhau ở dấu của $ad-bc$; bảng cho $y'>0$.

> [!loi-giai] Lời giải
> TCĐ $x=-1$ → loại $\dfrac{2x-3}{x-1}$ (TCĐ $x=1$). TCN $y=2$ → loại $\dfrac{x-3}{x+1}$ (TCN $y=1$).
> Còn $\dfrac{2x-3}{x+1}$: $ad-bc=2\cdot1-(-3)\cdot1=5>0$ (đồng biến ✓); $\dfrac{2x+3}{x+1}$: $ad-bc=2-3=-1<0$ (nghịch biến ✗).
> Đáp án: $y=\dfrac{2x-3}{x+1}$.

### Dạng 2. Tìm hệ số từ đồ thị (thường là trả lời ngắn)

- **Nhận biết:** "Đồ thị hàm số $y=\frac{ax+b}{x+c}$ như hình… Tính $a+b+c$", "hàm bậc ba có đồ thị như hình, tính $f(3)$".
- **Phương pháp:** mỗi thông tin đọc được là **một phương trình**:
  - phân thức $y=\frac{ax+b}{x+c}$: TCĐ $x=-c$, TCN $y=a$, giao $Oy$ cho $\frac bc$;
  - bậc ba: $y(0)=d$; tại hoành độ cực trị $x_i$ thì $y'(x_i)=0$; tọa độ các điểm cực trị cho $y(x_i)$.
- **Bẫy:** TCĐ $x=1$ thì $c=-1$ (đổi dấu!). Với bậc ba có 4 ẩn, cần đủ 4 phương trình.

> [!vi-du] Ví dụ 10
> Hình 7 là đồ thị của hàm số $y=\dfrac{ax+b}{x+c}$ ($a,b,c$ là các số thực). Tính $a+b+c$.

![Hình 7. Đồ thị hàm số y = (ax + b)/(x + c) có hai tiệm cận (nét đứt) và đi qua (0; −3)](h7-tim-he-so.svg)

> [!goi-y] Gợi ý 1
> Đọc trên hình: tiệm cận đứng, tiệm cận ngang, giao điểm với $Oy$.

> [!goi-y] Gợi ý 2
> TCĐ $x=1$ ⇒ $-c=1$. TCN $y=2$ ⇒ $a=2$. Qua $(0;\,-3)$ ⇒ $\dfrac{b}{c}=-3$.

> [!loi-giai] Lời giải
> $c=-1$, $a=2$, $b=-3c=3$. Hàm số là $y=\dfrac{2x+3}{x-1}$. Kiểm tra giao với $Ox$: $x=-\dfrac32$ ✓ (đúng như hình).
> $a+b+c=2+3-1=4$.

### Dạng 3. Số nghiệm của phương trình $f(x)=m$, có tham số

- **Nhận biết:** "tìm $m$ để phương trình… có 3 nghiệm phân biệt / có đúng 1 nghiệm", "có bao nhiêu giá trị nguyên của $m$…".
- **Phương pháp:**
  1. **Cô lập tham số:** đưa về dạng $g(x)=h(m)$ với $g$ không chứa $m$.
  2. Lập bảng biến thiên của $g$ (hoặc dùng đồ thị đề cho).
  3. Trượt đường thẳng $y=h(m)$, đọc điều kiện. Giải ra $m$, đếm giá trị nguyên nếu cần.
- **Bẫy:** quên dấu bằng/không bằng (tiếp xúc tại cực trị cho số nghiệm khác); chuyển vế sai dấu $m$.

> [!vi-du] Ví dụ 11
> Có bao nhiêu giá trị nguyên của tham số $m$ để phương trình $-x^3+3x+m-1=0$ có ba nghiệm phân biệt?

> [!goi-y] Gợi ý 1
> Cô lập: $-x^3+3x=1-m$. Khảo sát $g(x)=-x^3+3x$.

> [!goi-y] Gợi ý 2
> $g'(x)=-3x^2+3=0\iff x=\pm1$; $g(-1)=-2$, $g(1)=2$. Vì $a<0$: giảm – tăng – giảm.

> [!loi-giai] Lời giải
> $g$ có cực tiểu $-2$ (tại $x=-1$), cực đại $2$ (tại $x=1$). Ba nghiệm phân biệt $\iff-2<1-m<2\iff-1<m<3$.
> Các giá trị nguyên: $m\in\{0;\,1;\,2\}$ — có **3** giá trị.

### Dạng 4. Đúng/Sai về một hàm số cho bởi bảng biến thiên hoặc đồ thị

- **Nhận biết:** đề cho BBT/đồ thị và 4 mệnh đề: đơn điệu, cực trị, tiệm cận, số nghiệm, hệ số, tâm đối xứng.
- **Phương pháp:** ý a), b) thường **đọc thẳng** từ bảng; ý c), d) cần **tìm công thức** hàm số hoặc đếm nghiệm phương trình mới.
- **Bẫy:** khoảng đơn điệu đọc ở **dòng $x$**, không phải dòng $y$; "điểm cực đại" ($x$) khác "giá trị cực đại" ($y$).

> [!vi-du] Ví dụ 12 (Đúng/Sai)
> Cho hàm số bậc ba $y=f(x)=ax^3+bx^2+cx+d$ có bảng biến thiên:
>
> $$\begin{array}{c|ccccccc} x & -\infty & & -2 & & 0 & & +\infty \\ \hline y' & & + & 0 & - & 0 & + & \\ \hline & & & 3 & & & & +\infty \\ y & & \nearrow & & \searrow & & \nearrow & \\ & -\infty & & & & -1 & & \end{array}$$
>
> a) Hàm số nghịch biến trên khoảng $(-2;\,0)$.
>
> b) Phương trình $f(x)=2$ có ba nghiệm phân biệt.
>
> c) Đồ thị hàm số cắt trục hoành tại đúng hai điểm.
>
> d) $a+b+c+d=3$.

> [!goi-y] Gợi ý 1
> b), c): so $2$ và $0$ với giá trị cực đại $3$, giá trị cực tiểu $-1$.

> [!goi-y] Gợi ý 2
> d) $f'(x)=3ax(x+2)=3ax^2+6ax$ ⇒ $b=3a$, $c=0$. Dùng $f(0)=-1$, $f(-2)=3$ để tìm $a$, $d$. Để ý $a+b+c+d=f(1)$.

> [!loi-giai] Lời giải
> a) **Đúng** — trên $(-2;\,0)$ dòng $y'$ mang dấu $-$.
>
> b) **Đúng** — $-1<2<3$ nên đường $y=2$ cắt đồ thị tại 3 điểm.
>
> c) **Sai** — $-1<0<3$ nên trục hoành ($y=0$) cũng cắt đồ thị tại **3** điểm.
>
> d) **Đúng** — $d=f(0)=-1$; $f(-2)=-8a+4b+d=-8a+12a-1=4a-1=3\Rightarrow a=1$, $b=3$, $c=0$. Vậy $f(x)=x^3+3x^2-1$ và $a+b+c+d=f(1)=3$.

## Tóm tắt

| Loại hàm | Đạo hàm, cực trị | Tiệm cận | Tâm đối xứng |
|---|---|---|---|
| $y=ax^3+bx^2+cx+d$ | $y'=3ax^2+2bx+c$; 2 cực trị $\iff b^2-3ac>0$ | không có | điểm có hoành độ $-\dfrac{b}{3a}$ (nghiệm $y''=0$) |
| $y=\dfrac{ax+b}{cx+d}$ | $y'=\dfrac{ad-bc}{(cx+d)^2}$, không có cực trị | TCĐ $x=-\dfrac dc$, TCN $y=\dfrac ac$ | giao điểm hai tiệm cận |
| $y=\dfrac{ax^2+bx+c}{px+q}$ | viết $y=mx+n+\dfrac{r}{px+q}$; 0 hoặc 2 cực trị | TCĐ $x=-\dfrac qp$, TCX $y=mx+n$ | giao điểm TCĐ và TCX |

**Đọc đồ thị bậc ba:** $a$ ← nhánh phải; $d$ ← giao $Oy$; $c$ ← tích hoành độ cực trị $\dfrac{c}{3a}$ (hoặc $c=y'(0)$); $b$ ← tổng hoành độ cực trị $-\dfrac{2b}{3a}$.

**Đọc đồ thị $\frac{ax+b}{cx+d}$:** TCĐ, TCN, giao $Oy$ $\left(0;\,\frac bd\right)$, giao $Ox$ $\left(-\frac ba;\,0\right)$, đồng biến $\iff ad-bc>0$.

**Số nghiệm $f(x)=m$** = số giao điểm của đồ thị với đường nằm ngang $y=m$. Cô lập tham số trước, so $m$ với các giá trị cực trị và giới hạn.

**Sơ đồ tư duy khi gặp đề:** có đồ thị/BBT → đọc tiệm cận, chiều biến thiên, cực trị, giao trục → mỗi thông tin là một phương trình hoặc một điều kiện dấu; đề hỏi số nghiệm → đường thẳng nằm ngang.
