---
title: Nguyên hàm
thoi-gian: 45 phút
muc-tieu:
  - Hiểu nguyên hàm là phép "đi ngược" của đạo hàm, kiểm tra được một hàm số có là nguyên hàm của hàm số khác hay không
  - Hiểu vì sao các nguyên hàm của một hàm số lập thành một họ $F(x)+C$ và dùng đúng kí hiệu $\int f(x)\,dx$
  - Giải thích và vận dụng hai tính chất cơ bản (hằng số đưa ra ngoài, nguyên hàm của tổng, hiệu)
  - Thuộc và dùng bảng nguyên hàm của hàm lũy thừa, $\frac1x$, hàm lượng giác, hàm mũ để tìm nguyên hàm của các hàm số thường gặp
  - Tìm nguyên hàm thỏa mãn điều kiện cho trước và giải bài toán thực tế (từ vận tốc tìm quãng đường, từ tốc độ thay đổi tìm đại lượng)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. $F(x)$ là một nguyên hàm của $f(x)$ trên $K$ khi $F'(x)=f(x)$ với mọi $x\in K$. Nguyên hàm là **đạo hàm đi ngược**.
> 2. Có một nguyên hàm $F$ thì có cả **họ** $F(x)+C$, kí hiệu $\int f(x)\,dx=F(x)+C$. Luôn nhớ **$+C$**.
> 3. Hằng số đưa ra ngoài được, tổng/hiệu tách được. Tích, thương thì **không** tách được — phải khai triển hoặc chia trước.
> 4. Bảng nguyên hàm: $x^\alpha\to\dfrac{x^{\alpha+1}}{\alpha+1}$ ($\alpha\ne-1$), $\dfrac1x\to\ln\lvert x\rvert$, $\cos\to\sin$, $\sin\to-\cos$, $e^x\to e^x$, $a^x\to\dfrac{a^x}{\ln a}$.
> 5. Đề cho thêm $F(x_0)=c$ thì thay vào để tìm $C$. Vận tốc là đạo hàm của quãng đường nên **quãng đường là nguyên hàm của vận tốc**.

Ở Chương I, em đã đi theo một chiều: cho hàm số, **tính đạo hàm** để biết nó tăng hay giảm, nhanh hay chậm. Chương IV đi theo chiều ngược lại: **biết tốc độ thay đổi, tìm lại chính đại lượng đó**. Đồng hồ tốc độ của xe chỉ cho biết vận tốc ở từng thời điểm — vậy xe đã đi được bao xa? Một vết bèo lan rộng với tốc độ đã biết — sau một tuần nó phủ bao nhiêu mét vuông? Muốn trả lời, ta cần một hàm số mà **đạo hàm của nó bằng hàm số đã cho**. Hàm số đó gọi là **nguyên hàm**. Đây cũng là nền móng cho Bài 12 (Tích phân) và Bài 13 (diện tích, thể tích).

> [!nen-tang] Bảng đạo hàm lớp 11 — học thuộc trước khi đọc tiếp
> Mọi công thức nguyên hàm trong bài đều là một dòng của bảng này **đọc từ phải sang trái**.
> - $(c)'=0$ với $c$ là hằng số.
> - $(x^n)'=nx^{n-1}$.
> - $(\sqrt x)'=\frac{1}{2\sqrt x}$.
> - $\left(\frac1x\right)'=-\frac{1}{x^2}$.
> - $(\sin x)'=\cos x$.
> - $(\cos x)'=-\sin x$.
> - $(\tan x)'=\frac{1}{\cos^2x}$.
> - $(\cot x)'=-\frac{1}{\sin^2x}$.
> - $(e^x)'=e^x$.
> - $(a^x)'=a^x\ln a$.
> - $(\ln x)'=\frac1x$.
>
> **Quy tắc:** $(u\pm v)'=u'\pm v'$, $(ku)'=ku'$, $(uv)'=u'v+uv'$.

## 1. Nguyên hàm của một hàm số

### 1.1. Đạo hàm "đi ngược"

Thử đoán: hàm số nào có đạo hàm bằng $3x^2$? Em sẽ nghĩ ngay đến $x^3$, vì $(x^3)'=3x^2$. Nhưng $x^3+5$, $x^3-\sqrt2$, $x^3+2026$ cũng có đạo hàm bằng $3x^2$ (đạo hàm của hằng số bằng $0$). Vậy câu hỏi "đi ngược" có **vô số** đáp án, chúng chỉ khác nhau một hằng số.

![Hình 1. Đạo hàm và nguyên hàm là hai chiều ngược nhau. Đi ngược thì không biết hằng số ban đầu, nên phải thêm C](h1-dao-ham-nguyen-ham.svg)

> [!ghi-nho] Định nghĩa (SGK tr. 5)
> Cho hàm số $f(x)$ xác định trên $K$ (một khoảng, đoạn hoặc nửa khoảng). Hàm số $F(x)$ là **một nguyên hàm** của $f(x)$ trên $K$ nếu
> $$F'(x)=f(x)\quad\text{với mọi } x\in K.$$

Khi $K=[a;b]$, đẳng thức tại hai đầu mút được hiểu là đạo hàm một bên: $F'(a)$ là đạo hàm bên phải tại $a$, $F'(b)$ là đạo hàm bên trái tại $b$.

**Cách kiểm tra** $F$ có là nguyên hàm của $f$ hay không thì rất đơn giản: **tính $F'$ rồi so với $f$**. Muốn khẳng định "không phải", chỉ cần chỉ ra **một** điểm $x_0\in K$ mà $F'(x_0)\ne f(x_0)$.

> [!vi-du] Ví dụ 1
> a) Cho $f(x)=3x^2-4x+1$. Trong hai hàm số $F(x)=x^3-2x^2+x+5$ và $G(x)=x^3-4x^2+x$, hàm số nào là một nguyên hàm của $f(x)$ trên $\mathbb R$?
>
> b) Chứng minh $H(x)=x\ln x-x$ là một nguyên hàm của $h(x)=\ln x$ trên khoảng $(0;+\infty)$.

> [!goi-y] Gợi ý 1
> Không cần "tìm" nguyên hàm. Chỉ cần đạo hàm từng hàm số rồi so với hàm số đã cho.

> [!goi-y] Gợi ý 2
> b) $x\ln x$ là một tích, dùng $(uv)'=u'v+uv'$ với $u=x$, $v=\ln x$.

> [!loi-giai] Lời giải
> a) $F'(x)=3x^2-4x+1=f(x)$ với mọi $x$, nên $F$ **là** một nguyên hàm của $f$.
> $G'(x)=3x^2-8x+1$. Tại $x=1$: $G'(1)=-4$, còn $f(1)=0$. Vậy $G$ **không** là nguyên hàm của $f$.
>
> b) $H'(x)=1\cdot\ln x+x\cdot\dfrac1x-1=\ln x$ với mọi $x>0$. Vậy $H$ là một nguyên hàm của $\ln x$ trên $(0;+\infty)$.

> [!em-co-biet]
> Ở bài này ta **chưa** có công thức tìm nguyên hàm của $\ln x$ (cũng như của tích hai hàm số). Nhưng nếu đề **đưa sẵn** một hàm $F$, em luôn kiểm tra được bằng cách đạo hàm. Đây là kĩ năng "vạn năng" cho câu trắc nghiệm hỏi "hàm số nào là một nguyên hàm của…".

### 1.2. Họ các nguyên hàm — vì sao luôn có $+C$

Hình 1 đã gợi ý: nếu $F$ là một nguyên hàm của $f$ thì $F+C$ cũng vậy, vì $(F+C)'=F'+0=f$. Điều ngược lại cũng đúng, và đây mới là chỗ quan trọng:

> [!ghi-nho] Họ nguyên hàm (SGK tr. 5)
> Giả sử $F(x)$ là một nguyên hàm của $f(x)$ trên $K$. Khi đó:
> - Với mọi hằng số $C$, $F(x)+C$ cũng là một nguyên hàm của $f(x)$ trên $K$.
> - Mọi nguyên hàm $G(x)$ của $f(x)$ trên $K$ đều có dạng $G(x)=F(x)+C$.
>
> Tập hợp $\{F(x)+C,\ C\in\mathbb R\}$ gọi là **họ các nguyên hàm** của $f(x)$ trên $K$, kí hiệu
> $$\int f(x)\,dx=F(x)+C.$$

*Vì sao mọi nguyên hàm chỉ khác nhau một hằng số?* Nếu $F$ và $G$ cùng là nguyên hàm của $f$ thì $(G-F)'=f-f=0$ trên cả khoảng $K$. Hàm số có đạo hàm luôn bằng $0$ trên một khoảng thì **không tăng cũng không giảm** (Bài 1), tức là hằng số. Vậy $G-F=C$.

Về hình học: đồ thị của các hàm trong họ $F(x)+C$ là **cùng một đường cong được tịnh tiến lên xuống**. Tại cùng một hoành độ $x$, các tiếp tuyến của chúng song song với nhau (cùng hệ số góc $f(x)$).

![Hình 2. Họ nguyên hàm của f(x) = 2x là các parabol y = x² + C, tịnh tiến theo phương thẳng đứng. Chỉ có đúng một đường đi qua điểm (1; 3)](h2-ho-nguyen-ham.svg)

Hình 2 cũng cho thấy: muốn chọn ra **một** nguyên hàm cụ thể trong họ, chỉ cần biết thêm **một điểm** mà đồ thị đi qua. Ta sẽ dùng ý này ở mục 4.

> [!ghi-nho] Chú ý (SGK tr. 6)
> - "Tìm nguyên hàm" của $f(x)$ nghĩa là tìm cả họ. Chỉ cần tìm **một** nguyên hàm $F(x)$ rồi viết thêm $+C$.
> - Nếu $f(x)$ **liên tục** trên khoảng $K$ thì $f(x)$ có nguyên hàm trên $K$.
> - Biểu thức $f(x)\,dx$ là **vi phân** của $F(x)$: $dF(x)=F'(x)\,dx=f(x)\,dx$. Chữ $dx$ cho biết **biến** lấy nguyên hàm là $x$.
> - Đề không nói rõ $K$ thì hiểu là tìm nguyên hàm trên tập xác định của hàm số.

> [!vi-du] Ví dụ 2
> a) Tìm một nguyên hàm của $f(x)=x^4$ trên $\mathbb R$, từ đó tìm $\int x^4\,dx$.
>
> b) Tìm $\int 7\,dx$ và $\int 0\,dx$.

> [!goi-y] Gợi ý 1
> a) Hàm nào đạo hàm ra $x^4$? Thử $x^5$: $(x^5)'=5x^4$, thừa hệ số $5$. Chia bớt cho $5$.

> [!goi-y] Gợi ý 2
> b) Hàm nào có đạo hàm bằng hằng số $7$? Hàm nào có đạo hàm bằng $0$?

> [!loi-giai] Lời giải
> a) $\left(\dfrac{x^5}{5}\right)'=\dfrac{5x^4}{5}=x^4$ nên $F(x)=\dfrac{x^5}{5}$ là một nguyên hàm. Do đó $\int x^4\,dx=\dfrac{x^5}{5}+C$.
>
> b) $(7x)'=7$ nên $\int 7\,dx=7x+C$. Còn $(C)'=0$ nên $\int 0\,dx=C$.

> [!bay]
> - **Quên $+C$** khi đề hỏi $\int f(x)\,dx$: trong đề trắc nghiệm, phương án thiếu $+C$ thường chính là phương án nhiễu.
> - Phân biệt "**một** nguyên hàm" (một hàm cụ thể, ví dụ $\frac{x^5}{5}+3$) với "**họ** nguyên hàm" (có $+C$). Câu hỏi "hàm số nào là một nguyên hàm" thì đáp án có thể có hằng số lạ như $+3$, $-\sqrt2$ — vẫn đúng.
> - $\int 0\,dx=C$ chứ **không** bằng $0$.

## 2. Tính chất cơ bản của nguyên hàm

### 2.1. Hằng số và tổng, hiệu

Vì đạo hàm cho phép đưa hằng số ra ngoài và tách tổng, nên nguyên hàm (phép ngược) cũng vậy:

> [!ghi-nho] Tính chất (SGK tr. 6–7)
> Với $f$, $g$ liên tục trên $K$:
> - $\int kf(x)\,dx=k\int f(x)\,dx$ với $k\ne0$.
> - $\int[f(x)+g(x)]\,dx=\int f(x)\,dx+\int g(x)\,dx$.
> - $\int[f(x)-g(x)]\,dx=\int f(x)\,dx-\int g(x)\,dx$.

*Vì sao?* Nếu $F'=f$ và $G'=g$ thì $(kF)'=kf$ và $(F\pm G)'=f\pm g$. Nói cách khác, $kF$ là một nguyên hàm của $kf$, $F\pm G$ là một nguyên hàm của $f\pm g$.

Kết hợp với Ví dụ 2 (và cách làm tương tự cho $x^n$), ta có ngay công thức cho đa thức:

$$\int x^n\,dx=\frac{x^{n+1}}{n+1}+C$$

$$\int kx^n\,dx=\frac{k\,x^{n+1}}{n+1}+C$$

Nhớ bằng lời: **tăng số mũ thêm 1, rồi chia cho số mũ mới.**

> [!vi-du] Ví dụ 3
> Tìm:
>
> a) $\int(8x^3-6x^2+2x-5)\,dx$.
>
> b) $\int(x+2)(3x-1)\,dx$.

> [!goi-y] Gợi ý 1
> a) Tách thành từng số hạng, mỗi số hạng dùng "tăng mũ, chia mũ mới". Chỉ cần viết **một** hằng số $C$ ở cuối.

> [!goi-y] Gợi ý 2
> b) Chưa có công thức cho tích. Hãy **nhân phá ngoặc** để được đa thức trước.

> [!loi-giai] Lời giải
> a) $\int(8x^3-6x^2+2x-5)\,dx=8\cdot\dfrac{x^4}{4}-6\cdot\dfrac{x^3}{3}+2\cdot\dfrac{x^2}{2}-5x+C$, tức là
> $$=2x^4-2x^3+x^2-5x+C.$$
>
> b) $(x+2)(3x-1)=3x^2+5x-2$. Do đó
> $$\int(3x^2+5x-2)\,dx=x^3+\frac52x^2-2x+C.$$
>
> Kiểm tra lại bằng đạo hàm: $\left(x^3+\frac52x^2-2x\right)'=3x^2+5x-2$ ✓.

> [!bay] Không có "nguyên hàm của tích bằng tích các nguyên hàm"
> Thử với $x\cdot x$: nếu "tách tích" thì được $\frac{x^2}{2}\cdot\frac{x^2}{2}=\frac{x^4}{4}$, nhưng $\left(\frac{x^4}{4}\right)'=x^3\ne x^2$. Đúng phải là $\int x^2\,dx=\frac{x^3}{3}+C$. Tương tự, **không** chia hai nguyên hàm cho nhau. Gặp tích hay thương: **khai triển hoặc chia từng số hạng** trước.

> [!meo] Luôn tự kiểm tra bằng đạo hàm
> Tìm xong nguyên hàm, em đạo hàm lại trong đầu (mất 10 giây). Ra đúng hàm ban đầu là chắc chắn đúng. Thói quen này loại gần hết lỗi sai hệ số và dấu.

### 2.2. Bài toán thực tế: từ tốc độ thay đổi tìm lại đại lượng

Ý nghĩa cơ học của đạo hàm: nếu $S(t)$ là quãng đường đi được sau $t$ giây thì $S'(t)=v(t)$ là vận tốc. Đọc ngược lại:

$$S(t)=\int v(t)\,dt.$$

Tổng quát hơn, nếu biết **tốc độ thay đổi** $Q'(x)$ của một đại lượng $Q$ (chi phí biên, doanh thu biên, tốc độ tăng dân số, tốc độ chảy của nước…) thì $Q$ là một nguyên hàm của $Q'$. Hằng số $C$ được tìm nhờ **giá trị ban đầu** (thường là $S(0)=0$, chi phí cố định, số lượng ban đầu…).

> [!vi-du] Ví dụ 4
> Một đoàn tàu điện rời ga, vận tốc của nó sau $t$ giây là $v(t)=2+1{,}2t$ (m/s). Tính quãng đường đoàn tàu đi được trong 25 giây đầu tiên.

> [!goi-y] Gợi ý 1
> Gọi $S(t)$ là quãng đường đi được sau $t$ giây. Ta có $S'(t)=v(t)$, nên $S(t)$ là một nguyên hàm của $v(t)$.

> [!goi-y] Gợi ý 2
> Lúc rời ga ($t=0$) tàu chưa đi được mét nào: $S(0)=0$. Dùng điều này để tìm $C$.

> [!loi-giai] Lời giải
> $S(t)=\int(2+1{,}2t)\,dt=2t+0{,}6t^2+C$.
> $S(0)=0$ nên $C=0$, do đó $S(t)=0{,}6t^2+2t$.
> Sau 25 giây: $S(25)=0{,}6\cdot625+2\cdot25=375+50=425$ (m).

> [!vi-du] Ví dụ 5
> Một xưởng may tính được **chi phí biên** (tốc độ thay đổi của chi phí theo số sản phẩm) là $C'(x)=0{,}03x^2-1{,}2x+20$ (nghìn đồng/sản phẩm), với $x$ là số sản phẩm. Chi phí cố định (khi chưa may chiếc nào) là $500$ nghìn đồng. Tính tổng chi phí để may $50$ sản phẩm.

> [!goi-y] Gợi ý 1
> Chi phí $C(x)$ là một nguyên hàm của chi phí biên $C'(x)$. Ở đây hằng số của họ nguyên hàm nên đặt tên khác (ví dụ $K$) để khỏi lẫn với chữ $C$ của chi phí.

> [!goi-y] Gợi ý 2
> "Chi phí cố định 500 nghìn đồng" nghĩa là $C(0)=500$.

> [!loi-giai] Lời giải
> $C(x)=\int(0{,}03x^2-1{,}2x+20)\,dx=0{,}01x^3-0{,}6x^2+20x+K$.
> $C(0)=500$ nên $K=500$.
> $C(50)=0{,}01\cdot125\,000-0{,}6\cdot2\,500+20\cdot50+500$, tức là
> $$C(50)=1\,250-1\,500+1\,000+500$$
> $$=1\,250.$$
> Tổng chi phí khoảng $1\,250$ nghìn đồng, tức $1{,}25$ triệu đồng.

> [!ung-dung]
> Đây chính là cách điện thoại, đồng hồ thông minh "đoán" quãng đường em chạy khi mất sóng GPS: cảm biến đo **gia tốc** liên tục, máy lấy nguyên hàm một lần ra **vận tốc**, lấy thêm một lần nữa ra **quãng đường**. Trong Y học, từ **tốc độ** thuốc được truyền vào cơ thể (mg/phút), ta tính được **tổng lượng thuốc** đã vào sau một khoảng thời gian theo cùng cách.

## 3. Nguyên hàm của một số hàm số thường gặp

### 3.1. Hàm số lũy thừa và hàm số $\frac1x$

Hàm số $y=x^\alpha$ ($\alpha\in\mathbb R$) gọi là hàm số lũy thừa. Tập xác định của nó phụ thuộc $\alpha$:
- $\alpha$ nguyên dương: $\mathbb R$.
- $\alpha$ nguyên âm hoặc bằng $0$: $\mathbb R\setminus\{0\}$.
- $\alpha$ không nguyên: $(0;+\infty)$.

Với mọi $x>0$, ta có $(x^\alpha)'=\alpha x^{\alpha-1}$ (mở rộng công thức $(x^n)'$ của lớp 11). Đọc ngược lại, với $\alpha\ne-1$:

$$\left(\frac{x^{\alpha+1}}{\alpha+1}\right)'=\frac{(\alpha+1)x^{\alpha}}{\alpha+1}=x^\alpha.$$

*Vì sao phải có $\alpha\ne-1$?* Vì khi $\alpha=-1$, mẫu số $\alpha+1=0$ — công thức "tăng mũ, chia mũ mới" bị hỏng. Trường hợp $x^{-1}=\dfrac1x$ cần một hàm khác: $\ln\lvert x\rvert$.
- Với $x>0$: $(\ln x)'=\dfrac1x$.
- Với $x<0$: $\ln\lvert x\rvert=\ln(-x)$, đạo hàm hàm hợp cho $\dfrac{-1}{-x}=\dfrac1x$.

Cả hai trường hợp đều ra $\dfrac1x$, nên dùng $\ln\lvert x\rvert$ là đúng trên toàn bộ tập xác định.

> [!ghi-nho] Công thức (SGK tr. 8)
> $$\int x^\alpha\,dx=\frac{x^{\alpha+1}}{\alpha+1}+C\quad(\alpha\ne-1)$$
> $$\int\frac1x\,dx=\ln\lvert x\rvert+C$$

> [!meo] Viết về dạng lũy thừa trước khi dùng công thức
> - $\sqrt x=x^{\frac12}$.
> - $\sqrt[3]{x^2}=x^{\frac23}$.
> - $\dfrac{1}{x^n}=x^{-n}$.
> - $\dfrac{1}{\sqrt x}=x^{-\frac12}$.
> - $x\sqrt x=x^{\frac32}$.
>
> Xong rồi mới "tăng mũ, chia mũ mới". Cuối cùng có thể đổi lại về dạng căn cho gọn.

> [!vi-du] Ví dụ 6
> Tìm:
>
> a) $\int x^2\sqrt x\,dx$ $(x>0)$.
>
> b) $\int\dfrac{4}{x^5}\,dx$.
>
> c) $\int\left(x-\dfrac2x+\dfrac{1}{\sqrt x}\right)dx$ $(x>0)$.

> [!goi-y] Gợi ý 1
> a) $x^2\sqrt x=x^{2+\frac12}=x^{\frac52}$. b) $\dfrac{4}{x^5}=4x^{-5}$.

> [!goi-y] Gợi ý 2
> c) Ba số hạng dùng ba công thức khác nhau: $x^1$ (lũy thừa), $\dfrac1x$ (ra $\ln$), $x^{-\frac12}$ (lũy thừa). Vì $x>0$ nên $\ln\lvert x\rvert=\ln x$.

> [!loi-giai] Lời giải
> a) $\int x^{\frac52}\,dx=\dfrac{x^{\frac72}}{\frac72}+C=\dfrac27x^3\sqrt x+C$.
>
> b) $\int 4x^{-5}\,dx=4\cdot\dfrac{x^{-4}}{-4}+C=-\dfrac{1}{x^4}+C$.
>
> c) $\int x\,dx-2\int\dfrac1x\,dx+\int x^{-\frac12}\,dx$, tức là
> $$=\frac{x^2}{2}-2\ln x+2\sqrt x+C.$$
> (Vì $\int x^{-\frac12}dx=\dfrac{x^{\frac12}}{\frac12}=2\sqrt x$.)

> [!bay]
> - $\int\dfrac{1}{x^2}\,dx$ **không** phải $\ln x^2$. Ở đây $\alpha=-2\ne-1$ nên dùng lũy thừa: $\dfrac{x^{-1}}{-1}=-\dfrac1x$. Chỉ **đúng** $\dfrac1x$ (mũ $-1$) mới ra $\ln$.
> - Chia cho số mũ **âm** hoặc **phân số**: $\dfrac{x^{-4}}{-4}$, $\dfrac{x^{7/2}}{7/2}=\dfrac27x^{7/2}$. Học sinh hay quên dấu trừ hoặc quên lật phân số.
> - Với $x\in\mathbb R\setminus\{0\}$ phải viết $\ln\lvert x\rvert$. Chỉ khi đề cho $x>0$ mới bỏ dấu giá trị tuyệt đối.

### 3.2. Hàm số lượng giác

Đọc ngược bốn dòng lượng giác của bảng đạo hàm:

> [!ghi-nho] Công thức (SGK tr. 9)
> - $\int\cos x\,dx=\sin x+C$.
> - $\int\sin x\,dx=-\cos x+C$.
> - $\int\dfrac{1}{\cos^2x}\,dx=\tan x+C$.
> - $\int\dfrac{1}{\sin^2x}\,dx=-\cot x+C$.

*Vì sao $\int\sin x\,dx$ có dấu trừ?* Vì $(\cos x)'=-\sin x$, nên muốn đạo hàm ra $+\sin x$ ta cần $(-\cos x)'=\sin x$. Tương tự, $(\cot x)'=-\dfrac{1}{\sin^2x}$ nên $\int\dfrac{1}{\sin^2x}dx$ cũng mang dấu trừ. Cách nhớ: **hàm dưới dấu $\int$ có chữ "sin" thì kết quả có dấu trừ** ($\sin x\to-\cos x$, $\dfrac{1}{\sin^2x}\to-\cot x$).

> [!nen-tang] Công thức lượng giác lớp 11 hay dùng ở đây
> - $1+\tan^2x=\dfrac{1}{\cos^2x}$.
> - $1+\cot^2x=\dfrac{1}{\sin^2x}$.
> - Hạ bậc: $\cos^2x=\dfrac{1+\cos2x}{2}$, $\sin^2x=\dfrac{1-\cos2x}{2}$.
> - Thay $x$ bằng $\frac x2$: $2\cos^2\frac x2=1+\cos x$, $2\sin^2\frac x2=1-\cos x$.
>
> Ý tưởng: biến hàm "lạ" thành tổng các hàm **có trong bảng** rồi mới lấy nguyên hàm. Ở bài này em dùng dạng $2\cos^2\frac x2=1+\cos x$, $2\sin^2\frac x2=1-\cos x$ — vì $\cos2x$ chưa có sẵn trong bảng nguyên hàm của SGK.

> [!vi-du] Ví dụ 7
> Tìm:
>
> a) $\int(3\sin x-2\cos x)\,dx$.
>
> b) $\int(2+\tan^2x)\,dx$.
>
> c) $\int 2\cos^2\dfrac x2\,dx$.

> [!goi-y] Gợi ý 1
> b) $\tan^2x$ không có trong bảng. Viết $2+\tan^2x=1+(1+\tan^2x)=1+\dfrac{1}{\cos^2x}$.

> [!goi-y] Gợi ý 2
> c) Dùng hạ bậc: $2\cos^2\dfrac x2=1+\cos x$.

> [!loi-giai] Lời giải
> a) $3\int\sin x\,dx-2\int\cos x\,dx=-3\cos x-2\sin x+C$.
>
> b) $\int\left(1+\dfrac{1}{\cos^2x}\right)dx=x+\tan x+C$.
>
> c) $\int(1+\cos x)\,dx=x+\sin x+C$.

> [!bay]
> - Nhầm dấu: $\int\sin x\,dx=\cos x+C$ là **sai** — kiểm tra: $(\cos x)'=-\sin x$.
> - $\int\tan^2x\,dx\ne\dfrac{\tan^3x}{3}+C$: công thức lũy thừa chỉ dùng cho **biến $x$** mũ $\alpha$, không dùng cho $(\tan x)^2$, $(\sin x)^2$…

### 3.3. Hàm số mũ

Vì $(e^x)'=e^x$ nên $e^x$ là nguyên hàm của chính nó. Với $0<a\ne1$: $(a^x)'=a^x\ln a$, nên muốn đạo hàm ra đúng $a^x$ ta chia bớt cho $\ln a$:

$$\left(\frac{a^x}{\ln a}\right)'=\frac{a^x\ln a}{\ln a}=a^x.$$

> [!ghi-nho] Công thức (SGK tr. 10)
> $$\int e^x\,dx=e^x+C$$
> $$\int a^x\,dx=\frac{a^x}{\ln a}+C\quad(0<a\ne1)$$

> [!vi-du] Ví dụ 8
> Tìm:
>
> a) $\int 6^x\,dx$.
>
> b) $\int 2^{x+1}\,dx$.
>
> c) $\int(e^x-4^{-x})\,dx$.

> [!goi-y] Gợi ý 1
> b) $2^{x+1}=2\cdot2^x$: đưa hằng số $2$ ra ngoài.

> [!goi-y] Gợi ý 2
> c) $4^{-x}=\left(\dfrac14\right)^x$ là hàm mũ cơ số $a=\dfrac14$, và $\ln\dfrac14=-\ln4$.

> [!loi-giai] Lời giải
> a) $\int 6^x\,dx=\dfrac{6^x}{\ln6}+C$.
>
> b) $\int 2\cdot2^x\,dx=2\cdot\dfrac{2^x}{\ln2}+C=\dfrac{2^{x+1}}{\ln2}+C$.
>
> c) $\int\left(\frac14\right)^x dx=\dfrac{(1/4)^x}{\ln\frac14}=-\dfrac{1}{4^x\ln4}$. Do đó
> $$\int(e^x-4^{-x})\,dx=e^x+\frac{1}{4^x\ln4}+C.$$

> [!bay] Đừng nhầm hàm mũ với hàm lũy thừa
> - $x^3$: **biến ở cơ số** → lũy thừa, "tăng mũ, chia mũ mới": $\dfrac{x^4}{4}$.
> - $3^x$: **biến ở số mũ** → hàm mũ, chia cho $\ln3$: $\dfrac{3^x}{\ln3}$.
>
> Phương án nhiễu kinh điển: $\int 3^x\,dx=\dfrac{3^{x+1}}{x+1}+C$ (dùng nhầm công thức lũy thừa) hoặc $3^x\ln3+C$ (đó là **đạo hàm**, không phải nguyên hàm).

### 3.4. Bảng nguyên hàm

Gom tất cả lại (SGK tr. 10). Mỗi dòng đều kiểm tra được bằng cách đạo hàm vế phải.

| Hàm số $f(x)$ | $\int f(x)\,dx$ | Điều kiện |
|---|---|---|
| $0$ | $C$ | |
| $1$ | $x+C$ | |
| $x^\alpha$ | $\dfrac{x^{\alpha+1}}{\alpha+1}+C$ | $\alpha\ne-1$ |
| $\dfrac1x$ | $\ln\lvert x\rvert+C$ | $x\ne0$ |
| $e^x$ | $e^x+C$ | |
| $a^x$ | $\dfrac{a^x}{\ln a}+C$ | $0<a\ne1$ |
| $\cos x$ | $\sin x+C$ | |
| $\sin x$ | $-\cos x+C$ | |
| $\dfrac{1}{\cos^2x}$ | $\tan x+C$ | $\cos x\ne0$ |
| $\dfrac{1}{\sin^2x}$ | $-\cot x+C$ | $\sin x\ne0$ |

Bảng này cộng với hai tính chất ở mục 2 giúp em tìm nguyên hàm của rất nhiều hàm số. Quy trình chung: **biến đổi** (khai triển, chia, viết về $x^\alpha$, dùng công thức lượng giác) → **tách** thành tổng các hàm có trong bảng → **áp dụng bảng** → **đạo hàm lại để kiểm tra**.

## 4. Nguyên hàm thỏa mãn một điều kiện cho trước

Như Hình 2, họ $F(x)+C$ gồm vô số đường cong song song. Đề cho thêm **một điều kiện** $F(x_0)=c$ (đồ thị đi qua điểm $(x_0;\,c)$, hoặc giá trị ban đầu) thì chọn được **đúng một** hàm.

**Các bước:**
1. Tìm họ nguyên hàm $F(x)=G(x)+C$.
2. Thay $x=x_0$: $G(x_0)+C=c$, giải ra $C$.
3. Viết $F(x)$ cụ thể, rồi tính giá trị đề hỏi.

> [!vi-du] Ví dụ 9
> Cho hàm số $y=f(x)$ xác định trên $(0;+\infty)$, có $f'(x)=3x^2-\dfrac{2}{x^2}$ và $f(1)=4$. Tính $f(2)$.

> [!goi-y] Gợi ý 1
> $f$ là một nguyên hàm của $f'$. Viết $\dfrac{2}{x^2}=2x^{-2}$.

> [!goi-y] Gợi ý 2
> $\int 2x^{-2}\,dx=2\cdot\dfrac{x^{-1}}{-1}=-\dfrac2x$. Nhớ dấu trừ phía trước nó trong $f'$.

> [!loi-giai] Lời giải
> $f(x)=\int\left(3x^2-2x^{-2}\right)dx=x^3+\dfrac2x+C$.
> $f(1)=1+2+C=4$ nên $C=1$, do đó $f(x)=x^3+\dfrac2x+1$.
> $f(2)=8+1+1=10$.

> [!vi-du] Ví dụ 10
> Chiều cao $h(t)$ (cm) của một cây giống sau $t$ tuần được trồng tăng với tốc độ $h'(t)=1{,}5\sqrt t$ (cm/tuần). Lúc trồng, cây cao $12$ cm. Sau 9 tuần cây cao bao nhiêu?

> [!goi-y] Gợi ý 1
> $h(t)=\int1{,}5\,t^{\frac12}\,dt$, điều kiện $h(0)=12$.

> [!goi-y] Gợi ý 2
> $\int t^{\frac12}dt=\dfrac{t^{\frac32}}{\frac32}=\dfrac23t^{\frac32}$, và $9^{\frac32}=\left(\sqrt9\right)^3=27$.

> [!loi-giai] Lời giải
> $h(t)=1{,}5\cdot\dfrac23t^{\frac32}+C=t\sqrt t+C$.
> $h(0)=12$ nên $C=12$, do đó $h(t)=t\sqrt t+12$.
> Sau 9 tuần: $h(9)=9\cdot3+12=39$ (cm).

> [!bay]
> - Tìm $C$ xong phải **thay $C$ vào** rồi mới tính $F(x_1)$. Lỗi hay gặp: quên cộng $C$, ra $F(2)=9$ thay vì $10$ (Ví dụ 9).
> - Điều kiện "ban đầu" là tại $t=0$, nhưng đề có thể cho tại thời điểm khác (ví dụ "sau 2 giây vật cách mốc 5 m" là $S(2)=5$). Đọc kĩ.

## Dạng bài thi hay gặp

### Dạng 1. Tìm nguyên hàm (trắc nghiệm 4 lựa chọn)

- **Nhận biết:** "$\int f(x)\,dx$ bằng", "hàm số nào là một nguyên hàm của $f(x)$".
- **Phương pháp:**
  1. Biến đổi $f$ thành tổng các hàm trong bảng (khai triển tích, chia phân thức, viết căn thành lũy thừa, dùng $1+\tan^2x$, hạ bậc).
  2. Áp dụng bảng + tính chất.
  3. Hoặc làm ngược: **đạo hàm từng phương án**, phương án nào ra đúng $f(x)$ thì chọn.
- **Bẫy:** dấu của $\int\sin x$, nhầm $x^a$ với $a^x$, $\ln$ cho $\frac{1}{x^2}$, "tách" tích.

> [!vi-du] Ví dụ 11
> Hàm số nào dưới đây là một nguyên hàm của $f(x)=2x+\sin x$ trên $\mathbb R$?
>
> (1) $x^2+\cos x$.  (2) $x^2-\cos x+3$.  (3) $2-\cos x$.  (4) $x^2+\sin x$.

> [!goi-y] Gợi ý 1
> Đạo hàm từng hàm số. Hằng số $+3$ có đạo hàm bằng $0$, đừng vội loại phương án có nó.

> [!goi-y] Gợi ý 2
> $(\cos x)'=-\sin x$, $(-\cos x)'=\sin x$.

> [!loi-giai] Lời giải
> - $(x^2+\cos x)'=2x-\sin x$ ✗.
> - $(x^2-\cos x+3)'=2x+\sin x$ ✓.
> - $(2-\cos x)'=\sin x$ ✗.
> - $(x^2+\sin x)'=2x+\cos x$ ✗.
>
> Vậy chọn $x^2-\cos x+3$.

> [!meo] Soát bằng Casio fx-580VN X
> Muốn biết $F$ có phải nguyên hàm của $f$: dùng phím đạo hàm $\frac{d}{dx}(\square)\big|_{x=\square}$, nhập $F(x)$ và một giá trị như $x=0{,}7$ (chế độ **Radian** nếu có lượng giác), rồi so với $f(0{,}7)$ bấm bằng CALC. Khác nhau là loại ngay. Đây chỉ là cách soát nhanh, nên thử thêm một giá trị thứ hai nếu hai kết quả trùng nhau.

### Dạng 2. Nguyên hàm thỏa điều kiện — tính một giá trị (trả lời ngắn)

- **Nhận biết:** "$F(x)$ là một nguyên hàm của $f(x)$ thỏa $F(x_0)=c$. Tính $F(x_1)$" hoặc "biết $f'(x)=\dots$ và $f(x_0)=c$".
- **Phương pháp:** họ nguyên hàm → thay điều kiện tìm $C$ → tính giá trị. Nếu cần làm tròn, chỉ làm tròn **ở bước cuối**.
- **Bẫy:** quên $C$; nhầm $f$ với $f'$; máy tính để chế độ độ (D) khi có $\sin$, $\cos$.

> [!vi-du] Ví dụ 12
> Cho $F(x)$ là một nguyên hàm của $f(x)=e^x+2x$ thỏa mãn $F(0)=3$. Tính $F(1)$ (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> $F(x)=e^x+x^2+C$. Chú ý $e^0=1$, không phải $0$.

> [!goi-y] Gợi ý 2
> $1+C=3$.

> [!loi-giai] Lời giải
> $F(x)=e^x+x^2+C$. $F(0)=1+0+C=3$ nên $C=2$.
> $F(1)=e+1+2=e+3\approx5{,}718$. Đáp số: $5{,}7$.

### Dạng 3. Đúng/Sai về một nguyên hàm $F(x)$

- **Nhận biết:** đề cho $f(x)$ (thường kèm một điều kiện), bốn ý hỏi: biểu thức của $F$, giá trị $F$ tại một điểm, tính chất của $F$ (đồng biến, cực trị — liên hệ Chương I vì $F'=f$), đồ thị $F$ đi qua điểm nào.
- **Phương pháp:** tìm $F$ cụ thể ngay từ đầu, sau đó xử lí từng ý. Ý về đơn điệu, cực trị: dùng $F'(x)=f(x)$, **không cần** biểu thức $F$.
- **Bẫy:** ý (a) thường "gài" thiếu hoặc sai hằng số $C$; ý về đồ thị đi qua gốc tọa độ thì kiểm tra $F(0)$.

> [!vi-du] Ví dụ 13 (Đúng/Sai)
> Cho $F(x)$ là một nguyên hàm của $f(x)=3x^2+2\cos x$ trên $\mathbb R$ thỏa mãn $F(0)=1$. Xét các mệnh đề:
>
> a) $F(x)=x^3+2\sin x+1$.
>
> b) Hàm số $F(x)$ đồng biến trên $\mathbb R$.
>
> c) $F(\pi)=\pi^3$.
>
> d) Đồ thị hàm số $y=F(x)$ đi qua gốc tọa độ.

> [!goi-y] Gợi ý 1
> a) $F(x)=x^3+2\sin x+C$, $\sin0=0$.

> [!goi-y] Gợi ý 2
> b) $F'(x)=3x^2+2\cos x$. Xét riêng $\lvert x\rvert\ge1$ (khi đó $3x^2\ge3$) và $\lvert x\rvert<1$ (khi đó $\cos x>0$).

> [!loi-giai] Lời giải
> a) **Đúng** — $F(0)=0+0+C=1$ nên $C=1$.
>
> b) **Đúng** — $F'(x)=3x^2+2\cos x$. Nếu $\lvert x\rvert\ge1$ thì $3x^2+2\cos x\ge3-2=1>0$. Nếu $\lvert x\rvert<1$ thì $\cos x>0$ (vì $1<\frac\pi2$) và $3x^2\ge0$, tổng dương. Vậy $F'(x)>0$ với mọi $x$, $F$ đồng biến trên $\mathbb R$.
>
> c) **Sai** — $F(\pi)=\pi^3+2\sin\pi+1=\pi^3+1$.
>
> d) **Sai** — $F(0)=1\ne0$, đồ thị cắt trục tung tại điểm $(0;\,1)$.

### Dạng 4. Bài toán chuyển động, tăng trưởng (trả lời ngắn)

- **Nhận biết:** cho vận tốc $v(t)$ (hoặc gia tốc $a(t)$), tốc độ tăng/giảm của một đại lượng (dân số, vi khuẩn, chi phí, lượng nước…), hỏi quãng đường, độ cao, giá trị của đại lượng.
- **Phương pháp:**
  1. Đại lượng = nguyên hàm của tốc độ thay đổi: $S=\int v\,dt$ (và $v=\int a\,dt$ nếu đề cho gia tốc).
  2. Tìm $C$ từ giá trị ban đầu.
  3. Tìm **thời điểm** đề hỏi: xe dừng khi $v(t)=0$; vật lên cao nhất khi $v(t)=0$ (đổi chiều).
  4. Tính giá trị, làm tròn theo yêu cầu.
- **Bẫy:** quên $C$ khi vật **không** xuất phát từ mốc (ném từ độ cao 2 m); dùng sai thời điểm; gộp đơn vị phút với giây.

> [!vi-du] Ví dụ 14
> Một ô tô đang chạy thì người lái đạp phanh. Từ thời điểm đó, ô tô chuyển động chậm dần với vận tốc $v(t)=20-5t$ (m/s). Hỏi từ lúc đạp phanh đến khi dừng hẳn, ô tô đi thêm được bao nhiêu mét?

> [!goi-y] Gợi ý 1
> Xe dừng khi $v(t)=0$: tìm $t$.

> [!goi-y] Gợi ý 2
> $S(t)=\int(20-5t)\,dt$ với $S(0)=0$ (tính quãng đường kể từ lúc đạp phanh).

> [!loi-giai] Lời giải
> $v(t)=0\iff t=4$ (giây).
> $S(t)=20t-2{,}5t^2+C$, $S(0)=0$ nên $C=0$.
> $S(4)=80-40=40$ (m). Ô tô đi thêm $40$ m.

> [!vi-du] Ví dụ 15
> Từ độ cao $2$ m so với mặt đất, một quả bóng được ném thẳng đứng lên trên. Vận tốc của bóng sau $t$ giây là $v(t)=29{,}4-9{,}8t$ (m/s). Tìm độ cao lớn nhất của quả bóng so với mặt đất (làm tròn đến hàng phần mười).

![Hình 3. Vận tốc giảm đều. Khi v = 0 (t = 3 s) quả bóng đổi chiều chuyển động, độ cao h(t) đạt lớn nhất](h3-van-toc-do-cao.svg)

> [!goi-y] Gợi ý 1
> Độ cao $h(t)$ là một nguyên hàm của $v(t)$, với $h(0)=2$ (không phải $0$).

> [!goi-y] Gợi ý 2
> Bóng lên cao nhất đúng lúc nó ngừng đi lên, tức là $v(t)=0$. (Đây cũng là chỗ $h'(t)=0$ đổi dấu từ dương sang âm — cực đại theo Chương I.)

> [!loi-giai] Lời giải
> $h(t)=29{,}4t-4{,}9t^2+C$. $h(0)=2$ nên $C=2$.
> $v(t)=0\iff t=3$. Với $t<3$ thì $v>0$ (đi lên), với $t>3$ thì $v<0$ (rơi xuống).
> $h(3)=88{,}2-44{,}1+2=46{,}1$ (m). Độ cao lớn nhất là $46{,}1$ m.

> [!em-co-biet]
> Ký hiệu $\int$ là chữ **S kéo dài** (của từ Latin *summa* — tổng), do Leibniz đặt ra năm 1675. Vì sao "tổng" lại liên quan đến nguyên hàm? Quãng đường là **tổng** của rất nhiều quãng nhỏ $v\cdot\Delta t$. Ở Bài 12 (Tích phân), em sẽ thấy rõ mối liên hệ kì diệu này.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Định nghĩa | $F$ là một nguyên hàm của $f$ trên $K$ $\iff F'(x)=f(x)$, $\forall x\in K$ |
| Họ nguyên hàm | $\int f(x)\,dx=F(x)+C$ — các nguyên hàm chỉ khác nhau hằng số |
| Hằng số | $\int kf(x)\,dx=k\int f(x)\,dx$ $(k\ne0)$ |
| Tổng, hiệu | $\int(f\pm g)\,dx=\int f\,dx\pm\int g\,dx$ |
| Lũy thừa | $\int x^\alpha dx=\dfrac{x^{\alpha+1}}{\alpha+1}+C$ $(\alpha\ne-1)$ |
| Nghịch đảo | $\int\dfrac1x\,dx=\ln\lvert x\rvert+C$ |
| Mũ | $\int e^xdx=e^x+C$, $\int a^xdx=\dfrac{a^x}{\ln a}+C$ |
| Lượng giác | $\int\cos x\,dx=\sin x+C$, $\int\sin x\,dx=-\cos x+C$ |
| Lượng giác (tiếp) | $\int\dfrac{dx}{\cos^2x}=\tan x+C$, $\int\dfrac{dx}{\sin^2x}=-\cot x+C$ |
| Điều kiện $F(x_0)=c$ | Thay vào họ nguyên hàm để tìm $C$ |
| Thực tế | Quãng đường $=\int$ vận tốc, đại lượng $=\int$ tốc độ thay đổi |

**Sơ đồ tư duy khi gặp đề:** hàm có **tích, thương, căn, $\tan^2$, $\sin^2\frac x2$** → biến đổi về tổng các hàm trong bảng → áp dụng bảng → đạo hàm lại để kiểm tra. Đề cho **điều kiện** → tìm $C$. Đề **thực tế** → xác định "đại lượng" và "tốc độ thay đổi của nó", tìm thời điểm cần tính (thường từ $v=0$), rồi quay lại hai ý trên.
