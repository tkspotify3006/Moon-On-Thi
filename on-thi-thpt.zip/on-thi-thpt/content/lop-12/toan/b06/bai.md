---
title: Vectơ trong không gian
thoi-gian: 50 phút
muc-tieu:
  - Nhận biết vectơ trong không gian; hiểu các khái niệm độ dài, giá, hai vectơ cùng phương, cùng hướng, bằng nhau, đối nhau, vectơ-không
  - Thực hiện phép cộng, trừ vectơ trong không gian bằng quy tắc ba điểm, quy tắc hình bình hành và quy tắc hình hộp
  - Thực hiện phép nhân một số với một vectơ; dùng điều kiện cùng phương, hệ thức trung điểm, trọng tâm tam giác, trọng tâm tứ diện
  - Xác định góc giữa hai vectơ trong không gian; tính tích vô hướng trên hình lập phương, hình hộp, tứ diện đều
  - Vận dụng vectơ để giải thích và tính toán trong bài toán thực tế (hợp lực, lực căng dây, công của lực)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Vectơ trong không gian vẫn là **đoạn thẳng có hướng**; mọi khái niệm (cùng phương, cùng hướng, bằng nhau, đối nhau) **giống hệt** trong mặt phẳng.
> 2. Cộng vectơ: quy tắc ba điểm $\overrightarrow{AB}+\overrightarrow{BC}=\overrightarrow{AC}$, hình bình hành, và mới: **quy tắc hình hộp** $\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}=\overrightarrow{AC'}$.
> 3. Trừ vectơ: $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$ ("cùng gốc, cuối trừ đầu").
> 4. $\vec a$ cùng phương $\vec b\ne\vec 0$ $\iff \vec a=k\vec b$. Trọng tâm tứ diện $I$: $\overrightarrow{IA}+\overrightarrow{IB}+\overrightarrow{IC}+\overrightarrow{ID}=\vec 0$.
> 5. Góc giữa hai vectơ: **dời về chung gốc** rồi đo ($0^\circ$ đến $180^\circ$); $\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b)$, $\vec a^2=\lvert\vec a\rvert^2$.

Ở lớp 10, em đã dùng vectơ để biểu diễn lực, vận tốc **trong mặt phẳng**. Nhưng thế giới thật có ba chiều: dây cáp cần cẩu kéo kiện hàng lên cao, máy bay vừa tiến vừa lấy độ cao, bốn sợi dây treo một chiếc đèn chùm… Những đại lượng ấy không nằm gọn trong một mặt phẳng. Tin vui là: **gần như mọi thứ em đã học về vectơ phẳng đều dùng lại được**, chỉ cần thêm một quy tắc mới (quy tắc hình hộp) và cẩn thận hơn khi "dời" vectơ trong không gian. Bài này là nền móng cho cả chương: Bài 7 và Bài 8 sẽ gắn tọa độ cho các vectơ này.

> [!nen-tang] Nhắc lại vectơ trong mặt phẳng (lớp 10)
> - Vectơ $\overrightarrow{AB}$: điểm đầu $A$, điểm cuối $B$; độ dài $\lvert\overrightarrow{AB}\rvert=AB$.
> - Quy tắc ba điểm: $\overrightarrow{AB}+\overrightarrow{BC}=\overrightarrow{AC}$. Quy tắc hình bình hành $ABCD$: $\overrightarrow{AB}+\overrightarrow{AD}=\overrightarrow{AC}$. Quy tắc trừ: $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$.
> - $I$ là trung điểm $AB$ $\iff \overrightarrow{IA}+\overrightarrow{IB}=\vec 0$. $G$ là trọng tâm tam giác $ABC$ $\iff \overrightarrow{GA}+\overrightarrow{GB}+\overrightarrow{GC}=\vec 0$.
> - Tích vô hướng: $\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b)$; $\vec a\perp\vec b\iff\vec a\cdot\vec b=0$.

## 1. Vectơ trong không gian

### 1.1. Khái niệm

Hãy nhìn một kiện hàng được cần cẩu nhấc lên bằng bốn sợi cáp: mỗi sợi kéo theo một hướng xiên khác nhau, và bốn hướng ấy **không cùng nằm trong một mặt phẳng**. Muốn mô tả mỗi lực kéo, ta vẫn vẽ một mũi tên: hướng mũi tên là hướng lực, chiều dài mũi tên là độ lớn lực. Đó chính là vectơ — chỉ khác là bây giờ mũi tên có thể chĩa theo bất kì hướng nào trong không gian.

> [!ghi-nho] Định nghĩa (SGK tr. 46)
> - **Vectơ trong không gian** là một đoạn thẳng có hướng.
> - **Độ dài** của vectơ là khoảng cách giữa điểm đầu và điểm cuối: $\lvert\overrightarrow{AB}\rvert=AB$.
> - Đường thẳng đi qua điểm đầu và điểm cuối gọi là **giá** của vectơ.
> - Kí hiệu như lớp 10: $\overrightarrow{AB}$, hoặc $\vec a,\vec b,\vec x,\dots$ khi không cần chỉ rõ điểm đầu, điểm cuối.

Ví dụ trong đời sống: vận tốc của máy bay đang lấy độ cao, lực gió thổi vào lá cờ, lực căng của dây cáp, độ dịch chuyển của thang máy…

> [!vi-du] Ví dụ 1
> Cho hình hộp chữ nhật $ABCD.A'B'C'D'$ có $AB=3$, $AD=4$, $AA'=12$.
>
> a) Có bao nhiêu vectơ có điểm đầu là $A$ và điểm cuối là một đỉnh khác của hình hộp? Kể ra.
>
> b) Những vectơ nào trong số đó có giá nằm trong mặt phẳng $(ABCD)$?
>
> c) Tính độ dài của các vectơ $\overrightarrow{AC}$, $\overrightarrow{AB'}$ và $\overrightarrow{AC'}$.

> [!goi-y] Gợi ý 1
> Hình hộp có 8 đỉnh; bỏ đỉnh $A$ còn 7 đỉnh làm điểm cuối.

> [!goi-y] Gợi ý 2
> c) Độ dài vectơ = độ dài đoạn thẳng. Các mặt của hình hộp chữ nhật là hình chữ nhật → dùng định lí Pythagore. Với đường chéo $AC'$: tam giác $ACC'$ vuông tại $C$.

> [!loi-giai] Lời giải
> a) Có 7 vectơ: $\overrightarrow{AB}$, $\overrightarrow{AC}$, $\overrightarrow{AD}$, $\overrightarrow{AA'}$, $\overrightarrow{AB'}$, $\overrightarrow{AC'}$, $\overrightarrow{AD'}$.
>
> b) Ba vectơ $\overrightarrow{AB}$, $\overrightarrow{AC}$, $\overrightarrow{AD}$ (điểm cuối nằm trên mặt đáy $ABCD$).
>
> c) $AC=\sqrt{3^2+4^2}=5$; $AB'=\sqrt{3^2+12^2}=\sqrt{153}=3\sqrt{17}$; $AC'=\sqrt{AC^2+CC'^2}=\sqrt{25+144}=13$.
> Vậy $\lvert\overrightarrow{AC}\rvert=5$, $\lvert\overrightarrow{AB'}\rvert=3\sqrt{17}$, $\lvert\overrightarrow{AC'}\rvert=13$.

> [!meo] Đường chéo hình hộp chữ nhật
> Hình hộp chữ nhật kích thước $a, b, c$ có đường chéo dài $\sqrt{a^2+b^2+c^2}$ (Pythagore "hai lần"). Nhớ sẵn vài bộ số đẹp: $(2;3;6)\to7$, $(1;4;8)\to9$, $(3;4;12)\to13$, $(4;4;7)\to9$.

### 1.2. Hai vectơ cùng phương, cùng hướng, bằng nhau

Các định nghĩa **giữ nguyên** như trong mặt phẳng:

> [!ghi-nho] Định nghĩa (SGK tr. 47)
> - Hai vectơ **cùng phương** nếu giá của chúng song song hoặc trùng nhau.
> - Hai vectơ cùng phương thì hoặc **cùng hướng**, hoặc **ngược hướng**.
> - Hai vectơ $\vec a$ và $\vec b$ **bằng nhau** ($\vec a=\vec b$) nếu chúng **cùng độ dài và cùng hướng**.

Điều mới mẻ trong không gian: hai đường thẳng có thể **chéo nhau** (không song song, không cắt nhau). Khi giá của hai vectơ chéo nhau thì hai vectơ **không** cùng phương — dù nhìn trên hình vẽ có thể "trông như song song".

Ngược lại, hai vectơ bằng nhau **không cần** nằm trên cùng một mặt. Trong hình hộp $ABCD.A'B'C'D'$, cạnh $AB$ ở mặt đáy dưới và cạnh $D'C'$ ở mặt đáy trên, nhưng tứ giác $ABC'D'$ là hình bình hành nên $\overrightarrow{AB}=\overrightarrow{D'C'}$.

![Hình 1. Trong hình hộp, bốn cạnh song song cùng hướng cho bốn vectơ bằng nhau; vectơ ngược hướng là vectơ đối](h1-vecto-bang-nhau.svg)

> [!ghi-nho] Chú ý (SGK tr. 47–48)
> - Với mỗi điểm $O$ và vectơ $\vec a$ cho trước, có **duy nhất** điểm $M$ sao cho $\overrightarrow{OM}=\vec a$. (Nhờ vậy ta luôn "dời" được một vectơ về điểm gốc tùy ý.)
> - Hai vectơ cùng bằng vectơ thứ ba thì bằng nhau.
> - **Vectơ-không** $\vec 0$ (ví dụ $\overrightarrow{AA}$, $\overrightarrow{BB}$): độ dài $0$, quy ước cùng hướng (do đó cùng phương) với mọi vectơ.

> [!vi-du] Ví dụ 2
> Cho hình hộp $ABCD.A'B'C'D'$.
>
> a) Trong các vectơ có điểm đầu, điểm cuối là đỉnh của hình hộp, những vectơ nào bằng $\overrightarrow{AA'}$? Những vectơ nào cùng độ dài nhưng ngược hướng với $\overrightarrow{AA'}$?
>
> b) Gọi $M$ là trung điểm của $AB$. Xác định điểm $N$ sao cho $\overrightarrow{MN}=\overrightarrow{AA'}$.

> [!goi-y] Gợi ý 1
> Bốn cạnh bên $AA'$, $BB'$, $CC'$, $DD'$ song song và bằng nhau (các mặt bên là hình bình hành).

> [!goi-y] Gợi ý 2
> b) "Tịnh tiến" đoạn $AB$ theo vectơ $\overrightarrow{AA'}$ ta được đoạn $A'B'$. Trung điểm của $AB$ sẽ đi tới đâu?

> [!loi-giai] Lời giải
> a) Các mặt bên là hình bình hành nên $AA'$, $BB'$, $CC'$, $DD'$ song song, cùng độ dài, cùng hướng "từ đáy dưới lên đáy trên". Vậy $\overrightarrow{AA'}=\overrightarrow{BB'}=\overrightarrow{CC'}=\overrightarrow{DD'}$.
> Các vectơ cùng độ dài, ngược hướng: $\overrightarrow{A'A}$, $\overrightarrow{B'B}$, $\overrightarrow{C'C}$, $\overrightarrow{D'D}$.
>
> b) Gọi $N$ là trung điểm của $A'B'$. Vì $ABB'A'$ là hình bình hành nên $AM$ và $A'N$ song song, cùng hướng, cùng bằng $\frac12AB$; suy ra $AMNA'$ là hình bình hành. Do đó $\overrightarrow{MN}=\overrightarrow{AA'}$. Theo chú ý trên, điểm $N$ là duy nhất: $N$ là **trung điểm của $A'B'$**.

> [!bay]
> - "Cùng phương" **chưa đủ** để bằng nhau: $\overrightarrow{AB}$ và $\overrightarrow{C'D'}$ trong hình hộp cùng phương, cùng độ dài nhưng **ngược hướng** → không bằng nhau (chúng đối nhau).
> - "Cùng độ dài" cũng chưa đủ: trong hình lập phương, $\overrightarrow{AB}$ và $\overrightarrow{A'D'}$ dài bằng nhau nhưng không cùng phương.
> - Đề Đúng/Sai hay cài: "hai vectơ có giá nằm trên hai đường thẳng chéo nhau thì cùng phương" — **Sai**.

> [!ung-dung] Thang máy
> Thang máy đi từ tầng 3 lên tầng 9, rồi từ tầng 9 lên tầng 15 (các tầng cao bằng nhau). Hai vectơ dịch chuyển cùng hướng (thẳng đứng, đi lên) và cùng độ dài (6 tầng) nên **bằng nhau**, dù điểm đầu khác nhau. Còn nếu sau đó thang đi từ tầng 15 xuống tầng 9 thì vectơ dịch chuyển là vectơ **đối**.

## 2. Tổng và hiệu của hai vectơ trong không gian

### 2.1. Tổng hai vectơ — quy tắc ba điểm, quy tắc hình bình hành

Hai vectơ $\vec a$, $\vec b$ bất kì luôn "dời" được về nối đuôi nhau: lấy điểm $A$, dựng $\overrightarrow{AB}=\vec a$ rồi $\overrightarrow{BC}=\vec b$. Ba điểm $A,B,C$ **luôn nằm trong một mặt phẳng**, nên phép cộng hai vectơ thực chất diễn ra trong một mặt phẳng — mọi quy tắc của lớp 10 dùng lại được nguyên vẹn.

> [!ghi-nho] Định nghĩa và quy tắc (SGK tr. 49)
> Lấy điểm $A$ bất kì, dựng $\overrightarrow{AB}=\vec a$, $\overrightarrow{BC}=\vec b$. Khi đó $\vec a+\vec b=\overrightarrow{AC}$. (Kết quả không phụ thuộc cách chọn $A$.)
> - **Quy tắc ba điểm:** với ba điểm $A,B,C$ bất kì, $\overrightarrow{AB}+\overrightarrow{BC}=\overrightarrow{AC}$.
> - **Quy tắc hình bình hành:** nếu $ABCD$ là hình bình hành thì $\overrightarrow{AB}+\overrightarrow{AD}=\overrightarrow{AC}$.
> - **Tính chất:** giao hoán $\vec a+\vec b=\vec b+\vec a$; kết hợp $(\vec a+\vec b)+\vec c=\vec a+(\vec b+\vec c)$; $\vec a+\vec 0=\vec a$. Vì thế ta viết $\vec a+\vec b+\vec c$ không cần ngoặc.

**Bí quyết khi cộng trên hình:** thay một vectơ bằng **vectơ bằng nó** sao cho các vectơ "nối đuôi" nhau (điểm cuối vectơ trước là điểm đầu vectơ sau), rồi dùng quy tắc ba điểm.

> [!vi-du] Ví dụ 3
> Cho hình lập phương $ABCD.A'B'C'D'$ cạnh $2$. Tính độ dài của các vectơ:
>
> a) $\overrightarrow{AB}+\overrightarrow{CC'}$; b) $\overrightarrow{AB}+\overrightarrow{C'D'}$; c) $\overrightarrow{AD}+\overrightarrow{CC'}+\overrightarrow{D'C'}$.

> [!goi-y] Gợi ý 1
> a) $\overrightarrow{CC'}$ bằng vectơ nào xuất phát từ $B$?

> [!goi-y] Gợi ý 2
> b) $\overrightarrow{C'D'}$ quan hệ thế nào với $\overrightarrow{AB}$? c) Thay $\overrightarrow{CC'}=\overrightarrow{DD'}$ để nối đuôi $\overrightarrow{AD}$.

> [!loi-giai] Lời giải
> a) $\overrightarrow{CC'}=\overrightarrow{BB'}$ nên $\overrightarrow{AB}+\overrightarrow{CC'}=\overrightarrow{AB}+\overrightarrow{BB'}=\overrightarrow{AB'}$. Mặt $ABB'A'$ là hình vuông cạnh 2 nên $AB'=2\sqrt2$.
>
> b) $\overrightarrow{C'D'}=\overrightarrow{BA}$ (cùng độ dài, cùng hướng). Do đó $\overrightarrow{AB}+\overrightarrow{C'D'}=\overrightarrow{AB}+\overrightarrow{BA}=\overrightarrow{AA}=\vec 0$; độ dài bằng $0$.
>
> c) $\overrightarrow{AD}+\overrightarrow{DD'}+\overrightarrow{D'C'}=\overrightarrow{AC'}$ (ba điểm nối tiếp). $AC'$ là đường chéo lập phương: $AC'=\sqrt{2^2+2^2+2^2}=2\sqrt3$.

> [!vi-du] Ví dụ 4
> Cho tứ diện $ABCD$. Chứng minh rằng $\overrightarrow{AB}+\overrightarrow{DC}=\overrightarrow{AC}+\overrightarrow{DB}$.

> [!goi-y] Gợi ý 1
> Vế phải có $\overrightarrow{AC}$. Hãy "chèn điểm $C$" vào $\overrightarrow{AB}$: $\overrightarrow{AB}=\overrightarrow{AC}+\overrightarrow{CB}$.

> [!goi-y] Gợi ý 2
> Sau đó gom $\overrightarrow{DC}+\overrightarrow{CB}$ bằng quy tắc ba điểm.

> [!loi-giai] Lời giải
> $\overrightarrow{AB}+\overrightarrow{DC}=(\overrightarrow{AC}+\overrightarrow{CB})+\overrightarrow{DC}=\overrightarrow{AC}+(\overrightarrow{DC}+\overrightarrow{CB})=\overrightarrow{AC}+\overrightarrow{DB}$. ∎

> [!meo] Kĩ thuật "chèn điểm"
> Muốn biến $\overrightarrow{XY}$ thành tổng có chứa điểm $Z$: viết $\overrightarrow{XY}=\overrightarrow{XZ}+\overrightarrow{ZY}$ (chèn $Z$ vào giữa). Đây là động tác chính của mọi bài chứng minh đẳng thức vectơ. Thường ta biến đổi **một vế** (vế phức tạp hơn) cho tới khi ra vế còn lại.

### 2.2. Quy tắc hình hộp

Đây là quy tắc **mới** chỉ có trong không gian, và là "ngôi sao" của bài này trong đề thi.

![Hình 2. Quy tắc hình hộp: tổng ba vectơ cạnh xuất phát từ một đỉnh bằng vectơ đường chéo xuất phát từ đỉnh đó](h2-quy-tac-hinh-hop.svg)

**Vì sao đúng?** Áp dụng quy tắc hình bình hành **hai lần**:
- Đáy $ABCD$ là hình bình hành: $\overrightarrow{AB}+\overrightarrow{AD}=\overrightarrow{AC}$.
- Tứ giác $ACC'A'$ là hình bình hành ($AA'$ và $CC'$ song song, bằng nhau): $\overrightarrow{AC}+\overrightarrow{AA'}=\overrightarrow{AC'}$.

> [!ghi-nho] Quy tắc hình hộp (SGK tr. 50)
> Với hình hộp $ABCD.A'B'C'D'$:
> $$\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}=\overrightarrow{AC'}.$$
> Phát biểu bằng lời: **ba vectơ cạnh cùng xuất phát từ một đỉnh cộng lại bằng vectơ đường chéo của hình hộp xuất phát từ đỉnh đó.** Quy tắc đúng với **mọi** đỉnh, ví dụ từ đỉnh $B$: $\overrightarrow{BA}+\overrightarrow{BC}+\overrightarrow{BB'}=\overrightarrow{BD'}$.

> [!vi-du] Ví dụ 5
> a) Cho hình hộp chữ nhật $ABCD.A'B'C'D'$ có $AB=2$, $AD=3$, $AA'=6$. Tính $\lvert\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}\rvert$.
>
> b) Cho hình hộp $ABCD.A'B'C'D'$. Rút gọn $\overrightarrow{DA}+\overrightarrow{DC}+\overrightarrow{DD'}$.
>
> c) Với hình hộp ở câu b, chứng minh $\overrightarrow{AB}+\overrightarrow{B'C'}+\overrightarrow{DD'}=\overrightarrow{AC'}$.

> [!goi-y] Gợi ý 1
> a), b): ba vectơ cạnh cùng gốc → đường chéo cùng gốc. Ở b), đỉnh nào đối diện với $D$ qua tâm hình hộp?

> [!goi-y] Gợi ý 2
> c) Ba vectơ chưa cùng gốc. Thay $\overrightarrow{B'C'}$ và $\overrightarrow{DD'}$ bằng các vectơ bằng chúng xuất phát từ $A$.

> [!loi-giai] Lời giải
> a) Theo quy tắc hình hộp, tổng bằng $\overrightarrow{AC'}$, nên độ dài là $AC'=\sqrt{2^2+3^2+6^2}=\sqrt{49}=7$.
>
> b) Ba cạnh $DA$, $DC$, $DD'$ cùng xuất phát từ $D$; đỉnh đối diện với $D$ là $B'$. Vậy $\overrightarrow{DA}+\overrightarrow{DC}+\overrightarrow{DD'}=\overrightarrow{DB'}$.
>
> c) $\overrightarrow{B'C'}=\overrightarrow{BC}=\overrightarrow{AD}$ và $\overrightarrow{DD'}=\overrightarrow{AA'}$. Do đó vế trái $=\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}=\overrightarrow{AC'}$. ∎

> [!bay] Đường chéo nào?
> Hình hộp có 4 đường chéo $AC'$, $BD'$, $CA'$, $DB'$. Quy tắc cho đường chéo **xuất phát từ chính đỉnh chung** của ba cạnh, đi tới đỉnh **đối diện** (khác đáy, khác mặt bên). Đề thường đặt nhiễu $\overrightarrow{A'C}$ (ngược chiều) hoặc $\overrightarrow{AC}$ (đường chéo mặt đáy — quên cộng $\overrightarrow{AA'}$).

> [!ung-dung] Hợp lực của ba lực vuông góc
> Ba lực $\vec F_1$, $\vec F_2$, $\vec F_3$ cùng đặt tại một điểm, đôi một vuông góc, có thể xem là ba cạnh của một **hình hộp chữ nhật**. Hợp lực $\vec F_1+\vec F_2+\vec F_3$ là đường chéo, có độ lớn $\sqrt{F_1^2+F_2^2+F_3^2}$. Ví dụ ba lực $2$ N, $3$ N, $6$ N đôi một vuông góc có hợp lực $7$ N.

### 2.3. Vectơ đối và hiệu hai vectơ

> [!ghi-nho] Định nghĩa (SGK tr. 51)
> - **Vectơ đối** của $\vec a$, kí hiệu $-\vec a$: cùng độ dài, ngược hướng với $\vec a$. Ta có $\overrightarrow{BA}=-\overrightarrow{AB}$; $\vec 0$ là vectơ đối của chính nó; hai vectơ đối nhau $\iff$ tổng của chúng bằng $\vec 0$.
> - **Hiệu** $\vec a-\vec b=\vec a+(-\vec b)$.
> - **Quy tắc trừ:** với ba điểm $O,A,B$ bất kì, $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$.

Cách nhớ quy tắc trừ: hai vectơ **cùng gốc** $O$ trừ nhau, gốc "biến mất", còn lại vectơ đi **từ ngọn của vectơ bị trừ tới ngọn của vectơ trừ** — "cuối trừ đầu" giống như tọa độ $\overrightarrow{AB}=B-A$ mà em sẽ gặp ở Bài 7.

> [!vi-du] Ví dụ 6
> Cho hình hộp $ABCD.A'B'C'D'$. Rút gọn:
>
> a) $\overrightarrow{AC'}-\overrightarrow{AD}$; b) $\overrightarrow{AB}-\overrightarrow{C'D'}$; c) $\overrightarrow{AC'}-\overrightarrow{AC}$.

> [!goi-y] Gợi ý 1
> a), c): hai vectơ cùng gốc $A$ → quy tắc trừ.

> [!goi-y] Gợi ý 2
> b) Hai vectơ không cùng gốc. Trừ một vectơ là cộng vectơ đối: $-\overrightarrow{C'D'}=\overrightarrow{D'C'}=\overrightarrow{AB}$.

> [!loi-giai] Lời giải
> a) $\overrightarrow{AC'}-\overrightarrow{AD}=\overrightarrow{DC'}$.
>
> b) $\overrightarrow{AB}-\overrightarrow{C'D'}=\overrightarrow{AB}+\overrightarrow{D'C'}=\overrightarrow{AB}+\overrightarrow{AB}=2\overrightarrow{AB}$.
>
> c) $\overrightarrow{AC'}-\overrightarrow{AC}=\overrightarrow{CC'}$, và $\overrightarrow{CC'}=\overrightarrow{AA'}=\overrightarrow{BB'}$.

> [!bay]
> - $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$, **không phải** $\overrightarrow{BA}$. Đổi thứ tự trừ là đổi hướng kết quả.
> - Ở câu b), nhiều bạn thấy "$\overrightarrow{AB}$ và $\overrightarrow{C'D'}$ dài bằng nhau" rồi kết luận hiệu bằng $\vec 0$. Sai vì chúng **ngược hướng**: hiệu của hai vectơ đối nhau là $2\overrightarrow{AB}$, còn **tổng** mới bằng $\vec 0$.

> [!ung-dung] Lực và phản lực
> Một lọ hoa đặt trên bàn ép xuống mặt bàn một lực $\vec F$; mặt bàn đẩy lại lọ hoa một phản lực $\vec F'$. Theo định luật III Newton, $\vec F'=-\vec F$: hai vectơ cùng độ dài, ngược hướng. Tương tự, thang cuốn có hai làn (một lên, một xuống): nếu hai làn **song song** và chạy **cùng tốc độ** thì hai vectơ vận tốc cùng độ dài, ngược hướng, tức là hai vectơ **đối nhau**. Nếu hai làn không song song (chẳng hạn đặt chéo kiểu chữ V) hoặc chạy khác tốc độ thì chúng **không** đối nhau.

## 3. Tích của một số với một vectơ trong không gian

### 3.1. Định nghĩa và tính chất

Định nghĩa giống hệt lớp 10: nhân vectơ với số $k$ là **"co giãn"** vectơ $\lvert k\rvert$ lần, và **lật ngược hướng** nếu $k<0$.

> [!ghi-nho] Định nghĩa (SGK tr. 53)
> Với $k\ne0$ và $\vec a\ne\vec 0$, $k\vec a$ là vectơ:
> - cùng hướng với $\vec a$ nếu $k>0$, ngược hướng với $\vec a$ nếu $k<0$;
> - có độ dài $\lvert k\rvert\cdot\lvert\vec a\rvert$.
>
> Quy ước $0\vec a=\vec 0$, $k\vec 0=\vec 0$. Tính chất: $h(k\vec a)=(hk)\vec a$; $(h+k)\vec a=h\vec a+k\vec a$; $k(\vec a+\vec b)=k\vec a+k\vec b$; $1\vec a=\vec a$; $(-1)\vec a=-\vec a$.

> [!ghi-nho] Điều kiện cùng phương
> Hai vectơ $\vec a$ và $\vec b$ ($\vec b\ne\vec 0$) cùng phương $\iff$ có số thực $k$ sao cho $\vec a=k\vec b$.
> Hệ quả: ba điểm phân biệt $A,B,C$ **thẳng hàng** $\iff \overrightarrow{AC}=k\overrightarrow{AB}$ với số $k$ nào đó.

### 3.2. Trung điểm, trọng tâm tam giác, trọng tâm tứ diện

Các hệ thức sau quen thuộc từ lớp 10 và **vẫn đúng** trong không gian (với $O$ là điểm **bất kì**, không cần nằm trong mặt phẳng tam giác):

> [!ghi-nho] Hệ thức trung điểm và trọng tâm (SGK tr. 54)
> - $I$ là trung điểm $AB$: $\overrightarrow{IA}+\overrightarrow{IB}=\vec 0$ và $\overrightarrow{OA}+\overrightarrow{OB}=2\overrightarrow{OI}$.
> - $G$ là trọng tâm tam giác $ABC$: $\overrightarrow{GA}+\overrightarrow{GB}+\overrightarrow{GC}=\vec 0$ và $\overrightarrow{OA}+\overrightarrow{OB}+\overrightarrow{OC}=3\overrightarrow{OG}$.

Bây giờ áp dụng cho **tứ diện**. Gọi $G$ là trọng tâm tam giác $BCD$. Lấy $O\equiv A$ trong hệ thức trọng tâm:
$$\overrightarrow{AB}+\overrightarrow{AC}+\overrightarrow{AD}=3\overrightarrow{AG}.$$

**Trọng tâm tứ diện.** Điểm $I$ thỏa $\overrightarrow{IA}+\overrightarrow{IB}+\overrightarrow{IC}+\overrightarrow{ID}=\vec 0$ gọi là **trọng tâm** của tứ diện $ABCD$. Nó nằm ở đâu? Lấy $O\equiv I$: $\overrightarrow{IB}+\overrightarrow{IC}+\overrightarrow{ID}=3\overrightarrow{IG}$, nên điều kiện trở thành
$$\overrightarrow{IA}+3\overrightarrow{IG}=\vec 0\iff\overrightarrow{AI}=3\overrightarrow{IG}\iff\overrightarrow{AI}=\tfrac34\overrightarrow{AG}.$$
Vậy $I$ nằm trên đoạn $AG$ (nối đỉnh với trọng tâm mặt đối diện), **cách đỉnh $\frac34$ và cách mặt $\frac14$** độ dài $AG$.

![Hình 3. G là trọng tâm tam giác BCD; trọng tâm I của tứ diện nằm trên AG với AI = 3/4 AG](h3-trong-tam-tu-dien.svg)

> [!vi-du] Ví dụ 7
> Cho tứ diện $ABCD$. Gọi $M$, $N$ lần lượt là trung điểm của $AD$ và $BC$. Chứng minh rằng $\overrightarrow{AB}+\overrightarrow{DC}=2\overrightarrow{MN}$.

> [!goi-y] Gợi ý 1
> Đi từ $M$ tới $N$ bằng **hai đường**: qua $A$, $B$ và qua $D$, $C$. Viết $\overrightarrow{MN}$ theo hai cách bằng kĩ thuật chèn điểm.

> [!goi-y] Gợi ý 2
> Cộng hai đẳng thức. Vì $M$, $N$ là trung điểm nên $\overrightarrow{MA}+\overrightarrow{MD}=\vec 0$ và $\overrightarrow{BN}+\overrightarrow{CN}=\vec 0$.

> [!loi-giai] Lời giải
> $\overrightarrow{MN}=\overrightarrow{MA}+\overrightarrow{AB}+\overrightarrow{BN}$ và $\overrightarrow{MN}=\overrightarrow{MD}+\overrightarrow{DC}+\overrightarrow{CN}$.
> Cộng vế theo vế: $2\overrightarrow{MN}=(\overrightarrow{MA}+\overrightarrow{MD})+(\overrightarrow{AB}+\overrightarrow{DC})+(\overrightarrow{BN}+\overrightarrow{CN})=\vec 0+(\overrightarrow{AB}+\overrightarrow{DC})+\vec 0$.
> Vậy $\overrightarrow{AB}+\overrightarrow{DC}=2\overrightarrow{MN}$. ∎

> [!meo]
> Kết quả "**vectơ nối hai trung điểm = nửa tổng hai vectơ hai đầu**" rất hay dùng: với $M$, $N$ là trung điểm $AB$, $CD$ thì $\overrightarrow{MN}=\frac12(\overrightarrow{AC}+\overrightarrow{BD})=\frac12(\overrightarrow{AD}+\overrightarrow{BC})$. Mẹo nhớ: các vectơ đều đi **từ phía $M$ sang phía $N$** (từ $A$ hoặc $B$ tới $C$ hoặc $D$).

> [!vi-du] Ví dụ 8
> Một khối đồ chơi hình tứ diện đều $ABCD$ có cạnh $6$ cm, đồng chất (trọng tâm vật lí trùng trọng tâm $I$ của tứ diện). Gọi $G$ là trọng tâm tam giác $BCD$.
>
> a) Tính chiều cao $AG$ của tứ diện.
>
> b) Tính khoảng cách từ $I$ đến mặt $(BCD)$ và từ $I$ đến đỉnh $A$ (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Tứ diện đều thì chân đường cao từ $A$ là trọng tâm $G$ của tam giác đều $BCD$, và $BG=\frac23$ đường trung tuyến $=\frac{6}{\sqrt3}=2\sqrt3$.

> [!goi-y] Gợi ý 2
> Dùng $\overrightarrow{AI}=\frac34\overrightarrow{AG}$: $AI=\frac34AG$, $IG=\frac14AG$; vì $AG\perp(BCD)$ nên $IG$ là khoảng cách từ $I$ đến mặt.

> [!loi-giai] Lời giải
> a) Tam giác $ABG$ vuông tại $G$: $AG=\sqrt{AB^2-BG^2}=\sqrt{36-12}=\sqrt{24}=2\sqrt6\approx4{,}90$ cm.
>
> b) Khoảng cách từ $I$ đến mặt $(BCD)$: $IG=\frac14\cdot2\sqrt6=\frac{\sqrt6}{2}\approx1{,}22$ cm.
> Khoảng cách từ $I$ đến đỉnh $A$: $AI=\frac34\cdot2\sqrt6=\frac{3\sqrt6}{2}\approx3{,}67$ cm.

> [!ung-dung] Lực cản không khí
> Lực cản của không khí lên một ô tô ngược hướng chuyển động và có độ lớn tỉ lệ với **bình phương** vận tốc. Khi xe tăng tốc từ $60$ km/h lên $90$ km/h mà giữ nguyên hướng, lực cản $\vec F_1$ (lúc $60$ km/h) và $\vec F_2$ (lúc $90$ km/h) **cùng hướng**, nên $\vec F_1=k\vec F_2$ với $k>0$ và $k=\left(\frac{60}{90}\right)^2=\frac49\approx0{,}44$.

## 4. Tích vô hướng của hai vectơ trong không gian

### 4.1. Góc giữa hai vectơ

Trong không gian, hai vectơ có thể nằm trên hai đường thẳng chéo nhau — không có "đỉnh chung" để đo góc. Cách giải quyết: **dời cả hai về chung một gốc**.

> [!ghi-nho] Định nghĩa (SGK tr. 55)
> Cho $\vec a,\vec b\ne\vec 0$. Lấy điểm $O$ bất kì, dựng $\overrightarrow{OA}=\vec a$, $\overrightarrow{OB}=\vec b$. Góc $\widehat{AOB}$ (từ $0^\circ$ đến $180^\circ$) gọi là **góc giữa hai vectơ**, kí hiệu $(\vec a,\vec b)$. Nếu góc bằng $90^\circ$ thì $\vec a\perp\vec b$.
> - Cùng hướng: góc $0^\circ$. Ngược hướng: góc $180^\circ$.
> - Để tìm $(\overrightarrow{AB},\overrightarrow{CD})$: lấy $E$ sao cho $\overrightarrow{AE}=\overrightarrow{CD}$, khi đó $(\overrightarrow{AB},\overrightarrow{CD})=\widehat{BAE}$.

**Vì sao góc không phụ thuộc điểm $O$?** Dời sang gốc $O'$ khác, ta được tam giác $O'A'B'$ có ba cạnh lần lượt bằng ba cạnh của tam giác $OAB$ ($O'A'=OA$, $O'B'=OB$, và $\overrightarrow{A'B'}=\overrightarrow{AB}$ vì cùng bằng $\vec b-\vec a$). Hai tam giác bằng nhau nên góc ở đỉnh bằng nhau.

> [!vi-du] Ví dụ 9
> Cho hình lập phương $ABCD.A'B'C'D'$. Tính góc giữa các cặp vectơ:
>
> a) $\overrightarrow{AB}$ và $\overrightarrow{C'D'}$; b) $\overrightarrow{AB'}$ và $\overrightarrow{A'C'}$; c) $\overrightarrow{AC}$ và $\overrightarrow{B'D'}$.

> [!goi-y] Gợi ý 1
> Thay vectơ thứ hai bằng vectơ bằng nó, có gốc trùng gốc vectơ thứ nhất: $\overrightarrow{A'C'}=\overrightarrow{AC}$; $\overrightarrow{B'D'}=\overrightarrow{BD}$.

> [!goi-y] Gợi ý 2
> b) Tam giác $AB'C$ có ba cạnh là ba đường chéo của ba mặt hình vuông. c) Hai đường chéo của hình vuông $ABCD$ vuông góc.

> [!loi-giai] Lời giải
> a) $\overrightarrow{C'D'}=\overrightarrow{BA}$ ngược hướng với $\overrightarrow{AB}$, nên $(\overrightarrow{AB},\overrightarrow{C'D'})=180^\circ$.
>
> b) $\overrightarrow{A'C'}=\overrightarrow{AC}$, nên góc cần tìm là $\widehat{B'AC}$. Tam giác $AB'C$ có $AB'=B'C=CA$ (đều là đường chéo mặt) nên là tam giác đều: $(\overrightarrow{AB'},\overrightarrow{A'C'})=60^\circ$.
>
> c) $\overrightarrow{B'D'}=\overrightarrow{BD}$ và $AC\perp BD$, nên $(\overrightarrow{AC},\overrightarrow{B'D'})=90^\circ$.

> [!bay]
> - Phải dời về **chung gốc** (cả hai vectơ cùng **đi ra** từ một điểm). Nếu một vectơ đi vào, một vectơ đi ra khỏi đỉnh thì góc đo được là góc **bù**. Ví dụ trong tam giác đều $ABC$: $(\overrightarrow{AB},\overrightarrow{BC})=120^\circ$, **không phải** $60^\circ$.
> - Góc giữa hai **vectơ** có thể tù hoặc bằng $180^\circ$; còn góc giữa hai **đường thẳng** (đã học ở lớp 11) luôn từ $0^\circ$ đến $90^\circ$.

### 4.2. Tích vô hướng

> [!ghi-nho] Định nghĩa (SGK tr. 56)
> Với $\vec a,\vec b\ne\vec 0$: $$\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b).$$
> Quy ước: nếu $\vec a=\vec 0$ hoặc $\vec b=\vec 0$ thì $\vec a\cdot\vec b=0$.
> - $\vec a\perp\vec b\iff\vec a\cdot\vec b=0$ (với $\vec a,\vec b\ne\vec0$).
> - $\vec a^2=\vec a\cdot\vec a=\lvert\vec a\rvert^2$.
> - $\cos(\vec a,\vec b)=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$.
>
> Tính chất: $\vec a\cdot\vec b=\vec b\cdot\vec a$; $k(\vec a\cdot\vec b)=(k\vec a)\cdot\vec b$; $\vec a\cdot(\vec b+\vec c)=\vec a\cdot\vec b+\vec a\cdot\vec c$.

Nhờ các tính chất này, **nhân tích vô hướng giống như nhân đa thức**: $(\vec a+\vec b)^2=\vec a^2+2\vec a\cdot\vec b+\vec b^2$, $(\vec a+\vec b)\cdot(\vec a-\vec b)=\vec a^2-\vec b^2$…

Có **hai cách** tính tích vô hướng trên một hình:
1. **Dùng định nghĩa:** dời về chung gốc, tìm góc, nhân $\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos$.
2. **Phân tích qua các vectơ "gốc":** biểu diễn mọi vectơ qua vài vectơ đã biết độ dài và góc với nhau (ví dụ ba cạnh từ một đỉnh), rồi khai triển như đa thức.

> [!vi-du] Ví dụ 10
> Cho tứ diện đều $ABCD$ cạnh $a$. Tính $\overrightarrow{AB}\cdot\overrightarrow{AC}$, $\overrightarrow{AB}\cdot\overrightarrow{BC}$ và $\overrightarrow{AB}\cdot\overrightarrow{CD}$. Từ đó rút ra quan hệ giữa hai cạnh đối $AB$ và $CD$.

> [!goi-y] Gợi ý 1
> Mọi mặt là tam giác đều. $\overrightarrow{AB}$, $\overrightarrow{AC}$ chung gốc $A$, góc $60^\circ$. Còn $\overrightarrow{AB}$, $\overrightarrow{BC}$ thì **không** chung gốc.

> [!goi-y] Gợi ý 2
> Với $\overrightarrow{CD}$: chèn điểm $A$, $\overrightarrow{CD}=\overrightarrow{AD}-\overrightarrow{AC}$.

> [!loi-giai] Lời giải
> - $\overrightarrow{AB}\cdot\overrightarrow{AC}=a\cdot a\cdot\cos60^\circ=\dfrac{a^2}{2}$.
> - $(\overrightarrow{AB},\overrightarrow{BC})=180^\circ-60^\circ=120^\circ$ nên $\overrightarrow{AB}\cdot\overrightarrow{BC}=a^2\cos120^\circ=-\dfrac{a^2}{2}$.
> - $\overrightarrow{AB}\cdot\overrightarrow{CD}=\overrightarrow{AB}\cdot(\overrightarrow{AD}-\overrightarrow{AC})=\overrightarrow{AB}\cdot\overrightarrow{AD}-\overrightarrow{AB}\cdot\overrightarrow{AC}=\dfrac{a^2}{2}-\dfrac{a^2}{2}=0$.
>
> Vậy $AB\perp CD$: **trong tứ diện đều, hai cạnh đối diện vuông góc với nhau.**

> [!vi-du] Ví dụ 11
> Cho hình lập phương $ABCD.A'B'C'D'$ cạnh $a$. Đặt $\vec x=\overrightarrow{AB}$, $\vec y=\overrightarrow{AD}$, $\vec z=\overrightarrow{AA'}$.
>
> a) Biểu diễn $\overrightarrow{AC'}$ và $\overrightarrow{BD}$ qua $\vec x,\vec y,\vec z$.
>
> b) Tính $AC'$ bằng tích vô hướng và chứng minh $AC'\perp BD$.

> [!goi-y] Gợi ý 1
> $\vec x,\vec y,\vec z$ có độ dài $a$ và **đôi một vuông góc**: $\vec x\cdot\vec y=\vec y\cdot\vec z=\vec z\cdot\vec x=0$, $\vec x^2=\vec y^2=\vec z^2=a^2$.

> [!goi-y] Gợi ý 2
> $\overrightarrow{AC'}$: quy tắc hình hộp. $\overrightarrow{BD}$: quy tắc trừ $\overrightarrow{AD}-\overrightarrow{AB}$.

> [!loi-giai] Lời giải
> a) $\overrightarrow{AC'}=\vec x+\vec y+\vec z$; $\ \overrightarrow{BD}=\vec y-\vec x$.
>
> b) $AC'^2=(\vec x+\vec y+\vec z)^2=\vec x^2+\vec y^2+\vec z^2+2(\vec x\cdot\vec y+\vec y\cdot\vec z+\vec z\cdot\vec x)=3a^2$, nên $AC'=a\sqrt3$.
> $\overrightarrow{AC'}\cdot\overrightarrow{BD}=(\vec x+\vec y+\vec z)\cdot(\vec y-\vec x)=\vec y^2-\vec x^2+(\text{các tích chéo bằng }0)=a^2-a^2=0$. Vậy $AC'\perp BD$. ∎

> [!meo] Kiểm tra bằng tọa độ
> Với hình lập phương, hình hộp chữ nhật, em có thể đặt $A$ ở gốc tọa độ và ba cạnh $AB$, $AD$, $AA'$ dọc ba trục (sẽ học ở Bài 7, 8): ví dụ lập phương cạnh $1$ có $\overrightarrow{AC'}=(1;1;1)$, $\overrightarrow{BD}=(-1;1;0)$, tích vô hướng $-1+1+0=0$ ✓. Đây là cách **soát lại** rất nhanh cho câu Đúng/Sai.

> [!vi-du] Ví dụ 12
> Cho hai vectơ $\vec a$, $\vec b$ với $\lvert\vec a\rvert=2$, $\lvert\vec b\rvert=3$ và $(\vec a,\vec b)=60^\circ$. Tính $\vec a\cdot\vec b$, $(\vec a+2\vec b)\cdot(\vec a-\vec b)$, $\lvert\vec a+\vec b\rvert$ và $\lvert2\vec a-\vec b\rvert$.

> [!goi-y] Gợi ý 1
> Khai triển như đa thức; thay $\vec a^2=4$, $\vec b^2=9$.

> [!goi-y] Gợi ý 2
> Muốn tính độ dài, **bình phương** trước: $\lvert\vec u\rvert^2=\vec u^2$, rồi lấy căn.

> [!loi-giai] Lời giải
> - $\vec a\cdot\vec b=2\cdot3\cdot\cos60^\circ=3$.
> - $(\vec a+2\vec b)\cdot(\vec a-\vec b)=\vec a^2-\vec a\cdot\vec b+2\vec a\cdot\vec b-2\vec b^2=4+3-18=-11$.
> - $\lvert\vec a+\vec b\rvert^2=\vec a^2+2\vec a\cdot\vec b+\vec b^2=4+6+9=19\Rightarrow\lvert\vec a+\vec b\rvert=\sqrt{19}$.
> - $\lvert2\vec a-\vec b\rvert^2=4\vec a^2-4\vec a\cdot\vec b+\vec b^2=16-12+9=13\Rightarrow\lvert2\vec a-\vec b\rvert=\sqrt{13}$.

> [!bay]
> $\lvert\vec a+\vec b\rvert\ne\lvert\vec a\rvert+\lvert\vec b\rvert$ (trừ khi cùng hướng). Ở trên, $\lvert\vec a+\vec b\rvert=\sqrt{19}\approx4{,}36$ chứ không phải $5$. Đề trắc nghiệm luôn có phương án nhiễu $5$!

> [!ung-dung] Công của một lực (SGK tr. 57)
> Lực $\vec F$ làm vật dời theo vectơ $\overrightarrow{MN}$ thì công $A=\vec F\cdot\overrightarrow{MN}=F\cdot MN\cdot\cos\alpha$ (J). Kéo một chiếc xe trượt bằng sợi dây với lực $50$ N, dây hợp với mặt đường góc $30^\circ$, xe đi được $20$ m: $A=50\cdot20\cdot\cos30^\circ=500\sqrt3\approx866$ J. Vì $\cos\alpha$ lớn nhất ($=1$) khi $\alpha=0^\circ$, công lớn nhất khi **kéo cùng hướng chuyển động** — đó là lí do khi kéo vật nặng nên để dây càng gần song song với mặt đường càng đỡ tốn sức.

## Dạng bài thi hay gặp

### Dạng 1. Đúng/Sai về đẳng thức vectơ trên hình hộp, hình lập phương

- **Nhận biết:** cho hình hộp/lập phương/lăng trụ, hỏi vectơ nào bằng nhau, tổng/hiệu bằng gì.
- **Phương pháp:** (1) thay vectơ bằng vectơ bằng nó để **nối đuôi** hoặc **chung gốc**; (2) dùng quy tắc ba điểm, hình bình hành, hình hộp, quy tắc trừ; (3) kiểm điểm đầu – điểm cuối của kết quả.
- **Bẫy:** nhầm hướng (đường chéo $AC'$ với $A'C$); nhầm "cùng độ dài" với "bằng nhau"; quy tắc trừ viết ngược.

> [!vi-du] Ví dụ 13 (Đúng/Sai)
> Cho hình hộp $ABCD.A'B'C'D'$. Xét các mệnh đề:
>
> a) $\overrightarrow{AD}=\overrightarrow{B'C'}$.
>
> b) $\overrightarrow{AB}+\overrightarrow{AA'}=\overrightarrow{AB'}$.
>
> c) $\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{CC'}=\overrightarrow{A'C}$.
>
> d) $\overrightarrow{AB}-\overrightarrow{AD}=\overrightarrow{BD}$.

> [!goi-y] Gợi ý 1
> b) Mặt $ABB'A'$ là hình bình hành. c) $\overrightarrow{CC'}=\overrightarrow{AA'}$.

> [!goi-y] Gợi ý 2
> d) Hai vectơ cùng gốc $A$: $\overrightarrow{AB}-\overrightarrow{AD}$ là vectơ đi từ $D$ tới $B$ hay từ $B$ tới $D$?

> [!loi-giai] Lời giải
> a) **Đúng** — $ADC'B'$ là hình bình hành ($AD$ và $B'C'$ song song, bằng nhau, cùng hướng).
>
> b) **Đúng** — quy tắc hình bình hành trong mặt $ABB'A'$.
>
> c) **Sai** — vì $\overrightarrow{CC'}=\overrightarrow{AA'}$ nên vế trái $=\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}=\overrightarrow{AC'}$ (quy tắc hình hộp). Còn $\overrightarrow{A'C}$ nằm trên một đường chéo **khác** của hình hộp (đi từ $A'$ xuống $C$), không cùng phương với $\overrightarrow{AC'}$.
>
> d) **Sai** — $\overrightarrow{AB}-\overrightarrow{AD}=\overrightarrow{DB}$, là vectơ đối của $\overrightarrow{BD}$.

### Dạng 2. Tính tích vô hướng, góc trên hình lập phương, tứ diện đều

- **Nhận biết:** "Tính $\overrightarrow{AM}\cdot\overrightarrow{AB}$", "góc giữa hai vectơ…" trên hình có các cạnh đã biết độ dài và góc.
- **Phương pháp:**
  1. Nếu dời được về chung gốc và thấy ngay góc (tam giác đều, vuông cân…) → dùng định nghĩa.
  2. Nếu không → chọn **ba vectơ gốc** (ba cạnh từ một đỉnh), lập "bảng nhân" của chúng (bình phương và tích từng cặp), biểu diễn các vectơ cần tính qua chúng rồi khai triển.
  3. Góc: $\cos=\dfrac{\vec u\cdot\vec v}{\lvert\vec u\rvert\cdot\lvert\vec v\rvert}$.
- **Bẫy:** quên rằng góc giữa $\overrightarrow{AB}$ và $\overrightarrow{BC}$ là góc **ngoài** ($120^\circ$ trong tam giác đều); quên chia 2 khi dùng trung điểm.

> [!vi-du] Ví dụ 14
> Cho tứ diện đều $ABCD$ cạnh $2$, $M$ là trung điểm $CD$. Tính $\overrightarrow{AM}\cdot\overrightarrow{CD}$, $\overrightarrow{AM}\cdot\overrightarrow{AB}$ và góc giữa hai vectơ $\overrightarrow{AM}$, $\overrightarrow{AB}$ (làm tròn đến hàng phần mười của độ).

> [!goi-y] Gợi ý 1
> Vectơ gốc: $\overrightarrow{AB},\overrightarrow{AC},\overrightarrow{AD}$, mỗi vectơ có bình phương bằng $4$, tích từng cặp bằng $2\cdot2\cdot\cos60^\circ=2$.

> [!goi-y] Gợi ý 2
> $\overrightarrow{AM}=\frac12(\overrightarrow{AC}+\overrightarrow{AD})$; $\overrightarrow{CD}=\overrightarrow{AD}-\overrightarrow{AC}$; $AM$ là đường cao tam giác đều cạnh 2 nên $AM=\sqrt3$.

> [!loi-giai] Lời giải
> - $\overrightarrow{AM}\cdot\overrightarrow{CD}=\frac12(\overrightarrow{AC}+\overrightarrow{AD})\cdot(\overrightarrow{AD}-\overrightarrow{AC})=\frac12(\overrightarrow{AD}^2-\overrightarrow{AC}^2)=\frac12(4-4)=0$ (đúng với trực giác: trung tuyến của tam giác đều $ACD$ vuông góc với cạnh $CD$).
> - $\overrightarrow{AM}\cdot\overrightarrow{AB}=\frac12(\overrightarrow{AC}\cdot\overrightarrow{AB}+\overrightarrow{AD}\cdot\overrightarrow{AB})=\frac12(2+2)=2$.
> - $\cos(\overrightarrow{AM},\overrightarrow{AB})=\dfrac{2}{\sqrt3\cdot2}=\dfrac{1}{\sqrt3}\approx0{,}5774$, suy ra góc $\approx54{,}7^\circ$.

### Dạng 3. Biểu diễn vectơ qua ba vectơ cho trước — chứng minh thẳng hàng

- **Nhận biết:** "Đặt $\overrightarrow{AB}=\vec a$, $\overrightarrow{AD}=\vec b$, $\overrightarrow{AA'}=\vec c$. Biểu diễn $\overrightarrow{BD'}$…", "chứng minh ba điểm thẳng hàng".
- **Phương pháp:** đi từ điểm đầu đến điểm cuối **dọc theo các cạnh** (chèn điểm), mỗi bước thay bằng $\pm\vec a,\pm\vec b,\pm\vec c$. Để chứng minh $A,G,C'$ thẳng hàng: biểu diễn $\overrightarrow{AG}$ và $\overrightarrow{AC'}$ rồi chỉ ra $\overrightarrow{AG}=k\overrightarrow{AC'}$.
- **Bẫy:** đi ngược cạnh thì phải đổi dấu ($\overrightarrow{BA}=-\vec a$).

> [!vi-du] Ví dụ 15
> Cho hình hộp $ABCD.A'B'C'D'$, đặt $\overrightarrow{AB}=\vec a$, $\overrightarrow{AD}=\vec b$, $\overrightarrow{AA'}=\vec c$. Gọi $G$ là trọng tâm tam giác $A'BD$.
>
> a) Biểu diễn $\overrightarrow{BD'}$ và $\overrightarrow{AG}$ qua $\vec a,\vec b,\vec c$.
>
> b) Chứng minh $A$, $G$, $C'$ thẳng hàng và tính tỉ số $\dfrac{AG}{AC'}$.

> [!goi-y] Gợi ý 1
> $\overrightarrow{BD'}=\overrightarrow{BA}+\overrightarrow{AD}+\overrightarrow{DD'}$. Với trọng tâm $G$ của tam giác $A'BD$, dùng hệ thức với điểm $O\equiv A$.

> [!goi-y] Gợi ý 2
> $\overrightarrow{AA'}+\overrightarrow{AB}+\overrightarrow{AD}=3\overrightarrow{AG}$, mà vế trái chính là $\overrightarrow{AC'}$ theo quy tắc hình hộp.

> [!loi-giai] Lời giải
> a) $\overrightarrow{BD'}=\overrightarrow{BA}+\overrightarrow{AD}+\overrightarrow{DD'}=-\vec a+\vec b+\vec c$.
> $3\overrightarrow{AG}=\overrightarrow{AA'}+\overrightarrow{AB}+\overrightarrow{AD}=\vec a+\vec b+\vec c$, nên $\overrightarrow{AG}=\frac13(\vec a+\vec b+\vec c)$.
>
> b) Theo quy tắc hình hộp $\overrightarrow{AC'}=\vec a+\vec b+\vec c$, do đó $\overrightarrow{AG}=\frac13\overrightarrow{AC'}$: $A,G,C'$ thẳng hàng và $\dfrac{AG}{AC'}=\dfrac13$.

### Dạng 4. Bài toán thực tế: hợp lực, đèn treo, dây cáp

- **Nhận biết:** vật nặng treo bằng nhiều dây (đèn chùm, kiện hàng cần cẩu), nhiều lực cùng tác dụng vào một điểm, công của lực.
- **Phương pháp:**
  1. Vật **đứng yên** $\Rightarrow$ tổng các lực bằng $\vec 0$: tổng lực căng dây $=-\vec P$ (hướng lên, độ lớn bằng trọng lượng).
  2. Các dây **đối xứng** thì lực căng có độ lớn bằng nhau; thành phần nằm ngang triệt tiêu nhau, chỉ còn thành phần thẳng đứng $T\cos\alpha$ ($\alpha$ là góc giữa dây và phương thẳng đứng).
  3. Ba lực đôi một vuông góc → quy tắc hình hộp: hợp lực $=\sqrt{F_1^2+F_2^2+F_3^2}$.
- **Bẫy:** lấy nhầm góc giữa dây với **mặt phẳng ngang** thay cho góc với **phương thẳng đứng** (khi đó phải dùng $\sin$ thay cho $\cos$); quên rằng $n$ dây cùng chia nhau trọng lượng; làm tròn quá sớm.

![Hình 4. Đèn treo bằng bốn dây bằng nhau: thành phần thẳng đứng của bốn lực căng cân bằng với trọng lực](h4-den-treo.svg)

> [!vi-du] Ví dụ 16
> Một chiếc đèn trang trí có khung là hình vuông $ABCD$ nằm ngang, đường chéo dài $60$ cm, trọng lượng $40$ N (đặt tại tâm $O$ của khung). Đèn được treo vào móc $S$ trên trần bằng bốn sợi dây $SA$, $SB$, $SC$, $SD$ dài bằng nhau, với $S$ nằm thẳng trên $O$ và cách mặt khung $40$ cm. Tính độ lớn lực căng của mỗi sợi dây (bỏ qua khối lượng dây).

> [!goi-y] Gợi ý 1
> $OA=30$ cm, $SO=40$ cm, nên $SA=50$ cm và $\cos\alpha=\dfrac{SO}{SA}$ với $\alpha=\widehat{ASO}$.

> [!goi-y] Gợi ý 2
> Do đối xứng, bốn lực căng có cùng độ lớn $T$; thành phần nằm ngang triệt tiêu từng cặp đối diện ($A$ với $C$, $B$ với $D$). Cân bằng theo phương thẳng đứng: $4T\cos\alpha=P$.

> [!loi-giai] Lời giải
> $SA=\sqrt{30^2+40^2}=50$ cm, $\cos\alpha=\dfrac{40}{50}=0{,}8$.
> Đèn đứng yên nên $\vec T_A+\vec T_B+\vec T_C+\vec T_D+\vec P=\vec 0$. Theo phương thẳng đứng: $4T\cdot0{,}8=40\Rightarrow T=12{,}5$ N.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Vectơ bằng nhau | Cùng hướng **và** cùng độ dài (không cần cùng mặt phẳng) |
| Cùng phương | Giá song song hoặc trùng nhau; $\vec a=k\vec b$ ($\vec b\ne\vec0$) |
| Quy tắc ba điểm | $\overrightarrow{AB}+\overrightarrow{BC}=\overrightarrow{AC}$ |
| Quy tắc hình bình hành | $\overrightarrow{AB}+\overrightarrow{AD}=\overrightarrow{AC}$ |
| **Quy tắc hình hộp** | $\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}=\overrightarrow{AC'}$ |
| Quy tắc trừ | $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$ |
| Trung điểm $I$ của $AB$ | $\overrightarrow{OA}+\overrightarrow{OB}=2\overrightarrow{OI}$ |
| Trọng tâm $G$ tam giác $ABC$ | $\overrightarrow{OA}+\overrightarrow{OB}+\overrightarrow{OC}=3\overrightarrow{OG}$ |
| Trọng tâm $I$ tứ diện | $\overrightarrow{IA}+\overrightarrow{IB}+\overrightarrow{IC}+\overrightarrow{ID}=\vec0$; $\overrightarrow{AI}=\frac34\overrightarrow{AG}$ |
| Góc giữa hai vectơ | Dời về chung gốc; từ $0^\circ$ đến $180^\circ$ |
| Tích vô hướng | $\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b)$ |
| Độ dài qua tích vô hướng | $\lvert\vec u\rvert^2=\vec u^2$ (bình phương rồi khai triển) |
| Vuông góc | $\vec a\perp\vec b\iff\vec a\cdot\vec b=0$ |

**Sơ đồ tư duy khi gặp đề:** đẳng thức vectơ → *chèn điểm*, *nối đuôi*, *chung gốc*; ba cạnh từ một đỉnh hình hộp → *quy tắc hình hộp*; tích vô hướng/góc → *dời về chung gốc* hoặc *phân tích qua ba vectơ gốc*; vật đứng yên → *tổng lực bằng $\vec 0$*.
