---
title: Hệ trục tọa độ trong không gian
thoi-gian: 40 phút
muc-tieu:
  - Nhận biết hệ trục tọa độ $Oxyz$: gốc tọa độ, ba trục, ba vectơ đơn vị $\vec i,\vec j,\vec k$ và ba mặt phẳng tọa độ.
  - Xác định được tọa độ của một điểm, của một vectơ đối với hệ trục $Oxyz$; đọc nhanh tọa độ hình chiếu của điểm lên trục và mặt phẳng tọa độ.
  - Tính tọa độ vectơ $\overrightarrow{AB}$ từ tọa độ hai điểm; dùng hai vectơ bằng nhau để tìm tọa độ đỉnh của hình bình hành, hình hộp.
  - Biết đặt hệ trục vào một hình hộp, một căn phòng, một vùng trời… để giải bài toán thực tế.
---
> [!ghi-nho] Bài này trong 5 dòng
> - Hệ $Oxyz$: ba trục $Ox, Oy, Oz$ đôi một vuông góc tại gốc $O$; vectơ đơn vị $\vec i=(1;0;0)$, $\vec j=(0;1;0)$, $\vec k=(0;0;1)$.
> - $M(x;y;z) \iff \overrightarrow{OM}=x\vec i+y\vec j+z\vec k$ — $x$ là hoành độ, $y$ là tung độ, $z$ là cao độ.
> - $\vec a=(x;y;z) \iff \vec a=x\vec i+y\vec j+z\vec k$; hai vectơ bằng nhau khi ba tọa độ tương ứng bằng nhau.
> - $\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$ — "cuối trừ đầu".
> - Chiếu lên **trục** nào thì **giữ** tọa độ của trục đó; chiếu lên **mặt phẳng** nào thì **cho bằng 0** tọa độ không có tên trong mặt phẳng đó.

## 1. Hệ trục tọa độ trong không gian

### 1.1 Vì sao cần ba con số?

Hãy nhìn vào một góc phòng: sàn nhà và hai bức tường gặp nhau ở một điểm. Ba đường mép (hai mép chân tường và một mép đứng) **đôi một vuông góc** với nhau.

Giả sử có một con nhện đang treo lơ lửng trong phòng. Muốn chỉ cho bạn chính xác chỗ của nó, em chỉ cần nói: *cách bức tường thứ nhất 1,2 m, cách bức tường thứ hai 3 m, cách sàn 2,5 m*. **Ba con số** là đủ, không thừa, không thiếu.

> [!nen-tang] Nhớ lại lớp 10: hệ trục $Oxy$ trong mặt phẳng
> Trong mặt phẳng, hai trục $Ox, Oy$ vuông góc tại $O$; mỗi điểm $M$ ứng với **một cặp số** $(x;y)$ sao cho $\overrightarrow{OM}=x\vec i+y\vec j$. Trong không gian ta làm y hệt, chỉ thêm **trục thứ ba** $Oz$ và **số thứ ba** $z$.

### 1.2 Định nghĩa

Trong không gian, ba trục $Ox, Oy, Oz$ **đôi một vuông góc** tại gốc chung $O$. Gọi $\vec i,\vec j,\vec k$ lần lượt là vectơ đơn vị (độ dài bằng 1, cùng hướng với chiều dương) trên ba trục đó.

- Hệ ba trục như vậy gọi là **hệ trục tọa độ Descartes vuông góc** $Oxyz$, gọi tắt là **hệ tọa độ** $Oxyz$.
- $O$ là **gốc tọa độ**.
- Ba mặt phẳng $(Oxy)$, $(Oyz)$, $(Ozx)$ đôi một vuông góc, gọi là các **mặt phẳng tọa độ**.
- Không gian đã gắn hệ tọa độ $Oxyz$ gọi là **không gian** $Oxyz$.

![Hình 1. Hệ trục Oxyz, ba vectơ đơn vị và ba mặt phẳng tọa độ](he-truc-oxyz.svg)

Trong góc phòng ở trên: $O$ là góc phòng, $(Oxy)$ là **sàn nhà**, $(Oyz)$ và $(Ozx)$ là **hai bức tường**, trục $Oz$ là mép đứng của hai bức tường.

Vì $\vec i,\vec j,\vec k$ có độ dài 1 và đôi một vuông góc, theo tích vô hướng đã học ở Bài 6:
$$\vec i^{\,2}=\vec j^{\,2}=\vec k^{\,2}=1,\qquad \vec i\cdot\vec j=\vec j\cdot\vec k=\vec k\cdot\vec i=0.$$

> [!meo] Mỗi mặt phẳng tọa độ "thiếu" đúng một trục
> - $(Oxy)$ chứa $Ox, Oy$ và **vuông góc với** $Oz$.
> - $(Oyz)$ chứa $Oy, Oz$ và vuông góc với $Ox$.
> - $(Ozx)$ chứa $Oz, Ox$ và vuông góc với $Oy$.
>
> Viết $(Ozx)$ hay $(Oxz)$ đều chỉ cùng một mặt phẳng; SGK quen viết $(Ozx)$.

> [!vi-du] Ví dụ 1
> Cho hình lập phương $ABCD.A'B'C'D'$ có cạnh bằng 2.
>
> a) Có thể lập hệ tọa độ $Oxyz$ có gốc $O\equiv A$ và $\vec i,\vec j,\vec k$ **lần lượt bằng** $\overrightarrow{AB},\overrightarrow{AD},\overrightarrow{AA'}$ không?
>
> b) Có thể lập hệ tọa độ $Oxyz$ có gốc $O\equiv A$ và $\vec i,\vec j,\vec k$ **lần lượt cùng hướng** với $\overrightarrow{AB},\overrightarrow{AD},\overrightarrow{AA'}$ không?

> [!goi-y] Gợi ý 1
> Ba vectơ $\vec i,\vec j,\vec k$ cần thỏa hai điều kiện: đôi một vuông góc **và** có độ dài bằng 1.

> [!goi-y] Gợi ý 2
> Ba cạnh $AB, AD, AA'$ của hình lập phương có đôi một vuông góc không? Độ dài của chúng là bao nhiêu?

> [!loi-giai] Lời giải
> Ba cạnh $AB, AD, AA'$ xuất phát từ cùng đỉnh $A$ và đôi một vuông góc.
>
> a) **Không**, vì $\lvert\overrightarrow{AB}\rvert=2\ne 1$, mà vectơ đơn vị phải có độ dài 1.
>
> b) **Có**. Lấy $\vec i=\tfrac12\overrightarrow{AB}$, $\vec j=\tfrac12\overrightarrow{AD}$, $\vec k=\tfrac12\overrightarrow{AA'}$: ba vectơ này có chung gốc $A$, đôi một vuông góc, độ dài bằng 1 và cùng hướng với ba cạnh. Khi đó các tia $AB, AD, AA'$ chính là các tia $Ox, Oy, Oz$.

> [!bay] Phân biệt "bằng" và "cùng hướng"
> Đề hỏi "$\vec i$ **bằng** $\overrightarrow{AB}$" thì phải kiểm tra cả **độ dài bằng 1**. Đề hỏi "cùng hướng" hay "cùng phương" thì chỉ cần ba cạnh đôi một vuông góc. Đây là chỗ đề Đúng/Sai rất hay "gài".

## 2. Tọa độ của điểm, tọa độ của vectơ trong không gian

### 2.1 Tọa độ của điểm

**Trực quan.** Từ điểm $M$, kẻ các đường vuông góc xuống ba trục, ta được một **hình hộp chữ nhật** có một đỉnh là $O$, đỉnh đối diện là $M$ và ba cạnh nằm trên ba trục (Hình 2). Gọi $M_1, M_2, M_3$ là chân các đường vuông góc trên $Ox, Oy, Oz$.

Theo **quy tắc hình hộp** (Bài 6):
$$\overrightarrow{OM}=\overrightarrow{OM_1}+\overrightarrow{OM_2}+\overrightarrow{OM_3}.$$
Mà $\overrightarrow{OM_1}$ cùng phương với $\vec i$ nên $\overrightarrow{OM_1}=x\vec i$; tương tự $\overrightarrow{OM_2}=y\vec j$, $\overrightarrow{OM_3}=z\vec k$. Vậy
$$\overrightarrow{OM}=x\vec i+y\vec j+z\vec k.$$

![Hình 2. Điểm M(x; y; z) và các hình chiếu của M lên ba trục, lên mặt phẳng (Oxy)](toa-do-diem.svg)

> [!ghi-nho] Định nghĩa tọa độ của điểm
> Với mỗi điểm $M$ trong không gian $Oxyz$, có **duy nhất** bộ ba số $(x;y;z)$ sao cho $\overrightarrow{OM}=x\vec i+y\vec j+z\vec k$. Bộ ba đó là **tọa độ** của $M$, viết $M(x;y;z)$ hoặc $M=(x;y;z)$.
> - $x$: **hoành độ**, $y$: **tung độ**, $z$: **cao độ**.
> - Gốc tọa độ: $O(0;0;0)$.

**Cách hiểu dễ nhớ:** $M(x;y;z)$ nghĩa là "từ $O$, đi theo hướng $\vec i$ một đoạn $x$, rồi theo hướng $\vec j$ một đoạn $y$, rồi theo hướng $\vec k$ một đoạn $z$ thì tới $M$". Số âm nghĩa là đi **ngược** chiều dương của trục.

> [!vi-du] Ví dụ 2
> Trong không gian $Oxyz$, cho hình hộp chữ nhật $ABCD.A'B'C'D'$ có $A$ trùng gốc $O$; $B, D, A'$ lần lượt nằm trên các tia $Ox, Oy, Oz$ với $AB=3$, $AD=4$, $AA'=2$ (Hình 3). Tìm tọa độ tất cả các đỉnh.

![Hình 3. Hình hộp chữ nhật đặt trong hệ trục, A trùng gốc O](hinh-hop-oxyz.svg)

> [!goi-y] Gợi ý 1
> Ba đỉnh nằm trên trục: điểm trên tia $Ox$ cách $O$ một đoạn 3 thì $\overrightarrow{OB}=3\vec i$.

> [!goi-y] Gợi ý 2
> Với đỉnh $C'$, dùng quy tắc hình hộp: $\overrightarrow{AC'}=\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}$.

> [!loi-giai] Lời giải
> **Bước 1 – ba đỉnh trên trục.** $\overrightarrow{OB}=3\vec i$ nên $B(3;0;0)$; $\overrightarrow{OD}=4\vec j$ nên $D(0;4;0)$; $\overrightarrow{OA'}=2\vec k$ nên $A'(0;0;2)$.
>
> **Bước 2 – các đỉnh còn lại.** Theo quy tắc hình bình hành và quy tắc hình hộp:
>
> $\overrightarrow{OC}=\overrightarrow{OB}+\overrightarrow{OD}=3\vec i+4\vec j$ nên $C(3;4;0)$;
>
> $\overrightarrow{OB'}=3\vec i+2\vec k$ nên $B'(3;0;2)$; $\overrightarrow{OD'}=4\vec j+2\vec k$ nên $D'(0;4;2)$;
>
> $\overrightarrow{OC'}=3\vec i+4\vec j+2\vec k$ nên $C'(3;4;2)$.
>
> **Kết luận:** $A(0;0;0)$, $B(3;0;0)$, $C(3;4;0)$, $D(0;4;0)$, $A'(0;0;2)$, $B'(3;0;2)$, $C'(3;4;2)$, $D'(0;4;2)$.

> [!meo] Đọc tọa độ đỉnh hộp chữ nhật trong 5 giây
> Khi gốc ở một đỉnh và ba cạnh nằm trên ba tia $Ox, Oy, Oz$ với độ dài $a, b, c$: mỗi đỉnh có tọa độ chỉ gồm các số $0$ hoặc $a$ (vị trí 1), $0$ hoặc $b$ (vị trí 2), $0$ hoặc $c$ (vị trí 3). Đỉnh nằm ở mặt "đáy" có $z=0$, mặt "trên" có $z=c$…

### 2.2 Hình chiếu, điểm đặc biệt và điểm đối xứng

**Hình chiếu vuông góc.** Nhìn lại Hình 2 với $M(x;y;z)$:

- Chiếu $M$ **thẳng xuống sàn** $(Oxy)$: điểm "rơi" giữ nguyên vị trí ngang ($x$, $y$), chỉ mất độ cao. Vậy hình chiếu là $M'(x;y;0)$.
- Chiếu $M$ lên **trục** $Ox$: chỉ còn lại "phần đi theo $Ox$", tức $M_1(x;0;0)$.

| Chiếu $M(x;y;z)$ lên | Tọa độ hình chiếu | Quy tắc |
|---|---|---|
| trục $Ox$ | $(x;0;0)$ | giữ $x$ |
| trục $Oy$ | $(0;y;0)$ | giữ $y$ |
| trục $Oz$ | $(0;0;z)$ | giữ $z$ |
| mặt phẳng $(Oxy)$ | $(x;y;0)$ | cho $z=0$ |
| mặt phẳng $(Oyz)$ | $(0;y;z)$ | cho $x=0$ |
| mặt phẳng $(Ozx)$ | $(x;0;z)$ | cho $y=0$ |

Từ bảng trên suy ra luôn **dạng tọa độ của các điểm đặc biệt**: điểm thuộc trục $Ox$ có dạng $(a;0;0)$; điểm thuộc mặt phẳng $(Oxy)$ có dạng $(a;b;0)$; điểm thuộc $(Oyz)$ có dạng $(0;b;c)$…

> [!bay] Trục thì "giữ", mặt phẳng thì "xóa"
> Hình chiếu của $M(2;-3;5)$ lên trục $Oy$ là $(0;-3;0)$ — **giữ** tung độ. Nhiều bạn nhầm sang "xóa $y$" thành $(2;0;5)$, đó lại là hình chiếu lên **mặt phẳng** $(Ozx)$.

**Khoảng cách đến mặt phẳng tọa độ.** Đoạn $MM'$ vuông góc với sàn $(Oxy)$ và dài đúng bằng độ cao $\lvert z\rvert$. Tương tự:
$$d\big(M,(Oxy)\big)=\lvert z\rvert,\qquad d\big(M,(Oyz)\big)=\lvert x\rvert,\qquad d\big(M,(Ozx)\big)=\lvert y\rvert.$$

**Khoảng cách đến trục $Oz$.** Đó là độ dài $OM'$ (đường chéo hình chữ nhật trên sàn có hai cạnh $\lvert x\rvert$, $\lvert y\rvert$), nên theo định lí Pythagore: $d(M,Oz)=\sqrt{x^2+y^2}$. Tương tự $d(M,Ox)=\sqrt{y^2+z^2}$, $d(M,Oy)=\sqrt{x^2+z^2}$.

**Điểm đối xứng.** Soi gương trên sàn $(Oxy)$: ảnh của $M$ có cùng vị trí ngang nhưng độ cao **đổi dấu**, tức là $(x;y;-z)$. Tương tự:

| Đối xứng $M(x;y;z)$ qua | Tọa độ ảnh |
|---|---|
| gốc $O$ | $(-x;-y;-z)$ |
| trục $Ox$ | $(x;-y;-z)$ |
| trục $Oy$ | $(-x;y;-z)$ |
| trục $Oz$ | $(-x;-y;z)$ |
| mặt phẳng $(Oxy)$ | $(x;y;-z)$ |
| mặt phẳng $(Oyz)$ | $(-x;y;z)$ |
| mặt phẳng $(Ozx)$ | $(x;-y;z)$ |

> [!meo] Một câu nhớ cả bảng đối xứng
> **"Qua cái gì thì giữ cái đó, còn lại đổi dấu."** Qua trục $Ox$: giữ $x$, đổi dấu $y, z$. Qua mặt phẳng $(Oxy)$: giữ $x, y$, đổi dấu $z$. Qua gốc $O$: không giữ gì, đổi dấu cả ba.

> [!vi-du] Ví dụ 3
> Cho điểm $M(2;-3;5)$. Tìm:
>
> a) hình chiếu của $M$ lên trục $Oy$ và lên mặt phẳng $(Ozx)$;
>
> b) điểm đối xứng với $M$ qua mặt phẳng $(Oxy)$ và qua trục $Oz$;
>
> c) khoảng cách từ $M$ đến mặt phẳng $(Oyz)$ và đến trục $Oz$.

> [!goi-y] Gợi ý 1
> Trục: giữ đúng tọa độ của trục. Mặt phẳng: cho bằng 0 tọa độ không có tên trong mặt phẳng.

> [!goi-y] Gợi ý 2
> Đối xứng: "qua cái gì giữ cái đó". Khoảng cách đến $(Oyz)$ là $\lvert x\rvert$; đến trục $Oz$ là $\sqrt{x^2+y^2}$.

> [!loi-giai] Lời giải
> a) Hình chiếu lên $Oy$: $(0;-3;0)$. Hình chiếu lên $(Ozx)$: cho $y=0$, được $(2;0;5)$.
>
> b) Đối xứng qua $(Oxy)$: giữ $x,y$, đổi dấu $z$, được $(2;-3;-5)$. Đối xứng qua $Oz$: giữ $z$, đổi dấu $x,y$, được $(-2;3;5)$.
>
> c) $d\big(M,(Oyz)\big)=\lvert 2\rvert=2$; $d(M,Oz)=\sqrt{2^2+(-3)^2}=\sqrt{13}$.

### 2.3 Tọa độ của vectơ

Với vectơ $\vec a$ bất kì, ta "đặt gốc" của nó tại $O$: lấy điểm $M$ sao cho $\overrightarrow{OM}=\vec a$ (điểm $M$ như vậy luôn có và duy nhất — Bài 6). Vì $\overrightarrow{OM}=x\vec i+y\vec j+z\vec k$ nên $\vec a$ cũng viết được như vậy.

> [!ghi-nho] Định nghĩa tọa độ của vectơ
> Bộ ba số **duy nhất** $(x;y;z)$ sao cho $\vec a=x\vec i+y\vec j+z\vec k$ gọi là **tọa độ của vectơ** $\vec a$; viết $\vec a=(x;y;z)$ hoặc $\vec a(x;y;z)$.
> - Tọa độ của $\vec a$ chính là tọa độ của điểm $M$ với $\overrightarrow{OM}=\vec a$.
> - $\vec i=(1;0;0)$, $\vec j=(0;1;0)$, $\vec k=(0;0;1)$, $\vec 0=(0;0;0)$.
> - Cho $\vec a=(x;y;z)$, $\vec b=(x';y';z')$: $\vec a=\vec b \iff x=x',\ y=y',\ z=z'$.

> [!vi-du] Ví dụ 4
> a) Tìm tọa độ của các vectơ $\vec u=3\vec i-\vec k$ và $\vec v=2\vec j-5\vec i$.
>
> b) Tìm $m, n$ để hai vectơ $\vec a=(m+1;\,2;\,n)$ và $\vec b=(3;\,2;\,4-n)$ bằng nhau.

> [!goi-y] Gợi ý 1
> Viết lại đủ ba thành phần theo **đúng thứ tự** $\vec i,\vec j,\vec k$; thành phần nào vắng mặt thì hệ số bằng 0.

> [!goi-y] Gợi ý 2
> Hai vectơ bằng nhau ⇔ hoành độ bằng nhau, tung độ bằng nhau, cao độ bằng nhau.

> [!loi-giai] Lời giải
> a) $\vec u=3\vec i+0\vec j+(-1)\vec k$ nên $\vec u=(3;0;-1)$. $\vec v=-5\vec i+2\vec j+0\vec k$ nên $\vec v=(-5;2;0)$.
>
> b) $\vec a=\vec b \iff m+1=3$ và $n=4-n$ $\iff m=2,\ n=2$.

> [!bay] Thứ tự và số 0
> $\vec v=2\vec j-5\vec i$ có tọa độ $(-5;2;0)$, **không phải** $(2;-5;0)$: luôn sắp theo thứ tự $\vec i,\vec j,\vec k$. Và $3\vec i-\vec k$ là $(3;0;-1)$ chứ không phải $(3;-1)$ hay $(3;-1;0)$.

### 2.4 Tọa độ của vectơ theo tọa độ hai đầu mút

Cho $A(x_A;y_A;z_A)$ và $B(x_B;y_B;z_B)$. Theo quy tắc hiệu (Bài 6): $\overrightarrow{AB}=\overrightarrow{OB}-\overrightarrow{OA}$, nên
$$\overrightarrow{AB}=(x_B-x_A)\vec i+(y_B-y_A)\vec j+(z_B-z_A)\vec k.$$

> [!ghi-nho] Công thức "cuối trừ đầu"
> $$\overrightarrow{AB}=(x_B-x_A;\ y_B-y_A;\ z_B-z_A)$$
>
> Điểm **cuối** ($B$) trừ điểm **đầu** ($A$), làm riêng từng tọa độ.

> [!vi-du] Ví dụ 5
> Cho $A(1;-2;3)$, $B(4;0;-1)$. Tìm tọa độ của $\overrightarrow{AB}$ và $\overrightarrow{BA}$.

> [!goi-y] Gợi ý 1
> Lấy tọa độ $B$ trừ tọa độ $A$, cẩn thận với dấu trừ của số âm: $0-(-2)=2$.

> [!loi-giai] Lời giải
> $\overrightarrow{AB}=(4-1;\ 0-(-2);\ -1-3)=(3;2;-4)$.
>
> $\overrightarrow{BA}=(1-4;\ -2-0;\ 3-(-1))=(-3;-2;4)$ — đúng bằng $\overrightarrow{AB}$ đổi dấu cả ba tọa độ, vì $\overrightarrow{BA}=-\overrightarrow{AB}$.

**Dùng vectơ bằng nhau để tìm điểm.** Đây là kĩ năng quan trọng nhất của bài. Muốn tìm một điểm chưa biết, ta tìm một **cặp vectơ bằng nhau** trong hình (cạnh đối của hình bình hành, cạnh bên của lăng trụ/hình hộp), rồi cho ba tọa độ bằng nhau.

> [!vi-du] Ví dụ 6
> Cho $A(1;0;2)$, $B(2;3;-1)$, $C(0;4;1)$. Tìm tọa độ điểm $D$ sao cho $ABCD$ là hình bình hành.

> [!goi-y] Gợi ý 1
> Hình bình hành $ABCD$ (các đỉnh theo đúng thứ tự) có $\overrightarrow{AB}=\overrightarrow{DC}$. Hãy vẽ phác để thấy hai vectơ này cùng hướng.

> [!goi-y] Gợi ý 2
> Gọi $D(x;y;z)$, viết $\overrightarrow{DC}=(0-x;\,4-y;\,1-z)$ rồi cho bằng $\overrightarrow{AB}$.

> [!loi-giai] Lời giải
> $\overrightarrow{AB}=(1;3;-3)$. Gọi $D(x;y;z)$ thì $\overrightarrow{DC}=(-x;\,4-y;\,1-z)$.
>
> $ABCD$ là hình bình hành $\iff \overrightarrow{AB}=\overrightarrow{DC} \iff -x=1,\ 4-y=3,\ 1-z=-3 \iff x=-1,\ y=1,\ z=4$.
>
> Vậy $D(-1;1;4)$. (Kiểm tra nhanh: $\overrightarrow{AB}=(1;3;-3)$ và $\overrightarrow{AC}=(-1;4;-1)$ không cùng phương nên $A, B, C$ không thẳng hàng — hình bình hành thật sự tồn tại.)

> [!bay] Viết sai cặp vectơ
> Với hình bình hành $ABCD$: $\overrightarrow{AB}=\overrightarrow{DC}$ (hoặc $\overrightarrow{AD}=\overrightarrow{BC}$). Viết $\overrightarrow{AB}=\overrightarrow{CD}$ là **sai hướng** và sẽ ra điểm $D(1;7;-2)$ — một phương án nhiễu rất hay gặp trong đề.

> [!vi-du] Ví dụ 7
> Cho hình hộp $ABCD.A'B'C'D'$ có $A(1;2;0)$, $B(3;1;1)$, $D(0;4;2)$, $A'(2;2;3)$. Tìm tọa độ các đỉnh $C$ và $C'$.

> [!goi-y] Gợi ý 1
> Mặt đáy $ABCD$ là hình bình hành nên $\overrightarrow{DC}=\overrightarrow{AB}$.

> [!goi-y] Gợi ý 2
> Các cạnh bên của hình hộp song song, cùng hướng, bằng nhau: $\overrightarrow{CC'}=\overrightarrow{AA'}$.

> [!loi-giai] Lời giải
> **Bước 1.** $\overrightarrow{AB}=(2;-1;1)$. Gọi $C(x;y;z)$: $\overrightarrow{DC}=(x;\,y-4;\,z-2)=(2;-1;1)$ nên $C(2;3;3)$.
>
> **Bước 2.** $\overrightarrow{AA'}=(1;0;3)$. Gọi $C'(a;b;c)$: $\overrightarrow{CC'}=(a-2;\,b-3;\,c-3)=(1;0;3)$ nên $C'(3;3;6)$.
>
> **Kết luận:** $C(2;3;3)$, $C'(3;3;6)$.

### 2.5 Đặt hệ trục vào thực tế

Muốn dùng tọa độ cho một tình huống thực tế, em làm 3 việc: **chọn gốc** (một điểm cố định dễ đo: góc phòng, chân tháp…), **chọn ba hướng vuông góc** (thường là hai hướng nằm ngang và hướng thẳng đứng lên), **chọn đơn vị** (m, km…). Sau đó mỗi vị trí là một bộ ba số, mỗi lần di chuyển là một vectơ.

> [!vi-du] Ví dụ 8
> Một phòng học hình hộp chữ nhật rộng 6 m, dài 10 m, cao 3,5 m. Đặt hệ $Oxyz$ với $O$ là một góc sàn, $Ox$ dọc theo mép chân tường **chiều rộng**, $Oy$ dọc theo mép chân tường **chiều dài**, $Oz$ hướng lên trần, đơn vị mét (Hình 4). Như vậy mọi điểm trong phòng có $0\le x\le 6$, $0\le y\le 10$, $0\le z\le 3{,}5$. Một drone cất cánh từ điểm $A(2;3;0)$ trên sàn, bay thẳng đứng lên 2 m tới $B$, rồi bay ngang theo chiều dương của trục $Oy$ thêm 4 m tới $C$.
>
> a) Tìm tọa độ $B$, $C$ và tọa độ các vectơ dịch chuyển $\overrightarrow{AB}$, $\overrightarrow{BC}$.
>
> b) Khi ở $C$, drone cách trần nhà bao nhiêu mét? Cách bức tường nằm trong mặt phẳng $(Ozx)$ bao nhiêu mét?

![Hình 4. Hệ trục đặt trong phòng học và đường bay A → B → C của drone](phong-drone.svg)

> [!goi-y] Gợi ý 1
> Bay thẳng đứng lên 2 m: chỉ cao độ tăng 2. Bay theo chiều dương $Oy$ 4 m: chỉ tung độ tăng 4.

> [!goi-y] Gợi ý 2
> Trần nhà là mặt phẳng có mọi điểm cao độ bằng 3,5. Bức tường trong $(Ozx)$ là mặt phẳng $y=0$, khoảng cách tới nó là $\lvert y\rvert$.

> [!loi-giai] Lời giải
> a) $B(2;3;2)$, $C(2;7;2)$. $\overrightarrow{AB}=(0;0;2)=2\vec k$, $\overrightarrow{BC}=(0;4;0)=4\vec j$.
>
> b) Cách trần: $3{,}5-2=1{,}5$ (m). Cách bức tường trong $(Ozx)$: $\lvert y_C\rvert=7$ (m).

> [!ung-dung] Theo dõi máy bay bằng tọa độ
> Trạm kiểm soát không lưu đặt gốc $O$ tại trạm, $Ox$ hướng đông, $Oy$ hướng bắc, $Oz$ thẳng đứng lên trời, đơn vị km. Máy bay đang ở $(-30;40;10)$ (cao 10 km), bay về hướng **tây** với tốc độ 600 km/h trong 20 phút, giữ độ cao. Quãng bay $600\cdot\tfrac13=200$ km, hướng tây là **ngược** chiều $Ox$ nên vectơ dịch chuyển là $(-200;0;0)$ và vị trí mới là $(-230;40;10)$. (SGK tr. 64 cũng có một tình huống như vậy nhưng chọn $Ox$ hướng tây, $Oy$ hướng nam — luôn đọc kĩ đề chọn trục thế nào.) Khi máy bay chạy trên đường băng (mặt đất $\equiv (Oxy)$) thì tọa độ của nó luôn có dạng $(x;y;0)$.

> [!em-co-biet] Không chỉ có tọa độ Descartes
> Tên "tọa độ Descartes" ghi nhớ nhà toán học Pháp René Descartes (1596–1650). Ngoài bộ $(x;y;z)$, người ta còn xác định vị trí bằng **tọa độ cầu**: khoảng cách tới gốc và hai góc — giống như kinh độ, vĩ độ trên Trái Đất. Hệ thống định vị vệ tinh dùng cả hai loại và đổi qua lại liên tục (SGK tr. 65–66).

## Dạng bài thi hay gặp

### Dạng 1. Hình chiếu – điểm đối xứng – khoảng cách đến trục, mặt phẳng tọa độ

*Nhận biết:* đề cho một điểm $M(x;y;z)$ và hỏi hình chiếu, điểm đối xứng, hoặc khoảng cách tới $(Oxy)$, $(Oyz)$, $(Ozx)$, tới trục.

*Phương pháp:*
1. Hình chiếu lên trục: giữ tọa độ của trục, hai tọa độ kia bằng 0.
2. Hình chiếu lên mặt phẳng: cho bằng 0 tọa độ vắng mặt trong tên mặt phẳng.
3. Đối xứng: "qua cái gì giữ cái đó, còn lại đổi dấu".
4. Khoảng cách tới $(Oxy)$ là $\lvert z\rvert$…; tới trục $Oz$ là $\sqrt{x^2+y^2}$…

> [!vi-du] Ví dụ 9 (Đúng/Sai)
> Trong không gian $Oxyz$, cho điểm $M(-3;4;2)$. Xét tính đúng, sai của các mệnh đề:
>
> a) Hình chiếu vuông góc của $M$ lên trục $Ox$ là điểm $(-3;0;0)$.
>
> b) Hình chiếu vuông góc của $M$ lên mặt phẳng $(Oyz)$ là điểm $(-3;4;0)$.
>
> c) Điểm đối xứng với $M$ qua mặt phẳng $(Ozx)$ là $(-3;-4;2)$.
>
> d) Khoảng cách từ $M$ đến trục $Oz$ bằng 5.

> [!goi-y] Gợi ý 1
> Ý b: mặt phẳng $(Oyz)$ "thiếu" chữ $x$, vậy tọa độ nào phải bằng 0?

> [!goi-y] Gợi ý 2
> Ý d: khoảng cách tới trục $Oz$ chỉ phụ thuộc $x$ và $y$.

> [!loi-giai] Lời giải
> a) **Đúng** — chiếu lên $Ox$ giữ hoành độ: $(-3;0;0)$.
>
> b) **Sai** — chiếu lên $(Oyz)$ phải cho $x=0$: $(0;4;2)$. Điểm $(-3;4;0)$ là hình chiếu lên $(Oxy)$.
>
> c) **Đúng** — qua $(Ozx)$ giữ $x, z$, đổi dấu $y$: $(-3;-4;2)$.
>
> d) **Đúng** — $d(M,Oz)=\sqrt{(-3)^2+4^2}=5$.

*Bẫy:* nhầm "trục" với "mặt phẳng"; quên đổi dấu cả **hai** tọa độ khi đối xứng qua một trục; tính khoảng cách tới trục $Oz$ bằng $\lvert z\rvert$ (đó là khoảng cách tới **mặt phẳng** $(Oxy)$).

### Dạng 2. Tọa độ vectơ – tìm đỉnh hình bình hành, hình hộp

*Nhận biết:* cho tọa độ vài đỉnh, hỏi đỉnh còn lại hoặc tọa độ một vectơ.

*Phương pháp:*
1. Vẽ phác hình, xác định đúng **thứ tự đỉnh**.
2. Chọn cặp vectơ bằng nhau có chứa điểm cần tìm (cạnh đối hình bình hành, cạnh bên hình hộp/lăng trụ).
3. Đặt tọa độ điểm cần tìm là $(x;y;z)$, viết hai vectơ theo "cuối trừ đầu", cho ba tọa độ bằng nhau.

> [!vi-du] Ví dụ 10 (4 lựa chọn)
> Cho $A(2;1;-1)$, $B(3;0;1)$, $C(2;-1;3)$. Điểm $D$ để $ABCD$ là hình bình hành có tọa độ là
>
> **A.** $(1;0;1)$  **B.** $(3;-2;5)$  **C.** $(3;2;-3)$  **D.** $(1;2;-3)$

> [!goi-y] Gợi ý 1
> Dùng $\overrightarrow{AD}=\overrightarrow{BC}$.

> [!loi-giai] Lời giải
> $\overrightarrow{BC}=(2-3;\,-1-0;\,3-1)=(-1;-1;2)$. Gọi $D(x;y;z)$: $\overrightarrow{AD}=(x-2;\,y-1;\,z+1)=(-1;-1;2)$ nên $D(1;0;1)$. Chọn **A**.
>
> Phương án $(3;-2;5)$ là đỉnh thứ tư của hình bình hành $ABDC$ (sai thứ tự đỉnh); phương án $(3;2;-3)$ là đỉnh thứ tư của hình bình hành $ACBD$.

*Bẫy:* viết $\overrightarrow{AB}=\overrightarrow{CD}$; trừ ngược "đầu trừ cuối"; sai dấu khi trừ số âm.

### Dạng 3. Đặt hình hộp chữ nhật, hình lập phương vào hệ trục

*Nhận biết:* hình hộp chữ nhật/lập phương có một đỉnh trùng $O$, ba cạnh nằm trên ba tia $Ox, Oy, Oz$.

*Phương pháp:* ghi độ dài ba cạnh $a, b, c$ theo ba trục; đỉnh nào "đi" theo trục nào thì có tọa độ tương ứng bằng $a$, $b$ hoặc $c$, còn lại bằng 0. Tâm một mặt / tâm hình hộp: lấy "nửa đường" theo các trục tương ứng.

> [!vi-du] Ví dụ 11 (trả lời ngắn)
> Cho hình lập phương $ABCD.A'B'C'D'$ cạnh 4, có $A\equiv O$, $B, D, A'$ lần lượt thuộc các tia $Ox, Oy, Oz$. Gọi $I$ là tâm của mặt $A'B'C'D'$ (giao điểm hai đường chéo). Tính tổng các tọa độ của $I$.

> [!goi-y] Gợi ý 1
> Mặt $A'B'C'D'$ nằm ở độ cao bao nhiêu? Hình chiếu của $I$ xuống đáy là điểm nào của hình vuông $ABCD$?

> [!loi-giai] Lời giải
> $A'(0;0;4)$, $B'(4;0;4)$, $C'(4;4;4)$, $D'(0;4;4)$: cả mặt trên có cao độ 4. Hình chiếu của $I$ xuống đáy là tâm hình vuông $ABCD$ với $A(0;0;0)$, $C(4;4;0)$, tức là điểm $(2;2;0)$. Vậy $I(2;2;4)$, tổng các tọa độ bằng $2+2+4=$ **8**.

*Bẫy:* đặt nhầm trục ($B$ trên $Ox$ nhưng lại cho $D$ có hoành độ khác 0); quên rằng mặt trên có cao độ bằng chiều cao chứ không bằng 0.

### Dạng 4. Bài toán thực tế: drone, máy bay, căn phòng

*Nhận biết:* đề mô tả vị trí bằng "cách sàn…, cách tường…", hoặc chuyển động "bay lên…, bay về hướng…".

*Phương pháp:*
1. Đọc kĩ hệ trục đề đã chọn (hướng nào là chiều dương).
2. Di chuyển theo một hướng: cộng/trừ quãng đường vào **đúng một** tọa độ (ngược chiều dương thì trừ).
3. Khoảng cách tới sàn/tường là trị tuyệt đối của tọa độ tương ứng; tới trần là chiều cao phòng trừ cao độ.

> [!vi-du] Ví dụ 12 (trả lời ngắn)
> Hệ tọa độ: gốc tại trạm radar, $Ox$ hướng đông, $Oy$ hướng bắc, $Oz$ hướng lên, đơn vị km. Một máy bay ở vị trí $(-30;40;10)$, bay về hướng nam với tốc độ không đổi 800 km/h trong 15 phút, độ cao không đổi. Tìm tung độ vị trí mới của máy bay.

> [!goi-y] Gợi ý 1
> 15 phút $=\tfrac14$ giờ. Hướng nam cùng hay ngược chiều dương của $Oy$?

> [!loi-giai] Lời giải
> Quãng đường: $800\cdot\tfrac14=200$ km, theo hướng nam (ngược chiều $Oy$) nên tung độ giảm 200: $40-200=-160$. Vị trí mới $(-30;-160;10)$. Đáp số: **−160**.

*Bẫy:* quên đổi phút ra giờ; cộng thay vì trừ khi đi ngược chiều dương; nhầm hướng đông/bắc với trục.

## Tóm tắt

| Nội dung | Công thức / quy tắc |
|---|---|
| Vectơ đơn vị | $\vec i=(1;0;0)$, $\vec j=(0;1;0)$, $\vec k=(0;0;1)$ |
| Tọa độ điểm | $M(x;y;z) \iff \overrightarrow{OM}=x\vec i+y\vec j+z\vec k$ |
| Tọa độ vectơ | $\vec a=(x;y;z) \iff \vec a=x\vec i+y\vec j+z\vec k$ |
| Hai vectơ bằng nhau | bằng nhau từng tọa độ |
| Vectơ theo hai điểm | $\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$ |
| Hình chiếu lên trục | giữ tọa độ của trục, còn lại bằng 0 |
| Hình chiếu lên mặt phẳng | tọa độ vắng mặt trong tên mặt phẳng bằng 0 |
| Đối xứng | qua cái gì giữ cái đó, còn lại đổi dấu |
| Khoảng cách tới mặt phẳng tọa độ | tới $(Oxy)$: $\lvert z\rvert$; tới $(Oyz)$: $\lvert x\rvert$; tới $(Ozx)$: $\lvert y\rvert$ |
| Khoảng cách tới trục | tới $Oz$: $\sqrt{x^2+y^2}$ (tương tự cho $Ox$, $Oy$) |
| Tìm đỉnh hình bình hành $ABCD$ | $\overrightarrow{AB}=\overrightarrow{DC}$ hoặc $\overrightarrow{AD}=\overrightarrow{BC}$ |
