---
title: Ôn tập chương III
thoi-gian: 55 phút
muc-tieu:
  - Hệ thống hóa toàn chương III — khoảng biến thiên, khoảng tứ phân vị (Bài 9), phương sai, độ lệch chuẩn (Bài 10) — và thấy mỗi số đặc trưng "nhìn" vào phần nào của mẫu số liệu ghép nhóm
  - Tính thành thạo cả bốn số đặc trưng đo mức độ phân tán từ một bảng ghép nhóm, đúng công thức của SGK, làm tròn đúng lúc
  - Phân biệt chắc chắn các trường hợp dễ nhầm (phương sai – độ lệch chuẩn, nhân tần số – thay tần số, mẫu gốc – mẫu ghép nhóm, $\sigma_x$ – $s_x$ trên máy tính…) và chọn đúng số đặc trưng để so sánh, đánh giá rủi ro, phát hiện giá trị ngoại lệ
  - Giải được các bài tổng hợp theo ba dạng đề tốt nghiệp và tự làm được các dạng của "Bài tập cuối chương III" (SGK tr. 85–86)
---
> [!ghi-nho] Chương này trong 10 dòng
> 1. Chương III trả lời câu hỏi: **số liệu trải rộng, phân tán đến mức nào?** (lớp 11 đã hỏi: số liệu tập trung quanh đâu?).
> 2. **Khoảng biến thiên** $R=a_{k+1}-a_1$: đầu mút phải nhóm cuối trừ đầu mút trái nhóm đầu, sau khi **bỏ các nhóm tần số 0 ở hai đầu** (Bài 9).
> 3. **Tứ phân vị** $Q_r$: nhóm chứa $Q_r$ là nhóm **đầu tiên** $[a_p;a_{p+1})$ có tần số tích lũy $\ge\frac{rn}{4}$, rồi
> $$Q_r=a_p+\dfrac{\frac{rn}{4}-C}{m_p}\cdot(a_{p+1}-a_p),$$
> với $C=m_1+\dots+m_{p-1}$ là số giá trị **đứng trước** nhóm đó.
> 4. **Khoảng tứ phân vị** $\Delta_Q=Q_3-Q_1$: độ dài khoảng chứa khoảng **50% số liệu ở giữa**.
> 5. **Phương sai** (Bài 10), với $x_i$ là **giá trị đại diện**:
> $$s^2=\frac1n\sum m_i(x_i-\bar x)^2$$
> hoặc dạng tính nhanh
> $$s^2=\frac1n\sum m_ix_i^2-\bar x^2.$$
> 6. **Độ lệch chuẩn** $s=\sqrt{s^2}$, cùng đơn vị với số liệu. Trên máy tính, $s$ là $\sigma_x$ (chia $n$), **không phải** $s_x$ (chia $n-1$).
> 7. Cả bốn số đều **không âm**; số càng lớn thì mẫu càng **phân tán** (kém đồng đều, kém ổn định, rủi ro hơn). Tất cả chỉ là **giá trị xấp xỉ** cho mẫu gốc.
> 8. $R$ chỉ nhìn hai đầu, rất nhạy với giá trị bất thường; $\Delta_Q$ chỉ nhìn nửa giữa nên **bền**, dùng để phát hiện ngoại lệ: $x>Q_3+1{,}5\Delta_Q$ hoặc $x<Q_1-1{,}5\Delta_Q$.
> 9. $s$ dùng **mọi nhóm**, phản ánh đầy đủ nhất, là thước đo **rủi ro**. Không so sánh $s$ khi hai trung bình chênh nhau rất nhiều hoặc khác đơn vị — khi đó dùng hệ số biến thiên $CV=\dfrac{s}{\bar x}$ (mở rộng, ngoài SGK — xem Bài 10).
> 10. Nhân **mọi tần số** với cùng một số: cả bốn số đặc trưng **không đổi**. Cộng một số vào mọi số liệu: cả bốn **không đổi**. Nhân mọi số liệu với $c>0$: $R$, $\Delta_Q$, $s$ nhân $c$, còn $s^2$ nhân $c^2$.

Chương III ngắn (chỉ hai bài) nhưng **gần như chắc chắn có mặt trong đề tốt nghiệp**: thường là một câu 4 lựa chọn tính $R$ hoặc $Q_1$, một câu Đúng/Sai cho một bảng thực tế, và một câu trả lời ngắn tính $\Delta_Q$ hoặc $s$ có làm tròn. Đây là những điểm "dễ lấy mà dễ mất": công thức không khó, nhưng sai một bước nhỏ (quên bỏ nhóm tần số 0, lấy nhầm tần số tích lũy, đọc nhầm $s_x$) là mất trọn câu. Bài ôn tập này **không giảng lại** — em đã có Bài 9 và Bài 10. Ta làm bốn việc: (1) nhìn cả chương trên **một tấm bản đồ**; (2) tách bạch những thứ **dễ nhầm**; (3) gom các **lỗi sai** hay gặp; (4) luyện **bài tổng hợp** như đề thật, rồi đối chiếu với bài tập cuối chương của SGK.

## 1. Bản đồ của chương

### 1.1. Một bảng ghép nhóm, ba "đường đi"

Mọi bài toán của chương đều bắt đầu từ **một bảng ghép nhóm**. Từ bảng đó, em đi theo một trong ba đường, tùy số đặc trưng cần tính. Mỗi đường cần **một dòng phụ** khác nhau, vì thế việc đầu tiên khi đọc đề là xác định cần dòng phụ nào.

![Hình 1. Bản đồ chương III: từ bảng ghép nhóm, ba đường dẫn đến khoảng biến thiên, khoảng tứ phân vị và phương sai, độ lệch chuẩn](h1-ban-do-chuong.svg)

- **Đường 1 — đầu mút.** Chỉ cần nhìn nhóm đầu và nhóm cuối **có số liệu**. Ra ngay $R$.
- **Đường 2 — tần số tích lũy.** Cần dòng tần số tích lũy để biết số liệu thứ $\frac n4$, $\frac{3n}{4}$ nằm ở nhóm nào, rồi nội suy trong nhóm. Ra $Q_1$, $Q_3$, $\Delta_Q$.
- **Đường 3 — giá trị đại diện.** Thay mỗi nhóm bằng trung điểm của nó, coi mọi số liệu trong nhóm đều bằng trung điểm. Ra $\bar x$, rồi $s^2$, $s$.

**Vì sao cùng một bảng lại cho nhiều "độ phân tán" khác nhau?** Vì mỗi số đặc trưng trả lời một câu hỏi hơi khác: $R$ hỏi *"hai số liệu xa nhau nhất cách nhau bao nhiêu?"*, $\Delta_Q$ hỏi *"một nửa số liệu ở giữa trải rộng bao nhiêu?"*, $s$ hỏi *"trung bình mỗi số liệu cách $\bar x$ bao xa (theo kiểu bình phương)?"*. Ba câu hỏi khác nhau thì kết quả có thể "không đồng ý" với nhau — và đề thi rất thích khai thác chỗ này.

### 1.2. Bốn số đặc trưng trên một bảng

| Số đặc trưng | Cần lập | Dùng thông tin của | Với giá trị bất thường |
|---|---|---|---|
| $R$ (Bài 9) | không cần | hai nhóm ở hai đầu | rất nhạy |
| $\Delta_Q$ (Bài 9) | tần số tích lũy | nhóm chứa $Q_1$, $Q_3$ và số lượng trước chúng | **ít bị ảnh hưởng** |
| $s^2$ (Bài 10) | giá trị đại diện | mọi nhóm | khá nhạy |
| $s$ (Bài 10) | giá trị đại diện | mọi nhóm | khá nhạy |

Thêm hai điều cần nhớ:

- **Đơn vị:** $R$, $\Delta_Q$, $s$ cùng đơn vị với số liệu, còn $s^2$ có đơn vị là **bình phương** đơn vị số liệu.
- **Dùng tốt nhất khi:** $R$ để ước lượng nhanh, $\Delta_Q$ khi dữ liệu có giá trị bất thường và để phát hiện ngoại lệ, $s$ để so sánh độ ổn định và **đo rủi ro** ($s^2$ chủ yếu là bước tính trung gian).

Hình 2 đặt ba thước đo lên **cùng một biểu đồ** (số liệu Ví dụ 1 ở mục 4): $R$ phủ từ mép trái đến mép phải; $\Delta_Q$ chỉ phủ nửa giữa; còn đoạn từ $\bar x-s$ đến $\bar x+s$ nằm quanh trung bình.

![Hình 2. Ba thước đo độ phân tán trên cùng một mẫu (Ví dụ 1): R phủ cả hai đầu, ΔQ phủ nửa giữa, đoạn từ x̄ − s đến x̄ + s nằm quanh trung bình](h2-ba-thuoc-do.svg)

### 1.3. Gặp câu hỏi nào — dùng công cụ nào

| Đề hỏi | Công cụ | Xem lại |
|---|---|---|
| "khoảng biến thiên của mẫu ghép nhóm" | đầu mút, bỏ nhóm tần số 0 ở hai đầu | Bài 9 mục 1 |
| "nhóm chứa tứ phân vị thứ nhất/thứ ba" | tần số tích lũy so với $\frac n4$, $\frac{3n}{4}$ | Bài 9 mục 2.1 |
| "tính $Q_1$, $Q_3$, khoảng tứ phân vị" | công thức nội suy, giữ phân số đến cuối | Bài 9 mục 2 |
| "giá trị nào là giá trị ngoại lệ" | ngưỡng $Q_1-1{,}5\Delta_Q$, $Q_3+1{,}5\Delta_Q$ | Bài 9 mục 2.3 |
| "số trung bình, phương sai, độ lệch chuẩn" | giá trị đại diện, dạng tính nhanh hoặc máy ($\sigma_x$) | Bài 10 mục 1 |
| "đồng đều hơn / ổn định hơn / rủi ro hơn" | so sánh **cùng một** số đặc trưng của hai mẫu | Bài 9 mục 3, Bài 10 mục 2 |
| "trung bình chênh nhau nhiều / khác đơn vị" | hệ số biến thiên $CV=\frac{s}{\bar x}$ (mở rộng, ngoài SGK) | Bài 10 mục 2.2 |
| "nếu nhân/thay tần số, cộng/nhân số liệu thì…" | tính chất biến đổi (mục 2.2 bên dưới) | Bài 9, Bài 10 |

> [!meo] Ba câu tự hỏi trước khi đặt bút
> 1. **Đề hỏi số đặc trưng nào?** Gạch chân: "khoảng biến thiên", "khoảng tứ phân vị", "phương sai" hay "độ lệch chuẩn". Hai chữ cuối là hai đại lượng **khác nhau**.
> 2. **Cần dòng phụ nào?** Tứ phân vị cần tần số tích lũy. Trung bình, phương sai cần giá trị đại diện. Lập dòng phụ **ngay dưới bảng** trước khi tính.
> 3. **Làm tròn ở đâu?** Giữ phân số (hoặc giá trị máy) đến bước cuối, chỉ làm tròn kết quả mà đề hỏi.

## 2. Bảng so sánh – phân biệt

### 2.1. Tứ phân vị dùng đầu mút, phương sai dùng trung điểm

Hai công thức của chương "nhìn" một nhóm theo hai cách khác nhau, và đây là gốc của rất nhiều lỗi:

| | Tứ phân vị (Bài 9) | Số trung bình, phương sai (Bài 10) |
|---|---|---|
| Giả thiết về số liệu trong nhóm | **rải đều** trên cả nhóm | **dồn hết** về trung điểm |
| Số từ nhóm đi vào công thức | đầu mút trái $a_p$ và độ dài nhóm | giá trị đại diện $x_i=\frac{a_i+a_{i+1}}{2}$ |
| Tần số đi vào công thức | tần số tích lũy **trước** nhóm và tần số của nhóm | tần số **mọi** nhóm |
| Trên máy tính | **không** bấm được (máy cho $Q_1$, $Q_3$ kiểu mẫu gốc) | bấm được: $\bar x$, $\sigma_x^2$, $\sigma_x$ |

> [!bay]
> Máy tính cầm tay cũng hiện $Q_1$, $Q_3$ khi em nhập giá trị đại diện và tần số, nhưng đó là tứ phân vị của **mẫu gốc** gồm các trung điểm, **khác** công thức nội suy của SGK. Đề hỏi tứ phân vị của mẫu ghép nhóm thì phải tính tay theo công thức ở Bài 9.

### 2.2. Biến đổi số liệu và tần số — số nào đổi, số nào không?

Đây là dạng câu lí thuyết rất hay ra (SGK có câu 3.13). Hãy hiểu **vì sao** thay vì học thuộc:

| Thao tác | Kết quả | Vì sao |
|---|---|---|
| Cộng cùng số $c$ vào mọi số liệu (mọi đầu mút cộng $c$) | cả bốn số **không đổi** | cả mẫu chỉ "trượt" đi, không giãn ra |
| Nhân mọi số liệu với $c>0$ (đổi đơn vị) | $R$, $\Delta_Q$, $s$ nhân $c$; $s^2$ nhân $c^2$ | mọi khoảng cách giãn $c$ lần |
| **Nhân** mọi tần số với cùng một số | cả bốn số **không đổi** | tỉ lệ giữa các nhóm giữ nguyên |
| **Thay** mọi tần số bằng cùng một số | $R$ không đổi; $\Delta_Q$, $s^2$, $s$ thường thay đổi | các nhóm vẫn có số liệu nhưng tỉ lệ đã khác |
| Kéo dài nhóm cuối ra xa (thêm giá trị rất lớn) | $R$ tăng mạnh; $\Delta_Q$ gần như không đổi; $s^2$, $s$ tăng | $\Delta_Q$ chỉ nhìn nửa giữa |

**Chú ý hai chữ "nhân" và "thay".** "Nhân mọi tần số với 4" thì bảng chỉ là bảng cũ "phóng to", mọi số đặc trưng giữ nguyên. "Thay mọi tần số **bằng** 4" thì các nhóm thành đông như nhau: số liệu bị kéo ra hai đầu nhiều hơn, $\Delta_Q$ và $s$ thay đổi. Chỉ có $R$ chắc chắn không đổi, vì nhóm đầu và nhóm cuối vẫn có số liệu (với bảng ban đầu không có nhóm tần số 0).

> [!nen-tang] Vì sao nhân mọi tần số thì tứ phân vị không đổi?
> Giả sử mọi tần số được nhân với cùng một số $t>0$.
> Khi đó cỡ mẫu thành $tn$, vị trí thành $\frac{r\cdot tn}{4}$, tần số tích lũy trước nhóm thành $tC$, tần số nhóm thành $tm_p$. Thế vào công thức, $t$ ở tử và mẫu **giản ước hết**:
> $$\dfrac{\frac{rtn}{4}-tC}{tm_p}=\dfrac{\frac{rn}{4}-C}{m_p}.$$
> Với phương sai cũng vậy: $\dfrac{\sum tm_i(x_i-\bar x)^2}{tn}=\dfrac{\sum m_i(x_i-\bar x)^2}{n}$.

### 2.3. Các cặp dễ nhầm

| Cặp | Phân biệt |
|---|---|
| **Phương sai** – **độ lệch chuẩn** | $s^2$ (đơn vị bình phương) – $s=\sqrt{s^2}$ (cùng đơn vị số liệu). Đề cho $s=3$ thì $s^2=9$ |
| $\sigma_x$ – $s_x$ trên máy | chia $n$ (là $s$ của SGK) – chia $n-1$ (là $\hat s$). Đề hỏi độ lệch chuẩn thì đọc $\sigma_x$ |
| **Mẫu gốc** – **mẫu ghép nhóm** | số đặc trưng của mẫu gốc là chính xác; của mẫu ghép nhóm là **xấp xỉ**. Riêng $R$ của mẫu ghép nhóm luôn **lớn hơn** $R$ của mẫu gốc |
| **Đầu mút** – **giá trị đại diện** | $R$, $Q_r$ dùng đầu mút; $\bar x$, $s^2$ dùng trung điểm |
| **Phân tán hơn** – **lớn hơn** | phân tán là "trải rộng", không phải "có giá trị lớn". Trung bình lớn hơn **không** có nghĩa là phân tán hơn |
| **Đồng đều / ổn định / ít rủi ro** – **phân tán / rủi ro** | ba chữ đầu ứng với số đặc trưng **nhỏ hơn**; hai chữ sau ứng với số đặc trưng **lớn hơn** |
| $\Delta_Q$ – $s$ | $\Delta_Q$ là độ dài khoảng chứa nửa giữa; $s$ là "khoảng cách trung bình" đến $\bar x$. Hai số khác nhau, không thay cho nhau được |
| **Độ lệch chuẩn** – **hệ số biến thiên** | $s$ đo phân tán tuyệt đối (có đơn vị); $CV=\frac{s}{\bar x}$ đo phân tán tương đối (không đơn vị, so sánh được hai mẫu có quy mô khác nhau) |

### 2.4. Khi $R$, $\Delta_Q$, $s$ "không đồng ý" với nhau

Ba thước đo có thể cho **kết luận trái ngược** khi so sánh hai mẫu. Quy tắc chọn:

- Mẫu có **vài giá trị lẻ loi ở hai đầu** (nhóm đầu, nhóm cuối tần số rất nhỏ, có nhóm trống xen giữa) → tin $\Delta_Q$, vì $R$ bị vài giá trị đó "kéo dài".
- Cần đánh giá **độ ổn định, độ rủi ro** dùng mọi số liệu → dùng $s$ (đề thường nói rõ "dựa vào độ lệch chuẩn").
- Hai mẫu có **cùng $R$** → $R$ không phân biệt được, phải dùng $\Delta_Q$ hoặc $s$.
- Đề **chỉ định** số đặc trưng nào thì dùng đúng số đó, kể cả khi số khác cho kết luận ngược lại.

## 3. Lỗi sai hay gặp của cả chương

> [!bay] Bài 9 — khoảng biến thiên, tứ phân vị
> - **1.** **Không bỏ nhóm tần số 0 ở hai đầu** khi tính $R$. Nhóm tần số 0 nằm **giữa** thì không ảnh hưởng.
> - **2.** **Lấy trung điểm thay cho đầu mút** khi tính $R$ (ra $R$ nhỏ hơn đúng một độ dài nhóm), hoặc nhầm $R$ với độ dài một nhóm.
> - **3.** **Chọn nhầm nhóm chứa $Q_r$**: phải là nhóm **đầu tiên** có tần số tích lũy $\ge\frac{rn}{4}$. Hay chọn nhóm liền sau, hoặc chọn nhóm có tần số lớn nhất.
> - **4.** **Trừ nhầm tần số tích lũy của chính nhóm** thay vì tổng các nhóm **đứng trước** nó.
> - **5.** **Quên nhân độ dài nhóm**, hoặc nhân với $a_p$ thay vì $a_{p+1}-a_p$.
> - **6.** **Dùng $\frac n4$ khi tính $Q_3$** (phải là $\frac{3n}{4}$).
> - **7.** **Làm tròn $Q_1$, $Q_3$ quá sớm** rồi mới trừ, làm lệch chữ số cuối của $\Delta_Q$.
> - **8.** **Kết luận ngoại lệ khi chưa tính đủ chính xác** — giá trị sát ngưỡng $Q_3+1{,}5\Delta_Q$ phải tính ngưỡng bằng phân số.

> [!bay] Bài 10 — phương sai, độ lệch chuẩn
> - **9.** **Nhập đầu mút** (thay vì trung điểm) vào máy, hoặc quên nhập cột tần số.
> - **10.** **Đọc $s_x$ thay vì $\sigma_x$**. Hai số rất gần nhau nên luôn có mặt trong phương án nhiễu.
> - **11.** **Nhầm phương sai với độ lệch chuẩn** — đặc biệt trong câu Đúng/Sai: "phương sai xấp xỉ 2,26" mà 2,26 thực ra là $s$.
> - **12.** **Dạng tính nhanh: quên bình phương $\bar x$**, hoặc làm tròn $\bar x$ quá sớm khi số liệu lớn.
> - **13.** **"$s$ lớn hơn thì tốt hơn"** — ngược lại: với độ ổn định, $s$ **nhỏ** hơn mới tốt hơn.
> - **14.** **So sánh $s$ của hai mẫu có trung bình chênh nhau rất nhiều** (quán nhỏ và siêu thị) — phải dùng $CV$.

> [!bay] Lỗi chung cả chương
> - **15.** **Dùng hai số đặc trưng khác nhau cho hai mẫu** (ví dụ $R$ của mẫu này so với $\Delta_Q$ của mẫu kia). Phải so sánh **cùng một** số đặc trưng.
> - **16.** **Quên đơn vị** hoặc ghi sai đơn vị: $s^2$ có đơn vị bình phương (phút², kg²), các số còn lại cùng đơn vị số liệu.
> - **17.** **Coi số đặc trưng của mẫu ghép nhóm là chính xác.** Chúng chỉ xấp xỉ mẫu gốc. Câu Đúng/Sai hay hỏi "bằng" hay "xấp xỉ".

## 4. Bài tổng hợp

Năm bài dưới đây phối hợp **cả hai bài** của chương và bám ba dạng đề tốt nghiệp. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Một bảng — đủ bốn số đặc trưng

> [!vi-du] Ví dụ 1 (Bài 9 + Bài 10 — cùng dạng SGK Bài tập 3.14)
> Một phòng kiểm nghiệm đo **thời gian rã** (thời gian để viên thuốc rã hoàn toàn trong nước ở 37 °C) của 40 viên nén lấy ngẫu nhiên từ một lô:
>
> | Thời gian rã (phút) | [4; 6) | [6; 8) | [8; 10) | [10; 12) | [12; 14) |
> |---|---|---|---|---|---|
> | Số viên | 3 | 9 | 15 | 9 | 4 |
>
> a) Tính khoảng biến thiên, khoảng tứ phân vị của mẫu số liệu.
>
> b) Tính số trung bình, phương sai và độ lệch chuẩn (làm tròn độ lệch chuẩn đến hàng phần trăm).
>
> c) Kiểm tra thêm một viên của lô thấy rã hết $16$ phút. Theo quy tắc khoảng tứ phân vị, đây có phải giá trị ngoại lệ không?

> [!goi-y] Gợi ý 1
> Lập ngay hai dòng phụ dưới bảng. Tần số tích lũy: $3;\ 12;\ 27;\ 36;\ 40$. Giá trị đại diện: $5;\ 7;\ 9;\ 11;\ 13$.

> [!goi-y] Gợi ý 2
> $\frac n4=10$ và $\frac{3n}{4}=30$. Nhóm đầu tiên có tần số tích lũy $\ge10$ là $[6;8)$, nhóm đầu tiên có tần số tích lũy $\ge30$ là $[10;12)$.

> [!goi-y] Gợi ý 3
> c) Tính ngưỡng trên $Q_3+1{,}5\Delta_Q$ bằng phân số: $Q_3=\frac{32}{3}$, $\Delta_Q=\frac{28}{9}$.

> [!loi-giai] Lời giải
> **a)** $R=14-4=10$ (phút).
>
> $Q_1=6+\dfrac{10-3}{9}\cdot2=\dfrac{68}{9}\approx7{,}56$; $Q_3=10+\dfrac{30-27}{9}\cdot2=\dfrac{32}{3}\approx10{,}67$.
>
> $\Delta_Q=\dfrac{32}{3}-\dfrac{68}{9}=\dfrac{28}{9}\approx3{,}11$ (phút).
>
> **b)** $\sum m_ix_i=3\cdot5+9\cdot7+15\cdot9+9\cdot11+4\cdot13=364$, nên $\bar x=\dfrac{364}{40}=9{,}1$ (phút).
>
> $\sum m_ix_i^2=75+441+1215+1089+676=3496$, nên $\dfrac1n\sum m_ix_i^2=\dfrac{3496}{40}=87{,}4$ và $s^2=87{,}4-9{,}1^2=87{,}4-82{,}81=4{,}59$.
>
> $s=\sqrt{4{,}59}\approx2{,}14$ (phút). (Máy: $\sigma_x\approx2{,}1424$; nếu đọc nhầm $s_x$ sẽ được $2{,}17$.)
>
> **c)** $Q_3+1{,}5\Delta_Q=\dfrac{32}{3}+\dfrac{14}{3}=\dfrac{46}{3}\approx15{,}33$. Vì $16>15{,}33$ nên viên rã hết $16$ phút **là giá trị ngoại lệ** — phòng kiểm nghiệm cần xem lại viên này. (Ngưỡng dưới $Q_1-1{,}5\Delta_Q=\dfrac{26}{9}\approx2{,}89$ phút.)
>
> **Ý nghĩa:** thời gian rã trung bình khoảng $9{,}1$ phút, một nửa số viên ở giữa rã trong một khoảng dài chừng $3{,}1$ phút (từ khoảng $7{,}6$ đến $10{,}7$ phút), độ lệch chuẩn khoảng $2{,}1$ phút. Hình 2 vẽ lại cả ba thước đo trên biểu đồ.

> [!ung-dung] Vì sao nhà sản xuất thuốc quan tâm đến độ phân tán?
> Hai lô thuốc có cùng thời gian rã **trung bình** vẫn có thể rất khác nhau: lô có độ lệch chuẩn lớn sẽ có viên rã quá nhanh, viên rã quá chậm, nên lượng hoạt chất vào máu không đều giữa các lần uống. Vì vậy trong kiểm nghiệm, ngoài trung bình người ta luôn theo dõi độ phân tán, và loại riêng những viên "ngoại lệ" ra để tìm nguyên nhân.

### 4.2. Lãi nhiều hơn hay an toàn hơn?

> [!vi-du] Ví dụ 2 (Bài 10 — cùng dạng SGK Bài tập 3.15)
> Một hợp tác xã theo dõi lợi nhuận (triệu đồng/năm, tính trên cùng một diện tích) của 40 hộ trồng cây dược liệu X và 40 hộ trồng cây dược liệu Y:
>
> | Lợi nhuận (triệu đồng) | [0; 6) | [6; 12) | [12; 18) | [18; 24) | [24; 30) |
> |---|---|---|---|---|---|
> | Số hộ trồng X | 4 | 10 | 15 | 9 | 2 |
> | Số hộ trồng Y | 7 | 6 | 7 | 9 | 11 |
>
> a) Về trung bình, trồng cây nào đem lại lợi nhuận cao hơn?
>
> b) Tính độ lệch chuẩn của hai mẫu số liệu (làm tròn đến hàng phần trăm) và giải thích ý nghĩa.

> [!goi-y] Gợi ý 1
> Giá trị đại diện: $3;\ 9;\ 15;\ 21;\ 27$. Bảng **không** đối xứng nên phải tính trung bình thật sự.

> [!goi-y] Gợi ý 2
> $\sum m_ix_i$: X là $570$, Y là $666$. $\sum m_ix_i^2$: X là $9648$, Y là $14\,112$.

> [!goi-y] Gợi ý 3
> b) Hai trung bình có chênh nhau "rất nhiều" không? Nếu không, so sánh trực tiếp hai độ lệch chuẩn được.

> [!loi-giai] Lời giải
> **a)** $\bar x_X=\dfrac{570}{40}=14{,}25$; $\bar x_Y=\dfrac{666}{40}=16{,}65$ (triệu đồng). Trung bình, trồng **Y lãi cao hơn** khoảng $2{,}4$ triệu đồng.
>
> **b)** $s_X^2=\dfrac{9648}{40}-14{,}25^2=241{,}2-203{,}0625=38{,}1375$, nên $s_X\approx6{,}18$ (triệu đồng).
>
> $s_Y^2=\dfrac{14\,112}{40}-16{,}65^2=352{,}8-277{,}2225=75{,}5775$, nên $s_Y\approx8{,}69$ (triệu đồng).
>
> Hai trung bình khá gần nhau nên so sánh trực tiếp được: $s_Y>s_X$, lợi nhuận khi trồng Y **dao động mạnh hơn** — tức **rủi ro hơn**. Bảng cũng cho thấy điều đó: Y có $7$ hộ lãi dưới $6$ triệu, X chỉ có $4$ hộ.
>
> **Kết luận:** Y lãi trung bình cao hơn nhưng rủi ro cao hơn. Hộ nào chấp nhận rủi ro để mong lãi cao có thể chọn Y; hộ cần thu nhập ổn định nên chọn X.

> [!em-co-biet]
> Tính thêm hệ số biến thiên: $CV_X\approx\dfrac{6{,}18}{14{,}25}\approx43\%$, $CV_Y\approx\dfrac{8{,}69}{16{,}65}\approx52\%$. Ngay cả khi tính độ dao động **so với mức lãi** của chính nó, Y vẫn rủi ro hơn. Khoảng tứ phân vị cũng "đồng ý": $\Delta_{Q,X}\approx9{,}07$, $\Delta_{Q,Y}\approx15{,}55$. Trong tài chính, "lãi cao đi kèm rủi ro cao" gần như là một quy luật — người ta gọi là sự đánh đổi giữa lợi nhuận và rủi ro.

### 4.3. Đúng/Sai: thời gian chờ lấy thuốc

> [!vi-du] Ví dụ 3 (Đúng/Sai — Bài 9 + Bài 10)
> Thời gian chờ lấy thuốc (phút) của 40 người bệnh tại nhà thuốc một bệnh viện trong một buổi sáng:
>
> | Thời gian chờ (phút) | [0; 10) | [10; 20) | [20; 30) | [30; 40) | [40; 50) | [50; 60) |
> |---|---|---|---|---|---|---|
> | Số người | 5 | 14 | 12 | 6 | 2 | 1 |
>
> a) Khoảng biến thiên của mẫu số liệu là $60$ phút.
>
> b) Nhóm chứa tứ phân vị thứ nhất là $[0;10)$.
>
> c) Khoảng tứ phân vị của mẫu số liệu xấp xỉ $15{,}6$ phút.
>
> d) Theo quy tắc $x>Q_3+1{,}5\Delta_Q$, mọi người chờ từ $50$ phút trở lên đều là giá trị ngoại lệ.

> [!goi-y] Gợi ý 1
> Tần số tích lũy: $5;\ 19;\ 31;\ 37;\ 39;\ 40$. Vị trí $\frac n4=10$, $\frac{3n}{4}=30$.

> [!goi-y] Gợi ý 2
> d) Tính ngưỡng $Q_3+1{,}5\Delta_Q$ rồi hỏi: người chờ đúng $50$ hay $51$ phút có vượt ngưỡng không?

> [!loi-giai] Lời giải
> a) **Đúng** — nhóm đầu và nhóm cuối đều có người: $R=60-0=60$.
>
> b) **Sai** — tích lũy đến $[0;10)$ mới là $5<10$. Nhóm đầu tiên có tần số tích lũy $\ge10$ là $[10;20)$.
>
> c) **Đúng** — $Q_1=10+\dfrac{10-5}{14}\cdot10=\dfrac{95}{7}\approx13{,}57$; $Q_3=20+\dfrac{30-19}{12}\cdot10=\dfrac{175}{6}\approx29{,}17$; $\Delta_Q=\dfrac{655}{42}\approx15{,}60$.
>
> d) **Sai** — ngưỡng $Q_3+1{,}5\Delta_Q=\dfrac{175}{6}+\dfrac{655}{28}\approx29{,}17+23{,}39=52{,}56$. Người chờ $50$ hay $51$ phút **chưa** vượt ngưỡng, nên không phải ai trong nhóm $[50;60)$ cũng là ngoại lệ.

> [!bay]
> Ý d) gài hai bẫy: (1) "nhóm $[50;60)$ nằm ngoài cùng nên là ngoại lệ" — sai, phải so với **ngưỡng**; (2) ngưỡng $52{,}56$ nằm **giữa** nhóm $[50;60)$, nên với mẫu ghép nhóm ta không biết chắc người trong nhóm đó có phải ngoại lệ hay không. Ngoài ra, độ lệch chuẩn của mẫu này là $s\approx11{,}62$ — nhỏ hơn $\Delta_Q$; đừng nhầm hai số này.

### 4.4. Trả lời ngắn: tần số chưa biết

> [!vi-du] Ví dụ 4 (Bài 9 + Bài 10)
> Chiều dài (cm) của một lô cá giống được ghép nhóm như bảng dưới, trong đó $m$ là số nguyên dương chưa biết:
>
> | Chiều dài (cm) | [10; 12) | [12; 14) | [14; 16) | [16; 18) |
> |---|---|---|---|---|
> | Số con | 4 | $m$ | 10 | 6 |
>
> Biết chiều dài trung bình của mẫu số liệu ghép nhóm là $14$ cm.
>
> a) Tìm $m$.
>
> b) Tính khoảng tứ phân vị (làm tròn đến hàng phần mười) và độ lệch chuẩn (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> $n=20+m$, $\sum m_ix_i=4\cdot11+13m+10\cdot15+6\cdot17=296+13m$. Giải $\dfrac{296+13m}{20+m}=14$.

> [!goi-y] Gợi ý 2
> Có $m$ rồi mới lập được dòng tần số tích lũy. Với $\bar x=14$ là số đẹp, dùng dạng định nghĩa: độ lệch các nhóm so với $14$ là $-3;\ -1;\ 1;\ 3$.

> [!loi-giai] Lời giải
> **a)** $296+13m=14(20+m)=280+14m\Rightarrow m=16$, nên $n=36$.
>
> **b)** Tần số tích lũy: $4;\ 20;\ 30;\ 36$. $\frac n4=9$ → nhóm $[12;14)$; $\frac{3n}{4}=27$ → nhóm $[14;16)$.
>
> $Q_1=12+\dfrac{9-4}{16}\cdot2=12{,}625$; $Q_3=14+\dfrac{27-20}{10}\cdot2=15{,}4$; $\Delta_Q=2{,}775\approx2{,}8$ (cm).
>
> $\sum m_i(x_i-\bar x)^2=4\cdot9+16\cdot1+10\cdot1+6\cdot9=116$, nên $s^2=\dfrac{116}{36}=\dfrac{29}{9}$ và $s=\dfrac{\sqrt{29}}{3}\approx1{,}80$ (cm).

> [!bay]
> Quên rằng $m$ cũng nằm trong **mẫu số** $n=20+m$ là lỗi số 1 của dạng này. Lỗi số 2: chưa tìm $m$ đã vội lập tần số tích lũy. Lỗi số 3: làm tròn $\bar x$ hay $s^2$ giữa chừng — ở đây giữ $s^2=\frac{29}{9}$ rồi mới khai căn.

### 4.5. Đổi đơn vị, nhân tần số, thay tần số

> [!vi-du] Ví dụ 5 (Bài 9 + Bài 10 — cùng dạng SGK Bài tập 3.12, 3.13)
> Cân nặng (kg) của 30 trẻ sơ sinh tại một khoa sản trong một tuần:
>
> | Cân nặng (kg) | [2,0; 2,5) | [2,5; 3,0) | [3,0; 3,5) | [3,5; 4,0) | [4,0; 4,5) |
> |---|---|---|---|---|---|
> | Số trẻ | 2 | 6 | 12 | 8 | 2 |
>
> a) Tính $R$, $\Delta_Q$ và $s$ (làm tròn đến hàng phần trăm).
>
> b) Nếu đổi số liệu sang gam thì bốn số $R$, $\Delta_Q$, $s^2$, $s$ thay đổi thế nào?
>
> c) Tuần sau, số trẻ ở mỗi nhóm đều gấp ba tuần này. Các số đặc trưng có đổi không?
>
> d) Một bạn lập bảng nhầm: ghi **tất cả** tần số bằng $6$. Số đặc trưng nào của bảng nhầm vẫn bằng của bảng đúng?

> [!goi-y] Gợi ý 1
> a) Để tính $s$ gọn, đặt $u=\dfrac{x-3{,}25}{0{,}5}$: các giá trị đại diện $2{,}25;\ 2{,}75;\ \dots;\ 4{,}25$ thành $u=-2;\ -1;\ 0;\ 1;\ 2$ (xem mẹo đổi biến ở Bài 10).

> [!goi-y] Gợi ý 2
> b) $1$ kg $=1000$ g: mọi số liệu nhân $1000$. c) Nhân mọi tần số với $3$. d) **Thay** chứ không phải **nhân** — tính lại thử $\Delta_Q$.

> [!loi-giai] Lời giải
> **a)** $R=4{,}5-2{,}0=2{,}5$ (kg). Tần số tích lũy $2;\ 8;\ 20;\ 28;\ 30$, $\frac n4=7{,}5$, $\frac{3n}{4}=22{,}5$:
>
> $Q_1=2{,}5+\dfrac{7{,}5-2}{6}\cdot0{,}5\approx2{,}958$; $Q_3=3{,}5+\dfrac{22{,}5-20}{8}\cdot0{,}5=3{,}65625$; $\Delta_Q\approx0{,}70$ (kg).
>
> Với $u$:
> $$\bar u=\dfrac{-4-6+0+8+4}{30}=\dfrac1{15},$$
> $$s_u^2=\dfrac{8+6+0+8+8}{30}-\dfrac1{225}=\dfrac{224}{225}.$$
> Suy ra $s^2=0{,}5^2\cdot\dfrac{224}{225}=\dfrac{56}{225}\approx0{,}249$ và $s\approx0{,}50$ (kg). (Trung bình $\bar x=3{,}25+0{,}5\cdot\frac1{15}\approx3{,}28$ kg.)
>
> **b)** Nhân mọi số liệu với $1000$: $R=2500$ g, $\Delta_Q\approx698$ g, $s\approx499$ g (đều nhân $1000$), còn $s^2$ nhân $1000^2=10^6$, thành khoảng $248\,889$ g².
>
> **c)** Nhân mọi tần số với $3$ ($n=90$): **cả bốn số không đổi** — tỉ lệ các nhóm giữ nguyên.
>
> **d)** Bảng nhầm có tần số $6;6;6;6;6$ ($n=30$). Nhóm đầu và nhóm cuối vẫn có số liệu nên **$R=2{,}5$ kg không đổi**. Nhưng $\Delta_Q=3{,}875-2{,}625=1{,}25$ kg và $s=\sqrt{0{,}5}\approx0{,}71$ kg — đều **lớn hơn** bảng đúng, vì các nhóm ở hai đầu bị "thêm người". Vậy chỉ có **khoảng biến thiên** là giữ nguyên.

## 5. Đối chiếu "Bài tập cuối chương III" (SGK tr. 85–86)

Bảng dưới cho biết mỗi bài tập của SGK kiểm tra điều gì, nên xem lại ở đâu, kèm một **bài tự luyện cùng dạng** (số liệu khác). Làm xong, mở đáp số bên dưới để tự chấm.

| SGK | Kiểm tra | Xem lại | Bài tự luyện |
|---|---|---|---|
| 3.9 | Khoảng biến thiên | Bài 9 mục 1 | T1 câu a |
| 3.10, 3.11 | Nhóm chứa $Q_1$, $Q_3$ | Bài 9 mục 2.1 | T1 câu b |
| 3.12 | Số đặc trưng nào không phụ thuộc nhóm đầu, nhóm cuối | Mục 1.2, 2.2 ở trên | T2 câu a |
| 3.13 | Thay tần số thì số nào không đổi | Mục 2.2; Ví dụ 5 | T2 câu b |
| 3.14 | Tính $R$, $\Delta_Q$, $s$ của một mẫu | Ví dụ 1 | T3 |
| 3.15 | So sánh trung bình và độ lệch chuẩn hai lĩnh vực đầu tư | Bài 10 mục 2; Ví dụ 2 | Ví dụ 2 |
| 3.16 | Tính các số đặc trưng đo độ phân tán, nêu ý nghĩa | Ví dụ 1 | T4 |
| 3.17 | So sánh độ ổn định của hai dụng cụ đo | Bài 10 Ví dụ 2, Ví dụ 8 | T5 |

**T1.** Thời gian sử dụng (năm) đến khi hỏng của 24 chiếc máy giặt cùng loại:

| Thời gian (năm) | [6; 7) | [7; 8) | [8; 9) | [9; 10) | [10; 11) |
|---|---|---|---|---|---|
| Số máy | 2 | 5 | 9 | 6 | 2 |

a) Tính khoảng biến thiên. b) Tìm nhóm chứa $Q_1$, nhóm chứa $Q_3$, rồi tính $\Delta_Q$.

**T2.** Với bảng T1: a) Nếu hai máy bền nhất thật ra dùng được $14$ năm (nhóm $[10;11)$ được thay bằng nhóm $[14;15)$, các nhóm $[10;11),\dots,[13;14)$ có tần số $0$), thì $R$, $\Delta_Q$, $s$ thay đổi thế nào? b) Nếu thay tất cả các tần số bằng $3$ thì số đặc trưng nào trong bốn số $R$, $\Delta_Q$, $s^2$, $s$ không đổi?

**T3.** Khối lượng (kg) của 50 quả dưa lưới thu hoạch trong một ngày:

| Khối lượng (kg) | [1,0; 1,5) | [1,5; 2,0) | [2,0; 2,5) | [2,5; 3,0) | [3,0; 3,5) |
|---|---|---|---|---|---|
| Số quả | 4 | 10 | 18 | 12 | 6 |

Tính khoảng biến thiên, khoảng tứ phân vị và độ lệch chuẩn của mẫu số liệu.

**T4.** Thành tích nhảy xa (m) của 20 học sinh nam tại hội khỏe Phù Đổng cấp trường:

| Thành tích (m) | [4,0; 4,2) | [4,2; 4,4) | [4,4; 4,6) | [4,6; 4,8) |
|---|---|---|---|---|
| Số học sinh | 2 | 8 | 7 | 3 |

Tính các số đặc trưng đo mức độ phân tán. Chúng cho biết điều gì về thành tích của các bạn?

**T5.** Lan và Huệ dùng hai chiếc cân khác nhau, mỗi bạn cân $10$ lần cùng một gói dược liệu:

| Khối lượng đo được (g) | [99,0; 99,5) | [99,5; 100,0) | [100,0; 100,5) | [100,5; 101,0) |
|---|---|---|---|---|
| Số lần Lan cân | 1 | 5 | 3 | 1 |
| Số lần Huệ cân | 2 | 3 | 3 | 2 |

Tính độ lệch chuẩn của hai mẫu số liệu. Chiếc cân của bạn nào cho kết quả ổn định hơn?

> [!loi-giai] Đáp số bài tự luyện T1–T5
> - **T1.** a) $R=11-6=5$ năm. b) Tần số tích lũy $2;\ 7;\ 16;\ 22;\ 24$. $\frac n4=6$ nên $Q_1$ thuộc $[7;8)$, $Q_1=7+\frac{6-2}{5}=7{,}8$. $\frac{3n}{4}=18$ nên $Q_3$ thuộc $[9;10)$, $Q_3=9+\frac{18-16}{6}\approx9{,}33$. $\Delta_Q\approx1{,}53$ năm.
> - **T2.** a) $R$ tăng từ $5$ lên $9$ năm. $\Delta_Q$ **không đổi** ($Q_1$, $Q_3$ vẫn như cũ vì chỉ phụ thuộc các nhóm giữa). $s$ tăng từ khoảng $1{,}06$ lên khoảng $1{,}91$ năm. b) Chỉ có **$R$** không đổi. Thật vậy, với $n=15$ thì $\Delta_Q=9{,}75-7{,}25=2{,}5$ năm và $s=\sqrt2\approx1{,}41$ năm, đều khác bảng cũ.
> - **T3.** $R=2{,}5$ kg. $Q_1=1{,}925$, $Q_3\approx2{,}729$, $\Delta_Q\approx0{,}80$ kg. $\bar x=2{,}31$ kg, $s^2\approx0{,}306$, $s\approx0{,}55$ kg.
> - **T4.** $R=0{,}8$ m. $Q_1=4{,}275$, $Q_3\approx4{,}543$, $\Delta_Q\approx0{,}27$ m. $\bar x=4{,}41$ m, $s^2=0{,}0299$, $s\approx0{,}17$ m. Thành tích của các bạn khá đồng đều: một nửa số bạn ở giữa chỉ chênh nhau khoảng $27$ cm, và các thành tích lệch khỏi mức trung bình $4{,}41$ m chỉ khoảng $17$ cm.
> - **T5.** Lan: $\bar x=99{,}95$ g, $s^2=0{,}16$, $s=0{,}4$ g. Huệ: $\bar x=100$ g, $s\approx0{,}51$ g. Hai trung bình gần như bằng nhau và độ lệch chuẩn của Lan nhỏ hơn của Huệ, nên cân của **Lan** cho kết quả ổn định hơn.

## Tóm tắt — danh sách kiểm tra trước giờ thi

Mẫu ghép nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$, tần số $m_1,\dots,m_k$, cỡ mẫu $n$, giá trị đại diện $x_i$.

| Số đặc trưng | Công thức | Nhớ ngay |
|---|---|---|
| Khoảng biến thiên | $R=a_{k+1}-a_1$ | bỏ nhóm tần số 0 ở hai đầu; luôn lớn hơn $R$ của mẫu gốc |
| Tứ phân vị | ${Q_r=a_p+\dfrac{\frac{rn}{4}-C}{m_p}\cdot h}$ | nhóm $[a_p;a_{p+1})$ là nhóm đầu tiên có tần số tích lũy $\ge\frac{rn}{4}$; $C=m_1+\dots+m_{p-1}$ (các nhóm **trước**); $h=a_{p+1}-a_p$ |
| Khoảng tứ phân vị | $\Delta_Q=Q_3-Q_1$ | độ dài khoảng chứa 50% ở giữa; bền với giá trị bất thường |
| Giá trị ngoại lệ | ${x>Q_3+1{,}5\Delta_Q}$ hoặc ${x<Q_1-1{,}5\Delta_Q}$ | tính ngưỡng bằng phân số khi sát ngưỡng |
| Số trung bình | $\bar x=\dfrac{\sum m_ix_i}{n}$ | dùng trung điểm, không dùng đầu mút |
| Phương sai | $s^2=\dfrac1n\sum m_ix_i^2-\bar x^2$ | đơn vị bình phương; máy: $\sigma_x^2$ |
| Độ lệch chuẩn | $s=\sqrt{s^2}$ | máy: $\sigma_x$, không phải $s_x$; đo rủi ro, độ ổn định |
| Hệ số biến thiên (mở rộng, ngoài SGK) | $CV=\dfrac{s}{\bar x}$ | khi trung bình chênh nhau nhiều hoặc khác đơn vị |
| Biến đổi | cộng $c$: không đổi; nhân $c$: $R,\Delta_Q,s$ nhân $c$, $s^2$ nhân $c^2$ | nhân mọi tần số: không đổi; **thay** mọi tần số bằng nhau: chỉ $R$ chắc chắn không đổi |

**Sơ đồ một dòng:** *bảng ghép nhóm → (đầu mút → $R$) · (tần số tích lũy → $Q_1$, $Q_3$ → $\Delta_Q$ → ngoại lệ) · (giá trị đại diện → $\bar x$ → $s^2$ → $s$) → so sánh cùng một số đặc trưng: lớn hơn là phân tán hơn.*
