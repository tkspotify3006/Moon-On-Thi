---
title: Ôn tập chương II
thoi-gian: 60 phút
muc-tieu:
  - Hệ thống hóa toàn chương II — vectơ trong không gian, hệ trục tọa độ Oxyz, biểu thức tọa độ của các phép toán vectơ — và thấy ba bài là cùng một kiến thức viết bằng hai "ngôn ngữ": hình học và tọa độ
  - Phân biệt chắc chắn các cặp dễ nhầm (cùng phương – cùng hướng – bằng nhau, hình chiếu – đối xứng, trục – mặt phẳng tọa độ, góc giữa hai vectơ – góc giữa hai đường thẳng, tích vô hướng – tích của số với vectơ…)
  - Nhận ra và tránh các lỗi sai hay gặp nhất của chương trong đề thi
  - Giải được các bài tổng hợp phối hợp nhiều bài, theo đúng ba dạng đề tốt nghiệp (4 lựa chọn, Đúng/Sai, trả lời ngắn), kể cả bài thực tế
  - Tự làm được các dạng của "Bài tập cuối chương II" (SGK tr. 73–74)
---
> [!ghi-nho] Chương này trong 10 dòng
> 1. Vectơ trong không gian vẫn là **đoạn thẳng có hướng**. Cùng phương, cùng hướng, bằng nhau, đối nhau định nghĩa **như lớp 10** (Bài 6).
> 2. Cộng vectơ: quy tắc **ba điểm**, **hình bình hành** và quy tắc mới — **hình hộp** $\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}=\overrightarrow{AC'}$.
> 3. Trừ vectơ: $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$. Cùng phương: $\vec a=k\vec b$. Trung điểm, trọng tâm tam giác, trọng tâm tứ diện có hệ thức vectơ riêng.
> 4. Góc giữa hai vectơ: **dời về chung gốc**, từ $0^\circ$ đến $180^\circ$. Tích vô hướng $\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b)$ là **một số**.
> 5. Hệ $Oxyz$: ba trục đôi một vuông góc, $\vec i,\vec j,\vec k$ dài 1. $M(x;y;z)\iff\overrightarrow{OM}=x\vec i+y\vec j+z\vec k$ (Bài 7).
> 6. **Cuối trừ đầu**: $\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$. Hai vectơ bằng nhau khi ba tọa độ bằng nhau.
> 7. Hình chiếu: lên **trục** thì **giữ** tọa độ của trục, lên **mặt phẳng** thì **xóa** tọa độ vắng tên. Đối xứng: **qua cái gì giữ cái đó, còn lại đổi dấu**.
> 8. Cộng, trừ, nhân số: **làm riêng từng tọa độ**. Trung điểm, trọng tâm: **trung bình cộng**. Hình bình hành $ABCD$: $A+C=B+D$ (Bài 8).
> 9. $\vec a\cdot\vec b=xx'+yy'+zz'$, $\lvert\vec a\rvert=\sqrt{x^2+y^2+z^2}$, $\cos(\vec a,\vec b)=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$, vuông góc khi tích vô hướng bằng 0.
> 10. Bài thực tế: **chọn hệ trục → viết tọa độ → dịch câu hỏi** thành vectơ (dịch chuyển), độ dài (khoảng cách), tích vô hướng (góc, công của lực).

Chương II ngắn (ba bài) nhưng có mặt ở **mọi** đề tốt nghiệp: vài câu 4 lựa chọn "tính nhanh" bằng tọa độ, thường có một câu Đúng/Sai về hình hộp hoặc một tình huống thực tế (phòng học, drone, đèn treo), và một câu trả lời ngắn có làm tròn. Hơn nữa, chương này là **nền móng** cho Chương V (phương trình mặt phẳng, đường thẳng, mặt cầu) ở Tập hai — chắc chương II thì Chương V nhẹ đi một nửa.

Bài ôn tập này **không giảng lại** từng định nghĩa — em đã có Bài 6, 7, 8. Ở đây ta làm ba việc: (1) nhìn cả chương như **một cuốn từ điển hai ngôn ngữ**; (2) tách bạch những thứ **dễ nhầm**; (3) luyện **bài tổng hợp** phối hợp nhiều bài như trong đề thật.

## 1. Bản đồ của chương

### 1.1. Một kiến thức, hai ngôn ngữ

Cả chương thực ra chỉ có **một** đối tượng — vectơ — được mô tả bằng hai cách:

- **Ngôn ngữ hình học** (Bài 6): vectơ là mũi tên trên hình. Ta cộng bằng cách nối đuôi, đo góc bằng cách dời về chung gốc. Mạnh khi hình có **nhiều đối xứng** (hình hộp, tứ diện đều), đề không cho tọa độ.
- **Ngôn ngữ tọa độ** (Bài 7, 8): vectơ là bộ ba số. Ta cộng, trừ, nhân từng tọa độ, tính góc bằng công thức. Mạnh khi đề **cho sẵn tọa độ**, hoặc hình có **ba cạnh đôi một vuông góc** để gắn trục.

Cầu nối giữa hai ngôn ngữ là **hệ trục $Oxyz$** (Bài 7): ba vectơ đơn vị $\vec i,\vec j,\vec k$ chính là ba cạnh của một hình lập phương cạnh 1, và tọa độ điểm $M$ có được nhờ **quy tắc hình hộp** $\overrightarrow{OM}=\overrightarrow{OM_1}+\overrightarrow{OM_2}+\overrightarrow{OM_3}$.

![Hình 1. Từ điển hai ngôn ngữ của chương II: mỗi quy tắc hình học của Bài 6 có một "bản dịch" bằng tọa độ ở Bài 7, Bài 8](h1-tu-dien-chuong.svg)

| Hình học (Bài 6) | Tọa độ (Bài 7, 8) | Vì sao khớp nhau |
|---|---|---|
| Quy tắc trừ $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$ | $\overrightarrow{AB}=B-A$ (cuối trừ đầu) | tọa độ của $\overrightarrow{OA}$ là tọa độ của $A$ |
| Hai vectơ bằng nhau (cùng hướng, cùng độ dài) | ba tọa độ bằng nhau | tọa độ của vectơ là duy nhất |
| $\overrightarrow{OA}+\overrightarrow{OB}=2\overrightarrow{OI}$ | $I=\dfrac{A+B}{2}$ | chọn $O$ là gốc tọa độ |
| $\overrightarrow{OA}+\overrightarrow{OB}+\overrightarrow{OC}=3\overrightarrow{OG}$ | $G=\dfrac{A+B+C}{3}$ | như trên |
| Hình bình hành: $\overrightarrow{AB}=\overrightarrow{DC}$ | $A+C=B+D$ | $B-A=C-D$ |
| Cùng phương: $\vec a=k\vec b$ | ba tọa độ tỉ lệ theo **cùng** $k$ | nhân số làm riêng từng tọa độ |
| $\vec a\cdot\vec b=\lvert\vec a\rvert\cdot\lvert\vec b\rvert\cdot\cos(\vec a,\vec b)$ | $\vec a\cdot\vec b=xx'+yy'+zz'$ | $\vec i,\vec j,\vec k$ dài 1, đôi một vuông góc |
| $\lvert\vec a\rvert^2=\vec a^2$ | $\lvert\vec a\rvert=\sqrt{x^2+y^2+z^2}$ | tích vô hướng của $\vec a$ với chính nó |
| Đường chéo hình hộp chữ nhật $\sqrt{a^2+b^2+c^2}$ | khoảng cách $AB$ | Pythagore "hai lần" |

### 1.2. Gặp câu hỏi nào — dùng công cụ nào

| Đề hỏi | Công cụ | Xem lại |
|---|---|---|
| "vectơ nào bằng…", "tổng … bằng" trên hình hộp | thay bằng vectơ bằng nó để **nối đuôi**, quy tắc hình hộp | Bài 6 mục 2 |
| "biểu diễn $\overrightarrow{MN}$ theo…", "chứng minh thẳng hàng" | chèn điểm, hệ thức trung điểm/trọng tâm, $\overrightarrow{AC}=k\overrightarrow{AB}$ | Bài 6 mục 3 |
| tích vô hướng, góc trên tứ diện đều, hình lập phương | dời chung gốc; hoặc ba vectơ gốc; hoặc **gắn trục** | Bài 6 mục 4, Bài 8 Dạng 5 |
| hình chiếu, đối xứng, khoảng cách tới trục/mặt phẳng tọa độ | "giữ – xóa – đổi dấu" | Bài 7 mục 2.2 |
| đỉnh hình bình hành, hình hộp | cặp vectơ bằng nhau, $A+C=B+D$ | Bài 7 mục 2.4, Bài 8 mục 1.3 |
| điểm trên trục/mặt phẳng tọa độ thỏa điều kiện | dạng tọa độ đặc biệt → phương trình | Bài 8 Dạng 2 |
| góc, vuông góc, độ dài (có tham số) | công thức $\cos$, tích vô hướng $=0$ | Bài 8 mục 2 |
| drone, máy bay, đèn, camera, lực | chọn trục → tọa độ → vectơ, độ dài, góc | Bài 7 mục 2.5, Bài 8 mục 3 |

> [!meo] Ba câu tự hỏi trước khi đặt bút
> 1. **Đề có tọa độ không?** Có thì cứ tính. Không có nhưng hình có ba cạnh đôi một vuông góc (hình hộp chữ nhật, lập phương, chóp có cạnh bên vuông góc đáy là hình chữ nhật) thì **tự gắn trục** — thường nhanh và ít sai hơn biến đổi vectơ.
> 2. **Đề hỏi vectơ, số hay điểm?** Tổng, hiệu, $k\vec a$ cho **vectơ**. Tích vô hướng, độ dài, $\cos$ cho **số**. "Tìm $M$" thì gọi $M(x;y;z)$ hoặc dạng đặc biệt.
> 3. **Điểm đầu, điểm cuối có đúng thứ tự không?** Gần một nửa lỗi của chương là viết ngược chiều vectơ.

## 2. Bảng so sánh – phân biệt

### 2.1. Bốn quan hệ giữa hai vectơ

Cả bốn quan hệ dưới đây đều đòi hỏi **giá song song hoặc trùng nhau**. Chúng chỉ khác nhau ở **hướng** và **độ dài**.

| | Cùng phương | Cùng hướng | Bằng nhau | Đối nhau |
|---|---|---|---|---|
| Hướng | cùng hoặc ngược | cùng | cùng | ngược |
| Độ dài | tùy ý | tùy ý | **bằng nhau** | **bằng nhau** |
| Bằng tọa độ | $\vec a=k\vec b$ | ${\vec a=k\vec b,\ k>0}$ | $\vec a=\vec b$ (ba tọa độ) | $\vec a=-\vec b$ |
| Trên hình hộp | $\overrightarrow{AB}$, $\overrightarrow{C'D'}$ | $\overrightarrow{AB}$, $2\overrightarrow{DC}$ | $\overrightarrow{AB}$, $\overrightarrow{D'C'}$ | $\overrightarrow{AB}$, $\overrightarrow{C'D'}$ |

Hai câu hay bị gài trong đề Đúng/Sai: giá nằm trên hai đường thẳng **chéo nhau** thì **không** cùng phương; hai vectơ bằng nhau có thể nằm ở **hai mặt khác nhau** của hình ($\overrightarrow{AB}=\overrightarrow{D'C'}$, một cạnh ở đáy dưới, một cạnh ở đáy trên).

### 2.2. Trục hay mặt phẳng — hình chiếu, đối xứng, khoảng cách

Với $M(x;y;z)$:

| | Trục $Oz$ | Mặt phẳng $(Oxy)$ |
|---|---|---|
| Điểm thuộc nó có dạng | $(0;0;c)$ — **hai** tọa độ bằng 0 | $(a;b;0)$ — **một** tọa độ bằng 0 |
| Hình chiếu của $M$ | $(0;0;z)$ — **giữ** $z$ | $(x;y;0)$ — **xóa** $z$ |
| Đối xứng của $M$ | $(-x;-y;z)$ — giữ $z$, đổi dấu hai tọa độ | $(x;y;-z)$ — giữ $x,y$, đổi dấu $z$ |
| Khoảng cách từ $M$ | $\sqrt{x^2+y^2}$ | $\lvert z\rvert$ |

Mẹo chống nhầm: **trục là một đường, mặt phẳng là một tấm**. Chiếu lên một đường thì chỉ còn **một** con số, chiếu lên một tấm thì còn **hai** con số. Và khoảng cách tới **gốc** $O$ là $\sqrt{x^2+y^2+z^2}$ — đủ ba số.

### 2.3. Ba loại góc

| | Góc giữa hai vectơ | Góc giữa hai đường thẳng | Góc của tam giác tại đỉnh $A$ |
|---|---|---|---|
| Miền giá trị | $[0^\circ;\,180^\circ]$ | $[0^\circ;\,90^\circ]$ | $(0^\circ;\,180^\circ)$ |
| Công thức | $\cos=\dfrac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$ | lấy $\lvert\cos\rvert$ | dùng ${\overrightarrow{AB},\overrightarrow{AC}}$ **cùng đi ra từ $A$** |
| Bẫy | $(\overrightarrow{AB},\overrightarrow{BC})$ là góc **ngoài** | góc tù thì lấy góc bù | dùng $\overrightarrow{BA}$ thì ra góc bù |

### 2.4. Phép toán cho ra vectơ hay số?

| Phép toán | Kết quả | Ví dụ với $\vec a=(1;2;2)$, $\vec b=(2;0;1)$ |
|---|---|---|
| $\vec a+\vec b$, $\vec a-\vec b$ | **vectơ** | $(3;2;3)$, $(-1;2;1)$ |
| $k\vec a$ | **vectơ** | $3\vec a=(3;6;6)$ |
| $\vec a\cdot\vec b$ | **số** | $2+0+2=4$ |
| $\lvert\vec a\rvert$ | **số không âm** | $\sqrt{1+4+4}=3$ |
| $\vec a^2$ | **số** | $\lvert\vec a\rvert^2=9$ |

Hai bất đẳng thức "lặng lẽ": $\lvert\vec a+\vec b\rvert\le\lvert\vec a\rvert+\lvert\vec b\rvert$ (bằng khi cùng hướng) và $\lvert\vec a\cdot\vec b\rvert\le\lvert\vec a\rvert\cdot\lvert\vec b\rvert$ (vì $\lvert\cos\rvert\le1$). Nếu em tính ra $\lvert\cos\rvert>1$ thì chắc chắn đã sai ở đâu đó.

### 2.5. Thứ tự đỉnh — một hình, ba đáp số

Cho ba điểm $A$, $B$, $C$ không thẳng hàng. Đề hỏi *điểm $D$ để $ABCD$ là hình bình hành* thì chỉ có **một** đáp số: $D=A+C-B$. Nhưng đề hỏi *bốn điểm $A$, $B$, $C$, $D$ là bốn đỉnh của một hình bình hành* thì có **ba** đáp số:

| Hình bình hành | Cặp đỉnh đối diện chứa $D$ | $D$ bằng |
|---|---|---|
| $ABCD$ | $B$ – $D$ | $A+C-B$ |
| $ABDC$ | $A$ – $D$ | $B+C-A$ |
| $ADBC$ | $C$ – $D$ | $A+B-C$ |

Đề 4 lựa chọn gần như luôn đặt hai đáp số "sai thứ tự" làm phương án nhiễu.

## 3. Lỗi sai hay gặp của cả chương

> [!bay] Bài 6 — vectơ trong không gian
> - **1.** **Đường chéo sai** trong quy tắc hình hộp: $\overrightarrow{AB}+\overrightarrow{AD}+\overrightarrow{AA'}$ là $\overrightarrow{AC'}$, không phải $\overrightarrow{A'C}$, cũng không phải $\overrightarrow{AC}$ (quên $\overrightarrow{AA'}$).
> - **2.** **Cộng hai vectơ không nối đuôi**: $\overrightarrow{AB}+\overrightarrow{CC'}$ phải đổi $\overrightarrow{CC'}=\overrightarrow{BB'}$ rồi mới dùng quy tắc ba điểm.
> - **3.** **Quy tắc trừ viết ngược**: $\overrightarrow{OB}-\overrightarrow{OA}=\overrightarrow{AB}$, không phải $\overrightarrow{BA}$.
> - **4.** **Góc chưa chung gốc**: $(\overrightarrow{AB},\overrightarrow{BC})$ trong tam giác đều là $120^\circ$, không phải $60^\circ$.
> - **5.** **Nhầm trọng tâm tam giác với trọng tâm tứ diện**: $\overrightarrow{GB}+\overrightarrow{GC}+\overrightarrow{GD}=\vec 0$ (tam giác $BCD$) khác $\overrightarrow{IA}+\overrightarrow{IB}+\overrightarrow{IC}+\overrightarrow{ID}=\vec 0$ (tứ diện), và $\overrightarrow{AI}=\frac34\overrightarrow{AG}$ chứ không phải $\frac23$.
> - **6.** **$\lvert\vec a+\vec b\rvert=\lvert\vec a\rvert+\lvert\vec b\rvert$** — chỉ đúng khi cùng hướng. Muốn tính độ dài phải **bình phương** rồi khai triển.

> [!bay] Bài 7 — hệ trục tọa độ
> - **7.** **Trục "giữ", mặt phẳng "xóa"** bị làm ngược: hình chiếu của $M(2;-5;1)$ lên trục $Oy$ là $(0;-5;0)$, còn $(2;0;1)$ là hình chiếu lên **mặt phẳng** $(Ozx)$.
> - **8.** **Đối xứng qua trục chỉ đổi dấu một tọa độ** — phải đổi dấu **hai** tọa độ không mang tên trục.
> - **9.** **Khoảng cách tới trục $Oz$ bằng $\lvert z\rvert$** — sai: $\lvert z\rvert$ là khoảng cách tới **mặt phẳng** $(Oxy)$.
> - **10.** **Viết tọa độ sai thứ tự**: $\vec u=2\vec k-\vec i$ là $(-1;0;2)$, luôn xếp theo $\vec i,\vec j,\vec k$.
> - **11.** **Đầu trừ cuối**: $\overrightarrow{AB}=A-B$ là sai dấu cả ba tọa độ.

> [!bay] Bài 8 — biểu thức tọa độ
> - **12.** **Sai thứ tự đỉnh hình bình hành** (xem mục 2.5).
> - **13.** **Tích vô hướng ra vectơ** $(xx';\,yy';\,zz')$ — phải **cộng** ba tích.
> - **14.** **Cùng phương chỉ so hai tọa độ**, hoặc dùng tỉ số khi có tọa độ bằng 0. Phải kiểm cả ba tọa độ với **cùng một** $k$.
> - **15.** **Góc tù chỉ cần $\vec a\cdot\vec b<0$** — còn phải loại trường hợp hai vectơ **ngược hướng** (góc $180^\circ$).
> - **16.** **Trọng tâm "ngược"** ($C=3G-A-B$) bị viết thành $\frac{A+B+G}{3}$, hoặc quên nhân 3.
> - **17.** **Bài thực tế**: quên đổi phút ra giờ, đi ngược chiều dương mà vẫn cộng, **làm tròn sớm**, đọc nhầm "cách trần" thành cao độ.

## 4. Bài tổng hợp

Năm bài dưới đây đều **phối hợp nhiều bài** của chương và bám ba dạng đề tốt nghiệp. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Một hình lập phương — hai cách giải

> [!vi-du] Ví dụ 1 (Bài 6 + 7 + 8)
> Cho hình lập phương $ABCD.A'B'C'D'$ cạnh $2$. Gọi $M$ là trung điểm của $CC'$, $N$ là trung điểm của $A'D'$. Đặt $\vec x=\overrightarrow{AB}$, $\vec y=\overrightarrow{AD}$, $\vec z=\overrightarrow{AA'}$.
>
> a) Biểu diễn $\overrightarrow{AM}$ và $\overrightarrow{BN}$ theo $\vec x,\vec y,\vec z$.
>
> b) Chứng minh $AM\perp BN$ theo **hai cách**: bằng vectơ và bằng tọa độ.
>
> c) Tính độ dài đoạn $MN$ và góc giữa hai vectơ $\overrightarrow{AM}$, $\overrightarrow{AC'}$ (làm tròn đến hàng phần mười của độ).

![Hình 2. Hình lập phương cạnh 2 đặt trong hệ Oxyz với A ≡ O; M là trung điểm CC′, N là trung điểm A′D′](h2-lap-phuong.svg)

> [!goi-y] Gợi ý 1
> a) Đi từ $A$ tới $M$ dọc các cạnh: $A\to B\to C\to M$. Đi từ $B$ tới $N$: $B\to A\to A'\to N$. Nhớ $\overrightarrow{BC}=\vec y$, $\overrightarrow{CM}=\frac12\vec z$, $\overrightarrow{A'N}=\frac12\vec y$.

> [!goi-y] Gợi ý 2
> b) Cách 1: $\vec x,\vec y,\vec z$ đôi một vuông góc, mỗi vectơ có bình phương bằng $4$ — khai triển $\overrightarrow{AM}\cdot\overrightarrow{BN}$ như nhân đa thức. Cách 2: đặt $A\equiv O$, ba tia $Ox,Oy,Oz$ chứa $B,D,A'$ (Hình 2), rồi viết tọa độ $M$, $N$.

> [!goi-y] Gợi ý 3
> c) Đã có tọa độ thì $\overrightarrow{MN}=N-M$, $\overrightarrow{AC'}=(2;2;2)$. Dùng công thức $\cos$ của Bài 8.

> [!loi-giai] Lời giải
> **a)** $\overrightarrow{AM}=\overrightarrow{AB}+\overrightarrow{BC}+\overrightarrow{CM}=\vec x+\vec y+\tfrac12\vec z$.
> $\overrightarrow{BN}=\overrightarrow{BA}+\overrightarrow{AA'}+\overrightarrow{A'N}=-\vec x+\tfrac12\vec y+\vec z$.
>
> **b) Cách 1 (vectơ).** Các tích chéo $\vec x\cdot\vec y=\vec y\cdot\vec z=\vec z\cdot\vec x=0$, nên chỉ còn các số hạng "cùng tên":
> $$\overrightarrow{AM}\cdot\overrightarrow{BN}=-\vec x^2+\tfrac12\vec y^2+\tfrac12\vec z^2$$
> $$=-4+2+2=0.$$
> **Cách 2 (tọa độ).** $A(0;0;0)$, $B(2;0;0)$, $C(2;2;0)$, $C'(2;2;2)$, $A'(0;0;2)$, $D'(0;2;2)$. Suy ra $M(2;2;1)$, $N(0;1;2)$.
> $\overrightarrow{AM}=(2;2;1)$, $\overrightarrow{BN}=(-2;1;2)$, tích vô hướng $-4+2+2=0$. Vậy $AM\perp BN$. ∎
>
> **c)** $\overrightarrow{MN}=(-2;-1;1)$, nên $MN=\sqrt{4+1+1}=\sqrt6$.
> $\overrightarrow{AC'}=(2;2;2)$, $\overrightarrow{AM}\cdot\overrightarrow{AC'}=4+4+2=10$, $AM=3$, $AC'=2\sqrt3$.
> $\cos(\overrightarrow{AM},\overrightarrow{AC'})=\dfrac{10}{3\cdot2\sqrt3}=\dfrac{5\sqrt3}{9}\approx0{,}9623$, suy ra góc $\approx15{,}8^\circ$.

> [!meo] Chọn cách nào trong phòng thi?
> Hai cách cho cùng kết quả, nhưng cách tọa độ **ít phải nghĩ** hơn: không cần nhớ góc giữa các cạnh, chỉ cần đặt đúng trục. Cách vectơ lại **bắt buộc** khi hình **không** có ba cạnh vuông góc (tứ diện đều, hình hộp xiên) — xem Ví dụ 2. Hãy thạo cả hai.

### 4.2. Biểu diễn vectơ trong tứ diện, rồi tính độ dài

> [!vi-du] Ví dụ 2 (Bài 6 — liên hệ SGK Bài tập 2.36)
> Cho tứ diện $ABCD$. Lấy điểm $M$ thỏa mãn $3\overrightarrow{MA}+\overrightarrow{MB}=\vec 0$ và điểm $N$ thỏa mãn $3\overrightarrow{ND}+\overrightarrow{NC}=\vec 0$.
>
> a) Xác định vị trí của $M$ trên $AB$, của $N$ trên $DC$.
>
> b) Biểu diễn $\overrightarrow{MN}$ theo $\overrightarrow{AD}$ và $\overrightarrow{BC}$.
>
> c) Biết $ABCD$ là tứ diện đều cạnh $4$. Tính độ dài $MN$.

> [!goi-y] Gợi ý 1
> a) Chèn điểm $A$: $\overrightarrow{MB}=\overrightarrow{MA}+\overrightarrow{AB}$. Thay vào $3\overrightarrow{MA}+\overrightarrow{MB}=\vec 0$ để tính $\overrightarrow{AM}$ theo $\overrightarrow{AB}$.

> [!goi-y] Gợi ý 2
> b) Đi từ $M$ tới $N$ bằng hai đường: qua $A$, $D$ và qua $B$, $C$. Nhân đường thứ nhất với $3$, cộng với đường thứ hai — các vectơ "thừa" sẽ triệt tiêu nhờ điều kiện của $M$, $N$.

> [!goi-y] Gợi ý 3
> c) Trong tứ diện đều, hai cạnh đối vuông góc (Bài 6, Ví dụ 10): $\overrightarrow{AD}\cdot\overrightarrow{BC}=0$. Bình phương $\overrightarrow{MN}$ rồi khai triển.

> [!loi-giai] Lời giải
> **a)** $3\overrightarrow{MA}+\overrightarrow{MA}+\overrightarrow{AB}=\vec 0\iff\overrightarrow{AM}=\tfrac14\overrightarrow{AB}$: $M$ thuộc đoạn $AB$, $AM=\frac14AB$. Tương tự $\overrightarrow{DN}=\frac14\overrightarrow{DC}$.
>
> **b)** $\overrightarrow{MN}=\overrightarrow{MA}+\overrightarrow{AD}+\overrightarrow{DN}$ và $\overrightarrow{MN}=\overrightarrow{MB}+\overrightarrow{BC}+\overrightarrow{CN}$.
> Nhân đẳng thức đầu với $3$ rồi cộng với đẳng thức sau:
> $$4\overrightarrow{MN}=3\overrightarrow{AD}+\overrightarrow{BC}+\vec u,$$
> trong đó $\vec u=(3\overrightarrow{MA}+\overrightarrow{MB})+(3\overrightarrow{DN}+\overrightarrow{CN})$.
> Theo giả thiết $3\overrightarrow{MA}+\overrightarrow{MB}=\vec 0$ và $3\overrightarrow{DN}+\overrightarrow{CN}=-(3\overrightarrow{ND}+\overrightarrow{NC})=\vec 0$, nên $\vec u=\vec 0$. Vậy
> $$\overrightarrow{MN}=\tfrac34\overrightarrow{AD}+\tfrac14\overrightarrow{BC}.$$
>
> **c)** $MN^2=\tfrac{9}{16}AD^2+\tfrac{1}{16}BC^2+2\cdot\tfrac{3}{16}\,\overrightarrow{AD}\cdot\overrightarrow{BC}=9+1+0=10$, nên $MN=\sqrt{10}$.

> [!meo] Công thức "chia cùng tỉ lệ"
> Nếu $\overrightarrow{AM}=t\overrightarrow{AB}$ và $\overrightarrow{DN}=t\overrightarrow{DC}$ (cùng tỉ lệ $t$) thì $\overrightarrow{MN}=(1-t)\overrightarrow{AD}+t\overrightarrow{BC}$. Kiểm tra: $t=0$ cho $\overrightarrow{AD}$, $t=1$ cho $\overrightarrow{BC}$, $t=\frac12$ cho công thức "hai trung điểm" của Bài 6. Hệ số đứng trước $\overrightarrow{AD}$ là phần **còn lại** $1-t$ — đề trắc nghiệm hay đảo hai hệ số này.

### 4.3. Đúng/Sai: hình hộp cho bằng tọa độ

> [!vi-du] Ví dụ 3 (Bài 6 + 7 + 8 — liên hệ SGK Bài tập 2.39)
> Trong không gian $Oxyz$, cho hình hộp $OABC.O'A'B'C'$ có $A(2;-1;2)$, $C(2;2;-1)$ và $O'(-1;2;2)$. Xét các mệnh đề:
>
> a) $B(0;-3;3)$.
>
> b) $B'(3;3;3)$.
>
> c) $OABC.O'A'B'C'$ là một hình lập phương.
>
> d) Đường chéo $OB'$ có độ dài bằng $9$.

> [!goi-y] Gợi ý 1
> Đáy $OABC$ là hình bình hành: $\overrightarrow{OB}=\overrightarrow{OA}+\overrightarrow{OC}$. Quy tắc hình hộp: $\overrightarrow{OB'}=\overrightarrow{OA}+\overrightarrow{OC}+\overrightarrow{OO'}$. Vì gốc là $O$ nên tọa độ điểm = tọa độ vectơ từ $O$.

> [!goi-y] Gợi ý 2
> c) Hình hộp là hình lập phương khi ba cạnh $OA$, $OC$, $OO'$ **dài bằng nhau** và **đôi một vuông góc**. Tính ba độ dài và ba tích vô hướng.

> [!loi-giai] Lời giải
> a) **Sai.** $B=A+C=(4;1;1)$. Điểm $(0;-3;3)$ là kết quả của $A-C$ (nhầm cộng thành trừ).
>
> b) **Đúng.** $B'=A+C+O'=(2+2-1;\,-1+2+2;\,2-1+2)=(3;3;3)$.
>
> c) **Đúng.** $OA=OC=OO'=\sqrt{4+4+1}=3$ và
> $\overrightarrow{OA}\cdot\overrightarrow{OC}=4-2-2=0$, $\overrightarrow{OA}\cdot\overrightarrow{OO'}=-2-2+4=0$, $\overrightarrow{OC}\cdot\overrightarrow{OO'}=-2+4-2=0$.
> Ba cạnh xuất phát từ $O$ bằng nhau và đôi một vuông góc nên mọi mặt là hình vuông: hình hộp là hình lập phương cạnh $3$.
>
> d) **Sai.** $OB'=\sqrt{9+9+9}=\sqrt{27}=3\sqrt3\approx5{,}2$. (Đúng với công thức đường chéo lập phương $a\sqrt3$.) Số $9$ là tổng ba cạnh — lỗi "$\lvert\vec a+\vec b+\vec c\rvert=\lvert\vec a\rvert+\lvert\vec b\rvert+\lvert\vec c\rvert$".

> [!em-co-biet]
> Hình lập phương ở Ví dụ 3 bị "xoay nghiêng" so với ba trục, nên nhìn tọa độ các đỉnh không đoán được nó là lập phương — chỉ tích vô hướng mới phát hiện ra. Các phần mềm đồ họa 3D lưu mỗi vật thể bằng tọa độ đỉnh. Khi xoay vật, chúng giữ nguyên **độ dài** và **tích vô hướng** giữa các cạnh, nên hình không bị méo.

### 4.4. Trả lời ngắn: đường đi ngắn nhất qua một mặt phẳng

> [!vi-du] Ví dụ 4 (Bài 7 + 8 — vận dụng cao)
> Trong không gian $Oxyz$, cho $A(1;2;3)$ và $B(5;-2;1)$. Tìm điểm $M$ thuộc mặt phẳng $(Oxy)$ sao cho tổng $MA+MB$ nhỏ nhất. Tính giá trị nhỏ nhất đó (làm tròn đến hàng phần trăm).

![Hình 3. A và B cùng phía với (Oxy); lấy A′ đối xứng với A qua (Oxy); MA + MB = MA′ + MB ≥ A′B, dấu bằng khi M là giao điểm của A′B với (Oxy)](h3-doi-xung.svg)

> [!goi-y] Gợi ý 1
> $A$ và $B$ có cao độ cùng dương — cùng phía với "sàn" $(Oxy)$. Đường gấp khúc $A\to M\to B$ giống tia sáng phản xạ trên gương. Lấy $A'$ đối xứng với $A$ qua $(Oxy)$: với **mọi** $M$ trên sàn, $MA=MA'$.

> [!goi-y] Gợi ý 2
> $MA+MB=MA'+MB\ge A'B$ (bất đẳng thức tam giác). Dấu bằng khi $A'$, $M$, $B$ thẳng hàng. Gọi $M(x;y;0)$ rồi cho $\overrightarrow{A'M}=k\overrightarrow{A'B}$.

> [!loi-giai] Lời giải
> Đối xứng qua $(Oxy)$: giữ $x$, $y$, đổi dấu $z$, được $A'(1;2;-3)$. Khi đó $\overrightarrow{A'B}=(4;-4;4)$.
>
> $M(x;y;0)$ thẳng hàng với $A'$, $B$: $\overrightarrow{A'M}=(x-1;\,y-2;\,3)=k(4;-4;4)$. Cao độ cho $3=4k$, tức $k=\frac34$. Suy ra $x=1+3=4$, $y=2-3=-1$: $M(4;-1;0)$.
>
> Giá trị nhỏ nhất: $A'B=\sqrt{16+16+16}=4\sqrt3\approx6{,}93$.
>
> Kiểm tra: $MA=\sqrt{9+9+9}=3\sqrt3$, $MB=\sqrt{1+1+1}=\sqrt3$, tổng $4\sqrt3$ ✓.

> [!bay]
> - Nếu $A$ và $B$ nằm **khác phía** với $(Oxy)$ (cao độ trái dấu) thì **không** cần đối xứng: $M$ là giao điểm của chính đoạn $AB$ với mặt phẳng.
> - Đừng đối xứng nhầm qua **trục** hay qua **gốc**: qua mặt phẳng $(Oxy)$ chỉ đổi dấu **một** tọa độ $z$.

> [!ung-dung]
> Bài toán này là "ống nước ngắn nhất": cần đi một đường ống từ bồn $A$ chạm sàn tại một van $M$ rồi tới bồn $B$, sao cho tốn ít ống nhất. Ánh sáng phản xạ trên gương phẳng cũng "chọn" đúng đường ngắn nhất như vậy (nguyên lí Fermat) — đó là lí do góc tới bằng góc phản xạ.

### 4.5. Trả lời ngắn: dời chiếc đèn trong phòng

> [!vi-du] Ví dụ 5 (Bài 7 + 8 — liên hệ SGK Bài tập 2.42)
> Một phòng có dạng hình hộp chữ nhật dài $6$ m, rộng $5$ m, cao $3{,}2$ m. Chọn hệ $Oxyz$ có $O$ là một góc sàn, $Ox$ dọc chiều dài, $Oy$ dọc chiều rộng, $Oz$ hướng lên trần, đơn vị mét. Như vậy $(Oyz)$ và $(Ozx)$ là hai bức tường. Một chiếc đèn ban đầu treo cách trần $0{,}7$ m, cách tường $(Oyz)$ $2$ m và cách tường $(Ozx)$ $1{,}5$ m. Người ta dời đèn đến vị trí mới cách trần $0{,}5$ m và cách mỗi bức tường đó $3$ m.
>
> a) Tìm tọa độ $L_1$, $L_2$ của đèn trước và sau khi dời.
>
> b) Đèn đã được dời đi bao nhiêu mét (làm tròn đến hàng phần mười)?
>
> c) Một camera đặt ở góc trần $K(6;5;3{,}2)$ luôn hướng về chiếc đèn. Khi đèn được dời, camera phải quay một góc bao nhiêu độ (làm tròn đến hàng phần mười)?

![Hình 4. Phòng 6 m × 5 m × 3,2 m trong hệ Oxyz: đèn dời từ L₁ đến L₂; camera ở góc trần K quay một góc từ KL₁ sang KL₂](h4-phong-den.svg)

> [!goi-y] Gợi ý 1
> "Cách tường $(Oyz)$" là $\lvert x\rvert$, "cách tường $(Ozx)$" là $\lvert y\rvert$. "Cách **trần**" **không phải** cao độ: cao độ $=3{,}2-$ khoảng cách tới trần.

> [!goi-y] Gợi ý 2
> b) Độ dời là $L_1L_2=\lvert\overrightarrow{L_1L_2}\rvert$. c) Góc quay là góc giữa hai vectơ $\overrightarrow{KL_1}$ và $\overrightarrow{KL_2}$ (cùng xuất phát từ $K$).

> [!loi-giai] Lời giải
> **a)** $L_1(2;\,1{,}5;\,2{,}5)$ vì $3{,}2-0{,}7=2{,}5$. $L_2(3;\,3;\,2{,}7)$ vì $3{,}2-0{,}5=2{,}7$.
>
> **b)** $\overrightarrow{L_1L_2}=(1;\,1{,}5;\,0{,}2)$, $L_1L_2=\sqrt{1+2{,}25+0{,}04}=\sqrt{3{,}29}\approx1{,}8$ m.
>
> **c)** $\overrightarrow{KL_1}=(-4;\,-3{,}5;\,-0{,}7)$, $\overrightarrow{KL_2}=(-3;\,-2;\,-0{,}5)$.
> Tích vô hướng: $12+7+0{,}35=19{,}35$.
> $KL_1=\sqrt{16+12{,}25+0{,}49}=\sqrt{28{,}74}$, $KL_2=\sqrt{9+4+0{,}25}=\sqrt{13{,}25}$.
> $\cos=\dfrac{19{,}35}{\sqrt{28{,}74}\cdot\sqrt{13{,}25}}\approx0{,}9916$, nên góc quay $\approx7{,}4^\circ$.

> [!bay]
> Ở câu c), giữ nguyên căn đến bước cuối. Nếu làm tròn $KL_1\approx5{,}4$ và $KL_2\approx3{,}6$ trước khi chia thì $\cos\approx0{,}9954$, góc $\approx5{,}5^\circ$ — lệch gần $2^\circ$, sai đáp số trả lời ngắn.

## 5. Đối chiếu "Bài tập cuối chương II" (SGK tr. 73–74)

Bảng dưới cho biết mỗi bài tập của SGK kiểm tra điều gì, nên xem lại ở đâu, kèm một **bài tự luyện cùng dạng** (số liệu khác). Làm xong, mở đáp số bên dưới để tự chấm.

| SGK | Kiểm tra | Xem lại | Bài tự luyện cùng dạng |
|---|---|---|---|
| 2.25 | Trọng tâm tam giác trong tứ diện | Bài 6 mục 3.2 | (T1) Tứ diện $ABCD$, $G$ là trọng tâm tam giác $ABD$. Rút gọn $\overrightarrow{CA}+\overrightarrow{CB}+\overrightarrow{CD}$. |
| 2.26 | Biểu diễn vectơ trong hình hộp | Bài 6 mục 2.2 | (T2) Hình hộp $ABCD.A'B'C'D'$, $N$ là trung điểm $DD'$. Biểu diễn $\overrightarrow{BN}$ qua $\overrightarrow{AB}$, $\overrightarrow{AD}$, $\overrightarrow{AA'}$. |
| 2.27 | Quy tắc ba điểm, hình hộp | Bài 6, Dạng 1 | (T3) Rút gọn $\overrightarrow{AB}+\overrightarrow{CC'}+\overrightarrow{B'C'}$. |
| 2.28 | Tích vô hướng trên tứ diện đều | Bài 6, Dạng 2 | (T4) Tứ diện đều cạnh $a$, $N$ là trung điểm $BC$. Tính $\overrightarrow{AB}\cdot\overrightarrow{DN}$. |
| 2.29 | Tọa độ tổng, hiệu, $k\vec a$ | Bài 8 mục 1.1 | (T5) $\vec a=(3;0;-1)$, $\vec b=(1;-2;4)$. Tìm $2\vec a-3\vec b$. |
| 2.30 | Đỉnh thứ tư hình bình hành | Bài 8 mục 1.3; mục 2.5 ở trên | (T6) $A(0;2;-1)$, $B(1;-1;3)$, $C(4;0;2)$. Tìm $D$ để $ABCD$ là hình bình hành. |
| 2.31 | Trọng tâm "ngược" | Bài 8 mục 1.3 | (T7) $A(2;3;-1)$, $B(-2;0;4)$, trọng tâm $G(1;1;1)$. Tìm $C$. |
| 2.32–2.34, 2.40 | Tích vô hướng, độ dài, góc | Bài 8 mục 2 | (T8) $\vec a=(1;-1;4)$, $\vec b=(2;2;1)$. Tính $\vec a\cdot\vec b$, $\lvert\vec a\rvert$, $\cos(\vec a,\vec b)$. |
| 2.35 | Chứng minh đẳng thức vectơ | Bài 6 mục 2 | (T9) Hình chóp $S.ABCD$ có đáy là **hình bình hành**. Chứng minh $\overrightarrow{SA}+\overrightarrow{SC}=\overrightarrow{SB}+\overrightarrow{SD}$. |
| 2.36 | Biểu diễn vectơ theo hai vectơ | Bài 6 mục 3 | Ví dụ 2 ở trên. |
| 2.37 | Trọng tâm, thẳng hàng trong hình hộp | Bài 6, Dạng 3 | (T10) Hình hộp $ABCD.A'B'C'D'$, $G$ là trọng tâm tam giác $CB'D'$. Chứng minh $A$, $G$, $C'$ thẳng hàng và tính $\frac{AG}{AC'}$. |
| 2.38 | Trọng tâm; điểm trên trục để vuông góc | Bài 8, Dạng 2 | (T11) $A(1;2;0)$, $B(3;-1;2)$, $C(-1;0;4)$. Tìm $M\in Oz$ để $BM\perp AC$. |
| 2.39 | Đỉnh hình hộp từ tọa độ | Bài 7 mục 2.4 | Ví dụ 3 ở trên. |
| 2.41 | Vectơ, điểm thỏa đẳng thức, thẳng hàng | Bài 8, Dạng 1, 2 | (T12) $A(3;2;-2)$, $B(1;3;0)$. Tìm $N$ thuộc $(Ozx)$ để $A$, $B$, $N$ thẳng hàng. |
| 2.42 | Đặt hệ trục trong phòng, khoảng cách | Bài 7 mục 2.5 | Ví dụ 5 ở trên. |

> [!loi-giai] Đáp số bài tự luyện T1–T12
> - **T1.** $3\overrightarrow{CG}$ (hệ thức trọng tâm với điểm $O\equiv C$).
> - **T2.** $\overrightarrow{BN}=\overrightarrow{BA}+\overrightarrow{AD}+\overrightarrow{DN}=-\overrightarrow{AB}+\overrightarrow{AD}+\frac12\overrightarrow{AA'}$.
> - **T3.** $\overrightarrow{CC'}=\overrightarrow{BB'}$ nên tổng $=\overrightarrow{AB}+\overrightarrow{BB'}+\overrightarrow{B'C'}=\overrightarrow{AC'}$.
> - **T4.** $\overrightarrow{DN}=\frac12(\overrightarrow{DB}+\overrightarrow{DC})$. $\overrightarrow{AB}\cdot\overrightarrow{DB}=\overrightarrow{BA}\cdot\overrightarrow{BD}=\frac{a^2}{2}$ và $\overrightarrow{AB}\cdot\overrightarrow{DC}=0$ (hai cạnh đối). Kết quả $\frac{a^2}{4}$.
> - **T5.** $(6;0;-2)-(3;-6;12)=(3;6;-14)$.
> - **T6.** $D=A+C-B=(3;3;-2)$.
> - **T7.** $C=3G-A-B=(3;0;0)$.
> - **T8.** $\vec a\cdot\vec b=2-2+4=4$, $\lvert\vec a\rvert=\sqrt{18}=3\sqrt2$, $\lvert\vec b\rvert=3$, $\cos=\frac{4}{9\sqrt2}=\frac{2\sqrt2}{9}$.
> - **T9.** Gọi $O$ là tâm đáy (trung điểm chung của $AC$ và $BD$): hai vế cùng bằng $2\overrightarrow{SO}$. Đáy chỉ cần là **hình bình hành**, không cần hình chữ nhật.
> - **T10.** $\overrightarrow{AC}+\overrightarrow{AB'}+\overrightarrow{AD'}=(\vec x+\vec y)+(\vec x+\vec z)+(\vec y+\vec z)=2\overrightarrow{AC'}$ và vế trái bằng $3\overrightarrow{AG}$, nên $\overrightarrow{AG}=\frac23\overrightarrow{AC'}$: thẳng hàng, $\frac{AG}{AC'}=\frac23$.
> - **T11.** $M(0;0;t)$: $\overrightarrow{BM}=(-3;1;t-2)$, $\overrightarrow{AC}=(-2;-2;4)$. $6-2+4(t-2)=0\iff t=1$, $M(0;0;1)$.
> - **T12.** $N(x;0;z)$, $\overrightarrow{AN}=k\overrightarrow{AB}$ với $\overrightarrow{AB}=(-2;1;2)$. Tung độ: $-2=k$, nên $N=A-2\overrightarrow{AB}=(7;0;-6)$.

## Tóm tắt — danh sách kiểm tra trước giờ thi

| Khi gặp | Nhớ ngay |
|---|---|
| Tổng nhiều vectơ trên hình hộp | Đổi sang vectơ bằng nó để **nối đuôi** hoặc **chung gốc**; ba cạnh chung đỉnh → đường chéo từ đỉnh đó |
| Biểu diễn, chứng minh thẳng hàng | Chèn điểm; trung điểm, trọng tâm có hệ thức với điểm $O$ tùy ý; thẳng hàng $\iff\overrightarrow{AC}=k\overrightarrow{AB}$ |
| Tích vô hướng, góc trên hình | Dời chung gốc **hoặc** ba vectơ gốc **hoặc** gắn trục; độ dài: bình phương rồi khai triển |
| Hình chiếu, đối xứng | Trục giữ, mặt phẳng xóa; qua cái gì giữ cái đó, còn lại đổi dấu |
| Khoảng cách | Tới mặt phẳng tọa độ: một tọa độ; tới trục: căn hai tọa độ; tới gốc: căn ba tọa độ |
| Tìm điểm | Gọi tọa độ (hoặc dạng đặc biệt trên trục/mặt phẳng) → từng tọa độ bằng nhau |
| Hình bình hành | Đúng thứ tự đỉnh: $A+C=B+D$ |
| Góc, vuông góc | $\cos=\frac{\vec a\cdot\vec b}{\lvert\vec a\rvert\cdot\lvert\vec b\rvert}$; góc tù: tích âm **và** không ngược hướng |
| Thực tế | Đọc kĩ trục và chiều dương; "cách trần" ≠ cao độ; đổi đơn vị; làm tròn ở bước cuối |

**Sơ đồ một dòng:** *vectơ hình học (Bài 6) → gắn hệ trục, mỗi vectơ thành bộ ba số (Bài 7) → mọi phép toán thành phép tính trên số (Bài 8) → giải bài hình và bài thực tế bằng tính toán.*
