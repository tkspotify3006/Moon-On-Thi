---
title: Tính đơn điệu và cực trị của hàm số
thoi-gian: 50 phút
muc-tieu:
  - Hiểu thế nào là hàm số đồng biến, nghịch biến trên một khoảng; nhìn đồ thị biết hàm số tăng hay giảm
  - Dùng dấu của đạo hàm cấp một để xét tính đơn điệu; lập và đọc được bảng biến thiên
  - Phân biệt điểm cực trị của hàm số, giá trị cực trị và điểm cực trị của đồ thị
  - Tìm được cực trị của hàm số cụ thể bằng quy tắc 4 bước; đọc cực trị từ bảng biến thiên, đồ thị của f(x) và đồ thị của f′(x)
  - Vận dụng vào bài toán thực tế (chuyển động, nồng độ thuốc, lợi nhuận…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Đồng biến** trên $K$: $x$ tăng thì $f(x)$ tăng — đồ thị **đi lên** từ trái sang phải. **Nghịch biến**: đồ thị **đi xuống**.
> 2. $f'(x)>0$ trên khoảng $K$ $\Rightarrow$ $f$ đồng biến trên $K$; $f'(x)<0$ $\Rightarrow$ nghịch biến. ($f'=0$ chỉ tại hữu hạn điểm vẫn không sao.)
> 3. **Điểm cực trị** là chỗ $f'(x)$ **đổi dấu**: từ $+$ sang $-$ là cực đại, từ $-$ sang $+$ là cực tiểu.
> 4. $f'(x_0)=0$ **chưa chắc** là cực trị (ví dụ $y=x^3$ tại $0$); ngược lại, chỗ không có đạo hàm vẫn **có thể** là cực trị (ví dụ $y=\lvert x\rvert$ tại $0$).
> 5. Quy trình: tập xác định → $f'(x)$ → điểm $f'=0$ hoặc không xác định → **bảng biến thiên** → kết luận.

Mở đầu chương, ta gặp một câu hỏi rất đời thường: một chiếc xe chạy trên đường thẳng, **lúc nào xe tiến, lúc nào xe lùi?** Một bệnh nhân uống thuốc, **lúc nào nồng độ thuốc trong máu cao nhất?** Cả hai câu hỏi đều là: *hàm số đang tăng hay giảm, và nó "đổi chiều" ở đâu?* Công cụ trả lời chính là **đạo hàm** em đã học ở lớp 11. Bài này là nền móng cho cả chương I — và là phần chiếm nhiều điểm nhất trong đề thi Toán.

> [!nen-tang] Đạo hàm lớp 11 — cần thuộc trước khi học bài này
> **Bảng đạo hàm hay dùng:** $(c)'=0$; $(x^n)'=nx^{n-1}$; $(\sqrt x)'=\dfrac{1}{2\sqrt x}$; $\left(\dfrac1x\right)'=-\dfrac{1}{x^2}$; $(\sin x)'=\cos x$; $(\cos x)'=-\sin x$; $(e^x)'=e^x$; $(\ln x)'=\dfrac1x$.
>
> **Quy tắc:** $(u\pm v)'=u'\pm v'$; $(uv)'=u'v+uv'$; $\left(\dfrac uv\right)'=\dfrac{u'v-uv'}{v^2}$; hàm hợp $(\sqrt u)'=\dfrac{u'}{2\sqrt u}$, $(u^n)'=nu^{n-1}u'$.
>
> **Công thức nhanh** cho hàm phân thức bậc nhất: $\left(\dfrac{ax+b}{cx+d}\right)'=\dfrac{ad-bc}{(cx+d)^2}$.
>
> **Ý nghĩa:** $f'(x_0)$ là **hệ số góc của tiếp tuyến** của đồ thị tại điểm có hoành độ $x_0$; nếu $s(t)$ là quãng đường (tọa độ) thì $s'(t)=v(t)$ là **vận tốc**.

## 1. Tính đơn điệu của hàm số

### 1.1. Khái niệm đồng biến, nghịch biến

Hãy tưởng tượng em đi bộ trên đồ thị từ **trái sang phải** (tức là $x$ tăng dần). Có đoạn em phải **leo dốc** (đồ thị đi lên), có đoạn em **xuống dốc** (đồ thị đi xuống). Toán học gọi hai tình huống đó là *đồng biến* và *nghịch biến*.

> [!ghi-nho] Định nghĩa (SGK tr. 6)
> Cho $K$ là một khoảng, một đoạn hoặc một nửa khoảng và $y=f(x)$ xác định trên $K$.
> - $f$ **đồng biến** trên $K$ nếu với mọi $x_1,x_2\in K$: $x_1<x_2\Rightarrow f(x_1)<f(x_2)$.
> - $f$ **nghịch biến** trên $K$ nếu với mọi $x_1,x_2\in K$: $x_1<x_2\Rightarrow f(x_1)>f(x_2)$.
>
> Đồng biến hay nghịch biến trên $K$ gọi chung là **đơn điệu** trên $K$. Nếu đề không nói rõ $K$ thì hiểu là xét trên **tập xác định**.

Đọc bằng lời: *đồng biến* là "$x$ lớn hơn thì $y$ cũng lớn hơn" (hai đại lượng **cùng** chiều); *nghịch biến* là "$x$ lớn hơn thì $y$ lại nhỏ hơn" (**ngược** chiều).

![Hình 1. Đồ thị y = x³ − 3x + 2: các đoạn đi lên (đồng biến) và đi xuống (nghịch biến), cùng hai điểm "đổi chiều"](h1-don-dieu-cuc-tri.svg)

> [!vi-du] Ví dụ 1
> Quan sát Hình 1 (đồ thị hàm số $y=f(x)=x^3-3x+2$). Tìm các khoảng đồng biến, khoảng nghịch biến của hàm số.

> [!goi-y] Gợi ý 1
> Đi dọc đồ thị từ trái sang phải: đồ thị đi lên đến đâu thì bắt đầu đi xuống? Ghi lại **hoành độ** $x$ của chỗ đổi chiều.

> [!goi-y] Gợi ý 2
> Khoảng đơn điệu là khoảng giá trị của $x$ (đọc trên **trục hoành**), không phải của $y$.

> [!loi-giai] Lời giải
> Tập xác định $\mathbb R$. Đồ thị đi lên khi $x$ chạy từ $-\infty$ đến $-1$, đi xuống từ $-1$ đến $1$, rồi lại đi lên từ $1$ đến $+\infty$.
> Vậy hàm số **đồng biến** trên các khoảng $(-\infty;\,-1)$ và $(1;\,+\infty)$; **nghịch biến** trên khoảng $(-1;\,1)$.

> [!bay] Ba lỗi đọc đồ thị hay gặp
> 1. **Đọc khoảng theo trục tung.** Đồ thị đi xuống khi $y$ giảm từ $4$ về $0$, nhưng đáp án phải là khoảng của $x$: $(-1;\,1)$ chứ **không** phải $(0;\,4)$. Đề thi rất hay cài phương án nhiễu này.
> 2. **Gộp hai khoảng bằng dấu $\cup$.** Viết "đồng biến trên $(-\infty;-1)\cup(1;+\infty)$" là **sai**. Thử: $-1{,}5<1{,}5$ nhưng $f(-1{,}5)=3{,}125>f(1{,}5)=0{,}875$ — không thỏa định nghĩa trên tập hợp đó. Phải viết "đồng biến trên **từng** khoảng $(-\infty;-1)$ **và** $(1;+\infty)$".
> 3. **Nhầm "đồng biến" với "dương".** Hàm số có thể đồng biến mà giá trị vẫn âm (đoạn đồ thị bên trái trục tung, dưới trục hoành ở Hình 1 vẫn đang đi lên).

### 1.2. Tính đơn điệu và dấu của đạo hàm

**Vì sao đạo hàm lại cho biết hàm tăng hay giảm?** Đạo hàm $f'(x)$ là hệ số góc của tiếp tuyến — tức là "độ dốc" của đồ thị tại điểm đó.
- Dốc **dương** ($f'(x)>0$): tiếp tuyến chếch lên, đồ thị đang **đi lên**.
- Dốc **âm** ($f'(x)<0$): tiếp tuyến chếch xuống, đồ thị đang **đi xuống**.

Nói theo ngôn ngữ chuyển động: nếu $s(t)$ là vị trí thì $s'(t)$ là vận tốc; vận tốc dương nghĩa là vật đang đi theo chiều dương — vị trí $s$ tăng.

> [!ghi-nho] Định lí (SGK tr. 7)
> Cho $y=f(x)$ có đạo hàm trên khoảng $K$.
> - Nếu $f'(x)>0$ với mọi $x\in K$ thì $f$ **đồng biến** trên $K$.
> - Nếu $f'(x)<0$ với mọi $x\in K$ thì $f$ **nghịch biến** trên $K$.
>
> **Chú ý.**
> - Nếu $f'(x)\ge0$ (hoặc $f'(x)\le0$) với mọi $x\in K$ **và** $f'(x)=0$ **chỉ tại hữu hạn điểm** của $K$ thì $f$ vẫn đồng biến (nghịch biến) trên $K$.
> - Nếu $f'(x)=0$ với mọi $x\in K$ thì $f$ **không đổi** (hàm hằng) trên $K$.

Chú ý thứ nhất giải thích vì sao $y=x^3$ **đồng biến trên $\mathbb R$** dù $y'=3x^2$ bằng $0$ tại $x=0$: đồ thị chỉ "nằm ngang" đúng tại một điểm rồi lại đi lên tiếp (Hình 2a). Còn nếu $f'=0$ trên **cả một khoảng** thì trên khoảng đó đồ thị là một đoạn nằm ngang — hàm không tăng cũng không giảm.

![Hình 2. Hai trường hợp đặc biệt cần nhớ: (a) y = x³ và (b) y = |x|](h2-hai-truong-hop-dac-biet.svg)

> [!vi-du] Ví dụ 2
> Tìm các khoảng đồng biến, nghịch biến của mỗi hàm số:
>
> a) $y=-x^2+6x-5$;  b) $y=x^3+3x-1$.

> [!goi-y] Gợi ý 1
> Tính $y'$ rồi xét xem $y'$ dương ở đâu, âm ở đâu.

> [!goi-y] Gợi ý 2
> b) $y'=3x^2+3$. Biểu thức này có bao giờ âm hay bằng $0$ không?

> [!loi-giai] Lời giải
> a) Tập xác định $\mathbb R$. $y'=-2x+6$; $y'>0\iff x<3$, $y'<0\iff x>3$.
> Hàm số đồng biến trên $(-\infty;\,3)$, nghịch biến trên $(3;\,+\infty)$. (Đúng với hình dạng parabol "úp xuống" có đỉnh tại $x=3$.)
>
> b) Tập xác định $\mathbb R$. $y'=3x^2+3>0$ với mọi $x$. Vậy hàm số **đồng biến trên $\mathbb R$**.

> [!bay]
> "Hàm số đồng biến trên $K$ **thì** $f'(x)>0$ trên $K$" là **sai** — phản ví dụ $y=x^3$ có $f'(0)=0$. Điều đúng chỉ là: đồng biến (và có đạo hàm) thì $f'(x)\ge0$. Câu Đúng/Sai rất thích kiểm tra chiều "ngược lại" này.

### 1.3. Bảng biến thiên — công cụ trung tâm

Với hàm phức tạp hơn, $f'(x)$ đổi dấu nhiều lần. Ta gom mọi thông tin vào một **bảng biến thiên** (BBT) gồm ba dòng:
- dòng $x$: các điểm "mốc" xếp tăng dần (kèm $-\infty$, $+\infty$ hoặc hai đầu tập xác định);
- dòng $y'$: dấu của đạo hàm trên từng khoảng ($0$ tại điểm đạo hàm bằng $0$, gạch đôi $\Vert$ tại điểm hàm số không xác định);
- dòng $y$: mũi tên **đi lên** ($\nearrow$) nếu $y'>0$, **đi xuống** ($\searrow$) nếu $y'<0$, kèm giá trị tại các mốc và giới hạn ở hai đầu.

> [!ghi-nho] Các bước xét tính đơn điệu (SGK tr. 8)
> 1. Tìm **tập xác định**.
> 2. Tính $f'(x)$; tìm các điểm $x_i$ mà tại đó $f'(x)=0$ **hoặc** $f'(x)$ không xác định.
> 3. Sắp xếp các $x_i$ tăng dần, lập **bảng biến thiên**.
> 4. Kết luận các khoảng đồng biến, nghịch biến.

**Mẹo xét dấu $f'(x)$:** với $f'(x)$ là tam thức bậc hai $ax^2+bx+c$ có hai nghiệm, nhớ câu "**trong trái, ngoài cùng**": giữa hai nghiệm $f'$ trái dấu với $a$, ngoài hai nghiệm cùng dấu với $a$. Với biểu thức phức tạp hơn, thay một giá trị $x$ cụ thể trong mỗi khoảng để thử dấu.

> [!vi-du] Ví dụ 3
> Xét tính đơn điệu của hàm số $y=x^3-3x^2-9x+2$.

> [!goi-y] Gợi ý 1
> $y'=3x^2-6x-9=3(x^2-2x-3)$. Phân tích thành nhân tử để tìm nghiệm.

> [!goi-y] Gợi ý 2
> Nghiệm là $x=-1$ và $x=3$; hệ số $a=3>0$ nên $y'$ âm **giữa** hai nghiệm, dương **ngoài** hai nghiệm. Tính thêm $y(-1)$ và $y(3)$ để điền vào bảng.

> [!loi-giai] Lời giải
> Tập xác định $\mathbb R$. $y'=3(x+1)(x-3)$; $y'=0\iff x=-1$ hoặc $x=3$. Ta có $y(-1)=7$, $y(3)=-25$.
>
> $$\begin{array}{c|ccccccc} x & -\infty & & -1 & & 3 & & +\infty \\ \hline y' & & + & 0 & - & 0 & + & \\ \hline & & & 7 & & & & +\infty \\ y & & \nearrow & & \searrow & & \nearrow & \\ & -\infty & & & & -25 & & \end{array}$$
>
> Hàm số đồng biến trên các khoảng $(-\infty;\,-1)$ và $(3;\,+\infty)$; nghịch biến trên khoảng $(-1;\,3)$.

> [!vi-du] Ví dụ 4
> Xét chiều biến thiên của hàm số $y=\dfrac{2x+1}{x-1}$.

> [!goi-y] Gợi ý 1
> Tập xác định có "lỗ" ở đâu? Dùng công thức nhanh $\dfrac{ad-bc}{(cx+d)^2}$.

> [!goi-y] Gợi ý 2
> $ad-bc=2\cdot(-1)-1\cdot1$. Mẫu $(x-1)^2$ luôn dương trên tập xác định.

> [!loi-giai] Lời giải
> Tập xác định $\mathbb R\setminus\{1\}$. $y'=\dfrac{2\cdot(-1)-1\cdot1}{(x-1)^2}=\dfrac{-3}{(x-1)^2}<0$ với mọi $x\ne1$.
>
> $$\begin{array}{c|ccccc} x & -\infty & & 1 & & +\infty \\ \hline y' & & - & \Vert & - & \\ \hline & 2 & & \Vert\;+\infty & & \\ y & & \searrow & \Vert & \searrow & \\ & & & -\infty\;\Vert & & 2 \end{array}$$
>
> Hàm số nghịch biến trên **từng** khoảng $(-\infty;\,1)$ và $(1;\,+\infty)$.

> [!bay] Hàm phân thức: chỉ kết luận trên từng khoảng
> **Không** được nói "nghịch biến trên $\mathbb R\setminus\{1\}$". Lấy $x_1=0<x_2=2$: $y(0)=-1<y(2)=5$ — tức là "tăng" khi đi qua chỗ đứt. Vì vậy chỉ được kết luận trên **từng khoảng** của tập xác định. Phương án "nghịch biến trên $\mathbb R$" hay "trên $\mathbb R\setminus\{1\}$" luôn là phương án **sai**.

> [!vi-du] Ví dụ 5
> Xét chiều biến thiên của hàm số $y=\sqrt{6x-x^2}$.

> [!goi-y] Gợi ý 1
> Điều kiện căn: $6x-x^2\ge0$. Tập xác định là một **đoạn**.

> [!goi-y] Gợi ý 2
> $y'=\dfrac{(6x-x^2)'}{2\sqrt{6x-x^2}}=\dfrac{6-2x}{2\sqrt{6x-x^2}}=\dfrac{3-x}{\sqrt{6x-x^2}}$. Mẫu dương trên $(0;6)$ nên dấu $y'$ là dấu của $3-x$.

> [!loi-giai] Lời giải
> Tập xác định $[0;\,6]$. Với $x\in(0;\,6)$: $y'=\dfrac{3-x}{\sqrt{6x-x^2}}$; $y'=0\iff x=3$; $y(0)=y(6)=0$, $y(3)=3$.
>
> $$\begin{array}{c|ccccc} x & 0 & & 3 & & 6 \\ \hline y' & & + & 0 & - & \\ \hline & & & 3 & & \\ y & & \nearrow & & \searrow & \\ & 0 & & & & 0 \end{array}$$
>
> Hàm số đồng biến trên $(0;\,3)$, nghịch biến trên $(3;\,6)$. (Đồ thị là nửa trên của đường tròn tâm $(3;\,0)$ bán kính $3$ — rất khớp!)

> [!bay]
> Với hàm có căn, **quên tìm tập xác định** là lỗi chết người: phương án "đồng biến trên $(-\infty;\,3)$" nghe rất hợp lí nhưng sai, vì hàm số không xác định khi $x<0$.

> [!vi-du] Ví dụ 6 (Ứng dụng — chuyển động)
> Một chất điểm chuyển động trên một trục số nằm ngang, chiều dương từ trái sang phải. Vị trí của nó tại thời điểm $t$ giây là $s(t)=t^3-6t^2+9t$ (mét), $t\ge0$. Trong khoảng thời gian nào chất điểm đi sang phải, trong khoảng nào đi sang trái?

> [!goi-y] Gợi ý 1
> Đi sang phải $\iff$ vị trí $s$ tăng $\iff$ vận tốc $v(t)=s'(t)>0$.

> [!goi-y] Gợi ý 2
> $v(t)=3t^2-12t+9=3(t-1)(t-3)$. Xét dấu trên $[0;\,+\infty)$.

> [!loi-giai] Lời giải
> $v(t)=s'(t)=3(t-1)(t-3)$; $v>0$ khi $0<t<1$ hoặc $t>3$; $v<0$ khi $1<t<3$.
> Vậy chất điểm đi **sang phải** trong khoảng $(0;\,1)$ giây và $(3;\,+\infty)$; đi **sang trái** trong khoảng $(1;\,3)$ giây. Tại $t=1$ và $t=3$ vận tốc bằng $0$ — đó là lúc chất điểm "quay đầu" (đổi chiều chuyển động).

## 2. Cực trị của hàm số

### 2.1. Khái niệm cực đại, cực tiểu

Nhìn lại Hình 1: tại $x=-1$ đồ thị đang đi lên thì chuyển sang đi xuống — điểm $(-1;\,4)$ giống **đỉnh một ngọn đồi**. Tại $x=1$ đồ thị đi xuống rồi đi lên — điểm $(1;\,0)$ giống **đáy một thung lũng**. Điều quan trọng: "đỉnh đồi" chỉ cao nhất **so với vùng lân cận**, không nhất thiết cao nhất trên toàn bộ đồ thị (ở Hình 1, khi $x>2$ đồ thị còn lên cao hơn $4$ nhiều).

> [!ghi-nho] Định nghĩa (SGK tr. 9)
> Cho $y=f(x)$ xác định và liên tục trên khoảng $(a;\,b)$ ($a$ có thể là $-\infty$, $b$ có thể là $+\infty$) và $x_0\in(a;\,b)$.
> - Nếu có số $h>0$ sao cho $f(x)<f(x_0)$ với mọi $x\in(x_0-h;\,x_0+h)\subset(a;\,b)$, $x\ne x_0$, thì $f$ **đạt cực đại** tại $x_0$.
> - Nếu có số $h>0$ sao cho $f(x)>f(x_0)$ với mọi $x\in(x_0-h;\,x_0+h)\subset(a;\,b)$, $x\ne x_0$, thì $f$ **đạt cực tiểu** tại $x_0$.

Ba khái niệm **phải phân biệt** (đề thi hỏi đúng chữ nào thì trả lời đúng thứ đó):

| Gọi là | Là gì | Ở Hình 1 |
|---|---|---|
| **Điểm cực đại của hàm số** | số $x_0$ (một hoành độ) | $x=-1$ |
| **Giá trị cực đại** $f_{\text{CĐ}}$ hay $y_{\text{CĐ}}$ | số $f(x_0)$ (một tung độ) | $y_{\text{CĐ}}=4$ |
| **Điểm cực đại của đồ thị** | điểm $M_0(x_0;\,f(x_0))$ | $(-1;\,4)$ |

Với cực tiểu cũng vậy: điểm cực tiểu của hàm số là $x=1$, giá trị cực tiểu $y_{\text{CT}}=0$, điểm cực tiểu của đồ thị là $(1;\,0)$. Điểm cực đại và điểm cực tiểu gọi chung là **điểm cực trị**; giá trị cực đại và giá trị cực tiểu gọi chung là **cực trị** (giá trị cực trị).

**Vì sao gọi là "cực trị địa phương"?** Định nghĩa chỉ so $f(x_0)$ với các điểm **gần** $x_0$ (trong khoảng $(x_0-h;\,x_0+h)$). Vì vậy có thể xảy ra chuyện lạ: giá trị cực đại **nhỏ hơn** giá trị cực tiểu (Hình 3).

![Hình 3. Đồ thị y = x + 1/x: giá trị cực đại nhỏ hơn giá trị cực tiểu — cực trị chỉ mang tính "địa phương"](h3-cuc-tri-la-dia-phuong.svg)

> [!vi-du] Ví dụ 7
> Cho hàm số $y=f(x)$ có bảng biến thiên:
>
> $$\footnotesize\begin{array}{c|ccccccccc} x & -\infty & & -2 & & 0 & & 2 & & +\infty \\ \hline y' & & - & 0 & + & 0 & - & 0 & + & \\ \hline & +\infty & & & & 1 & & & & +\infty \\ y & & \searrow & & \nearrow & & \searrow & & \nearrow & \\ & & & -3 & & & & -3 & & \end{array}$$
>
> a) Tìm các điểm cực tiểu của hàm số và giá trị cực tiểu.
>
> b) Tìm điểm cực đại của đồ thị hàm số.
>
> c) Hàm số có bao nhiêu điểm cực trị?

> [!goi-y] Gợi ý 1
> Cực tiểu là chỗ mũi tên "đi xuống rồi đi lên" (dấu $y'$ đổi từ $-$ sang $+$).

> [!goi-y] Gợi ý 2
> "Điểm cực đại của **đồ thị**" phải viết dạng tọa độ $(x;\,y)$.

> [!loi-giai] Lời giải
> a) $y'$ đổi dấu từ $-$ sang $+$ tại $x=-2$ và $x=2$: hàm số có **hai** điểm cực tiểu $x=\pm2$, giá trị cực tiểu $y_{\text{CT}}=-3$ (cả hai điểm cùng giá trị).
>
> b) $y'$ đổi dấu từ $+$ sang $-$ tại $x=0$, $y(0)=1$. Điểm cực đại của đồ thị là $(0;\,1)$.
>
> c) Có $3$ điểm cực trị: $x=-2$, $x=0$, $x=2$.

> [!bay]
> Ở câu hỏi "giá trị cực đại của hàm số bằng bao nhiêu?", đáp án là $1$; phương án nhiễu hay gặp là $0$ (điểm cực đại $x$) hoặc $(0;\,1)$ (điểm của đồ thị). Ở câu "hàm số có bao nhiêu **giá trị** cực tiểu?", bảng trên chỉ có **một** giá trị $-3$, nhưng có **hai** điểm cực tiểu.

### 2.2. Cách tìm cực trị

**Ý tưởng:** cực đại là chỗ hàm số "đang tăng thì chuyển sang giảm", tức là $f'$ đổi từ **dương sang âm**. Cực tiểu là chỗ "đang giảm thì chuyển sang tăng", $f'$ đổi từ **âm sang dương**.

> [!ghi-nho] Điều kiện đủ để có cực trị (SGK tr. 10)
> Giả sử $f$ liên tục trên khoảng $(a;\,b)$ chứa $x_0$ và có đạo hàm trên $(a;\,x_0)$ và $(x_0;\,b)$.
> - $f'(x)<0$ trên $(a;\,x_0)$ và $f'(x)>0$ trên $(x_0;\,b)$ $\Rightarrow$ $x_0$ là **điểm cực tiểu**.
> - $f'(x)>0$ trên $(a;\,x_0)$ và $f'(x)<0$ trên $(x_0;\,b)$ $\Rightarrow$ $x_0$ là **điểm cực đại**.

Gọn trong bảng biến thiên:

$$\begin{array}{c|ccccc} x & a & & x_0 & & b \\ \hline f'(x) & & - & & + & \\ \hline f(x) & & \searrow & f(x_0)\ \text{(CT)} & \nearrow & \end{array}$$

$$\begin{array}{c|ccccc} x & a & & x_0 & & b \\ \hline f'(x) & & + & & - & \\ \hline f(x) & & \nearrow & f(x_0)\ \text{(CĐ)} & \searrow & \end{array}$$

**Vì sao $f'$ không đổi dấu thì không có cực trị?** Nếu $f'>0$ ở cả hai phía của $x_0$ thì hàm số tăng liên tục khi đi qua $x_0$: bên trái $x_0$ có giá trị nhỏ hơn $f(x_0)$, bên phải có giá trị lớn hơn — $f(x_0)$ chẳng phải "đỉnh" cũng chẳng phải "đáy". Đó chính là chuyện xảy ra với $y=x^3$ tại $x=0$ (Hình 2a).

Ngược lại, hàm $y=\lvert x\rvert$ **không có đạo hàm** tại $x=0$ nhưng $y'=-1$ khi $x<0$ và $y'=1$ khi $x>0$: đạo hàm đổi dấu từ $-$ sang $+$, nên $x=0$ là điểm cực tiểu (Hình 2b). Vì vậy khi tìm cực trị phải xét **cả** những điểm đạo hàm không xác định (nhưng hàm số vẫn xác định).

> [!ghi-nho] Quy tắc tìm cực trị (SGK tr. 11)
> 1. Tìm tập xác định.
> 2. Tính $f'(x)$; tìm các điểm tại đó $f'(x)=0$ hoặc $f'(x)$ không xác định.
> 3. Lập bảng biến thiên.
> 4. Từ bảng biến thiên suy ra cực trị: $f'$ đổi dấu **$+\to-$** là **cực đại**, **$-\to+$** là **cực tiểu**, **không đổi dấu** là **không có cực trị**.

> [!vi-du] Ví dụ 8
> Tìm cực trị của hàm số $y=-x^4+2x^2+1$.

> [!goi-y] Gợi ý 1
> $y'=-4x^3+4x=-4x(x^2-1)$. Có ba nghiệm.

> [!goi-y] Gợi ý 2
> Thử dấu: tại $x=2$, $y'=-32+8<0$. Ba nghiệm đơn nên dấu $y'$ **đan xen** khi đi qua từng nghiệm.

> [!loi-giai] Lời giải
> Tập xác định $\mathbb R$. $y'=-4x(x-1)(x+1)$; $y'=0\iff x\in\{-1;\,0;\,1\}$. $y(\pm1)=2$, $y(0)=1$.
>
> $$\small\begin{array}{c|ccccccccc} x & -\infty & & -1 & & 0 & & 1 & & +\infty \\ \hline y' & & + & 0 & - & 0 & + & 0 & - & \\ \hline & & & 2 & & & & 2 & & \\ y & & \nearrow & & \searrow & & \nearrow & & \searrow & \\ & -\infty & & & & 1 & & & & -\infty \end{array}$$
>
> Hàm số đạt cực đại tại $x=-1$ và $x=1$, $y_{\text{CĐ}}=2$; đạt cực tiểu tại $x=0$, $y_{\text{CT}}=1$.

> [!meo] Mẹo với hàm trùng phương
> Với $y=ax^4+bx^2+c$ ($a\ne0$): $y'=2x(2ax^2+b)$. Nếu $a$ và $b$ **trái dấu** thì có **3** điểm cực trị; nếu $ab\ge0$ thì chỉ có **1** điểm cực trị là $x=0$. Ví dụ 8: $a=-1$, $b=2$ trái dấu → 3 cực trị ✓. Dùng mẹo để **soát** đáp án trắc nghiệm.

> [!vi-du] Ví dụ 9
> Tìm cực trị của hàm số $y=\dfrac{x^2+3}{x+1}$.

> [!goi-y] Gợi ý 1
> Dùng quy tắc thương: $y'=\dfrac{2x(x+1)-(x^2+3)}{(x+1)^2}$. Rút gọn tử số.

> [!goi-y] Gợi ý 2
> Tử số $x^2+2x-3=(x-1)(x+3)$. Mẫu luôn dương nên dấu $y'$ là dấu của tử. Nhớ có gạch đôi tại $x=-1$.

> [!loi-giai] Lời giải
> Tập xác định $\mathbb R\setminus\{-1\}$. $y'=\dfrac{x^2+2x-3}{(x+1)^2}$; $y'=0\iff x=-3$ hoặc $x=1$. $y(-3)=\dfrac{12}{-2}=-6$, $y(1)=\dfrac42=2$.
>
> $$\footnotesize\begin{array}{c|ccccccccc} x & -\infty & & -3 & & -1 & & 1 & & +\infty \\ \hline y' & & + & 0 & - & \Vert & - & 0 & + & \\ \hline & & & -6 & & \Vert\;+\infty & & & & +\infty \\ y & & \nearrow & & \searrow & \Vert & \searrow & & \nearrow & \\ & -\infty & & & & -\infty\;\Vert & & 2 & & \end{array}$$
>
> Hàm số đạt cực đại tại $x=-3$, $y_{\text{CĐ}}=-6$; đạt cực tiểu tại $x=1$, $y_{\text{CT}}=2$. (Lại thấy $y_{\text{CĐ}}<y_{\text{CT}}$ — hoàn toàn bình thường.)

> [!bay]
> $x=-1$ làm $y'$ không xác định nhưng **không** phải điểm cực trị — vì hàm số cũng **không xác định** tại đó. Điểm cực trị phải thuộc tập xác định.

> [!meo] Soát nhanh bằng máy tính cầm tay (Casio fx-580VN X)
> - **Tính đạo hàm tại một điểm** (phím $\frac{d}{dx}$, thường bấm SHIFT rồi phím tích phân): nhập $\frac{d}{dx}\big(f(x)\big)\big|_{x=x_0}$ để kiểm tra $f'(x_0)=0$, hoặc thử dấu $f'$ tại một điểm trong mỗi khoảng.
> - **Chế độ Bảng (Table)**: nhập $f(x)$, cho $x$ chạy từ trái sang phải với bước nhỏ, nhìn cột $f(x)$ tăng hay giảm để soát BBT. Tên mục trong MENU có thể khác nhau tùy máy — hãy thử trước với Ví dụ 3.
> Máy chỉ để **soát**; lời giải vẫn cần đạo hàm và bảng biến thiên.

### 2.3. Đọc tính đơn điệu và cực trị từ đồ thị của $f'(x)$

Đây là dạng **bẫy nhất** của chương (gắn với Bài tập 1.6, SGK tr. 14). Đề cho **đồ thị của đạo hàm** $y=f'(x)$, không cho đồ thị của $f$. Nguyên tắc duy nhất cần nhớ:

> [!ghi-nho] Đọc đồ thị của đạo hàm: chỉ nhìn vị trí so với trục hoành
> - Đồ thị $f'$ nằm **trên** trục $Ox$ ($f'>0$) → $f$ **đồng biến**.
> - Đồ thị $f'$ nằm **dưới** trục $Ox$ ($f'<0$) → $f$ **nghịch biến**.
> - Đồ thị $f'$ **cắt** (xuyên qua) trục $Ox$ tại $x_0$ → $x_0$ là **điểm cực trị** của $f$: cắt từ trên xuống ($+\to-$) là cực đại, từ dưới lên ($-\to+$) là cực tiểu.
> - Đồ thị $f'$ chỉ **chạm** (tiếp xúc) trục $Ox$ rồi quay lại → $f'$ không đổi dấu → **không** là cực trị.

![Hình 4. Từ đồ thị của f′(x) (trên) suy ra bảng biến thiên của f(x) (dưới)](h4-do-thi-dao-ham.svg)

> [!vi-du] Ví dụ 10
> Hàm số $f(x)$ có đạo hàm trên $\mathbb R$, đồ thị của $y=f'(x)$ như phần trên của Hình 4 (cắt trục hoành tại $x=-2$, $x=3$ và chạm trục hoành tại $x=1$).
>
> a) Tìm các khoảng đồng biến, nghịch biến của $f$.
>
> b) Hàm số $f$ có bao nhiêu điểm cực trị? Là những điểm nào?
>
> c) Trên khoảng $(-1;\,1)$, đồ thị $f'$ **đi lên**. Có phải $f$ đồng biến trên $(-1;\,1)$ không?

> [!goi-y] Gợi ý 1
> Tô màu: chỗ nào đồ thị $f'$ ở trên trục hoành, chỗ nào ở dưới?

> [!goi-y] Gợi ý 2
> c) "Đồ thị $f'$ đi lên" nghĩa là $f'$ **tăng**, không phải $f'$ **dương**.

> [!loi-giai] Lời giải
> a) $f'>0$ trên $(-\infty;\,-2)$ và $(3;\,+\infty)$ → $f$ đồng biến trên hai khoảng này. $f'<0$ trên $(-2;\,1)$ và $(1;\,3)$, $f'(1)=0$ chỉ tại một điểm → $f$ **nghịch biến trên cả khoảng** $(-2;\,3)$.
>
> b) $f'$ đổi dấu $+\to-$ tại $x=-2$ → cực đại; đổi dấu $-\to+$ tại $x=3$ → cực tiểu; tại $x=1$ chỉ chạm, không đổi dấu → không là cực trị. Vậy $f$ có **2** điểm cực trị: $x=-2$ (cực đại) và $x=3$ (cực tiểu).
>
> c) **Không.** Trên $(-1;\,1)$ đồ thị $f'$ đi lên nhưng vẫn nằm **dưới** trục hoành, tức $f'<0$: $f$ đang **nghịch biến**. Tương tự, trên $(-\infty;\,-2)$ đồ thị $f'$ đi xuống nhưng vẫn ở trên trục hoành → $f$ vẫn **đồng biến**.

> [!bay] Bẫy số 1 của chương
> - Đếm số giao điểm của đồ thị $f'$ với trục hoành rồi kết luận số cực trị → **sai** nếu có điểm chỉ chạm (như $x=1$).
> - Nhìn các "đáy" của đồ thị $f'$ (ở Hình 4, gần $x\approx-1{,}1$ và $x\approx2{,}4$) rồi tưởng là cực trị của $f$ → **sai**: đó là cực trị của $f'$, không phải của $f$.
> - Nhìn đồ thị $f'$ đi lên/đi xuống để kết luận $f$ tăng/giảm → **sai**: chỉ nhìn **trên hay dưới** trục hoành.

> [!ung-dung] Nồng độ thuốc trong máu
> Trong dược lí, sau khi uống thuốc, nồng độ thuốc $C(t)$ trong máu thường **tăng** (thuốc đang được hấp thu) rồi **giảm** (thuốc bị chuyển hóa, đào thải). Thời điểm $C$ đạt **cực đại** gọi là $t_{\max}$, nồng độ khi đó là $C_{\max}$ — hai thông số các dược sĩ, bác sĩ dùng để so sánh các dạng bào chế và quyết định khoảng cách giữa các liều. Tìm $t_{\max}$ chính là tìm điểm cực đại: giải $C'(t)=0$ và kiểm tra $C'$ đổi dấu từ $+$ sang $-$ (xem Ví dụ 14).

## Dạng bài thi hay gặp

### Dạng 1. Đọc bảng biến thiên hoặc đồ thị của $f(x)$

- **Nhận biết:** đề cho BBT hoặc hình đồ thị $y=f(x)$, hỏi "hàm số đồng biến trên khoảng nào", "giá trị cực đại", "điểm cực tiểu của đồ thị", "số điểm cực trị".
- **Phương pháp:** khoảng đơn điệu đọc theo **dòng $x$** (trục hoành); cực trị: chỗ mũi tên đổi chiều. Phương án đúng có thể là một khoảng **con** của khoảng đơn điệu.
- **Bẫy:** đọc khoảng theo dòng $y$; nhầm điểm cực trị ↔ giá trị cực trị ↔ điểm của đồ thị; chọn khoảng chứa điểm gạch đôi; chọn khoảng "lấn" qua điểm đổi chiều.

> [!vi-du] Ví dụ 11
> Cho hàm số $y=f(x)$ có bảng biến thiên:
>
> $$\begin{array}{c|ccccccc} x & -\infty & & -1 & & 2 & & +\infty \\ \hline y' & & + & 0 & - & 0 & + & \\ \hline & & & 3 & & & & +\infty \\ y & & \nearrow & & \searrow & & \nearrow & \\ & -\infty & & & & -4 & & \end{array}$$
>
> Hàm số đã cho nghịch biến trên khoảng nào trong các khoảng: $(-4;\,3)$; $(0;\,2)$; $(-1;\,+\infty)$; $(-\infty;\,2)$?

> [!goi-y] Gợi ý 1
> Khoảng nghịch biến đọc từ dòng $x$ là $(-1;\,2)$. Phương án đúng phải là khoảng **nằm trọn** trong $(-1;\,2)$.

> [!goi-y] Gợi ý 2
> $(-4;\,3)$ lấy từ dòng $y$ — loại ngay.

> [!loi-giai] Lời giải
> $f$ nghịch biến trên $(-1;\,2)$ nên nghịch biến trên mọi khoảng con của nó, chẳng hạn $(0;\,2)$. Các phương án còn lại đều sai: $(-4;\,3)$ là khoảng giá trị $y$; $(-1;\,+\infty)$ và $(-\infty;\,2)$ đều chứa phần hàm số đồng biến. **Đáp án: $(0;\,2)$.**

### Dạng 2. Tìm khoảng đơn điệu, cực trị của hàm số cho bởi công thức

- **Nhận biết:** "hàm số $y=\ldots$ đồng biến trên khoảng nào", "giá trị cực tiểu của hàm số", "tổng/hiệu các giá trị cực trị", "khoảng cách giữa hai điểm cực trị của đồ thị".
- **Phương pháp:** đúng 4 bước của quy tắc; với hàm bậc ba, bậc bốn, phân thức đã quen thì chỉ cần $f'$ → nghiệm → dấu → kết luận. Tính $y$ tại các điểm cực trị **từ hàm $f$ ban đầu** (không phải từ $f'$).
- **Bẫy:** thay nghiệm vào $f'$ thay vì $f$ (luôn ra $0$!); quên tập xác định với hàm căn, phân thức; nhầm dấu khi phân tích nhân tử.

> [!vi-du] Ví dụ 12 (Trả lời ngắn)
> Cho hàm số $y=2x^3+3x^2-12x+1$. Gọi $y_{\text{CĐ}}$, $y_{\text{CT}}$ lần lượt là giá trị cực đại và giá trị cực tiểu. Tính $y_{\text{CĐ}}-y_{\text{CT}}$.

> [!goi-y] Gợi ý 1
> $y'=6x^2+6x-12=6(x-1)(x+2)$. Hệ số $a=6>0$: hàm bậc ba "đi lên – xuống – lên", nên nghiệm **nhỏ** là điểm cực đại.

> [!goi-y] Gợi ý 2
> Tính $y(-2)$ và $y(1)$ bằng hàm ban đầu.

> [!loi-giai] Lời giải
> $y'=0\iff x=-2$ hoặc $x=1$. $y'$ đổi dấu $+\to-$ tại $x=-2$, $-\to+$ tại $x=1$.
> $y_{\text{CĐ}}=y(-2)=-16+12+24+1=21$; $y_{\text{CT}}=y(1)=2+3-12+1=-6$.
> $y_{\text{CĐ}}-y_{\text{CT}}=21-(-6)=$ **27**.

> [!meo] Mẹo với hàm bậc ba
> Với $y=ax^3+bx^2+cx+d$ ($a\ne0$):
> - $y'=3ax^2+2bx+c$ có hai nghiệm phân biệt $\iff$ hàm số có **2** cực trị; còn lại (vô nghiệm hoặc nghiệm kép) thì **không** có cực trị và hàm số đơn điệu trên $\mathbb R$.
> - $a>0$: dáng "lên – xuống – lên", cực đại ở nghiệm **nhỏ**. $a<0$: "xuống – lên – xuống", cực tiểu ở nghiệm nhỏ.
> - Đồng biến trên $\mathbb R$ $\iff$ $a>0$ và $y'$ có biệt thức $\Delta'=b^2-3ac\le0$.

### Dạng 3. Cho $f'(x)$ — bằng công thức hoặc đồ thị

- **Nhận biết:** "Cho hàm số $f(x)$ có đạo hàm $f'(x)=x^2(x-1)(x+2)^3$…" hoặc "đồ thị hàm số $y=f'(x)$ như hình…". Hỏi số điểm cực trị, khoảng đơn điệu của $f$.
- **Phương pháp:** **không** cần tìm $f$. Lập bảng **xét dấu $f'$**: nghiệm bội **lẻ** → $f'$ đổi dấu → là điểm cực trị; nghiệm bội **chẵn** → không đổi dấu → không là cực trị. Với đồ thị: cắt trục là cực trị, chạm trục thì không (mục 2.3).
- **Bẫy:** đếm tất cả nghiệm của $f'$; nhầm đồ thị $f'$ với đồ thị $f$.

> [!vi-du] Ví dụ 13
> Cho hàm số $f(x)$ có đạo hàm $f'(x)=x^2(x-1)(x+2)^3$ với mọi $x\in\mathbb R$. Hàm số $f$ có bao nhiêu điểm cực trị? Điểm nào là điểm cực đại?

> [!goi-y] Gợi ý 1
> Liệt kê nghiệm kèm bội: $x=0$ (bội 2), $x=1$ (bội 1), $x=-2$ (bội 3).

> [!goi-y] Gợi ý 2
> Thử dấu tại một điểm, ví dụ $x=2$: $f'(2)=4\cdot1\cdot64>0$. Đi từ phải sang trái, qua nghiệm bội lẻ thì đổi dấu, qua nghiệm bội chẵn thì giữ dấu.

> [!loi-giai] Lời giải
> Bảng xét dấu: $f'>0$ trên $(-\infty;\,-2)$; $f'<0$ trên $(-2;\,0)$ và $(0;\,1)$; $f'>0$ trên $(1;\,+\infty)$.
> $f'$ đổi dấu tại $x=-2$ ($+\to-$, **cực đại**) và $x=1$ ($-\to+$, cực tiểu); không đổi dấu tại $x=0$.
> Vậy $f$ có **2** điểm cực trị; điểm cực đại là $x=-2$.

### Dạng 4. Câu Đúng/Sai về một hàm số — thường gắn bối cảnh thực tế

- **Nhận biết:** một hàm số (thường là mô hình thực tế: vận tốc, nồng độ, lợi nhuận, dân số…) và 4 ý: đạo hàm, khoảng tăng/giảm, thời điểm đạt cực đại, giá trị cực đại hoặc một tính toán liên quan.
- **Phương pháp:** tính $f'$ **một lần, cẩn thận**, lập BBT trên đúng **miền thực tế** (thường $t\ge0$), rồi soát từng ý dựa trên BBT. Ý cuối thường là vận dụng: giải phương trình, so sánh hai thời điểm.
- **Bẫy:** quên điều kiện $t\ge0$ (nghiệm âm phải loại); nhầm "thời điểm" ($t$) với "giá trị" ($C$); đơn vị.

> [!vi-du] Ví dụ 14 (Đúng/Sai)
> Nồng độ một loại thuốc trong máu bệnh nhân sau khi uống $t$ giờ được mô hình hóa bởi $C(t)=\dfrac{30t}{t^2+4}$ (mg/L), $t\ge0$. Xét các mệnh đề:
>
> a) $C'(t)=\dfrac{30(4-t^2)}{(t^2+4)^2}$.
>
> b) Nồng độ thuốc tăng trong 3 giờ đầu.
>
> c) Nồng độ thuốc đạt cực đại $7{,}5$ mg/L tại thời điểm 2 giờ sau khi uống.
>
> d) Khoảng thời gian nồng độ thuốc từ $6$ mg/L trở lên kéo dài đúng 3 giờ.

> [!goi-y] Gợi ý 1
> Quy tắc thương: $C'=\dfrac{30(t^2+4)-30t\cdot2t}{(t^2+4)^2}$. Với $t\ge0$, $C'$ cùng dấu với $4-t^2$.

> [!goi-y] Gợi ý 2
> d) Giải $C(t)=6$: $30t=6t^2+24\iff t^2-5t+4=0$. Từ BBT, $C\ge6$ giữa hai nghiệm.

> [!loi-giai] Lời giải
> a) **Đúng.** $C'=\dfrac{30t^2+120-60t^2}{(t^2+4)^2}=\dfrac{30(4-t^2)}{(t^2+4)^2}$.
>
> b) **Sai.** $C'>0$ chỉ khi $0<t<2$; với $2<t<3$ thì $C'<0$ — nồng độ đã giảm.
>
> c) **Đúng.** $C'$ đổi dấu $+\to-$ tại $t=2$ (loại $t=-2$ vì $t\ge0$); $C(2)=\dfrac{60}{8}=7{,}5$ mg/L.
>
> d) **Đúng.** $C(t)=6\iff t=1$ hoặc $t=4$. $C$ tăng trên $(0;\,2)$, giảm trên $(2;\,+\infty)$, nên $C(t)\ge6\iff1\le t\le4$: kéo dài $4-1=3$ giờ.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Đồng biến trên $K$ | $x_1<x_2\Rightarrow f(x_1)<f(x_2)$; đồ thị đi lên |
| Nghịch biến trên $K$ | $x_1<x_2\Rightarrow f(x_1)>f(x_2)$; đồ thị đi xuống |
| Dấu đạo hàm | $f'>0$ trên $K$ → đồng biến; $f'<0$ → nghịch biến; $f'=0$ tại hữu hạn điểm vẫn được |
| Điểm cực đại | $f'$ đổi dấu $+\to-$ (tăng rồi giảm) |
| Điểm cực tiểu | $f'$ đổi dấu $-\to+$ (giảm rồi tăng) |
| Không là cực trị | $f'$ không đổi dấu (ví dụ $y=x^3$ tại $0$; nghiệm bội chẵn) |
| Ba khái niệm | điểm cực trị $x_0$ · giá trị cực trị $f(x_0)$ · điểm cực trị của đồ thị $(x_0;\,f(x_0))$ |
| Đồ thị $f'$ | trên $Ox$ → $f$ tăng; dưới $Ox$ → $f$ giảm; **cắt** $Ox$ → cực trị; **chạm** $Ox$ → không |
| Phân thức bậc nhất | $y'=\dfrac{ad-bc}{(cx+d)^2}$: đơn điệu trên **từng** khoảng, không có cực trị |

**Sơ đồ khi gặp đề:** có công thức $f$ → tập xác định → $f'$ → nghiệm (và chỗ $f'$ không xác định) → BBT → đọc kết quả. Có BBT/đồ thị $f$ → đọc theo trục hoành, mũi tên đổi chiều là cực trị. Có $f'$ (công thức hoặc đồ thị) → chỉ xét **dấu** của $f'$ — đổi dấu mới là cực trị.
