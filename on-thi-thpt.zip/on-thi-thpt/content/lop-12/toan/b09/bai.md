---
title: Khoảng biến thiên và khoảng tứ phân vị
thoi-gian: 45 phút
muc-tieu:
  - Nhắc lại được mẫu số liệu ghép nhóm (nhóm, tần số, cỡ mẫu, giá trị đại diện) và cách tính tứ phân vị của mẫu ghép nhóm
  - Tính được khoảng biến thiên $R=a_{k+1}-a_1$ của mẫu số liệu ghép nhóm
  - Tính được tứ phân vị $Q_1$, $Q_3$ và khoảng tứ phân vị $\Delta_Q=Q_3-Q_1$ của mẫu số liệu ghép nhóm
  - Hiểu ý nghĩa, vai trò của khoảng biến thiên và khoảng tứ phân vị trong việc đo mức độ phân tán; biết vì sao khoảng tứ phân vị ít bị ảnh hưởng bởi giá trị bất thường
  - Dùng hai số đặc trưng này để so sánh độ phân tán của hai mẫu số liệu trong bài toán thực tế
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mẫu ghép nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$ với $m_1>0$, $m_k>0$: **khoảng biến thiên** $R=a_{k+1}-a_1$ (đầu mút phải nhóm cuối trừ đầu mút trái nhóm đầu).
> 2. **Tứ phân vị thứ $r$** ($r=1,2,3$): tìm nhóm $[a_p;a_{p+1})$ đầu tiên có tần số tích lũy $\ge \dfrac{rn}{4}$, rồi $Q_r=a_p+\dfrac{\frac{rn}{4}-(m_1+\dots+m_{p-1})}{m_p}\cdot(a_{p+1}-a_p)$.
> 3. **Khoảng tứ phân vị** $\Delta_Q=Q_3-Q_1$: độ dài khoảng chứa khoảng **50% số liệu ở giữa**.
> 4. $R$ và $\Delta_Q$ đều đo **mức độ phân tán**: càng lớn thì số liệu càng phân tán (kém đồng đều). Với mẫu ghép nhóm, chúng chỉ là **giá trị xấp xỉ** của mẫu gốc.
> 5. $R$ rất nhạy với giá trị bất thường ở hai đầu; $\Delta_Q$ chỉ phụ thuộc vào nửa giữa nên **ít bị ảnh hưởng** — dùng $\Delta_Q$ để so sánh khi dữ liệu có giá trị bất thường.

Ở lớp 11, em đã học các số đặc trưng đo **xu thế trung tâm** của mẫu số liệu ghép nhóm: số trung bình, trung vị, mốt — chúng trả lời câu hỏi *"số liệu tập trung quanh giá trị nào?"*. Nhưng chừng đó chưa đủ. Hai lớp có cùng điểm trung bình 7,0 có thể rất khác nhau: lớp này ai cũng quanh 7 điểm, lớp kia có bạn 3 điểm, có bạn 10 điểm. Chương III trả lời câu hỏi thứ hai: ***số liệu trải rộng, phân tán đến mức nào?*** Bài này học hai "thước đo độ phân tán" đơn giản nhất: **khoảng biến thiên** và **khoảng tứ phân vị**. Bài 10 sẽ học phương sai và độ lệch chuẩn.

> [!nen-tang] Nhắc lại lớp 11: mẫu số liệu ghép nhóm
> - Khi có rất nhiều số liệu (hoặc số liệu đo liên tục như thời gian, chiều cao), người ta **chia thành các nhóm** dạng nửa khoảng $[a_1;a_2), [a_2;a_3),\dots,[a_k;a_{k+1})$ và chỉ ghi **tần số** $m_i$ = số giá trị rơi vào nhóm $[a_i;a_{i+1})$. Đó là **mẫu số liệu ghép nhóm**; dãy số ban đầu gọi là **mẫu số liệu gốc**.
> - **Cỡ mẫu** $n=m_1+m_2+\dots+m_k$. **Độ dài nhóm** $[a_i;a_{i+1})$ là $a_{i+1}-a_i$.
> - **Giá trị đại diện** của nhóm là trung điểm $x_i=\dfrac{a_i+a_{i+1}}{2}$ (dùng để tính số trung bình $\bar x=\dfrac{m_1x_1+\dots+m_kx_k}{n}$).
> - **Tần số tích lũy** của nhóm thứ $i$ là $m_1+m_2+\dots+m_i$ — số giá trị **nhỏ hơn** $a_{i+1}$.
> - Khi đã ghép nhóm, ta **mất** giá trị chính xác của từng số liệu, chỉ biết nó nằm trong nhóm nào. Vì vậy mọi số đặc trưng tính từ mẫu ghép nhóm đều là **giá trị xấp xỉ** cho mẫu gốc.

## 1. Khoảng biến thiên

### 1.1. Từ mẫu gốc đến mẫu ghép nhóm

Với mẫu số liệu gốc (lớp 10), khoảng biến thiên là **giá trị lớn nhất trừ giá trị nhỏ nhất**. Nhưng với mẫu ghép nhóm, ta không biết giá trị lớn nhất, nhỏ nhất là bao nhiêu! Ta chỉ biết:

- mọi số liệu đều $\ge a_1$ (đầu mút trái của nhóm đầu tiên có số liệu);
- mọi số liệu đều $< a_{k+1}$ (đầu mút phải của nhóm cuối cùng có số liệu).

Nghĩa là toàn bộ số liệu nằm gọn trong nửa khoảng $[a_1;a_{k+1})$. Độ dài của nửa khoảng này là cách xấp xỉ tự nhiên nhất cho "độ trải rộng" của số liệu.

> [!ghi-nho] Định nghĩa (SGK tr. 76)
> Cho mẫu số liệu ghép nhóm gồm các nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$ với tần số $m_1,\dots,m_k$, trong đó $m_1>0$ và $m_k>0$. **Khoảng biến thiên** của mẫu là
> $$R=a_{k+1}-a_1.$$

**Vì sao $R$ của mẫu ghép nhóm luôn lớn hơn $R$ của mẫu gốc?** Gọi $x_{\min}$, $x_{\max}$ là giá trị nhỏ nhất, lớn nhất thật sự. Vì $a_1\le x_{\min}$ và $x_{\max}<a_{k+1}$ nên
$$x_{\max}-x_{\min}<a_{k+1}-a_1.$$
Khoảng biến thiên của mẫu ghép nhóm là một **xấp xỉ "dư"** — nó tính cả phần trống ở hai đầu nhóm mà có thể không có số liệu nào.

![Hình 1. Mọi số liệu gốc nằm giữa đầu mút trái nhóm đầu và đầu mút phải nhóm cuối, nên khoảng biến thiên của mẫu ghép nhóm luôn lớn hơn của mẫu gốc](h1-khoang-bien-thien.svg)

> [!ghi-nho] Ý nghĩa
> - Khoảng biến thiên của mẫu ghép nhóm **xấp xỉ** khoảng biến thiên của mẫu gốc.
> - $R$ dùng để đo **mức độ phân tán**: $R$ càng lớn thì số liệu càng phân tán (trải rộng, kém đồng đều).

> [!bay] Nhóm đầu hoặc nhóm cuối có tần số 0
> Điều kiện $m_1>0$, $m_k>0$ rất quan trọng. Nếu bảng có nhóm ở **đầu** hoặc **cuối** với tần số $0$ thì phải **bỏ các nhóm đó** trước khi lấy đầu mút. Ví dụ bảng có các nhóm $[0;10),\dots,[40;50)$ mà tần số nhóm đầu và nhóm cuối đều bằng $0$ thì $R=40-10=30$, **không phải** $50-0=50$. Nhóm tần số $0$ nằm **ở giữa** thì không ảnh hưởng.

> [!vi-du] Ví dụ 1
> Thời gian đi từ nhà đến trường của học sinh hai lớp 12A và 12B được thống kê như sau:
>
> | Thời gian (phút) | [0; 10) | [10; 20) | [20; 30) | [30; 40) | [40; 50) |
> |---|---|---|---|---|---|
> | Số học sinh 12A | 5 | 12 | 10 | 6 | 2 |
> | Số học sinh 12B | 0 | 9 | 15 | 8 | 0 |
>
> Tính khoảng biến thiên của mỗi mẫu. Theo khoảng biến thiên, thời gian đến trường của lớp nào phân tán hơn?

> [!goi-y] Gợi ý 1
> Với mỗi lớp, tìm nhóm **đầu tiên** và nhóm **cuối cùng** có tần số khác $0$.

> [!goi-y] Gợi ý 2
> Lớp 12B: nhóm $[0;10)$ và $[40;50)$ không có bạn nào.

> [!loi-giai] Lời giải
> - Lớp 12A: nhóm đầu $[0;10)$ có $5>0$, nhóm cuối $[40;50)$ có $2>0$, nên $R_A=50-0=50$ (phút).
> - Lớp 12B: nhóm có số liệu đầu tiên là $[10;20)$, cuối cùng là $[30;40)$, nên $R_B=40-10=30$ (phút).
>
> Vì $R_A>R_B$ nên thời gian đến trường của học sinh lớp 12A **phân tán hơn** (có bạn ở rất gần, có bạn ở rất xa), còn lớp 12B đồng đều hơn.

> [!vi-du] Ví dụ 2
> Chiều cao (cm) của 40 cây giống trong một vườn ươm được ghép nhóm như sau:
>
> | Chiều cao (cm) | [10; 15) | [15; 20) | [20; 25) | [25; 30) | [30; 35) |
> |---|---|---|---|---|---|
> | Số cây | 3 | 8 | 15 | 10 | 4 |
>
> a) Tính khoảng biến thiên $R$ của mẫu ghép nhóm.
>
> b) Biết cây thấp nhất cao $11{,}2$ cm và cây cao nhất cao $33{,}5$ cm. Tính khoảng biến thiên của mẫu số liệu gốc. Giá trị nào là chính xác, giá trị nào là xấp xỉ?

> [!goi-y] Gợi ý 1
> a) Chỉ cần hai số: đầu mút trái nhóm đầu và đầu mút phải nhóm cuối.

> [!goi-y] Gợi ý 2
> b) Mẫu gốc: lấy lớn nhất trừ nhỏ nhất như lớp 10.

> [!loi-giai] Lời giải
> a) $R=35-10=25$ (cm).
>
> b) $R_{\text{gốc}}=33{,}5-11{,}2=22{,}3$ (cm) — đây là giá trị **chính xác**. Còn $R=25$ cm là giá trị **xấp xỉ** (và đúng như lí thuyết, $25>22{,}3$).

### 1.2. Nhược điểm của khoảng biến thiên

$R$ chỉ dùng **hai** con số ở hai đầu, bỏ qua toàn bộ phần còn lại. Hệ quả:

- Chỉ cần **một** giá trị bất thường (rất lớn hoặc rất nhỏ) là $R$ tăng vọt, dù hầu hết số liệu vẫn tập trung như cũ.
- Hai mẫu có cùng $R$ vẫn có thể phân tán rất khác nhau ở phần giữa.

Ví dụ: một lớp 40 bạn, 39 bạn tự học từ 30 đến 120 phút mỗi ngày, riêng một bạn ghi "290 phút". Khoảng biến thiên bị kéo dài gấp đôi chỉ vì một bạn. Ta cần một thước đo "bền" hơn — đó là khoảng tứ phân vị.

## 2. Khoảng tứ phân vị

### 2.1. Tứ phân vị của mẫu ghép nhóm — nhắc lại và hiểu công thức

**Tứ phân vị** là ba giá trị $Q_1$, $Q_2$, $Q_3$ chia mẫu số liệu (đã sắp xếp tăng dần) thành **bốn phần có số lượng xấp xỉ bằng nhau**, mỗi phần khoảng 25% số liệu. $Q_2$ chính là trung vị.

Với mẫu ghép nhóm, ta không biết từng giá trị, nên ta làm hai việc:

**Việc 1 — Tìm nhóm chứa $Q_r$.** $Q_r$ ứng với vị trí thứ $\dfrac{rn}{4}$ trong dãy đã sắp xếp. Lập dòng **tần số tích lũy**; nhóm chứa $Q_r$ là nhóm **đầu tiên** có tần số tích lũy $\ge\dfrac{rn}{4}$. Gọi nhóm đó là $[a_p;a_{p+1})$.

**Việc 2 — Nội suy trong nhóm.** Ta **giả sử các giá trị trong nhóm $[a_p;a_{p+1})$ rải đều** trên nhóm. Trước nhóm này đã có $C=m_1+\dots+m_{p-1}$ giá trị. Muốn đến vị trí $\frac{rn}{4}$ ta còn phải "đi tiếp" $\frac{rn}{4}-C$ giá trị trong số $m_p$ giá trị của nhóm, tức là đi được một **tỉ lệ** $\dfrac{\frac{rn}{4}-C}{m_p}$ của độ dài nhóm. Vậy:

> [!ghi-nho] Công thức tứ phân vị của mẫu ghép nhóm (SGK tr. 77)
> $$Q_r=a_p+\dfrac{\dfrac{rn}{4}-C}{m_p}\cdot(a_{p+1}-a_p)$$
> với $r=1,2,3$, trong đó:
> - $[a_p;a_{p+1})$ là nhóm chứa tứ phân vị thứ $r$, $m_p$ là tần số của nhóm đó;
> - $C=m_1+\dots+m_{p-1}$ là tổng tần số các nhóm **đứng trước** nó (bằng $0$ nếu $p=1$).
>
> SGK viết gộp: $Q_r=a_p+\dfrac{\frac{rn}{4}-(m_1+\dots+m_{p-1})}{m_p}\cdot(a_{p+1}-a_p)$.

Đọc công thức thành lời: ***Q = đầu nhóm + (vị trí cần tìm − số giá trị đã đi qua) : tần số nhóm × độ dài nhóm.***

Về mặt hình học, nối các điểm $(a_{i+1};\ \text{tần số tích lũy})$ ta được **đường tần số tích lũy** (Hình 2). Công thức trên chính là đọc hoành độ của điểm trên đường gấp khúc này có tung độ $\frac{rn}{4}$.

![Hình 2. Đường tần số tích lũy: Q₁ và Q₃ là hoành độ ứng với tung độ n/4 và 3n/4 (số liệu Ví dụ 3)](h2-tan-so-tich-luy.svg)

> [!meo] Tự kiểm tra kết quả
> - $Q_r$ **luôn nằm trong** nhóm đã chọn: $a_p\le Q_r\le a_{p+1}$. Nếu tính ra số nằm ngoài nhóm → em đã chọn sai nhóm hoặc trừ nhầm $C$.
> - Luôn có $Q_1\le Q_2\le Q_3$.
> - SGK đôi khi tìm nhóm bằng cách chỉ ra vị trí của tứ phân vị trong mẫu gốc (ví dụ với $n=38$ thì $Q_1$ của mẫu gốc là $x_{10}$). Cách dùng tần số tích lũy ở trên cho **cùng một nhóm**, nhưng nhanh và ít nhầm hơn.

### 2.2. Định nghĩa khoảng tứ phân vị

> [!ghi-nho] Định nghĩa (SGK tr. 77)
> **Khoảng tứ phân vị** của mẫu số liệu ghép nhóm, kí hiệu $\Delta_Q$, là hiệu giữa tứ phân vị thứ ba và tứ phân vị thứ nhất:
> $$\Delta_Q=Q_3-Q_1.$$

Vì từ $Q_1$ đến $Q_3$ có khoảng 50% số liệu (25% + 25%), nên **$\Delta_Q$ là độ dài của khoảng chứa một nửa số liệu nằm ở giữa**. Nửa giữa càng "bè" ra thì $\Delta_Q$ càng lớn.

> [!ghi-nho] Ý nghĩa
> - Khoảng tứ phân vị của mẫu ghép nhóm **xấp xỉ** khoảng tứ phân vị của mẫu gốc.
> - $\Delta_Q$ cũng đo **mức độ phân tán**: $\Delta_Q$ càng lớn thì mẫu số liệu càng phân tán.

> [!vi-du] Ví dụ 3
> Thời gian tự học mỗi ngày của 40 học sinh lớp 12C được ghi lại:
>
> | Thời gian (phút) | [0; 30) | [30; 60) | [60; 90) | [90; 120) | [120; 150) |
> |---|---|---|---|---|---|
> | Số học sinh | 4 | 10 | 14 | 8 | 4 |
>
> Tính $Q_1$, $Q_3$ và khoảng tứ phân vị $\Delta_Q$ của mẫu số liệu.

> [!goi-y] Gợi ý 1
> $n=40$. Lập dòng tần số tích lũy: $4;\ 14;\ 28;\ 36;\ 40$. Tìm vị trí $\frac{n}{4}=10$ và $\frac{3n}{4}=30$.

> [!goi-y] Gợi ý 2
> Nhóm đầu tiên có tần số tích lũy $\ge10$ là $[30;60)$; nhóm đầu tiên có tần số tích lũy $\ge30$ là $[90;120)$. Mỗi nhóm dài $30$.

> [!loi-giai] Lời giải
> Cỡ mẫu $n=4+10+14+8+4=40$.
>
> | Nhóm | [0; 30) | [30; 60) | [60; 90) | [90; 120) | [120; 150) |
> |---|---|---|---|---|---|
> | Tần số | 4 | 10 | 14 | 8 | 4 |
> | Tần số tích lũy | 4 | 14 | 28 | 36 | 40 |
>
> **Tính $Q_1$:** $\frac{n}{4}=10$. Nhóm chứa $Q_1$ là $[30;60)$ (tích lũy $14\ge10$), trước nó có $4$ giá trị:
> $$Q_1=30+\dfrac{10-4}{10}\cdot30=30+18=48.$$
> **Tính $Q_3$:** $\frac{3n}{4}=30$. Nhóm chứa $Q_3$ là $[90;120)$ (tích lũy $36\ge30$), trước nó có $4+10+14=28$ giá trị:
> $$Q_3=90+\dfrac{30-28}{8}\cdot30=90+7{,}5=97{,}5.$$
> **Kết luận:** $\Delta_Q=97{,}5-48=49{,}5$ (phút). Khoảng một nửa số học sinh "ở giữa" có thời gian tự học trải trong một khoảng dài chừng 49,5 phút (từ khoảng 48 đến 97,5 phút).

> [!bay] Ba lỗi kinh điển khi tính $Q_r$
> 1. **Lấy nhầm tần số tích lũy của chính nhóm** thay cho tổng các nhóm **đứng trước**: với $Q_3$ ở trên phải trừ $28$, không phải $36$.
> 2. **Nhân nhầm độ dài nhóm**: phải nhân với $a_{p+1}-a_p$ (ở đây $30$), không phải nhân với $a_p$ hay $a_{p+1}$.
> 3. **Quên chữ $r$**: với $Q_3$ vị trí là $\frac{3n}{4}$, không phải $\frac{n}{4}$. (Và với $Q_2$ là $\frac{2n}{4}=\frac n2$ — đúng công thức trung vị của lớp 11.)

> [!vi-du] Ví dụ 4
> Thời gian chờ thanh toán (phút) của khách hàng tại một siêu thị trong một buổi:
>
> | Thời gian (phút) | [0; 4) | [4; 8) | [8; 12) | [12; 16) | [16; 20) |
> |---|---|---|---|---|---|
> | Số khách | 6 | 14 | 11 | 5 | 2 |
>
> Tính khoảng tứ phân vị của mẫu số liệu (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> $n=38$ không chia hết cho $4$: $\frac n4=9{,}5$ và $\frac{3n}{4}=28{,}5$. Vị trí lẻ không sao — công thức vẫn dùng bình thường.

> [!goi-y] Gợi ý 2
> Tần số tích lũy: $6;\ 20;\ 31;\ 36;\ 38$.

> [!loi-giai] Lời giải
> $n=38$. Tần số tích lũy: $6;\ 20;\ 31;\ 36;\ 38$.
>
> - $\frac n4=9{,}5$: nhóm chứa $Q_1$ là $[4;8)$: $Q_1=4+\dfrac{9{,}5-6}{14}\cdot4=4+1=5$.
> - $\frac{3n}{4}=28{,}5$: nhóm chứa $Q_3$ là $[8;12)$: $Q_3=8+\dfrac{28{,}5-20}{11}\cdot4=8+\dfrac{34}{11}\approx11{,}09$.
>
> Vậy $\Delta_Q=Q_3-Q_1\approx11{,}09-5=6{,}09$ (phút).

### 2.3. Vì sao khoảng tứ phân vị "bền" trước giá trị bất thường?

$\Delta_Q$ chỉ phụ thuộc vào **nửa giữa** của mẫu số liệu. Thêm một giá trị cực lớn ở đầu phải chỉ làm các vị trí $\frac n4$, $\frac{3n}{4}$ dịch đi một chút, nên $Q_1$, $Q_3$ gần như không đổi. Trong khi đó $R$ "ăn theo" giá trị cực đoan ngay lập tức.

> [!vi-du] Ví dụ 5
> Quay lại Ví dụ 3, giả sử có thêm **một** học sinh tự học $290$ phút mỗi ngày. Bảng mới có thêm các nhóm $[150;180),\dots,[270;300)$, trong đó chỉ nhóm $[270;300)$ có tần số $1$, các nhóm còn lại tần số $0$. So sánh khoảng biến thiên và khoảng tứ phân vị trước và sau khi thêm học sinh này.

> [!goi-y] Gợi ý 1
> Bây giờ $n=41$; nhóm cuối có số liệu là $[270;300)$.

> [!goi-y] Gợi ý 2
> $\frac n4=10{,}25$ và $\frac{3n}{4}=30{,}75$; các nhóm chứa $Q_1$, $Q_3$ không đổi.

> [!loi-giai] Lời giải
> - Trước: $R=150-0=150$, $\Delta_Q=49{,}5$.
> - Sau: $R=300-0=300$ — **tăng gấp đôi**.
> - $Q_1=30+\dfrac{10{,}25-4}{10}\cdot30=48{,}75$; $Q_3=90+\dfrac{30{,}75-28}{8}\cdot30=100{,}3125$; $\Delta_Q\approx51{,}56$ — chỉ tăng khoảng $4\%$.
>
> Chỉ một số liệu bất thường đã làm $R$ thay đổi hoàn toàn, còn $\Delta_Q$ gần như giữ nguyên. Vì vậy khi dữ liệu có giá trị bất thường, **$\Delta_Q$ phản ánh độ phân tán đáng tin hơn $R$**.

![Hình 3. Thêm một giá trị bất thường: khoảng biến thiên tăng gấp đôi, khoảng tứ phân vị (phần tô đậm) gần như không đổi](h3-gia-tri-bat-thuong.svg)

> [!nen-tang] Giá trị ngoại lệ (lớp 10)
> Một giá trị $x$ được coi là **giá trị ngoại lệ (bất thường)** nếu
> $$x>Q_3+1{,}5\,\Delta_Q$$
> hoặc
> $$x<Q_1-1{,}5\,\Delta_Q.$$
> SGK lớp 12 nhận xét: khoảng tứ phân vị không bị ảnh hưởng bởi giá trị bất thường **và có thể dùng để phát hiện, loại bỏ giá trị bất thường** — chính là nhờ quy tắc này. Ở Ví dụ 3: $Q_3+1{,}5\Delta_Q=97{,}5+74{,}25=171{,}75$, nên một bạn tự học $290$ phút là giá trị ngoại lệ, còn một bạn tự học $160$ phút thì không.

> [!ung-dung] Kiểm soát chất lượng
> Ở nhà máy đóng chai, thời gian vận hành, khối lượng sản phẩm… được theo dõi liên tục. Người ta thường lấy khoảng $[Q_1-1{,}5\Delta_Q;\ Q_3+1{,}5\Delta_Q]$ làm "vùng bình thường": sản phẩm rơi ra ngoài sẽ bị đánh dấu để kiểm tra. Trong y học cũng vậy — một kết quả xét nghiệm nằm quá xa nửa giữa của nhóm người khỏe mạnh là tín hiệu cần chú ý.

## 3. Dùng khoảng biến thiên và khoảng tứ phân vị để so sánh độ phân tán

Quy tắc chung: **mẫu nào có số đặc trưng đo độ phân tán lớn hơn thì phân tán hơn**. Nhưng $R$ và $\Delta_Q$ đo hai "phần" khác nhau của dữ liệu, nên **có thể cho kết luận trái ngược nhau**:

- $R$ nhìn **toàn bộ** (hai đầu mút) — dễ bị chi phối bởi vài giá trị cực đoan.
- $\Delta_Q$ nhìn **nửa giữa** — phản ánh mức độ đồng đều của phần lớn số liệu.

> [!vi-du] Ví dụ 6
> Thời gian phục vụ một khách (phút) tại hai quầy giao dịch A và B trong một ngày:
>
> | Thời gian (phút) | [0; 5) | [5; 10) | [10; 15) | [15; 20) | [20; 25) | [25; 30) |
> |---|---|---|---|---|---|---|
> | Quầy A | 1 | 4 | 10 | 10 | 4 | 1 |
> | Quầy B | 0 | 8 | 7 | 7 | 8 | 0 |
>
> a) Tính khoảng biến thiên của mỗi mẫu.
>
> b) Tính khoảng tứ phân vị của mỗi mẫu (làm tròn đến hàng phần trăm).
>
> c) Nên dùng số đặc trưng nào để so sánh mức độ đồng đều thời gian phục vụ của hai quầy? Quầy nào phục vụ đồng đều hơn?

> [!goi-y] Gợi ý 1
> Mỗi quầy có $n=30$, $\frac n4=7{,}5$, $\frac{3n}{4}=22{,}5$. Tần số tích lũy quầy A: $1;5;15;25;29;30$; quầy B: $0;8;15;22;30;30$.

> [!goi-y] Gợi ý 2
> Quầy A có hai khách "bất thường" ở hai đầu ($[0;5)$ và $[25;30)$), còn phần lớn khách tập trung ở $[10;20)$.

> [!loi-giai] Lời giải
> a) $R_A=30-0=30$; quầy B bỏ hai nhóm tần số $0$ ở hai đầu: $R_B=25-5=20$.
>
> b) Quầy A: $Q_1=10+\dfrac{7{,}5-5}{10}\cdot5=11{,}25$; $Q_3=15+\dfrac{22{,}5-15}{10}\cdot5=18{,}75$; $\Delta_{Q,A}=7{,}5$.
>
> Quầy B: $Q_1=5+\dfrac{7{,}5-0}{8}\cdot5=9{,}6875$; $Q_3=20+\dfrac{22{,}5-22}{8}\cdot5=20{,}3125$; $\Delta_{Q,B}=10{,}625\approx10{,}63$.
>
> c) Theo $R$ thì A phân tán hơn ($30>20$), nhưng theo $\Delta_Q$ thì B phân tán hơn ($10{,}63>7{,}5$). Độ rộng của A chủ yếu do **hai khách bất thường** ở hai đầu; phần lớn khách của A được phục vụ trong khoảng $10$–$20$ phút. Vì vậy nên dùng **khoảng tứ phân vị**: quầy **A phục vụ đồng đều hơn**.

> [!em-co-biet]
> Tình huống mở đầu của SGK (nhiệt độ cao nhất trong ngày tháng Sáu năm 2021 và 2022 tại Hà Nội, SGK tr. 75) cũng có hiện tượng này: một năm có khoảng biến thiên lớn hơn, nhưng năm kia lại có khoảng tứ phân vị lớn hơn. Em hãy tự tính lại bằng công thức ở mục 2 để thấy — đó là lí do người ta không bao giờ chỉ dựa vào một con số khi kết luận về dữ liệu.

## Dạng bài thi hay gặp

### Dạng 1. Tính khoảng biến thiên của mẫu ghép nhóm

- **Nhận biết:** "khoảng biến thiên của mẫu số liệu ghép nhóm bằng…" — thường là câu 4 lựa chọn mức biết.
- **Phương pháp:** (1) Tìm nhóm **đầu tiên** và **cuối cùng** có tần số khác $0$. (2) $R=$ đầu mút phải nhóm cuối $-$ đầu mút trái nhóm đầu.
- **Bẫy:** không bỏ nhóm tần số $0$ ở hai đầu; lấy nhầm **giá trị đại diện** (trung điểm) thay cho đầu mút; nhầm $R$ với **độ dài một nhóm**.

> [!vi-du] Ví dụ 7
> Số giờ sử dụng điện thoại mỗi ngày của một nhóm người được cho trong bảng:
>
> | Số giờ | [0; 2) | [2; 4) | [4; 6) | [6; 8) | [8; 10) | [10; 12) |
> |---|---|---|---|---|---|---|
> | Số người | 0 | 7 | 15 | 11 | 4 | 0 |
>
> Khoảng biến thiên của mẫu số liệu ghép nhóm bằng bao nhiêu?

> [!goi-y] Gợi ý 1
> Nhóm $[0;2)$ và $[10;12)$ không có ai.

> [!loi-giai] Lời giải
> Nhóm đầu có số liệu là $[2;4)$, nhóm cuối có số liệu là $[8;10)$. Vậy $R=10-2=8$ (giờ). Đáp án nhiễu hay gặp: $12$ (không bỏ nhóm tần số $0$), $6$ (lấy trung điểm $9-3$), $2$ (độ dài một nhóm).

### Dạng 2. Tính tứ phân vị, khoảng tứ phân vị (trả lời ngắn có làm tròn)

- **Nhận biết:** bảng ghép nhóm + "tính $Q_1$ / $Q_3$ / khoảng tứ phân vị (làm tròn…)".
- **Phương pháp:** (1) Tính $n$, lập dòng tần số tích lũy. (2) Tính $\frac n4$, $\frac{3n}{4}$ → chọn nhóm. (3) Thế vào công thức, **giữ phân số đến cuối**, chỉ làm tròn kết quả $\Delta_Q$ cuối cùng.
- **Bẫy:** làm tròn $Q_1$, $Q_3$ trước rồi mới trừ có thể làm lệch chữ số cuối; ba lỗi kinh điển ở mục 2.1.

> [!vi-du] Ví dụ 8
> Khối lượng (gam) của 50 quả trứng gà trong một lô hàng:
>
> | Khối lượng (g) | [40; 45) | [45; 50) | [50; 55) | [55; 60) | [60; 65) |
> |---|---|---|---|---|---|
> | Số quả | 5 | 12 | 17 | 11 | 5 |
>
> Tính khoảng tứ phân vị của mẫu số liệu (làm tròn đến hàng phần mười).

> [!goi-y] Gợi ý 1
> $n=50$, $\frac n4=12{,}5$, $\frac{3n}{4}=37{,}5$. Tần số tích lũy: $5;\ 17;\ 34;\ 45;\ 50$.

> [!goi-y] Gợi ý 2
> $Q_1$ thuộc $[45;50)$ (trước nó có $5$ quả); $Q_3$ thuộc $[55;60)$ (trước nó có $34$ quả).

> [!loi-giai] Lời giải
> $Q_1=45+\dfrac{12{,}5-5}{12}\cdot5=45+\dfrac{37{,}5}{12}=48{,}125$.
>
> $Q_3=55+\dfrac{37{,}5-34}{11}\cdot5=55+\dfrac{17{,}5}{11}\approx56{,}591$.
>
> $\Delta_Q=Q_3-Q_1\approx56{,}591-48{,}125\approx8{,}5$ (g).

### Dạng 3. So sánh độ phân tán của hai mẫu số liệu

- **Nhận biết:** hai dòng tần số trên cùng một bảng (hai lớp, hai cửa hàng, hai năm…), hỏi "mẫu nào phân tán hơn / đồng đều hơn / ổn định hơn".
- **Phương pháp:** tính cùng một số đặc trưng cho cả hai mẫu rồi so sánh. Nếu đề không nói rõ, ưu tiên $\Delta_Q$ (đặc biệt khi có nhóm lẻ loi ở hai đầu). Khi hai mẫu có **cùng $R$**, chỉ $\Delta_Q$ mới phân biệt được.
- **Bẫy:** nhầm "phân tán hơn" với "trung bình lớn hơn" — một mẫu có giá trị lớn hơn **không** có nghĩa là phân tán hơn. "Đồng đều hơn", "ổn định hơn" nghĩa là **ít** phân tán hơn ($\Delta_Q$ **nhỏ** hơn).

> [!vi-du] Ví dụ 9
> Điểm kiểm tra giữa kì môn Toán của hai lớp:
>
> | Điểm | [4; 5) | [5; 6) | [6; 7) | [7; 8) | [8; 9) | [9; 10) |
> |---|---|---|---|---|---|---|
> | Lớp 12A | 2 | 6 | 12 | 14 | 5 | 1 |
> | Lớp 12B | 4 | 9 | 8 | 8 | 9 | 2 |
>
> Dùng khoảng biến thiên và khoảng tứ phân vị, cho biết điểm của lớp nào đồng đều hơn.

> [!goi-y] Gợi ý 1
> Cả hai lớp đều có $n=40$ và có số liệu ở cả nhóm đầu lẫn nhóm cuối — $R$ có giúp phân biệt không?

> [!goi-y] Gợi ý 2
> Tần số tích lũy 12A: $2;8;20;34;39;40$. 12B: $4;13;21;29;38;40$. Vị trí $10$ và $30$.

> [!loi-giai] Lời giải
> $R_A=R_B=10-4=6$: khoảng biến thiên **không phân biệt** được hai lớp.
>
> Lớp 12A: $Q_1=6+\dfrac{10-8}{12}\cdot1\approx6{,}17$; $Q_3=7+\dfrac{30-20}{14}\cdot1\approx7{,}71$; $\Delta_Q\approx1{,}55$.
>
> Lớp 12B: $Q_1=5+\dfrac{10-4}{9}\cdot1\approx5{,}67$; $Q_3=8+\dfrac{30-29}{9}\cdot1\approx8{,}11$; $\Delta_Q\approx2{,}44$.
>
> Vì $1{,}55<2{,}44$ nên điểm của lớp **12A đồng đều hơn**.

### Dạng 4. Đọc bảng — Đúng/Sai tổng hợp (có giá trị ngoại lệ)

- **Nhận biết:** một bảng thực tế, 4 mệnh đề về $R$, nhóm chứa $Q_1$/$Q_3$, giá trị $Q_r$, $\Delta_Q$, giá trị ngoại lệ.
- **Phương pháp:** lập ngay dòng tần số tích lũy rồi lần lượt kiểm tra từng ý; ý cuối thường hỏi ngoại lệ → tính $Q_1-1{,}5\Delta_Q$ và $Q_3+1{,}5\Delta_Q$.
- **Bẫy:** ý "nhóm chứa $Q_1$" hay đặt nhóm **liền sau** nhóm đúng; ý ngoại lệ hay chọn giá trị **sát** ngưỡng — phải tính đủ chính xác mới kết luận được.

> [!vi-du] Ví dụ 10 (Đúng/Sai)
> Chiều cao (cm) của 40 nam sinh khối 12 được ghép nhóm:
>
> | Chiều cao (cm) | [150; 155) | [155; 160) | [160; 165) | [165; 170) | [170; 175) | [175; 180) |
> |---|---|---|---|---|---|---|
> | Số học sinh | 3 | 9 | 14 | 10 | 3 | 1 |
>
> a) Khoảng biến thiên của mẫu số liệu là $30$ cm.
>
> b) Nhóm chứa tứ phân vị thứ nhất là $[160;165)$.
>
> c) Tứ phân vị thứ ba là $Q_3=167$ cm.
>
> d) Theo quy tắc $Q_3+1{,}5\Delta_Q$, một bạn cao $179$ cm là giá trị ngoại lệ.

> [!goi-y] Gợi ý 1
> Tần số tích lũy: $3;\ 12;\ 26;\ 36;\ 39;\ 40$. $\frac n4=10$, $\frac{3n}{4}=30$.

> [!goi-y] Gợi ý 2
> d) Tính $Q_1$ thật chính xác (để dạng phân số) rồi mới tính ngưỡng $Q_3+1{,}5\Delta_Q$.

> [!loi-giai] Lời giải
> a) **Đúng** — $R=180-150=30$.
>
> b) **Sai** — tích lũy đến $[155;160)$ đã là $12\ge10$, nên $Q_1$ thuộc $[155;160)$.
>
> c) **Đúng** — $Q_3=165+\dfrac{30-26}{10}\cdot5=167$.
>
> d) **Sai** — $Q_1=155+\dfrac{10-3}{9}\cdot5=\dfrac{1430}{9}\approx158{,}89$, $\Delta_Q\approx8{,}11$, ngưỡng $Q_3+1{,}5\Delta_Q\approx167+12{,}17=179{,}17>179$. Vậy $179$ cm **chưa** phải giá trị ngoại lệ.

## Tóm tắt

Mẫu ghép nhóm $[a_1;a_2),\dots,[a_k;a_{k+1})$, tần số $m_1,\dots,m_k$, cỡ mẫu $n$.

| Nội dung | Công thức / Ghi nhớ |
|---|---|
| Khoảng biến thiên | $R=a_{k+1}-a_1$ (với $m_1>0$, $m_k>0$; bỏ nhóm tần số $0$ ở hai đầu) |
| Nhóm chứa $Q_r$ | nhóm đầu tiên có tần số tích lũy $\ge\dfrac{rn}{4}$ |
| Tứ phân vị | $Q_r=a_p+\dfrac{\frac{rn}{4}-(m_1+\dots+m_{p-1})}{m_p}\cdot(a_{p+1}-a_p)$ |
| Khoảng tứ phân vị | $\Delta_Q=Q_3-Q_1$ — độ dài khoảng chứa khoảng 50% số liệu ở giữa |
| Giá trị ngoại lệ (lớp 10) | $x>Q_3+1{,}5\Delta_Q$ hoặc $x<Q_1-1{,}5\Delta_Q$ |
| Ý nghĩa | $R$, $\Delta_Q$ càng lớn → càng phân tán; đều là xấp xỉ của mẫu gốc |
| So sánh $R$ và $\Delta_Q$ | $R$ dễ tính nhưng nhạy với giá trị bất thường; $\Delta_Q$ bền hơn, phản ánh nửa giữa |

**Sơ đồ khi gặp đề:** đọc bảng → tính $n$ → bỏ nhóm tần số $0$ ở hai đầu để tính $R$ → lập dòng tần số tích lũy → tìm vị trí $\frac n4$, $\frac{3n}{4}$ → chọn nhóm → thế công thức → $\Delta_Q$ → so sánh (lớn hơn = phân tán hơn, nhỏ hơn = đồng đều hơn).
