---
title: Tích phân
thoi-gian: 50 phút
muc-tieu:
  - Hiểu vì sao diện tích hình thang cong tính được bằng hiệu $F(b)-F(a)$ của một nguyên hàm, từ đó nhận biết định nghĩa tích phân và kí hiệu $\int_a^b f(x)\,dx$
  - Tính được tích phân trong những trường hợp đơn giản bằng bảng nguyên hàm, kể cả hàm chứa dấu giá trị tuyệt đối
  - Nắm và vận dụng các tính chất của tích phân (hằng số, tổng, hiệu, cộng đoạn, đổi cận)
  - Hiểu ý nghĩa hình học (diện tích) và ý nghĩa vật lí (quãng đường, độ dịch chuyển) của tích phân
  - Giải bài toán thực tế bằng tích phân: quãng đường từ vận tốc, lượng nước, lợi nhuận, giá trị trung bình
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. $F$ là một nguyên hàm của $f$ trên $[a;b]$ thì $\displaystyle\int_a^b f(x)\,dx=F(x)\Big|_a^b=F(b)-F(a)$. Kết quả là **một số**, không có $+C$.
> 2. $f\ge0$ trên $[a;b]$: tích phân = **diện tích** hình thang cong dưới đồ thị.
> 3. Hằng số đưa ra ngoài, tổng/hiệu tách được, $\int_a^b=\int_a^c+\int_c^b$, đổi cận thì đổi dấu, $\int_a^a=0$.
> 4. Có dấu giá trị tuyệt đối: tìm chỗ biểu thức đổi dấu, **chia đoạn**, bỏ dấu đó trên từng đoạn.
> 5. $\int_a^b v(t)\,dt$ là **độ dịch chuyển**, $\int_a^b\lvert v(t)\rvert\,dt$ là **quãng đường**. Tổng quát: $\int_a^b Q'(x)\,dx=Q(b)-Q(a)$ là lượng thay đổi của $Q$.

Ở Bài 11, em đã biết từ vận tốc tìm lại quãng đường bằng nguyên hàm: tìm họ $S(t)+C$, rồi dùng $S(0)=0$ để tìm $C$. Bài này cho em một công cụ gọn hơn rất nhiều. Muốn biết vật đi được bao xa **từ giây thứ $a$ đến giây thứ $b$**, chỉ cần lấy $S(b)-S(a)$ — hằng số $C$ tự triệt tiêu. Hiệu này gọi là **tích phân**. Điều bất ngờ là cùng con số đó lại chính là **diện tích** một hình phẳng có cạnh cong. Nhờ vậy, tích phân nối hai bài toán tưởng như chẳng liên quan: đo diện tích và tính tổng tích lũy của một đại lượng thay đổi.

> [!nen-tang] Cần nhớ từ Bài 11
> - $F$ là một nguyên hàm của $f$ khi $F'(x)=f(x)$. Mọi nguyên hàm của $f$ có dạng $F(x)+C$.
> - $\int x^\alpha dx=\dfrac{x^{\alpha+1}}{\alpha+1}+C$ $(\alpha\ne-1)$.
> - $\int\dfrac1x\,dx=\ln\lvert x\rvert+C$.
> - $\int e^xdx=e^x+C$, $\int a^xdx=\dfrac{a^x}{\ln a}+C$.
> - $\int\cos x\,dx=\sin x+C$, $\int\sin x\,dx=-\cos x+C$.
> - $\int\dfrac{dx}{\cos^2x}=\tan x+C$, $\int\dfrac{dx}{\sin^2x}=-\cot x+C$.

## 1. Khái niệm tích phân

### 1.1. Hình thang cong

Hình thang vuông có hai cạnh đáy song song, một cạnh vuông góc với đáy và một cạnh xiên **thẳng**. Nếu thay cạnh xiên thẳng bằng một **đường cong**, ta được một hình thang cong.

> [!ghi-nho] Hình thang cong (SGK tr. 12)
> Cho hàm số $y=f(x)$ **liên tục** và **không âm** trên đoạn $[a;b]$ $(a<b)$. Hình phẳng giới hạn bởi đồ thị $y=f(x)$, trục hoành và hai đường thẳng $x=a$, $x=b$ gọi là một **hình thang cong**.

Hai điều kiện "liên tục" và "không âm" có lí do: liên tục để cạnh cong không bị đứt, không âm để cả hình nằm **phía trên** trục hoành (cạnh đáy là đoạn $[a;b]$ trên trục $Ox$).

> [!vi-du] Ví dụ 1
> Hình phẳng nào dưới đây là một hình thang cong?
>
> a) Giới hạn bởi $y=\sqrt x$, trục hoành và hai đường thẳng $x=1$, $x=4$.
>
> b) Giới hạn bởi $y=x^2-1$, trục hoành và hai đường thẳng $x=0$, $x=2$.
>
> c) Giới hạn bởi $y=2^x$, trục hoành và hai đường thẳng $x=-1$, $x=1$.

> [!goi-y] Gợi ý 1
> Kiểm tra từng hàm số: có liên tục trên đoạn đã cho không? Có giá trị âm nào trên đoạn đó không?

> [!goi-y] Gợi ý 2
> b) Thử $x=0$: $y=0^2-1=?$

> [!loi-giai] Lời giải
> a) $\sqrt x$ liên tục và $\sqrt x\ge0$ trên $[1;4]$: **là** hình thang cong.
>
> b) $y(0)=-1<0$, phần đồ thị trên $[0;1)$ nằm dưới trục hoành: **không** là hình thang cong.
>
> c) $2^x$ liên tục và $2^x>0$ với mọi $x$: **là** hình thang cong (không cần $x\ge0$, chỉ cần $f(x)\ge0$).

### 1.2. Diện tích hình thang cong — vì sao lại dùng nguyên hàm?

Với hình thang thường, ta có công thức. Với hình thang cong thì sao? Ý tưởng của SGK (HĐ1, HĐ2 tr. 13) là **cho cạnh bên phải chạy**:

Gọi $S(x)$ là diện tích phần hình thang cong nằm giữa hai đường thẳng đứng tại $a$ và tại $x$ (với $a\le x\le b$). Khi $x=a$, phần đó không có bề rộng nên $S(a)=0$. Khi $x=b$, ta được cả hình: $S(b)$ chính là diện tích cần tìm.

![Hình 1. Khi x tăng thêm h, diện tích tăng thêm một dải mỏng. Dải này kẹp giữa hai hình chữ nhật cao f(x) và f(x + h)](h1-dai-mong.svg)

Bây giờ cho $x$ tăng thêm một lượng nhỏ $h>0$. Diện tích tăng thêm $S(x+h)-S(x)$ chính là **dải mỏng** trong Hình 1. Với $f$ đồng biến như hình vẽ, dải mỏng nằm giữa hai hình chữ nhật cùng bề rộng $h$:
- hình nhỏ cao $f(x)$, diện tích $f(x)\cdot h$;
- hình lớn cao $f(x+h)$, diện tích $f(x+h)\cdot h$.

Do đó

$$f(x)\cdot h\le S(x+h)-S(x)\le f(x+h)\cdot h.$$

Chia cho $h$:

$$f(x)\le\frac{S(x+h)-S(x)}{h}\le f(x+h).$$

Cho $h\to0$: vì $f$ liên tục nên $f(x+h)\to f(x)$, phân thức ở giữa bị "kẹp" và cũng dần tới $f(x)$. Mà giới hạn của phân thức đó chính là **đạo hàm** $S'(x)$. Vậy

$$S'(x)=f(x).$$

Nói cách khác: **hàm diện tích $S(x)$ là một nguyên hàm của $f(x)$**. (Với $h<0$, hoặc $f$ không đồng biến, lập luận tương tự.)

Từ đây chỉ còn một bước. Nếu $F$ là một nguyên hàm bất kì của $f$ thì $S(x)=F(x)+C$. Dùng $S(a)=0$: $C=-F(a)$. Vậy diện tích cần tìm là

$$S=S(b)=F(b)-F(a).$$

> [!ghi-nho] Diện tích hình thang cong (SGK tr. 14)
> Nếu $f(x)$ liên tục và không âm trên $[a;b]$ thì diện tích hình thang cong giới hạn bởi $y=f(x)$, trục hoành, $x=a$, $x=b$ là
> $$S=F(b)-F(a),$$
> trong đó $F(x)$ là một nguyên hàm bất kì của $f(x)$ trên $[a;b]$.

*Kiểm tra trên một hình quen thuộc:* hình thang vuông dưới đường $y=x+2$ trên $[0;2]$ có hai đáy $2$ và $4$, cao $2$, diện tích $\frac{(2+4)\cdot2}{2}=6$. Theo công thức mới: $F(x)=\frac{x^2}{2}+2x$, $F(2)-F(0)=2+4-0=6$ ✓.

> [!vi-du] Ví dụ 2
> Tính diện tích hình thang cong giới hạn bởi đồ thị $y=\sqrt x$, trục hoành và hai đường thẳng $x=0$, $x=4$.

> [!goi-y] Gợi ý 1
> $\sqrt x\ge0$ và liên tục trên $[0;4]$. Cần một nguyên hàm của $\sqrt x=x^{\frac12}$.

> [!goi-y] Gợi ý 2
> $\int x^{\frac12}dx=\dfrac{x^{\frac32}}{\frac32}+C=\dfrac23x\sqrt x+C$. Chọn $F(x)=\dfrac23x\sqrt x$ (lấy $C=0$ cho gọn).

> [!loi-giai] Lời giải
> $F(x)=\dfrac23x\sqrt x$ là một nguyên hàm của $\sqrt x$.
> $S=F(4)-F(0)=\dfrac23\cdot4\cdot2-0=\dfrac{16}{3}$ (đơn vị diện tích).

### 1.3. Định nghĩa tích phân

Hiệu $F(b)-F(a)$ **không phụ thuộc** vào việc chọn nguyên hàm nào. Thật vậy, nếu $G(x)=F(x)+C$ thì
$$G(b)-G(a)=\big(F(b)+C\big)-\big(F(a)+C\big)$$
$$=F(b)-F(a).$$
Hằng số $C$ triệt tiêu. Vì thế hiệu này là một con số xác định, đáng được đặt tên riêng.

> [!ghi-nho] Định nghĩa (SGK tr. 14)
> Cho $f(x)$ liên tục trên đoạn $[a;b]$ và $F(x)$ là một nguyên hàm của $f(x)$ trên $[a;b]$. Hiệu số $F(b)-F(a)$ gọi là **tích phân từ $a$ đến $b$** của $f(x)$, kí hiệu
> $$\int_a^b f(x)\,dx=F(x)\Big|_a^b=F(b)-F(a).$$

Đẳng thức này còn được gọi là **công thức Newton – Leibniz**. Để ý: định nghĩa chỉ cần $f$ **liên tục**, không cần $f\ge0$. Điều kiện không âm chỉ dùng khi muốn hiểu tích phân là diện tích.

> [!ghi-nho] Chú ý (SGK tr. 14)
> - $\int$ là dấu tích phân, $a$ là **cận dưới**, $b$ là **cận trên**, $f(x)\,dx$ là biểu thức dưới dấu tích phân, $f(x)$ là **hàm số dưới dấu tích phân**.
> - Quy ước: $\displaystyle\int_a^a f(x)\,dx=0$ và $\displaystyle\int_a^b f(x)\,dx=-\int_b^a f(x)\,dx$.
> - Tích phân không phụ thuộc tên biến: $\displaystyle\int_a^b f(x)\,dx=\int_a^b f(t)\,dt=\int_a^b f(u)\,du$.

*Vì sao hai quy ước hợp lí?* Theo công thức, $F(a)-F(a)=0$, và $F(b)-F(a)=-\big(F(a)-F(b)\big)$. Quy ước chỉ là để công thức Newton – Leibniz đúng với **mọi** cặp cận.

> [!bay] Nguyên hàm khác tích phân
> - $\int f(x)\,dx$ (không cận) là **họ hàm số**, có $+C$.
> - $\int_a^b f(x)\,dx$ (có cận) là **một số**, không có $+C$, không chứa $x$.
>
> Lỗi hay gặp: chỉ tính $F(b)$ rồi quên trừ $F(a)$, nhất là khi $F(a)$ không bằng $0$ (ví dụ $e^0=1$, $\cos0=1$).

**Cách trình bày chuẩn** (3 bước): tìm một nguyên hàm $F$ → viết $F(x)\Big|_a^b$ → thay cận trên **trừ** cận dưới.

> [!vi-du] Ví dụ 3
> Tính:
>
> a) $\displaystyle\int_{-2}^{1}x^2\,dx$.
>
> b) $\displaystyle\int_0^{\frac\pi3}\sin t\,dt$.
>
> c) $\displaystyle\int_1^{e^2}\frac{dx}{x}$.
>
> d) $\displaystyle\int_0^1 3^x\,dx$.

> [!goi-y] Gợi ý 1
> Dùng bảng nguyên hàm: $x^2\to\dfrac{x^3}{3}$; $\sin t\to-\cos t$; $\dfrac1x\to\ln\lvert x\rvert$; $3^x\to\dfrac{3^x}{\ln3}$.

> [!goi-y] Gợi ý 2
> Cẩn thận dấu: $(-2)^3=-8$; $-\cos\dfrac\pi3-(-\cos0)$; $\ln e^2=2$; $3^0=1$.

> [!loi-giai] Lời giải
> a) $\displaystyle\int_{-2}^{1}x^2\,dx=\frac{x^3}{3}\Big|_{-2}^{1}=\frac13-\frac{-8}{3}=\frac93=3$.
>
> b) $\displaystyle\int_0^{\frac\pi3}\sin t\,dt=-\cos t\Big|_0^{\frac\pi3}=-\frac12-(-1)=\frac12$.
>
> c) $\displaystyle\int_1^{e^2}\frac{dx}{x}=\ln\lvert x\rvert\Big|_1^{e^2}=\ln e^2-\ln1=2-0=2$.
>
> d) $\displaystyle\int_0^1 3^x\,dx=\frac{3^x}{\ln3}\Big|_0^1=\frac{3-1}{\ln3}=\frac{2}{\ln3}$.

> [!meo] Soát bằng Casio fx-580VN X
> Máy có phím tích phân $\int_\square^\square\square\,dx$. Nhập hàm và hai cận, máy cho **giá trị gần đúng**. Ví dụ câu d) máy cho $1{,}8204\ldots$, đối chiếu với $\frac{2}{\ln3}$ cũng bằng $1{,}8204\ldots$. Có hàm lượng giác thì nhớ chuyển sang chế độ **Radian**. Mẹo này rất hữu ích để chọn nhanh đáp án trắc nghiệm, nhưng em vẫn phải biết tính tay để làm câu Đúng/Sai và câu hỏi có tham số.

### 1.4. Ý nghĩa hình học của tích phân

Ghép mục 1.2 với định nghĩa:

> [!ghi-nho] Ý nghĩa hình học (SGK tr. 15)
> Nếu $f(x)$ liên tục và **không âm** trên $[a;b]$ thì $\displaystyle\int_a^b f(x)\,dx$ là diện tích $S$ của hình thang cong giới hạn bởi $y=f(x)$, trục hoành, $x=a$, $x=b$:
> $$S=\int_a^b f(x)\,dx.$$

Chiều ngược lại cũng rất có ích: nếu hình phẳng là hình quen thuộc (tam giác, hình thang, một phần hình tròn), em tính được tích phân **mà không cần nguyên hàm**. Có những hàm như $\sqrt{4-x^2}$ mà ở lớp 12 ta chưa có cách tìm nguyên hàm, nhưng tích phân của nó vẫn tính được nhờ hình học.

> [!vi-du] Ví dụ 4
> Dùng ý nghĩa hình học, tính:
>
> a) $\displaystyle\int_{-1}^{2}(x+2)\,dx$.
>
> b) $\displaystyle\int_0^2\sqrt{4-x^2}\,dx$.

> [!goi-y] Gợi ý 1
> a) Trên $[-1;2]$, $x+2\ge1>0$. Hình dưới đường thẳng là hình thang vuông. Tìm độ dài hai đáy tại $x=-1$ và $x=2$.

> [!goi-y] Gợi ý 2
> b) $y=\sqrt{4-x^2}\iff y\ge0$ và $x^2+y^2=4$: đó là nửa trên của đường tròn tâm $O$, bán kính $2$. Với $0\le x\le2$ ta chỉ lấy phần nằm trong góc phần tư thứ nhất.

> [!loi-giai] Lời giải
> a) Hình thang vuông có đáy $f(-1)=1$, đáy $f(2)=4$, chiều cao $2-(-1)=3$:
> $$\int_{-1}^{2}(x+2)\,dx=\frac{(1+4)\cdot3}{2}=\frac{15}{2}.$$
> Kiểm tra bằng nguyên hàm: $\left(\frac{x^2}{2}+2x\right)\Big|_{-1}^{2}=6-\left(-\frac32\right)=\frac{15}{2}$ ✓.
>
> b) Hình cần tính là **một phần tư** hình tròn bán kính $2$:
> $$\int_0^2\sqrt{4-x^2}\,dx=\frac14\cdot\pi\cdot2^2=\pi.$$

![Hình 2. Ví dụ 4: tích phân bằng diện tích một hình thang vuông và một phần tư hình tròn](h2-y-nghia-hinh-hoc.svg)

> [!bay]
> - $\int_{-r}^{r}\sqrt{r^2-x^2}\,dx$ là **nửa** hình tròn ($\frac{\pi r^2}{2}$), còn $\int_0^r\sqrt{r^2-x^2}\,dx$ chỉ là **một phần tư** ($\frac{\pi r^2}{4}$). Nhìn kĩ hai cận.
> - Ý nghĩa diện tích chỉ dùng khi $f\ge0$. Nếu $f\le0$ trên $[a;b]$ thì hình nằm dưới trục hoành và $\int_a^b f(x)\,dx=-S$ (một số âm). Ví dụ $\int_0^1(x-1)\,dx=-\frac12$, trong khi tam giác tương ứng có diện tích $\frac12$.

### 1.5. Ý nghĩa vật lí: tích phân của vận tốc

Nếu $s(t)$ là tọa độ (vị trí) của vật thì $v(t)=s'(t)$, tức $s$ là một nguyên hàm của $v$. Theo định nghĩa:

$$\int_a^b v(t)\,dt=s(b)-s(a).$$

Vế phải là **vị trí lúc sau trừ vị trí lúc đầu**, tức là độ dịch chuyển của vật trong khoảng thời gian $[a;b]$. Khi vật đi **một chiều** ($v\ge0$) thì độ dịch chuyển bằng **quãng đường** đi được. Trên đồ thị vận tốc, đó là **diện tích dưới đường $v(t)$**.

So với Bài 11, em không phải tìm $C$ nữa: tích phân tự lo việc đó.

> [!vi-du] Ví dụ 5
> Một đoàn tàu đang vào ga thì hãm phanh, từ lúc đó tàu chuyển động chậm dần đều với vận tốc $v(t)=16-2t$ (m/s), $t$ tính bằng giây kể từ lúc hãm. Tính quãng đường tàu đi được từ lúc hãm phanh đến khi dừng hẳn.

> [!goi-y] Gợi ý 1
> Tàu dừng khi $v(t)=0$. Tìm thời điểm đó, gọi là $T$.

> [!goi-y] Gợi ý 2
> Trên $[0;T]$, $v(t)\ge0$ (tàu đi một chiều), nên quãng đường $=\displaystyle\int_0^T v(t)\,dt$.

> [!loi-giai] Lời giải
> $v(t)=0\iff16-2t=0\iff t=8$ (giây).
> $$s=\int_0^8(16-2t)\,dt=\left(16t-t^2\right)\Big|_0^8$$
> $$=128-64=64.$$
> Tàu đi thêm được $64$ m.
> Kiểm tra bằng hình học: dưới đường $v(t)$ là tam giác vuông có hai cạnh $8$ và $16$, diện tích $\frac{8\cdot16}{2}=64$ ✓.

> [!ung-dung]
> Bài toán "khoảng cách phanh" này dùng để tính **khoảng cách an toàn** giữa các xe trên đường cao tốc. Vận tốc ban đầu tăng gấp đôi thì quãng đường phanh tăng gấp **bốn** (diện tích tam giác tỉ lệ với bình phương cạnh). Đó là lí do biển báo khoảng cách an toàn ghi số mét tăng rất nhanh theo tốc độ.

## 2. Tính chất của tích phân

### 2.1. Bốn tính chất cơ bản

> [!ghi-nho] Tính chất (SGK tr. 16)
> Cho $f(x)$, $g(x)$ liên tục trên $[a;b]$. Khi đó:
> - $\displaystyle\int_a^b kf(x)\,dx=k\int_a^b f(x)\,dx$ ($k$ là hằng số).
> - $\displaystyle\int_a^b[f(x)+g(x)]\,dx=\int_a^b f(x)\,dx+\int_a^b g(x)\,dx$.
> - $\displaystyle\int_a^b[f(x)-g(x)]\,dx=\int_a^b f(x)\,dx-\int_a^b g(x)\,dx$.
> - $\displaystyle\int_a^b f(x)\,dx=\int_a^c f(x)\,dx+\int_c^b f(x)\,dx$ $(a<c<b)$.

*Vì sao?* Ba tính chất đầu đến thẳng từ tính chất của nguyên hàm (Bài 11): nếu $F$, $G$ là nguyên hàm của $f$, $g$ thì $kF$, $F\pm G$ là nguyên hàm của $kf$, $f\pm g$; thay cận là xong. Tính chất thứ tư (**cộng đoạn**) cũng chỉ là phép cộng:
$$\big[F(c)-F(a)\big]+\big[F(b)-F(c)\big]=F(b)-F(a).$$
Về hình học: cắt hình thang cong bằng đường thẳng $x=c$ thành hai mảnh, tổng diện tích hai mảnh bằng diện tích cả hình.

> [!em-co-biet]
> Nhờ quy ước đổi cận, tính chất cộng đoạn đúng với **mọi** $c$, kể cả $c$ nằm ngoài $[a;b]$ (miễn $f$ liên tục trên đoạn chứa cả ba số). Ví dụ $\int_0^2 f=\int_0^5 f+\int_5^2 f$. Đề thi rất hay dùng điều này.

> [!vi-du] Ví dụ 6
> Tính:
>
> a) $\displaystyle\int_1^2\left(4x^3-\frac{2}{x^2}\right)dx$.
>
> b) $\displaystyle\int_0^\pi(3\cos x+2\sin x)\,dx$.
>
> c) $\displaystyle\int_0^1(e^x+2^x)\,dx$.

> [!goi-y] Gợi ý 1
> Tách thành từng tích phân, hằng số đưa ra ngoài. a) Viết $\dfrac{2}{x^2}=2x^{-2}$, nguyên hàm là $-\dfrac2x$.

> [!goi-y] Gợi ý 2
> b) $\sin\pi=\sin0=0$ và $\cos\pi=-1$, $\cos0=1$.

> [!loi-giai] Lời giải
> a) $\displaystyle\int_1^2 4x^3dx-2\int_1^2x^{-2}dx=x^4\Big|_1^2+\frac2x\Big|_1^2$, tức là
> $$=(16-1)+(1-2)=14.$$
>
> b) $\displaystyle3\int_0^\pi\cos x\,dx+2\int_0^\pi\sin x\,dx=3\sin x\Big|_0^\pi-2\cos x\Big|_0^\pi$, tức là
> $$=3(0-0)-2(-1-1)=4.$$
>
> c) $\displaystyle e^x\Big|_0^1+\frac{2^x}{\ln2}\Big|_0^1=(e-1)+\frac{2-1}{\ln2}=e-1+\frac{1}{\ln2}$.

> [!bay]
> - Ở câu a), $\int\left(-2x^{-2}\right)dx=+\dfrac2x$: hai dấu trừ khử nhau. Học sinh hay ra $-\dfrac2x$ rồi sai dấu cả bài.
> - Không có "tích phân của tích bằng tích các tích phân": $\int_a^b f(x)g(x)\,dx\ne\int_a^b f(x)\,dx\cdot\int_a^b g(x)\,dx$. Gặp tích thì khai triển trước.

**Dùng tính chất khi chưa biết $f$.** Đề thi rất hay cho sẵn vài giá trị tích phân của một hàm $f$ "bí ẩn" rồi hỏi tích phân khác. Em không cần (và không thể) tìm $f$. Chỉ cần biến đổi biểu thức cần tính về các tích phân đã biết bằng bốn tính chất.

> [!vi-du] Ví dụ 7
> Cho $f$, $g$ liên tục trên $\mathbb R$, biết $\displaystyle\int_0^2 f(x)\,dx=3$, $\displaystyle\int_0^5 f(x)\,dx=7$ và $\displaystyle\int_0^2 g(x)\,dx=-1$. Tính:
>
> a) $\displaystyle\int_2^5 f(x)\,dx$.
>
> b) $\displaystyle\int_0^2\big[3f(x)-2g(x)+x\big]\,dx$.

> [!goi-y] Gợi ý 1
> a) Cộng đoạn: $\int_0^5=\int_0^2+\int_2^5$.

> [!goi-y] Gợi ý 2
> b) Tách thành ba tích phân. Số hạng $x$ **không** phải $f$ hay $g$: phải tính riêng $\int_0^2x\,dx$.

> [!loi-giai] Lời giải
> a) $\displaystyle\int_2^5 f=\int_0^5 f-\int_0^2 f=7-3=4$.
>
> b) $\displaystyle3\int_0^2 f-2\int_0^2 g+\int_0^2x\,dx=3\cdot3-2\cdot(-1)+\frac{x^2}{2}\Big|_0^2$, tức là
> $$=9+2+2=13.$$

> [!bay] Hằng số dưới dấu tích phân
> $\int_0^2\big[f(x)+1\big]dx=3+\int_0^2 1\,dx=3+2=5$, **không** phải $3+1$. Số $1$ cũng phải "tích phân" theo $x$ trên đoạn dài $2$: $\int_a^b k\,dx=k(b-a)$.

### 2.2. Tích phân của hàm số chứa dấu giá trị tuyệt đối

Ta chưa có nguyên hàm của $\lvert x-1\rvert$ trên cả đoạn, vì biểu thức này "đổi công thức" tại $x=1$. Cách xử lí rất tự nhiên: **cắt đoạn tại chỗ đổi dấu** (tính chất cộng đoạn), trên mỗi đoạn con thì phá dấu giá trị tuyệt đối.

**Các bước:**
1. Giải $g(x)=0$ để tìm các nghiệm nằm **trong** $(a;b)$.
2. Lập bảng xét dấu $g(x)$ trên $[a;b]$.
3. Tách $\int_a^b\lvert g(x)\rvert dx$ thành tổng các tích phân trên từng đoạn con. Đoạn nào $g\ge0$ giữ nguyên, đoạn nào $g\le0$ đổi thành $-g$.
4. Tính từng tích phân rồi cộng.

> [!vi-du] Ví dụ 8
> Tính:
>
> a) $\displaystyle\int_{-1}^{3}\lvert x-1\rvert\,dx$.
>
> b) $\displaystyle\int_2^4\lvert x^2-9\rvert\,dx$.

> [!goi-y] Gợi ý 1
> a) $x-1=0\iff x=1\in(-1;3)$. Trên $[-1;1]$: $x-1\le0$. Trên $[1;3]$: $x-1\ge0$.

> [!goi-y] Gợi ý 2
> b) $x^2-9=0\iff x=\pm3$, chỉ $x=3$ nằm trong $(2;4)$. Trên $[2;3]$: $x^2-9\le0$, nên $\lvert x^2-9\rvert=9-x^2$.

> [!loi-giai] Lời giải
> a) $\displaystyle\int_{-1}^{1}(1-x)\,dx+\int_1^3(x-1)\,dx=\left(x-\frac{x^2}{2}\right)\Big|_{-1}^{1}+\left(\frac{x^2}{2}-x\right)\Big|_1^3$, tức là
> $$=\left[\frac12-\left(-\frac32\right)\right]+\left[\frac32-\left(-\frac12\right)\right]$$
> $$=2+2=4.$$
> Kiểm tra bằng hình: đồ thị $y=\lvert x-1\rvert$ tạo với trục hoành hai tam giác vuông cân, cạnh góc vuông $2$, mỗi tam giác có diện tích $2$ ✓.
>
> b) $\displaystyle\int_2^3(9-x^2)\,dx+\int_3^4(x^2-9)\,dx=\left(9x-\frac{x^3}{3}\right)\Big|_2^3+\left(\frac{x^3}{3}-9x\right)\Big|_3^4$, tức là
> $$=\left(18-\frac{46}{3}\right)+\left[-\frac{44}{3}-(-18)\right]$$
> $$=\frac83+\frac{10}{3}=6.$$

> [!bay]
> - **Không** được viết $\int_a^b\lvert g\rvert dx=\left\lvert\int_a^b g\,dx\right\rvert$. Ở câu b): $\int_2^4(x^2-9)\,dx=\frac{56}{3}-18=\frac23$, khác hẳn $6$. Hai cách chỉ trùng nhau khi $g$ **không đổi dấu** trên $[a;b]$.
> - Nghiệm nằm **ngoài** đoạn (như $x=-3$ ở câu b) thì bỏ qua, không cắt.

> [!meo] Hàm số lẻ trên đoạn đối xứng
> Nếu $f$ là hàm số lẻ ($f(-x)=-f(x)$), đồ thị đối xứng qua gốc $O$, phần trên trục hoành bên này bù đúng phần dưới trục hoành bên kia. Vì thế $\int_{-a}^{a}f(x)\,dx=0$. Ví dụ $\int_{-2}^{2}(x^3-x)\,dx=0$ — nhìn là ra, không cần tính. (Đây là kiến thức mở rộng, SGK không nêu, nhưng giúp soát đáp án rất nhanh.)

### 2.3. Độ dịch chuyển và quãng đường

Khi vận tốc **đổi dấu**, vật đi tới rồi quay lại. Lúc đó:
- $\displaystyle\int_a^b v(t)\,dt$ là **độ dịch chuyển** (vị trí cuối trừ vị trí đầu). Đoạn đi lùi được tính **âm** nên có thể "bù trừ" với đoạn đi tới.
- $\displaystyle\int_a^b\lvert v(t)\rvert\,dt$ là **tổng quãng đường** đi được. Đoạn nào cũng được tính dương.

Đây chính là ý của bài tập 4.11 (SGK tr. 18), và là chỗ đề thi rất hay "gài".

> [!vi-du] Ví dụ 9
> Một chất điểm chuyển động trên một đường thẳng với vận tốc $v(t)=t^2-4t+3$ (m/s), $t$ tính bằng giây. Trong 3 giây đầu ($0\le t\le3$), tính độ dịch chuyển và tổng quãng đường chất điểm đi được.

> [!goi-y] Gợi ý 1
> $v(t)=(t-1)(t-3)$. Xét dấu trên $[0;3]$: dương trên $[0;1)$, âm trên $(1;3)$.

> [!goi-y] Gợi ý 2
> Một nguyên hàm của $v$ là $F(t)=\dfrac{t^3}{3}-2t^2+3t$. Tính $F(0)$, $F(1)$, $F(3)$ một lần rồi dùng lại.

> [!loi-giai] Lời giải
> $F(0)=0$, $F(1)=\dfrac13-2+3=\dfrac43$, $F(3)=9-18+9=0$.
>
> Độ dịch chuyển: $\displaystyle\int_0^3 v(t)\,dt=F(3)-F(0)=0$ (m). Sau 3 giây chất điểm **quay về đúng chỗ cũ**.
>
> Quãng đường: $\displaystyle\int_0^1 v\,dt-\int_1^3 v\,dt=\big[F(1)-F(0)\big]-\big[F(3)-F(1)\big]$, tức là
> $$=\frac43-\left(-\frac43\right)=\frac83\approx2{,}67.$$
> Tổng quãng đường khoảng $2{,}67$ m.

![Hình 3. Phần trên trục hoành (đi tới) và phần dưới trục hoành (đi lùi) có diện tích bằng nhau: độ dịch chuyển bằng 0, quãng đường bằng 8/3 m](h3-van-toc-doi-dau.svg)

### 2.4. Tích phân trong thực tế: lượng thay đổi và giá trị trung bình

Ý nghĩa vật lí ở mục 1.5 đúng cho **mọi** đại lượng. Nếu $Q'(x)$ là tốc độ thay đổi của $Q$ thì
$$\int_a^b Q'(x)\,dx=Q(b)-Q(a)$$
là **lượng thay đổi** của $Q$ khi $x$ đi từ $a$ đến $b$. Ví dụ: tốc độ nước chảy (lít/phút) → lượng nước; lợi nhuận biên → lợi nhuận tăng thêm; tốc độ tăng dân số → số người tăng thêm.

> [!vi-du] Ví dụ 10
> Một máy bơm đưa nước lên bồn chứa với tốc độ $r(t)=12+0{,}6t^2$ (lít/phút), $t$ là số phút kể từ lúc bật máy. Hỏi trong 10 phút đầu, máy bơm được bao nhiêu lít nước?

> [!goi-y] Gợi ý 1
> Gọi $V(t)$ là lượng nước đã bơm. $V'(t)=r(t)$, lượng cần tìm là $V(10)-V(0)=\displaystyle\int_0^{10}r(t)\,dt$.

> [!goi-y] Gợi ý 2
> Nguyên hàm của $0{,}6t^2$ là $0{,}2t^3$.

> [!loi-giai] Lời giải
> $$\int_0^{10}(12+0{,}6t^2)\,dt=\left(12t+0{,}2t^3\right)\Big|_0^{10}$$
> $$=120+200=320.$$
> Máy bơm được $320$ lít nước.

**Giá trị trung bình.** Nếu một đại lượng thay đổi liên tục theo $f(x)$ trên $[a;b]$, giá trị "trung bình" của nó là chiều cao của hình chữ nhật có **cùng đáy** $[a;b]$ và **cùng diện tích** với hình dưới đồ thị:

> [!ghi-nho] Giá trị trung bình (SGK tr. 17)
> $$\bar f=\frac{1}{b-a}\int_a^b f(x)\,dx.$$

*Vì sao?* Chia $[a;b]$ thành $n$ đoạn rất nhỏ, mỗi đoạn dài $\Delta x=\frac{b-a}{n}$, lấy trung bình cộng $n$ giá trị: $\frac{f(x_1)+\dots+f(x_n)}{n}=\frac{1}{b-a}\big[f(x_1)\Delta x+\dots+f(x_n)\Delta x\big]$. Tổng trong ngoặc gần bằng diện tích dưới đồ thị, tức là tích phân.

> [!vi-du] Ví dụ 11
> Sau khi uống một liều thuốc, nồng độ thuốc trong máu của một bệnh nhân được mô hình hóa bởi $C(t)=4t-t^2$ (mg/L), $0\le t\le4$, $t$ tính bằng giờ. Tính nồng độ trung bình trong 4 giờ đó (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> $a=0$, $b=4$, nên $\bar C=\dfrac14\displaystyle\int_0^4(4t-t^2)\,dt$.

> [!goi-y] Gợi ý 2
> Nguyên hàm: $2t^2-\dfrac{t^3}{3}$.

> [!loi-giai] Lời giải
> $$\int_0^4(4t-t^2)\,dt=\left(2t^2-\frac{t^3}{3}\right)\Big|_0^4$$
> $$=32-\frac{64}{3}=\frac{32}{3}.$$
> $\bar C=\dfrac14\cdot\dfrac{32}{3}=\dfrac83\approx2{,}67$ (mg/L). Để ý: nồng độ cao nhất là $C(2)=4$ mg/L, trung bình chỉ bằng $\frac23$ giá trị cao nhất.

> [!ung-dung]
> Trong dược lí, bác sĩ quan tâm **diện tích dưới đường cong nồng độ thuốc** (kí hiệu AUC) — chính là một tích phân. AUC cho biết tổng lượng thuốc cơ thể thực sự "tiếp xúc", dùng để so sánh hai cách dùng thuốc (uống và tiêm) hay hai hãng thuốc có tương đương nhau không.

## Dạng bài thi hay gặp

### Dạng 1. Tính tích phân trực tiếp (trắc nghiệm 4 lựa chọn)

- **Nhận biết:** "$\int_a^b f(x)\,dx$ bằng", $f$ là tổng các hàm trong bảng nguyên hàm (có thể phải khai triển trước).
- **Phương pháp:**
  1. Biến đổi $f$ về tổng các hàm có trong bảng (khai triển tích, chia phân thức, viết căn thành lũy thừa).
  2. Tìm một nguyên hàm $F$ (không cần $+C$).
  3. Tính $F(b)-F(a)$. Soát lại bằng máy tính.
- **Bẫy:** quên trừ $F(a)$ khi $F(a)\ne0$; dấu của $\int\sin x$; nhầm tích phân với $f(b)-f(a)$.

> [!vi-du] Ví dụ 12
> $\displaystyle\int_0^1(x+1)^2\,dx$ bằng
>
> (1) $\dfrac83$.  (2) $\dfrac73$.  (3) $3$.  (4) $4$.

> [!goi-y] Gợi ý 1
> Khai triển $(x+1)^2=x^2+2x+1$ rồi dùng bảng.

> [!goi-y] Gợi ý 2
> Mỗi phương án nhiễu ứng với một lỗi: chỉ tính $F(1)$ mà quên $F(0)$; tính $f(1)-f(0)$ (nhầm sang đạo hàm); tính $f(1)$.

> [!loi-giai] Lời giải
> $$\int_0^1(x^2+2x+1)\,dx=\left(\frac{x^3}{3}+x^2+x\right)\Big|_0^1$$
> $$=\frac13+1+1=\frac73.$$
> Chọn $\frac73$. (Nếu dùng $F(x)=\frac{(x+1)^3}{3}$ thì phải nhớ $F(0)=\frac13\ne0$: $\frac83-\frac13=\frac73$. Quên trừ sẽ ra $\frac83$.)

### Dạng 2. Dùng tính chất với các tích phân cho trước (trả lời ngắn)

- **Nhận biết:** đề cho $\int f$, $\int g$ trên một vài đoạn, hỏi tích phân của một tổ hợp, hoặc trên đoạn khác.
- **Phương pháp:**
  1. Đưa hằng số ra ngoài, tách tổng/hiệu.
  2. Cận lệch thì dùng **cộng đoạn**, cận ngược thì **đổi dấu**.
  3. Số hạng là hàm cụ thể ($x$, hằng số…) thì tính riêng.
- **Bẫy:** $\int_a^b k\,dx=k(b-a)$, không phải $k$; quên đổi dấu khi đảo cận.

> [!vi-du] Ví dụ 13
> Cho $\displaystyle\int_1^4 f(x)\,dx=10$ và $\displaystyle\int_1^4 g(x)\,dx=3$. Tính $\displaystyle\int_4^1\big[g(x)-2f(x)\big]\,dx$.

> [!goi-y] Gợi ý 1
> Cận trên nhỏ hơn cận dưới: đổi cận thì đổi dấu, $\int_4^1=-\int_1^4$.

> [!goi-y] Gợi ý 2
> $\int_1^4[g-2f]\,dx=3-2\cdot10$.

> [!loi-giai] Lời giải
> $$\int_4^1[g(x)-2f(x)]\,dx$$
> $$=-\int_1^4[g(x)-2f(x)]\,dx$$
> $$=-(3-20)=17.$$
> Đáp số: $17$.

### Dạng 3. Đúng/Sai về $f(x)$, nguyên hàm $F(x)$ và tích phân

- **Nhận biết:** đề cho $f(x)$ (thường kèm $F(x_0)=c$), bốn ý: biểu thức $F$, giá trị một tích phân, liên hệ $\int_a^b f=F(b)-F(a)$, tích phân có dấu giá trị tuyệt đối hoặc diện tích.
- **Phương pháp:** tìm $F$ ngay (Bài 11). Tích phân nào cũng là **hiệu hai giá trị của $F$**, kể cả khi $F$ có hằng số $C$ lạ. Ý có $\lvert f\rvert$ thì xét dấu $f$ trước.
- **Bẫy:** nhầm $\int_0^b f$ với $F(b)$ (chỉ đúng khi $F(0)=0$); cho rằng $\int\lvert f\rvert=\lvert\int f\rvert$.

> [!vi-du] Ví dụ 14 (Đúng/Sai)
> Cho hàm số $f(x)=6x^2-4x$ và $F(x)$ là một nguyên hàm của $f(x)$ trên $\mathbb R$ thỏa mãn $F(1)=2$. Xét các mệnh đề:
>
> a) $F(x)=2x^3-2x^2+2$.
>
> b) $\displaystyle\int_0^1 f(x)\,dx=2$.
>
> c) $\displaystyle\int_0^2 f(x)\,dx=F(2)-F(0)=8$.
>
> d) $\displaystyle\int_0^1\lvert f(x)\rvert\,dx=0$.

> [!goi-y] Gợi ý 1
> b) Tích phân là $F(1)-F(0)$, mà $F(0)=2$ chứ không phải $0$.

> [!goi-y] Gợi ý 2
> d) $\lvert f\rvert\ge0$ và không đồng nhất bằng $0$ trên $[0;1]$, nên tích phân của nó phải **dương**. Muốn tính cụ thể: $f(x)=2x(3x-2)$ đổi dấu tại $x=\frac23$.

> [!loi-giai] Lời giải
> a) **Đúng** — $F(x)=2x^3-2x^2+C$, $F(1)=C=2$.
>
> b) **Sai** — $\int_0^1 f=F(1)-F(0)=2-2=0$.
>
> c) **Đúng** — $F(2)=16-8+2=10$, $F(0)=2$, hiệu bằng $8$.
>
> d) **Sai** — $f\le0$ trên $\left[0;\frac23\right]$, $f\ge0$ trên $\left[\frac23;1\right]$. Tính ra $\int_0^1\lvert f\rvert\,dx=\frac{8}{27}+\frac{8}{27}=\frac{16}{27}>0$. Con số $0$ là $\int_0^1 f$ (phần âm và phần dương bù nhau), không phải tích phân của $\lvert f\rvert$.

### Dạng 4. Chuyển động: quãng đường từ vận tốc, đọc đồ thị vận tốc (trả lời ngắn)

- **Nhận biết:** cho $v(t)$ bằng công thức **hoặc bằng đồ thị** (thường là các đoạn thẳng), hỏi quãng đường, thời điểm dừng, vận tốc trung bình, hai xe gặp nhau.
- **Phương pháp:**
  1. Xác định khoảng thời gian $[a;b]$ (xe dừng khi $v=0$).
  2. Xét dấu $v$: không đổi dấu thì quãng đường $=\int_a^b v\,dt$; đổi dấu thì chia đoạn, lấy $\int\lvert v\rvert$.
  3. Đồ thị là đường gấp khúc: quãng đường = **tổng diện tích** các tam giác, hình chữ nhật, hình thang — không cần viết công thức $v(t)$.
  4. Vận tốc trung bình bằng quãng đường chia cho thời gian (cũng chính là giá trị trung bình của $v$).
- **Bẫy:** đọc sai đơn vị (km/h với m/s, phút với giây); quên đoạn chạy đều; tính độ dịch chuyển khi đề hỏi quãng đường.

> [!vi-du] Ví dụ 15
> Một ô tô xuất phát từ trạng thái đứng yên. Đồ thị vận tốc của nó (Hình 4) gồm ba đoạn thẳng: tăng tốc đều từ $0$ lên $12$ m/s trong 4 giây đầu, chạy đều $12$ m/s đến giây thứ 10, rồi phanh, giảm tốc đều và dừng ở giây thứ 13. Tính quãng đường ô tô đi được và vận tốc trung bình trong 13 giây đó (vận tốc trung bình làm tròn đến hàng phần mười).

![Hình 4. Quãng đường là diện tích dưới đồ thị vận tốc: tam giác 24 m, hình chữ nhật 72 m, tam giác 18 m](h4-do-thi-van-toc.svg)

> [!goi-y] Gợi ý 1
> $v\ge0$ suốt 13 giây, quãng đường $=\int_0^{13}v(t)\,dt$ = diện tích hình dưới đồ thị.

> [!goi-y] Gợi ý 2
> Hình dưới đồ thị là một hình thang (đáy lớn $13$, đáy nhỏ $10-4=6$, cao $12$), hoặc tách thành tam giác + hình chữ nhật + tam giác.

> [!loi-giai] Lời giải
> Cộng ba mảnh: $\frac12\cdot4\cdot12+6\cdot12+\frac12\cdot3\cdot12=24+72+18=114$ (m).
> Hoặc dùng công thức hình thang: $\frac{(13+6)\cdot12}{2}=114$ ✓.
> Vận tốc trung bình: $\dfrac{114}{13}\approx8{,}8$ (m/s).

> [!em-co-biet]
> Ở Bài 11, ta biết kí hiệu $\int$ là chữ S kéo dài (*summa* — tổng). Bây giờ em thấy rõ vì sao: tích phân là **tổng** của rất nhiều mảnh nhỏ $f(x)\,\Delta x$ (dải mỏng ở Hình 1, quãng đường nhỏ $v\,\Delta t$). Newton và Leibniz (thế kỉ XVII) phát hiện ra rằng tổng này tính được bằng **nguyên hàm** — một trong những phát hiện quan trọng nhất của toán học, gọi là định lí cơ bản của giải tích.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Định nghĩa | $\int_a^b f(x)\,dx=F(x)\Big\vert_a^b=F(b)-F(a)$, $F$ là một nguyên hàm bất kì của $f$ |
| Quy ước | $\int_a^a f\,dx=0$; $\int_a^b f\,dx=-\int_b^a f\,dx$ |
| Ý nghĩa hình học | $f\ge0$: $\int_a^b f\,dx$ = diện tích hình thang cong |
| Hằng số, tổng, hiệu | $\int_a^b kf=k\int_a^b f$; $\int_a^b(f\pm g)=\int_a^b f\pm\int_a^b g$ |
| Cộng đoạn | $\int_a^b f=\int_a^c f+\int_c^b f$ |
| Hằng số dưới dấu $\int$ | $\int_a^b k\,dx=k(b-a)$ |
| Dấu giá trị tuyệt đối | Tìm nghiệm trong $(a;b)$ → chia đoạn → phá dấu giá trị tuyệt đối |
| Vận tốc | $\int_a^b v\,dt$ = độ dịch chuyển; $\int_a^b\lvert v\rvert\,dt$ = quãng đường |
| Lượng thay đổi | $\int_a^b Q'(x)\,dx=Q(b)-Q(a)$ |
| Giá trị trung bình | $\bar f=\dfrac{1}{b-a}\int_a^b f(x)\,dx$ |

**Sơ đồ tư duy khi gặp đề:** có hàm cụ thể → biến đổi về bảng nguyên hàm → $F(b)-F(a)$. Có dấu giá trị tuyệt đối hoặc vận tốc đổi dấu → xét dấu, chia đoạn. Chỉ cho giá trị tích phân của $f$ → dùng tính chất, không tìm $f$. Có đồ thị đoạn thẳng hoặc nửa/phần tư đường tròn → tính diện tích bằng hình học.
