---
title: Ôn tập chương I
thoi-gian: 60 phút
muc-tieu:
  - Hệ thống hóa toàn chương I — đơn điệu, cực trị, GTLN và GTNN, tiệm cận, khảo sát và đồ thị, ứng dụng thực tiễn — và thấy chúng cùng xoay quanh đạo hàm, giới hạn và bảng biến thiên
  - Phân biệt chắc chắn các cặp khái niệm dễ nhầm (cực trị – GTLN, đồ thị f – đồ thị f′, tốc độ trung bình – tức thời, chi phí biên – chi phí trung bình…)
  - Nhận ra và tránh các lỗi sai hay gặp nhất của chương trong đề thi
  - Giải được các bài tổng hợp phối hợp nhiều bài, theo đúng ba dạng đề tốt nghiệp (4 lựa chọn, Đúng/Sai, trả lời ngắn)
  - Tự làm được các dạng của "Bài tập cuối chương I" (SGK tr. 42–44)
---
> [!ghi-nho] Chương này trong 10 dòng
> 1. Mọi thứ bắt đầu từ **dấu của $f'(x)$**: $f'>0$ trên khoảng thì $f$ đồng biến, $f'<0$ thì nghịch biến (Bài 1).
> 2. **Cực trị** là chỗ $f'$ **đổi dấu** ($+\to-$: cực đại; $-\to+$: cực tiểu). $f'(x_0)=0$ mà không đổi dấu thì **không** là cực trị.
> 3. Phân biệt: điểm cực trị $x_0$ · giá trị cực trị $f(x_0)$ · điểm cực trị của đồ thị $(x_0;\,f(x_0))$.
> 4. **GTLN, GTNN trên đoạn**: so sánh $f$ tại các điểm tới hạn **trong** đoạn và **hai đầu mút**. Trên khoảng: đọc **bảng biến thiên**, có thể không tồn tại (Bài 2).
> 5. Cực trị là khái niệm **địa phương**, GTLN – GTNN là **toàn cục**: GTLN có thể nằm ở đầu mút.
> 6. **Tiệm cận**: ngang — giới hạn tại $\pm\infty$ là một số; đứng — một giới hạn một bên là $\pm\infty$; xiên — $\lim\big[f(x)-(ax+b)\big]=0$ (Bài 3).
> 7. **Ba họ hàm** cần thuộc dáng: bậc ba (tâm đối xứng có hoành độ $-\frac{b}{3a}$), $\frac{ax+b}{cx+d}$ (tâm là giao hai tiệm cận), $\frac{ax^2+bx+c}{px+q}$ (tâm là giao TCĐ và TCX) (Bài 4).
> 8. **Số nghiệm của $f(x)=m$** = số giao điểm của đồ thị với đường nằm ngang $y=m$.
> 9. **Đạo hàm là tốc độ thay đổi tức thời**: vận tốc $v=s'$, gia tốc $a=v'$, chi phí biên $C'(x)$ (Bài 5).
> 10. **Bài toán tối ưu**: chọn ẩn → điều kiện của ẩn → lập hàm một biến → GTLN/GTNN → trả lời **đúng đại lượng** được hỏi.

Chương I là chương **nặng điểm nhất** của đề Toán tốt nghiệp: gần như đề nào cũng có câu đọc bảng biến thiên hoặc đồ thị, một câu Đúng/Sai về một hàm số hay một mô hình thực tế, và ít nhất một câu trả lời ngắn về tối ưu. Bài ôn tập này **không giảng lại** từng định nghĩa — em đã có Bài 1 đến Bài 5. Ở đây ta làm ba việc: (1) nhìn cả chương trên **một tấm bản đồ**; (2) tách bạch những thứ **dễ nhầm**; (3) luyện **bài tổng hợp** phối hợp nhiều bài như trong đề thật.

## 1. Bản đồ của chương

### 1.1. Hai công cụ, một "trạm trung chuyển"

Cả chương chỉ dùng **hai công cụ** của lớp 11: **đạo hàm** và **giới hạn**. Đạo hàm cho biết đồ thị đi lên hay đi xuống, đỉnh – đáy ở đâu; giới hạn cho biết đồ thị đi về đâu ở hai đầu và gần những điểm "cấm". Mọi thông tin đó được gom vào **bảng biến thiên (BBT)** — và từ BBT, em trả lời gần như mọi câu hỏi còn lại.

![Hình 1. Bản đồ chương I: đạo hàm và giới hạn dẫn đến bảng biến thiên; từ bảng biến thiên trả lời câu hỏi của các Bài 2, 4, 5](h1-ban-do-chuong.svg)

**Vì sao BBT lại là "trạm trung chuyển"?** Vì nó trả lời được cùng lúc năm câu hỏi khác nhau:

| Nhìn vào chỗ nào của BBT | Đọc được gì | Bài |
|---|---|---|
| Dòng $y'$: dấu $+$ / $-$ trên từng khoảng | Khoảng đồng biến, nghịch biến (đọc theo **dòng $x$**) | Bài 1 |
| Chỗ mũi tên đổi chiều | Điểm cực trị ($x$) và giá trị cực trị ($y$) | Bài 1 |
| So sánh các "đỉnh", "đáy" **và hai đầu** trên tập đang xét | GTLN, GTNN (hoặc kết luận **không có**) | Bài 2 |
| Hai đầu $x\to\pm\infty$; hai bên vạch kép $\Vert$ | Tiệm cận ngang; tiệm cận đứng | Bài 3 |
| Kẻ đường ngang $y=m$ cắt các mũi tên | Số nghiệm của $f(x)=m$ | Bài 4 |

### 1.2. Gặp câu hỏi nào — dùng công cụ nào

| Đề hỏi | Công cụ | Xem lại |
|---|---|---|
| "đồng biến/nghịch biến trên khoảng nào", "có bao nhiêu cực trị" | dấu của $f'$ (bảng xét dấu, nghiệm bội chẵn – lẻ) | Bài 1 |
| "cho đồ thị $y=f'(x)$…" | chỉ nhìn đồ thị $f'$ **trên hay dưới** trục hoành | Bài 1 mục 2.3 |
| "giá trị lớn nhất trên đoạn…" | quy tắc so sánh (điểm tới hạn trong đoạn + 2 đầu mút) | Bài 2 |
| "giá trị lớn nhất trên khoảng / trên $\mathbb R$…" | BBT kèm giới hạn ở đầu mở | Bài 2 |
| "đồ thị có bao nhiêu tiệm cận" | giới hạn tại $\pm\infty$, nghiệm của mẫu (thử tử!) | Bài 3 |
| "đồ thị trong hình là của hàm số nào", "dấu các hệ số" | tiệm cận, chiều biến thiên, giao trục | Bài 4 |
| "phương trình $f(x)=m$ có mấy nghiệm", "tìm $m$ để…" | cô lập $m$, đường ngang trượt trên BBT | Bài 4 |
| "vận tốc, gia tốc, tốc độ tăng tại thời điểm…" | đạo hàm cấp một, cấp hai, thế số | Bài 5 |
| "lớn nhất / nhỏ nhất / tốn ít nhất / lãi nhiều nhất" | lập hàm một biến → GTLN, GTNN | Bài 2, Bài 5 |

> [!meo] Ba câu tự hỏi trước khi đặt bút
> 1. **Đề cho cái gì?** Công thức $f$, BBT/đồ thị của $f$, hay **$f'$** (công thức/đồ thị)? Ba trường hợp đọc theo ba cách khác nhau.
> 2. **Xét trên tập nào?** Tập xác định, một đoạn, một khoảng, hay miền thực tế $t\ge0$?
> 3. **Đề hỏi đại lượng nào?** $x$ hay $f(x)$? Giá trị lớn nhất của $f$ hay của $f'$? Giá bán hay lợi nhuận?

## 2. Bảng so sánh – phân biệt

### 2.1. "Đỉnh" và "điểm cao nhất"

| | Cực đại (Bài 1) | Giá trị lớn nhất (Bài 2) |
|---|---|---|
| So sánh với | các điểm **lân cận** $x_0$ | **mọi** điểm của tập $D$ |
| Vị trí | luôn ở **bên trong** khoảng xác định | có thể ở **đầu mút** của đoạn |
| Số lượng | có thể nhiều giá trị cực đại khác nhau | chỉ **một** số $M$ (có thể đạt tại nhiều điểm) |
| Có thể không tồn tại? | có (hàm đơn điệu không có cực trị) | có (trên khoảng); trên đoạn với $f$ liên tục thì **luôn có** |
| Lạ nhưng đúng | $y_{\text{CĐ}}$ có thể **nhỏ hơn** $y_{\text{CT}}$ | $\max f$ có thể **khác mọi** giá trị cực đại |

Và ba chữ cần đọc đúng: **điểm cực đại của hàm số** là $x_0$; **giá trị cực đại** là $f(x_0)$; **điểm cực đại của đồ thị** là $(x_0;\,f(x_0))$. Tương tự, "GTLN **bằng**" hỏi $M$, còn "GTLN **đạt tại**" hỏi $x_0$.

### 2.2. Đề cho $f$ hay cho $f'$?

| | Cho BBT/đồ thị của $f$ | Cho đồ thị của $f'$ |
|---|---|---|
| $f$ đồng biến ở đâu | đồ thị $f$ **đi lên** | đồ thị $f'$ nằm **trên** trục hoành |
| Cực trị của $f$ | đỉnh, đáy của đồ thị $f$ | chỗ đồ thị $f'$ **cắt** (xuyên qua) trục hoành |
| Không là cực trị | đoạn "nằm ngang" rồi đi tiếp cùng chiều | chỗ đồ thị $f'$ chỉ **chạm** trục hoành |
| Đỉnh, đáy của đồ thị đang nhìn | là cực trị của $f$ | là cực trị của **$f'$**, **không** phải của $f$ |
| Đồ thị đang nhìn đi lên | $f$ tăng | $f'$ tăng — **chưa** biết $f$ tăng hay giảm |

### 2.3. Ba loại tiệm cận

| | Tiệm cận ngang ${y=y_0}$ | Tiệm cận đứng ${x=x_0}$ | Tiệm cận xiên ${y=ax+b}$ (${a\ne0}$) |
|---|---|---|---|
| Điều kiện | ${\lim\limits_{x\to+\infty}f=y_0}$ **hoặc** ${\lim\limits_{x\to-\infty}f=y_0}$ | **một** giới hạn một bên tại $x_0$ là $\pm\infty$ | $\lim\big[f-(ax+b)\big]=0$ tại $+\infty$ hoặc $-\infty$ |
| Tối đa | 2 | không giới hạn | 2 |
| Trên BBT | số ghi ở cột $\pm\infty$ | vạch kép **và** có $\pm\infty$ bên cạnh | không đọc trực tiếp |
| Cách tìm nhanh | so bậc tử – mẫu | nghiệm của mẫu **mà tử khác 0** | chia đa thức, lấy phần thương |

### 2.4. Ba họ hàm số của chương

| | Bậc ba ${y=ax^3+\dots}$ | $\dfrac{ax+b}{cx+d}$ | $\dfrac{ax^2+bx+c}{px+q}$ |
|---|---|---|---|
| Tập xác định | $\mathbb R$ | ${\mathbb R\setminus\left\{-\frac dc\right\}}$ | ${\mathbb R\setminus\left\{-\frac qp\right\}}$ |
| Số cực trị | 0 hoặc 2 | **0** | 0 hoặc 2 |
| Tiệm cận | không có | TCĐ $x=-\frac dc$, TCN $y=\frac ac$ | TCĐ $x=-\frac qp$, TCX (phần thương) |
| Tâm đối xứng | hoành độ $-\frac{b}{3a}$ (nghiệm $y''=0$) | giao hai tiệm cận | giao TCĐ và TCX |
| Đơn điệu | có thể trên cả $\mathbb R$ | chỉ trên **từng** khoảng | chỉ trên **từng** khoảng |

### 2.5. Những cặp dễ nhầm trong bài toán thực tế

| Cặp | Phân biệt |
|---|---|
| Tốc độ thay đổi **trung bình** – **tức thời** | $\dfrac{f(x_2)-f(x_1)}{x_2-x_1}$ (cả đoạn) – $f'(x_0)$ (tại một thời điểm) |
| **Vận tốc** – **tốc độ** | $v$ có dấu (chiều chuyển động) – $\lvert v\rvert$ luôn không âm |
| **Độ dịch chuyển** – **quãng đường** | $s(t_2)-s(t_1)$ – cộng từng chặng khi vật đổi chiều |
| **Tăng tốc** – **giảm tốc** | $v$, $a$ cùng dấu – $v$, $a$ trái dấu (không phải "$a>0$ là tăng tốc") |
| **Chi phí biên** – **chi phí trung bình** | $C'(x)$ (làm thêm 1 sản phẩm) – $\dfrac{C(x)}{x}$ (chia đều) |
| **Doanh thu** – **lợi nhuận** | $R=x\cdot p$ – $P=R-C$; giá tối ưu của hai hàm này **khác nhau** |
| **Lớn nhất** – **tăng nhanh nhất** | GTLN của $f$ – GTLN của $f'$ (dùng $f''$) |
| **Tiến tới** – **đạt được** | giá trị tiệm cận (dân số tối đa, nồng độ giới hạn) thường **không bao giờ đạt** |

## 3. Lỗi sai hay gặp của cả chương

> [!bay] Bài 1 — đơn điệu và cực trị
> - **1.** **Đọc khoảng đơn điệu theo dòng $y$** của BBT. Khoảng luôn là khoảng của $x$.
> - **2.** **Gộp hai khoảng bằng $\cup$**, hoặc kết luận "$y=\frac{2x-1}{x+1}$ đồng biến trên $\mathbb R\setminus\{-1\}$". Chỉ được nói "trên **từng** khoảng".
> - **3.** **"$f'(x_0)=0$ thì $x_0$ là cực trị"** — sai với $y=x^3$ tại $0$. Ngược lại, $y=\lvert x\rvert$ **không có đạo hàm** tại $0$ mà vẫn đạt cực tiểu ở đó.
> - **4.** **"$f$ đồng biến trên $K$ khi và chỉ khi $f'>0$ trên $K$"** — sai chiều "chỉ khi" (lại là $y=x^3$). Đúng: $f'\ge0$ và chỉ bằng $0$ tại hữu hạn điểm.
> - **5.** **Đếm tất cả nghiệm của $f'$** là số cực trị — quên rằng nghiệm bội chẵn (đồ thị $f'$ chạm trục) không làm $f'$ đổi dấu.

> [!bay] Bài 2 — GTLN, GTNN
> - **6.** **Quên hai đầu mút**, hoặc **giữ nghiệm nằm ngoài đoạn**.
> - **7.** **Coi giới hạn là giá trị đạt được**: số ghi ở cột $+\infty$ của BBT, hay giá trị tiệm cận, không phải là GTLN/GTNN.
> - **8.** **Trả lời $x_0$ khi đề hỏi giá trị** (hoặc ngược lại).

> [!bay] Bài 3 — tiệm cận
> - **9.** **"Mẫu bằng 0 là có tiệm cận đứng"** — phải thử tử, rút gọn. Còn một bẫy ngược lại (giống SGK Bài tập 1.37): BBT có **vạch kép** tại $x_0$ nhưng **cả hai** giới hạn một bên đều là **số hữu hạn** (ví dụ hàm số đi từ $3$ xuống $-1$ ở bên trái, rồi bắt đầu lại từ $5$ ở bên phải) thì $x=x_0$ **không** là tiệm cận đứng.
> - **10.** **Quên tách hai phía khi có căn**: $\sqrt{x^2}=\lvert x\rvert$, nên $x\to-\infty$ thường cho thêm một tiệm cận ngang khác.
> - **11.** **Đếm hai lần** một tiệm cận ngang khi $\lim\limits_{x\to+\infty}f=\lim\limits_{x\to-\infty}f$.

> [!bay] Bài 4 — đồ thị, số nghiệm
> - **12.** **Quên dấu của $a$ đảo chiều** khi suy dấu $b$, $c$ từ $\frac{c}{3a}$, $-\frac{2b}{3a}$.
> - **13.** **Đọc sai phương trình**: $2f(x)-3=0$ là $f(x)=\frac32$, **không** phải $f(x)=3$.
> - **14.** **"Giá trị cực đại luôn lớn hơn giá trị cực tiểu"** — sai với hàm phân thức (hai cực trị ở hai nhánh khác nhau).

> [!bay] Bài 5 — thực tiễn
> - **15.** **Quên điều kiện của ẩn** ($t\ge0$, cạnh dương, số lượng không vượt sức chứa…) — nghiệm của $f'=0$ nằm ngoài miền thì phải loại, và GTLN dời ra **đầu mút**.
> - **16.** **Làm tròn sớm**: giữ $\sqrt{\ }$, $\pi$, $e$ đến bước cuối.
> - **17.** **Trả lời nhầm đại lượng**: đề hỏi giá bán mà trả lời số lần giảm giá; hỏi quãng đường mà trả lời độ dịch chuyển; hỏi "tăng nhanh nhất **khi nào**" mà trả lời tốc độ.

## 4. Bài tổng hợp

Năm bài dưới đây đều **phối hợp nhiều bài** của chương và bám ba dạng đề tốt nghiệp. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Một hàm số — đủ mọi câu hỏi

> [!vi-du] Ví dụ 1 (Bài 1 + 2 + 3 + 4)
> Cho hàm số $y=f(x)=\dfrac{x^2-2x+5}{x-1}$.
>
> a) Khảo sát sự biến thiên, lập bảng biến thiên; chỉ ra các tiệm cận và tâm đối xứng của đồ thị.
>
> b) Tìm giá trị lớn nhất và giá trị nhỏ nhất của $f(x)$ trên đoạn $[2;\,5]$.
>
> c) Biện luận theo $m$ số nghiệm của phương trình $f(x)=m$.

> [!goi-y] Gợi ý 1
> Chia đa thức trước: $x^2-2x+5=(x-1)^2+4$, nên $y=x-1+\dfrac{4}{x-1}$. Dạng này cho ngay tiệm cận xiên và đạo hàm gọn.

> [!goi-y] Gợi ý 2
> $$y'=1-\frac{4}{(x-1)^2}=\frac{(x+1)(x-3)}{(x-1)^2}.$$
> Nhớ gạch đôi tại $x=1$.

> [!goi-y] Gợi ý 3
> c) Trên nhánh trái ($x<1$), $f$ lấy những giá trị nào? Trên nhánh phải thì sao? Có "khoảng trống" nào trên trục tung mà đồ thị không chạm tới?

> [!loi-giai] Lời giải
> **a)** Tập xác định $\mathbb R\setminus\{1\}$. $y'=0\iff x=-1$ hoặc $x=3$; $y(-1)=\dfrac{8}{-2}=-4$, $y(3)=\dfrac82=4$.
> - $\lim\limits_{x\to1^-}y=-\infty$, $\lim\limits_{x\to1^+}y=+\infty$ → TCĐ $x=1$.
> - $y-(x-1)=\dfrac{4}{x-1}\to0$ khi $x\to\pm\infty$ → TCX $y=x-1$; $\lim\limits_{x\to-\infty}y=-\infty$, $\lim\limits_{x\to+\infty}y=+\infty$ (không có TCN).
>
> $$\footnotesize\begin{array}{c|ccccccccc} x & -\infty & & -1 & & 1 & & 3 & & +\infty \\ \hline y' & & + & 0 & - & \Vert & - & 0 & + & \\ \hline & & & -4 & & \Vert{+\infty} & & & & +\infty \\ y & & \nearrow & & \searrow & \Vert & \searrow & & \nearrow & \\ & -\infty & & & & {-\infty}\Vert & & 4 & & \end{array}$$
>
> Đồng biến trên $(-\infty;\,-1)$ và $(3;\,+\infty)$; nghịch biến trên **từng** khoảng $(-1;\,1)$ và $(1;\,3)$. Cực đại $(-1;\,-4)$, cực tiểu $(3;\,4)$ — giá trị cực đại **nhỏ hơn** giá trị cực tiểu. Tâm đối xứng là giao của TCĐ và TCX: $I(1;\,0)$ (trung điểm của hai điểm cực trị ✓).
>
> **b)** Trong $(2;\,5)$ chỉ có $x=3$. $f(2)=5$; $f(3)=4$; $f(5)=\dfrac{20}{4}=5$. Vậy $\max\limits_{[2;5]}f=5$ (đạt tại **hai** điểm $x=2$ và $x=5$), $\min\limits_{[2;5]}f=f(3)=4$.
>
> **c)** Nhánh trái nhận mọi giá trị $\le-4$, nhánh phải nhận mọi giá trị $\ge4$. Vậy:
> - $m<-4$ hoặc $m>4$: **2 nghiệm**;
> - $m=-4$ hoặc $m=4$: **1 nghiệm** (đường ngang chạm đúng điểm cực trị);
> - $-4<m<4$: **vô nghiệm**.

> [!bay]
> Ở câu b), phương án "GTLN bằng $4$" là cái bẫy của người nhầm cực trị với GTLN: $x=3$ là điểm **cực tiểu** nên cho GTNN, còn GTLN nằm ở **đầu mút**. Ở câu c), đừng nghĩ "$m$ nằm giữa hai cực trị thì 3 nghiệm" như hàm bậc ba — hàm phân thức này có "khoảng trống" $(-4;\,4)$.

### 4.2. Đọc đồ thị của đạo hàm

> [!vi-du] Ví dụ 2 (Bài 1 + 2)
> Hàm số $f(x)$ có đạo hàm liên tục trên $\mathbb R$; đồ thị của $y=f'(x)$ như Hình 2 (cắt trục hoành tại $x=-1$, $x=4$ và tiếp xúc trục hoành tại $x=2$).
>
> a) Tìm các khoảng đồng biến, nghịch biến và các điểm cực trị của $f$.
>
> b) Sắp xếp $f(0)$, $f(2)$, $f(3)$ theo thứ tự tăng dần.
>
> c) Trên đoạn $[0;\,5]$, giá trị lớn nhất của $f$ đạt tại $x$ bằng bao nhiêu? Giá trị nhỏ nhất thì sao?

![Hình 2. Đồ thị của y = f′(x): cắt trục hoành tại x = −1 và x = 4, tiếp xúc trục hoành tại x = 2](h2-do-thi-dao-ham.svg)

> [!goi-y] Gợi ý 1
> Chỉ nhìn **trên hay dưới** trục hoành. Đồ thị $f'$ đi lên hay đi xuống, "đỉnh" ở đâu — không quan trọng.

> [!goi-y] Gợi ý 2
> b) $0$, $2$, $3$ cùng nằm trong một khoảng mà $f$ đồng biến không?

> [!goi-y] Gợi ý 3
> c) Lập BBT của $f$ trên $[0;\,5]$: chỉ có một điểm đổi chiều. GTNN phải so sánh hai đầu mút — đề có cho đủ dữ kiện để so sánh không?

> [!loi-giai] Lời giải
> **a)** $f'<0$ trên $(-\infty;\,-1)$ và $(4;\,+\infty)$; $f'>0$ trên $(-1;\,2)$ và $(2;\,4)$, $f'(2)=0$ chỉ tại một điểm. Vậy $f$ nghịch biến trên $(-\infty;\,-1)$ và $(4;\,+\infty)$, **đồng biến trên cả khoảng** $(-1;\,4)$.
> $f'$ đổi dấu $-\to+$ tại $x=-1$ → **cực tiểu**; $+\to-$ tại $x=4$ → **cực đại**; tại $x=2$ chỉ tiếp xúc → **không** là cực trị. $f$ có đúng **2** điểm cực trị.
>
> **b)** $0<2<3$ đều thuộc $(-1;\,4)$, nơi $f$ đồng biến, nên $f(0)<f(2)<f(3)$.
>
> **c)** Trên $[0;\,5]$: $f$ tăng trên $[0;\,4]$, giảm trên $[4;\,5]$. Vậy GTLN đạt tại $x=4$. GTNN là số nhỏ hơn trong hai số $f(0)$ và $f(5)$ — **chưa so sánh được** chỉ từ dấu của $f'$. (Ở Chương IV, em sẽ dùng **diện tích** giới hạn bởi đồ thị $f'$ để so sánh hai số này.)

> [!bay]
> Đồ thị $f'$ có "đỉnh" gần $x\approx-0{,}15$ và $x\approx3{,}4$ — đó là cực trị của **$f'$**, không phải của $f$. Và điểm tiếp xúc $x=2$ hay bị đếm nhầm thành cực trị thứ ba.

### 4.3. Đúng/Sai về một mô hình thực tế: thấu kính hội tụ

> [!vi-du] Ví dụ 3 (Bài 1 + 2 + 3 + 5 — liên hệ SGK Bài tập 1.44)
> Một thấu kính hội tụ có tiêu cự $12$ cm. Khoảng cách $p$ (cm) từ vật đến thấu kính và khoảng cách $q$ (cm) từ ảnh thật đến thấu kính thỏa mãn $\dfrac1p+\dfrac1q=\dfrac1{12}$, với $p>12$. Xét các mệnh đề:
>
> a) $q=g(p)=\dfrac{12p}{p-12}$.
>
> b) Hàm số $q=g(p)$ nghịch biến trên $(12;\,+\infty)$: đưa vật ra xa thì ảnh tiến lại gần thấu kính.
>
> c) Đồ thị của $q=g(p)$ có tiệm cận ngang là $q=0$.
>
> d) Khoảng cách giữa vật và ảnh, $d=p+q$, nhỏ nhất bằng $48$ cm, khi $p=24$ cm.

> [!goi-y] Gợi ý 1
> a) Quy đồng: $\dfrac1q=\dfrac1{12}-\dfrac1p=\dfrac{p-12}{12p}$.

> [!goi-y] Gợi ý 2
> c) Tính $\lim\limits_{p\to+\infty}\dfrac{12p}{p-12}$ — tỉ số hai hệ số của $p$.

> [!goi-y] Gợi ý 3
> d) Viết lại $\dfrac{12p}{p-12}=12+\dfrac{144}{p-12}$, nên
> $$d=p+12+\frac{144}{p-12}.$$
> Đặt $u=p-12>0$ cho gọn.

> [!loi-giai] Lời giải
> a) **Đúng.** $\dfrac1q=\dfrac{p-12}{12p}\Rightarrow q=\dfrac{12p}{p-12}$.
>
> b) **Đúng.** $g'(p)=\dfrac{12(p-12)-12p}{(p-12)^2}=\dfrac{-144}{(p-12)^2}<0$.
>
> c) **Sai.** $\lim\limits_{p\to+\infty}g(p)=12$: tiệm cận ngang là $q=12$. Ý nghĩa: vật ở rất xa thì ảnh hiện **gần đúng tại tiêu điểm**. Ngoài ra $\lim\limits_{p\to12^+}g(p)=+\infty$: tiệm cận đứng $p=12$ — vật càng sát tiêu điểm thì ảnh càng ra xa vô cùng (Hình 3).
>
> d) **Đúng.** $d=u+\dfrac{144}{u}+24$ với $u=p-12>0$; $d'(u)=1-\dfrac{144}{u^2}=0\iff u=12$, $d'$ đổi dấu $-\to+$. Vậy $d_{\min}=12+12+24=48$ cm khi $p=24$ cm (khi đó $q=24$ cm cũng vậy).

![Hình 3. Đồ thị q = 12p/(p − 12): tiệm cận đứng p = 12, tiệm cận ngang q = 12; điểm (24; 24) cho khoảng cách vật – ảnh nhỏ nhất](h3-thau-kinh.svg)

> [!em-co-biet]
> Kết quả $d_{\min}=4f$ đúng với **mọi** thấu kính hội tụ tiêu cự $f$: muốn thu ảnh thật trên màn thì màn phải cách vật ít nhất bốn lần tiêu cự. Đây là cách các phòng thí nghiệm Vật lí đo nhanh tiêu cự của một thấu kính.

### 4.4. Trả lời ngắn: tốc độ tăng dân số

> [!vi-du] Ví dụ 4 (Bài 1 + 5 — liên hệ SGK Bài tập 1.45)
> Dân số của một quốc gia sau $t$ năm kể từ đầu năm 2024 được ước tính bởi $N(t)=80e^{0{,}015t}$ (triệu người), $0\le t\le50$.
>
> a) Ước tính dân số sau 10 năm (triệu người, làm tròn đến hàng phần mười).
>
> b) Chứng tỏ dân số luôn tăng trong giai đoạn đang xét.
>
> c) Tốc độ tăng dân số đạt $1{,}5$ triệu người/năm vào năm nào? Lúc đó dân số khoảng bao nhiêu?

> [!goi-y] Gợi ý 1
> $\left(e^{kt}\right)'=ke^{kt}$, nên $N'(t)=80\cdot0{,}015\,e^{0{,}015t}=1{,}2\,e^{0{,}015t}$.

> [!goi-y] Gợi ý 2
> c) Giải $1{,}2\,e^{0{,}015t}=1{,}5$ bằng cách lấy $\ln$ hai vế. Để ý $N'(t)=0{,}015\,N(t)$.

> [!loi-giai] Lời giải
> a) $N(10)=80e^{0{,}15}\approx92{,}9$ triệu người.
>
> b) $N'(t)=1{,}2\,e^{0{,}015t}>0$ với mọi $t$ nên $N$ đồng biến trên $[0;\,50]$.
>
> c) $1{,}2\,e^{0{,}015t}=1{,}5\iff e^{0{,}015t}=1{,}25\iff t=\dfrac{\ln1{,}25}{0{,}015}\approx14{,}88$.
> $t\approx14{,}88$ nghĩa là đã qua 14 năm trọn (hết năm 2037) và đang ở năm thứ 15, tức **năm 2038**. Vì $N'=0{,}015N$, lúc đó $N=\dfrac{1{,}5}{0{,}015}=100$ triệu người.

> [!bay]
> Đọc kĩ "kể từ đầu năm" hay "kể từ năm": $t$ là số năm **đã trôi qua**, nên $t\approx14{,}88$ rơi vào năm $2024+14=2038$, không phải $2024+15=2039$. Đề trả lời ngắn thường hỏi thẳng $t$ (làm tròn) để tránh tranh cãi — em cứ trả lời đúng thứ được hỏi.

### 4.5. Trả lời ngắn: kéo cáp điện ra đảo

> [!vi-du] Ví dụ 5 (Bài 2 + 5 — liên hệ SGK Bài tập 1.46)
> Một hòn đảo ở điểm $C$ cách bờ biển $3$ km; điểm gần đảo nhất trên bờ là $B$. Nhà máy điện $A$ nằm trên bờ, cách $B$ $8$ km (bờ biển coi là đường thẳng). Người ta kéo cáp từ $A$ dọc bờ đến một điểm $M$ trên đoạn $AB$, rồi đi dưới biển từ $M$ thẳng tới $C$ (Hình 4). Chi phí lắp cáp dưới biển là $50$ triệu đồng/km, trên đất liền là $40$ triệu đồng/km. Hỏi $M$ cách $A$ bao nhiêu kilômét để tổng chi phí nhỏ nhất? Chi phí nhỏ nhất là bao nhiêu?

![Hình 4. Cáp chạy dọc bờ từ A đến M rồi đi dưới biển từ M đến đảo C; CB = 3 km, AB = 8 km, BM = x](h4-cap-ra-dao.svg)

> [!goi-y] Gợi ý 1
> Đặt $BM=x$ (km), $0\le x\le8$. Tam giác $BMC$ vuông tại $B$: $MC=\sqrt{x^2+9}$; $AM=8-x$.

> [!goi-y] Gợi ý 2
> $f(x)=50\sqrt{x^2+9}+40(8-x)$. Giải $f'(x)=\dfrac{50x}{\sqrt{x^2+9}}-40=0$; bình phương khi hai vế cùng không âm.

> [!goi-y] Gợi ý 3
> Đừng quên so sánh với hai đầu mút $x=0$ (đi biển vuông góc từ $B$) và $x=8$ (đi biển thẳng từ $A$).

> [!loi-giai] Lời giải
> $f'(x)=0\iff 5x=4\sqrt{x^2+9}\iff\begin{cases}x\ge0\\25x^2=16x^2+144\end{cases}\iff x=4$.
>
> $f(0)=150+320=470$; $f(4)=50\cdot5+40\cdot4=410$; $f(8)=50\sqrt{73}\approx427{,}2$ (triệu đồng).
>
> Vậy chọn $M$ với $BM=4$ km, tức $M$ cách $A$ **$4$ km**; chi phí nhỏ nhất là **$410$ triệu đồng**.

> [!meo] Kiểm tra nhanh bằng góc
> Tại điểm tối ưu (nếu nằm **bên trong** đoạn), $\dfrac{x}{\sqrt{x^2+9}}=\dfrac{40}{50}$, tức $\cos\alpha$ bằng **giá trên đất liền chia cho giá dưới biển**, với $\alpha=\widehat{CMB}$. Ở đây $\cos\alpha=0{,}8$, tam giác $BMC$ là tam giác "3 – 4 – 5" ✓. Nếu tính ra $BM$ lớn hơn $AB$ (ví dụ vẫn đảo đó nhưng nhà máy chỉ cách $B$ có $3$ km, trong khi $BM$ tính được là $4$ km) thì $f'<0$ trên cả đoạn, điểm tối ưu nằm ở **đầu mút** $M\equiv A$: kéo cáp dưới biển thẳng từ nhà máy.

## 5. Đối chiếu "Bài tập cuối chương I" (SGK tr. 42–44)

Bảng dưới cho biết mỗi bài tập của SGK kiểm tra điều gì, nên xem lại ở đâu, kèm một **bài tự luyện cùng dạng** (số liệu khác). Làm xong, mở đáp số bên dưới để tự chấm.

| SGK | Kiểm tra | Xem lại | Bài tự luyện cùng dạng |
|---|---|---|---|
| 1.30 | Chiều đúng của định lí "dấu $f'$ ⇒ đơn điệu" | Bài 1 mục 1.2 | (T1) Đúng hay sai: nếu $f$ đồng biến trên $(a;b)$ thì $f'(x)>0$ với mọi $x\in(a;b)$? |
| 1.31 | Hàm nghịch biến trên $\mathbb R$ | Bài 1, mẹo bậc ba | (T2) $y=-x^3+2x^2-3x+1$ có nghịch biến trên $\mathbb R$ không? |
| 1.32 | Hàm có / không có cực trị | Bài 1 mục 2.2 | (T3) Trong $y=x^3+x$, $y=\lvert x+2\rvert$, $y=\frac{x-1}{x+3}$, hàm nào có cực trị? |
| 1.33 | Cực trị hàm chứa $\ln$ | Bài 1 | (T4) Tìm giá trị cực đại của $y=\frac{\ln x}{x}$. |
| 1.34 | GTLN trên đoạn, hàm chứa $e^x$ | Bài 2 mục 2 | (T5) GTLN, GTNN của $y=(x+1)e^{-x}$ trên $[-2;\,1]$. |
| 1.35, 1.37 | Đọc tiệm cận từ giới hạn, BBT | Bài 3 mục 4; lỗi số 9 ở trên | Làm câu đọc BBT trong phần Luyện tập của bài này. |
| 1.36 | Tiệm cận xiên | Bài 3 mục 3 | (T6) Tiệm cận xiên của $y=\frac{2x^2+3x-1}{x+1}$. |
| 1.38, 1.39 | Nhận dạng hàm từ đồ thị | Bài 4, Dạng 1 | (T7) Hàm $y=\frac{x^2+ax+b}{x+1}$ có TCX $y=x-1$ và đồ thị cắt $Oy$ tại $(0;\,-2)$. Tìm $a$, $b$. |
| 1.40 | Chiều biến thiên, cực trị | Bài 1 | (T8) $y=-x^3+3x^2-3x+4$ và $y=-x^4+4x^2-1$. |
| 1.41 | GTLN, GTNN trên nửa khoảng; hàm căn | Bài 2 | (T9) $y=\frac{x-2}{x+1}$ trên $[0;\,+\infty)$; $y=\sqrt{3-2x-x^2}$. |
| 1.42 | Tìm các tiệm cận | Bài 3 | (T10) $y=\frac{5x+1}{2x-4}$ và $y=\frac{x^2-3x}{2x+2}$. |
| 1.43 | Khảo sát và vẽ đồ thị | Bài 4; Ví dụ 1 ở trên | Khảo sát lại Ví dụ 1 và tự vẽ đồ thị. |
| 1.44 | Mô hình thấu kính | Bài 3, Bài 5 | Ví dụ 3 ở trên. |
| 1.45 | Tốc độ tăng dân số | Bài 5 mục 1 | Ví dụ 4 ở trên. |
| 1.46 | Tối ưu chi phí kéo cáp | Bài 5 mục 2.2 | Ví dụ 5 ở trên. |

> [!loi-giai] Đáp số bài tự luyện T1–T10
> - **T1.** Sai: $y=x^3$ đồng biến trên $\mathbb R$ nhưng $y'(0)=0$.
> - **T2.** Có: $y'=-3x^2+4x-3$ có $\Delta'=4-9<0$ và hệ số $-3<0$, nên $y'<0$ với mọi $x$.
> - **T3.** Chỉ $y=\lvert x+2\rvert$ (cực tiểu tại $x=-2$). $y=x^3+x$ có $y'=3x^2+1>0$; hàm phân thức bậc nhất không có cực trị.
> - **T4.** $y'=\frac{1-\ln x}{x^2}$ đổi dấu $+\to-$ tại $x=e$: giá trị cực đại $\frac1e$.
> - **T5.** $y'=-xe^{-x}$; $y(-2)=-e^2$, $y(0)=1$, $y(1)=\frac2e$. GTLN $=1$, GTNN $=-e^2$.
> - **T6.** $2x^2+3x-1=(x+1)(2x+1)-2$ → TCX $y=2x+1$ (và TCĐ $x=-1$).
> - **T7.** $x^2+ax+b=(x+1)(x-1)+r$ cho $a=0$; $y(0)=b=-2$. Hàm số $y=\frac{x^2-2}{x+1}$.
> - **T8.** $y'=-3(x-1)^2\le0$: nghịch biến trên $\mathbb R$, không có cực trị. Hàm thứ hai: cực đại tại $x=\pm\sqrt2$ ($y_{\text{CĐ}}=3$), cực tiểu tại $x=0$ ($y_{\text{CT}}=-1$).
> - **T9.** $y'=\frac{3}{(x+1)^2}>0$: $\min=y(0)=-2$, **không có** GTLN ($y\to1$ nhưng không đạt). Hàm căn: tập xác định $[-3;\,1]$, $\max=y(-1)=2$, $\min=y(-3)=y(1)=0$.
> - **T10.** TCĐ $x=2$, TCN $y=\frac52$. Hàm thứ hai: $x^2-3x=(2x+2)\left(\frac x2-2\right)+4$ → TCX $y=\frac x2-2$, TCĐ $x=-1$.

## Tóm tắt — danh sách kiểm tra trước giờ thi

| Khi gặp | Nhớ ngay |
|---|---|
| Công thức $f$ | Tập xác định → $f'$ → nghiệm, chỗ không xác định → BBT |
| BBT / đồ thị $f$ | Khoảng đọc theo $x$; cực trị = mũi tên đổi chiều; tiệm cận ở hai đầu và vạch kép (có $\pm\infty$) |
| Công thức / đồ thị $f'$ | Chỉ xét **dấu**: cắt trục là cực trị, chạm trục thì không |
| GTLN, GTNN | Đoạn: so sánh điểm tới hạn + 2 đầu mút. Khoảng: BBT, giới hạn không phải giá trị |
| Tiệm cận | Mẫu bằng 0 → thử tử; có căn → tách hai phía; xiên → chia đa thức |
| Đồ thị, số nghiệm | Ba họ hàm và tâm đối xứng; cô lập $m$, trượt đường ngang |
| Thực tiễn | Ẩn + đơn vị + điều kiện → hàm một biến → khảo sát → trả lời đúng đại lượng, làm tròn ở bước cuối |

**Sơ đồ một dòng:** *đạo hàm và giới hạn → bảng biến thiên → đơn điệu, cực trị, GTLN – GTNN, tiệm cận, số nghiệm → bài toán thực tế.*
