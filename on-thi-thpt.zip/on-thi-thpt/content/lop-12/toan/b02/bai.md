---
title: Giá trị lớn nhất và giá trị nhỏ nhất của hàm số
thoi-gian: 45 phút
muc-tieu:
  - Hiểu đúng định nghĩa giá trị lớn nhất, giá trị nhỏ nhất của hàm số trên một tập D (hai điều kiện, không được thiếu điều kiện nào)
  - Đọc được giá trị lớn nhất, giá trị nhỏ nhất từ đồ thị và từ bảng biến thiên
  - Tìm giá trị lớn nhất, giá trị nhỏ nhất trên một khoảng bằng bảng biến thiên
  - Tìm giá trị lớn nhất, giá trị nhỏ nhất trên một đoạn theo quy tắc ba bước dùng đạo hàm
  - Giải bài toán tối ưu thực tế (thể tích, diện tích, chi phí, lợi nhuận, tốc độ thay đổi) bằng cách đặt ẩn, lập hàm và khảo sát
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. $M=\max\limits_D f(x)$ khi **cả hai** điều kiện xảy ra: $f(x)\le M$ với mọi $x\in D$, **và** có $x_0\in D$ để $f(x_0)=M$. Giá trị nhỏ nhất tương tự với dấu $\ge$.
> 2. Trên **khoảng** (hay tập bất kì): lập **bảng biến thiên** rồi đọc. Có thể **không có** GTLN hoặc GTNN.
> 3. Trên **đoạn** $[a;b]$, hàm liên tục **luôn có** cả GTLN và GTNN. Quy tắc: tìm các điểm trong $(a;b)$ mà $f'=0$ hoặc $f'$ không tồn tại → tính $f$ tại các điểm đó **và** tại $a$, $b$ → so sánh.
> 4. GTLN **không nhất thiết** là giá trị cực đại; nó có thể đạt ở **đầu mút**.
> 5. Bài toán thực tế: đặt ẩn (có đơn vị) → tìm điều kiện của ẩn → lập hàm một biến → khảo sát → trả lời đúng câu hỏi.

Ở Bài 1, em đã biết dùng đạo hàm để xem hàm số tăng ở đâu, giảm ở đâu và có cực trị tại điểm nào. Bài này dùng lại đúng công cụ đó để trả lời một câu hỏi rất "đời thường": **lớn nhất là bao nhiêu, nhỏ nhất là bao nhiêu?** Cắt bìa thế nào để hộp đựng được nhiều nhất, bán giá bao nhiêu để lãi nhiều nhất, làm lon thế nào để tốn ít vật liệu nhất… đều là bài toán tìm giá trị lớn nhất hoặc nhỏ nhất của một hàm số.

> [!nen-tang] Đạo hàm cần nhớ (lớp 11)
> - $(x^n)'=nx^{n-1}$; $\left(\dfrac1x\right)'=-\dfrac1{x^2}$; $(\sqrt x)'=\dfrac1{2\sqrt x}$; $(\sqrt u)'=\dfrac{u'}{2\sqrt u}$.
> - $(e^x)'=e^x$; $(\ln x)'=\dfrac1x$; $(\sin x)'=\cos x$; $(\cos x)'=-\sin x$.
> - $(uv)'=u'v+uv'$; $\left(\dfrac uv\right)'=\dfrac{u'v-uv'}{v^2}$.
> - Dấu của $f'$ cho chiều biến thiên: $f'>0$ trên một khoảng thì $f$ đồng biến, $f'<0$ thì nghịch biến (xem Bài 1).

## 1. Định nghĩa

### 1.1. Nhìn trên đồ thị trước

Hãy nhìn Hình 1. Đồ thị của hàm số $y=f(x)$ được vẽ trên đoạn $[-2;4]$. Nếu coi đồ thị là một con đường đi qua đồi núi thì:
- **giá trị lớn nhất** là độ cao của **điểm cao nhất** trên cả đoạn đường;
- **giá trị nhỏ nhất** là độ cao của **điểm thấp nhất**.

![Hình 1. Trên đoạn [−2; 4], điểm cao nhất nằm ở đầu mút x = 4, không phải ở điểm cực đại](h1-gtln-gtnn-doan.svg)

Điểm cực đại $(0;3)$ chỉ là "đỉnh của một ngọn đồi nhỏ": nó cao hơn các điểm **ở gần nó**, nhưng cuối đường, tại $x=4$, đồ thị lên tới độ cao $5$. Vì vậy trên đoạn $[-2;4]$ giá trị lớn nhất là $5$, chứ không phải $3$.

### 1.2. Định nghĩa chính xác

> [!ghi-nho] Định nghĩa (SGK tr. 15)
> Cho hàm số $y=f(x)$ xác định trên tập $D$.
> - Số $M$ là **giá trị lớn nhất** (GTLN) của hàm số trên $D$ nếu $f(x)\le M$ với mọi $x\in D$ **và** tồn tại $x_0\in D$ sao cho $f(x_0)=M$. Kí hiệu $M=\max\limits_{x\in D}f(x)$ hay $M=\max\limits_D f(x)$.
> - Số $m$ là **giá trị nhỏ nhất** (GTNN) của hàm số trên $D$ nếu $f(x)\ge m$ với mọi $x\in D$ **và** tồn tại $x_0\in D$ sao cho $f(x_0)=m$. Kí hiệu $m=\min\limits_{x\in D}f(x)$ hay $m=\min\limits_D f(x)$.

**Vì sao cần đủ hai điều kiện?**
- Chỉ có "$f(x)\le M$ với mọi $x$" thì chưa đủ: với hàm trong Hình 1, cả $100$ cũng thỏa $f(x)\le 100$, nhưng $100$ không phải GTLN. Điều kiện thứ hai — **có điểm thật sự đạt tới $M$** — mới "ép" $M$ thành số nhỏ nhất trong các chặn trên.
- Chỉ có "có $x_0$ để $f(x_0)=M$" thì cũng chưa đủ: $f(0)=3$ nhưng $3$ không phải GTLN vì còn có giá trị lớn hơn.

> [!ghi-nho] Chú ý (SGK tr. 16)
> - Nói "GTLN, GTNN của hàm số" mà **không nói trên tập nào** thì hiểu là trên **tập xác định** của hàm số.
> - Thực hành hay viết gọn $\max\limits_D y$, $\min\limits_D y$.
> - Muốn tìm GTLN, GTNN trên một tập $D$, cách chung là **lập bảng biến thiên trên $D$** rồi đọc.

> [!vi-du] Ví dụ 1 (đọc từ đồ thị)
> Dựa vào Hình 1, tìm giá trị lớn nhất, giá trị nhỏ nhất của $f(x)$:
>
> a) trên đoạn $[-2;4]$;
>
> b) trên đoạn $[-2;2]$.

> [!goi-y] Gợi ý 1
> Tìm điểm cao nhất, thấp nhất của **phần đồ thị nằm trong đoạn** đang xét — bỏ qua phần ngoài đoạn.

> [!goi-y] Gợi ý 2
> b) Phần đồ thị ứng với $x\in[-2;2]$ không còn chứa điểm $(4;5)$.

> [!loi-giai] Lời giải
> a) Điểm cao nhất là $(4;5)$, điểm thấp nhất là $(2;-2)$. Vậy $\max\limits_{[-2;4]}f(x)=f(4)=5$, $\min\limits_{[-2;4]}f(x)=f(2)=-2$.
>
> b) Trên $[-2;2]$, điểm cao nhất là điểm cực đại $(0;3)$, điểm thấp nhất vẫn là $(2;-2)$. Vậy $\max\limits_{[-2;2]}f(x)=f(0)=3$, $\min\limits_{[-2;2]}f(x)=f(2)=-2$.
>
> Nhận xét: **cùng một hàm số, đổi tập xét thì GTLN, GTNN có thể đổi**.

> [!bay] Phân biệt cực trị và GTLN, GTNN
> - **Cực đại** là khái niệm **địa phương** (so với các điểm lân cận); **GTLN** là khái niệm **toàn cục** (so với **mọi** điểm của $D$).
> - Hàm số có thể có nhiều cực đại, nhưng GTLN (nếu có) chỉ là **một số**; số đó có thể đạt tại nhiều điểm $x_0$ khác nhau.
> - Câu hỏi "GTLN **bằng bao nhiêu**" (hỏi giá trị $M$) khác câu hỏi "GTLN **đạt tại** $x$ bằng bao nhiêu" (hỏi $x_0$). Đề thi rất hay đặt hai số này làm phương án nhiễu cho nhau.

### 1.3. Tìm GTLN, GTNN bằng định nghĩa hoặc bảng biến thiên

> [!vi-du] Ví dụ 2
> Tìm giá trị lớn nhất và giá trị nhỏ nhất của hàm số $y=\sqrt{8+2x-x^2}$.

> [!goi-y] Gợi ý 1
> Đề không nói "trên tập nào" → xét trên **tập xác định**. Điều kiện: $8+2x-x^2\ge 0$.

> [!goi-y] Gợi ý 2
> Biểu thức dưới căn là một tam thức bậc hai có đỉnh tại $x=1$. Hoặc tính $y'$ rồi lập bảng biến thiên.

> [!loi-giai] Lời giải
> **Tập xác định:** $8+2x-x^2\ge0\iff x^2-2x-8\le0\iff -2\le x\le4$, tức $D=[-2;4]$.
>
> **Cách 1 (đánh giá trực tiếp).** Ta có $8+2x-x^2=9-(x-1)^2$, nên $0\le 8+2x-x^2\le 9$ trên $D$. Suy ra $0\le y\le 3$.
> - $y=3\iff x=1$, nên $\max y=y(1)=3$.
> - $y=0\iff x=-2$ hoặc $x=4$, nên $\min y=y(-2)=y(4)=0$.
>
> **Cách 2 (bảng biến thiên).** Với $x\in(-2;4)$: $y'=\dfrac{2-2x}{2\sqrt{8+2x-x^2}}=\dfrac{1-x}{\sqrt{8+2x-x^2}}$; $y'=0\iff x=1$.
>
> | $x$ | $-2$ | | $1$ | | $4$ |
> |:-:|:-:|:-:|:-:|:-:|:-:|
> | $y'$ | | $+$ | $0$ | $-$ | |
> | $y$ | $0$ | $\nearrow$ | $3$ | $\searrow$ | $0$ |
>
> Từ bảng: $\max\limits_{[-2;4]}y=y(1)=3$; $\min\limits_{[-2;4]}y=y(-2)=y(4)=0$.

Khi xét trên một **khoảng** (không chứa đầu mút), hàm số có thể tăng mãi hoặc tiến sát một số mà **không bao giờ chạm tới**. Lúc đó GTLN hoặc GTNN **không tồn tại**. Bảng biến thiên (có ghi giới hạn ở hai đầu) giúp em thấy ngay điều này.

> [!vi-du] Ví dụ 3 (trên một khoảng)
> Tìm giá trị lớn nhất và giá trị nhỏ nhất (nếu có) của hàm số $y=x+\dfrac4x$ trên khoảng $(0;+\infty)$.

> [!goi-y] Gợi ý 1
> $y'=1-\dfrac{4}{x^2}$. Chỉ lấy nghiệm thuộc $(0;+\infty)$.

> [!goi-y] Gợi ý 2
> Hai đầu khoảng không thuộc tập xét, nên thay vì tính giá trị tại đó, hãy tính **giới hạn** $\lim\limits_{x\to0^+}y$ và $\lim\limits_{x\to+\infty}y$.

> [!loi-giai] Lời giải
> $y'=1-\dfrac4{x^2}=\dfrac{x^2-4}{x^2}$; trên $(0;+\infty)$: $y'=0\iff x=2$ (loại $x=-2$).
>
> $\lim\limits_{x\to0^+}\left(x+\dfrac4x\right)=+\infty$, $\lim\limits_{x\to+\infty}\left(x+\dfrac4x\right)=+\infty$, $y(2)=4$.
>
> | $x$ | $0$ | | $2$ | | $+\infty$ |
> |:-:|:-:|:-:|:-:|:-:|:-:|
> | $y'$ | | $-$ | $0$ | $+$ | |
> | $y$ | $+\infty$ | $\searrow$ | $4$ | $\nearrow$ | $+\infty$ |
>
> Vậy $\min\limits_{(0;+\infty)}y=y(2)=4$; hàm số **không có** giá trị lớn nhất trên $(0;+\infty)$ (vì $y$ lớn tùy ý).

![Hình 2. Đồ thị y = x + 4/x trên (0; +∞): có điểm thấp nhất nhưng không có điểm cao nhất](h2-tren-khoang.svg)

> [!bay] "Tiến sát" không phải là "đạt được"
> Hàm $y=\dfrac1x$ trên $(0;+\infty)$ luôn dương và tiến sát $0$ khi $x\to+\infty$, nhưng **không có** $x$ nào cho $y=0$. Vậy hàm số **không có** GTNN trên khoảng đó — đừng trả lời "GTNN bằng $0$". Nhớ điều kiện thứ hai của định nghĩa: phải **có $x_0$** đạt tới giá trị đó.

> [!meo] Bất đẳng thức Cauchy (AM–GM) để soát nhanh
> Với $a,b\ge0$: $a+b\ge2\sqrt{ab}$, dấu bằng khi $a=b$. Ví dụ 3: $x+\dfrac4x\ge2\sqrt{4}=4$, dấu bằng khi $x=\dfrac4x$, tức $x=2$. Cách này nhanh cho các hàm dạng "$ax+\dfrac bx$" với $x>0$, nhưng cách lập bảng biến thiên dùng được cho **mọi** hàm số.

## 2. Cách tìm giá trị lớn nhất và giá trị nhỏ nhất của hàm số trên một đoạn

### 2.1. Vì sao chỉ cần xét "vài điểm đặc biệt"?

Một hàm số **liên tục trên đoạn** $[a;b]$ (đồ thị là một nét liền, có hai đầu mút) thì **luôn có** điểm cao nhất và điểm thấp nhất. Điểm cao nhất (hoặc thấp nhất) đó chỉ có thể nằm ở một trong hai chỗ:

1. **Ở đầu mút** $a$ hoặc $b$ — như điểm $(4;5)$ ở Hình 1.
2. **Ở bên trong** $(a;b)$. Khi đó nó cao hơn (hoặc thấp hơn) mọi điểm lân cận, tức là một **điểm cực trị**. Theo Bài 1, tại điểm cực trị thì $f'(x_0)=0$ (đỉnh "bằng phẳng", tiếp tuyến nằm ngang) hoặc $f'(x_0)$ **không tồn tại** (đỉnh "nhọn", như đáy chữ V của $y=\lvert x\rvert$).

Vậy ta không cần xét **vô số** điểm của đoạn, chỉ cần so sánh giá trị tại một **danh sách ngắn các ứng viên**. Đó chính là quy tắc sau.

> [!ghi-nho] Quy tắc tìm GTLN, GTNN trên đoạn $[a;b]$ (SGK tr. 18)
> Cho $f$ liên tục trên $[a;b]$, có đạo hàm trên $(a;b)$ (có thể trừ hữu hạn điểm), và $f'(x)=0$ chỉ tại hữu hạn điểm.
> 1. Tìm các điểm $x_1,x_2,\dots,x_n$ **thuộc khoảng** $(a;b)$ mà tại đó $f'(x)=0$ hoặc $f'(x)$ không tồn tại.
> 2. Tính $f(x_1),\dots,f(x_n)$ **và** $f(a)$, $f(b)$.
> 3. Số lớn nhất trong các số trên là $M=\max\limits_{[a;b]}f(x)$; số nhỏ nhất là $m=\min\limits_{[a;b]}f(x)$.

> [!vi-du] Ví dụ 4
> Cho $f(x)=x^3-3x^2-9x+5$. Tìm giá trị lớn nhất, giá trị nhỏ nhất của $f(x)$:
>
> a) trên đoạn $[-2;4]$;
>
> b) trên đoạn $[0;4]$.

> [!goi-y] Gợi ý 1
> $f'(x)=3x^2-6x-9=3(x^2-2x-3)$. Giải $f'(x)=0$.

> [!goi-y] Gợi ý 2
> Ở câu b, nghiệm nào của $f'(x)=0$ **không nằm trong** $(0;4)$ thì bỏ đi.

> [!loi-giai] Lời giải
> $f'(x)=3(x^2-2x-3)=0\iff x=-1$ hoặc $x=3$.
>
> a) Cả $-1$ và $3$ đều thuộc $(-2;4)$. Tính: $f(-2)=3$; $f(-1)=10$; $f(3)=-22$; $f(4)=-15$.
> Vậy $\max\limits_{[-2;4]}f(x)=f(-1)=10$, $\min\limits_{[-2;4]}f(x)=f(3)=-22$.
>
> b) Trên $(0;4)$ chỉ có $x=3$ (loại $x=-1$). Tính: $f(0)=5$; $f(3)=-22$; $f(4)=-15$.
> Vậy $\max\limits_{[0;4]}f(x)=f(0)=5$, $\min\limits_{[0;4]}f(x)=f(3)=-22$.

> [!bay] Ba lỗi hay gặp với quy tắc
> 1. **Quên tính tại hai đầu mút** — như câu b, GTLN lại nằm ở đầu mút $x=0$.
> 2. **Không loại nghiệm ngoài đoạn** — nếu giữ $x=-1$ ở câu b, em sẽ trả lời sai GTLN là $10$.
> 3. Quy tắc này **chỉ dùng cho đoạn**. Trên khoảng $(a;b)$ hay $(a;+\infty)$, hàm có thể không có GTLN/GTNN; phải lập bảng biến thiên như Ví dụ 3.

> [!vi-du] Ví dụ 5
> Tìm giá trị lớn nhất và giá trị nhỏ nhất của hàm số $y=x^4-8x^2+3$ trên đoạn $[-1;3]$.

> [!goi-y] Gợi ý 1
> $y'=4x^3-16x=4x(x^2-4)$ có ba nghiệm; nghiệm nào nằm trong $(-1;3)$?

> [!goi-y] Gợi ý 2
> Có 4 giá trị cần so sánh: tại hai đầu mút và tại hai điểm tới hạn còn lại.

> [!loi-giai] Lời giải
> $y'=4x(x^2-4)=0\iff x=0$, $x=2$ hoặc $x=-2$. Trong $(-1;3)$ chỉ có $x=0$ và $x=2$.
>
> $y(-1)=-4$; $y(0)=3$; $y(2)=16-32+3=-13$; $y(3)=81-72+3=12$.
>
> Vậy $\max\limits_{[-1;3]}y=y(3)=12$, $\min\limits_{[-1;3]}y=y(2)=-13$.

Quy tắc dùng được cho mọi loại hàm em đã học: hàm mũ, lôgarit, lượng giác, hàm chứa căn.

> [!vi-du] Ví dụ 6
> Tìm giá trị lớn nhất và giá trị nhỏ nhất của:
>
> a) $y=x-2\ln x$ trên đoạn $[1;e]$;
>
> b) $y=x+2\cos x$ trên đoạn $[0;\pi]$.

> [!goi-y] Gợi ý 1
> a) $y'=1-\dfrac2x$. Kiểm tra nghiệm có thuộc $(1;e)$ không (nhớ $e\approx2{,}718$).

> [!goi-y] Gợi ý 2
> b) $y'=1-2\sin x=0\iff\sin x=\dfrac12$. Trên $(0;\pi)$ có **hai** nghiệm.

> [!loi-giai] Lời giải
> a) $y'=1-\dfrac2x=0\iff x=2\in(1;e)$.
> $y(1)=1$; $y(2)=2-2\ln2\approx0{,}614$; $y(e)=e-2\approx0{,}718$.
> Vậy $\max\limits_{[1;e]}y=y(1)=1$, $\min\limits_{[1;e]}y=y(2)=2-2\ln2$.
>
> b) $y'=1-2\sin x=0\iff\sin x=\dfrac12\iff x=\dfrac\pi6$ hoặc $x=\dfrac{5\pi}6$ (trong $(0;\pi)$).
> $y(0)=2$; $y\left(\dfrac\pi6\right)=\dfrac\pi6+\sqrt3\approx2{,}256$; $y\left(\dfrac{5\pi}6\right)=\dfrac{5\pi}6-\sqrt3\approx0{,}886$; $y(\pi)=\pi-2\approx1{,}142$.
> Vậy $\max\limits_{[0;\pi]}y=\dfrac\pi6+\sqrt3$, $\min\limits_{[0;\pi]}y=\dfrac{5\pi}6-\sqrt3$.

> [!bay] Lượng giác: dùng radian
> Với $x+2\cos x$, biến $x$ vừa đứng một mình vừa nằm trong $\cos$, nên **bắt buộc** đo bằng radian. Khi bấm máy kiểm tra, chuyển máy sang chế độ **radian (R)**; để ở độ (D) sẽ ra số sai hoàn toàn.

> [!meo] Hai mẹo tiết kiệm thời gian
> - Nếu $f'(x)>0$ (hoặc $<0$) trên cả khoảng $(a;b)$ thì $f$ **đơn điệu**, GTLN và GTNN nằm ở **hai đầu mút**. Ví dụ $y=\dfrac{2x+1}{x+1}$ có $y'=\dfrac1{(x+1)^2}>0$, nên trên $[0;2]$: $\min y=y(0)=1$, $\max y=y(2)=\dfrac53$ — khỏi giải phương trình.
> - Soát lại bằng **chế độ Bảng (Table)** của máy tính cầm tay: nhập $f(x)$, cho $x$ chạy từ $a$ đến $b$ với bước nhỏ, xem cột giá trị lớn nhất, nhỏ nhất nằm quanh đâu. Bảng chỉ cho giá trị **gần đúng** tại các điểm đã chọn, nên dùng để **kiểm tra** chứ không thay cho lời giải.

## 3. Bài toán tối ưu trong thực tế

Đây là phần **rất hay ra** ở câu trả lời ngắn và câu Đúng/Sai. Mọi bài đều đi theo một khuôn:

> [!ghi-nho] Năm bước giải bài toán tối ưu
> 1. **Đặt ẩn** $x$ là một đại lượng thay đổi được (ghi rõ đơn vị). Thường chọn đại lượng mà đề hỏi, hoặc đại lượng giúp viết các kích thước khác dễ nhất.
> 2. **Tìm điều kiện** của $x$ từ ý nghĩa thực tế (độ dài dương, không vượt quá kích thước tấm vật liệu, số lượng không âm…). Bước này cho ta **tập $D$**.
> 3. **Lập hàm** cần tối ưu theo **một** biến $x$. Nếu có hai đại lượng, dùng dữ kiện còn lại (thể tích cho trước, chu vi cho trước…) để rút một đại lượng theo đại lượng kia.
> 4. **Tìm GTLN/GTNN** của hàm trên $D$ (quy tắc đoạn, hoặc bảng biến thiên nếu $D$ là khoảng).
> 5. **Trả lời đúng câu hỏi**: đề hỏi kích thước, giá bán hay giá trị lớn nhất? Đơn vị gì? Làm tròn thế nào?

### 3.1. Thể tích lớn nhất — chiếc hộp không nắp

> [!vi-du] Ví dụ 7
> Từ một tấm bìa hình chữ nhật kích thước $16\text{ cm}\times10\text{ cm}$, người ta cắt bỏ bốn hình vuông bằng nhau ở bốn góc rồi gấp lên thành một chiếc hộp không nắp (Hình 3). Tìm cạnh hình vuông bị cắt để hộp có thể tích lớn nhất, và tính thể tích đó.

![Hình 3. Cắt bốn hình vuông cạnh x ở bốn góc rồi gấp thành hộp không nắp](h3-hop-carton.svg)

> [!goi-y] Gợi ý 1
> Gọi cạnh hình vuông bị cắt là $x$ (cm). Hộp có chiều cao $x$, đáy là hình chữ nhật $(16-2x)\times(10-2x)$. Điều kiện: cạnh ngắn $10-2x$ phải dương.

> [!goi-y] Gợi ý 2
> $V(x)=x(16-2x)(10-2x)=4x^3-52x^2+160x$. Tìm GTLN trên khoảng $(0;5)$ bằng bảng biến thiên.

> [!loi-giai] Lời giải
> Gọi $x$ (cm) là cạnh hình vuông bị cắt. Điều kiện: $x>0$ và $10-2x>0$, tức $0<x<5$.
>
> Thể tích hộp: $V(x)=x(16-2x)(10-2x)=4x^3-52x^2+160x$ (cm³).
>
> $V'(x)=12x^2-104x+160=4(3x^2-26x+40)=4(x-2)(3x-20)$; $V'(x)=0\iff x=2$ (nhận) hoặc $x=\dfrac{20}3$ (loại, vì $>5$).
>
> | $x$ | $0$ | | $2$ | | $5$ |
> |:-:|:-:|:-:|:-:|:-:|:-:|
> | $V'$ | | $+$ | $0$ | $-$ | |
> | $V$ | $0$ | $\nearrow$ | $144$ | $\searrow$ | $0$ |
>
> Vậy cắt hình vuông cạnh $2$ cm thì hộp có thể tích lớn nhất $V(2)=2\cdot12\cdot6=144$ cm³.

> [!bay] Điều kiện của ẩn quyết định nghiệm nào bị loại
> Nếu quên điều kiện $x<5$, em sẽ giữ cả $x=\dfrac{20}3$. Thử lại: khi đó cạnh đáy $10-2x<0$ — vô lí. Trong bài thực tế, **điều kiện của ẩn luôn phải viết ra trước khi đạo hàm**.

SGK giải bài toán cùng dạng với tấm bìa hình vuông cạnh 60 cm ở tr. 17 (Ví dụ 3); em có thể tự làm lại để đối chiếu.

### 3.2. Đọc đúng câu hỏi: giá trị lớn nhất hay tốc độ lớn nhất?

> [!vi-du] Ví dụ 8
> Sau khi uống một liều thuốc, nồng độ thuốc trong máu của một người được mô hình hóa bởi $C(t)=\dfrac{20t}{t^2+4}$ (mg/L), với $t\ge0$ là thời gian tính bằng giờ. Sau bao lâu thì nồng độ thuốc cao nhất, và nồng độ cao nhất là bao nhiêu?

> [!goi-y] Gợi ý 1
> Tập xét là $[0;+\infty)$ — không phải một đoạn, nên lập bảng biến thiên (tính thêm giới hạn khi $t\to+\infty$).

> [!goi-y] Gợi ý 2
> $C'(t)=\dfrac{20(t^2+4)-20t\cdot2t}{(t^2+4)^2}=\dfrac{20(4-t^2)}{(t^2+4)^2}$.

> [!loi-giai] Lời giải
> $C'(t)=\dfrac{20(4-t^2)}{(t^2+4)^2}$; trên $(0;+\infty)$: $C'(t)=0\iff t=2$. $C(0)=0$, $C(2)=\dfrac{40}{8}=5$, $\lim\limits_{t\to+\infty}C(t)=0$.
>
> | $t$ | $0$ | | $2$ | | $+\infty$ |
> |:-:|:-:|:-:|:-:|:-:|:-:|
> | $C'$ | | $+$ | $0$ | $-$ | |
> | $C$ | $0$ | $\nearrow$ | $5$ | $\searrow$ | $0$ |
>
> Sau $2$ giờ nồng độ thuốc cao nhất, bằng $5$ mg/L. Sau đó thuốc được đào thải dần, nồng độ giảm về gần $0$.

Nhiều bài hỏi **"tăng nhanh nhất khi nào"**. Đạo hàm $f'(t)$ là **tốc độ thay đổi** của $f$, nên "tăng nhanh nhất" nghĩa là tìm GTLN **của $f'(t)$** — tức là phải khảo sát **hàm $f'$**, dùng đạo hàm của nó là $f''$.

> [!vi-du] Ví dụ 9
> Số lượt tải một ứng dụng mới (tính bằng nghìn lượt) sau $t$ tháng phát hành được ước lượng bởi $S(t)=-t^3+18t^2$, $0\le t\le12$.
>
> a) Tổng số lượt tải lớn nhất trong 12 tháng đó là bao nhiêu?
>
> b) Tại thời điểm $t$ nào thì số lượt tải tăng nhanh nhất, và tốc độ tăng khi đó là bao nhiêu?

> [!goi-y] Gợi ý 1
> a) $S'(t)=-3t^2+36t=3t(12-t)\ge0$ trên $[0;12]$: $S$ đồng biến.

> [!goi-y] Gợi ý 2
> b) Tốc độ là $v(t)=S'(t)=-3t^2+36t$. Tìm GTLN của $v(t)$ trên $[0;12]$, với $v'(t)=-6t+36$.

> [!loi-giai] Lời giải
> a) $S'(t)=3t(12-t)\ge0$ trên $[0;12]$ nên $S$ đồng biến; GTLN là $S(12)=-1728+2592=864$ (nghìn lượt).
>
> b) $v(t)=-3t^2+36t$, $v'(t)=-6t+36=0\iff t=6$. $v(0)=0$, $v(6)=108$, $v(12)=0$.
> Vậy tại thời điểm $t=6$ (tròn 6 tháng sau khi phát hành) số lượt tải tăng nhanh nhất, với tốc độ $108$ nghìn lượt/tháng.

> [!bay] "Lớn nhất" và "tăng nhanh nhất" khác nhau
> Ở Ví dụ 9, $S$ lớn nhất tại $t=12$, nhưng **tăng nhanh nhất** tại $t=6$. Đề thi hay hỏi câu b và đặt phương án nhiễu là $t=12$ (nhầm sang GTLN của $S$) hoặc $864$. Bài Vận dụng ở SGK tr. 18 (lây lan virus) cũng hỏi đúng kiểu này.

### 3.3. Chi phí nhỏ nhất — chiếc lon hình trụ

> [!vi-du] Ví dụ 10
> Một lon nước hình trụ có nắp, dung tích $330$ cm³. Tìm bán kính đáy $r$ để tốn ít vật liệu nhất (diện tích toàn phần nhỏ nhất). Làm tròn đến hàng phần trăm.

> [!goi-y] Gợi ý 1
> Có hai đại lượng $r$ và $h$. Dùng dung tích $\pi r^2h=330$ để rút $h=\dfrac{330}{\pi r^2}$.

> [!goi-y] Gợi ý 2
> $S=2\pi r^2+2\pi rh=2\pi r^2+\dfrac{660}{r}$ với $r>0$. Đạo hàm, giải $S'(r)=0$.

> [!loi-giai] Lời giải
> Gọi $r$ (cm) là bán kính đáy, $h$ (cm) là chiều cao, $r>0$. Từ $\pi r^2h=330$ có $h=\dfrac{330}{\pi r^2}$.
>
> Diện tích toàn phần: $S(r)=2\pi r^2+2\pi r\cdot\dfrac{330}{\pi r^2}=2\pi r^2+\dfrac{660}{r}$.
>
> $S'(r)=4\pi r-\dfrac{660}{r^2}=\dfrac{4\pi r^3-660}{r^2}$; $S'(r)=0\iff r^3=\dfrac{165}{\pi}\iff r=\sqrt[3]{\dfrac{165}{\pi}}\approx3{,}74$ cm. $S'$ đổi dấu từ âm sang dương tại đó, và $S\to+\infty$ khi $r\to0^+$ hoặc $r\to+\infty$, nên đây là điểm cho $S$ nhỏ nhất.
>
> Khi đó $h=\dfrac{330}{\pi r^2}=2r\approx7{,}49$ cm và $S_{\min}\approx264{,}36$ cm².

> [!em-co-biet] Vì sao lon nước ngọt thật lại "cao gầy" hơn?
> Theo tính toán, lon tốn ít vật liệu nhất khi **chiều cao bằng đường kính** ($h=2r$). Lon thật thường cao hơn nhiều vì nắp và đáy làm bằng vật liệu dày hơn, đắt hơn thân lon (giống SGK Bài tập 1.15 tr. 19: giá vật liệu mặt đáy và mặt bên khác nhau), lại còn phải vừa tay cầm. Đổi hàm chi phí thì điểm tối ưu cũng đổi theo.

> [!ung-dung] Tối ưu ở quanh ta
> - Nhà sản xuất chọn kích thước bao bì để tốn ít vật liệu nhất.
> - Cửa hàng chọn giá bán để lợi nhuận lớn nhất (xem Dạng 3 bên dưới).
> - Bác sĩ, dược sĩ đọc đồ thị nồng độ thuốc để biết lúc thuốc có tác dụng mạnh nhất (Ví dụ 8).
> - Kĩ sư chọn góc, độ dài để quãng đường, thời gian, năng lượng là nhỏ nhất.

## Dạng bài thi hay gặp

### Dạng 1. GTLN, GTNN trên một đoạn (thường là trả lời ngắn)

- **Nhận biết:** "Tìm giá trị lớn nhất $M$ và nhỏ nhất $m$ của hàm số trên đoạn $[a;b]$. Tính $M+m$ (hoặc $M\cdot m$, $M^2+m^2$…)".
- **Phương pháp:** áp dụng quy tắc ba bước ở mục 2. Nếu hàm chứa căn mà đề không cho đoạn, **tập xác định thường chính là đoạn** cần xét.
- **Bẫy:** quên đầu mút; giữ nghiệm ngoài đoạn; tính nhầm giá trị (nên tính hai lần); trả lời $x_0$ thay vì giá trị.

> [!vi-du] Ví dụ 11
> Gọi $M$, $m$ lần lượt là giá trị lớn nhất, giá trị nhỏ nhất của hàm số $y=x+\sqrt{4-x^2}$. Tính $M^2+m^2$.

> [!goi-y] Gợi ý 1
> Tập xác định $D=[-2;2]$ là một đoạn. $y'=1-\dfrac{x}{\sqrt{4-x^2}}$ với $x\in(-2;2)$.

> [!goi-y] Gợi ý 2
> $y'=0\iff\sqrt{4-x^2}=x$. Phương trình này buộc $x\ge0$; bình phương được $x^2=2$.

> [!loi-giai] Lời giải
> $D=[-2;2]$. Với $x\in(-2;2)$: $y'=1-\dfrac{x}{\sqrt{4-x^2}}=0\iff\sqrt{4-x^2}=x\iff\begin{cases}x\ge0\\4-x^2=x^2\end{cases}\iff x=\sqrt2$.
>
> $y(-2)=-2$; $y(2)=2$; $y(\sqrt2)=\sqrt2+\sqrt2=2\sqrt2$.
>
> Vậy $M=2\sqrt2$, $m=-2$ và $M^2+m^2=8+4=12$.

> [!bay]
> Nếu bình phương mà **quên điều kiện $x\ge0$**, em sẽ nhận thêm $x=-\sqrt2$ (cho $y=0$). Con số này không làm sai đáp số ở đây nhưng sẽ làm sai ở những bài khác — luôn đặt điều kiện trước khi bình phương.

### Dạng 2. Đọc GTLN, GTNN từ bảng biến thiên hoặc đồ thị

- **Nhận biết:** đề cho bảng biến thiên hoặc đồ thị của $f$ (hoặc của $f'$), hỏi GTLN/GTNN trên một tập.
- **Phương pháp:**
  - Cho **BBT/đồ thị của $f$**: so sánh giá trị tại các điểm cực trị **thuộc tập xét** và tại đầu mút; với đầu "mở" thì xem **giới hạn** — giới hạn **không được tính** là giá trị đạt được.
  - Cho **đồ thị của $f'$**: phần đồ thị **dưới** trục $Ox$ → $f$ giảm, **trên** trục → $f$ tăng. Từ đó suy ra GTLN/GTNN đạt tại đâu. Điểm $f'$ **chạm** trục mà không đổi dấu thì **không** phải cực trị.
- **Bẫy:** coi giới hạn như giá trị; nhầm đồ thị $f'$ với đồ thị $f$.

> [!vi-du] Ví dụ 12
> a) Hàm số $y=f(x)$ có bảng biến thiên:
>
> | $x$ | $-\infty$ | | $-1$ | | $2$ | | $+\infty$ |
> |:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
> | $f'$ | | $+$ | $0$ | $-$ | $0$ | $+$ | |
> | $f$ | $1$ | $\nearrow$ | $4$ | $\searrow$ | $-3$ | $\nearrow$ | $5$ |
>
> Tìm giá trị lớn nhất và giá trị nhỏ nhất (nếu có) của $f(x)$ trên $\mathbb R$.
>
> b) Hàm số $y=g(x)$ có đạo hàm liên tục trên $\mathbb R$; đồ thị của $y=g'(x)$ trên đoạn $[-1;4]$ như Hình 4. Giá trị nhỏ nhất của $g(x)$ trên $[-1;4]$ đạt tại $x$ bằng bao nhiêu? Giá trị lớn nhất của $g(x)$ trên đoạn $[1;4]$ là giá trị nào?

![Hình 4. Đồ thị của đạo hàm y = g′(x): âm trên (−1; 1), không âm trên (1; 4), chạm trục tại x = 3](h4-do-thi-dao-ham.svg)

> [!goi-y] Gợi ý 1
> a) Số $5$ ở cuối bảng là **giới hạn** khi $x\to+\infty$. Có $x$ nào để $f(x)=5$ không? Có $x$ nào để $f(x)>4$ không?

> [!goi-y] Gợi ý 2
> b) Đọc dấu $g'$: âm trên $(-1;1)$, dương trên $(1;3)$ và $(3;4)$. Tại $x=3$ đồ thị $g'$ chỉ chạm trục.

> [!loi-giai] Lời giải
> a) Trên $(2;+\infty)$, $f$ tăng từ $-3$ và tiến sát $5$, nên $f$ nhận mọi giá trị trong $(-3;5)$, **lớn hơn $4$** ở những chỗ gần $5$, nhưng không bao giờ bằng $5$. Vậy $f$ **không có** GTLN trên $\mathbb R$. Trên $(-\infty;-1)$, $f$ đi từ gần $1$ lên $4$; nên mọi giá trị của $f$ đều $\ge-3$ và $f(2)=-3$. Vậy $\min\limits_{\mathbb R}f(x)=f(2)=-3$.
>
> b) $g'<0$ trên $(-1;1)$ nên $g$ giảm trên $[-1;1]$; $g'\ge0$ trên $(1;4)$ (chỉ bằng $0$ tại $x=3$) nên $g$ tăng trên $[1;4]$. Vậy trên $[-1;4]$, GTNN đạt tại $x=1$. Trên $[1;4]$, $g$ tăng nên GTLN là $g(4)$. (Lưu ý: $x=3$ **không** phải cực trị.)

### Dạng 3. Bài toán tối ưu thực tế (trả lời ngắn hoặc Đúng/Sai)

- **Nhận biết:** hộp, bể, lon, hàng rào, khung cửa, giá bán – số lượng, chi phí – thời gian, quãng đường – vận tốc…
- **Phương pháp:** năm bước ở mục 3. Đặc biệt với bài **giá bán – số lượng**: đặt $x$ là **số lần** tăng/giảm giá, viết **giá mới** và **số lượng mới** theo $x$, rồi lợi nhuận $=$ (giá $-$ chi phí mỗi sản phẩm) $\times$ số lượng.
- **Bẫy:** trả lời $x$ thay cho giá bán (đề hỏi giá bán!); quên trừ chi phí; quên đơn vị nghìn đồng.

> [!vi-du] Ví dụ 13
> Một quán trà sữa bán mỗi ly giá $30$ nghìn đồng thì mỗi ngày bán được $200$ ly. Chủ quán khảo sát thấy: cứ giảm giá $1$ nghìn đồng mỗi ly thì mỗi ngày bán thêm được $20$ ly. Chi phí làm mỗi ly là $12$ nghìn đồng. Quán nên bán giá bao nhiêu để lợi nhuận mỗi ngày lớn nhất?

> [!goi-y] Gợi ý 1
> Gọi $x$ (nghìn đồng) là số tiền giảm mỗi ly, $0\le x\le18$ (giá không thấp hơn chi phí). Giá mới $30-x$, số ly $200+20x$.

> [!goi-y] Gợi ý 2
> Lợi nhuận $P(x)=(30-x-12)(200+20x)=(18-x)(200+20x)$.

> [!loi-giai] Lời giải
> $P(x)=(18-x)(200+20x)=-20x^2+160x+3600$, với $x\in[0;18]$.
>
> $P'(x)=-40x+160=0\iff x=4$. $P(0)=3600$; $P(4)=14\cdot280=3920$; $P(18)=0$.
>
> Lợi nhuận lớn nhất $3\,920$ nghìn đồng/ngày khi giảm $4$ nghìn, tức **giá bán $26$ nghìn đồng** mỗi ly.

### Dạng 4. Đúng/Sai tổng hợp về một hàm số

- **Nhận biết:** cho một hàm cụ thể, bốn ý từ dễ đến khó: đạo hàm/nghiệm → GTLN/GTNN trên một đoạn → trên đoạn khác → biểu thức $M\pm m$ hoặc bài toán có tham số.
- **Phương pháp:** tính $f'$, các nghiệm và **bảng giá trị** một lần, rồi dùng lại cho mọi ý, chỉ đổi danh sách điểm theo từng đoạn.
- **Bẫy:** ý sau đổi đoạn mà em vẫn dùng danh sách điểm của ý trước.

> [!vi-du] Ví dụ 14 (Đúng/Sai)
> Cho hàm số $f(x)=2x^3-3x^2-12x+1$. Xét các mệnh đề:
>
> a) $f'(x)=0\iff x=-1$ hoặc $x=2$.
>
> b) $\max\limits_{[0;3]}f(x)=1$.
>
> c) Giá trị lớn nhất của $f(x)$ trên đoạn $[-2;3]$ là $f(3)$.
>
> d) Trên đoạn $[-2;0]$, $M-m=9$ với $M$, $m$ là GTLN, GTNN của $f(x)$ trên đoạn đó.

> [!goi-y] Gợi ý 1
> $f'(x)=6x^2-6x-12=6(x+1)(x-2)$. Tính sẵn: $f(-2)$, $f(-1)$, $f(0)$, $f(2)$, $f(3)$.

> [!goi-y] Gợi ý 2
> Với mỗi đoạn, chỉ chọn các điểm thuộc đoạn đó.

> [!loi-giai] Lời giải
> Bảng giá trị: $f(-2)=-3$; $f(-1)=8$; $f(0)=1$; $f(2)=-19$; $f(3)=-8$.
>
> a) **Đúng** — $6(x+1)(x-2)=0\iff x=-1$ hoặc $x=2$.
>
> b) **Đúng** — trên $[0;3]$ xét $f(0)=1$, $f(2)=-19$, $f(3)=-8$: lớn nhất là $1$.
>
> c) **Sai** — trên $[-2;3]$ xét cả năm giá trị: lớn nhất là $f(-1)=8$, còn $f(3)=-8$.
>
> d) **Sai** — trên $[-2;0]$ xét $f(-2)=-3$, $f(-1)=8$, $f(0)=1$: $M=8$, $m=-3$, $M-m=11$.

## Tóm tắt

| Tình huống | Cách làm | Ghi nhớ |
|---|---|---|
| Định nghĩa $\max\limits_D f=M$ | $f(x)\le M$ mọi $x\in D$ **và** có $x_0$ với $f(x_0)=M$ | Thiếu một điều kiện là sai |
| Trên đoạn $[a;b]$, $f$ liên tục | Điểm $f'=0$ hoặc không tồn tại trong $(a;b)$ + hai đầu mút → so sánh | Luôn có GTLN, GTNN |
| Trên khoảng / nửa khoảng / $\mathbb R$ | Lập BBT, tính giới hạn ở đầu mở | Có thể không tồn tại |
| $f$ đơn điệu trên $[a;b]$ | GTLN, GTNN ở hai đầu mút | Không cần giải $f'=0$ |
| Cho đồ thị $f'$ | Dưới $Ox$: $f$ giảm; trên $Ox$: $f$ tăng | Chạm mà không đổi dấu: không cực trị |
| Tăng nhanh nhất | Tìm GTLN của $f'$ (dùng $f''$) | Khác với GTLN của $f$ |
| Bài thực tế | Đặt ẩn → điều kiện → lập hàm → khảo sát → trả lời | Điều kiện viết **trước** khi đạo hàm |

**Sơ đồ tư duy khi gặp đề:** tập xét là **đoạn** → quy tắc ba bước; là **khoảng** hoặc **$\mathbb R$** → bảng biến thiên kèm giới hạn; đề cho **hình/bảng** → đọc dấu và so sánh; đề **thực tế** → năm bước, rồi quay về một trong hai cách trên.
