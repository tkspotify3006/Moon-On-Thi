---
title: Công thức tính góc trong không gian
thoi-gian: 50 phút
muc-tieu:
  - Hiểu vì sao góc giữa hai đường thẳng, giữa đường thẳng và mặt phẳng, giữa hai mặt phẳng tính được qua góc giữa các vectơ chỉ phương, vectơ pháp tuyến
  - Tính được góc giữa hai đường thẳng theo vectơ chỉ phương (công thức côsin có trị tuyệt đối)
  - Tính được góc giữa đường thẳng và mặt phẳng theo vectơ chỉ phương và vectơ pháp tuyến (công thức sin)
  - Tính được góc giữa hai mặt phẳng theo hai vectơ pháp tuyến (công thức côsin)
  - Vận dụng vào bài toán thực tiễn (độ nghiêng mái nhà, tấm pin mặt trời, đường cáp trượt, đường bay, lều chóp…)
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mọi góc trong bài đều nằm trong $[0^\circ;\,90^\circ]$, nên công thức luôn có **trị tuyệt đối** ở tử.
> 2. Hai đường thẳng (VTCP $\vec u,\vec u'$): $\cos(\Delta,\Delta')=\lvert\cos(\vec u,\vec u')\rvert$.
> 3. Đường thẳng – mặt phẳng (VTCP $\vec u$, VTPT $\vec n$): $\sin(\Delta,(P))=\lvert\cos(\vec u,\vec n)\rvert$ — chú ý là **sin**.
> 4. Hai mặt phẳng (VTPT $\vec n,\vec n'$): $\cos\big((P),(Q)\big)=\lvert\cos(\vec n,\vec n')\rvert$.
> 5. Mẹo nhớ: **cùng loại vectơ thì côsin, khác loại (VTCP với VTPT) thì sin.**

Ở lớp 11, muốn tính góc giữa hai mặt phẳng em phải dựng giao tuyến, kẻ hai đường vuông góc, rồi giải tam giác — rất dễ "bí" ở bước dựng hình. Với tọa độ $Oxyz$, mọi chuyện gọn hơn nhiều: mỗi đường thẳng có một **vectơ chỉ phương** (Bài 15), mỗi mặt phẳng có một **vectơ pháp tuyến** (Bài 14). Góc giữa các "hình" được quy về **góc giữa hai vectơ**, mà góc giữa hai vectơ thì em đã biết tính bằng tích vô hướng từ Bài 8. Cả bài chỉ có **ba công thức**, khác nhau đúng ở chỗ nào dùng côsin, chỗ nào dùng sin.

> [!nen-tang] Nhắc lại cần dùng (lớp 11 và Bài 8)
> - **Góc giữa hai vectơ** $\vec a=(x;\,y;\,z)$, $\vec b=(x';\,y';\,z')$ khác $\vec 0$: $\cos(\vec a,\vec b)=\dfrac{xx'+yy'+zz'}{\sqrt{x^2+y^2+z^2}\cdot\sqrt{x'^2+y'^2+z'^2}}$, góc này nằm trong $[0^\circ;\,180^\circ]$ (có thể **tù**).
> - **Góc giữa hai đường thẳng** (lớp 11): qua một điểm kẻ hai đường lần lượt song song với chúng, góc **nhỏ** tạo bởi hai đường đó là góc cần tìm. Nó nằm trong $[0^\circ;\,90^\circ]$. Hai đường song song hoặc trùng nhau thì góc bằng $0^\circ$.
> - **Góc giữa đường thẳng và mặt phẳng** (lớp 11): là góc giữa đường thẳng và **hình chiếu** của nó trên mặt phẳng. Nếu đường thẳng vuông góc với mặt phẳng thì góc bằng $90^\circ$. Nếu song song hoặc nằm trong mặt phẳng thì góc bằng $0^\circ$.
> - **Góc giữa hai mặt phẳng** (lớp 11): bằng góc giữa **hai đường thẳng lần lượt vuông góc** với hai mặt phẳng đó. Cũng nằm trong $[0^\circ;\,90^\circ]$.
> - Đọc VTCP của đường thẳng (Bài 15): $\begin{cases}x=x_0+at\\ y=y_0+bt\\ z=z_0+ct\end{cases}$ hay $\dfrac{x-x_0}{a}=\dfrac{y-y_0}{b}=\dfrac{z-z_0}{c}$ đều có VTCP $\vec u=(a;\,b;\,c)$ — **hệ số của $t$**, hoặc **các mẫu số**.
> - Đọc VTPT của mặt phẳng (Bài 14): $Ax+By+Cz+D=0$ có VTPT $\vec n=(A;\,B;\,C)$.

> [!meo] Quy ước làm tròn
> Trong bài này (giống SGK tr. 51), nếu đề không nói gì thêm thì góc tính theo **độ** và làm tròn đến **hàng phần mười**. Nhớ để máy tính ở chế độ **Deg** (độ) trước khi bấm $\cos^{-1}$, $\sin^{-1}$.

## 1. Công thức tính góc giữa hai đường thẳng

### 1.1. Vì sao phải lấy trị tuyệt đối

Cho hai đường thẳng $\Delta$, $\Delta'$ có VTCP $\vec u$, $\vec u'$. Đặt hai vectơ chung gốc. Có hai khả năng:

- Góc $(\vec u,\vec u')\le90^\circ$: góc giữa hai đường thẳng **bằng** góc giữa hai vectơ.
- Góc $(\vec u,\vec u')>90^\circ$ (tù): đường thẳng thì "không có chiều", nên ta được quyền **đảo chiều** một vectơ. Khi đó góc giữa hai đường thẳng là $180^\circ-(\vec u,\vec u')$, tức là **góc bù**.

![Hình 1. Hai VTCP tạo góc tù 120°, nhưng hai đường thẳng chỉ tạo góc 60° — góc bù của 120°](h1-hai-duong-thang.svg)

Vì $\cos(180^\circ-\alpha)=-\cos\alpha$, hai trường hợp gộp lại thành một: côsin của góc giữa hai đường thẳng luôn bằng **giá trị tuyệt đối** của côsin góc giữa hai vectơ.

> [!ghi-nho] Công thức (SGK tr. 50)
> Hai đường thẳng $\Delta$, $\Delta'$ có VTCP $\vec u=(a;\,b;\,c)$, $\vec u'=(a';\,b';\,c')$:
> $$\cos(\Delta,\Delta')=\lvert\cos(\vec u,\vec u')\rvert=\frac{\lvert aa'+bb'+cc'\rvert}{\sqrt{a^2+b^2+c^2}\cdot\sqrt{a'^2+b'^2+c'^2}}.$$

Ba điều đi kèm:

- Công thức **không quan tâm** hai đường thẳng cắt nhau hay chéo nhau. Chéo nhau vẫn dùng được, vì góc chỉ phụ thuộc vào **hướng**.
- Đổi $\vec u$ thành $k\vec u$ ($k\ne0$) thì kết quả không đổi. Vì thế ta được phép **rút gọn VTCP** cho số nhỏ trước khi tính.
- $\Delta\perp\Delta'\iff aa'+bb'+cc'=0$ (côsin bằng $0$, góc $90^\circ$).

> [!vi-du] Ví dụ 1
> Tính góc giữa hai đường thẳng $\Delta:\begin{cases}x=2+t\\ y=-1+2t\\ z=3-2t\end{cases}$ và $\Delta':\dfrac{x-1}{2}=\dfrac{y+3}{1}=\dfrac{z}{-2}$.

> [!goi-y] Gợi ý 1
> VTCP của $\Delta$ là các hệ số của $t$; VTCP của $\Delta'$ là các mẫu số.

> [!goi-y] Gợi ý 2
> $\vec u=(1;\,2;\,-2)$, $\vec u'=(2;\,1;\,-2)$. Hai vectơ này đều có độ dài $3$.

> [!loi-giai] Lời giải
> $\vec u\cdot\vec u'=1\cdot2+2\cdot1+(-2)(-2)=8$; $\lvert\vec u\rvert=\lvert\vec u'\rvert=\sqrt{1+4+4}=3$.
> $\cos(\Delta,\Delta')=\dfrac{\lvert8\rvert}{3\cdot3}=\dfrac89$, nên $(\Delta,\Delta')\approx27{,}3^\circ$.

> [!vi-du] Ví dụ 2 (khi tích vô hướng âm)
> Cho $\Delta:\begin{cases}x=t\\ y=1-t\\ z=2\end{cases}$ và $\Delta':\begin{cases}x=3\\ y=s\\ z=-s\end{cases}$.
>
> a) Tính góc giữa hai vectơ chỉ phương và góc giữa hai đường thẳng.
>
> b) Tính góc giữa $\Delta$ và trục $Oy$.

> [!goi-y] Gợi ý 1
> $z=2$ không có $t$ nên tọa độ thứ ba của $\vec u$ bằng $0$. Tương tự, $x=3$ cho tọa độ thứ nhất của $\vec u'$ bằng $0$.

> [!goi-y] Gợi ý 2
> Trục $Oy$ có VTCP $\vec j=(0;\,1;\,0)$.

> [!loi-giai] Lời giải
> a) $\vec u=(1;\,-1;\,0)$, $\vec u'=(0;\,1;\,-1)$, $\vec u\cdot\vec u'=-1$, $\lvert\vec u\rvert=\lvert\vec u'\rvert=\sqrt2$.
> $\cos(\vec u,\vec u')=\dfrac{-1}{2}$ nên **góc giữa hai vectơ** bằng $120^\circ$.
> Góc giữa hai đường thẳng: $\cos(\Delta,\Delta')=\left\lvert-\frac12\right\rvert=\frac12$, nên $(\Delta,\Delta')=60^\circ$ (đúng như Hình 1).
>
> b) $\cos(\Delta,Oy)=\dfrac{\lvert1\cdot0+(-1)\cdot1+0\cdot0\rvert}{\sqrt2\cdot1}=\dfrac{1}{\sqrt2}$, nên $(\Delta,Oy)=45^\circ$.

> [!bay] 120° hay 60°?
> Đề trắc nghiệm hay đặt cả $120^\circ$ lẫn $60^\circ$ vào các phương án. Góc giữa hai **đường thẳng** không bao giờ quá $90^\circ$, nên $120^\circ$ chắc chắn sai. Nếu đề hỏi góc giữa hai **vectơ** thì mới có thể là $120^\circ$. Đọc kĩ đề hỏi góc giữa **cái gì**.

> [!vi-du] Ví dụ 3 (hai đường chéo nhau trong hình hộp)
> Cho hình hộp chữ nhật $ABCD.A'B'C'D'$ có $AB=3$, $AD=4$, $AA'=2$. Tính góc giữa hai đường thẳng $A'C$ và $BD$.

> [!goi-y] Gợi ý 1
> Gắn hệ trục: gốc tại $A$, tia $Ox$ theo $AB$, tia $Oy$ theo $AD$, tia $Oz$ theo $AA'$. Khi đó $B(3;\,0;\,0)$, $D(0;\,4;\,0)$, $A'(0;\,0;\,2)$, $C(3;\,4;\,0)$.

> [!goi-y] Gợi ý 2
> $\overrightarrow{A'C}=(3;\,4;\,-2)$, $\overrightarrow{BD}=(-3;\,4;\,0)$.

> [!loi-giai] Lời giải
> $\overrightarrow{A'C}\cdot\overrightarrow{BD}=-9+16+0=7$; $\lvert\overrightarrow{A'C}\rvert=\sqrt{29}$, $\lvert\overrightarrow{BD}\rvert=5$.
> $\cos(A'C,BD)=\dfrac{7}{5\sqrt{29}}\approx0{,}26$, nên $(A'C,BD)\approx74{,}9^\circ$.
> Ở lớp 11, muốn tính góc này em phải dựng đường song song với $BD$ đi qua một điểm của $A'C$ — khá vất vả. Với tọa độ, chỉ mất vài dòng.

> [!meo] Bấm máy Casio fx-580VN X
> Cách chắc chắn nhất, máy nào cũng làm được: tự tính phân số $\dfrac{\lvert\vec u\cdot\vec u'\rvert}{\lvert\vec u\rvert\lvert\vec u'\rvert}$, rồi bấm **SHIFT cos** ($\cos^{-1}$) với máy để ở chế độ **Deg**. Máy fx-580VN X còn có chế độ **Vectơ** (trong **MENU**): khai báo hai vectơ rồi dùng các lệnh trong **OPTN** như tích vô hướng, và với một số phiên bản có cả lệnh tính **góc giữa hai vectơ** (tên lệnh và vị trí phím có thể khác nhau giữa các bản máy, em xem hướng dẫn đi kèm máy). Lưu ý: lệnh góc này cho góc giữa hai **vectơ**, trong $[0^\circ;\,180^\circ]$. Nếu máy ra góc tù thì góc giữa hai đường thẳng là $180^\circ$ trừ đi số đó.

## 2. Công thức tính góc giữa đường thẳng và mặt phẳng

### 2.1. Từ côsin chuyển sang sin

Cho đường thẳng $\Delta$ (VTCP $\vec u$) cắt mặt phẳng $(P)$ (VTPT $\vec n$) tại $I$. Gọi $\varphi=(\Delta,(P))$ là góc giữa $\Delta$ và hình chiếu $\Delta_0$ của nó trên $(P)$. Qua $I$ dựng đường thẳng $\Delta'$ có VTCP $\vec n$, tức là đường **vuông góc** với $(P)$.

![Hình 2. Đường thẳng Δ, hình chiếu Δ₀ trên (P) và đường Δ' vuông góc với (P): góc giữa Δ và (P) là φ, góc giữa Δ và Δ' là 90° − φ](h2-duong-mat.svg)

Nhìn Hình 2: $\Delta$, $\Delta_0$, $\Delta'$ cùng nằm trong một mặt phẳng thẳng đứng, trong đó $\Delta'\perp\Delta_0$. Vì vậy góc giữa $\Delta$ và $\Delta'$ **phụ** với $\varphi$:
$$(\Delta,\Delta')=90^\circ-\varphi.$$
Mà góc giữa hai đường thẳng $\Delta,\Delta'$ tính được bằng công thức ở mục 1 (VTCP $\vec u$ và $\vec n$). Dùng $\cos(90^\circ-\varphi)=\sin\varphi$:
$$\sin\varphi=\cos(90^\circ-\varphi)=\cos(\Delta,\Delta')=\lvert\cos(\vec u,\vec n)\rvert.$$

> [!ghi-nho] Công thức (SGK tr. 51)
> Đường thẳng $\Delta$ có VTCP $\vec u=(a;\,b;\,c)$, mặt phẳng $(P)$ có VTPT $\vec n=(A;\,B;\,C)$:
> $$\sin(\Delta,(P))=\lvert\cos(\vec u,\vec n)\rvert=\frac{\lvert aA+bB+cC\rvert}{\sqrt{a^2+b^2+c^2}\cdot\sqrt{A^2+B^2+C^2}}.$$

Kiểm tra lại với hai trường hợp đặc biệt cho chắc:

- $\Delta\perp(P)$: $\vec u$ cùng phương với $\vec n$, côsin của chúng bằng $\pm1$, nên $\sin\varphi=1$, $\varphi=90^\circ$ ✓.
- $\Delta\parallel(P)$ hoặc $\Delta\subset(P)$: $\vec u$ "nằm dọc" mặt phẳng nên $\vec u\perp\vec n$, tích vô hướng bằng $0$, $\sin\varphi=0$, $\varphi=0^\circ$ ✓.

> [!bay] Bẫy số 1 của cả bài: dùng côsin thay vì sin
> Tử số và mẫu số y hệt công thức góc giữa hai đường thẳng, chỉ khác chữ **sin**. Nếu bấm nhầm $\cos^{-1}$ em sẽ ra $90^\circ-\varphi$, và chắc chắn con số đó có mặt trong các phương án nhiễu. Lý do là $\vec n$ **vuông góc** với mặt phẳng, chứ không nằm trong nó: góc giữa $\vec u$ và $\vec n$ là góc với "cột đứng", phải lấy phần còn lại.

> [!vi-du] Ví dụ 4
> a) Tính góc giữa đường thẳng $\Delta:\dfrac{x-1}{1}=\dfrac{y+2}{-1}=\dfrac{z-3}{2}$ và mặt phẳng $(P):2x+y-z+3=0$.
>
> b) Tính góc giữa trục $Oy$ và mặt phẳng $(Q):x+2y+2z-5=0$.

> [!goi-y] Gợi ý 1
> a) $\vec u=(1;\,-1;\,2)$, $\vec n=(2;\,1;\,-1)$. Đây là góc **đường – mặt**, dùng sin.

> [!goi-y] Gợi ý 2
> b) Trục $Oy$ có VTCP $\vec j=(0;\,1;\,0)$.

> [!loi-giai] Lời giải
> a) $\vec u\cdot\vec n=2-1-2=-1$; $\lvert\vec u\rvert=\sqrt6$, $\lvert\vec n\rvert=\sqrt6$.
> $\sin(\Delta,(P))=\dfrac{\lvert-1\rvert}{\sqrt6\cdot\sqrt6}=\dfrac16$, nên $(\Delta,(P))\approx9{,}6^\circ$.
> (Nếu bấm nhầm $\cos^{-1}\frac16$ sẽ ra $80{,}4^\circ$ — sai.)
>
> b) $\sin(Oy,(Q))=\dfrac{\lvert0\cdot1+1\cdot2+0\cdot2\rvert}{1\cdot\sqrt{1+4+4}}=\dfrac23$, nên $(Oy,(Q))\approx41{,}8^\circ$.

### 2.2. Đường thẳng qua hai điểm — bài toán cáp treo

Nhiều bài thực tế không cho phương trình đường thẳng mà cho **hai điểm**. Khi đó VTCP chính là vectơ nối hai điểm. "Mặt đất" thường được chọn là mặt phẳng $(Oxy)$ có VTPT $\vec k=(0;\,0;\,1)$.

> [!vi-du] Ví dụ 5 (đường cáp trượt)
> Chọn hệ $Oxyz$ (đơn vị mét), mặt đất là $(Oxy)$, $Oz$ hướng thẳng lên. Một đường cáp trượt (zipline) căng thẳng từ đỉnh tháp $A(0;\,0;\,20)$ đến cột đích $B(60;\,80;\,5)$.
>
> a) Đường cáp tạo với mặt đất một góc bao nhiêu độ?
>
> b) Để trượt an toàn, người ta muốn góc đó **đúng bằng** $10^\circ$ nhưng giữ nguyên $A$ và vị trí chân cột đích; chỉ thay đổi độ cao điểm $B$ thành $B'(60;\,80;\,h)$ với $h<20$. Tính $h$ (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> $\vec u=\overrightarrow{AB}=(60;\,80;\,-15)$, VTPT mặt đất $\vec k=(0;\,0;\,1)$. Góc đường – mặt nên dùng sin.

> [!goi-y] Gợi ý 2
> b) $\overrightarrow{AB'}=(60;\,80;\,h-20)$. Lập phương trình $\sin10^\circ=\dfrac{20-h}{\sqrt{100^2+(20-h)^2}}$, đặt $X=20-h>0$.

> [!loi-giai] Lời giải
> a) $\sin\varphi=\dfrac{\lvert-15\rvert}{\sqrt{60^2+80^2+15^2}\cdot1}=\dfrac{15}{\sqrt{10225}}\approx0{,}148$, nên $\varphi\approx8{,}5^\circ$.
>
> b) Với $X=20-h>0$: $\dfrac{X}{\sqrt{10000+X^2}}=\sin10^\circ$. Bình phương: $X^2=\sin^2 10^\circ\,(10000+X^2)$, tức $X^2\cos^2 10^\circ=10000\sin^2 10^\circ$, nên $X=100\tan10^\circ\approx17{,}63$.
> (Hình học cho cùng kết quả: cáp là cạnh huyền của tam giác vuông có cạnh nằm ngang $\sqrt{60^2+80^2}=100$ và cạnh đứng $X$, nên $\tan10^\circ=\frac{X}{100}$.)
> Vậy $h\approx20-17{,}63=2{,}37$ m.

> [!meo] Góc với mặt đất — đọc ngay từ tọa độ
> Với mặt đất $(Oxy)$, công thức sin rút gọn thành $\sin\varphi=\dfrac{\lvert c\rvert}{\sqrt{a^2+b^2+c^2}}$: "**độ chênh cao** chia **chiều dài**". Đây chính là định nghĩa sin trong tam giác vuông mà em đã quen — công thức tọa độ và hình học thông thường gặp nhau ở đây.

## 3. Công thức tính góc giữa hai mặt phẳng

### 3.1. Quy về góc giữa hai pháp tuyến

Theo định nghĩa lớp 11, góc giữa hai mặt phẳng $(P)$, $(Q)$ bằng góc giữa hai đường thẳng lần lượt **vuông góc** với chúng. Mà giá của hai VTPT $\vec n$, $\vec n'$ chính là hai đường thẳng như vậy! Do đó góc giữa hai mặt phẳng là góc giữa hai **đường thẳng** có VTCP $\vec n$, $\vec n'$, và ta dùng lại đúng công thức ở mục 1.

![Hình 3. Nhìn dọc theo giao tuyến: hai mặt phẳng hiện thành hai đường, hai VTPT vuông góc với chúng; góc giữa hai VTPT bằng góc giữa hai mặt phẳng hoặc bằng góc bù](h3-hai-mat.svg)

Hình 3 giải thích trực quan: nếu "xoay" mặt $(P)$ đi một góc $\varphi$ để thành $(Q)$, thì VTPT của nó cũng xoay đi đúng $\varphi$. Lại có thể xảy ra trường hợp $\vec n'$ chĩa "ngược phía", khi đó góc giữa hai VTPT là $180^\circ-\varphi$. Trị tuyệt đối xử lí cả hai trường hợp.

> [!ghi-nho] Công thức (SGK tr. 52)
> Hai mặt phẳng $(P)$, $(Q)$ có VTPT $\vec n=(A;\,B;\,C)$, $\vec n'=(A';\,B';\,C')$:
> $$\cos\big((P),(Q)\big)=\lvert\cos(\vec n,\vec n')\rvert=\frac{\lvert AA'+BB'+CC'\rvert}{\sqrt{A^2+B^2+C^2}\cdot\sqrt{A'^2+B'^2+C'^2}}.$$

Hai trường hợp đặc biệt khớp với Bài 14: $(P)\perp(Q)\iff AA'+BB'+CC'=0$ (góc $90^\circ$); $(P)\parallel(Q)$ hoặc trùng nhau thì $\vec n'=k\vec n$, côsin bằng $1$, góc $0^\circ$.

> [!vi-du] Ví dụ 6
> a) Tính góc giữa hai mặt phẳng $(P):2x-y+2z-1=0$ và $(Q):x+2y-2z+3=0$.
>
> b) Tính góc giữa $(P)$ và mặt phẳng tọa độ $(Oyz)$.

> [!goi-y] Gợi ý 1
> a) $\vec n=(2;\,-1;\,2)$, $\vec n'=(1;\,2;\,-2)$, cả hai đều có độ dài $3$.

> [!goi-y] Gợi ý 2
> b) $(Oyz)$ có phương trình $x=0$, VTPT $\vec i=(1;\,0;\,0)$.

> [!loi-giai] Lời giải
> a) $\vec n\cdot\vec n'=2-2-4=-4$. $\cos\big((P),(Q)\big)=\dfrac{\lvert-4\rvert}{3\cdot3}=\dfrac49$, nên $\big((P),(Q)\big)\approx63{,}6^\circ$.
> (Quên trị tuyệt đối sẽ ra $\cos^{-1}\left(-\frac49\right)\approx116{,}4^\circ$ — vượt quá $90^\circ$, sai.)
>
> b) $\cos\big((P),(Oyz)\big)=\dfrac{\lvert2\cdot1\rvert}{3\cdot1}=\dfrac23$, nên góc $\approx48{,}2^\circ$.

> [!vi-du] Ví dụ 7 (mặt phẳng cắt ba trục)
> Cho $A(3;\,0;\,0)$, $B(0;\,4;\,0)$, $C(0;\,0;\,2)$. Tính góc giữa mặt phẳng $(ABC)$ và các mặt phẳng $(OAB)$, $(OAC)$.

> [!goi-y] Gợi ý 1
> Dùng phương trình đoạn chắn (Bài 14): $\dfrac x3+\dfrac y4+\dfrac z2=1$, nhân $12$ để có VTPT nguyên.

> [!goi-y] Gợi ý 2
> $(OAB)$ chính là $(Oxy)$, VTPT $\vec k$; $(OAC)$ chính là $(Oxz)$, VTPT $\vec j$.

> [!loi-giai] Lời giải
> $(ABC):4x+3y+6z-12=0$, VTPT $\vec n=(4;\,3;\,6)$, $\lvert\vec n\rvert=\sqrt{61}$.
> - $\cos\big((ABC),(OAB)\big)=\dfrac{\lvert6\rvert}{\sqrt{61}}\approx0{,}768$, nên góc $\approx39{,}8^\circ$.
> - $\cos\big((ABC),(OAC)\big)=\dfrac{\lvert3\rvert}{\sqrt{61}}\approx0{,}384$, nên góc $\approx67{,}4^\circ$.

> [!meo] Góc giữa mặt phẳng và mặt phẳng tọa độ
> Với $(P):Ax+By+Cz+D=0$:
> - góc với $(Oxy)$: $\cos=\dfrac{\lvert C\rvert}{\sqrt{A^2+B^2+C^2}}$;
> - góc với $(Oxz)$: $\cos=\dfrac{\lvert B\rvert}{\sqrt{A^2+B^2+C^2}}$;
> - góc với $(Oyz)$: $\cos=\dfrac{\lvert A\rvert}{\sqrt{A^2+B^2+C^2}}$.
>
> Hệ số **đi với trục vuông góc** với mặt tọa độ đó ($(Oxy)\perp Oz$ nên lấy hệ số của $z$).

### 3.2. Vận dụng: mái che nghiêng bao nhiêu độ?

Đây là kiểu bài mở đầu của SGK (tr. 50): một tấm mái phẳng được đỡ bởi các cột thẳng đứng cao khác nhau, hỏi mái nghiêng so với mặt sàn bao nhiêu độ. Chìa khóa: **đặt hệ trục sao cho mặt sàn là $(Oxy)$**, đỉnh cột có cao độ $z$ bằng chiều cao cột.

![Hình 4. Mái che A'B'C' đặt trên ba cột thẳng đứng dựng tại ba đỉnh tam giác vuông ABC trên mặt sàn](h4-mai-che.svg)

> [!vi-du] Ví dụ 8
> Một mái che phẳng hình tam giác $A'B'C'$ được đỡ bởi ba cột thẳng đứng $AA'$, $BB'$, $CC'$ cao lần lượt $3{,}2$ m; $2{,}6$ m; $2{,}9$ m. Chân cột $A$, $B$, $C$ trên mặt sàn tạo thành tam giác vuông tại $A$ với $AB=4$ m, $AC=3$ m. Mái che nghiêng so với mặt sàn một góc bao nhiêu độ?

> [!goi-y] Gợi ý 1
> Đặt $A$ ở gốc, $Ox$ theo $AB$, $Oy$ theo $AC$: $A'(0;\,0;\,3{,}2)$, $B'(4;\,0;\,2{,}6)$, $C'(0;\,3;\,2{,}9)$.

> [!goi-y] Gợi ý 2
> VTPT của mái: $\big[\overrightarrow{A'B'},\overrightarrow{A'C'}\big]$. Mặt sàn có VTPT $\vec k$, nên chỉ cần tọa độ thứ ba và độ dài của VTPT mái.

> [!loi-giai] Lời giải
> $\overrightarrow{A'B'}=(4;\,0;\,-0{,}6)$, $\overrightarrow{A'C'}=(0;\,3;\,-0{,}3)$.
> $\big[\overrightarrow{A'B'},\overrightarrow{A'C'}\big]=\big(0\cdot(-0{,}3)-(-0{,}6)\cdot3;\ (-0{,}6)\cdot0-4\cdot(-0{,}3);\ 4\cdot3-0\cdot0\big)=(1{,}8;\,1{,}2;\,12)$.
> $\cos\varphi=\dfrac{12}{\sqrt{1{,}8^2+1{,}2^2+12^2}}=\dfrac{12}{\sqrt{148{,}68}}\approx0{,}984$, nên $\varphi\approx10{,}2^\circ$.

> [!ung-dung] Độ dốc mái và tấm pin mặt trời
> Mái tôn có thể làm khá thoải (thường chỉ khoảng $10^\circ$–$15^\circ$), còn mái ngói phải dốc hơn nhiều (thường khoảng $30^\circ$ trở lên) để nước mưa không thấm ngược qua kẽ ngói. Đây là các con số tham khảo, mỗi loại vật liệu có hướng dẫn riêng. Ở Việt Nam, tấm pin mặt trời thường được đặt nghiêng khoảng $10^\circ$–$20^\circ$ so với mặt đất (gần bằng vĩ độ nơi lắp) để đón nắng tốt trong cả năm. Kĩ sư chỉ cần đo cao độ ba góc tấm pin là tính được góc nghiêng bằng đúng phép tính của Ví dụ 8.

> [!bay] Góc giữa hai mặt phẳng và góc nhị diện
> Ở lớp 11 em đã gặp **góc nhị diện**, có thể **tù** (ví dụ góc giữa hai mặt bên kề nhau của một cái lều chóp). Còn **góc giữa hai mặt phẳng** luôn trong $[0^\circ;\,90^\circ]$, và công thức của bài này cho đúng góc đó. Nếu đề hỏi góc giữa hai mặt phẳng thì không bao giờ trả lời số lớn hơn $90^\circ$.

## Dạng bài thi hay gặp

### Dạng 1. Tính góc từ phương trình: chọn đúng công thức

- **Nhận biết:** "tính góc giữa…", "côsin (sin) của góc giữa… bằng", câu trả lời ngắn "làm tròn đến hàng phần mười của độ".
- **Phương pháp:**
  1. Xác định đề hỏi góc giữa **cặp đối tượng nào**: đường – đường, đường – mặt, mặt – mặt.
  2. Đọc đúng vectơ: đường thẳng lấy VTCP, mặt phẳng lấy VTPT.
  3. Tính phân số: **trị tuyệt đối của tích vô hướng** chia cho **tích hai độ dài**. Đường – mặt thì đó là **sin**, còn lại là **côsin**.
  4. Bấm $\sin^{-1}$ hoặc $\cos^{-1}$ (chế độ Deg) và làm tròn.

| Góc giữa | Hai vectơ dùng | Phân số bằng |
|---|---|---|
| hai đường thẳng | VTCP và VTCP | $\cos$ |
| đường thẳng và mặt phẳng | VTCP và VTPT | $\sin$ |
| hai mặt phẳng | VTPT và VTPT | $\cos$ |

- **Bẫy:** lấy nhầm VTPT của mặt phẳng thành "VTCP" của đường, đọc thiếu số $0$ khi phương trình vắng biến, quên trị tuyệt đối, dùng côsin cho góc đường – mặt.

> [!vi-du] Ví dụ 9
> Tính góc giữa đường thẳng $\Delta:\dfrac{x+1}{2}=\dfrac{y}{-1}=\dfrac{z-2}{2}$ và mặt phẳng $(P):x-2y+2z+5=0$.

> [!goi-y] Gợi ý 1
> Đường – mặt: dùng sin, với $\vec u=(2;\,-1;\,2)$ và $\vec n=(1;\,-2;\,2)$.

> [!goi-y] Gợi ý 2
> Hai vectơ đều có độ dài $3$.

> [!loi-giai] Lời giải
> $\vec u\cdot\vec n=2+2+4=8$. $\sin(\Delta,(P))=\dfrac{8}{3\cdot3}=\dfrac89$, nên $(\Delta,(P))\approx62{,}7^\circ$.
> Phương án nhiễu thường gặp: $27{,}3^\circ$ (bấm $\cos^{-1}\frac89$). Hai số này cộng lại đúng $90^\circ$ — dấu hiệu em vừa nhầm sin với côsin.

### Dạng 2. Góc với trục tọa độ và mặt phẳng tọa độ

- **Nhận biết:** đề có $Ox$, $Oy$, $Oz$, $(Oxy)$, $(Oxz)$, $(Oyz)$, hoặc "mặt đất", "phương thẳng đứng".
- **Phương pháp:** VTCP các trục là $\vec i,\vec j,\vec k$; VTPT các mặt tọa độ $(Oyz),(Oxz),(Oxy)$ cũng lần lượt là $\vec i,\vec j,\vec k$. Thay vào là công thức rút gọn chỉ còn **một** tọa độ trên tử.
- **Bẫy:** $(Oxy)$ có VTPT là $\vec k$ (vuông góc với nó), **không phải** $\vec i$ hay $\vec j$. Và góc giữa $(P)$ với $(Oxy)$ cộng góc giữa trục $Oz$ với $(P)$ luôn bằng $90^\circ$ — hai câu hỏi khác nhau, đáp số khác nhau.

> [!vi-du] Ví dụ 10
> Cho mặt phẳng $(P):2x+3y+6z-12=0$. Tính góc giữa $(P)$ và $(Oxy)$, góc giữa trục $Oz$ và $(P)$, góc giữa trục $Ox$ và $(P)$.

> [!goi-y] Gợi ý 1
> $\lvert\vec n\rvert=\sqrt{4+9+36}=7$.

> [!goi-y] Gợi ý 2
> $(P)$ với $(Oxy)$ là mặt – mặt (côsin, VTPT $\vec k$); $Oz$ và $Ox$ với $(P)$ là đường – mặt (sin, VTCP $\vec k$ và $\vec i$).

> [!loi-giai] Lời giải
> - $\cos\big((P),(Oxy)\big)=\dfrac67$, nên góc $\approx31{,}0^\circ$.
> - $\sin(Oz,(P))=\dfrac67$, nên góc $\approx59{,}0^\circ$. Đúng là $31{,}0^\circ+59{,}0^\circ=90^\circ$.
> - $\sin(Ox,(P))=\dfrac27$, nên góc $\approx16{,}6^\circ$.

### Dạng 3. Điều kiện về góc chứa tham số (thường ở câu Đúng/Sai)

- **Nhận biết:** "tìm $m$ để góc bằng $45^\circ$", "có bao nhiêu giá trị $m$…", "khi $m$ tăng thì góc…".
- **Phương pháp:** viết côsin (sin) theo $m$, cho bằng giá trị đã biết rồi **bình phương hai vế** (hai vế đều không âm) để bỏ trị tuyệt đối và căn. Giải phương trình, nhớ có thể có **hai** nghiệm trái dấu.
- **Bẫy:** quên nghiệm âm khi bình phương $m^2$; nhầm chiều biến thiên — côsin **càng lớn** thì góc **càng nhỏ**.

> [!vi-du] Ví dụ 11 (Đúng/Sai)
> Cho mặt phẳng $(P):3x+4y+mz-1=0$ ($m$ là tham số). Xét các mệnh đề:
>
> a) Khi $m=0$ thì $(P)$ vuông góc với $(Oxy)$.
>
> b) $(P)$ tạo với $(Oxy)$ góc $45^\circ$ khi và chỉ khi $m=5$.
>
> c) Khi $m=5$, trục $Oz$ tạo với $(P)$ góc $45^\circ$.
>
> d) Khi $\lvert m\rvert$ càng lớn thì góc giữa $(P)$ và $(Oxy)$ càng lớn.

> [!goi-y] Gợi ý 1
> $\cos\big((P),(Oxy)\big)=\dfrac{\lvert m\rvert}{\sqrt{25+m^2}}$.

> [!goi-y] Gợi ý 2
> b) Giải $\dfrac{\lvert m\rvert}{\sqrt{25+m^2}}=\dfrac{\sqrt2}{2}$ bằng cách bình phương. d) Viết $\dfrac{\lvert m\rvert}{\sqrt{25+m^2}}=\dfrac{1}{\sqrt{\frac{25}{m^2}+1}}$ (với $m\ne0$).

> [!loi-giai] Lời giải
> a) **Đúng.** $m=0$: $\vec n=(3;\,4;\,0)$, $\vec n\cdot\vec k=0$ nên $(P)\perp(Oxy)$.
>
> b) **Sai.** $\dfrac{m^2}{25+m^2}=\dfrac12\iff m^2=25\iff m=\pm5$. Có **hai** giá trị, không chỉ $m=5$.
>
> c) **Đúng.** $\sin(Oz,(P))=\dfrac{5}{\sqrt{50}}=\dfrac{\sqrt2}{2}$ nên góc bằng $45^\circ$.
>
> d) **Sai.** $\lvert m\rvert$ tăng thì $\frac{25}{m^2}$ giảm, nên côsin **tăng**, góc **giảm** (mặt phẳng càng gần nằm ngang).

### Dạng 4. Bài toán thực tế: lều, mái nhà, đường bay

- **Nhận biết:** đề mô tả vật thật (mái, tấm pin, lều, kim tự tháp, máy bay cất cánh…), có số đo chiều dài, chiều cao.
- **Phương pháp:** (1) chọn hệ trục khéo: mặt đất là $(Oxy)$, trục $Oz$ thẳng đứng, gốc ở tâm hoặc ở một đỉnh đối xứng. (2) Viết tọa độ các điểm cần dùng. (3) Dịch câu hỏi: "nghiêng so với mặt đất" của **đường** dùng sin, của **mặt** dùng côsin. (4) Làm tròn ở bước cuối.
- **Bẫy:** góc giữa hai mặt bên của lều là góc giữa hai mặt phẳng, phải $\le90^\circ$, dù nhìn hình em thấy "góc mở" giữa hai mặt là góc tù.

> [!vi-du] Ví dụ 12 (lều chóp)
> Một chiếc lều có dạng hình chóp tứ giác đều $S.ABCD$, đáy là hình vuông cạnh $4$ m nằm trên mặt đất, đỉnh $S$ cao $3$ m. Tính (làm tròn đến hàng phần mười của độ):
>
> a) góc giữa một mặt bên và mặt đất;
>
> b) góc giữa một cạnh bên và mặt đất;
>
> c) góc giữa hai mặt bên kề nhau $(SAB)$ và $(SBC)$.

> [!goi-y] Gợi ý 1
> Gốc $O$ ở tâm đáy: $S(0;\,0;\,3)$, $A(2;\,-2;\,0)$, $B(2;\,2;\,0)$, $C(-2;\,2;\,0)$.

> [!goi-y] Gợi ý 2
> $\big[\overrightarrow{SA},\overrightarrow{SB}\big]$ cho VTPT của $(SAB)$; tương tự với $(SBC)$.

> [!loi-giai] Lời giải
> $\overrightarrow{SA}=(2;\,-2;\,-3)$, $\overrightarrow{SB}=(2;\,2;\,-3)$, $\overrightarrow{SC}=(-2;\,2;\,-3)$.
> $\big[\overrightarrow{SA},\overrightarrow{SB}\big]=(12;\,0;\,8)$, chọn $\vec n_1=(3;\,0;\,2)$. $\big[\overrightarrow{SB},\overrightarrow{SC}\big]=(0;\,12;\,8)$, chọn $\vec n_2=(0;\,3;\,2)$.
>
> a) mặt đất là $(Oxy)$: $\cos\big((SAB),(Oxy)\big)=\dfrac{2}{\sqrt{13}}$, nên góc $\approx56{,}3^\circ$.
>
> b) $\sin(SA,(Oxy))=\dfrac{3}{\sqrt{4+4+9}}=\dfrac{3}{\sqrt{17}}$, nên góc $\approx46{,}7^\circ$.
>
> c) $\cos\big((SAB),(SBC)\big)=\dfrac{\lvert0+0+4\rvert}{\sqrt{13}\cdot\sqrt{13}}=\dfrac4{13}$, nên góc $\approx72{,}1^\circ$.
> (Góc nhị diện giữa hai mặt bên này, nhìn từ trong lều, là góc tù $180^\circ-72{,}1^\circ=107{,}9^\circ$. Nhưng góc giữa hai **mặt phẳng** là $72{,}1^\circ$.)

> [!em-co-biet]
> Kim tự tháp Kheops (Ai Cập) có mặt bên nghiêng khoảng $52^\circ$ so với mặt đất (SGK tr. 53 có bài tập về kim tự tháp này). Người Ai Cập cổ đo độ dốc bằng đơn vị *seked*: số đơn vị chiều ngang ứng với mỗi đơn vị chiều cao — tức là họ giữ **tỉ số chiều ngang / độ chênh cao** không đổi, một cách khác để "cố định một góc".

## Tóm tắt

Với $\vec u=(a;\,b;\,c)$, $\vec u'=(a';\,b';\,c')$ là VTCP của $\Delta$, $\Delta'$; $\vec n=(A;\,B;\,C)$, $\vec n'=(A';\,B';\,C')$ là VTPT của $(P)$, $(Q)$.

| Góc | Công thức |
|---|---|
| $(\Delta,\Delta')$ | $\cos=\dfrac{\lvert aa'+bb'+cc'\rvert}{\lvert\vec u\rvert\cdot\lvert\vec u'\rvert}$ |
| $(\Delta,(P))$ | $\sin=\dfrac{\lvert aA+bB+cC\rvert}{\lvert\vec u\rvert\cdot\lvert\vec n\rvert}$ |
| $((P),(Q))$ | $\cos=\dfrac{\lvert AA'+BB'+CC'\rvert}{\lvert\vec n\rvert\cdot\lvert\vec n'\rvert}$ |
| Miền giá trị | mọi góc trên đều thuộc $[0^\circ;\,90^\circ]$ |
| Vuông góc | $\Delta\perp\Delta'$: $\vec u\cdot\vec u'=0$; $\Delta\perp(P)$: $\vec u$ cùng phương $\vec n$; $(P)\perp(Q)$: $\vec n\cdot\vec n'=0$ |
| Góc bằng $0^\circ$ | $\Delta\parallel(P)$ hoặc $\Delta\subset(P)$: $\vec u\cdot\vec n=0$ |
| Với $(Oxy)$ | $\cos\big((P),(Oxy)\big)=\dfrac{\lvert C\rvert}{\lvert\vec n\rvert}$; $\sin(\Delta,(Oxy))=\dfrac{\lvert c\rvert}{\lvert\vec u\rvert}$ |

**Sơ đồ làm bài:** đề hỏi góc giữa **gì với gì?** → lấy đúng vectơ (đường: VTCP, mặt: VTPT) → lấy trị tuyệt đối của tích vô hướng chia cho tích hai độ dài → **khác loại thì sin, cùng loại thì côsin** → $\sin^{-1}$ / $\cos^{-1}$ ở chế độ Deg → kiểm tra kết quả $\le90^\circ$.
