---
title: Ôn tập chương IV
thoi-gian: 60 phút
muc-tieu:
  - Hệ thống hóa toàn chương IV — nguyên hàm, tích phân, diện tích và thể tích — và thấy cả chương chỉ xoay quanh một ý: "đạo hàm đi ngược" rồi lấy hiệu $F(b)-F(a)$
  - Phân biệt chắc chắn các cặp dễ nhầm (nguyên hàm – tích phân, $x^\alpha$ – $a^x$, $\int f$ – $\int\lvert f\rvert$ – $\left\lvert\int f\right\rvert$, độ dịch chuyển – quãng đường, diện tích – thể tích…)
  - Nhận ra và tránh các lỗi sai hay gặp nhất của chương trong đề thi
  - Giải được các bài tổng hợp phối hợp nhiều bài (và cả Chương I), theo đúng ba dạng đề tốt nghiệp
  - Tự làm được các dạng của "Bài tập cuối chương IV" (SGK tr. 27–28)
---
> [!ghi-nho] Chương này trong 10 dòng
> 1. **Nguyên hàm là đạo hàm đi ngược**: $F'(x)=f(x)$. Có một nguyên hàm thì có cả họ $\int f(x)\,dx=F(x)+C$ (Bài 11).
> 2. **Bảng nguyên hàm** = bảng đạo hàm đọc từ phải sang trái. Tích, thương, căn, $\tan^2x$… phải **biến đổi về tổng** các hàm có trong bảng trước.
> 3. Đề cho thêm $F(x_0)=c$ (giá trị ban đầu) thì thay vào để tìm **$C$**.
> 4. **Tích phân** $\int_a^b f(x)\,dx=F(b)-F(a)$ là **một số**, không có $+C$ (Bài 12).
> 5. Tính chất: hằng số đưa ra ngoài, tổng/hiệu tách được, **cộng đoạn**, **đổi cận thì đổi dấu**, $\int_a^b k\,dx=k(b-a)$.
> 6. **Lượng thay đổi**: $\int_a^b Q'(x)\,dx=Q(b)-Q(a)$. Riêng vận tốc: $\int v$ là độ dịch chuyển, $\int\lvert v\rvert$ là quãng đường.
> 7. **Giá trị trung bình** của $f$ trên $[a;b]$: $\dfrac{1}{b-a}\int_a^b f(x)\,dx$.
> 8. **Diện tích**: $S=\int_a^b\lvert f(x)-g(x)\rvert\,dx$ — tìm nghiệm của $f=g$, chia đoạn, cộng trị tuyệt đối từng mảnh (Bài 13).
> 9. **Thể tích**: $V=\int_a^b S(x)\,dx$ (mặt cắt bất kì) — riêng khối tròn xoay quanh $Ox$: $V=\pi\int_a^b f^2(x)\,dx$.
> 10. Gặp $\pi$ thì hỏi "mặt cắt có phải hình tròn không?", gặp diện tích thì hỏi "đồ thị có cắt nhau **bên trong** đoạn không?".

Chương IV ngắn (ba bài) nhưng là chương **chắc chắn có mặt** trong đề tốt nghiệp: thường có một câu tìm nguyên hàm hoặc tính tích phân, một câu diện tích hoặc thể tích, và rất hay có một câu trả lời ngắn về chuyển động, lượng nước, lượng thuốc… Bài ôn tập này **không giảng lại** — em đã có Bài 11, 12, 13. Ở đây ta làm ba việc: (1) xếp cả chương lên **một sơ đồ**; (2) tách bạch những thứ **dễ nhầm**; (3) luyện **bài tổng hợp** phối hợp nhiều bài như trong đề thật.

## 1. Bản đồ của chương

### 1.1. Một ý tưởng, ba tầng

Cả chương chỉ dùng **một công cụ của lớp 11 và Chương I: đạo hàm** — nhưng đi theo chiều ngược lại. Mỗi bài dựng thêm một tầng lên tầng trước:

- **Tầng 1 — Bài 11:** từ $f$ tìm $F$ với $F'=f$ (nguyên hàm). Kết quả là một **họ hàm** $F(x)+C$.
- **Tầng 2 — Bài 12:** lấy hiệu $F(b)-F(a)$ (tích phân). Hằng số $C$ triệt tiêu, kết quả là **một số**. Con số này có hai "gương mặt": **diện tích** dưới đồ thị và **lượng thay đổi** của một đại lượng.
- **Tầng 3 — Bài 13:** dùng tích phân để đo hình: **diện tích** hình phẳng (cộng các dải mỏng) và **thể tích** vật thể (cộng các lát mỏng).

![Hình 1. Bản đồ chương IV: đạo hàm đi ngược thành nguyên hàm; hiệu F(b) − F(a) là tích phân; tích phân cho diện tích, thể tích và lượng thay đổi trong thực tế](h1-ban-do-chuong.svg)

**Vì sao phép "lấy hiệu" lại quan trọng đến thế?** Vì nó trả lời cùng lúc nhiều câu hỏi tưởng như khác nhau:

| Em tính $F(b)-F(a)$ với… | Con số đó là | Bài |
|---|---|---|
| $F$ là nguyên hàm của $f\ge0$ | diện tích hình thang cong dưới đồ thị $f$ | Bài 12 |
| $F=s$ (vị trí), $f=v$ (vận tốc) | độ dịch chuyển từ thời điểm $a$ đến $b$ | Bài 12 |
| $F=Q$, $f=Q'$ (tốc độ thay đổi) | lượng $Q$ tăng thêm: nước, thuốc, dân số, lợi nhuận… | Bài 12 |
| $F$ là nguyên hàm của $\lvert f-g\rvert$ | diện tích giữa hai đồ thị | Bài 13 |
| $F$ là nguyên hàm của $S(x)$ hoặc $\pi f^2(x)$ | thể tích vật thể, khối tròn xoay | Bài 13 |

### 1.2. Gặp câu hỏi nào — dùng công cụ nào

| Đề hỏi | Công cụ | Xem lại |
|---|---|---|
| "$\int f(x)\,dx$ bằng", "hàm số nào là một nguyên hàm" | biến đổi về bảng; hoặc **đạo hàm từng phương án** | Bài 11 mục 3 |
| "nguyên hàm thỏa mãn $F(x_0)=c$", "biết $f'$ và $f(x_0)$" | họ nguyên hàm → thay điều kiện tìm $C$ | Bài 11 mục 4 |
| "$\int_a^b f(x)\,dx$ bằng" (hàm cụ thể) | $F(b)-F(a)$, soát bằng máy tính | Bài 12 mục 1.3 |
| "cho $\int f$ trên vài đoạn, tính…" | tính chất: tách, cộng đoạn, đổi cận | Bài 12 mục 2.1 |
| "$\int\lvert\dots\rvert$", "quãng đường khi vật đổi chiều" | xét dấu, chia đoạn | Bài 12 mục 2.2–2.3 |
| "lượng nước/thuốc… trong khoảng thời gian", "trung bình" | $\int_a^b Q'=Q(b)-Q(a)$; $\frac{1}{b-a}\int_a^b f$ | Bài 12 mục 2.4 |
| "diện tích hình phẳng giới hạn bởi…" | giao điểm → chia đoạn → $\int\lvert f-g\rvert$ | Bài 13 mục 1 |
| "thể tích vật thể, mặt cắt là…" | tính $S(x)$ → $\int_a^b S(x)\,dx$ | Bài 13 mục 2.1 |
| "quay … quanh trục $Ox$" | $\pi\int_a^b f^2(x)\,dx$ | Bài 13 mục 2.2 |

> [!meo] Ba câu tự hỏi trước khi đặt bút
> 1. **Đề hỏi một hàm hay một số?** Có $\int$ mà **không có cận** → trả lời là họ hàm, có $+C$. Có cận → một con số.
> 2. **Hàm dưới dấu tích phân có đổi dấu trên đoạn không?** Có ảnh hưởng ngay khi đề hỏi **diện tích** hoặc **quãng đường**.
> 3. **Đại lượng nào là "tốc độ", đại lượng nào là "tổng"?** Vận tốc ↔ quãng đường, tốc độ chảy ↔ lượng nước, chi phí biên ↔ chi phí. Tổng = tích phân của tốc độ.

## 2. Bảng so sánh – phân biệt

### 2.1. Nguyên hàm và tích phân

| | Nguyên hàm $\int f(x)\,dx$ (Bài 11) | Tích phân $\int_a^b f(x)\,dx$ (Bài 12) |
|---|---|---|
| Kết quả là | một **họ hàm số** $F(x)+C$ | **một số** $F(b)-F(a)$ |
| Có $+C$? | có (luôn viết) | không (đã triệt tiêu) |
| Có chứa $x$? | có | không — $\int_a^b f(x)\,dx=\int_a^b f(t)\,dt$ |
| Kiểm tra bằng | đạo hàm vế phải, phải ra $f(x)$ | máy tính (phím $\int_\square^\square$) |
| Điều kiện ban đầu | dùng để **tìm $C$** | không cần — hiệu tự loại $C$ |

Mối nối giữa hai bài là đẳng thức em nên thuộc lòng: nếu $f$ có đạo hàm liên tục thì
$$\int_a^b f'(x)\,dx=f(b)-f(a).$$
Nó cho phép tính **giá trị tại một điểm** từ một tích phân (SGK Bài tập 4.23) — xem Ví dụ 1.

### 2.2. Những cặp "na ná" trong bảng nguyên hàm

| Dễ nhầm | Đúng | Sai hay gặp |
|---|---|---|
| $x^3$ (biến ở **cơ số**) | $\dfrac{x^4}{4}+C$ | — |
| $3^x$ (biến ở **số mũ**) | $\dfrac{3^x}{\ln3}+C$ | $\dfrac{3^{x+1}}{x+1}$, $3^x\ln3$ (đó là đạo hàm) |
| $\dfrac1x$ (mũ $-1$) | $\ln\lvert x\rvert+C$ | $\dfrac{x^0}{0}$ (công thức lũy thừa không dùng được) |
| $\dfrac{1}{x^2}$ (mũ $-2$) | $-\dfrac1x+C$ | $\ln x^2$ |
| $\cos x$ | $\sin x+C$ | $-\sin x$ |
| $\sin x$ | $-\cos x+C$ | $\cos x$ |
| $\dfrac{1}{\cos^2x}$ | $\tan x+C$ | $-\tan x$, $\cot x$ |
| $\dfrac{1}{\sin^2x}$ | $-\cot x+C$ | $\cot x$ |

Cách nhớ dấu: hàm dưới dấu $\int$ có chữ **"sin"** ($\sin x$, $\frac{1}{\sin^2x}$) thì kết quả mang **dấu trừ**. Và với mọi dòng, **đạo hàm vế phải** là cách kiểm tra chắc nhất.

### 2.3. Ba con số: $\int f$, $\left\lvert\int f\right\rvert$ và $\int\lvert f\rvert$

| | $\int_a^b f(x)\,dx$ | $\left\lvert\int_a^b f(x)\,dx\right\rvert$ | $\int_a^b\lvert f(x)\rvert\,dx$ |
|---|---|---|---|
| Dấu | âm, dương hoặc $0$ | không âm | không âm |
| Ý nghĩa | "diện tích có dấu": trên trục cộng, dưới trục trừ | không có ý nghĩa riêng | **diện tích thật** |
| Với vận tốc $v$ | **độ dịch chuyển** | độ lớn độ dịch chuyển | **quãng đường** |
| Bằng nhau khi | — | $f$ **không đổi dấu** trên $[a;b]$ | — |

Ví dụ với $f(x)=3-x$ trên $[0;4]$ (đổi dấu tại $x=3$): hình dưới đồ thị gồm một tam giác trên trục hoành (diện tích $\frac92$) và một tam giác dưới trục hoành (diện tích $\frac12$). Vậy $\int_0^4 f\,dx=\frac92-\frac12=4$, $\left\lvert\int_0^4 f\,dx\right\rvert=4$, còn $\int_0^4\lvert f\rvert\,dx=\frac92+\frac12=5$.

### 2.4. Diện tích và thể tích

| | Diện tích hình phẳng | Thể tích theo mặt cắt | Khối tròn xoay quanh $Ox$ |
|---|---|---|---|
| Công thức | ${\int_a^b\lvert f-g\rvert\,dx}$ | ${\int_a^b S(x)\,dx}$ | ${\pi\int_a^b f^2(x)\,dx}$ |
| "Mảnh" được cộng | dải mỏng cao $\lvert f-g\rvert$ | lát mỏng diện tích $S(x)$ | lát tròn bán kính $\lvert f(x)\rvert$ |
| Có $\pi$? | không | chỉ khi mặt cắt là hình tròn | **có** |
| Trị tuyệt đối? | **có** — phải chia đoạn | không ($S\ge0$) | không ($f^2\ge0$) |
| Đơn vị | đơn vị dài **mũ 2** | mũ 3 | mũ 3 |

Khi quay miền **giữa hai đồ thị** $0\le g(x)\le f(x)$ quanh $Ox$, SGK chưa cho công thức riêng. Cách chắc ăn nhất là **trừ hai khối tròn xoay**: $V=\pi\int_a^b f^2\,dx-\pi\int_a^b g^2\,dx$. Viết $\pi\int_a^b(f-g)^2\,dx$ là **sai**, vì $(f-g)^2\ne f^2-g^2$ (xem Bài 13, Dạng 3).

### 2.5. Những cặp dễ nhầm trong bài toán thực tế

| Cặp | Phân biệt |
|---|---|
| **Tìm hàm** – **tìm lượng thay đổi** | "độ cao **lúc** $t=3$" cần $h(t)$ đầy đủ, tức phải tìm $C$ từ $h(0)$ (Bài 11) – "độ cao **tăng thêm** từ $t=1$ đến $t=3$" chỉ cần $\int_1^3 v\,dt$ (Bài 12) |
| **Gia tốc** – **vận tốc** – **vị trí** | lấy nguyên hàm **hai lần**, mỗi lần một hằng số: $v(0)$ rồi $s(0)$ |
| **Độ dịch chuyển** – **quãng đường** | $\int v$ – $\int\lvert v\rvert$; khác nhau khi vật **đổi chiều** ($v$ đổi dấu) |
| **Xa nhất** – **sau cùng** | vị trí xa nhất ở lúc $v=0$ đổi dấu (cực trị theo Chương I), không nhất thiết ở cuối khoảng thời gian |
| **Giá trị trung bình** – **trung bình hai đầu** | $\frac{1}{b-a}\int_a^b f$ – $\frac{f(a)+f(b)}{2}$; chỉ trùng nhau khi $f$ là hàm bậc nhất |
| **Tốc độ** – **tổng lượng** | lít/phút – lít; mg/giờ – mg. Đơn vị của tích phân = đơn vị của $f$ × đơn vị của $x$ |

## 3. Lỗi sai hay gặp của cả chương

> [!bay] Bài 11 — nguyên hàm
> - **1.** **Quên $+C$** khi hỏi họ nguyên hàm. Ngược lại, câu "hàm số nào là **một** nguyên hàm" thì phương án có hằng số lạ như $+5$, $-\sqrt2$ **vẫn đúng**.
> - **2.** **"Tách" tích, thương**: $\int x(x-1)\,dx\ne\frac{x^2}{2}\cdot\left(\frac{x^2}{2}-x\right)$. Phải nhân phá ngoặc hoặc chia từng số hạng trước.
> - **3.** **Dùng công thức lũy thừa cho hàm của $x$**: $\int\tan^2x\,dx\ne\frac{\tan^3x}{3}$, $\int(2x+1)^2dx\ne\frac{(2x+1)^3}{3}$. Lũy thừa chỉ áp dụng cho **chính biến $x$**.
> - **4.** **Sai dấu** ở $\int\sin x$, $\int\frac{1}{\sin^2x}$, hoặc quên chia $\ln a$ ở $\int a^x$. Hoặc viết $\int\frac{1}{x}=\ln x$ khi $x$ có thể âm (đúng là $\ln\lvert x\rvert$).
> - **5.** **Tìm được $C$ nhưng quên thay vào** khi tính $F(x_1)$. Hoặc nhầm $e^0=0$, $\cos0=0$ khi thay điều kiện.

> [!bay] Bài 12 — tích phân
> - **6.** **Chỉ tính $F(b)$, quên trừ $F(a)$** — nhất là khi $F(a)\ne0$ ($e^0=1$, $\cos0=1$, hay $\frac{(x+1)^3}{3}$ tại $0$ bằng $\frac13$).
> - **7.** **$\int_a^b k\,dx=k$** — sai, đúng là $k(b-a)$. Ví dụ $\int_1^4\big[f(x)+2\big]dx=\int_1^4 f\,dx+6$.
> - **8.** **Đổi cận mà quên đổi dấu**, hoặc "tách" $\int f\cdot g=\int f\cdot\int g$.
> - **9.** **$\int\lvert f\rvert=\left\lvert\int f\right\rvert$** khi $f$ đổi dấu. Tính **độ dịch chuyển** khi đề hỏi **quãng đường**.
> - **10.** **Máy tính để chế độ độ (D)** khi có $\sin$, $\cos$ — tích phân lượng giác phải ở chế độ **Radian**.

> [!bay] Bài 13 — diện tích, thể tích
> - **11.** **Bỏ trị tuyệt đối khi có nghiệm bên trong đoạn**: hai mảnh trái dấu triệt tiêu nhau, kết quả nhỏ hơn thật, thậm chí bằng $0$ hoặc âm. Diện tích **âm** (như phương án $-9$ ở SGK Bài tập 4.24) là vô lí.
> - **12.** **Chia đoạn cả ở nghiệm nằm ngoài $[a;b]$**, hoặc quên rằng khi đề không cho $x=a$, $x=b$ thì cận là nghiệm **nhỏ nhất và lớn nhất** của $f=g$.
> - **13.** **Quên $\pi$, quên bình phương, bình phương sai** trong $\pi\int f^2$: $(4-x^2)^2\ne16-x^4$.
> - **14.** **Thêm $\pi$ "theo thói quen"** vào $\int S(x)\,dx$ khi mặt cắt là tam giác, hình vuông, hình chữ nhật.
> - **15.** **Quay miền giữa hai đồ thị** mà viết $\pi\int(f-g)^2$.
> - **16.** **Quên đổi đơn vị**: $1\text{ dm}^3=1$ lít, $1\text{ m}^3=1000$ lít, $1\text{ cm}^3=1$ ml. Đừng làm tròn quá sớm.

> [!bay] Những hàm "lạ" trong đề trắc nghiệm
> SGK có vài câu như $\int\sin2x\,dx$ (Bài tập 4.20) hay $\int e^{2x}dx$ (Bài tập 4.10) — những hàm này **không có sẵn trong bảng nguyên hàm** của SGK. Khi gặp ở câu trắc nghiệm, em **không cần** công thức mới: đạo hàm từng phương án bằng quy tắc hàm hợp của lớp 11, ví dụ $\left(-\frac12\cos2x\right)'=-\frac12\cdot(-\sin2x)\cdot2=\sin2x$. Phương án nào đạo hàm ra đúng hàm đề cho thì chọn. Riêng $e^{2x}=(e^2)^x$ là hàm mũ cơ số $e^2$ nên vẫn dùng được bảng: $\int e^{2x}dx=\dfrac{(e^2)^x}{\ln e^2}+C=\dfrac{e^{2x}}{2}+C$.

## 4. Bài tổng hợp

Năm bài dưới đây đều **phối hợp nhiều bài** của chương (có bài nối cả sang Chương I) và bám ba dạng đề tốt nghiệp. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Từ đạo hàm về hàm số, rồi về tích phân

> [!vi-du] Ví dụ 1 (Bài 11 + 12 + Chương I — liên hệ SGK Bài tập 4.23, 4.29)
> Hàm số $f(x)$ có đạo hàm $f'(x)=2\cos x+1$ trên $\mathbb R$ và $f(0)=3$.
>
> a) Tìm $f(x)$.
>
> b) Tính $\displaystyle\int_0^\pi f'(x)\,dx$.
>
> c) Tìm giá trị lớn nhất của $f(x)$ trên đoạn $[0;\,\pi]$.
>
> d) Tính diện tích hình phẳng giới hạn bởi đồ thị $y=f'(x)$, trục hoành và hai đường thẳng $x=0$, $x=\pi$. So sánh với kết quả câu b).

> [!goi-y] Gợi ý 1
> a) $f$ là một nguyên hàm của $f'$: $\int(2\cos x+1)\,dx=2\sin x+x+C$. Thay $x=0$.

> [!goi-y] Gợi ý 2
> b) Không cần tính lại nguyên hàm: $\int_0^\pi f'(x)\,dx=f(\pi)-f(0)$.

> [!goi-y] Gợi ý 3
> c) và d) đều cần biết $f'$ **đổi dấu ở đâu** trên $[0;\pi]$: giải $2\cos x+1=0$. Ở d), trên mỗi đoạn con, tích phân của $f'$ lại là hiệu hai giá trị của $f$.

> [!loi-giai] Lời giải
> **a)** $f(x)=2\sin x+x+C$ và $f(0)=C=3$. Vậy $f(x)=2\sin x+x+3$.
>
> **b)** $\displaystyle\int_0^\pi f'(x)\,dx=f(\pi)-f(0)=(\pi+3)-3=\pi$.
>
> **c)** Trên $[0;\pi]$: $f'(x)=0\iff\cos x=-\frac12\iff x=\frac{2\pi}{3}$. $f'>0$ trên $\left[0;\frac{2\pi}3\right)$ và $f'<0$ trên $\left(\frac{2\pi}3;\pi\right]$, nên $f$ tăng rồi giảm:
> $$\max_{[0;\pi]}f=f\!\left(\tfrac{2\pi}{3}\right)=\sqrt3+\frac{2\pi}{3}+3\approx6{,}83.$$
>
> **d)** $f'$ đổi dấu tại $\frac{2\pi}{3}$, nên tách đoạn:
> - $\displaystyle\int_0^{2\pi/3}f'\,dx=f\!\left(\tfrac{2\pi}3\right)-f(0)=\sqrt3+\tfrac{2\pi}{3}$ (dương).
> - $\displaystyle\int_{2\pi/3}^{\pi}f'\,dx=f(\pi)-f\!\left(\tfrac{2\pi}3\right)=\tfrac{\pi}{3}-\sqrt3$ (âm, $\approx-0{,}69$).
>
> $$S=\left(\sqrt3+\frac{2\pi}{3}\right)+\left(\sqrt3-\frac{\pi}{3}\right)$$
> $$=2\sqrt3+\frac{\pi}{3}\approx4{,}51.$$
> Câu b) cho $\pi\approx3{,}14$ — nhỏ hơn $S$, vì ở đó phần dưới trục hoành đã **trừ bớt** phần trên.

> [!meo]
> Đẳng thức $\int_a^b f'(x)\,dx=f(b)-f(a)$ giúp em "đi tắt": khi đã có $f$, mọi tích phân của $f'$ chỉ là **hiệu hai giá trị của $f$** — không cần tìm nguyên hàm lần nữa.

### 4.2. Đọc đồ thị của đạo hàm bằng diện tích

Ở Ôn tập chương I (Ví dụ 2), ta có đồ thị của $f'$ và kết luận: trên $[0;5]$, giá trị nhỏ nhất của $f$ là số nhỏ hơn trong hai số $f(0)$, $f(5)$, nhưng **chưa so sánh được**. Bây giờ ta có công cụ để làm việc đó.

> [!vi-du] Ví dụ 2 (Bài 12 + 13 + Chương I — liên hệ SGK Bài tập 4.25)
> Hàm số $f(x)$ có đạo hàm liên tục trên $\mathbb R$, $f(0)=1$. Đồ thị của $y=f'(x)$ như Hình 2: cắt trục hoành tại $x=-1$, $x=4$ và tiếp xúc trục hoành tại $x=2$. Hình phẳng giới hạn bởi đồ thị $y=f'(x)$ và trục hoành trên đoạn $[0;4]$ có diện tích $S_1=2{,}4$; trên đoạn $[4;5]$ có diện tích $S_2=2{,}55625$.
>
> a) Tính $f(4)$ và $f(5)$.
>
> b) Tìm giá trị lớn nhất và giá trị nhỏ nhất của $f(x)$ trên đoạn $[0;5]$.

![Hình 2. Đồ thị y = f′(x): phần trên trục hoành trên [0; 4] có diện tích S₁ = 2,4; phần dưới trục hoành trên [4; 5] có diện tích S₂ ≈ 2,56](h2-dien-tich-dao-ham.svg)

> [!goi-y] Gợi ý 1
> $f(4)-f(0)=\int_0^4 f'(x)\,dx$. Trên $[0;4]$ đồ thị $f'$ ở **trên** trục hoành (chỉ chạm tại $x=2$), nên tích phân này **bằng** diện tích $S_1$.

> [!goi-y] Gợi ý 2
> Trên $[4;5]$ đồ thị ở **dưới** trục hoành: $\int_4^5 f'(x)\,dx=-S_2$.

> [!goi-y] Gợi ý 3
> b) Lập bảng biến thiên của $f$ trên $[0;5]$ từ dấu của $f'$ (Chương I), rồi dùng các giá trị vừa tính.

> [!loi-giai] Lời giải
> **a)** $f(4)=f(0)+\int_0^4 f'\,dx=1+2{,}4=3{,}4$.
> $f(5)=f(4)+\int_4^5 f'\,dx=3{,}4-2{,}55625=0{,}84375$.
>
> **b)** $f'\ge0$ trên $[0;4]$ (chỉ bằng $0$ tại $x=2$, $x=4$), $f'<0$ trên $(4;5]$: $f$ tăng trên $[0;4]$, giảm trên $[4;5]$.
> - GTLN: $f(4)=3{,}4$.
> - GTNN: so sánh $f(0)=1$ và $f(5)\approx0{,}84$ → $\min\limits_{[0;5]}f=f(5)=0{,}84375$.
>
> Nói gọn: vì $S_2>S_1$, phần "đi xuống" trên $[4;5]$ **lớn hơn** phần "đi lên" trên $[0;4]$, nên $f(5)<f(0)$.

> [!bay]
> - Câu hỏi so sánh $f(0)$ và $f(5)$ **không cần** biết $f(0)$: chỉ cần dấu của $f(5)-f(0)=S_1-S_2$.
> - Đừng cộng $S_1+S_2$ khi tính $f(5)-f(0)$: đó là **diện tích**, còn $f(5)-f(0)$ là **tích phân có dấu**.

### 4.3. Đúng/Sai: diện tích giữa hai đồ thị cắt nhau ba lần

> [!vi-du] Ví dụ 3 (Bài 12 + 13 — liên hệ SGK Bài tập 4.24, 4.33)
> Gọi $(H)$ là hình phẳng giới hạn bởi đồ thị hai hàm số $y=x^3-2x$ và $y=x^2$ (Hình 3). Xét các mệnh đề:
>
> a) Hai đồ thị cắt nhau tại ba điểm có hoành độ $-1$, $0$, $2$.
>
> b) Với mọi $x\in(0;2)$, đồ thị $y=x^2$ nằm phía trên đồ thị $y=x^3-2x$.
>
> c) Diện tích của $(H)$ bằng $\left\lvert\displaystyle\int_{-1}^{2}(x^3-x^2-2x)\,dx\right\rvert=\frac94$.
>
> d) Diện tích của $(H)$ bằng $\dfrac{37}{12}$.

![Hình 3. Hai đồ thị y = x³ − 2x và y = x² cắt nhau tại x = −1, 0, 2; trên [−1; 0] đường bậc ba ở trên, trên [0; 2] parabol ở trên](h3-hai-do-thi.svg)

> [!goi-y] Gợi ý 1
> Hoành độ giao điểm: $x^3-2x=x^2\iff x(x^2-x-2)=0$.

> [!goi-y] Gợi ý 2
> b) Thử một điểm trong $(0;2)$, chẳng hạn $x=1$.

> [!goi-y] Gợi ý 3
> c), d) Đặt $h(x)=x^3-x^2-2x$, một nguyên hàm là $H(x)=\frac{x^4}{4}-\frac{x^3}{3}-x^2$. Tính $H(-1)$, $H(0)$, $H(2)$ một lần rồi dùng lại.

> [!loi-giai] Lời giải
> a) **Đúng.** $x(x+1)(x-2)=0\iff x\in\{-1;\,0;\,2\}$.
>
> b) **Đúng.** Tại $x=1$: $x^2=1$, còn $x^3-2x=-1$. Trong $(0;2)$ hai đồ thị không cắt nhau, nên thứ tự trên – dưới giữ nguyên.
>
> c) **Sai.** Ta có:
> - $H(-1)=\frac14+\frac13-1=-\frac{5}{12}$;
> - $H(0)=0$;
> - $H(2)=4-\frac83-4=-\frac83$.
>
> Từ đó:
> - $\int_{-1}^0 h\,dx=\frac{5}{12}$ (dương).
> - $\int_0^2 h\,dx=-\frac83$ (âm).
>
> Tích phân trên cả đoạn bằng $\frac{5}{12}-\frac83=-\frac94$. Lấy trị tuyệt đối được $\frac94$, nhưng hai mảnh trái dấu đã **triệt tiêu một phần**, nên đó không phải diện tích.
>
> d) **Đúng.** $S=\frac{5}{12}+\frac83=\frac{5+32}{12}=\frac{37}{12}$.

> [!meo] Soát bằng Casio fx-580VN X
> Nhập $\int_{-1}^{2}\lvert X^3-X^2-2X\rvert\,dX$ (bọc hàm bằng lệnh **Abs** — trị tuyệt đối), máy cho $3{,}0833\ldots=\frac{37}{12}$. Nếu quên Abs, máy cho $-2{,}25$ — con số âm là dấu hiệu em đang tính tích phân chứ không phải diện tích.

### 4.4. Trả lời ngắn: drone bay lên rồi hạ xuống

> [!vi-du] Ví dụ 4 (Bài 11 + 12 + Chương I — liên hệ SGK Bài tập 4.27, 4.30, 4.31)
> Một drone cất cánh thẳng đứng từ sân thượng cao $10$ m. Gia tốc của nó sau $t$ giây là $a(t)=4-2t$ (m/s²), vận tốc ban đầu bằng $0$. Chiều dương hướng lên, $0\le t\le5$.
>
> a) Tìm vận tốc $v(t)$ và độ cao $h(t)$ (so với mặt đất).
>
> b) Drone lên cao nhất lúc nào, ở độ cao bao nhiêu mét (làm tròn đến hàng phần mười)?
>
> c) Tính độ dịch chuyển và quãng đường drone đi được trong 5 giây đầu.

> [!goi-y] Gợi ý 1
> Hai lần lấy nguyên hàm, hai hằng số: $v=\int a\,dt$ với $v(0)=0$, rồi $h=\int v\,dt$ với $h(0)=10$ (không phải $0$).

> [!goi-y] Gợi ý 2
> b) Drone lên cao nhất khi $v$ đổi dấu từ dương sang âm (cực đại của $h$ theo Chương I).

> [!goi-y] Gợi ý 3
> c) $v$ đổi dấu tại $t=4$: quãng đường $=\int_0^4 v\,dt+\left\lvert\int_4^5 v\,dt\right\rvert$.

> [!loi-giai] Lời giải
> **a)** $v(t)=\int(4-2t)\,dt=4t-t^2+C_1$, $v(0)=0\Rightarrow C_1=0$: $v(t)=4t-t^2$.
> $h(t)=\int(4t-t^2)\,dt=2t^2-\dfrac{t^3}{3}+C_2$, $h(0)=10\Rightarrow C_2=10$:
> $$h(t)=2t^2-\frac{t^3}{3}+10.$$
>
> **b)** $v(t)=t(4-t)$: dương trên $(0;4)$, âm trên $(4;5]$. Drone lên cao nhất lúc $t=4$ s:
> $$h(4)=32-\frac{64}{3}+10=\frac{62}{3}\approx20{,}7\ \text{m}.$$
>
> **c)** Độ dịch chuyển: $\displaystyle\int_0^5 v\,dt=h(5)-h(0)=50-\frac{125}{3}=\frac{25}{3}\approx8{,}3$ m (cuối cùng drone cao hơn chỗ cất cánh $8{,}3$ m).
> Quãng đường:
> - đi lên: $\int_0^4 v\,dt=h(4)-h(0)=\frac{32}{3}$;
> - đi xuống: $\int_4^5 v\,dt=h(5)-h(4)=-\frac73$.
>
> Tổng quãng đường $=\frac{32}{3}+\frac73=13$ m.

> [!bay]
> - Đề hỏi "độ cao lớn nhất" mà trả lời $h(5)$ (cuối khoảng thời gian) là sai — chỗ cao nhất ở $t=4$.
> - Đề hỏi "độ cao" (so với mặt đất) thì phải cộng $10$ m của sân thượng. Đề hỏi "lên cao thêm bao nhiêu" thì không.

### 4.5. Trả lời ngắn: bình gốm có thành dày

> [!vi-du] Ví dụ 5 (Bài 13 — liên hệ SGK Bài tập 4.35)
> Một người thợ gốm làm chiếc bình có **mặt trong** là mặt tròn xoay sinh ra khi quay đồ thị
> $$y=f(x)=5+\frac x2-\frac{x^2}{40},\quad0\le x\le20$$
> quanh trục $Ox$ ($x$, $y$ tính bằng cm, $x=0$ ở đáy trong, $x=20$ ở miệng bình). Coi gần đúng: thành bình dày đều $1$ cm, tức **mặt ngoài** sinh ra khi quay $y=f(x)+1$. Đáy bình là khối trụ dày $1$ cm, bán kính $f(0)+1$ (Hình 4).
>
> a) Bình chứa được tối đa bao nhiêu lít nước (làm tròn đến hàng phần trăm)?
>
> b) Cần bao nhiêu cm³ đất sét để làm bình (làm tròn đến hàng đơn vị)?

![Hình 4. Mặt cắt dọc của bình gốm: mặt trong y = f(x), mặt ngoài y = f(x) + 1, đáy dày 1 cm](h4-binh-gom.svg)

> [!goi-y] Gợi ý 1
> a) Dung tích là thể tích khối tròn xoay **bên trong**: $V_1=\pi\int_0^{20}f^2(x)\,dx$. Khai triển $f^2$ trước.

> [!goi-y] Gợi ý 2
> b) Phần thành bình = khối "ngoài" trừ khối "trong" trên $[0;20]$:
> $$\pi\int_0^{20}\big[(f+1)^2-f^2\big]dx.$$
> Để ý $(f+1)^2-f^2=2f+1$ — không cần bình phương $f$ nữa!

> [!goi-y] Gợi ý 3
> Đừng quên phần **đáy**: khối trụ bán kính $f(0)+1=6$ cm, cao $1$ cm.

> [!loi-giai] Lời giải
> **a)** $f^2=25+5x+\dfrac{x^2}{4}-\dfrac{x^2}{4}-\dfrac{x^3}{40}+\dfrac{x^4}{1600}$, tức là
> $$f^2(x)=25+5x-\frac{x^3}{40}+\frac{x^4}{1600}.$$
> Một nguyên hàm của $f^2$ là $G(x)=25x+\dfrac{5x^2}{2}-\dfrac{x^4}{160}+\dfrac{x^5}{8000}$, nên
> $$\int_0^{20}f^2\,dx=G(20)-G(0)$$
> $$=500+1000-1000+400=900.$$
> $V_1=900\pi\approx2827{,}4$ cm³ $\approx2{,}83$ lít.
>
> **b)** Thành bình:
> $$\pi\int_0^{20}(2f+1)\,dx$$
> $$=\pi\int_0^{20}\left(11+x-\frac{x^2}{20}\right)dx$$
> $$=\pi\left(220+200-\frac{400}{3}\right)=\frac{860\pi}{3}.$$
> Đáy: $\pi\cdot6^2\cdot1=36\pi$.
> Tổng: $\dfrac{860\pi}{3}+36\pi=\dfrac{968\pi}{3}\approx1014$ cm³ đất sét.

> [!em-co-biet]
> Mô hình "mặt ngoài $=f(x)+1$" đo độ dày **theo phương bán kính**. Ở chỗ thành bình nghiêng nhiều, độ dày thật (đo vuông góc với thành) hơi nhỏ hơn $1$ cm, nên đây là phép tính **gần đúng** — đủ tốt để người thợ ước lượng đất sét cần chuẩn bị.

## 5. Đối chiếu "Bài tập cuối chương IV" (SGK tr. 27–28)

Bảng dưới cho biết mỗi bài tập của SGK kiểm tra điều gì, nên xem lại ở đâu, kèm một **bài tự luyện cùng dạng** (số liệu khác). Làm xong, mở đáp số bên dưới để tự chấm.

| SGK | Kiểm tra (xem lại) | Bài tự luyện cùng dạng |
|---|---|---|
| 4.20 | Nhận ra một nguyên hàm (hàm hợp) — *Lỗi sai ở mục 3, khung "hàm lạ"* | (T1) Trong $\sin3x$, $\frac13\sin3x$, $-\frac13\sin3x$, $3\sin3x$, hàm nào là một nguyên hàm của $\cos3x$? |
| 4.21 | Họ nguyên hàm, $+C$ — *Bài 11 mục 1.2* | (T2) Tìm $\int(3e^x-2)\,dx$. |
| 4.22 | Nguyên hàm thỏa điều kiện — *Bài 11 mục 4* | (T3) $F$ là nguyên hàm của $e^x+2e^{-x}$, $F(0)=1$. Tìm $F$. |
| 4.23 | $\int_a^b f'=f(b)-f(a)$ — *Mục 2.1; Ví dụ 1* | (T4) $f(-1)=2$, $\int_{-1}^{2}f'(x)\,dx=7$. Tính $f(2)$. |
| 4.24, 4.33 | Diện tích giữa hai đồ thị — *Bài 13 mục 1.2; Ví dụ 3* | (T5) $y=x^2$, $y=4x-x^2$, $x=0$, $x=3$. |
| 4.25 | Diện tích khi biết các tích phân — *Bài 13 Dạng 1; Ví dụ 2* | (T6) $f$ cắt $Ox$ tại $-3$, $0$, $3$; dưới trục trên $(-3;0)$, trên trục trên $(0;3)$; $\int_{-3}^3f=2$, $\int_0^3f=5$. Tính diện tích. |
| 4.26 | Thể tích khối cầu, chỏm cầu — *Bài 13 mục 2.2* | (T7) Quay miền dưới $y=\sqrt{9-x^2}$, $0\le x\le3$, quanh $Ox$. |
| 4.27, 4.30 | Từ gia tốc tìm vận tốc — *Bài 11; Ví dụ 4* | (T8) $a(t)=6t-2$, $v(0)=3$. Tính $v(3)$. |
| 4.28 | Họ nguyên hàm (bảng) — *Bài 11 mục 3* | (T9) a) $\int\left(5^x-\frac3x\right)dx$; b) $\int\left(\frac{1}{\sqrt x}+2\sin x-\frac{1}{\cos^2x}\right)dx$. |
| 4.29 | Nguyên hàm lượng giác thỏa điều kiện — *Bài 11 mục 4* | (T10) $f=2\sin x+\frac{1}{\cos^2x}$, $F\left(\frac\pi3\right)=0$. |
| 4.31 | Quãng đường lớn nhất ($v=0$) — *Bài 12 mục 1.5* | (T11) Xuồng tắt máy trôi với $v(t)=8-2t$ (m/s). Trôi thêm được bao xa? |
| 4.32 | Tính tích phân — *Bài 12 mục 1.3, 2.1* | (T12) a) $\int_1^4(2x-3\sqrt x)\,dx$; b) $\int_0^{\pi/3}(\sin x+2\cos x)\,dx$; c) $\int_{\pi/4}^{\pi/3}\frac{dx}{\cos^2x}$; d) $\int_1^9\frac{x+2}{\sqrt x}\,dx$. |
| 4.34 | Thể tích khối tròn xoay — *Bài 13 mục 2.2* | (T13) a) $y=x^2+1$, $y=0$, $x=0$, $x=1$; b) $y=\sqrt{16-x^2}$, $y=0$, $x=1$, $x=3$. |
| 4.35 | Thể tích thực tế, thành có độ dày — *Bài 13 Dạng 4; Ví dụ 5* | Làm lại Ví dụ 5 với thành dày $0{,}5$ cm. |

> [!loi-giai] Đáp số bài tự luyện T1–T13
> - **T1.** $\frac13\sin3x$, vì $\left(\frac13\sin3x\right)'=\frac13\cdot3\cos3x=\cos3x$.
> - **T2.** $3e^x-2x+C$.
> - **T3.** $e^{-x}=\left(\frac1e\right)^x$ nên $\int e^{-x}dx=\frac{(1/e)^x}{\ln(1/e)}=-e^{-x}$. $F=e^x-2e^{-x}+C$, $F(0)=-1+C=1$, vậy $F(x)=e^x-2e^{-x}+2$.
> - **T4.** $f(2)=f(-1)+7=9$.
> - **T5.** $x^2=4x-x^2\iff x=0$ hoặc $x=2$ (nằm trong đoạn!). $S=\int_0^2(4x-2x^2)\,dx+\int_2^3(2x^2-4x)\,dx=\frac83+\frac83=\frac{16}{3}$. (Không chia đoạn sẽ ra $\left\lvert\int_0^3(2x^2-4x)\,dx\right\rvert=0$.)
> - **T6.** $\int_{-3}^0f=2-5=-3$, nên $S=3+5=8$.
> - **T7.** $V=\pi\int_0^3(9-x^2)\,dx=18\pi$ (nửa khối cầu bán kính $3$ ✓).
> - **T8.** $v=3t^2-2t+3$, $v(3)=24$ m/s.
> - **T9.** a) $\frac{5^x}{\ln5}-3\ln\lvert x\rvert+C$. b) $2\sqrt x-2\cos x-\tan x+C$.
> - **T10.** $F=-2\cos x+\tan x+C$ và $-1+\sqrt3+C=0$, vậy $F(x)=-2\cos x+\tan x+1-\sqrt3$.
> - **T11.** Dừng khi $t=4$ s, quãng đường $\int_0^4(8-2t)\,dt=16$ m.
> - **T12.** a) $15-14=1$. b) $\frac12+\sqrt3$. c) $\sqrt3-1$. d) $\int_1^9\left(\sqrt x+2x^{-\frac12}\right)dx=\frac{52}{3}+8=\frac{76}{3}$.
> - **T13.** a) $\pi\int_0^1(x^4+2x^2+1)\,dx=\frac{28\pi}{15}$. b) $\pi\int_1^3(16-x^2)\,dx=\frac{70\pi}{3}$.

## Tóm tắt — danh sách kiểm tra trước giờ thi

| Khi gặp | Nhớ ngay |
|---|---|
| $\int f(x)\,dx$ | Biến đổi về bảng → áp dụng → **$+C$** → đạo hàm lại để kiểm tra |
| Điều kiện $F(x_0)=c$ | Thay vào họ nguyên hàm để tìm $C$, rồi **thay $C$ vào** |
| $\int_a^b f(x)\,dx$ | $F(b)-F(a)$, nhớ trừ $F(a)$; máy tính để Radian |
| Chỉ cho giá trị tích phân | Tách, cộng đoạn, đổi cận đổi dấu, $\int_a^b k=k(b-a)$ |
| $\int_a^b f'(x)\,dx$ | $=f(b)-f(a)$ |
| Có $\lvert\ \rvert$, vật đổi chiều | Xét dấu → chia đoạn; $\int v$ là độ dịch chuyển, $\int\lvert v\rvert$ là quãng đường |
| Diện tích | Giao điểm → chia đoạn → "trên trừ dưới" → cộng; kết quả **dương** |
| Thể tích | Mặt cắt hình gì? Tròn → $\pi f^2$; khác → tự tính $S(x)$; miền giữa hai đường → trừ hai khối |
| Thực tế | Tốc độ ↔ tổng; tìm thời điểm $v=0$; đổi đơn vị, làm tròn ở bước cuối |

**Sơ đồ một dòng:** *đạo hàm đi ngược → nguyên hàm $F$ (+C) → tích phân $F(b)-F(a)$ → diện tích, thể tích, lượng thay đổi trong thực tế.*
