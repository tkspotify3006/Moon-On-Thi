---
title: Công nghệ gene
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm công nghệ gene (công nghệ di truyền) và công nghệ DNA tái tổ hợp.
  - Trình bày được nguyên lí tạo DNA tái tổ hợp: vai trò của enzyme cắt giới hạn, DNA ligase, vector (plasmid); các bước tách chiết – cắt – nối – chuyển vào tế bào nhận – chọn dòng.
  - Nêu được một số thành tựu của công nghệ DNA tái tổ hợp (insulin người, vi sinh vật biến đổi gene trong công nghiệp, môi trường, nông nghiệp).
  - Nêu được khái niệm, nguyên lí và một số thành tựu tạo thực vật, động vật biến đổi gene (lúa vàng, bông kháng sâu, cừu sản xuất antithrombin, cá hồi tăng trưởng nhanh).
  - Tranh luận, phản biện được về sản xuất, sử dụng sản phẩm biến đổi gene và các vấn đề đạo đức sinh học.
  - Giải thích được ý nghĩa từng bước trong thực hành tách chiết DNA (Bài 6).
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Công nghệ gene** (công nghệ di truyền) dùng **công nghệ DNA tái tổ hợp** để thay đổi kiểu gene, kiểu hình của sinh vật và tạo sản phẩm protein có ích.
> 2. **DNA tái tổ hợp** = **gene chuyển** + **vector** (thường là **plasmid**), ghép từ hai nguồn DNA khác nhau (thường khác loài).
> 3. Ba "dụng cụ": **enzyme cắt giới hạn** (kéo — cắt ở trình tự nhận biết, tạo **đầu dính**), **DNA ligase** (keo — nối liên kết phosphodiester), **vector** (xe chở — tự tái bản, giúp gene được biểu hiện trong tế bào nhận).
> 4. Quy trình: **tách chiết → cắt (cùng một enzyme) → nối → chuyển vào tế bào nhận → chọn dòng tế bào mang DNA tái tổ hợp → thu sản phẩm**.
> 5. **Sinh vật biến đổi gene** có hệ gene đã bị biến đổi (thường thêm gene loài khác). Động vật: vi tiêm gene vào **trứng vừa thụ tinh** + cấy phôi; thực vật: **súng bắn gene/virus** + **nuôi cấy tế bào** tái sinh cây. Công nghệ này mang lại nhiều lợi ích nhưng gây quan ngại về **sức khoẻ, môi trường và đạo đức sinh học**.

> [!nen-tang] Nhớ lại từ Bài 1 và Bài 2
> - DNA gồm hai mạch **đối song song**, kết cặp **A – T, G – C** bằng liên kết hydrogen; các nucleotide trong một mạch nối nhau bằng **liên kết phosphodiester** (xem Bài 1).
> - Trong tái bản, enzyme **ligase** nối các đoạn Okazaki — chính enzyme "nối" này được dùng lại trong bài hôm nay.
> - Mã di truyền gần như **phổ biến** cho mọi loài: cùng một bộ ba mã hoá cùng một amino acid ở vi khuẩn lẫn người (xem Bài 2).
> - Gene nhân thực thường **phân mảnh** (exon xen intron); tế bào nhân thực cắt intron sau phiên mã, còn **vi khuẩn không làm được việc này** (xem Bài 2).
>
> Hai ý cuối là "chìa khoá" giải thích vì sao vi khuẩn có thể làm ra protein của người — nhưng với điều kiện ta phải chuẩn bị gene cho đúng cách.

## 1. Công nghệ DNA tái tổ hợp

**Câu hỏi mở đầu:** làm sao để một con vi khuẩn bé xíu "làm thuê" sản xuất insulin của người? Ý tưởng rất đơn giản: lấy **đúng đoạn DNA** quy định insulin từ tế bào người, **gắn** nó vào một phân tử DNA mà vi khuẩn chấp nhận và tự nhân lên, rồi **đưa** vào vi khuẩn. Vi khuẩn sinh sản rất nhanh, mỗi tế bào con đều mang gene đó và đọc nó như gene của chính mình.

Toàn bộ quy trình kĩ thuật ấy là **công nghệ DNA tái tổ hợp**. Khi dùng nó để thay đổi kiểu gene, kiểu hình của sinh vật và tạo sản phẩm protein, ta gọi chung là **công nghệ gene** (SGK cũng gọi là **công nghệ di truyền**). Công nghệ gene gồm hai mảng: **công nghệ DNA tái tổ hợp** và **công nghệ tạo sinh vật biến đổi gene**.

### 1.1. Khái niệm

**Công nghệ DNA tái tổ hợp** là quy trình kĩ thuật tạo ra phân tử DNA từ **hai nguồn khác nhau** (thường thuộc hai loài), rồi chuyển phân tử đó vào **tế bào nhận** để tạo ra nhiều sản phẩm protein của gene chuyển.

**DNA tái tổ hợp** gồm hai phần:

| Thành phần | Là gì | Vai trò |
|---|---|---|
| **Gene chuyển** | đoạn DNA mang gene cần chuyển (ví dụ gene insulin người) | mang thông tin tạo ra sản phẩm mong muốn |
| **Vector** (thể truyền) | phân tử DNA dùng làm "xe chở", thường là **plasmid** | đưa gene vào tế bào nhận, **tự tái bản** được và giúp gene chuyển được **phiên mã, dịch mã** trong tế bào nhận |

> [!bay]
> - "Tái tổ hợp" ở đây là ghép DNA **trong ống nghiệm** từ hai nguồn — khác với "biến dị tổ hợp" do lai (Bài 8).
> - **Tế bào nhận** (thường là vi khuẩn *E. coli*, nấm men…) không phải là thành phần của DNA tái tổ hợp. DNA tái tổ hợp chỉ gồm **gene chuyển + vector**.

### 1.2. Ba "dụng cụ" của kĩ thuật ghép gene

Hãy hình dung công việc như cắt – dán một đoạn băng: cần **kéo**, **keo** và một **cuộn băng chủ** để dán vào.

**a) Enzyme cắt giới hạn (restrictase) — "cái kéo"**

- Mỗi loại enzyme cắt giới hạn chỉ nhận biết **một trình tự nucleotide đặc hiệu** (thường dài 4–8 cặp nucleotide) gọi là **trình tự nhận biết**, và cắt cả hai mạch DNA **tại vị trí xác định** trong trình tự đó.
- Trình tự nhận biết thường **đối xứng**: đọc mạch trên theo chiều 5' → 3' giống hệt đọc mạch dưới theo chiều 5' → 3'. Ví dụ enzyme EcoRI nhận biết 5'-GAATTC-3', mạch bổ sung cũng là 5'-GAATTC-3'.
- Nhiều enzyme cắt **so le** hai mạch → mỗi đầu cắt có một đoạn **mạch đơn** thò ra, gọi là **đầu dính**. EcoRI cắt giữa G và A trên mỗi mạch → đầu dính là 5'-AATT.

![Hình 1. EcoRI cắt so le tại trình tự GAATTC tạo hai đầu dính bổ sung; khi ghép với đoạn DNA khác cũng cắt bằng EcoRI, DNA ligase nối các chỗ hở](hinh-1-enzyme.svg)

**Vì sao phải cắt gene cần chuyển và vector bằng CÙNG một enzyme?** Vì cùng enzyme thì tạo ra **cùng kiểu đầu dính**. Đầu dính của gene và đầu dính của plasmid **bổ sung** với nhau nên tự bắt cặp (bằng liên kết hydrogen) — giống hai mảnh ghép cùng khớp.

**b) DNA ligase — "keo dán"**

Khi hai đầu dính đã bắt cặp, khung đường – phosphate của mỗi mạch vẫn còn **chỗ hở**. **DNA ligase** xúc tác hình thành **liên kết phosphodiester** để bịt các chỗ hở đó, tạo phân tử DNA liền mạch. Mỗi chỗ nối giữa hai đoạn DNA mạch kép có **2 chỗ hở** (mỗi mạch một chỗ) → ligase nối 2 liên kết.

**c) Vector — "xe chở gene"**

Vector phổ biến nhất là **plasmid**: phân tử DNA **vòng, mạch kép, nhỏ**, nằm trong tế bào chất của vi khuẩn, **tự tái bản độc lập** với DNA vùng nhân. Ngoài plasmid, có thể dùng **virus** (ví dụ thể thực khuẩn) làm vector.

Một vector tốt cần:
- **tự tái bản** được trong tế bào nhận (để gene được nhân lên theo tế bào);
- có trình tự giúp gene chuyển **được phiên mã và dịch mã** trong tế bào nhận;
- có **vị trí nhận biết** của enzyme cắt giới hạn (chỗ để "mở cửa" gắn gene);
- có **gene đánh dấu** (thường là gene kháng kháng sinh) để nhận ra tế bào đã nhận vector.

> [!em-co-biet]
> Enzyme cắt giới hạn vốn là "vũ khí" của vi khuẩn: chúng cắt vụn DNA của virus xâm nhập. DNA của chính vi khuẩn được bảo vệ vì các vị trí nhận biết đã bị đánh dấu hoá học. Con người chỉ việc "mượn" vũ khí này.

### 1.3. Nguyên lí và các bước tạo DNA tái tổ hợp

**Nguyên lí** (SGK tr. 27): kết hợp bốn nhóm kĩ thuật là **tách chiết gene** ra khỏi tế bào, **nhân bản gene**, **cắt** và **ghép nối** DNA. Mục tiêu cuối cùng là gene, khi vào tế bào nhận, phải **làm ra được sản phẩm hoạt động được**.

![Hình 2. Quy trình tạo DNA tái tổ hợp và đưa vào tế bào vi khuẩn](hinh-2-quy-trinh.svg)

| Bước | Làm gì | Vì sao |
|---|---|---|
| 1. Tách chiết | Tách plasmid từ vi khuẩn; tách DNA (hoặc gene) cần chuyển từ tế bào cho | có nguyên liệu để ghép |
| 2. Cắt | Cắt plasmid và DNA chứa gene bằng **cùng một enzyme cắt giới hạn** | tạo đầu dính bổ sung; plasmid mở vòng ở điểm cắt |
| 3. Nối | Trộn hai loại DNA đã cắt; đầu dính bắt cặp; **DNA ligase** nối | tạo **DNA tái tổ hợp** (plasmid tái tổ hợp) |
| 4. Chuyển vào tế bào nhận | Đưa DNA tái tổ hợp vào tế bào nhận (thường *E. coli*); có thể xử lí tế bào bằng muối CaCl~2~ hoặc xung điện để màng dễ cho DNA đi qua | tế bào nhận nhân lên nhanh, mỗi tế bào con đều có bản sao plasmid |
| 5. Chọn dòng | Nuôi trên môi trường có chất chọn lọc (ví dụ kháng sinh) để giữ lại **dòng tế bào mang DNA tái tổ hợp** | chỉ một phần nhỏ tế bào nhận được DNA tái tổ hợp |
| 6. Thu sản phẩm | Nuôi dòng tế bào đã chọn ở quy mô lớn, tách chiết protein | gene chuyển được phiên mã, dịch mã → protein |

**Vì sao phải chọn dòng?** Sau bước 4, trong ống nghiệm có ba loại tế bào: (1) không nhận plasmid nào; (2) nhận plasmid **không** chứa gene (plasmid tự đóng vòng lại); (3) nhận **plasmid tái tổ hợp** — loại ta cần, thường rất ít. Gene đánh dấu trên vector giúp loại bỏ loại (1); muốn phân biệt (2) và (3) cần thêm dấu hiệu khác (xem Dạng 3).

> [!vi-du] Ví dụ 1
> Cho các thao tác: (a) nuôi tế bào trên môi trường có kháng sinh; (b) dùng DNA ligase nối gene vào plasmid; (c) cắt plasmid và DNA chứa gene bằng cùng một enzyme cắt giới hạn; (d) đưa DNA tái tổ hợp vào tế bào *E. coli*; (e) tách plasmid và DNA chứa gene khỏi tế bào. Sắp xếp các thao tác theo đúng trình tự.

> [!goi-y] Gợi ý 1
> Muốn cắt thì phải có DNA trong tay trước. Muốn nối thì phải cắt trước.

> [!goi-y] Gợi ý 2
> Chọn dòng (môi trường kháng sinh) chỉ có ý nghĩa khi DNA tái tổ hợp **đã vào** tế bào.

> [!loi-giai] Lời giải
> Tách chiết (e) → cắt (c) → nối (b) → chuyển vào tế bào nhận (d) → chọn dòng (a).
>
> Trình tự đúng: **e → c → b → d → a**.

> [!vi-du] Ví dụ 2
> Một đoạn DNA mạch kép **dạng thẳng** có mạch 1 là 5'-TACGAATTCAGGCTTAAGCGGATCCATGAATTCGTA-3'. Enzyme EcoRI nhận biết 5'-GAATTC-3', enzyme BamHI nhận biết 5'-GGATCC-3'.
> a) Cắt đoạn DNA bằng EcoRI thì thu được bao nhiêu đoạn?
> b) Cắt bằng cả EcoRI và BamHI thì thu được bao nhiêu đoạn?

> [!goi-y] Gợi ý 1
> Đọc mạch 1 theo chiều 5' → 3' và tìm từng trình tự nhận biết. Vì trình tự nhận biết **đối xứng**, nếu mạch 1 không có GAATTC ở một chỗ thì mạch 2 ở chỗ đó cũng không có — chỉ cần dò một mạch.

> [!goi-y] Gợi ý 2
> DNA thẳng bị cắt ở n vị trí thì thành **n + 1** đoạn (như cắt sợi dây n nhát).

> [!loi-giai] Lời giải
> Bước 1: Dò GAATTC: gặp ở "TAC**GAATTC**AGG…" và "…CAT**GAATTC**GTA" → **2 vị trí** EcoRI. (Đoạn "CTTAAG" ở giữa **không** phải vị trí EcoRI — đó là bẫy: đọc ngược mạch 1 từ phải sang trái mới thấy chữ "GAATTC", nhưng như vậy là đọc sai chiều.)
>
> Bước 2: Dò GGATCC: gặp ở "…GC**GGATCC**AT…" → **1 vị trí** BamHI.
>
> a) 2 vết cắt → 2 + 1 = **3 đoạn**.
>
> b) 2 + 1 = 3 vết cắt → **4 đoạn**.

> [!bay]
> - DNA **thẳng** cắt n chỗ → **n + 1** đoạn; DNA **vòng** (plasmid) cắt n chỗ → **n** đoạn. Plasmid cắt 1 chỗ chỉ **mở vòng** thành 1 đoạn thẳng.
> - Chỉ tính trình tự đọc **đúng chiều 5' → 3'**.

### 1.4. Một số thành tựu của công nghệ DNA tái tổ hợp

Thành tựu nổi bật nhất là tạo ra các dòng **vi sinh vật biến đổi gene** (SGK tr. 28):

| Lĩnh vực | Ví dụ |
|---|---|
| **Dược phẩm** | Vi khuẩn mang gene insulin người sản xuất **insulin người** chữa bệnh đái tháo đường (SGK: công ty Eli Lilly đưa ra thị trường năm 1979). Gene insulin được tách chiết, **loại bỏ intron**, gắn vào plasmid rồi chuyển vào vi khuẩn; sản phẩm tách ra được xử lí hoá học để thành insulin có chức năng. |
| **Công nghiệp, môi trường** | Vi khuẩn biến đổi gene làm tăng hiệu quả sản xuất ethanol từ vật liệu thực vật; xử lí nước thải, phân huỷ hoá chất độc, tách chiết kim loại nặng, tăng thu hồi dầu… |
| **Nông nghiệp** | Vi khuẩn biến đổi gene giúp cây tăng hấp thụ nitrogen, ức chế vi khuẩn và nấm gây bệnh cho cây. |

**Vì sao gene insulin phải bỏ intron trước khi chuyển vào vi khuẩn?** Vi khuẩn **không có** bộ máy cắt intron. Nếu đưa nguyên gene phân mảnh của người vào, vi khuẩn sẽ dịch mã cả phần intron → chuỗi polypeptide sai hoàn toàn. Vì vậy người ta dùng bản gene chỉ gồm các exon nối liền — thường tạo bằng cách **phiên mã ngược** mRNA trưởng thành thành **cDNA** (xem Bài 2, mục Phiên mã ngược).

> [!vi-du] Ví dụ 3 (dựa trên câu hỏi Luyện tập SGK tr. 31)
> Một bạn tách nguyên một gene của người (gồm 3 exon xen 2 intron) khỏi hệ gene, gắn vào plasmid rồi chuyển vào *E. coli*. Vi khuẩn có tạo ra đúng protein của người không? Muốn vi khuẩn tạo đúng protein thì cần làm gì?

> [!goi-y] Gợi ý 1
> Mã di truyền có tính phổ biến, nên vi khuẩn "đọc hiểu" được bộ ba của người. Vậy vấn đề nằm ở đâu trong cấu trúc gene?

> [!goi-y] Gợi ý 2
> Ở tế bào người, mRNA trưởng thành đã mất intron. Vi khuẩn có bước "cắt intron – nối exon" không?

> [!loi-giai] Lời giải
> Bước 1: Mã di truyền phổ biến → vi khuẩn **có thể** dịch mã gene người.
>
> Bước 2: Nhưng gene này **phân mảnh**. Vi khuẩn phiên mã cả intron và **không cắt được intron** → mRNA chứa intron → dịch mã ra chuỗi polypeptide **sai** (thường bị lệch khung đọc hoặc gặp bộ ba kết thúc sớm).
>
> Bước 3: Cách làm đúng: dùng gene **đã loại intron** (cDNA tổng hợp từ mRNA trưởng thành nhờ enzyme phiên mã ngược), gắn sau **promoter** mà RNA polymerase của vi khuẩn nhận ra (vector đảm nhiệm). Một số protein còn cần **xử lí sau dịch mã** (như insulin) nên sau khi tách chiết phải xử lí thêm.
>
> Kết luận: chuyển nguyên gene có intron thì **không** thu được đúng protein người.

> [!ung-dung]
> Về mốc thời gian: SGK ghi năm 1979. Theo các tư liệu khác, insulin người tái tổ hợp được tạo ra năm 1978 và được cấp phép làm thuốc năm 1982. Khi đi thi, em dùng mốc theo SGK.
>
> Trước khi có insulin tái tổ hợp, insulin cho người bệnh được tách từ tuỵ lợn, bò — số lượng hạn chế và đôi khi gây dị ứng vì khác vài amino acid. Insulin người do vi sinh vật sản xuất có cấu trúc giống insulin của người, sản xuất được với số lượng lớn. Ngày nay nhiều thuốc khác (hormone sinh trưởng, vaccine viêm gan B, thuốc kích thích tạo hồng cầu…) cũng được sản xuất theo cách này.

## 2. Công nghệ tạo thực vật và động vật biến đổi gene

### 2.1. Khái niệm sinh vật biến đổi gene

**Sinh vật biến đổi gene** là sinh vật có hệ gene đã được con người biến đổi, chủ yếu là **có thêm gene mới từ loài khác**. Vì vậy động vật, thực vật có thêm gene từ loài khác còn gọi là **động vật, thực vật chuyển gene**.

**Mục đích:** tạo ra sinh vật mang những đặc điểm **chưa từng có trong tự nhiên** để phục vụ con người (cây tự tạo chất diệt sâu, động vật tiết protein làm thuốc vào sữa…). Lai giống thông thường không làm được điều đó, vì lai chỉ tổ hợp lại các allele **sẵn có trong loài**, còn công nghệ gene vượt qua được **rào cản loài**.

> [!bay]
> Sinh vật biến đổi gene **không chỉ** là "thêm gene lạ". Hệ gene có thể bị biến đổi bằng cách **làm biến đổi** hoặc **loại bỏ** (làm bất hoạt) một gene sẵn có. "Chuyển gene" chỉ là trường hợp phổ biến nhất.

### 2.2. Nguyên lí tạo động vật biến đổi gene

Cả động vật và thực vật biến đổi gene đều dựa trên **nguyên lí DNA tái tổ hợp**. Điểm khó là làm sao từ **một tế bào** nhận gene phát triển thành **cả một cơ thể** mà mọi tế bào đều mang gene chuyển.

![Hình 3. Nguyên lí tạo động vật và thực vật biến đổi gene](hinh-3-sinh-vat-bien-doi-gene.svg)

Với động vật (SGK tr. 29):

1. **Tế bào nhận là trứng vừa thụ tinh** — lúc nhân tinh trùng và nhân trứng **chưa hoà hợp** với nhau. Tế bào trứng đủ lớn để dùng kim tiêm siêu nhỏ **bơm hàng trăm bản sao** gene chuyển vào.
2. Gene chuyển cài **ngẫu nhiên** vào hệ gene của nhân trứng hoặc nhân tinh trùng. Tỉ lệ thành công rất thấp → phải tiêm **rất nhiều trứng**.
3. Nuôi hợp tử thành phôi sớm, **cấy phôi** vào tử cung con cái "mẹ nuôi" để mang thai và sinh con.
4. **Sàng lọc** con sinh ra để tìm con mang gene chuyển (không phải con nào cũng mang).
5. **Lai** các con chuyển gene với nhau để tạo dòng **đồng hợp** về gene chuyển — ổn định qua các thế hệ.

**Vì sao chọn trứng vừa thụ tinh mà không tiêm vào tế bào cơ thể trưởng thành?** Vì hợp tử là tế bào **đầu tiên** của cơ thể. Gene cài vào hợp tử sẽ được nhân lên qua nguyên phân và có mặt ở **mọi tế bào** của con vật — kể cả tế bào sinh dục, nên còn **truyền được cho đời sau**.

> [!vi-du] Ví dụ 4
> Hai con cừu C (cái) và E (đực) được sàng lọc là đều mang **một bản** gene chuyển T (gene chuyển cài vào một chiếc của một cặp NST; chiếc tương đồng không có T). Cho C × E. Tính tỉ lệ cừu con **đồng hợp** về gene chuyển; trong số cừu con mang gene chuyển, cừu đồng hợp chiếm bao nhiêu?

> [!goi-y] Gợi ý 1
> Coi mỗi con là "dị hợp" T/– (một chiếc NST có T, chiếc kia không). Phép lai giống Aa × Aa ở Bài 8.

> [!goi-y] Gợi ý 2
> Đời con: 1 TT : 2 T/– : 1 –/–. "Mang gene chuyển" gồm những kiểu nào?

> [!loi-giai] Lời giải
> Bước 1: T/– × T/– → ¼ TT : ½ T/– : ¼ –/–.
>
> Bước 2: Tỉ lệ đồng hợp TT = **1/4 = 25%**.
>
> Bước 3: Con mang gene chuyển = TT + T/– = 3/4 → trong số đó TT chiếm (1/4) : (3/4) = **1/3**.
>
> Đây chính là lí do bước 5 cần lai rồi **tiếp tục sàng lọc** (ví dụ lai phân tích) để giữ lại con đồng hợp.

### 2.3. Nguyên lí tạo thực vật biến đổi gene

Cũng dựa trên DNA tái tổ hợp như ở vi khuẩn, nhưng tế bào thực vật có **thành cellulose** dày, nên phải dùng cách riêng để đưa DNA vào (SGK tr. 30):

- **Súng bắn gene**: bắn các hạt rất nhỏ bằng **vàng** hoặc **vonfram** được bọc DNA tái tổ hợp xuyên qua thành tế bào;
- hoặc dùng **virus** làm vector.

Sau đó tế bào đã nhận gene được **nuôi cấy** cho **tái sinh** thành cây hoàn chỉnh. Điều này làm được vì tế bào thực vật có **tính toàn năng** — một tế bào có thể phát triển thành cả cây (em đã học nuôi cấy mô ở Sinh học 10).

> [!ghi-nho] So sánh nhanh (SGK tr. 31)
> | | Động vật biến đổi gene | Thực vật biến đổi gene |
> |---|---|---|
> | Tế bào nhận | trứng vừa thụ tinh (hợp tử) | tế bào thực vật (tế bào soma, mô) |
> | Cách đưa gene vào | vi tiêm | súng bắn gene, virus |
> | Công nghệ đi kèm | thụ tinh nhân tạo, nuôi phôi, cấy phôi vào mẹ nuôi | nuôi cấy tế bào – tái sinh cây |
> | Bước cuối | sàng lọc, lai tạo dòng đồng hợp | chọn cây mang gene, nhân giống |

> [!em-co-biet]
> Ngoài súng bắn gene, cách rất phổ biến để chuyển gene vào cây là dùng vi khuẩn đất *Agrobacterium*: tự nhiên nó đã biết "chèn" một đoạn DNA trong plasmid của mình vào hệ gene cây. Các nhà khoa học thay đoạn DNA đó bằng gene cần chuyển.

### 2.4. Một số thành tựu

| Đối tượng | Sinh vật biến đổi gene | Gene chuyển → đặc điểm mới |
|---|---|---|
| Thực vật | **Lúa vàng** ("golden rice") | thêm gene tổng hợp **tiền chất vitamin A** (β-carotene) → hạt gạo màu vàng, giúp phòng thiếu vitamin A |
| Thực vật | **Bông kháng sâu** | gene từ **vi khuẩn** tạo **độc tố diệt sâu** → không phải phun thuốc trừ sâu hoá học |
| Động vật | **Cừu chuyển gene** | gene **antithrombin** của người, protein được tiết vào **sữa** → dễ tách chiết làm thuốc chống đông máu dùng trong phẫu thuật |
| Động vật | **Cá hồi chuyển gene** | thêm gene **hormone sinh trưởng** → lớn nhanh hơn nhiều so với cá hồi thường |

> [!em-co-biet]
> SGK lấy ví dụ cừu. Trên thực tế, thuốc antithrombin tái tổ hợp đầu tiên được cấp phép (năm 2006 ở châu Âu) được chiết từ sữa **dê** chuyển gene. Nguyên lí hoàn toàn giống nhau.

**Vì sao lại cho protein tiết vào sữa?** Vì sữa được vắt ra hằng ngày mà **không phải giết** con vật, lượng lớn, dễ tinh chế. Con vật trở thành "nhà máy sinh học" sống.

> [!ung-dung] Mở rộng (ngoài SGK)
> Ở Việt Nam, từ năm 2015 một số giống **ngô biến đổi gene** (kháng sâu, chịu thuốc trừ cỏ) đã được phép trồng thương mại. Câu hỏi Luyện tập SGK tr. 31 gợi ý em tìm hiểu giống cây biến đổi gene đang trồng ở địa phương mình.

## 3. Lợi ích, quan ngại và vấn đề đạo đức sinh học

Công nghệ gene giúp **tăng năng suất, chất lượng** cây trồng vật nuôi, tạo thuốc và vật liệu mới. Nhưng SGK (tr. 30) nêu rõ ba nhóm quan ngại:

| Nhóm quan ngại | Nội dung | Ví dụ |
|---|---|---|
| **Môi trường** | gene chuyển phát tán ra tự nhiên | cây trồng kháng thuốc diệt cỏ, kháng côn trùng, kháng virus **lai với cây hoang dại** họ hàng → truyền gene → tạo **"siêu cỏ dại"** rất khó diệt |
| **Sức khoẻ** | ảnh hưởng lâu dài khi dùng sản phẩm biến đổi gene chưa được hiểu đầy đủ | có thể gây dị ứng hoặc bệnh khác |
| **Đạo đức sinh học** | có nên biến đổi hệ gene của người? | chỉnh sửa hệ gene phôi người bị cấm nghiên cứu ở nhiều nước; dùng DNA tái tổ hợp chữa bệnh di truyền còn lo ngại vì **chưa đảm bảo** gene thay thế hoạt động bình thường và **không ảnh hưởng** gene khác |

**Cách nhiều nước ứng xử:** không cấm thực phẩm biến đổi gene nhưng **bắt buộc ghi nhãn** trên bao bì để người tiêu dùng **tự lựa chọn**; sinh vật biến đổi gene phải được đánh giá an toàn trước khi được phép đưa ra môi trường.

> [!em-co-biet] Liệu pháp gene
> **Liệu pháp gene** là đưa gene lành vào tế bào người bệnh (thường dùng virus đã bị làm mất khả năng gây bệnh làm vector) để thay thế chức năng của gene hỏng. Cần phân biệt: sửa gene ở **tế bào sinh dưỡng** chỉ tác động lên người được chữa; còn sửa gene ở **phôi, tế bào sinh dục** sẽ **truyền cho các thế hệ sau** — đây là điểm gây tranh cãi đạo đức lớn nhất.

> [!vi-du] Ví dụ 5
> Xét các phát biểu sau về sinh vật biến đổi gene, phát biểu nào đúng, phát biểu nào sai?
> a) Cây bông kháng sâu mang gene của một loài vi khuẩn.
> b) Mọi con cừu sinh ra từ phôi đã được tiêm gene đều mang gene chuyển.
> c) Gene kháng thuốc diệt cỏ ở cây trồng có thể phát tán sang cây hoang dại cùng họ qua thụ phấn chéo.
> d) Vì đã được cấp phép nên thực phẩm biến đổi gene không cần ghi nhãn.

> [!goi-y] Gợi ý 1
> Nhớ lại Hình 3: sau khi cừu con ra đời, bước tiếp theo là gì? Tại sao lại cần bước đó?

> [!goi-y] Gợi ý 2
> Lai với cây hoang dại cần điều kiện gì? Mục đích của nhãn "biến đổi gene" là gì?

> [!loi-giai] Lời giải
> a) **Đúng** — gene tạo độc tố diệt sâu lấy từ vi khuẩn.
>
> b) **Sai** — gene chỉ cài vào hệ gene ở một số ít trứng; phải **sàng lọc** mới biết con nào mang gene.
>
> c) **Đúng** — cây trồng có thể lai với loài hoang dại họ hàng gần → nguy cơ "siêu cỏ dại".
>
> d) **Sai** — nhiều nước yêu cầu ghi nhãn để người tiêu dùng tự lựa chọn.

## 4. Thực hành: Tách chiết DNA (Bài 6)

Bài thực hành (SGK tr. 32–34) tách DNA từ gan gà bằng dụng cụ đơn giản. Đề thi thường hỏi **ý nghĩa** của từng bước — chỉ cần hiểu "mỗi hoá chất phá vỡ cái gì".

| Bước | Thao tác | Ý nghĩa |
|---|---|---|
| 1 | Nghiền/xay gan với nước lạnh | phá vỡ mô, tách rời tế bào (nước lạnh hạn chế enzyme phân huỷ DNA) |
| 2 | Lọc qua giấy lọc | bỏ cặn, lấy dịch trong |
| 3 | Thêm **nước rửa bát** (chất tẩy rửa) | hoà tan **lipid** → phá **màng tế bào, màng nhân** → giải phóng DNA |
| 4 | Thêm **nước dứa tươi** | dứa có enzyme **protease** → cắt các **protein** (như histone) bám vào DNA |
| 5 | Rót nhẹ **cồn ethanol lạnh** theo thành ống | DNA **không tan** trong cồn → **kết tủa** thành sợi trắng đục ở lớp cồn phía trên; dùng đũa quấn nhẹ lấy ra |

Vì sao DNA nổi lên lớp cồn? Cồn **nhẹ hơn nước** nên tạo lớp trên; cồn "hút" nước mạnh hơn DNA nên các phân tử DNA bị đẩy sát vào nhau và kết tủa tại đó. Có thể nhận biết DNA bằng thuốc thử **diphenylamine** (đun nóng → màu xanh lam).

> [!bay]
> - Nên chọn **mô động vật** (gan gà, gan lợn): giàu DNA, dễ nghiền. Mô thực vật nhiều nước, ít DNA hơn, có sắc tố cần loại bỏ.
> - Phải **xoay nhẹ** đũa: DNA đã kết tủa dễ **gãy vụn**.
> - Có thể thay nước dứa bằng dung dịch có protease khác (ví dụ nước ép đu đủ xanh, dung dịch enzyme protease).

## Dạng bài thi hay gặp

> [!ghi-nho] Chìa khoá chung
> Nhớ **ai làm gì**: enzyme cắt giới hạn **cắt** (tại trình tự đặc hiệu, tạo đầu dính) — ligase **nối** (liên kết phosphodiester) — vector **chở và nhân lên** — tế bào nhận **sản xuất** — gene đánh dấu giúp **chọn dòng**.

### Dạng 1. Thứ tự các bước và vai trò của enzyme, vector

*Nhận biết:* "trình tự đúng là…", "enzyme nào dùng để…", "vector cần đặc điểm gì", "vì sao phải dùng cùng một enzyme…".

*Phương pháp:*
1. Thuộc chuỗi **tách → cắt → nối → chuyển → chọn → thu sản phẩm**.
2. Ghép đúng công cụ với bước: cắt ↔ restrictase; nối ↔ ligase; chuyển ↔ vector (và CaCl~2~/xung điện); chọn ↔ gene đánh dấu.
3. Với câu "không đúng", soát từng phương án bằng câu hỏi "công cụ này **có** làm việc đó không?".

> [!vi-du] Ví dụ 6
> Trong kĩ thuật tạo DNA tái tổ hợp, enzyme ligase có vai trò nào sau đây?
> (1) Nhận biết và cắt DNA tại trình tự đặc hiệu. (2) Nối liên kết phosphodiester giữa gene chuyển và vector. (3) Làm hai đầu dính bắt cặp bổ sung với nhau. (4) Mở xoắn plasmid để gắn gene.

> [!goi-y] Gợi ý 1
> Đầu dính bắt cặp **tự nhiên** nhờ liên kết hydrogen — có cần enzyme không?

> [!goi-y] Gợi ý 2
> Ligase chỉ có một việc: bịt chỗ hở trên khung đường – phosphate.

> [!loi-giai] Lời giải
> (1) là việc của enzyme cắt giới hạn. (3) xảy ra tự phát do các base bổ sung. (4) không phải bước của kĩ thuật này. Chỉ **(2)** đúng.

*Bẫy:* nhầm "ligase tạo liên kết hydrogen" — sai, ligase tạo **liên kết phosphodiester** (liên kết cộng hoá trị trong một mạch).

### Dạng 2. Đếm vị trí cắt, số đoạn, kích thước DNA tái tổ hợp

*Nhận biết:* cho trình tự nhận biết và một đoạn DNA (hoặc độ dài DNA), hỏi số vị trí cắt, số đoạn, số liên kết ligase nối, độ dài phân tử tái tổ hợp.

*Phương pháp:*
1. Dò trình tự nhận biết trên **một mạch** theo chiều 5' → 3' (trình tự đối xứng nên không cần dò mạch kia).
2. Số đoạn: DNA thẳng **n + 1**, DNA vòng **n** (n là tổng số vết cắt của mọi enzyme dùng).
3. Ước lượng tần số: trình tự nhận biết dài k cặp nucleotide, nếu bốn loại nucleotide phân bố ngẫu nhiên và bằng nhau thì cứ trung bình **4^k^** cặp nucleotide có một vị trí. Số vị trí kì vọng ≈ (độ dài DNA) : 4^k^.
4. Mỗi chỗ nối giữa hai đoạn mạch kép: ligase nối **2** liên kết phosphodiester. Gắn **một** đoạn gene vào plasmid mở vòng ở **một** điểm → có 2 chỗ nối → **4** liên kết.
5. Chiều dài: L = N(cặp) × 0,34 nm.

> [!vi-du] Ví dụ 7
> Một phân tử DNA dài 12 288 cặp nucleotide, trong đó bốn loại nucleotide phân bố ngẫu nhiên với tỉ lệ bằng nhau. Theo lí thuyết, trung bình có bao nhiêu vị trí cắt của EcoRI (nhận biết 6 cặp nucleotide)? Nếu dùng enzyme nhận biết 4 cặp nucleotide thì số vị trí thay đổi thế nào?

> [!goi-y] Gợi ý 1
> Xác suất một vị trí bất kì khớp đúng 1 nucleotide là 1/4. Khớp đúng 6 nucleotide liên tiếp là bao nhiêu?

> [!goi-y] Gợi ý 2
> Số vị trí kì vọng = độ dài × xác suất.

> [!loi-giai] Lời giải
> Bước 1: Xác suất khớp GAATTC = (1/4)^6^ = 1/4096.
>
> Bước 2: Số vị trí kì vọng ≈ 12 288 : 4096 = **3**.
>
> Bước 3: Với enzyme nhận biết 4 cặp: (1/4)^4^ = 1/256 → 12 288 : 256 = 48 vị trí — **nhiều gấp 16 lần**. Trình tự nhận biết càng ngắn, enzyme cắt càng nhiều chỗ, đoạn cắt càng ngắn.

*Bẫy:* quên quy tắc DNA vòng (n đoạn) và DNA thẳng (n + 1 đoạn); đếm cả trình tự đọc sai chiều.

### Dạng 3. Chọn dòng bằng gene đánh dấu — đọc sơ đồ, đọc kết quả nuôi cấy

> [!em-co-biet] Dạng mở rộng
> SGK 2018 không trình bày chi tiết bước chọn dòng. Dạng này là mở rộng, nhưng hay gặp trong đề thi thử và đề đánh giá năng lực. Em nên học sau khi đã vững Dạng 1 và Dạng 2.

*Nhận biết:* plasmid mang hai gene kháng kháng sinh (ví dụ kháng ampicillin – amp^R^ và kháng tetracycline – tet^R^), gene chuyển được gắn **vào giữa** một trong hai gene đó; hỏi tế bào nào sống trên môi trường nào.

*Phương pháp:*
1. Gene bị chèn vào giữa thì **mất chức năng** (bị "cắt đôi").
2. Lập bảng 3 loại tế bào × các loại môi trường.

> [!vi-du] Ví dụ 8
> Plasmid mang gene amp^R^ và tet^R^; vị trí cắt của enzyme nằm **trong** gene tet^R^. Sau khi gắn gene chuyển và đưa vào vi khuẩn (vốn mẫn cảm với cả hai kháng sinh), làm thế nào để chọn ra vi khuẩn mang plasmid tái tổ hợp?

> [!goi-y] Gợi ý 1
> Plasmid tái tổ hợp có gene chuyển chen vào giữa tet^R^ → tet^R^ còn hoạt động không? amp^R^ thì sao?

> [!goi-y] Gợi ý 2
> Lập bảng: tế bào không nhận plasmid / nhận plasmid không có gene chuyển / nhận plasmid tái tổ hợp — sống hay chết trên môi trường có ampicillin, có tetracycline?

> [!loi-giai] Lời giải
> | Loại tế bào | Môi trường + ampicillin | Môi trường + tetracycline |
> |---|---|---|
> | Không nhận plasmid | chết | chết |
> | Nhận plasmid không có gene chuyển | sống | sống |
> | Nhận plasmid tái tổ hợp | **sống** | **chết** |
>
> Cách chọn: cấy trên môi trường có **ampicillin** → giữ lại hai loại tế bào có plasmid. Cấy chuyển từng khuẩn lạc sang môi trường có **tetracycline**: khuẩn lạc **không mọc** được ở đây chính là dòng mang **plasmid tái tổ hợp** → lấy khuẩn lạc tương ứng trên đĩa ampicillin để nuôi.

*Bẫy:* tưởng tế bào mang DNA tái tổ hợp "kháng cả hai kháng sinh" — sai, gene bị chèn đã mất chức năng.

### Dạng 4. Đúng/Sai về thành tựu, quy trình tạo sinh vật biến đổi gene và đạo đức sinh học

*Nhận biết:* câu Đúng/Sai 4 ý về insulin, lúa vàng, bông kháng sâu, cừu antithrombin, cá hồi; về tế bào nhận, cách chuyển gene; về quan ngại.

*Phương pháp:* soát từng ý theo 3 câu hỏi:
1. **Gene gì, lấy từ đâu, tạo ra gì?** (lúa vàng: tiền chất vitamin A — không phải "vitamin A"; bông: độc tố diệt sâu từ gene vi khuẩn; cừu: antithrombin người trong sữa; cá hồi: hormone sinh trưởng).
2. **Tế bào nhận & công nghệ đi kèm?** (động vật: trứng vừa thụ tinh + cấy phôi; thực vật: tế bào + nuôi cấy tái sinh).
3. Ý nói **tuyệt đối** ("mọi", "luôn", "hoàn toàn an toàn", "không có rủi ro") thường **sai**.

(Xem Ví dụ 5 ở mục 3.)

*Bẫy:* "lúa vàng chứa vitamin A" (thật ra là tiền chất); "gene chuyển cài vào vị trí định trước trong hệ gene cừu" (thật ra cài **ngẫu nhiên**); "plasmid nằm trên NST của vi khuẩn" (plasmid nằm **ngoài** DNA vùng nhân).

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Công nghệ gene | dùng công nghệ DNA tái tổ hợp để thay đổi kiểu gene, kiểu hình; gồm công nghệ DNA tái tổ hợp + tạo sinh vật biến đổi gene |
| DNA tái tổ hợp | gene chuyển + vector (plasmid, virus) |
| Enzyme cắt giới hạn | nhận biết trình tự đặc hiệu (thường đối xứng), cắt so le → đầu dính; gene và vector cắt **cùng một** enzyme |
| DNA ligase | nối liên kết **phosphodiester** |
| Vector | tự tái bản; giúp gene được phiên mã, dịch mã; có điểm cắt và gene đánh dấu |
| Quy trình | tách chiết → cắt → nối → chuyển vào tế bào nhận → chọn dòng → thu sản phẩm |
| Thành tựu vi sinh vật | insulin người (gene đã bỏ intron); ethanol; xử lí ô nhiễm, kim loại nặng; thu hồi dầu; tăng hấp thụ nitrogen |
| Động vật biến đổi gene | vi tiêm vào trứng vừa thụ tinh → nuôi phôi → cấy vào mẹ nuôi → sàng lọc → lai tạo dòng đồng hợp. Ví dụ: cừu tiết antithrombin vào sữa, cá hồi tăng trưởng nhanh |
| Thực vật biến đổi gene | súng bắn gene (hạt vàng, vonfram)/virus → nuôi cấy tế bào tái sinh cây. Ví dụ: lúa vàng (tiền chất vitamin A), bông kháng sâu |
| Quan ngại | phát tán gene → siêu cỏ dại; sức khoẻ (dị ứng…); đạo đức (chỉnh sửa hệ gene người) → đánh giá an toàn, ghi nhãn |
| Tách chiết DNA | nghiền → lọc → chất tẩy rửa (phá màng) → nước dứa (protease cắt protein) → cồn lạnh (kết tủa DNA) |

**Công thức nhanh:** DNA thẳng n vết cắt → n + 1 đoạn; DNA vòng → n đoạn · số vị trí kì vọng ≈ N : 4^k^ · gắn 1 đoạn vào plasmid (1 điểm cắt) → ligase nối 4 liên kết phosphodiester · L = N × 0,34 nm.
