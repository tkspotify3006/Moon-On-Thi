---
title: Di truyền học người và di truyền y học
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm và vai trò của di truyền học người và di truyền y học.
  - Kể được một số phương pháp nghiên cứu di truyền người; trình bày được phương pháp phả hệ và phương pháp di truyền tế bào.
  - Vẽ và đọc được phả hệ: xác định tính trạng trội hay lặn, gene nằm trên NST thường hay NST X; tính được xác suất sinh con mắc bệnh.
  - Nhận biết được một số hội chứng do đột biến NST từ bộ NST (karyotype): Down, Turner, Klinefelter…
  - Nêu được khái niệm và cơ sở khoa học của y học tư vấn; giải thích được vì sao cần tư vấn di truyền trước khi kết hôn và sàng lọc trước sinh.
  - Nêu được khái niệm liệu pháp gene, một số thành tựu, ứng dụng và những rào cản về kĩ thuật, đạo đức.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Di truyền học người** nghiên cứu sự di truyền và biến dị ở người; **di truyền y học** là một lĩnh vực của nó, chuyên về **cơ chế phát sinh, cách di truyền** của bệnh di truyền để phòng tránh và chữa trị.
> 2. Không thể lai hay gây đột biến ở người, nên phải dùng phương pháp riêng: **phả hệ** (theo dõi tính trạng trong dòng họ), **di truyền tế bào** (quan sát bộ NST), trẻ đồng sinh, di truyền phân tử…
> 3. Đọc phả hệ: bố mẹ bình thường sinh con bệnh → **lặn**; bố mẹ bệnh sinh con bình thường → **trội**; bệnh lặn mà con **gái** bệnh có **bố** bình thường → gene trên **NST thường**.
> 4. **Y học tư vấn** dựa trên quy luật di truyền, xét nghiệm NST – sinh hoá (chọc dịch ối, sinh thiết nhau thai) và kĩ thuật phân tử để tính rủi ro, chẩn đoán trước sinh, khuyên tránh **kết hôn cận huyết**.
> 5. **Liệu pháp gene**: thay gene bệnh bằng gene bình thường hoặc chỉnh sửa gene bệnh trong **tế bào soma**; đã có thành tựu (RPE65, CRISPR – Cas9) nhưng còn nhiều rào cản kĩ thuật và đạo đức.

> [!nen-tang] Nhớ lại trước khi học
> - **Bài 8 (Mendel):** Aa × Aa → 1 AA : 2 Aa : 1 aa. Một người **bình thường** sinh từ Aa × Aa thì có kiểu gene **1/3 AA : 2/3 Aa** (đã loại aa).
> - **Bài 10 (liên kết với giới tính):** gene lặn trên vùng không tương đồng của X: nam chỉ cần một allele lặn (X^a^Y) là biểu hiện; con trai nhận X từ **mẹ**, con gái nhận một X từ bố và một X từ mẹ.
> - **Bài 7 (NST):** bộ NST người 2n = 46 gồm 22 cặp NST thường và 1 cặp NST giới tính (nữ XX, nam XY).
> - **Bài 12 (đột biến NST):** lệch bội (thể ba 2n + 1, thể một 2n − 1) do một cặp NST không phân li trong giảm phân.

## 1. Khái niệm, vai trò của di truyền học người và di truyền y học

### 1.1. Khái niệm

**Di truyền học người** là ngành khoa học nghiên cứu **sự di truyền và biến dị ở người**. Các quy luật em đã học (Mendel, liên kết gene, liên kết với giới tính…) đều đúng với người, nhưng con người có những đặc điểm khiến việc nghiên cứu khó hơn hẳn.

Trong di truyền học người có một lĩnh vực chuyên về bệnh tật, gọi là **di truyền y học**: nghiên cứu **cơ chế phát sinh** và **cơ chế di truyền** của các bệnh di truyền, từ đó đề xuất biện pháp **phòng tránh và chữa trị** (SGK tr. 68).

> [!bay]
> Di truyền y học là **một lĩnh vực của** di truyền học người, không phải hai ngành ngang hàng tách rời. Đề hay hỏi "lĩnh vực nào nghiên cứu cơ chế phát sinh bệnh di truyền và đề xuất cách phòng, chữa" → di truyền **y học**.

### 1.2. Vai trò

| | Di truyền học người | Di truyền y học |
|---|---|---|
| Loại nghiên cứu | **Cơ bản** (tìm hiểu quy luật) | **Ứng dụng** (giải quyết vấn đề sức khoẻ) |
| Cho ta biết | Cơ chế di truyền và biến dị ở người; mối quan hệ kiểu gene – môi trường – kiểu hình | Nguyên nhân phát sinh bệnh di truyền, triệu chứng bệnh lí |
| Ứng dụng | Tạo môi trường phù hợp để phát huy tối đa thể chất, năng lực, tố chất bẩm sinh | Tư vấn phòng ngừa, chẩn đoán, chữa trị một số bệnh di truyền |

**Vì sao không nghiên cứu người như nghiên cứu đậu hà lan?**

- **Không được phép** lai có chủ đích hay gây đột biến ở người (lí do **đạo đức**).
- Người **sinh sản chậm**, mỗi thế hệ khoảng 25–30 năm; nhà khoa học không thể theo dõi nhiều thế hệ trong đời mình.
- Mỗi gia đình **ít con** → số liệu nhỏ, khó thống kê tỉ lệ như 3 : 1.
- Bộ NST nhiều (2n = 46), nhiều NST có kích thước, hình dạng gần giống nhau.

Vì vậy, người ta dùng những phương pháp **quan sát** thay cho thí nghiệm lai.

## 2. Một số phương pháp nghiên cứu di truyền người

Có nhiều phương pháp: nghiên cứu ở **cấp độ phân tử**, **tế bào**, nghiên cứu **trẻ đồng sinh**, nghiên cứu **phả hệ**… SGK tập trung vào hai phương pháp: **phả hệ** và **di truyền tế bào** (SGK tr. 69).

| Phương pháp | Làm gì | Trả lời câu hỏi |
|---|---|---|
| Phả hệ | Ghi lại sự xuất hiện một tính trạng trong dòng họ qua nhiều thế hệ | Trội hay lặn? Trên NST thường hay NST giới tính? Một hay nhiều gene? |
| Di truyền tế bào | Quan sát số lượng, hình dạng, kích thước NST | Có đột biến NST (thừa, thiếu, mất đoạn, chuyển đoạn…) không? |
| Trẻ đồng sinh | So sánh trẻ sinh đôi **cùng trứng** (cùng kiểu gene) với **khác trứng** | Tính trạng phụ thuộc vào kiểu gene hay môi trường nhiều hơn? |
| Di truyền phân tử | Phân tích DNA, xác định trình tự gene | Gene nào bị đột biến, đột biến kiểu gì? |

> [!em-co-biet] Vì sao trẻ đồng sinh hữu ích?
> Hai trẻ sinh đôi **cùng trứng** có kiểu gene giống hệt nhau. Nếu nuôi ở hai môi trường khác nhau mà một tính trạng (như nhóm máu) vẫn giống nhau → tính trạng đó do kiểu gene quyết định là chủ yếu; nếu một tính trạng (như cân nặng) khác nhau nhiều → môi trường ảnh hưởng mạnh.

### 2.1. Phương pháp nghiên cứu phả hệ

**a) Phả hệ là gì?** Phả hệ là một **sơ đồ** dùng các **kí hiệu hình học** để ghi lại sự di truyền của một (hoặc vài) tính trạng qua các thế hệ trong một dòng họ. Có thể hiểu phả hệ là **"phép lai tự nhiên"** ở người: ta không bố trí được phép lai, nhưng các cuộc hôn nhân trong dòng họ chính là những phép lai đã xảy ra sẵn.

**b) Cách xây dựng phả hệ.** Bắt đầu từ **một người có đặc điểm khác thường** (thường là mắc một bệnh di truyền). Từ người đó, ta tìm hiểu anh chị em ruột, bố mẹ, con cái, họ hàng qua các thế hệ: ai có đặc điểm đang xét thì **tô đen**, ai không có thì để **trắng** (SGK tr. 69).

![Hình 1. Các kí hiệu thường dùng khi vẽ phả hệ: ô vuông là nam, hình tròn là nữ, tô đen là người có tính trạng đang nghiên cứu](hinh-1-ki-hieu.svg)

- Mỗi **thế hệ** nằm trên **một hàng ngang**, đánh số La Mã I, II, III… từ trên xuống.
- Đường ngang nối nam – nữ là **vợ chồng**; từ đó kẻ xuống một đường dọc tới **các con** (anh chị em ruột nối chung một thanh ngang).
- Mỗi người được đánh số (thường đánh liên tục 1, 2, 3… hoặc theo từng thế hệ: II.3 là người thứ 3 ở thế hệ II).

> [!bay] Đọc kí hiệu cho đúng
> - Trong đề, **tô đen** có thể là "bị bệnh", nhưng cũng có thể là "thuận tay trái", "tóc xoăn"… Luôn đọc **chú thích** của đề.
> - Có đề vẽ người **mang gene** (dị hợp, không biểu hiện) bằng chấm giữa hoặc tô nửa. Người này **không bị bệnh** — đừng tính là người bệnh.

**c) Ứng dụng và hạn chế.** Theo dõi phả hệ cho biết tính trạng di truyền **trội hay lặn**, gene nằm trên **NST thường hay NST giới tính**, do **một hay nhiều gene** quy định. Nhờ phả hệ, người ta phát hiện nhiều bệnh di truyền; ví dụ bệnh **cholesterol máu cao gia đình** do một allele đột biến **trội trên NST thường** làm hỏng thụ thể tiếp nhận LDL cholesterol, khiến người mang gene dễ xơ vữa động mạch, nguy cơ bệnh tim mạch cao bất thường ngay từ khoảng 35 tuổi (SGK tr. 70).

Hạn chế: mỗi gia đình chỉ có vài người con, nên phải **tổng hợp nhiều phả hệ** mới kết luận chắc chắn về kiểu di truyền.

### 2.2. Đọc phả hệ: bốn dấu hiệu then chốt

Đây là kĩ năng **hay thi nhất** của bài. Ta trả lời lần lượt **hai câu hỏi**: (1) trội hay lặn? (2) NST thường hay NST X?

![Hình 2. Bốn dấu hiệu then chốt: (a) và (b) quyết định trội/lặn; (c) và (d) loại trừ khả năng gene nằm trên NST X](hinh-2-dau-hieu.svg)

**Câu hỏi 1 — Trội hay lặn?**

- **(a)** Bố mẹ **đều bình thường** mà sinh con **bị bệnh** → allele bệnh phải "ẩn" ở bố mẹ → bệnh do allele **lặn** (bố mẹ là Aa × Aa).
- **(b)** Bố mẹ **đều bị bệnh** mà sinh con **bình thường** → bố mẹ "giấu" allele bình thường → bệnh do allele **trội** (bố mẹ là Aa × Aa, con bình thường aa).

Vì sao chắc chắn như vậy? Nếu bệnh trội mà bố mẹ đều bình thường (aa × aa) thì con không thể có allele trội gây bệnh (bỏ qua đột biến mới). Lập luận tương tự cho (b).

**Câu hỏi 2 — Trên NST thường hay trên X?** Hãy **thử giả sử gene trên X**, rồi tìm mâu thuẫn:

- **(c)** Bệnh lặn, có **con gái bị bệnh** mà **bố bình thường**. Nếu gene trên X thì con gái X^a^X^a^ phải nhận X^a^ từ bố → bố X^a^Y phải bị bệnh. Mâu thuẫn → gene trên **NST thường**.
- **(d)** Bệnh trội, **bố bị bệnh** mà có **con gái bình thường**. Nếu gene trên X thì bố X^A^Y truyền X^A^ cho **mọi** con gái → mọi con gái phải bệnh. Mâu thuẫn → gene trên **NST thường**.

Ngoài ra, nếu bệnh lặn mà có **mẹ bị bệnh** sinh **con trai bình thường** → cũng loại X (vì mẹ X^a^X^a^ thì mọi con trai đều X^a^Y bị bệnh).

| Kiểu di truyền | Dấu hiệu gợi ý trên phả hệ |
|---|---|
| Lặn, NST thường | Thường "cách thế hệ"; bố mẹ bình thường sinh con bệnh; nam, nữ bị bệnh ngang nhau |
| Trội, NST thường | Bệnh xuất hiện **liên tục** qua các thế hệ; người bệnh có ít nhất một bố/mẹ bệnh; nam, nữ ngang nhau |
| Lặn, trên X | Phần lớn người bệnh là **nam**; con trai bệnh nhận allele từ **mẹ** (mẹ thường bình thường); "ông ngoại → cháu trai" |
| Trội, trên X | Bố bệnh (mẹ bình thường) → **tất cả con gái** bệnh, **tất cả con trai** bình thường |
| Trên Y | Chỉ nam bị, truyền thẳng **bố → tất cả con trai** |

> [!bay] Bảng trên chỉ là "gợi ý", không phải bằng chứng
> "Phần lớn người bệnh là nam" **chưa đủ** để kết luận gene trên X. Chỉ các dấu hiệu (a)–(d) mới cho kết luận **chắc chắn**. Nếu phả hệ không có dấu hiệu loại trừ thì cả hai khả năng (NST thường, X) đều có thể — đề sẽ phải cho thêm dữ kiện (xem Dạng 1).

> [!vi-du] Ví dụ 1
> Quan sát phả hệ ở Hình 3 về một bệnh di truyền do một gene có hai allele quy định (người số 9 chưa sinh). Bệnh do allele trội hay lặn? Gene nằm trên NST thường hay NST X?

![Hình 3. Phả hệ ba thế hệ về một bệnh di truyền: tô đen là người bị bệnh; người số 9 là con chưa sinh của cặp vợ chồng 6 – 7](hinh-3-pha-he.svg)

> [!goi-y] Gợi ý 1
> Tìm một cặp bố mẹ cùng bình thường mà có con bị bệnh.

> [!goi-y] Gợi ý 2
> Người số 8 là nữ bị bệnh. Bố của cô (người số 3) có bị bệnh không? Nếu gene nằm trên X thì sao?

> [!loi-giai] Lời giải
> Bước 1: Cặp 1 × 2 đều bình thường sinh con trai 5 bị bệnh (cặp 3 × 4 cũng vậy với con gái 8) → bệnh do allele **lặn**.
>
> Bước 2: Giả sử gene trên X: con gái 8 bị bệnh có kiểu gene X^a^X^a^, phải nhận X^a^ từ bố 3 → bố 3 phải là X^a^Y (bị bệnh). Nhưng người 3 bình thường → mâu thuẫn.
>
> Kết luận: bệnh do allele **lặn** trên **NST thường**.

> [!ung-dung]
> Hoạt động *Dừng lại và suy ngẫm* (SGK tr. 71) gợi ý em vẽ phả hệ của chính gia đình mình về một tính trạng như thuận tay trái/phải, tóc xoăn/thẳng. Hãy thử: hỏi ông bà, bố mẹ, cô chú… rồi áp dụng 4 dấu hiệu trên. Em sẽ thấy với một gia đình nhỏ, nhiều khi **không** đủ dấu hiệu để kết luận — đó chính là hạn chế của phương pháp phả hệ.

### 2.3. Phương pháp di truyền tế bào

**a) Khái niệm.** Là phương pháp nghiên cứu **số lượng, hình dạng, kích thước NST** của bộ NST bình thường và bộ NST bất thường.

**b) Cách tiến hành** (SGK tr. 70):

1. Lấy **tế bào bạch cầu** của người, nuôi cấy trong môi trường nhân tạo cho chúng phân chia.
2. Cho **colchicine** vào môi trường: chất này ngăn hình thành thoi phân bào → tế bào **dừng ở kì giữa**, khi NST co xoắn cực đại, dễ quan sát nhất.
3. Làm tiêu bản, nhuộm, chụp ảnh bộ NST.
4. Lập **bộ NST đồ (karyotype)**: xếp các cặp NST tương đồng thành hàng theo **kích thước giảm dần**, đánh số **1 → 22** cho NST thường, cặp NST giới tính xếp riêng ở cuối.

> [!bay] Vì sao là bạch cầu, không phải hồng cầu?
> Hồng cầu trưởng thành của người **không có nhân** → không có NST để quan sát. Bạch cầu có nhân, lấy dễ (qua máu), nuôi cấy được.

**c) Ứng dụng.**

- Hiểu đặc điểm bộ NST bình thường của loài người.
- So sánh bộ NST của người bệnh với karyotype chuẩn → phát hiện **đột biến số lượng** và **cấu trúc** NST gây bệnh.
- Phát hiện sớm đột biến NST ở **thai nhi** → giúp gia đình đưa ra quyết định phù hợp.
- Phát hiện nhiều bệnh **ung thư**: ví dụ chuyển đoạn giữa NST số 8 và số 14 trong tế bào soma gây ung thư bạch cầu **Burkitt** (SGK tr. 64 in nhầm là "8 và 9" — dùng 8 – 14, xem Bài 12); chuyển gần như toàn bộ vai dài NST 21 sang vai ngắn NST 14 cũng gây **hội chứng Down** (SGK tr. 71).

![Hình 4. Sơ đồ karyotype của một người nam mắc hội chứng Down: cặp số 21 có 3 chiếc, tổng số 47 NST (47,XY,+21)](hinh-4-karyotype-down.svg)

**Nhận biết một số hội chứng qua karyotype** (cơ chế phát sinh: xem Bài 12). SGK chỉ nêu Down, Turner, Klinefelter, XXX và tiếng mèo kêu; Patau, Edwards là **mở rộng** (hay gặp trong đề cũ) — SGK tr. 64 nói lệch bội NST thường đều gây chết thai trừ thừa NST 21, thực tế trẻ Patau, Edwards vẫn có thể được sinh ra nhưng thường chết sớm:

| Hội chứng | Bộ NST | Tổng số NST | Giới | Đặc điểm chính |
|---|---|---|---|---|
| Down | 3 chiếc NST **21** (thể ba) | 47 | nam hoặc nữ | Mặt tròn, mắt xếch, lưỡi dày, chậm phát triển trí tuệ |
| Patau | 3 chiếc NST **13** | 47 | nam hoặc nữ | Nhiều dị tật nặng (sứt môi, thừa ngón…), thường chết sớm |
| Edwards | 3 chiếc NST **18** | 47 | nam hoặc nữ | Dị tật tim, đầu nhỏ, thường chết sớm |
| Turner | chỉ **1 X** (XO) | 45 | **nữ** | Lùn, cổ ngắn, buồng trứng không phát triển, vô sinh |
| Klinefelter | **XXY** | 47 | **nam** | Chân tay dài, tinh hoàn nhỏ, thường vô sinh |
| Ba X (siêu nữ) | **XXX** | 47 | nữ | Thường gần bình thường, có thể rối loạn kinh nguyệt |
| Tiếng mèo kêu | **mất đoạn** vai ngắn NST số 5 | 46 | nam hoặc nữ | Tiếng khóc như mèo kêu, chậm phát triển |

> [!meo] Đếm nhanh để đoán hội chứng
> - **47** NST: tìm cặp có 3 chiếc → 21 (Down), 13 (Patau), 18 (Edwards); hoặc giới tính XXY (Klinefelter), XXX.
> - **45** NST, chỉ một X, là nữ → **Turner** (thể một, 2n − 1).
> - **46** NST mà vẫn bệnh → nghĩ đến **đột biến cấu trúc** (mất đoạn, chuyển đoạn…).
> - Có Y → **nam** (dù có mấy X). Không có Y → **nữ**.

> [!bay]
> - Bệnh **bạch tạng, máu khó đông, mù màu, hồng cầu hình liềm, phenylketonuria** là bệnh do **đột biến gene** → **không** nhìn thấy trên karyotype (NST vẫn bình thường). Muốn phát hiện phải dùng xét nghiệm sinh hoá hoặc phân tích DNA.
> - Hội chứng Down **không phải** chỉ ở nữ hay chỉ ở nam: NST 21 là NST thường.

> [!vi-du] Ví dụ 2
> Phân tích bộ NST của một người thấy có 47 NST, trong đó cặp NST giới tính gồm hai chiếc X và một chiếc Y, các cặp NST thường bình thường. (a) Người này là nam hay nữ, mắc hội chứng gì? (b) Nêu một cách hợp tử này có thể được tạo ra từ bố mẹ có bộ NST bình thường.

> [!goi-y] Gợi ý 1
> Có Y thì giới tính là gì? XXY là thừa NST nào?

> [!goi-y] Gợi ý 2
> Hợp tử XXY = giao tử bất thường (n + 1) + giao tử bình thường (n). Giao tử thừa có thể đến từ mẹ (XX) hoặc từ bố (XY).

> [!loi-giai] Lời giải
> (a) Có NST Y → **nam**; thừa một X (XXY, 47 NST) → hội chứng **Klinefelter**.
>
> (b) Hai khả năng:
> - Mẹ giảm phân bị rối loạn, cặp XX không phân li → trứng **XX**; thụ tinh với tinh trùng **Y** → XXY.
> - Bố giảm phân I bị rối loạn, cặp XY không phân li → tinh trùng **XY**; thụ tinh với trứng **X** → XXY.

> [!em-co-biet]
> Nguy cơ sinh con mắc hội chứng Down tăng rõ khi tuổi mẹ cao (đặc biệt sau 35 tuổi), vì tế bào trứng được hình thành từ khi người mẹ còn là bào thai, "chờ" rất lâu nên dễ rối loạn phân li NST hơn. Đây là lí do bác sĩ khuyên phụ nữ mang thai lớn tuổi làm xét nghiệm trước sinh.

## 3. Y học tư vấn

### 3.1. Khái niệm

**Y học tư vấn** (di truyền học tư vấn) là lĩnh vực **cung cấp thông tin** cho người bệnh và những người **có nguy cơ** mắc bệnh di truyền hoặc sinh con mắc bệnh di truyền, về: **nguyên nhân, cơ chế** gây bệnh, **khả năng mắc bệnh** (xác suất), và **biện pháp hạn chế, phòng tránh** cho đời con (SGK tr. 71).

Nói đơn giản: bác sĩ tư vấn di truyền giúp gia đình **biết trước rủi ro** để **tự quyết định** một cách hiểu biết.

### 3.2. Cơ sở khoa học

Y học tư vấn dựa trên **ba trụ cột**:

**① Quy luật di truyền và di truyền học quần thể → tính xác suất.** Dựa vào phả hệ và các quy luật Mendel, liên kết với giới tính…, bác sĩ tính được xác suất sinh con mắc bệnh. Ví dụ: hai vợ chồng **cùng mang** allele lặn gây bệnh tan máu bẩm sinh (Aa × Aa) thì mỗi lần sinh, xác suất con bị bệnh là **1/4**.

**② Xét nghiệm NST và chỉ tiêu sinh hoá → chẩn đoán trước sinh.** Tế bào thai nhi và dịch ối, nhau thai được lấy ra để phân tích:

| Kĩ thuật | Khi nào | Làm gì | Phát hiện được |
|---|---|---|---|
| **Chọc dịch ối** | Thai khoảng 16 tuần | Dùng siêu âm định vị, lấy khoảng 20 mL dịch ối → li tâm tách **tế bào thai** và **dịch ối** → nuôi cấy tế bào khoảng 2 tuần | Phân tích NST (đột biến NST, NST giới tính), phân tích DNA; phân tích sinh hoá dịch ối phát hiện khoảng 40 loại rối loạn chuyển hoá |
| **Sinh thiết nhau thai** | Thai 11–13 tuần | Lấy tế bào nhau thai (có cùng nguồn gốc với thai) | Phân tích bộ NST: hội chứng Down, một số dị tật bẩm sinh |

**③ Kĩ thuật phân tử → xác định gene gây bệnh, chọn cách điều trị.** Ví dụ: người bị ung thư phổi có thể xét nghiệm để biết gene nào bị đột biến, từ đó bác sĩ chọn **thuốc đích** (thuốc hướng đích) đặc hiệu cho loại đột biến đó.

> [!bay]
> - Chọc dịch ối lấy **tế bào của thai** (bong ra trong dịch ối), không phải tế bào của mẹ. Vì vậy kết quả phản ánh bộ NST của **thai nhi**.
> - Kết quả xác suất của tư vấn là **rủi ro cho mỗi lần sinh**, không phải "cứ 4 con thì đúng 1 con bệnh".

### 3.3. Tư vấn

Từ kết quả phả hệ, di truyền tế bào và di truyền phân tử, các nhà khoa học đưa ra lời khuyên để **phòng tránh** và **chữa trị** một số bệnh di truyền:

**a) Tránh kết hôn cận huyết (giữa những người có họ hàng gần).** Người có họ hàng gần nhận chung allele từ tổ tiên, nên khả năng **cả hai cùng mang** một allele lặn gây bệnh cao hơn hẳn so với hai người không họ hàng. Khi cả hai cùng dị hợp thì xác suất sinh con bệnh (đồng hợp lặn) lên tới **25%** mỗi lần sinh.

> [!vi-du] Ví dụ 3
> Hai anh em họ (con của hai anh em ruột) kết hôn với nhau. Ông nội chung của họ mang allele lặn a gây bệnh (Aa); bà nội và những người "từ ngoài vào" dòng họ (mẹ của mỗi người) đều có kiểu gene AA. (a) Tính xác suất họ sinh con đầu lòng bị bệnh. (b) So sánh với một cặp vợ chồng không họ hàng, mỗi người có xác suất mang allele bệnh (Aa) là 1/50.

> [!goi-y] Gợi ý 1
> Ông nội Aa × bà nội AA → mỗi người con (bố của chàng trai, bố của cô gái) là Aa với xác suất bao nhiêu?

> [!goi-y] Gợi ý 2
> Bố Aa × mẹ AA → con là Aa với xác suất 1/2. Vậy chàng trai là Aa với xác suất 1/2 × 1/2. Cô gái tương tự. Chỉ khi **cả hai** là Aa mới sinh được con aa (xác suất 1/4).

> [!loi-giai] Lời giải
> (a) Mỗi người con của ông bà là Aa với xác suất 1/2 → chàng trai là Aa với xác suất 1/2 × 1/2 = 1/4; cô gái cũng là 1/4.
>
> Xác suất con đầu lòng bị bệnh = 1/4 × 1/4 × 1/4 = **1/64** (khoảng 1,6%).
>
> (b) Cặp không họ hàng: 1/50 × 1/50 × 1/4 = **1/10 000** (0,01%).
>
> So sánh: (1/64) : (1/10 000) ≈ **156 lần**. Đây là cơ sở khoa học của quy định **cấm kết hôn giữa những người có họ trong phạm vi ba đời** (Luật Hôn nhân và gia đình).

**Vì sao phần lớn người bị bệnh di truyền lặn lại có bố mẹ đều bình thường?** (Luyện tập 2, SGK tr. 74.) Vì allele gây bệnh thường **hiếm** và tồn tại chủ yếu ở **người dị hợp** (Aa) — người mang gene nhưng khoẻ mạnh. Ví dụ, nếu tần số allele a trong quần thể là 1/100 thì người aa chỉ chiếm khoảng 1/10 000, còn người Aa chiếm khoảng 2/100 — **gần 200 lần** nhiều hơn. Hầu hết các cuộc hôn nhân "có thể sinh con bệnh" là Aa × Aa (hai người bình thường), hơn nữa người mắc bệnh nặng thường ít có khả năng sinh con.

**b) Sàng lọc trước sinh.** Giúp bác sĩ đưa lời khuyên để bố mẹ có thể quyết định **đình chỉ thai kì** khi thai mắc bệnh di truyền, dị tật bẩm sinh **không thể chữa trị**. Đối tượng nên được sàng lọc: phụ nữ mang thai **lớn tuổi**; gia đình đã có con hoặc người thân mắc bệnh di truyền; vợ chồng từng tiếp xúc với tác nhân gây đột biến (phóng xạ, hoá chất độc)…

**c) Sàng lọc sơ sinh.** Xét nghiệm sinh hoá có thể phát hiện sớm một số **bệnh rối loạn chuyển hoá** di truyền. Ví dụ trẻ mắc **galactose huyết** (không chuyển hoá được đường galactose từ sữa) nếu được phát hiện sớm và ăn chế độ **hạn chế lactose** thì sẽ không biểu hiện triệu chứng bệnh. Gene bệnh vẫn còn, nhưng ta "chặn" được con đường gây hại.

**d) Thuốc hướng đích.** Biết gene gây bệnh (đặc biệt là ung thư), bác sĩ chọn thuốc riêng cho từng người bệnh, **tăng hiệu quả** và **giảm tác dụng phụ**.

> [!ung-dung] Sàng lọc sơ sinh ở Việt Nam
> Nhiều bệnh viện lấy vài giọt **máu gót chân** của trẻ trong vài ngày đầu sau sinh để sàng lọc một số bệnh như suy giáp bẩm sinh, thiếu enzyme G6PD, rối loạn chuyển hoá… Phát hiện sớm giúp điều trị hoặc ăn uống phù hợp ngay từ đầu, tránh tổn thương lâu dài.

> [!em-co-biet] Bảo vệ vốn gene của loài người
> Ngoài tư vấn và sàng lọc, mỗi người có thể góp phần giảm gánh nặng bệnh di truyền: hạn chế tiếp xúc tác nhân gây đột biến (thuốc trừ sâu, hoá chất độc, phóng xạ), bảo vệ môi trường, không kết hôn cận huyết, khám sức khoẻ tiền hôn nhân. Đó là cách bảo vệ **vốn gene** — kho allele mà thế hệ sau thừa hưởng.

## 4. Một số thành tựu và ứng dụng của liệu pháp gene

### 4.1. Khái niệm và thành tựu trong nghiên cứu

**Liệu pháp gene** là biện pháp chữa bệnh di truyền bằng cách **thay thế gene bệnh** trong tế bào người bệnh bằng **gene bình thường**, hoặc **chỉnh sửa gene bị bệnh** (SGK tr. 73).

Quy trình chung hiện nay (thử nghiệm trên **tế bào soma**, cho bệnh do **một gene** quy định):

1. Lấy tế bào của người bệnh ra khỏi cơ thể.
2. Đưa gene bình thường vào tế bào (thường dùng **virus làm thể truyền**, vì virus vốn có khả năng "chui" vào tế bào và đưa vật chất di truyền của nó vào).
3. Nuôi cấy cho tế bào đã sửa gene **nhân lên** với số lượng lớn.
4. Tiêm (truyền) trở lại cho bệnh nhân.

**Một số thành tựu** (SGK tr. 73):

- Năm 2007: dùng virus mang gene **RPE65** bình thường để chữa cho một số bệnh nhân **mù** do đột biến hiếm gặp ở gene này → thị lực cải thiện đáng kể.
- Năm 2009: thử nghiệm liệu pháp gene chữa bệnh **mù bẩm sinh Leber** cho 12 người → tất cả đều cải thiện thị lực.
- Năm 2018: dùng hệ thống **CRISPR – Cas9** chỉnh sửa gene gây bệnh **hồng cầu hình liềm** trong tế bào người, rồi tiêm tế bào đã chỉnh sửa trở lại cho bệnh nhân, cho kết quả khả quan.

> [!em-co-biet]
> Cuối năm 2023, liệu pháp đầu tiên dựa trên CRISPR – Cas9 để điều trị bệnh hồng cầu hình liềm đã được cơ quan quản lí dược phẩm ở Anh và Mỹ cấp phép. Tế bào gốc tạo máu của chính bệnh nhân được lấy ra, chỉnh sửa gene rồi truyền trở lại.

### 4.2. Ứng dụng và những rào cản

**Ứng dụng chủ yếu:** chữa các bệnh di truyền do **một gene** quy định. Điều kiện quan trọng: gene bình thường đưa vào phải được **duy trì và hoạt động suốt đời** người bệnh. Muốn vậy, tế bào nhận gene phải **có khả năng phân chia suốt đời**; nếu không, phải lặp lại việc thay gene nhiều lần — không khả thi.

→ **Tế bào gốc tuỷ xương** là đối tượng thích hợp: chúng phân chia liên tục để tạo ra các tế bào máu, nên phù hợp để chữa các bệnh liên quan đến **tế bào máu** và bệnh **suy giảm miễn dịch**.

**Rào cản về kĩ thuật:**

- Làm sao để gene chuyển vào hoạt động **đúng thời điểm, đúng vị trí**, tạo sản phẩm **đúng liều lượng** cần thiết?
- Làm sao để gene chuyển vào **không ảnh hưởng** đến hoạt động của các gene khác và của tế bào (ví dụ chèn sai chỗ làm hỏng một gene quan trọng)?

**Rào cản về đạo đức:** có nên chỉnh sửa hệ gene người không? Hệ gene được hình thành qua hàng triệu năm tiến hoá; can thiệp có thể gây hậu quả khó lường. Vì vậy liệu pháp gene hiện nay **chủ yếu còn ở giai đoạn nghiên cứu, thử nghiệm**.

> [!bay]
> - Liệu pháp gene hiện nay chỉ thử nghiệm trên **tế bào soma** → người bệnh có thể khỏi, nhưng **allele bệnh vẫn có thể truyền cho con** (vì tế bào sinh dục không được sửa).
> - Tế bào **hồng cầu trưởng thành** không có nhân, không phân chia → **không** phải đối tượng để đưa gene vào; đối tượng là **tế bào gốc** tạo máu.
> - "Đã được áp dụng rộng rãi" là **sai** — phần lớn vẫn là thử nghiệm.

## Dạng bài thi hay gặp

> [!ghi-nho] Quy trình 3 bước cho mọi bài phả hệ
> 1. **Xác định quy luật**: trội/lặn (dấu hiệu a, b) → NST thường/X (dấu hiệu c, d hoặc dữ kiện đề cho).
> 2. **Ghi kiểu gene chắc chắn** trước: người bệnh lặn (aa, X^a^Y, X^a^X^a^); người bình thường có bố/mẹ hoặc con bị bệnh lặn (NST thường) → Aa.
> 3. **Người chưa chắc**: viết **tỉ lệ kiểu gene** (thường 1/3 AA : 2/3 Aa) rồi mới tính xác suất cho đời con.

### Dạng 1. Xác định quy luật di truyền từ phả hệ

*Nhận biết:* cho phả hệ (hình hoặc mô tả bằng lời), hỏi bệnh trội/lặn, gene trên NST thường hay X; hoặc hỏi "phát biểu nào đúng".

*Phương pháp:*
1. Tìm dấu hiệu (a) hoặc (b) để kết luận trội/lặn.
2. Giả sử gene trên X → kiểm tra các cặp bố – con gái, mẹ – con trai. Có mâu thuẫn → NST thường.
3. Không có mâu thuẫn → đọc thêm dữ kiện đề cho (ví dụ "người X không mang allele gây bệnh").

> [!vi-du] Ví dụ 4
> Một phả hệ về bệnh M (do một gene có hai allele quy định): Thế hệ I: ông 1 bị bệnh, bà 2 bình thường. Thế hệ II: con của họ là con gái 3 và con trai 4, đều bình thường; người 3 lấy chồng 5 bình thường. Thế hệ III: con của 3 × 5 gồm con trai 6 bị bệnh, con gái 7 và con trai 8 bình thường. Biết người 5 **không mang** allele gây bệnh. Xác định quy luật di truyền của bệnh M.

> [!goi-y] Gợi ý 1
> Cặp 3 × 5 đều bình thường sinh con 6 bị bệnh → trội hay lặn?

> [!goi-y] Gợi ý 2
> Nếu gene trên NST thường, con 6 (aa) phải nhận a từ **cả** bố và mẹ. Người 5 có allele a không?

> [!loi-giai] Lời giải
> Bước 1: 3 × 5 bình thường sinh con bị bệnh → bệnh do allele **lặn**.
>
> Bước 2: Nếu gene trên NST thường, con 6 là aa phải nhận một allele a từ bố 5 → 5 phải là Aa, trái với dữ kiện "5 không mang allele gây bệnh". Loại.
>
> Bước 3: Nếu gene trên X: ông 1 là X^a^Y truyền X^a^ cho con gái 3 → 3 là X^A^X^a^ (bình thường); 3 × 5 (X^A^Y) → con trai 6 nhận X^a^ từ mẹ → X^a^Y bị bệnh. Hoàn toàn phù hợp.
>
> Kết luận: bệnh M do allele **lặn trên NST X** (vùng không tương đồng). Đây đúng là kiểu "**ông ngoại → mẹ → cháu trai**".

*Bẫy:* nếu **bỏ** dữ kiện "5 không mang allele gây bệnh" thì phả hệ này phù hợp với **cả hai** khả năng (NST thường hoặc X) — không được vội kết luận "vì chỉ nam bị bệnh nên trên X".

### Dạng 2. Tính xác suất sinh con mắc bệnh (một bệnh, NST thường)

*Nhận biết:* "xác suất cặp vợ chồng … sinh con bị bệnh / con trai không bị bệnh / hai con…".

*Phương pháp:*
1. Viết tỉ lệ kiểu gene của bố và mẹ. Người bình thường có bố mẹ Aa × Aa → **1/3 AA : 2/3 Aa**.
2. Đổi ra **tỉ lệ giao tử**: (1/3 AA : 2/3 Aa) cho **2/3 A : 1/3 a**.
3. Con aa = (giao tử a của bố) × (giao tử a của mẹ). Hỏi "con trai/con gái" thì nhân thêm 1/2.
4. Hỏi **nhiều con** → **không** được nhân thẳng xác suất từng con; phải chia trường hợp kiểu gene bố mẹ (xem ví dụ).

> [!vi-du] Ví dụ 5
> Tiếp tục với phả hệ ở Hình 3 (bệnh do allele lặn trên NST thường). Theo lí thuyết, tính xác suất để cặp vợ chồng 6 – 7: (a) sinh con đầu lòng bị bệnh; (b) sinh con đầu lòng là con trai bị bệnh; (c) sinh con đầu lòng không mang allele gây bệnh; (d) sinh hai người con đều không bị bệnh.

> [!goi-y] Gợi ý 1
> Bố mẹ của người 6 (cặp 1 – 2) có kiểu gene gì? Người 6 bình thường, vậy tỉ lệ kiểu gene của 6 là bao nhiêu? Người 7 tương tự.

> [!goi-y] Gợi ý 2
> Mỗi người (1/3 AA : 2/3 Aa) cho giao tử 2/3 A : 1/3 a. Câu (c) là con AA.

> [!goi-y] Gợi ý 3
> Câu (d): chia hai trường hợp — cả 6 và 7 đều là Aa (xác suất 4/9), hoặc không phải cả hai đều Aa (5/9). Trong mỗi trường hợp, hai lần sinh mới độc lập với nhau.

> [!loi-giai] Lời giải
> Bước 1: 1 × 2 bình thường sinh 5 bị bệnh → 1, 2 đều Aa → 6 có tỉ lệ 1/3 AA : 2/3 Aa. Tương tự 3, 4 đều Aa → 7 có tỉ lệ 1/3 AA : 2/3 Aa.
>
> Bước 2: Giao tử của mỗi người: 2/3 A : 1/3 a.
>
> (a) Con aa = 1/3 × 1/3 = **1/9**.
>
> (b) Con trai bị bệnh = 1/9 × 1/2 = **1/18**.
>
> (c) Con AA = 2/3 × 2/3 = **4/9**.
>
> (d) - Nếu 6 và 7 đều Aa (xác suất 2/3 × 2/3 = 4/9): mỗi con bình thường với xác suất 3/4 → hai con đều bình thường: (3/4)^2^ = 9/16.
> - Nếu không phải cả hai đều Aa (xác suất 5/9): không thể sinh con bệnh → hai con chắc chắn bình thường.
>
> Xác suất = 4/9 × 9/16 + 5/9 × 1 = 1/4 + 5/9 = **29/36** ≈ 0,81.

*Bẫy:* tính (d) bằng (1 − 1/9)^2^ = 64/81 ≈ 0,79 là **sai**. Lí do: hai lần sinh **không độc lập** khi chưa biết kiểu gene bố mẹ — nếu bố mẹ là Aa × Aa thì "rủi ro" ấy áp dụng cho **cả hai** đứa con cùng lúc. Chỉ khi đã biết chắc kiểu gene bố mẹ thì các lần sinh mới độc lập.

### Dạng 3. Phả hệ hai bệnh (một bệnh trên NST thường, một bệnh trên X)

*Nhận biết:* đề cho hai bệnh, thường là bạch tạng/bệnh P (lặn, NST thường) với máu khó đông hoặc mù màu (lặn, trên X), hai gene phân li độc lập.

*Phương pháp:* **tách riêng từng bệnh**, tính xác suất từng bệnh, rồi **nhân** (vì hai gene nằm trên hai cặp NST khác nhau). Chú ý: với bệnh trên X, nếu đề hỏi "con trai…", "con gái…" thì giới tính đã gắn vào phép tính bệnh X — **không nhân thêm 1/2 hai lần**.

> [!vi-du] Ví dụ 6
> Bệnh P do allele lặn a trên NST thường; bệnh máu khó đông do allele lặn h trên vùng không tương đồng của X. Người vợ bình thường, có bố bị bệnh P, có anh trai bị máu khó đông (bố mẹ cô không bị máu khó đông). Người chồng bình thường, có em gái bị bệnh P (bố mẹ anh đều bình thường). Theo lí thuyết, tính xác suất cặp vợ chồng này sinh con đầu lòng: (a) không mắc bệnh nào; (b) mắc cả hai bệnh.

> [!goi-y] Gợi ý 1
> Bệnh P: vợ có bố aa → vợ chắc chắn là gì? Chồng có em gái bệnh, bố mẹ bình thường → tỉ lệ kiểu gene của chồng?

> [!goi-y] Gợi ý 2
> Máu khó đông: anh trai vợ X^h^Y nhận X^h^ từ mẹ → mẹ vợ X^H^X^h^, bố vợ X^H^Y. Vậy vợ là X^H^X^H^ hay X^H^X^h^ với xác suất bao nhiêu? Chồng bình thường: X^H^Y.

> [!loi-giai] Lời giải
> **Bệnh P:** vợ Aa (bố aa). Chồng 1/3 AA : 2/3 Aa → giao tử a = 1/3. Con bị P = 1/2 × 1/3 = **1/6**; không bị P = 5/6.
>
> **Máu khó đông:** vợ 1/2 X^H^X^H^ : 1/2 X^H^X^h^ → giao tử X^h^ = 1/4. Chồng X^H^Y → con bị bệnh chỉ có thể là con trai X^h^Y = 1/4 (X^h^) × 1/2 (Y) = **1/8**; không bị = 7/8.
>
> (a) Không mắc bệnh nào = 5/6 × 7/8 = **35/48** ≈ 0,73.
>
> (b) Mắc cả hai bệnh = 1/6 × 1/8 = **1/48** ≈ 0,02.

*Bẫy:* nhân thêm 1/2 vào xác suất máu khó đông khi đề không hỏi giới tính; hoặc quên rằng chồng bình thường X^H^Y thì **mọi con gái** đều không bị máu khó đông.

### Dạng 4. Nhận biết hội chứng do đột biến NST, đếm số NST

*Nhận biết:* cho karyotype (hoặc mô tả: "47 NST, 3 chiếc số 21"), hỏi tên hội chứng, giới tính, số NST trong tế bào ở một kì phân bào.

*Phương pháp:* đếm tổng số NST → tìm cặp bất thường → tra bảng ở mục 2.3. Số NST trong tế bào ở các kì nguyên phân tính như bình thường nhưng thay 2n = 46 bằng số NST thực tế của người đó.

> [!vi-du] Ví dụ 7
> Một bé gái mắc hội chứng Down do thừa một NST số 21. (a) Tế bào sinh dưỡng của bé có bao nhiêu NST? (b) Ở kì sau của nguyên phân, một tế bào của bé có bao nhiêu NST đơn?

> [!goi-y] Gợi ý 1
> Thể ba: 2n + 1. Người bình thường 2n = 46.

> [!goi-y] Gợi ý 2
> Kì sau nguyên phân: mỗi NST kép tách thành 2 NST đơn, chưa chia tế bào → số NST đơn gấp đôi.

> [!loi-giai] Lời giải
> (a) 2n + 1 = 46 + 1 = **47** NST.
>
> (b) Kì sau nguyên phân: 47 × 2 = **94** NST đơn.

*Bẫy:* nhầm Turner (45, nữ) với Klinefelter (47, nam); nghĩ bạch tạng, máu khó đông thấy được trên karyotype.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Di truyền học người | Nghiên cứu di truyền, biến dị ở người (nghiên cứu cơ bản) |
| Di truyền y học | Cơ chế phát sinh, di truyền của bệnh → phòng, chữa (nghiên cứu ứng dụng) |
| Phương pháp phả hệ | Sơ đồ ghi tính trạng trong dòng họ → trội/lặn, NST thường/giới tính; hạn chế: ít con, cần nhiều phả hệ |
| Phương pháp di truyền tế bào | Nuôi cấy bạch cầu + colchicine (dừng kì giữa) → karyotype 1–22 + XX/XY → phát hiện đột biến NST, một số ung thư |
| Y học tư vấn | Cung cấp thông tin nguyên nhân, cơ chế, xác suất, cách phòng tránh; cơ sở: quy luật di truyền, xét nghiệm NST – sinh hoá (chọc ối, sinh thiết nhau thai), kĩ thuật phân tử |
| Tư vấn | Tránh kết hôn cận huyết; sàng lọc trước sinh, sơ sinh; thuốc hướng đích |
| Liệu pháp gene | Thay/chỉnh sửa gene bệnh trong tế bào soma; tế bào gốc tuỷ xương phù hợp; còn thử nghiệm, rào cản kĩ thuật và đạo đức |

**Đọc phả hệ:**

| Dấu hiệu | Kết luận |
|---|---|
| Bố mẹ bình thường → con bệnh | Lặn |
| Bố mẹ bệnh → con bình thường | Trội |
| Bệnh lặn: con gái bệnh, bố bình thường (hoặc mẹ bệnh, con trai bình thường) | NST thường |
| Bệnh trội: bố bệnh, con gái bình thường (hoặc mẹ bình thường, con trai bệnh) | NST thường |

**Công thức xác suất hay dùng:** người bình thường có bố mẹ Aa × Aa → 1/3 AA : 2/3 Aa → giao tử 2/3 A : 1/3 a. Hai người như vậy kết hôn → con bệnh 1/9; con AA 4/9; hai con đều bình thường 29/36.

**Karyotype:** 47 + ba chiếc 21 → Down · 45, XO → Turner (nữ) · 47, XXY → Klinefelter (nam) · 47 + ba chiếc 13 → Patau · 47 + ba chiếc 18 → Edwards.
