---
title: Đột biến nhiễm sắc thể
thoi-gian: 50 phút
muc-tieu:
  - Phát biểu được khái niệm đột biến NST; phân biệt đột biến cấu trúc với đột biến số lượng (lệch bội, đa bội).
  - Trình bày được nguyên nhân, cơ chế phát sinh và phân biệt bốn dạng đột biến cấu trúc NST: mất đoạn, lặp đoạn, đảo đoạn, chuyển đoạn.
  - Trình bày được nguyên nhân, cơ chế phát sinh thể lệch bội (do NST không phân li trong giảm phân) và thể đa bội (tự đa bội, dị đa bội); lấy được ví dụ minh hoạ.
  - Phân tích được tác hại của các dạng đột biến NST và vai trò của chúng trong tiến hoá, nghiên cứu di truyền, chọn giống.
  - Giải thích được mối quan hệ giữa di truyền và biến dị.
  - Giải được các dạng bài: nhận biết dạng đột biến từ trình tự gene, đếm số NST của thể đột biến, tính tỉ lệ giao tử – hợp tử khi NST không phân li, giao tử của thể tứ bội và thể ba.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Đột biến NST** = biến đổi về **cấu trúc** (mất đoạn, lặp đoạn, đảo đoạn, chuyển đoạn) hoặc **số lượng** NST (lệch bội, đa bội).
> 2. Đột biến cấu trúc do NST bị **đứt gãy rồi nối lại sai** (tác nhân vật lí, hoá học) hoặc do **trao đổi chéo không cân** giữa các đoạn tương đồng.
> 3. **Lệch bội** (2n + 1, 2n − 1, 2n − 2…): thay đổi ở **một hoặc vài cặp** NST, do cặp NST **không phân li** trong giảm phân → giao tử n + 1, n − 1.
> 4. **Đa bội**: bộ NST đơn bội tăng lên **số nguyên lần lớn hơn 2** — tự đa bội (3n, 4n… cùng một loài) và dị đa bội (2n~A~ + 2n~B~, lai xa kèm đa bội hoá).
> 5. Phần lớn đột biến NST có hại vì làm **mất cân bằng gene**, nhưng chúng là nguyên liệu cho **tiến hoá** (lặp đoạn, chuyển đoạn, đa bội hình thành loài mới) và **chọn giống** (cây tam bội không hạt, cây đa bội to khoẻ).

> [!nen-tang] Nhớ lại từ Bài 7 và lớp 10
> - Mỗi NST có **tâm động** (nơi đính vào thoi phân bào) chia NST thành hai vai, hai đầu có **đầu mút** bảo vệ. Gene nằm thành hàng trên NST, mỗi gene ở một **locus**.
> - Tế bào sinh dưỡng có bộ NST **lưỡng bội 2n** gồm n **cặp tương đồng**; giao tử có bộ **đơn bội n** (mỗi cặp một chiếc). Người: 2n = 46.
> - **Giảm phân I**: hai NST kép của mỗi cặp tương đồng **tách nhau** về hai tế bào. **Giảm phân II**: hai **chromatid** của mỗi NST kép tách nhau. Muốn NST di chuyển về hai cực, tế bào cần **thoi phân bào** được tạo từ các **vi ống**.
>
> Hai ý cuối là "chìa khoá" của bài này: nếu một cặp NST **không tách** được (không phân li) → giao tử thừa/thiếu một chiếc NST; nếu **thoi phân bào** không hình thành → cả bộ NST bị "kẹt" lại trong một tế bào → đa bội.

**Câu hỏi mở bài.** Một người có cặp NST giới tính XY nhưng lại mang kiểu hình **nữ**; khi soi bộ NST, người ta thấy NST Y của người này **ngắn hơn** bình thường. Vì sao lại như vậy? Em sẽ trả lời được ở mục 5.2.

## 1. Khái niệm đột biến nhiễm sắc thể

**Đột biến NST** là những biến đổi về **cấu trúc** hoặc **số lượng** NST của loài. Khác với đột biến gene (Bài 4) chỉ liên quan đến một hoặc vài cặp nucleotide trong một gene, đột biến NST thường liên quan đến **cả một đoạn NST chứa nhiều gene**, hoặc **cả một NST**, thậm chí **cả bộ NST** — nên nhiều đột biến NST có thể **nhìn thấy dưới kính hiển vi** (Bài 14 sẽ thực hành quan sát).

| Nhóm | Dạng | Thay đổi gì? |
|---|---|---|
| **Đột biến cấu trúc** | mất đoạn, lặp đoạn, đảo đoạn, chuyển đoạn | số lượng, trật tự hoặc vị trí các gene **trên NST** |
| **Đột biến số lượng — lệch bội** | thể một (2n − 1), thể ba (2n + 1), thể không (2n − 2)… | số NST ở **một hoặc vài cặp** |
| **Đột biến số lượng — đa bội** | tam bội 3n, tứ bội 4n…; song lưỡng bội 2n~A~ + 2n~B~ | **cả bộ NST** tăng lên số nguyên lần (lớn hơn 2) |

> [!bay]
> - "Đa bội" là bộ NST đơn bội tăng lên **số nguyên lần lớn hơn 2** (3n, 4n, 5n…). Bộ 2n là lưỡng bội bình thường, **không** phải đa bội.
> - Thể ba (2n + 1) **không** phải "tam bội" (3n). Thể ba chỉ thừa **một chiếc** NST ở **một cặp**; tam bội thừa **cả một bộ** n NST.

## 2. Đột biến cấu trúc nhiễm sắc thể

### 2.1. Nguyên nhân và cơ chế phát sinh

**Nguyên nhân:** tác nhân **vật lí** (tia X, tia gamma…), tác nhân **hoá học**, hoặc do **trao đổi chéo** giữa các đoạn có trình tự nucleotide tương đồng trên các NST.

**Cơ chế** — có hai con đường chính:

1. **Đứt gãy rồi nối lại sai.** Tia phóng xạ mang năng lượng cao có thể làm đứt **cùng lúc cả hai mạch** của phân tử DNA. Tế bào cố "vá" lại chỗ đứt, nhưng các đoạn có thể bị nối theo cách khác ban đầu hoặc **không được nối lại**:
   - đoạn bị đứt rơi mất, không được nối → **mất đoạn**;
   - đoạn bị đứt được nối lại nhưng **quay ngược 180°** → **đảo đoạn**;
   - đoạn bị đứt được nối vào **vị trí khác** (trên NST đó hoặc NST khác) → **chuyển đoạn**.
2. **Trao đổi chéo không cân.** Trong giảm phân, khi các NST tiếp hợp, chúng có thể bắt cặp **lệch** nhau tại các đoạn có trình tự giống nhau rồi trao đổi chéo. Kết quả: một chromatid **nhận thêm** một đoạn (**lặp đoạn**), chromatid kia **mất** đúng đoạn đó (**mất đoạn**). Đây là lí do mất đoạn và lặp đoạn thường "đi cùng nhau".

> [!em-co-biet] Vì sao gọi là "trao đổi chéo không cân"?
> Trao đổi chéo bình thường (Bài 11) xảy ra giữa hai chromatid bắt cặp **thẳng hàng**: đoạn đổi đi và đoạn nhận về dài bằng nhau, mỗi chromatid vẫn đủ gene. Nếu hai chromatid bắt cặp **lệch** (ví dụ vì trên NST có những trình tự lặp lại giống nhau), điểm trao đổi trên hai chromatid không ở cùng vị trí → một bên "lời" một đoạn, một bên "lỗ" một đoạn.

### 2.2. Các dạng đột biến cấu trúc

Quy ước: các chữ cái là các đoạn NST (mỗi đoạn mang gene), dấu • là tâm động. NST ban đầu: **ABCD•EFGH**.

![Hình 1. Bốn dạng đột biến cấu trúc NST, mô tả bằng trình tự các đoạn gene](hinh-1-cau-truc.svg)

**a) Mất đoạn** — một đoạn NST bị đứt và không được nối lại → NST **ngắn đi**, **mất gene**.

- Ví dụ: ABCD•EFGH → ABCD•EH (mất đoạn FG).
- Vì mất vật chất di truyền nên mất đoạn **phần nhiều có hại**; đoạn mất càng dài, càng nhiều gene quan trọng thì càng nặng. Đoạn mất lớn có thể nhận ra dưới **kính hiển vi quang học** (NST ngắn hơn bình thường).

**b) Lặp đoạn** — một đoạn NST được **lặp lại một hoặc vài lần** → NST **dài ra**, **tăng số bản sao** của các gene trong đoạn đó.

- Ví dụ: ABCD•EFGH → ABCD•EFG**FG**H (đoạn FG lặp thêm một lần).
- Không mất gene nào, nhưng **lượng sản phẩm** của gene bị lặp tăng lên → có thể làm **mất cân bằng gene**, gây hại hoặc làm thay đổi kiểu hình.

**c) Đảo đoạn** — một đoạn NST bị đứt, **quay ngược 180°** rồi nối lại vào chỗ cũ.

- Ví dụ: ABCD•EFGH → ABCD•**GFE**H (đoạn EFG bị đảo).
- **Không làm mất hay thêm** vật chất di truyền, chiều dài NST **không đổi** — chỉ **trật tự** gene thay đổi.
- Tuy nhiên, nếu **điểm đứt** rơi đúng vào giữa một gene thì gene đó bị hỏng; hai phần của hai gene khác nhau ghép lại cũng có thể tạo ra một **gene mới**.
- Đoạn bị đảo có thể **chứa tâm động** (ví dụ đảo đoạn C D • E: ABCD•EFGH → AB**E•DC**FGH — tâm động cũng "quay" theo, nên vị trí tâm động trên NST thay đổi) hoặc **không chứa** tâm động (như ví dụ trên).

**d) Chuyển đoạn** — một đoạn NST được chuyển từ vị trí này sang **vị trí khác**: trên **cùng một NST**, hoặc **sang NST khác** (thường là NST **không tương đồng**).

- Chuyển đoạn trong một NST: ABCD•EFGH → AD•EF**BC**GH — đoạn BC rời vai trái, chuyển sang vai phải (nằm giữa F và G).
- Chuyển đoạn giữa hai NST, thường gặp nhất là **chuyển đoạn tương hỗ** (hai NST **đổi đoạn** cho nhau): ABCD•EFGH và MNO•PQR → ABCD•EF**QR** và MNO•P**GH**. Cũng có chuyển đoạn **không tương hỗ**: một đoạn chuyển sang NST khác mà không nhận lại gì.
- Hệ quả: gene đổi sang NST khác → **nhóm gene liên kết thay đổi** (Bài 11); vị trí gene thay đổi có thể làm thay đổi **mức độ biểu hiện** của gene; kích thước các NST có thể thay đổi.

> [!bay] Lưu ý thuật ngữ "chuyển đoạn tương đồng" trong SGK
> SGK tr. 61 viết: chuyển đoạn giữa các NST "được gọi là chuyển đoạn tương đồng". Cách gọi này dễ gây hiểu nhầm: chuyển đoạn thường xảy ra giữa hai NST **không tương đồng**, và tên gọi chuẩn của dạng hai NST đổi đoạn cho nhau là **chuyển đoạn tương hỗ** (dạng một chiều là **không tương hỗ**). Đi thi, em cứ hiểu và dùng như sau: trao đổi đoạn giữa hai NST **tương đồng** (giữa các chromatid không chị em) là **trao đổi chéo** (Bài 11); trao đổi đoạn giữa hai NST **không tương đồng** là **chuyển đoạn** — làm thay đổi nhóm gene liên kết.

> [!bay] Đảo đoạn hay chuyển đoạn trong một NST?
> Cả hai đều giữ nguyên tập hợp gene trên NST, nên đề thi rất hay cài bẫy. Cách phân biệt:
> - **Đảo đoạn**: đoạn bị biến đổi vẫn **nằm ở chỗ cũ**, chỉ **đọc ngược**: EFG → GFE. Các gene ngoài đoạn đó giữ nguyên vị trí.
> - **Chuyển đoạn**: đoạn bị biến đổi **dời sang chỗ khác**, có thể vẫn giữ chiều cũ (BC vẫn là BC nhưng nằm ở vị trí mới).
>
> Mẹo: tìm đoạn khác với NST gốc; nếu viết ngược đoạn đó lại mà khớp với **đúng vị trí cũ** → đảo đoạn.

> [!vi-du] Ví dụ 1
> Một NST có trình tự các đoạn gene là **MNOP•QRST**. Hãy cho biết mỗi NST sau được tạo ra do dạng đột biến cấu trúc nào: (1) MNOP•QRSRST; (2) MNOP•QST; (3) MQ•PONRST; (4) MOP•QRNST.

> [!goi-y] Gợi ý 1
> So sánh **số đoạn** trước: thừa đoạn → lặp; thiếu đoạn → mất; đủ đoạn → đảo hoặc chuyển.

> [!goi-y] Gợi ý 2
> Với các NST đủ đoạn, xét xem đoạn thay đổi bị **đọc ngược tại chỗ** hay **dời sang chỗ khác**. Chú ý vị trí của tâm động: đoạn NOP•Q có chứa tâm động.

> [!loi-giai] Lời giải
> (1) MNOP•QRS**RS**T: đoạn RS xuất hiện hai lần → **lặp đoạn**.
>
> (2) MNOP•QST: thiếu đoạn R → **mất đoạn**.
>
> (3) M**Q•PON**RST: đoạn N O P • Q viết ngược là Q • P O N (tâm động quay theo, giờ nằm giữa Q và P), nằm đúng chỗ cũ → **đảo đoạn chứa tâm động**.
>
> (4) MOP•QR**N**ST: đoạn N rời vai trái, sang nằm giữa R và S ở vai phải, chiều không đổi → **chuyển đoạn trong một NST**.

## 3. Đột biến số lượng nhiễm sắc thể

### 3.1. Đột biến lệch bội

**Khái niệm:** đột biến lệch bội (còn gọi là dị bội) làm thay đổi số lượng NST ở **một hoặc một vài cặp** NST.

**Nguyên nhân:** đến nay vẫn chưa rõ hoá chất hay tác nhân nào là nguyên nhân chính. Ở người, tần số sinh con mắc **hội chứng Down** (thừa NST 21) **tăng theo tuổi người mẹ** (nhiều trường hợp do cặp NST 21 không phân li trong giảm phân I ở mẹ), trong khi không thấy liên quan rõ với tuổi người bố (SGK tr. 62, 67).

**Cơ chế:** trong giảm phân, **một hoặc vài cặp NST không phân li** → tạo giao tử thừa một chiếc (n + 1) hoặc thiếu một chiếc (n − 1) của cặp đó. Giao tử lệch bội kết hợp với giao tử bình thường (n):

- (n + 1) + n → hợp tử **2n + 1** (thể ba);
- (n − 1) + n → hợp tử **2n − 1** (thể một).

Có hai trường hợp không phân li:

![Hình 2. Một cặp NST không phân li ở giảm phân I hoặc ở giảm phân II tạo giao tử lệch bội](hinh-2-khong-phan-li.svg)

| Không phân li ở | Diễn biến | Giao tử về cặp NST đó |
|---|---|---|
| **Giảm phân I** | Hai NST kép của cặp tương đồng cùng đi về một cực | **½ (n + 1) : ½ (n − 1)** — giao tử n + 1 chứa **hai chiếc khác nhau** của cặp (một từ bố, một từ mẹ) |
| **Giảm phân II** (ở một tế bào con) | Hai chromatid của một NST kép không tách nhau | **¼ (n + 1) : ¼ (n − 1) : ½ n** — giao tử n + 1 chứa **hai bản giống hệt nhau** |

**Vì sao điều này quan trọng khi làm bài?** Vì nhìn vào **allele** trong giao tử thừa NST, em đoán được lần phân bào nào bị lỗi. Ví dụ, cơ thể Aa: giao tử **Aa** ↔ lỗi giảm phân I; giao tử **AA** hoặc **aa** ↔ lỗi giảm phân II.

**Các dạng lệch bội** (n là số cặp NST của loài):

| Tên | Kí hiệu | Đặc điểm | Ví dụ ở người (2n = 46) |
|---|---|---|---|
| Thể ba | 2n + 1 | một cặp có **3** chiếc | Down: 3 NST 21 (47 NST) |
| Thể một | 2n − 1 | một cặp chỉ còn **1** chiếc | Turner: XO (45 NST) |
| Thể không | 2n − 2 | **mất cả** một cặp | (gây chết) |
| Thể bốn | 2n + 2 | một cặp có **4** chiếc | |
| Thể ba kép | 2n + 1 + 1 | **hai** cặp khác nhau, mỗi cặp có 3 chiếc | |
| Thể một kép | 2n − 1 − 1 | **hai** cặp khác nhau, mỗi cặp có 1 chiếc | |

Với NST giới tính ở người, người ta thường ghi trực tiếp: **XXY** (hội chứng Klinefelter), **XO** (hội chứng Turner, O nghĩa là thiếu một NST giới tính), **XXX**, **XYY**.

> [!bay]
> - **Thể không (2n − 2)** là mất **cả một cặp** (2 chiếc **cùng cặp**); còn **thể một kép (2n − 1 − 1)** cũng có 2n − 2 NST nhưng là mất 1 chiếc ở **hai cặp khác nhau**. Cùng số NST, khác tên gọi!
> - Tương tự: **thể bốn (2n + 2)** khác **thể ba kép (2n + 1 + 1)**.
> - Số **loại** thể ba tối đa của loài bằng **số cặp NST n** (thừa ở cặp 1, cặp 2…, cặp n) — không phải 2n.

> [!vi-du] Ví dụ 2
> Một loài thực vật có bộ NST 2n = 18. Hãy tính: a) số NST trong tế bào sinh dưỡng của thể một, thể ba, thể không, thể ba kép; b) số loại thể ba khác nhau tối đa; c) số loại thể ba kép khác nhau tối đa.

> [!goi-y] Gợi ý 1
> 2n = 18 → n = 9 cặp. Mỗi dấu "+1" là thêm 1 NST, mỗi "−1" là bớt 1 NST.

> [!goi-y] Gợi ý 2
> Thể ba có thể xảy ra ở bất kì cặp nào trong 9 cặp. Thể ba kép cần chọn **2 cặp khác nhau** trong 9 cặp — thứ tự không quan trọng → tổ hợp $C_9^2$.

> [!loi-giai] Lời giải
> a) Thể một 2n − 1 = **17**; thể ba 2n + 1 = **19**; thể không 2n − 2 = **16**; thể ba kép 2n + 1 + 1 = **20**.
>
> b) Số loại thể ba = n = **9**.
>
> c) Số loại thể ba kép = $C_9^2 = \dfrac{9\cdot 8}{2} = 36$.

> [!vi-du] Ví dụ 3
> Một cặp vợ chồng có bộ NST bình thường sinh được một con gái có bộ NST giới tính **XO**. Hãy nêu các khả năng về cơ chế phát sinh.

> [!goi-y] Gợi ý 1
> Hợp tử XO = giao tử mang X + giao tử **không mang NST giới tính** (kí hiệu O). Giao tử O có thể đến từ bố hay mẹ?

> [!goi-y] Gợi ý 2
> Mẹ XX bình thường cho giao tử X; bố XY bình thường cho X hoặc Y. Giao tử O xuất hiện khi cặp NST giới tính không phân li (ở giảm phân I hoặc II) — chiếc X/Y "đi lạc" sang giao tử kia.

> [!loi-giai] Lời giải
> Khả năng 1: ở **bố**, cặp XY không phân li (ở giảm phân I; hoặc ở giảm phân II của tế bào chứa X hay chứa Y) → có giao tử **O**; giao tử O kết hợp với trứng X → **XO**.
>
> Khả năng 2: ở **mẹ**, cặp XX không phân li (giảm phân I hoặc II) → trứng **O**; trứng O kết hợp với tinh trùng X → **XO**.
>
> Chỉ dựa vào bộ NST thì chưa biết là khả năng nào; muốn xác định cần thêm thông tin, ví dụ một bệnh do gene trên X mà người con có giống bố hay giống mẹ.

> [!meo] Truy nguồn gốc giao tử bất thường ở người
> - **XYY**: hai chiếc Y chỉ có thể đến từ **bố** → tinh trùng **YY** do hai chromatid của Y không tách ở **giảm phân II**.
> - **XXY**: hoặc trứng **XX** (mẹ, GP I hoặc GP II) + tinh trùng Y; hoặc trứng X + tinh trùng **XY** (bố, chắc chắn lỗi **GP I**, vì chỉ GP I mới có X và Y cùng tế bào).

### 3.2. Đột biến đa bội

**Khái niệm:** bộ NST đơn bội (n) trong tế bào tăng lên một số nguyên lần **lớn hơn 2**. Số bộ NST đơn bội trong tế bào gọi là **mức bội thể**.

**Nguyên nhân:** phần lớn thể đa bội trong tự nhiên chưa rõ nguyên nhân. Các nhà khoa học tìm được chất **colchicine** — chất **ngăn cản sự hình thành vi ống**, do đó **không tạo được thoi phân bào**. NST vẫn nhân đôi nhưng không được kéo về hai cực, tế bào không phân chia → bộ NST tăng gấp đôi. Vì vậy colchicine được dùng để **gây đa bội ở thực vật**.

**Cơ chế** — ba con đường (Hình 3):

![Hình 3. Ba con đường hình thành thể đa bội](hinh-3-da-boi.svg)

1. **Tự đa bội qua nguyên phân:** ở hợp tử hoặc tế bào phôi sớm (2n), NST nhân đôi nhưng tế bào không phân chia → tế bào **4n**; tế bào này nguyên phân tiếp tạo cơ thể tứ bội. Nếu xảy ra ở **đỉnh sinh trưởng** của cành thì chỉ cành đó mang tế bào 4n.
2. **Tự đa bội qua giảm phân và thụ tinh:** giảm phân bị rối loạn, **tất cả** các cặp NST không phân li → giao tử **2n**. Giao tử 2n + giao tử n → hợp tử **3n** (tam bội); giao tử 2n + giao tử 2n → hợp tử **4n** (tứ bội).
3. **Dị đa bội (song lưỡng bội):** lai xa giữa loài A và loài B → con lai **n~A~ + n~B~**. Con lai này thường **bất thụ** vì NST của loài A và loài B **không có cặp tương đồng** để tiếp hợp trong giảm phân. Nếu bộ NST của con lai được **nhân đôi** (đa bội hoá) → **2n~A~ + 2n~B~**: mỗi NST lại có "bạn" tương đồng → giảm phân bình thường, **hữu thụ** — đó có thể là một **loài mới**.

**Các dạng đột biến đa bội:**

| | Tự đa bội (đa bội cùng nguồn) | Dị đa bội (đa bội khác nguồn, song lưỡng bội) |
|---|---|---|
| Nguồn gốc bộ NST | tăng số bộ NST **của cùng một loài** | **kết hợp** bộ NST của **hai loài** khác nhau |
| Kí hiệu | 3n, 4n, 5n, 6n… | 2n~A~ + 2n~B~ |
| Ví dụ | chuối trồng tam bội (3n), dưa hấu và nho tam bội không hạt | lúa mì trồng hiện nay là loài **lục bội (6n)**, hình thành do lai xa nhiều lần kèm đa bội hoá |

Trong tự đa bội, người ta phân biệt **đa bội chẵn** (4n, 6n…) và **đa bội lẻ** (3n, 5n…):

- **Đa bội lẻ (3n…) thường bất thụ.** Vì sao? Mỗi "cặp" có 3 chiếc; khi giảm phân, 3 chiếc không chia đều cho hai cực được (một bên 2, một bên 1), và n "cặp" như vậy phân li ngẫu nhiên → hầu hết giao tử có số NST lệch, mất cân bằng gene, không có khả năng sống. Đây chính là lí do quả của cây tam bội **không có hạt**.
- **Đa bội chẵn (4n…) thường hữu thụ** hơn, vì các NST có thể bắt cặp và chia đều.

**Đặc điểm của thể đa bội** (thấy rõ ở thực vật): hàm lượng DNA trong tế bào tăng gấp bội → tổng hợp nhiều chất hơn → **tế bào to**, cơ quan sinh dưỡng (thân, lá, củ, quả) **to**, **sinh trưởng mạnh**, thường chống chịu tốt hơn dạng lưỡng bội.

> [!bay] Lệch bội hay đa bội?
> | | Lệch bội | Đa bội |
> |---|---|---|
> | Phạm vi | 1 hoặc vài **cặp** NST | **toàn bộ** các cặp NST |
> | Cơ chế | 1 (vài) cặp không phân li | **tất cả** các cặp không phân li (thoi phân bào không hình thành) hoặc lai xa + đa bội hoá |
> | Cân bằng gene | **mất cân bằng** → thường có hại, gây chết | đa bội chẵn **ít mất cân bằng** hơn |
> | Ví dụ | 2n + 1, 2n − 1 | 3n, 4n, 2n~A~ + 2n~B~ |

> [!vi-du] Ví dụ 4
> Dưa hấu có 2n = 22. Từ giống dưa hấu lưỡng bội, người ta muốn tạo dưa hấu tam bội không hạt. a) Nêu cách làm. b) Tế bào lá của cây tứ bội và cây tam bội có bao nhiêu NST? c) Vì sao quả của cây tam bội không có hạt?

> [!goi-y] Gợi ý 1
> Tam bội = giao tử 2n + giao tử n. Lấy giao tử 2n ở đâu một cách "chủ động"? Cây tứ bội (4n) giảm phân bình thường cho giao tử 2n.

> [!goi-y] Gợi ý 2
> Dùng colchicine để tạo cây 4n từ cây 2n, rồi lai 4n với 2n.

> [!loi-giai] Lời giải
> a) Xử lí colchicine lên hạt nảy mầm hoặc đỉnh sinh trưởng của cây 2n → chọn cây **4n**. Lai cây 4n (giao tử 2n) với cây 2n (giao tử n) → hạt lai **3n**, gieo thành cây tam bội.
>
> b) Cây 4n: 4 × 11 = **44** NST; cây 3n: 3 × 11 = **33** NST.
>
> c) Cây 3n giảm phân rối loạn (mỗi nhóm 3 NST không chia đều), hầu hết giao tử mất cân bằng gene, không có khả năng thụ tinh → noãn không phát triển thành hạt; quả vẫn lớn được (thường cần kích thích bằng hạt phấn hoặc chất điều hoà sinh trưởng) nhưng **không hạt**.

## 4. Tác hại của đột biến nhiễm sắc thể

### 4.1. Tác hại của đột biến cấu trúc

| Dạng | Tác hại | Ví dụ |
|---|---|---|
| Mất đoạn | Mất gene → **hầu hết có hại** | Người: mất một đoạn vai ngắn **NST số 5** → **hội chứng tiếng mèo kêu** (tiếng khóc như mèo, đầu nhỏ, trí tuệ chậm phát triển, hai mắt cách xa) |
| Lặp đoạn | Thêm bản sao gene → **mất cân bằng gene**, có thể gây hại | Ruồi giấm: lặp đoạn trên NST X làm **giảm số mắt đơn**, mắt nhỏ (dẹt) hơn bình thường |
| Đảo đoạn, chuyển đoạn | Nếu điểm đứt không làm hỏng gene thì thường **ít hoặc không hại** cho bản thân cá thể; nhưng vị trí gene đổi có thể đổi mức biểu hiện gene, và thể **dị hợp** đảo đoạn / chuyển đoạn thường **giảm khả năng sinh sản** (khoảng 50%) | Người: chuyển gần như cả vai dài **NST 21** sang vai ngắn **NST 14** → **hội chứng Down**; chuyển đoạn giữa **NST 9 và NST 22** ở tế bào sinh dưỡng tạo gene gây ung thư → **ung thư bạch cầu** (bạch cầu tuỷ mạn); chuyển đoạn giữa **NST 8 và NST 14** ở tế bào cơ thể → ung thư **Burkitt** |

> [!bay] Burkitt: NST 8 với NST 14 (không phải 8 với 9)
> Ở trang 64, SGK in "chuyển đoạn giữa NST số 8 và số 9" gây ung thư Burkitt — đây là **lỗi in**. Chính SGK ở Bài 13 (tr. 71) lại ghi đúng là **NST số 8 và số 14**, và tài liệu y học cũng xác định chuyển đoạn đặc trưng của Burkitt là giữa NST 8 và NST 14. Khi đi thi, em dùng **8 – 14**. Nếu đề chỉ hỏi "chuyển đoạn gây ung thư" thì đó vẫn là **chuyển đoạn** (đột biến cấu trúc), không phải lệch bội. (Burkitt thực chất là một loại u lympho — ung thư tế bào lympho, một loại bạch cầu — nên SGK gọi là "ung thư bạch cầu".)

**Vì sao thể dị hợp chuyển đoạn/đảo đoạn giảm khả năng sinh sản?** "Dị hợp" ở đây nghĩa là trong cặp tương đồng có **một NST bình thường và một NST đột biến**. Khi giảm phân, hai NST này khó tiếp hợp đúng; nhiều giao tử nhận **thiếu hoặc thừa** đoạn gene → giao tử hoặc hợp tử chết. Bản thân cá thể vẫn khoẻ (đủ gene), nhưng **số con sinh ra ít đi**.

> [!bay]
> Hội chứng Down thường do **thể ba NST 21** (lệch bội, 47 NST). Nhưng một số ít trường hợp do **chuyển đoạn** vai dài NST 21 sang NST 14 — người bệnh có thể chỉ có **46** NST mà vẫn mang 3 "phần" NST 21. Đề hỏi "Down **luôn** do lệch bội" → **sai**.

### 4.2. Tác hại của đột biến số lượng

- **Lệch bội** làm **mất cân bằng gene** (một cặp NST có số bản sao gene khác hẳn các cặp còn lại) → thường **có hại, thậm chí gây chết**. Ở người, SGK (tr. 64) nêu: các lệch bội đều gây chết thai, **trừ** thừa/thiếu NST giới tính (XXY, XO, XXX…) và thừa NST 21. Thực tế còn một số ít trẻ thể ba NST 13 (Patau) hoặc 18 (Edwards) được sinh ra nhưng thường chết sớm (xem bảng ở Bài 13) — vì vậy ở đây ta nói "hầu hết".
- Ở người, thai **đa bội** đều chết sớm.
- **Đa bội lẻ** (3n…) ở thực vật và một số động vật bậc thấp thường **bất thụ**.
- **Đa bội chẵn** (4n…) ít gây hại hơn đa bội lẻ vì thường **không làm mất cân bằng gene**: mọi gene đều tăng số bản sao như nhau.

> [!em-co-biet] Mẹ càng lớn tuổi, nguy cơ sinh con Down càng cao
> Theo số liệu thống kê được SGK dẫn (tr. 67), tỉ lệ trẻ sinh ra mắc Down chỉ khoảng 1/2 300 khi mẹ dưới 20 tuổi, nhưng tăng vọt lên khoảng 1/100 khi mẹ ngoài 40 và còn cao hơn nữa sau 45 tuổi. Một giả thuyết: tế bào trứng của người mẹ dừng ở kì đầu giảm phân I từ khi còn là bào thai và chỉ hoàn tất khi rụng trứng — chờ hàng chục năm, cơ chế giữ các NST tương đồng dính với nhau "lão hoá" dần, dễ không phân li. Vì vậy phụ nữ mang thai sau 35 tuổi thường được khuyên **sàng lọc trước sinh**.

## 5. Vai trò của đột biến nhiễm sắc thể

### 5.1. Trong tiến hoá

- **Đột biến cấu trúc** tái cấu trúc bộ NST: thay đổi số lượng, cấu trúc của gene và cách phân bố gene trong hệ gene.
  - **Lặp đoạn** tạo ra bản sao "dư" của gene; bản sao này có thể tích luỹ đột biến và mang chức năng mới mà không làm mất chức năng cũ. Ví dụ: ở người, lặp đoạn đã hình thành **họ gene hemoglobin** gồm nhiều gene tương tự nhau, mỗi gene hoạt động ở một giai đoạn phát triển (phôi, thai, sau sinh).
  - **Chuyển đoạn đặc biệt**: tổ tiên chung của người và tinh tinh có 48 NST; ở dòng tiến hoá dẫn tới loài người, hai NST tâm mút **dung hợp** thành một NST tâm giữa — chính là **NST số 2** của người. Vì vậy người có **46** NST, còn tinh tinh vẫn giữ **48** NST như tổ tiên.
- **Đa bội** có vai trò quan trọng trong **hình thành loài mới**, nhất là ở thực vật: chuối trồng tam bội; nhiều loài lúa mì, lúa mạch là đa bội khác nguồn. Ở động vật hiếm hơn nhưng vẫn có: một số loài thằn lằn tam bội, giun dẹp, đỉa, một số loài tôm nước mặn, gần đây có cả loài chuột tứ bội.

> [!vi-du] Ví dụ 5
> Người có 2n = 46, tinh tinh có 2n = 48. Giả sử NST số 2 của người được hình thành do hai NST của tổ tiên dung hợp lại và không có thay đổi số lượng nào khác. a) Hai NST tổ tiên đó có dạng tâm động như thế nào? b) Vì sao sự dung hợp này làm giảm 2 NST trong bộ 2n chứ không phải giảm 1?

> [!goi-y] Gợi ý 1
> NST số 2 của người là NST **tâm giữa** — hai vai dài gần bằng nhau. Ghép hai NST có tâm động ở gần đầu mút (tâm mút) ở phía đầu có tâm động thì được NST dạng gì?

> [!goi-y] Gợi ý 2
> Bộ 2n gồm các **cặp**. Sự dung hợp xảy ra ở **cả hai chiếc** của mỗi cặp liên quan (sau nhiều thế hệ, dạng đột biến trở thành đồng hợp trong loài).

> [!loi-giai] Lời giải
> a) Hai NST tổ tiên là NST **tâm mút**; khi dung hợp ở phía đầu có tâm động, chúng tạo thành một NST **tâm giữa** (vai trái là NST thứ nhất, vai phải là NST thứ hai).
>
> b) Ở tổ tiên có **2 cặp** (4 chiếc) NST tâm mút. Sau dung hợp, mỗi bộ đơn bội giảm từ 24 xuống **23** NST (2 chiếc → 1 chiếc), nên bộ lưỡng bội giảm từ 48 xuống **46**.

### 5.2. Trong nghiên cứu di truyền

**Dùng mất đoạn để xác định vị trí gene trên NST.** Xét cá thể có một NST bình thường mang allele **lặn** a, còn NST tương đồng với nó bị **mất đoạn** đúng chỗ chứa locus đó (mất luôn allele trội A). Lúc này a "đứng một mình", không bị A át → **kiểu hình lặn hiện ra** dù chỉ có một allele lặn. Nếu kiểu hình lặn hiện ra khi mất đoạn X mà không hiện khi mất đoạn Y → gene nằm trong đoạn X.

**Trả lời câu hỏi mở bài.** Ở người, gene quy định giới tính nam (gene **SRY**, Bài 10) nằm ở **đầu vai ngắn NST Y**. Người kia có NST Y bị **mất đoạn đầu vai ngắn** → mất gene SRY → phôi không phát triển theo hướng nam → kiểu hình **nữ** dù có cặp XY. Chính những trường hợp như vậy đã giúp các nhà khoa học **xác định vị trí** của gene quy định giới tính nam.

**Chuyển đoạn và đảo đoạn** làm gene đổi vị trí → có thể làm biểu hiện gene thay đổi; nghiên cứu các đột biến này giúp xác định **ảnh hưởng của vị trí gene** trên NST đến sự biểu hiện của nó.

### 5.3. Trong chọn giống

- **Chuyển đoạn** có thể dùng để **chuyển các gene quý** (ví dụ gene năng suất, gene kháng bệnh) nằm trên các NST khác nhau về **cùng một NST** → chúng **di truyền cùng nhau** (liên kết), không bị tách ra qua các thế hệ.
- **Phòng trừ sâu hại bằng côn trùng mang đột biến:** cá thể dị hợp chuyển đoạn/đảo đoạn giảm khả năng sinh sản. Người ta nuôi số lượng lớn **con đực** mang chuyển đoạn hoặc đảo đoạn, thả ra tự nhiên giao phối với con cái bình thường → số con sinh ra giảm → **quần thể sâu hại giảm** mà không cần nhiều thuốc trừ sâu.
- **Cây đa bội:**
  - cây ăn quả **tam bội** cho quả **không hạt**: dưa hấu, nho tam bội…;
  - cây **dâu tằm** đa bội có lá to, sinh trưởng nhanh hơn cây lưỡng bội → năng suất lá cao cho nghề nuôi tằm.

> [!ung-dung] Cần tạo giống cây ăn quả không hạt thì chọn loại đột biến nào?
> Chọn **đa bội lẻ (tam bội)**: cơ quan sinh dưỡng to nhờ đa bội, mà giảm phân rối loạn nên không tạo hạt. Muốn có cây tam bội: tạo cây 4n bằng colchicine rồi lai với cây 2n (Ví dụ 4). Cây tam bội không có hạt để gieo nên được nhân giống bằng **cách khác**: tạo lại hạt lai 3n mỗi vụ (dưa hấu) hoặc **nhân giống vô tính** — giâm, chiết, ghép, nuôi cấy mô (nho, chuối).

## 6. Mối quan hệ giữa di truyền và biến dị

- **Di truyền** là quá trình **truyền đạt** thông tin quy định tính trạng từ thế hệ này sang thế hệ sau — nhờ tái bản DNA, nhân đôi và phân li NST trong nguyên phân, giảm phân, thụ tinh (Bài 7, 8).
- **Biến dị di truyền** là những biến đổi trong **vật chất di truyền** (gene, NST) làm xuất hiện đặc điểm mới **có thể truyền cho thế hệ sau**: đột biến gene (Bài 4), đột biến NST (bài này), biến dị tổ hợp (Bài 8, 11).

Hai mặt này **gắn bó chặt chẽ**, không tách rời:

1. Biến dị (đột biến) chỉ có ý nghĩa với loài khi nó **được di truyền** lại — chính quá trình di truyền truyền nguyên vẹn cả gene bình thường **lẫn** đột biến mới phát sinh cho đời con.
2. Ngược lại, nếu chỉ có di truyền mà không có biến dị, mọi thế hệ giống hệt nhau, sinh vật **không thể thích nghi** khi môi trường thay đổi.

Nhờ di truyền **vừa ổn định** (giữ đặc điểm của loài) **vừa biến đổi** (tạo biến dị mới), sinh giới thích nghi được với môi trường thay đổi và **không ngừng phát triển**, hình thành nhiều loài từ tổ tiên chung.

## Dạng bài thi hay gặp

> [!ghi-nho] Bảng "đếm nhanh" số NST (n là số cặp NST của loài)
> | Thể đột biến | Số NST trong tế bào sinh dưỡng | Thể đột biến | Số NST |
> |---|---|---|---|
> | Thể một | 2n − 1 | Tam bội | 3n |
> | Thể ba | 2n + 1 | Tứ bội | 4n |
> | Thể không | 2n − 2 | Thể một kép | 2n − 1 − 1 |
> | Thể bốn | 2n + 2 | Thể ba kép | 2n + 1 + 1 |
>
> Số loại thể ba (thể một, thể không, thể bốn) tối đa = **n**; số loại thể ba kép (thể một kép) tối đa = $C_n^2$.

### Dạng 1. Nhận biết dạng đột biến cấu trúc từ trình tự gene

*Nhận biết:* đề cho trình tự gene trên NST trước và sau đột biến (hoặc hình vẽ), hỏi tên dạng đột biến, hoặc hỏi "dạng nào làm thay đổi chiều dài / nhóm gene liên kết…".

*Phương pháp:*
1. Đếm số đoạn: **ít hơn** → mất đoạn; **nhiều hơn** và có đoạn trùng → lặp đoạn.
2. Đủ đoạn, cùng một NST: đoạn bị **đọc ngược tại chỗ** → đảo đoạn (có/không chứa tâm động); đoạn **dời chỗ** → chuyển đoạn trong một NST.
3. Xuất hiện gene của **NST khác** (và/hoặc mất gene sang NST khác) → chuyển đoạn giữa hai NST.

| Dạng | Chiều dài NST | Số lượng gene trên NST | Nhóm gene liên kết |
|---|---|---|---|
| Mất đoạn | giảm | giảm | không đổi (chỉ bớt gene) |
| Lặp đoạn | tăng | tăng (bản sao) | không đổi |
| Đảo đoạn | không đổi | không đổi | không đổi |
| Chuyển đoạn trong 1 NST | không đổi | không đổi | không đổi |
| Chuyển đoạn giữa 2 NST | có thể thay đổi | có thể thay đổi | **thay đổi** |

> [!vi-du] Ví dụ 6
> Trên một cặp NST tương đồng, NST thứ nhất có trình tự **ABC•DEFG**, NST thứ hai có trình tự **abc•defg** (chữ in hoa và chữ thường là các allele). Một tế bào sinh tinh giảm phân tạo ra giao tử mang NST **ABC•DEFdefg**. a) NST này mang dạng đột biến cấu trúc nào? b) Nêu cơ chế có thể đã tạo ra nó và trình tự của chromatid được tạo ra đồng thời trong cùng lần trao đổi.

> [!goi-y] Gợi ý 1
> NST mới dài hơn NST ban đầu (10 đoạn so với 7), chứa **hai bản** của các locus D, E, F (một bản mang allele trội, một bản mang allele lặn). Đó là dạng gì?

> [!goi-y] Gợi ý 2
> Một NST nhận thêm đoạn từ **NST tương đồng** của nó trong giảm phân → nghĩ đến trao đổi chéo **không cân**. NST kia mất đúng đoạn này.

> [!loi-giai] Lời giải
> a) Đoạn mang locus D, E, F xuất hiện hai lần → **lặp đoạn**.
>
> b) Ở kì đầu giảm phân I, chromatid ABC•DEFG và chromatid abc•defg bắt cặp **lệch** nhau rồi trao đổi chéo không cân: chromatid thứ nhất đứt sau F, chromatid thứ hai đứt trước d. Hai phần đổi chỗ nối lại:
>
> - ABC•DEF + defg → **ABC•DEFdefg** (lặp đoạn def);
> - abc• + G → **abc•G** (mất đoạn ở các locus d, e, f).
>
> Kiểm tra: tổng số đoạn trước (7 + 7 = 14) bằng tổng số đoạn sau (10 + 4 = 14) — không mất vật chất, chỉ chia **không đều**.

*Bẫy:* tưởng lặp đoạn phải là chữ **giống hệt** nhau (DEF lặp thành DEFDEF). Thực tế đoạn lặp có thể mang allele khác (def) nếu sinh ra do trao đổi chéo không cân giữa hai NST tương đồng.

### Dạng 2. Đếm số NST của thể lệch bội, đa bội qua các kì phân bào

*Nhận biết:* "loài có 2n = …; thể ba / thể tứ bội… có bao nhiêu NST; ở kì giữa / kì sau nguyên phân có bao nhiêu NST, chromatid…".

*Phương pháp:*
1. Tính số NST trong tế bào sinh dưỡng của thể đột biến (bảng đếm nhanh ở trên). Gọi số này là **S**.
2. Áp dụng quy luật nguyên phân (Bài 7): kì trung gian sau nhân đôi, kì đầu, kì giữa: **S NST kép** (2S chromatid); kì sau: **2S NST đơn**; kết thúc: mỗi tế bào con **S NST đơn**.
3. Nếu đề cho số NST đếm được, làm ngược lại: tìm S rồi so với 2n.

> [!vi-du] Ví dụ 7
> Ở một loài thực vật, 2n = 24. Một tế bào sinh dưỡng của thể đột biến đang ở kì sau nguyên phân có **50** NST đơn. a) Thể đột biến này thuộc dạng nào? b) Nếu là thể tam bội của loài này thì ở kì giữa nguyên phân, tế bào có bao nhiêu chromatid?

> [!goi-y] Gợi ý 1
> Ở kì sau nguyên phân, số NST đơn **gấp đôi** số NST của tế bào lúc bình thường.

> [!goi-y] Gợi ý 2
> 50 : 2 = 25 = 24 + 1. Tam bội có 3n = 36 NST; kì giữa mỗi NST kép có 2 chromatid.

> [!loi-giai] Lời giải
> a) Số NST trong tế bào sinh dưỡng = 50 : 2 = 25 = 2n + 1 → **thể ba**.
>
> b) Tam bội: 3n = 3 × 12 = 36 NST. Kì giữa: 36 NST kép → **72 chromatid**.

*Bẫy:* quên chia đôi ở kì sau; nhầm n với 2n khi tính 3n (3n = 3 × 12 = 36, **không** phải 3 × 24).

### Dạng 3. Tỉ lệ giao tử, hợp tử khi một số tế bào có cặp NST không phân li

*Nhận biết:* "có x% số tế bào sinh tinh/sinh trứng có cặp NST mang cặp gene … không phân li trong giảm phân I (hoặc II), các tế bào khác giảm phân bình thường…; tính tỉ lệ giao tử / tỉ lệ hợp tử thể ba, thể một…".

*Phương pháp:*
1. Chia tế bào thành **hai nhóm**: nhóm rối loạn (x%) và nhóm bình thường (1 − x%).
2. Nhóm rối loạn ở **GP I**: cho ½ giao tử (n + 1) mang **cả hai** allele (ví dụ Aa) và ½ giao tử (n − 1) (kí hiệu O). Nhóm bình thường: ½ A : ½ a.
3. Nhân tỉ lệ nhóm với tỉ lệ giao tử trong nhóm rồi cộng lại. Kết hợp với giao tử của cơ thể kia (nhân tỉ lệ) để ra tỉ lệ hợp tử.

> [!vi-du] Ví dụ 8
> Một cơ thể đực có kiểu gene Aa. Trong giảm phân, có **16%** số tế bào sinh tinh có cặp NST mang cặp gene Aa không phân li ở giảm phân I, giảm phân II bình thường; các tế bào khác giảm phân bình thường. Cơ thể cái Aa giảm phân bình thường. Theo lí thuyết: a) giao tử đực mang Aa chiếm bao nhiêu? b) hợp tử thể ba chiếm bao nhiêu? c) hợp tử có kiểu gene **Aaa** chiếm bao nhiêu?

> [!goi-y] Gợi ý 1
> Nhóm 16% rối loạn GP I cho ½ Aa : ½ O. Nhóm 84% bình thường cho ½ A : ½ a. Viết đủ 4 loại giao tử đực với tỉ lệ.

> [!goi-y] Gợi ý 2
> Hợp tử thể ba = giao tử đực Aa (n + 1) × giao tử cái bình thường (n). Hợp tử Aaa = giao tử đực Aa × giao tử cái a.

> [!loi-giai] Lời giải
> a) Giao tử đực: Aa = O = 16% × ½ = **8%**; A = a = 84% × ½ = 42%.
>
> b) Giao tử cái đều bình thường (½ A : ½ a), nên hợp tử thể ba (2n + 1) = tỉ lệ giao tử đực Aa = **8%**.
>
> c) Aaa = Aa (đực) × a (cái) = 8% × ½ = **4%**.

*Bẫy:* (1) quên nhân ½ ở bước tạo giao tử của nhóm rối loạn (lấy luôn 16% là giao tử Aa); (2) nhầm lỗi GP II cũng cho giao tử Aa — **sai**, lỗi GP II cho AA hoặc aa.

### Dạng 4. Giao tử và đời con của thể tứ bội, thể ba

> [!em-co-biet] Dạng này nằm ngoài SGK
> SGK 2018 không dạy cách tính giao tử của thể tứ bội, thể ba; đề tốt nghiệp từ 2025 ít khi hỏi trực tiếp, nhưng đề thi thử và đề tuyển sinh riêng vẫn dùng (thường ở mức vận dụng). Em nên học sau khi đã vững Dạng 1–3; chỉ cần nắm cách **đếm tổ hợp** dưới đây, không cần học thuộc bảng.

*Nhận biết:* "cây tứ bội AAaa…", "thể ba AAa…", kèm giả thiết "giảm phân bình thường, giao tử lưỡng bội có khả năng thụ tinh" (tứ bội) hoặc "giao tử n và n + 1 đều có khả năng thụ tinh" (thể ba).

*Phương pháp:*
1. **Thể tứ bội** (4 chiếc mỗi "cặp"): giao tử 2n nhận **2 trong 4** chiếc → có $C_4^2 = 6$ cách chọn, xem như ngẫu nhiên. Viết 4 allele ra rồi đếm.
2. **Thể ba** (3 chiếc): giao tử nhận 2 chiếc (n + 1) hoặc 1 chiếc (n); mỗi cách chia 3 chiếc thành "2 + 1" có 3 cách → 6 giao tử.
3. Tỉ lệ đời con: lập bảng hoặc nhân tỉ lệ; thường tính **kiểu hình lặn trước** (chỉ có một tổ hợp) rồi lấy 1 trừ đi.

| Kiểu gene | Giao tử | Tỉ lệ |
|---|---|---|
| AAAA | AA | 1 |
| AAAa | AA : Aa | 1 : 1 |
| **AAaa** | **AA : Aa : aa** | **1 : 4 : 1** |
| Aaaa | Aa : aa | 1 : 1 |
| AAa (thể ba) | AA : Aa : A : a | 1 : 2 : 2 : 1 |
| Aaa (thể ba) | Aa : aa : A : a | 2 : 1 : 1 : 2 |

> [!meo] Vì sao AAaa cho 1 : 4 : 1?
> Đánh số 4 allele: A~1~, A~2~, a~1~, a~2~. Chọn 2 trong 4 có 6 cách: A~1~A~2~ (1 cách AA); A~1~a~1~, A~1~a~2~, A~2~a~1~, A~2~a~2~ (4 cách Aa); a~1~a~2~ (1 cách aa). Không cần học thuộc — chỉ cần đếm!

> [!vi-du] Ví dụ 9
> Ở một loài thực vật, allele A quy định quả đỏ trội hoàn toàn so với allele a quy định quả vàng. Cho cây tứ bội **AAaa** tự thụ phấn; biết cây tứ bội giảm phân chỉ tạo giao tử lưỡng bội có khả năng thụ tinh. Theo lí thuyết, tỉ lệ kiểu hình ở đời con là bao nhiêu? Tỉ lệ kiểu gene AAaa ở đời con là bao nhiêu?

> [!goi-y] Gợi ý 1
> Giao tử của AAaa: 1/6 AA : 4/6 Aa : 1/6 aa. Cây quả vàng phải có kiểu gene gì?

> [!goi-y] Gợi ý 2
> Quả vàng = aaaa = aa (đực) × aa (cái). Kiểu gene AAaa ở đời con có thể tạo từ AA × aa, aa × AA hoặc Aa × Aa.

> [!loi-giai] Lời giải
> Bước 1: quả vàng aaaa = 1/6 × 1/6 = **1/36** → quả đỏ = 35/36. Tỉ lệ kiểu hình: **35 đỏ : 1 vàng**.
>
> Bước 2: AAaa = AA × aa + aa × AA + Aa × Aa = 1/36 + 1/36 + 16/36 = **18/36 = 1/2**.

*Bẫy:* tính giao tử AAaa là ½ Aa : ¼ AA : ¼ aa (nhầm với cách tính Aa × Aa ở lưỡng bội). Cũng đừng quên đọc kĩ giả thiết của đề về loại giao tử có khả năng thụ tinh.

## Tóm tắt

| | Đột biến cấu trúc | Lệch bội | Đa bội |
|---|---|---|---|
| Phạm vi | một đoạn NST | 1 hoặc vài cặp NST | toàn bộ bộ NST |
| Các dạng | mất, lặp, đảo, chuyển đoạn | 2n + 1, 2n − 1, 2n − 2, 2n + 1 + 1… | tự đa bội (3n, 4n…), dị đa bội (2n~A~ + 2n~B~) |
| Cơ chế | đứt gãy – nối lại sai; trao đổi chéo không cân | 1 (vài) cặp NST không phân li trong giảm phân | thoi phân bào không hình thành (colchicine): tất cả các cặp không phân li; lai xa + đa bội hoá |
| Hậu quả | mất đoạn: hầu hết có hại; lặp: mất cân bằng gene; đảo, chuyển: ít hại cho cá thể nhưng thể dị hợp giảm sinh sản | mất cân bằng gene → thường có hại, gây chết | lẻ: bất thụ (không hạt); chẵn: ít hại; tế bào và cơ quan to |
| Ví dụ | mất đoạn NST 5 (tiếng mèo kêu); lặp đoạn mắt dẹt ruồi giấm; chuyển đoạn 21→14 (Down), 9–22 (ung thư bạch cầu), 8–14 (Burkitt) | Down (3 NST 21), Klinefelter XXY, Turner XO | chuối, dưa hấu, nho tam bội; lúa mì lục bội |
| Vai trò | xác định vị trí gene (mất đoạn); chuyển gene quý về cùng NST; phòng trừ sâu hại; tiến hoá (họ gene hemoglobin, NST số 2 người) | xác định vị trí gene trên NST | tạo giống cây không hạt, năng suất cao; hình thành loài mới |

**Công thức nhanh:** thể ba 2n + 1, thể một 2n − 1; số loại thể ba = n, thể ba kép = $C_n^2$ · lỗi GP I ở x% tế bào (cặp Aa) → giao tử Aa = O = x/2 · giao tử AAaa = 1 AA : 4 Aa : 1 aa → AAaa tự thụ cho 35 trội : 1 lặn.
