---
title: Liên kết gene và hoán vị gene
thoi-gian: 50 phút
muc-tieu:
  - Trình bày được cách Morgan bố trí và tiến hành thí nghiệm lai trên ruồi giấm; từ kết quả phát biểu được khái niệm liên kết gene và hoán vị gene.
  - Giải thích được cơ sở tế bào học của liên kết gene (các gene cùng nằm trên một NST phân li cùng nhau) và của hoán vị gene (trao đổi chéo giữa hai chromatid không chị em ở kì đầu giảm phân I).
  - Nêu được ý nghĩa của liên kết gene và hoán vị gene đối với tiến hoá và chọn giống.
  - Hiểu tần số hoán vị gene, vì sao tần số này không vượt quá 50%; dùng tần số hoán vị để lập bản đồ di truyền và nêu được ý nghĩa của bản đồ.
  - Viết đúng kiểu gene dị hợp đều, dị hợp chéo; tính được tỉ lệ giao tử, tần số hoán vị và tỉ lệ kiểu hình đời con trong các dạng bài thi.
  - Nêu được quan điểm của Mendel và Morgan về tính quy luật của hiện tượng di truyền.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Liên kết gene**: các gene nằm trên **cùng một NST** có xu hướng di truyền cùng nhau. Số **nhóm gene liên kết = n** (số NST trong bộ đơn bội).
> 2. Dị hợp hai cặp gene cùng NST viết là $\dfrac{AB}{ab}$ (**dị hợp đều**) hoặc $\dfrac{Ab}{aB}$ (**dị hợp chéo**). Liên kết hoàn toàn → chỉ 2 loại giao tử, mỗi loại 50%.
> 3. **Hoán vị gene**: ở kì đầu giảm phân I, hai **chromatid không chị em** của cặp NST tương đồng **trao đổi chéo** → xuất hiện giao tử **tái tổ hợp** (mang tổ hợp gene mới).
> 4. **Tần số hoán vị f** = tổng tỉ lệ giao tử tái tổ hợp, luôn **f ≤ 50%**. Mỗi giao tử hoán vị chiếm f/2, mỗi giao tử liên kết chiếm (1 − f)/2.
> 5. **Bản đồ di truyền**: 1% tần số hoán vị = **1 cM** (centiMorgan). Hai gene càng xa nhau, f càng lớn → dự đoán được tỉ lệ tổ hợp gene mới khi lai.

Ở Bài 8, em đã thấy cơ thể AaBb tạo **4 loại giao tử bằng nhau** và F~2~ cho tỉ lệ 9 : 3 : 3 : 1. Nhưng điều đó chỉ đúng khi hai gene nằm trên **hai cặp NST khác nhau**.

Năm 1905, khi lai hai tính trạng ở cây đậu ngọt, Bateson và cộng sự thu được F~2~ **không** theo tỉ lệ 9 : 3 : 3 : 1: các kiểu hình giống bố mẹ chiếm nhiều hơn hẳn, còn các kiểu hình mới lại ít hơn dự đoán. Họ không giải thích được. Lời giải đến từ phòng thí nghiệm ruồi giấm của **Thomas Hunt Morgan** — và cũng là nội dung của bài này.

Hãy nghĩ thế này: một tế bào người có khoảng 20 000 gene nhưng chỉ có 23 cặp NST. Vậy **mỗi NST phải mang hàng trăm, hàng nghìn gene**. Các gene "ngồi chung một chiếc NST" thì khi NST phân li, chúng đi cùng nhau — chúng **không thể** phân li độc lập.

> [!nen-tang] Nhắc lại giảm phân (Sinh học 10)
> - Ở kì trung gian, mỗi NST nhân đôi thành **NST kép** gồm 2 **chromatid chị em** (giống hệt nhau, dính ở tâm động).
> - **Kì đầu giảm phân I**: hai NST kép của cặp tương đồng (một từ bố, một từ mẹ) **bắt cặp** sát nhau theo chiều dọc (tiếp hợp). Lúc này có 4 chromatid nằm cạnh nhau. Một chromatid của NST bố và một chromatid của NST mẹ gọi là hai **chromatid không chị em**.
> - Giảm phân I: hai NST kép của cặp tương đồng tách nhau. Giảm phân II: hai chromatid tách nhau. Mỗi giao tử nhận **một chromatid** của mỗi cặp NST.

## 1. Liên kết gene

### 1.1. Thí nghiệm của Morgan

Morgan chọn **ruồi giấm** (*Drosophila melanogaster*) vì chúng dễ nuôi trong ống nghiệm, vòng đời chỉ khoảng 10–14 ngày, mỗi cặp đẻ hàng trăm con, có nhiều đột biến dễ quan sát và bộ NST chỉ có **2n = 8**.

Ông xét hai tính trạng (SGK tr. 54–55):

- Màu thân: **B** – thân xám trội hoàn toàn so với **b** – thân đen.
- Kích thước cánh: **V** – cánh dài trội hoàn toàn so với **v** – cánh cụt (cánh rất ngắn).

Hai gene này nằm trên NST thường. Ông tiến hành:

1. **P** thuần chủng: thân xám, cánh dài × thân đen, cánh cụt → **F~1~**: 100% thân xám, cánh dài.
2. **Lai phân tích con đực F~1~**: ♂ F~1~ thân xám, cánh dài × ♀ thân đen, cánh cụt.

Nếu hai gene phân li độc lập như Mendel, con đực F~1~ (dị hợp hai cặp) phải cho 4 loại giao tử bằng nhau, và F~a~ phải có 4 kiểu hình tỉ lệ **1 : 1 : 1 : 1**. Nhưng Morgan chỉ thu được:

=> F~a~: 1 xám, dài : 1 đen, cụt

Tức là **chỉ 2 kiểu hình giống bố mẹ, tỉ lệ 1 : 1**. Thân xám luôn đi cùng cánh dài, thân đen luôn đi cùng cánh cụt — như thể hai tính trạng được "buộc" vào nhau.

### 1.2. Giải thích — cơ sở tế bào học

**Suy luận của Morgan.** Con cái thân đen, cánh cụt chỉ cho một loại giao tử (mang b và v). Vậy F~a~ có 2 kiểu hình nghĩa là con đực F~1~ chỉ tạo **2 loại giao tử** với tỉ lệ bằng nhau: một loại mang **B và V**, một loại mang **b và v**. Điều này chỉ xảy ra nếu gene màu thân và gene kích thước cánh **nằm trên cùng một NST**: allele B nằm cùng chiếc NST với V (nhận từ bố mẹ xám, dài), allele b nằm cùng chiếc NST với v (nhận từ bố mẹ đen, cụt).

Khi giảm phân, cả chiếc NST di chuyển như một khối, nên các gene trên đó **đi cùng nhau** về một giao tử:

![Hình 1. Liên kết gene hoàn toàn: cơ thể dị hợp hai cặp gene trên một cặp NST tương đồng chỉ tạo hai loại giao tử, mỗi loại 50%](hinh-1-lien-ket.svg)

> [!ghi-nho] Liên kết gene
> **Liên kết gene** là hiện tượng các gene nằm trên **cùng một NST** di truyền cùng nhau. Cơ sở tế bào học: mỗi gene nằm ở một locus xác định trên NST; các gene xếp dọc theo chiều dài NST; khi NST phân li trong giảm phân thì các gene trên nó **phân li cùng nhau**.

**Nhóm gene liên kết.** Tất cả các gene nằm trên cùng một NST tạo thành một **nhóm gene liên kết**. Vì mỗi cặp NST tương đồng mang cùng một bộ gene, nên:

**Số nhóm gene liên kết = n** (số NST trong bộ đơn bội của loài).

Ví dụ: ruồi giấm 2n = 8 → 4 nhóm liên kết; đậu hà lan 2n = 14 → 7 nhóm; lúa 2n = 24 → 12 nhóm.

> [!bay]
> Số nhóm liên kết bằng **n**, không phải 2n. Hai chiếc NST trong một cặp tương đồng mang **cùng các gene** (có thể khác allele), nên chúng chỉ tính là **một** nhóm liên kết.

### 1.3. Cách viết kiểu gene khi các gene cùng nằm trên một NST

Khi hai gene nằm trên cùng một NST, ta không viết AaBb nữa (vì cách viết đó không cho biết allele nào nằm cùng chiếc NST với allele nào). Thay vào đó ta viết **theo từng chiếc NST**: mỗi chiếc là một "tầng", hai tầng cách nhau bằng một gạch ngang (SGK vẽ hai gạch song song, tượng trưng cho cặp NST tương đồng).

| Cách viết | Đọc là | Ý nghĩa |
|---|---|---|
| $\dfrac{AB}{ab}$ | dị hợp **đều** (dị hợp tử đều) | hai allele trội nằm **cùng** một chiếc NST |
| $\dfrac{Ab}{aB}$ | dị hợp **chéo** (dị hợp tử chéo) | mỗi chiếc NST mang một allele trội |

Hai kiểu gene $\dfrac{AB}{ab}$ và $\dfrac{Ab}{aB}$ có **cùng kiểu hình** (trội cả hai tính trạng) và cùng "có A, a, B, b" — nhưng chúng **khác nhau** về cách sắp xếp, nên cho giao tử khác nhau:

- $\dfrac{AB}{ab}$ liên kết hoàn toàn → **50% AB : 50% ab**.
- $\dfrac{Ab}{aB}$ liên kết hoàn toàn → **50% Ab : 50% aB**.

Trong thí nghiệm của Morgan, F~1~ nhận một NST mang B, V từ bố mẹ xám, dài và một NST mang b, v từ bố mẹ đen, cụt, nên F~1~ có kiểu gene $\dfrac{BV}{bv}$ (dị hợp đều).

> [!meo] Biết P thì biết F~1~ là dị hợp đều hay chéo
> - P~tc~: $\dfrac{AB}{AB}$ × $\dfrac{ab}{ab}$ (trội – trội × lặn – lặn) → F~1~ dị hợp **đều** $\dfrac{AB}{ab}$.
> - P~tc~: $\dfrac{Ab}{Ab}$ × $\dfrac{aB}{aB}$ (trội – lặn × lặn – trội) → F~1~ dị hợp **chéo** $\dfrac{Ab}{aB}$.

> [!vi-du] Ví dụ 1
> Ở một loài thực vật, A – thân cao trội hoàn toàn so với a – thân thấp; B – hoa đỏ trội hoàn toàn so với b – hoa trắng. Hai gene cùng nằm trên một cặp NST và liên kết hoàn toàn. Lai cây thân cao, hoa trắng thuần chủng với cây thân thấp, hoa đỏ thuần chủng được F~1~. Cho F~1~ tự thụ phấn. Xác định tỉ lệ kiểu hình ở F~2~.

> [!goi-y] Gợi ý 1
> Viết kiểu gene của P theo từng chiếc NST: cây cao, trắng thuần chủng là $\dfrac{Ab}{Ab}$. Cây thấp, đỏ thuần chủng là gì? F~1~ là dị hợp đều hay chéo?

> [!goi-y] Gợi ý 2
> F~1~ $\dfrac{Ab}{aB}$ liên kết hoàn toàn chỉ cho 2 loại giao tử: ½ Ab : ½ aB. Kẻ bảng 2 × 2.

> [!loi-giai] Lời giải
> Bước 1: P~tc~: $\dfrac{Ab}{Ab}$ × $\dfrac{aB}{aB}$ → F~1~: $\dfrac{Ab}{aB}$ (100% cao, đỏ).
>
> Bước 2: F~1~ × F~1~: mỗi bên cho ½ Ab : ½ aB.
>
> Bước 3: F~2~: ¼ $\dfrac{Ab}{Ab}$ : ½ $\dfrac{Ab}{aB}$ : ¼ $\dfrac{aB}{aB}$.
>
> Kết luận: F~2~ có **1 cao, trắng : 2 cao, đỏ : 1 thấp, đỏ** — chỉ 3 kiểu hình, không có cây thấp, trắng.

> [!bay]
> Đừng mặc định "dị hợp × dị hợp → 3 : 1". Liên kết hoàn toàn: $\dfrac{AB}{ab}$ × $\dfrac{AB}{ab}$ cho **3 : 1**, còn $\dfrac{Ab}{aB}$ × $\dfrac{Ab}{aB}$ cho **1 : 2 : 1**. Phải xác định dị hợp đều hay chéo trước khi tính.

### 1.4. Vai trò của liên kết gene

- **Trong tự nhiên:** liên kết gene giúp duy trì sự **ổn định** của loài. Nhiều gene có lợi, cùng giúp sinh vật thích nghi với môi trường, có thể nằm trên cùng một NST. Chúng được truyền **cùng nhau** thành một "khối", không bị tách rời qua các thế hệ.
- **Trong chọn giống:**
  - Người ta dùng **chỉ thị phân tử**: những đoạn trình tự nucleotide nằm **rất gần** (liên kết chặt) với gene quy định tính trạng mong muốn. Chỉ cần kiểm tra DNA của cây non xem có chỉ thị hay không là biết cây có mang gene đó hay không. Không cần chờ cây lớn, ra hoa, kết quả mới thấy tính trạng.
  - Có thể gây đột biến **chuyển đoạn NST** để đưa các gene có lợi về **cùng một NST**, tạo giống mang nhiều đặc điểm tốt luôn đi kèm nhau.

> [!ung-dung]
> Gene kháng bệnh bạc lá ở lúa chỉ thể hiện khi cây bị nhiễm bệnh. Nhờ chỉ thị phân tử liên kết chặt với gene này, nhà chọn giống chỉ cần lấy một mẩu lá mạ để phân tích DNA là chọn được cây mang gene kháng. Việc chọn lọc nhanh hơn nhiều so với chờ lây bệnh ngoài đồng.

## 2. Hoán vị gene

### 2.1. Thí nghiệm của Morgan

Morgan làm tiếp một phép lai, lần này **đổi giới tính** của ruồi F~1~ đem lai phân tích (SGK tr. 56):

- **P** thuần chủng: thân xám, cánh dài × thân đen, cánh cụt → F~1~: 100% thân xám, cánh dài ($\dfrac{BV}{bv}$).
- **Lai phân tích con cái F~1~**: ♀ F~1~ thân xám, cánh dài × ♂ thân đen, cánh cụt.

Kết quả F~a~ có **4 kiểu hình**, nhưng tỉ lệ không phải 1 : 1 : 1 : 1:

| Kiểu hình F~a~ | Tỉ lệ | Loại |
|---|---|---|
| Thân xám, cánh dài | 41,5% | giống bố mẹ (kiểu **bố mẹ**) |
| Thân đen, cánh cụt | 41,5% | giống bố mẹ (kiểu **bố mẹ**) |
| Thân xám, cánh cụt | 8,5% | tổ hợp mới (kiểu **tái tổ hợp**) |
| Thân đen, cánh dài | 8,5% | tổ hợp mới (kiểu **tái tổ hợp**) |

Nhận xét:

- Hai kiểu hình giống bố mẹ vẫn **chiếm đa số** (83%) → hai gene vẫn liên kết với nhau (nếu phân li độc lập thì mỗi loại phải là 25%).
- Nhưng xuất hiện 17% kiểu hình **mới** → sự liên kết đã bị **phá vỡ** ở một phần giao tử của con cái F~1~.

Vì con đực thân đen, cánh cụt chỉ cho một loại giao tử bv, nên tỉ lệ kiểu hình F~a~ **chính là** tỉ lệ giao tử của ruồi cái F~1~: 41,5% BV : 41,5% bv : 8,5% Bv : 8,5% bV.

> [!em-co-biet] Vì sao đổi giới tính lại cho kết quả khác?
> Ở ruồi giấm, con **đực** gần như không xảy ra trao đổi chéo khi giảm phân, nên gene liên kết **hoàn toàn**; con **cái** thì có trao đổi chéo. Vì thế lai phân tích con đực F~1~ cho 1 : 1, còn lai phân tích con cái F~1~ cho 4 kiểu hình. (Ở tằm dâu thì ngược lại: con cái không hoán vị.) Trong đề thi, nếu đề nói "ruồi giấm" mà không nói gì thêm, em hiểu là **hoán vị chỉ xảy ra ở con cái**.

### 2.2. Cơ sở tế bào học — trao đổi chéo

Ở **kì đầu giảm phân I**, khi hai NST kép tương đồng bắt cặp, ở **một số tế bào** hai **chromatid không chị em** có thể bắt chéo nhau. Chúng đứt ra ở cùng một vị trí rồi **nối đổi đoạn** cho nhau. Đó là **trao đổi chéo**. Nếu điểm bắt chéo nằm **giữa** hai gene đang xét, các allele đổi chỗ cho nhau giữa hai chromatid và tạo ra tổ hợp gene mới:

![Hình 2. Trao đổi chéo giữa hai chromatid không chị em ở kì đầu giảm phân I: một tế bào AB/ab tạo 4 giao tử, trong đó 2 giao tử liên kết (AB, ab) và 2 giao tử hoán vị (Ab, aB)](hinh-2-trao-doi-cheo.svg)

Theo dõi Hình 2:

1. Sau nhân đôi, cặp NST $\dfrac{AB}{ab}$ có 4 chromatid: A B, A B (chị em) và a b, a b (chị em).
2. Trao đổi chéo xảy ra giữa **một** chromatid mang A B và **một** chromatid mang a b (không chị em), tại điểm nằm giữa A và B.
3. Sau trao đổi: 4 chromatid là **A B, A b, a B, a b**.
4. Qua hai lần phân bào, mỗi giao tử nhận một chromatid → tế bào này cho **4 loại giao tử, mỗi loại ¼**. Hai giao tử Ab và aB là **giao tử hoán vị** (tái tổ hợp). Hai giao tử AB và ab vẫn là **giao tử liên kết**.

> [!ghi-nho] Hoán vị gene
> **Hoán vị gene** là hiện tượng các allele tương ứng của một gene **đổi vị trí** cho nhau trên cặp NST tương đồng, làm xuất hiện các **tổ hợp gene mới**, từ đó tạo ra các tổ hợp kiểu hình mới. Nguyên nhân: **trao đổi chéo** giữa các chromatid không chị em của cặp NST kép tương đồng ở **kì đầu giảm phân I**.

### 2.3. Tần số hoán vị gene — vì sao không vượt quá 50%?

**Tần số hoán vị gene (f)** = tỉ lệ phần trăm các giao tử tái tổ hợp (giao tử hoán vị) trên tổng số giao tử.

Ở thí nghiệm Morgan: f = 8,5% + 8,5% = **17%**.

**Liên hệ với số tế bào có trao đổi chéo.** Một tế bào có trao đổi chéo (giữa hai gene) cho 4 giao tử, trong đó chỉ **2** giao tử hoán vị, tức **một nửa**. Tế bào không trao đổi chéo thì không cho giao tử hoán vị nào. Vậy:

**f = ½ × (tỉ lệ tế bào có trao đổi chéo giữa hai gene)**

Trong sơ đồ minh hoạ của SGK (tr. 57), 34% số tế bào xảy ra trao đổi chéo → f = 34% : 2 = 17%. Kết quả này khớp với số liệu lai phân tích.

**Vì sao f ≤ 50%?** Ngay cả khi **100%** tế bào đều có trao đổi chéo giữa hai gene, mỗi tế bào cũng chỉ cho một nửa số giao tử là hoán vị → f tối đa = ½ × 100% = **50%**. (Trên thực tế không phải tế bào nào cũng trao đổi chéo, nên f thường nhỏ hơn 50% nhiều.) Khi f = 50%, cơ thể cho 4 loại giao tử bằng nhau, kết quả lai **giống hệt** phân li độc lập.

> [!vi-du] Ví dụ 2
> Một cơ thể đực có kiểu gene $\dfrac{AB}{ab}$. Khi giảm phân, có 1 000 tế bào sinh tinh; trong đó 240 tế bào xảy ra trao đổi chéo giữa A và B. Tính tần số hoán vị gene và số lượng tinh trùng mang Ab.

> [!goi-y] Gợi ý 1
> Mỗi tế bào sinh tinh cho 4 tinh trùng. Tổng có bao nhiêu tinh trùng?

> [!goi-y] Gợi ý 2
> Mỗi tế bào có trao đổi chéo cho đúng 1 Ab, 1 aB, 1 AB, 1 ab.

> [!loi-giai] Lời giải
> Bước 1: Tổng số tinh trùng = 1 000 × 4 = 4 000.
>
> Bước 2: Số tinh trùng hoán vị = 240 × 2 = 480 (gồm 240 Ab và 240 aB).
>
> Bước 3: f = 480 : 4 000 = 12% (cũng bằng ½ × 240/1 000 = ½ × 24%).
>
> Kết luận: **f = 12%**, có **240** tinh trùng mang Ab.

### 2.4. Tỉ lệ giao tử khi có hoán vị với tần số f

Hai giao tử hoán vị có tỉ lệ bằng nhau, hai giao tử liên kết cũng bằng nhau:

- Mỗi giao tử **hoán vị** chiếm **f/2**.
- Mỗi giao tử **liên kết** chiếm **(1 − f)/2**.

**Giao tử nào là hoán vị?** Là giao tử **không có sẵn** trên NST của cơ thể ban đầu:

| Giao tử | Từ $\dfrac{AB}{ab}$ (dị hợp đều) | Từ $\dfrac{Ab}{aB}$ (dị hợp chéo) |
|---|---|---|
| AB | $\dfrac{1-f}{2}$ (liên kết) | $\dfrac{f}{2}$ (hoán vị) |
| ab | $\dfrac{1-f}{2}$ (liên kết) | $\dfrac{f}{2}$ (hoán vị) |
| Ab | $\dfrac{f}{2}$ (hoán vị) | $\dfrac{1-f}{2}$ (liên kết) |
| aB | $\dfrac{f}{2}$ (hoán vị) | $\dfrac{1-f}{2}$ (liên kết) |

> [!meo] Luôn có
> - Mỗi giao tử liên kết **luôn ≥ 25%**, mỗi giao tử hoán vị **luôn ≤ 25%** (vì f ≤ 50%; bằng 25% khi f = 50%).
> - Chỉ cần nhớ tỉ lệ giao tử **ab**: dị hợp đều → ab = (1 − f)/2 (≥ 25%); dị hợp chéo → ab = f/2 (≤ 25%).

> [!vi-du] Ví dụ 3
> Cơ thể có kiểu gene $\dfrac{Ab}{aB}$ giảm phân xảy ra hoán vị gene với tần số 20%. Xác định tỉ lệ các loại giao tử.

> [!goi-y] Gợi ý 1
> Đây là dị hợp chéo: hai giao tử liên kết là Ab và aB (có sẵn trên NST). Hai giao tử hoán vị là gì?

> [!loi-giai] Lời giải
> Giao tử liên kết: Ab = aB = (1 − 0,2) : 2 = **40%**.
>
> Giao tử hoán vị: AB = ab = 0,2 : 2 = **10%**.
>
> Kiểm tra: 40 + 40 + 10 + 10 = 100%. ✓

> [!bay]
> - Nhầm "giao tử hoán vị = f" (thực ra **mỗi loại** chỉ là f/2; **tổng** hai loại mới là f).
> - Quên xét dị hợp đều hay chéo: cùng f = 20% nhưng ab = 40% (đều) hay 10% (chéo).
> - Cơ thể chỉ dị hợp **một** cặp, ví dụ $\dfrac{AB}{Ab}$: hoán vị cũng không tạo giao tử mới (chỉ có AB và Ab, mỗi loại 50%). Hoán vị chỉ có "tác dụng" khi dị hợp **cả hai** cặp.

### 2.5. Tính tần số hoán vị từ phép lai phân tích

Lai phân tích cơ thể dị hợp hai cặp với cơ thể $\dfrac{ab}{ab}$ (chỉ cho giao tử ab), thì **tỉ lệ kiểu hình đời con = tỉ lệ giao tử** của cơ thể dị hợp. Do đó:

**f = (số cá thể thuộc hai kiểu hình chiếm tỉ lệ nhỏ) : (tổng số cá thể) × 100%**

- Hai kiểu hình **chiếm nhiều** ↔ giao tử liên kết → cho biết allele nào nằm cùng NST.
- Hai kiểu hình **chiếm ít** ↔ giao tử hoán vị.

> [!vi-du] Ví dụ 4
> Ở cà chua, A – thân cao, a – thân thấp; B – quả tròn, b – quả bầu dục (trội hoàn toàn). Cho cây thân cao, quả tròn (cây X) lai với cây thân thấp, quả bầu dục, đời con có: 205 cây cao, bầu dục : 203 cây thấp, tròn : 47 cây cao, tròn : 45 cây thấp, bầu dục. Xác định kiểu gene của X và tần số hoán vị gene.

> [!goi-y] Gợi ý 1
> Đây là phép lai phân tích. Đời con có 4 kiểu hình, 2 nhiều 2 ít → hai gene liên kết, có hoán vị.

> [!goi-y] Gợi ý 2
> Hai kiểu hình chiếm nhiều (cao, bầu dục và thấp, tròn) ứng với giao tử **liên kết** của X là Ab và aB. Vậy X là dị hợp đều hay chéo?

> [!loi-giai] Lời giải
> Bước 1: Tổng = 205 + 203 + 47 + 45 = 500 cây.
>
> Bước 2: Giao tử liên kết của X là Ab và aB → X có kiểu gene $\dfrac{Ab}{aB}$ (dị hợp chéo).
>
> Bước 3: Kiểu hình tái tổ hợp (cao, tròn và thấp, bầu dục) = 47 + 45 = 92 cây → f = 92 : 500 = **18,4%**.

> [!bay]
> Kiểu hình "trội – trội" và "lặn – lặn" **không phải lúc nào** cũng là kiểu bố mẹ. Ở Ví dụ 4, chúng lại là kiểu **tái tổ hợp** vì X dị hợp chéo. Luôn so sánh **số lượng**: nhóm nhiều là liên kết, nhóm ít là hoán vị.

**So sánh nhanh kết quả lai phân tích cơ thể dị hợp hai cặp:**

| Kết quả F~a~ | Kết luận |
|---|---|
| 4 kiểu hình, 1 : 1 : 1 : 1 | phân li độc lập (hoặc cùng NST nhưng f = 50%) |
| 2 kiểu hình, 1 : 1 | liên kết hoàn toàn |
| 4 kiểu hình, 2 lớn bằng nhau + 2 nhỏ bằng nhau | liên kết không hoàn toàn (có hoán vị), f = tổng 2 nhóm nhỏ |

### 2.6. Vai trò của hoán vị gene

- Hoán vị gene tạo ra **giao tử tái tổ hợp** mang tổ hợp gene mới. Các giao tử này lại kết hợp ngẫu nhiên khi thụ tinh. Kết quả là **nguồn biến dị di truyền tăng lên**, cung cấp nguyên liệu cho **tiến hoá** và **chọn giống**.
- Nhờ hoán vị, các gene tốt vốn nằm trên **hai chiếc NST khác nhau** của cặp tương đồng có thể được "gom" về **cùng một chiếc NST**, tạo nhóm gene liên kết có lợi.
- Dựa vào tần số hoán vị, người ta lập được **bản đồ di truyền** (mục 3).

> [!ghi-nho] Liên kết và hoán vị — hai mặt bổ sung cho nhau
> Liên kết gene giữ cho các nhóm gene **ổn định** qua các thế hệ. Hoán vị gene tạo ra **tổ hợp mới**, tăng biến dị. Một loài vừa cần ổn định, vừa cần đa dạng.

## 3. Bản đồ di truyền

### 3.1. Khái niệm

**Ý tưởng then chốt:** trao đổi chéo có thể xảy ra ở vị trí bất kì dọc theo NST. Hai gene nằm **càng xa nhau** thì có càng nhiều vị trí "chen giữa" để điểm trao đổi chéo rơi vào → **tần số hoán vị càng lớn**. Ngược lại, hai gene rất gần nhau thì hiếm khi bị tách ra → f nhỏ, gần như liên kết hoàn toàn.

Vậy có thể dùng f như một **thước đo khoảng cách** giữa các gene:

**1% tần số hoán vị = 1 cM (centiMorgan)**

(Đơn vị mang tên Morgan để ghi nhận công của ông.)

**Bản đồ di truyền** là sơ đồ biểu diễn **trật tự sắp xếp** và **khoảng cách tương đối** giữa các gene trên NST. Loại bản đồ dựng từ tần số hoán vị gene còn gọi là **bản đồ liên kết**. Một loại khác là **bản đồ vật lí**: khoảng cách giữa các gene tính bằng **số cặp nucleotide** (đọc từ trình tự DNA). Hai loại bản đồ cho cùng **trật tự** gene nhưng **khoảng cách** được biểu thị khác nhau (SGK tr. 58).

![Hình 3. Bản đồ di truyền của ba gene A, B, C trên một NST, khoảng cách tính bằng cM (1 cM = 1% tần số hoán vị)](hinh-3-ban-do.svg)

**Cách xác định trật tự ba gene.** Biết tần số hoán vị giữa từng cặp gene, gene nào nằm **giữa** thì khoảng cách lớn nhất (giữa hai gene đầu mút) xấp xỉ **bằng tổng** hai khoảng cách còn lại.

> [!vi-du] Ví dụ 5
> Ba gene D, E, G cùng nằm trên một NST. Tần số hoán vị: D–E = 15%, E–G = 6%, D–G = 9%. Xác định trật tự và vẽ bản đồ.

> [!goi-y] Gợi ý 1
> Khoảng cách lớn nhất là 15 cM (D–E). Tổng hai khoảng cách còn lại bằng bao nhiêu?

> [!loi-giai] Lời giải
> Bước 1: D–G + G–E = 9 + 6 = 15 = D–E → G nằm **giữa** D và E.
>
> Bước 2: Bản đồ: **D —(9 cM)— G —(6 cM)— E**.
>
> Vậy nếu cơ thể $\dfrac{DE}{de}$ giảm phân, mỗi giao tử hoán vị De hoặc dE chiếm khoảng 15% : 2 = 7,5%.

> [!bay]
> Với hai gene ở rất xa nhau trên cùng một NST, tần số hoán vị đo được chỉ tiến tới **50%**, không vượt quá. Nên khoảng cách trên bản đồ (cộng dồn từ các đoạn ngắn) có thể > 50 cM, nhưng **f đo được giữa hai gene thì không bao giờ > 50%**.

### 3.2. Ý nghĩa của bản đồ di truyền

- **Dự đoán** trước tần số các tổ hợp gene mới trong các phép lai → chủ động chọn cặp lai, ước tính cần trồng/nuôi bao nhiêu cá thể để thu được tổ hợp mong muốn. Điều này rất có ý nghĩa trong **chọn, tạo giống**.
- Xác định **vị trí** của gene, kể cả gene gây bệnh ở người → phục vụ **y học** (chẩn đoán, tư vấn di truyền).
- Tìm các **chỉ thị phân tử** nằm sát gene quan tâm để chọn giống nhờ chỉ thị (mục 1.4).

> [!ung-dung] Chọn nhầm bao nhiêu khi dùng chỉ thị phân tử?
> Giả sử chỉ thị M nằm cách gene kháng bệnh R là 2 cM. Cây $\dfrac{MR}{mr}$ cho giao tử Mr chiếm 1% và MR chiếm 49%. Nếu chọn cây con theo chỉ thị M, thì trong số giao tử mang M có 1 : 50 = **2%** không mang R. Nghĩa là cứ khoảng 50 cây chọn được thì có 1 cây "chọn nhầm". Chỉ thị càng gần gene thì càng ít nhầm. Vì vậy người ta luôn tìm chỉ thị liên kết **chặt** nhất.

## 4. Quan điểm của Mendel và Morgan về tính quy luật của di truyền

| | Mendel | Morgan |
|---|---|---|
| Đối tượng | Đậu hà lan | Ruồi giấm |
| Đơn vị di truyền | "Nhân tố di truyền" tồn tại thành cặp, **riêng rẽ, không pha trộn**; mỗi nhân tố nhận từ bố hoặc mẹ | Nhân tố di truyền (gene) **nằm trên NST** tại các locus xác định |
| Phương pháp | Mô hình toán học: thống kê, xác suất để phân tích số liệu lai | Kết hợp phân tích con lai với **cơ sở tế bào học** (hành vi NST) |
| Phát hiện | Quy luật phân li, phân li độc lập | Liên kết gene, hoán vị gene; bằng chứng cho **thuyết di truyền NST** |

Hai quan điểm **không mâu thuẫn mà bổ sung cho nhau**:

- Morgan chứng minh các "nhân tố" của Mendel chính là gene nằm trên NST. Đó là bằng chứng mạnh nhất cho thuyết di truyền NST.
- Phân li độc lập đúng khi các gene nằm trên **các NST khác nhau**. Liên kết gene đúng khi chúng nằm trên **cùng một NST**. Hoán vị gene là cơ chế **phá vỡ một phần** sự liên kết, tạo kiểu hình mới khác bố mẹ.

> [!em-co-biet]
> Năm 1913, Alfred Sturtevant khi còn là sinh viên trong nhóm của Morgan đã dựng **bản đồ di truyền đầu tiên** cho các gene trên NST X của ruồi giấm, chỉ từ các tần số hoán vị. Morgan nhận giải Nobel Sinh lí học hoặc Y học năm 1933.

## Dạng bài thi hay gặp

> [!ghi-nho] Chìa khóa chung: GIAO TỬ trước, ĐỜI CON sau
> 1. Xác định kiểu gene dị hợp **đều** hay **chéo**.
> 2. Viết tỉ lệ giao tử: liên kết (1 − f)/2, hoán vị f/2 (liên kết hoàn toàn: f = 0).
> 3. Tổ hợp giao tử để ra đời con. Với bài kiểu hình, tính qua tỉ lệ **aabb** (= tích tỉ lệ giao tử ab của hai bên).

### Dạng 1. Tính tỉ lệ giao tử

*Nhận biết:* cho kiểu gene (có thể kèm một cặp gene phân li độc lập) và tần số hoán vị, hỏi tỉ lệ một loại giao tử.

*Phương pháp:*
1. Cặp gene nằm trên NST khác: tính riêng như Mendel (½).
2. Cặp gene liên kết: tính theo bảng ở mục 2.4.
3. Nhân các tỉ lệ (vì các NST khác nhau phân li độc lập).

> [!vi-du] Ví dụ 6
> Cơ thể có kiểu gene $Dd\dfrac{AB}{ab}$ giảm phân, hoán vị gene giữa A và B với tần số 30%. Tính tỉ lệ giao tử d Ab.

> [!goi-y] Gợi ý 1
> Cặp Dd nằm trên NST khác → d = ½. Ab là giao tử liên kết hay hoán vị của $\dfrac{AB}{ab}$?

> [!loi-giai] Lời giải
> Ab là giao tử hoán vị → Ab = 0,3 : 2 = 0,15.
>
> d Ab = ½ × 0,15 = **0,075 = 7,5%**.

*Bẫy:* tính Ab = 0,35 (nhầm thành giao tử liên kết) hoặc quên nhân ½ của cặp Dd.

### Dạng 2. Tìm kiểu gene và tần số hoán vị từ phép lai phân tích

*Nhận biết:* "lai phân tích", "lai với cây đồng hợp lặn", đời con có 4 kiểu hình với 2 nhóm nhiều – ít.

*Phương pháp:* (xem mục 2.5)
1. Tỉ lệ kiểu hình đời con = tỉ lệ giao tử của cơ thể đem lai.
2. Hai kiểu hình nhiều → giao tử liên kết → suy ra dị hợp đều/chéo.
3. f = tổng tỉ lệ hai kiểu hình ít.

> [!vi-du] Ví dụ 7
> Ở một loài, cho cơ thể dị hợp hai cặp gene (A, a và B, b; trội hoàn toàn) lai phân tích, đời con có kiểu hình lặn về cả hai tính trạng (aabb) chiếm 6%. Xác định kiểu gene của cơ thể đem lai và tần số hoán vị.

> [!goi-y] Gợi ý 1
> aabb ở đời con = (giao tử ab của cơ thể dị hợp) × 1. Vậy ab = 6%. Con số này lớn hơn hay nhỏ hơn 25%?

> [!loi-giai] Lời giải
> Bước 1: ab = 6% < 25% → ab là giao tử **hoán vị** → cơ thể đem lai là $\dfrac{Ab}{aB}$ (dị hợp chéo).
>
> Bước 2: f = 2 × 6% = **12%**.

*Bẫy:* thấy aabb là "lặn – lặn" liền nghĩ đó là giao tử liên kết → kết luận dị hợp đều, khi đó (1 − f) : 2 = 6% → f = 88% > 50% (vô lí). Luôn so ab với 25% trước.

### Dạng 3. Tỉ lệ kiểu hình đời con khi P dị hợp hai cặp × dị hợp hai cặp

*Nhận biết:* hai bên P đều dị hợp hai cặp gene cùng NST (tự thụ phấn, F~1~ × F~1~…), có hoán vị ở **một bên** hoặc **hai bên**.

*Phương pháp — mẹo aabb:* Khi **cả hai bên P đều dị hợp hai cặp** (Aa và Bb), mỗi tính trạng riêng lẻ vẫn phân li 3 trội : 1 lặn. Ta có hệ thức:

- **A-B- = 0,5 + aabb**
- **A-bb = aaB- = 0,25 − aabb**

**Vì sao?** Tỉ lệ aa = ¼ → aaB- + aabb = 0,25 → aaB- = 0,25 − aabb. Tương tự A-bb = 0,25 − aabb. Bốn kiểu hình cộng lại bằng 1 → A-B- = 1 − 2(0,25 − aabb) − aabb = 0,5 + aabb.

Các bước:
1. Tính ab của từng bên (bên không hoán vị: f = 0).
2. aabb = ab (bên 1) × ab (bên 2).
3. Suy ra 3 kiểu hình còn lại bằng hệ thức trên.

> [!vi-du] Ví dụ 8
> Ở ruồi giấm, A – thân xám, a – thân đen; B – cánh dài, b – cánh cụt (trội hoàn toàn); hai gene cùng nằm trên một NST thường. Cho ♀ $\dfrac{AB}{ab}$ × ♂ $\dfrac{AB}{ab}$. Ở con cái xảy ra hoán vị với tần số 20%. Tính tỉ lệ các kiểu hình ở đời con.

> [!goi-y] Gợi ý 1
> Ruồi giấm đực không hoán vị → con đực cho ab = 50%. Con cái dị hợp đều, f = 20% → ab = ?

> [!goi-y] Gợi ý 2
> aabb = ab (♀) × ab (♂). Rồi dùng A-B- = 0,5 + aabb.

> [!loi-giai] Lời giải
> Bước 1: ♀: ab = (1 − 0,2) : 2 = 0,4. ♂: ab = 0,5.
>
> Bước 2: aabb = 0,4 × 0,5 = 0,20.
>
> Bước 3: A-B- = 0,5 + 0,2 = 0,70; A-bb = aaB- = 0,25 − 0,2 = 0,05.
>
> Kết luận: **70% xám, dài : 5% xám, cụt : 5% đen, dài : 20% đen, cụt**.

> [!vi-du] Ví dụ 9 (hoán vị hai bên, dị hợp chéo — tính ngược)
> Ở một loài thực vật, cho cây F~1~ dị hợp hai cặp gene (trội hoàn toàn) tự thụ phấn. F~2~ có 4 kiểu hình, trong đó cây mang hai tính trạng lặn chiếm 4%. Biết hoán vị xảy ra ở cả hai giới với tần số như nhau. Tìm kiểu gene F~1~, tần số hoán vị và tỉ lệ cây trội cả hai tính trạng ở F~2~.

> [!goi-y] Gợi ý 1
> Tự thụ phấn → hai bên giống nhau → aabb = (ab)^2^. Lấy căn bậc hai.

> [!goi-y] Gợi ý 2
> ab vừa tìm được lớn hơn hay nhỏ hơn 25%? Điều đó cho biết dị hợp đều hay chéo.

> [!loi-giai] Lời giải
> Bước 1: (ab)^2^ = 0,04 → ab = 0,2.
>
> Bước 2: 0,2 < 0,25 → ab là giao tử hoán vị → F~1~ là $\dfrac{Ab}{aB}$, f = 2 × 0,2 = **40%**.
>
> Bước 3: A-B- = 0,5 + 0,04 = **54%**.

*Bẫy:*
- Dùng mẹo "0,5 + aabb" cho phép lai mà một bên **không** dị hợp hai cặp (ví dụ $\dfrac{AB}{ab}$ × $\dfrac{Ab}{ab}$) → sai, vì khi đó tỉ lệ aa không còn là ¼.
- Quên rằng ruồi giấm đực không hoán vị (đề cho ruồi giấm mà vẫn tính hoán vị hai bên).
- Tự thụ phấn liên kết hoàn toàn: $\dfrac{AB}{ab}$ → 3 : 1; $\dfrac{Ab}{aB}$ → 1 : 2 : 1 (aabb = 0). Hệ thức trên vẫn đúng: aabb = 0 → A-B- = 50%, A-bb = aaB- = 25%.

> [!meo] Bấm máy nhanh
> Có aabb = x → A-B- = 0,5 + x; A-bb = aaB- = 0,25 − x. Ví dụ x = 0,16 → 0,66 : 0,09 : 0,09 : 0,16. Kiểm tra tổng = 1.

### Dạng 4. Lập bản đồ di truyền từ tần số hoán vị

*Nhận biết:* cho tần số hoán vị (hoặc khoảng cách cM) giữa các cặp gene, hỏi trật tự gene hoặc khoảng cách còn lại.

*Phương pháp:*
1. Đổi tần số hoán vị sang cM (1% = 1 cM).
2. Tìm khoảng cách lớn nhất; gene không thuộc cặp đó nằm **giữa**.
3. Kiểm tra: khoảng cách lớn ≈ tổng hai khoảng cách nhỏ.

> [!vi-du] Ví dụ 10
> Trên một NST có bốn gene P, Q, R, S. Tần số hoán vị: P–Q = 12%; Q–R = 5%; P–R = 17%; R–S = 20%; Q–S = 25%. Xác định trật tự bốn gene.

> [!goi-y] Gợi ý 1
> Xét ba gene P, Q, R trước: 12 + 5 = 17 → gene nào ở giữa?

> [!goi-y] Gợi ý 2
> Đặt P ở vị trí 0 trên thước. Q, R ở vị trí bao nhiêu? S cách R 20 cM và cách Q 25 cM thì S ở bên nào của R?

> [!loi-giai] Lời giải
> Bước 1: P–Q + Q–R = 12 + 5 = 17 = P–R → Q ở giữa P và R. Đặt P = 0, Q = 12, R = 17.
>
> Bước 2: S cách R 20 cM → S = 37 hoặc S = −3. Kiểm tra với Q–S = 25: S = 37 thì 37 − 12 = 25 ✓; S = −3 thì 12 − (−3) = 15 ✗.
>
> Kết luận: trật tự **P – Q – R – S** (P 0; Q 12; R 17; S 37 cM).

*Bẫy:* cộng hai khoảng cách bất kì mà không kiểm tra với dữ kiện thứ ba; hoặc đổi nhầm f = 17% thành 34 cM (nhân đôi, nhầm với tỉ lệ tế bào trao đổi chéo).

## Tóm tắt

| | Phân li độc lập | Liên kết hoàn toàn | Hoán vị gene (tần số f) |
|---|---|---|---|
| Vị trí hai gene | hai cặp NST khác nhau | cùng một NST | cùng một NST |
| Kí hiệu | AaBb | viết theo NST: AB/ab (đều), Ab/aB (chéo) | như liên kết hoàn toàn |
| Số loại giao tử | 4 (mỗi loại 25%) | 2 (mỗi loại 50%) | 4: liên kết (1 − f)/2, hoán vị f/2 |
| Lai phân tích | 1 : 1 : 1 : 1 | 1 : 1 | 2 lớn + 2 nhỏ |
| Cơ sở tế bào học | các cặp NST phân li độc lập | gene trên một NST phân li cùng nhau | trao đổi chéo giữa chromatid không chị em, kì đầu GP I |
| Ý nghĩa | tăng biến dị tổ hợp | duy trì ổn định nhóm gene có lợi | tăng biến dị; lập bản đồ di truyền |

**Công thức cần nhớ:**

- Số nhóm gene liên kết = n.
- f = tổng % giao tử hoán vị = ½ × % tế bào có trao đổi chéo; 0 ≤ f ≤ 50%.
- Lai phân tích: f = tổng tỉ lệ hai kiểu hình chiếm ít.
- P dị hợp hai cặp × dị hợp hai cặp: A-B- = 0,5 + aabb; A-bb = aaB- = 0,25 − aabb.
- Bản đồ: 1% hoán vị = 1 cM; gene ở giữa khi khoảng cách lớn = tổng hai khoảng cách nhỏ.
