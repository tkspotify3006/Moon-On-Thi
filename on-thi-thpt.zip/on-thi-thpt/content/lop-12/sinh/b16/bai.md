---
title: Tương tác giữa kiểu gene với môi trường và thành tựu chọn giống
thoi-gian: 35 phút
muc-tieu:
  - Phân tích được kiểu gene và môi trường cùng tác động như thế nào để tạo ra kiểu hình.
  - Nêu được khái niệm mức phản ứng và lấy được ví dụ minh hoạ.
  - Giải thích được vì sao bố mẹ không truyền cho con "tính trạng có sẵn" mà truyền một kiểu gene với mức phản ứng của nó.
  - Vận dụng hiểu biết về thường biến và mức phản ứng để giải thích các biện pháp trong chọn giống, trồng trọt, chăn nuôi, y học.
  - Phân biệt được thường biến với đột biến và biến dị tổ hợp.
  - Nêu được các bước tạo giống bằng lai hữu tính và một số thành tựu chọn, tạo giống vật nuôi, cây trồng ở Việt Nam và trên thế giới.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Kiểu gene + môi trường → kiểu hình.** Gene cho "bản thiết kế" protein, môi trường cho nguyên liệu, năng lượng và tín hiệu điều hoà biểu hiện gene.
> 2. Cùng một kiểu gene, ở các môi trường khác nhau cho các kiểu hình khác nhau. Những biến đổi kiểu hình đó gọi là **thường biến**. Thường biến **không làm thay đổi kiểu gene**, nên không di truyền.
> 3. **Mức phản ứng** là tập hợp các kiểu hình của **cùng một kiểu gene** ở các môi trường khác nhau. Mức phản ứng do **kiểu gene quy định** nên di truyền được. Bố mẹ truyền cho con **kiểu gene với mức phản ứng của nó**, không truyền tính trạng có sẵn.
> 4. Trong sản xuất: **giống** = kiểu gene, **kĩ thuật** = môi trường, **năng suất** = kiểu hình. Giống quy định năng suất tối đa, kĩ thuật quyết định năng suất cụ thể trong giới hạn đó.
> 5. Tạo giống bằng lai hữu tính: **tạo dòng thuần → lai các dòng → chọn lọc, nhân giống**. Thành tựu: gà Đông Tảo, lợn Landrace, bò Blanc-Blue-Belgium, lúa ST25, Đài thơm 8, lúa lai KC06-1…

SGK mở đầu bằng một câu hỏi rất "đời": năng lực học tập của mỗi người do **gene** hay do **môi trường** quyết định? Nhiều người trả lời "do gene" (con nhà nòi), nhiều người trả lời "do chăm chỉ". Bài này cho em thấy câu hỏi "gene **hay** môi trường" đặt chưa đúng. Câu trả lời của sinh học là: gene **và** môi trường, chúng **tương tác** với nhau.

> [!nen-tang] Nhắc lại từ Bài 2, Bài 3
> - Gene → (phiên mã) → mRNA → (dịch mã) → protein. Protein (enzyme, protein cấu trúc, hormone…) tham gia tạo nên các đặc điểm của cơ thể.
> - Gene không phải lúc nào cũng hoạt động. Tế bào **điều hoà biểu hiện gene**: bật hay tắt, nhiều hay ít, tuỳ tín hiệu (ví dụ operon *lac* chỉ phiên mã khi có lactose, Bài 3).
> - **Kiểu gene** là tổ hợp toàn bộ các gene trong tế bào của cơ thể. **Kiểu hình** là tổ hợp các tính trạng của cơ thể (hình thái, sinh lí, hoá sinh…).

## 1. Mối quan hệ giữa kiểu gene và môi trường

### 1.1. Sự tương tác giữa kiểu gene và môi trường

Hãy tưởng tượng em có một **công thức nấu ăn** rất chuẩn. Công thức giống như **gene**: nó chỉ dẫn phải làm gì. Nhưng món ăn ngon hay dở còn tuỳ **nguyên liệu** có đủ không, **bếp** nóng bao nhiêu, nấu lúc nào. Đó là **môi trường**. Món ăn cuối cùng chính là **kiểu hình**.

Cụ thể trong tế bào (Hình 1):

- **Gene** cung cấp thông tin để bộ máy của tế bào tổng hợp **protein**. Các protein này cùng các phân tử khác tạo nên đặc điểm kiểu hình.
- **Môi trường** (bên trong và bên ngoài cơ thể) cung cấp **nguyên liệu** cho tế bào chuyển hoá vật chất, năng lượng, đồng thời cung cấp các **tín hiệu** điều hoà gene nào được biểu hiện, biểu hiện mạnh hay yếu.
- Ngoài ra, môi trường còn có thể **ảnh hưởng trực tiếp** lên sản phẩm của gene (ví dụ nhiệt độ làm enzyme mất hoạt tính, độ pH làm sắc tố đổi màu).

![Hình 1. Kiểu gene quy định protein, môi trường cung cấp nguyên liệu, tín hiệu và tác động trực tiếp, hai bên cùng tạo nên kiểu hình](hinh-1-kg-mt-kh.svg)

Vì vậy, **cùng một kiểu gene** đặt trong các điều kiện môi trường khác nhau có thể cho **các kiểu hình khác nhau**. Những biến đổi kiểu hình như vậy được gọi là **thường biến** (SGK tr. 83). Một số tài liệu (ngoài SGK) gọi khả năng này của kiểu gene là **sự mềm dẻo kiểu hình**.

Hai ví dụ trong SGK:

- **Hoa phù dung** (*Hibiscus mutabilis*): trên cùng một cây, hoa nở buổi sáng màu **trắng**, đến chiều chuyển dần sang **hồng** (SGK tr. 83, Hình 16.1). Các tế bào của bông hoa có cùng kiểu gene từ sáng đến chiều. Cái thay đổi là điều kiện trong ngày (ánh sáng, nhiệt độ), làm sắc tố đỏ hồng được tích luỹ dần trong cánh hoa.
- **Người sinh đôi cùng trứng**: hai người phát triển từ cùng một hợp tử nên có kiểu gene gần như giống hệt. Nếu lớn lên ở hai môi trường khác nhau (dinh dưỡng, khí hậu, lối sống, học tập…), họ vẫn có nhiều điểm khác nhau về cân nặng, sức khoẻ, sở thích, kĩ năng…

> [!em-co-biet] Ngoài SGK: hoa cẩm tú cầu "đổi màu theo đất"
> Cây cẩm tú cầu (*Hydrangea macrophylla*) trồng trên **đất chua** thường cho hoa **xanh lam**. Cùng cây đó (hoặc cành giâm của nó) trồng trên **đất kiềm** lại cho hoa **hồng**. Nguyên nhân: ở đất chua, ion nhôm (Al^3+^) dễ hoà tan, được cây hút lên và kết hợp với sắc tố trong cánh hoa tạo màu lam. Ở đất kiềm, nhôm khó hoà tan nên hoa giữ màu hồng. Người trồng hoa chỉ cần chỉnh độ chua của đất là "chọn" được màu hoa, không cần đổi giống.

> [!vi-du] Ví dụ 1
> Cây rau mác mọc ở bờ ao có lá hình mũi mác (dạng đầu mũi tên). Nhưng khi một phần cây chìm trong nước, các lá mọc dưới nước lại có dạng **bản dài, mảnh như dải băng**. Lá dưới nước và lá trên cạn có phải do hai kiểu gene khác nhau quy định không? Hiện tượng này là loại biến dị nào? Nó có lợi gì cho cây?

> [!goi-y] Gợi ý 1
> Lá trên cạn và lá dưới nước mọc ra từ **cùng một cây**. Các tế bào của một cây có kiểu gene như thế nào?

> [!goi-y] Gợi ý 2
> Lá bản dài, mảnh có lợi gì khi ở dưới nước có dòng chảy?

> [!loi-giai] Lời giải
> Các lá đều mọc ra từ cùng một cây, các tế bào của cây được tạo ra bằng nguyên phân nên có **cùng kiểu gene**. Hình dạng lá khác nhau là do **môi trường** khác nhau (trong nước và trên cạn), nên đây là **thường biến**.
>
> Lá bản dài, mảnh ít bị dòng nước làm rách, còn lá mũi mác trên cạn có phiến rộng, hứng được nhiều ánh sáng. Thường biến giúp **cá thể thích nghi** với điều kiện sống thay đổi.

**Đặc điểm của thường biến** (SGK hiện hành không liệt kê thành mục riêng, đây là phần tổng hợp mở rộng, đề thi rất hay hỏi):

- Xảy ra **đồng loạt**, **theo cùng một hướng** ở các cá thể có cùng kiểu gene sống trong cùng điều kiện. Ví dụ, cả ruộng lúa thiếu đạm đều lá vàng, thấp cây.
- **Tương ứng** với sự thay đổi của môi trường, nên **dự đoán được**. Môi trường đổi lại thì kiểu hình cũng có thể đổi lại.
- **Không làm thay đổi kiểu gene**, nên **không di truyền** cho đời sau.
- Giúp cá thể **thích nghi** với những thay đổi của môi trường trong đời sống.

> [!bay] "Thường biến không di truyền" nhưng "khả năng có thường biến" thì di truyền
> Cây phù dung con mọc từ hạt không "nhớ" là bông hoa mẹ đã hồng vào buổi chiều. Nhưng nó nhận từ bố mẹ **kiểu gene** có khả năng đổi màu hoa theo điều kiện trong ngày. Vì thế, các bông hoa của nó cũng sẽ trắng buổi sáng, hồng buổi chiều. Cái được di truyền là **kiểu gene và cách nó phản ứng với môi trường**, không phải màu hoa ở một thời điểm.

**Phân biệt thường biến, đột biến và biến dị tổ hợp.**

Ba loại biến dị này đều làm sinh vật "khác đi", nhưng bản chất rất khác. Bảng dưới đây là phần tổng hợp mở rộng (ngoài SGK bài này, gom kiến thức từ nhiều bài), em nên thuộc:

| | Thường biến | Đột biến (Bài 4, Bài 12) | Biến dị tổ hợp (Bài 8, Bài 11) |
|---|---|---|---|
| Là gì? | Biến đổi **kiểu hình** của cùng một kiểu gene | Biến đổi trong **vật chất di truyền** (gene, NST) | **Tổ hợp lại** các allele sẵn có của bố mẹ |
| Nguyên nhân | Điều kiện **môi trường** thay đổi | Tác nhân vật lí, hoá học, sinh học, sai sót khi tái bản DNA | **Giảm phân** (phân li độc lập, hoán vị gene) và **thụ tinh** |
| Kiểu gene có đổi? | **Không** | **Có** (xuất hiện allele mới hoặc NST mới) | **Có** (tổ hợp allele mới, không có allele mới) |
| Di truyền? | **Không** | **Có** (nếu xảy ra ở tế bào sinh dục hoặc ở cây sinh sản sinh dưỡng) | **Có** |
| Tính chất | Đồng loạt, theo hướng xác định | Riêng lẻ, ngẫu nhiên, vô hướng | Riêng lẻ, theo quy luật di truyền |
| Ý nghĩa | Giúp cá thể thích nghi | Nguyên liệu **sơ cấp** cho tiến hoá và chọn giống | Nguyên liệu **thứ cấp** cho tiến hoá và chọn giống |

> [!meo] Ba câu hỏi để phân loại một biến dị
> - Các cá thể so sánh có **cùng kiểu gene** không (cùng cây, cành giâm, sinh đôi cùng trứng, dòng thuần)? Nếu có và khác nhau do môi trường → **thường biến**.
> - Có xuất hiện **allele mới, NST mới** (thường ở một vài cá thể lẻ tẻ, đột ngột) không? → **đột biến**.
> - Con có kiểu hình **mới so với bố mẹ** nhưng chỉ là sự **kết hợp lại** tính trạng của bố mẹ, ông bà (ví dụ hạt vàng, nhăn từ P vàng, trơn × xanh, nhăn) → **biến dị tổ hợp**.

### 1.2. Mức phản ứng

**a) Khái niệm**

Kiểu gene chỉ cung cấp **thông tin** để tạo ra sản phẩm. Còn sản phẩm có được tạo ra hay không, tạo ra nhiều hay ít, chất lượng ra sao thì còn tuỳ điều kiện môi trường. Vì thế, một kiểu gene có thể cho ra **nhiều kiểu hình** tương ứng với nhiều môi trường.

> **Mức phản ứng** của một kiểu gene là **tập hợp các kiểu hình** của **cùng một kiểu gene** tương ứng với các điều kiện môi trường khác nhau (SGK tr. 84).

Hai ví dụ trong SGK:

- **Ruồi giấm** đồng hợp về allele đột biến làm cánh tiêu biến: nếu ấu trùng được nuôi ở nhiệt độ **dưới 29 °C** thì ruồi trưởng thành có **cánh cụt**. Nhưng ấu trùng **cùng kiểu gene** nuôi ở khoảng **31 °C** lại có cánh dài **gần như bình thường**. Gene đột biến vẫn còn nguyên, chỉ có cách nó biểu hiện thay đổi theo nhiệt độ.
- **Cành giâm**: cắt nhiều cành từ **một cây** đem trồng ở các điều kiện khác nhau, các cây con có **chiều cao khác nhau**. Tập hợp các chiều cao đó (cùng một kiểu gene) là một phần mức phản ứng của kiểu gene về chiều cao cây.

**Vì sao dùng cành giâm?** Muốn biết mức phản ứng của **một** kiểu gene, ta phải có **nhiều cá thể cùng kiểu gene đó** rồi đặt vào các môi trường khác nhau. Nếu dùng các cây mọc từ hạt, chúng có kiểu gene khác nhau, ta sẽ không biết sự khác biệt do gene hay do môi trường. Các cách tạo cá thể cùng kiểu gene: **giâm, chiết, ghép cành, nuôi cấy mô** (sinh sản sinh dưỡng), dùng **dòng thuần chủng**, hoặc ở người là **trẻ sinh đôi cùng trứng**.

> [!vi-du] Ví dụ 2
> Từ một cây hoa hồng, người ta giâm 4 cành rồi trồng ở 4 điều kiện. Sau một năm, chiều cao các cây như sau:
>
> | Cây | Điều kiện trồng | Chiều cao (cm) |
> |---|---|---|
> | 1 | đất tốt, đủ nắng | 92 |
> | 2 | đất tốt, bóng râm | 110 |
> | 3 | đất nghèo, đủ nắng | 58 |
> | 4 | đất nghèo, bóng râm | 64 |
>
> a) Vì sao có thể nói 4 cây có cùng kiểu gene? Sự khác nhau về chiều cao thuộc loại biến dị nào?
>
> b) Một bạn kết luận: "Mức phản ứng về chiều cao của kiểu gene này là từ 58 cm đến 110 cm". Em có đồng ý hoàn toàn không?

> [!goi-y] Gợi ý 1
> Các cành giâm được tạo ra từ tế bào của cây nào, bằng hình thức phân bào nào?

> [!goi-y] Gợi ý 2
> Thí nghiệm mới thử bao nhiêu điều kiện? Còn những điều kiện khác (đất rất tốt và có giàn, đất rất khô…) thì sao?

> [!loi-giai] Lời giải
> a) Cả 4 cành đều lấy từ **một cây**, cây con mọc lên nhờ **nguyên phân**, nên có **cùng kiểu gene** với cây mẹ. Chiều cao khác nhau chỉ do điều kiện trồng khác nhau → **thường biến**.
>
> b) **Chưa hoàn toàn**. 58 cm và 110 cm chỉ là các kiểu hình **đo được trong 4 điều kiện đã thử**. Mức phản ứng là tập hợp kiểu hình ở **mọi** điều kiện mà kiểu gene có thể gặp, nên có thể rộng hơn. Nói đúng hơn: "Trong 4 điều kiện thí nghiệm, kiểu gene này cho chiều cao từ 58 cm đến 110 cm, chênh nhau 52 cm."
>
> Nhận xét thêm: cây 2 (bóng râm) cao nhất. Thiếu ánh sáng, cây thường **vươn cao**, thân mảnh để tìm sáng. Cao hơn không có nghĩa là khoẻ hơn.

**Bản chất của sự di truyền tính trạng.** Bây giờ em trả lời được câu hỏi trong SGK: "Nói tính trạng được di truyền từ bố mẹ sang con có chính xác không?"

**Không hoàn toàn chính xác.** Bố mẹ truyền cho con **các allele** (qua giao tử), tức là truyền một **kiểu gene**. Kiểu gene này quy định một **mức phản ứng**. Còn tính trạng cụ thể của con (cao bao nhiêu, nặng bao nhiêu…) được **hình thành lại** trong quá trình phát triển, nhờ sự tương tác giữa kiểu gene ấy với môi trường mà con sống. Vì vậy:

> Sự di truyền tính trạng thực chất là **di truyền mức phản ứng** của kiểu gene. Các đặc điểm của cơ thể không được truyền trực tiếp từ thế hệ này sang thế hệ khác (SGK tr. 84).

> [!bay] Đừng nhầm "mức phản ứng" với "thường biến"
> - **Thường biến**: từng **biến đổi kiểu hình** cụ thể (lá dưới nước bản dài, hoa chiều màu hồng…). Không di truyền.
> - **Mức phản ứng**: **giới hạn**, tức là **tập hợp tất cả** các kiểu hình mà kiểu gene có thể cho ra. Do kiểu gene quy định nên **di truyền được**.
> - Thường biến chỉ xảy ra **trong giới hạn** của mức phản ứng. Môi trường dù thay đổi mạnh đến đâu cũng không làm kiểu hình vượt ra ngoài mức phản ứng (nếu điều kiện quá khắc nghiệt, sinh vật chết).

**Mức phản ứng rộng và hẹp** (kiến thức bổ sung, đề thi hay hỏi). Mỗi tính trạng có mức phản ứng riêng:

- **Tính trạng số lượng** (đo, đếm, cân được: năng suất, sản lượng sữa, khối lượng cơ thể, số hạt trên bông…) do nhiều gene quy định và chịu ảnh hưởng mạnh của môi trường. Chúng thường có **mức phản ứng rộng**: chăm sóc tốt hay kém thì khác nhau rất nhiều.
- **Tính trạng chất lượng** (màu hoa, hình dạng hạt, nhóm máu, tỉ lệ bơ trong sữa của một giống bò…) thường có **mức phản ứng hẹp**, ít thay đổi theo điều kiện nuôi trồng.

Ví dụ: cùng một giống bò, cho ăn tốt thì **sản lượng sữa** tăng rõ rệt, nhưng **tỉ lệ bơ** trong sữa thay đổi rất ít. Muốn tăng tỉ lệ bơ, phải **đổi giống** (đổi kiểu gene), không chỉ đổi thức ăn.

**b) Đọc đồ thị mức phản ứng**

Trong đề thi, mức phản ứng hay được cho dưới dạng **bảng** hoặc **đồ thị**: trục ngang là điều kiện môi trường, trục dọc là kiểu hình (năng suất, chiều cao…), mỗi đường là **một kiểu gene** (một giống). Hình 2 là ví dụ với hai giống lúa X và Y trồng ở 5 mức phân đạm.

![Hình 2. Năng suất của hai giống lúa X và Y ở các mức bón đạm: giống X tăng mạnh theo lượng phân (mức phản ứng rộng), giống Y thay đổi ít (mức phản ứng hẹp)](hinh-2-muc-phan-ung.svg)

> [!vi-du] Ví dụ 3
> Dựa vào Hình 2 (số liệu năng suất, tấn/ha):
>
> | Lượng đạm (kg N/ha) | 0 | 40 | 80 | 120 | 160 |
> |---|---|---|---|---|---|
> | Giống X | 4,0 | 5,2 | 6,4 | 7,3 | 7,6 |
> | Giống Y | 4,6 | 5,1 | 5,5 | 5,7 | 5,8 |
>
> a) Tính chênh lệch giữa năng suất cao nhất và thấp nhất của mỗi giống. Giống nào có mức phản ứng về năng suất rộng hơn?
>
> b) Một hộ ở vùng đất nghèo, ít vốn, gần như không bón phân. Một hợp tác xã thâm canh, bón 120 – 160 kg N/ha. Nên khuyên mỗi nơi trồng giống nào?
>
> c) Có thể nói "giống X tốt hơn giống Y" không?

> [!goi-y] Gợi ý 1
> Chênh lệch = giá trị lớn nhất − giá trị nhỏ nhất trên cùng một hàng (cùng một giống).

> [!goi-y] Gợi ý 2
> Ở cột 0 kg N/ha, giống nào cao hơn? Ở cột 120 và 160 thì sao? Hai đường cắt nhau ở khoảng nào?

> [!loi-giai] Lời giải
> a) Giống X: 7,6 − 4,0 = **3,6 tấn/ha**. Giống Y: 5,8 − 4,6 = **1,2 tấn/ha**. Giống X có mức phản ứng về năng suất **rộng hơn**: nó "đáp ứng" mạnh khi điều kiện được cải thiện.
>
> b) Không bón phân: Y (4,6) > X (4,0) → hộ ít vốn nên trồng **giống Y**. Bón 120 – 160 kg N/ha: X (7,3 – 7,6) > Y (5,7 – 5,8) → hợp tác xã thâm canh nên trồng **giống X**.
>
> c) **Không**. Hai đường **cắt nhau** (trong khoảng 0 – 40 kg N/ha), nên giống nào "tốt hơn" còn tuỳ môi trường. Đây chính là ý nghĩa của **tương tác** kiểu gene – môi trường: không thể xếp hạng giống mà không nói rõ điều kiện trồng.

> [!bay] "Mức phản ứng rộng" không có nghĩa là "luôn năng suất cao"
> Giống có mức phản ứng rộng cho năng suất rất cao khi điều kiện tốt, nhưng ở điều kiện kém có thể thua giống khác. Khi đề hỏi "nên chọn giống nào", phải đọc **cột ứng với điều kiện của vùng đó**, không chọn theo độ rộng.

**c) Vận dụng hiểu biết về mức phản ứng**

**Trong y học.** Với một số bệnh di truyền, nếu biết gene gây bệnh biểu hiện như thế nào, người ta có thể **thay đổi môi trường** (thức ăn, luyện tập, sinh hoạt) để giảm nhẹ hoặc ngăn triệu chứng, dù kiểu gene không đổi.

- **Phenylketonuria (phenyl keto niệu, PKU)**: bệnh do **allele đột biến lặn trên NST thường**. Người bệnh không tổng hợp được enzyme chuyển hoá amino acid **phenylalanine**. Phenylalanine từ thức ăn tích tụ trong máu, gây độc cho hệ thần kinh đang phát triển, làm trẻ **chậm phát triển trí tuệ**. Nếu phát hiện sớm (sàng lọc sơ sinh) và cho trẻ ăn theo **chế độ hạn chế phenylalanine**, trẻ vẫn mang kiểu gene bệnh nhưng triệu chứng giảm rất nhiều hoặc không biểu hiện.
- **Galactosemia** (SGK tr. 87, Luyện tập 3): allele lặn làm mất enzyme chuyển hoá đường **galactose**, galactose tích tụ gây hàng loạt triệu chứng. Galactose có trong sữa (đường lactose của sữa bị phân giải thành glucose và galactose). Cách giảm nhẹ: cho trẻ dùng **chế độ ăn không có lactose, galactose**, ví dụ thay sữa thường bằng sữa công thức không lactose hoặc sữa từ đậu nành.

> [!vi-du] Ví dụ 4
> Một bé được chẩn đoán PKU ngay sau sinh và được ăn kiêng phenylalanine nghiêm ngặt. Bé lớn lên phát triển trí tuệ bình thường.
>
> a) Kiểu gene của bé có thay đổi sau khi ăn kiêng không?
>
> b) Vì sao phải phát hiện và ăn kiêng **càng sớm càng tốt**?
>
> c) Vì sao có thể nói đây là ứng dụng hiểu biết về mức phản ứng?

> [!goi-y] Gợi ý 1
> Thức ăn có thể sửa được DNA trong tế bào không?

> [!goi-y] Gợi ý 2
> Phenylalanine tích tụ gây hại cho cơ quan nào, vào giai đoạn nào?

> [!loi-giai] Lời giải
> a) **Không**. Bé vẫn đồng hợp tử về allele lặn gây bệnh. Chế độ ăn chỉ thay đổi **môi trường**, không sửa được gene.
>
> b) Tổn thương do phenylalanine tích tụ xảy ra ở **não đang phát triển** của trẻ nhỏ và rất khó phục hồi. Ăn kiêng muộn thì phần não đã tổn thương không trở lại bình thường.
>
> c) Cùng kiểu gene PKU, môi trường "nhiều phenylalanine" cho kiểu hình chậm phát triển trí tuệ, môi trường "ít phenylalanine" cho kiểu hình gần bình thường. Hai kiểu hình này đều nằm trong **mức phản ứng** của kiểu gene. Biết điều đó, bác sĩ chọn môi trường cho ra kiểu hình **có lợi** nhất.

> [!em-co-biet] Béo phì do gene hay do ăn nhiều? (SGK tr. 87)
> Ăn nhiều, ít vận động dễ gây béo phì, nhưng gene cũng góp phần. Ví dụ, gene mã hoá hormone **leptin** (hormone làm giảm cảm giác thèm ăn) nếu bị đột biến thì người đó ăn mãi không thấy no. Thú vị hơn, nếu người mẹ bị **thiếu ăn khi mang thai**, môi trường trong tử cung có thể làm thay đổi lâu dài cách biểu hiện một số gene của thai nhi theo hướng "tích trữ năng lượng". Khi trẻ sinh ra trong điều kiện đủ ăn, đặc điểm này lại làm tăng nguy cơ béo phì. Đây là ví dụ đẹp về môi trường tác động đến biểu hiện gene.

**Trong nông nghiệp.** Hãy "dịch" ba khái niệm sang ngôn ngữ nhà nông:

| Di truyền học | Nông nghiệp |
|---|---|
| Kiểu gene | **Giống** cây trồng, vật nuôi |
| Môi trường | **Kĩ thuật** canh tác, chăm sóc (phân bón, nước, thời vụ, mật độ, thức ăn…) |
| Kiểu hình | **Năng suất**, chất lượng sản phẩm |

Từ đó rút ra hai hệ quả:

1. **Giống quyết định giới hạn năng suất** (năng suất tối đa có thể đạt). Kĩ thuật chỉ giúp đạt đến gần giới hạn đó. Bón thêm phân cho giống cũ không thể vượt năng suất tối đa của nó. Muốn vượt, phải **tạo giống mới** có mức phản ứng cao hơn. Vì vậy, các nhà chọn giống tìm cách tạo giống có **mức phản ứng rộng** và **giới hạn cao** về các tính trạng liên quan đến năng suất, vừa cho năng suất cao, vừa thích nghi được với nhiều điều kiện canh tác.
2. **Kĩ thuật quyết định năng suất cụ thể** trong giới hạn của giống. Giống mới tốt mà trồng sai thời vụ, bón sai loại phân, sai liều lượng, sai thời điểm thì năng suất vẫn thấp. Nhà sản xuất giống đã khảo nghiệm và biết **môi trường tối ưu** cho giống, nên nông dân cần **làm đúng quy trình hướng dẫn**.

> [!ung-dung] Vì sao "nhất nước, nhì phân, tam cần, tứ giống" cần sửa lại?
> Câu tục ngữ cũ đặt giống ở cuối, vì ngày xưa các giống địa phương có năng suất tối đa thấp, có chăm đến đâu cũng chỉ được chừng ấy. Ngày nay, nhờ các giống mới có mức phản ứng cao, nhiều cánh đồng đạt 8 – 10 tấn/ha. Nhưng giống tốt chỉ phát huy khi đủ nước, đủ phân, đúng kĩ thuật. Giống và kĩ thuật **phải đi cùng nhau**, đúng như quan hệ kiểu gene – môi trường.

**Trong giáo dục và phát triển thể chất.** Mỗi người có một kiểu gene quy định mức phản ứng về chiều cao, thể lực, năng lực… Để đạt **mức cao nhất** trong giới hạn đó, cần **dinh dưỡng đầy đủ, cân đối**, **vận động** và sinh hoạt hợp lí theo lứa tuổi. Với năng lực học tập, ngoài các yếu tố trên còn cần **môi trường học tập tốt**: thầy cô, bạn bè, sách vở, thiết bị… Câu hỏi mở bài giờ có câu trả lời: gene vạch ra **giới hạn**, còn môi trường (và sự cố gắng của em) quyết định em đi **đến đâu** trong giới hạn đó.

> [!vi-du] Ví dụ 5 (thỏ Himalaya, đối chiếu Luyện tập 1, SGK tr. 87)
> Thỏ Himalaya được nuôi ở nhiệt độ thấp (khoảng 25 °C trở xuống) có lông trắng ở thân, nhưng lông ở **tai, mõm, bàn chân, đuôi** màu **đen**. Nuôi ở nhiệt độ cao (từ 30 °C trở lên), thỏ có lông **trắng toàn thân**.
>
> a) Đưa ra giả thuyết giải thích.
>
> b) Thiết kế một thí nghiệm để kiểm tra giả thuyết.

> [!goi-y] Gợi ý 1
> Các phần đen (tai, mõm, chân, đuôi) có điểm chung gì về **nhiệt độ** so với thân? Chúng nằm ở đâu trên cơ thể?

> [!goi-y] Gợi ý 2
> Lông đen do sắc tố melanin. Sắc tố được tạo ra nhờ enzyme. Enzyme nhạy cảm với yếu tố nào?

> [!goi-y] Gợi ý 3
> Muốn kiểm chứng, hãy **thay đổi nhiệt độ** ở một vùng da của chính con thỏ đó rồi xem lông mọc lại màu gì.

> [!loi-giai] Lời giải
> a) **Giả thuyết**: thỏ Himalaya có gene quy định enzyme tổng hợp sắc tố đen. Enzyme này **chỉ hoạt động ở nhiệt độ thấp** và bị bất hoạt ở nhiệt độ cao. Tai, mõm, chân, đuôi là các **phần đầu mút**, xa trung tâm cơ thể, mất nhiệt nhanh nên có **nhiệt độ thấp hơn** thân. Ở đó enzyme hoạt động → lông đen. Ở thân nhiệt độ cao hơn → enzyme không hoạt động → lông trắng. Khi nuôi ở môi trường ≥ 30 °C, cả các phần đầu mút cũng đủ ấm → toàn thân trắng. Mọi tế bào da của thỏ có **cùng kiểu gene**, màu lông khác nhau do **nhiệt độ** (thường biến).
>
> b) **Thí nghiệm**: chọn một con thỏ Himalaya nuôi ở 25 °C, **cạo một mảng lông trắng ở lưng**, rồi **chườm lạnh** (buộc túi nước đá) lên vùng đó trong thời gian lông mọc lại. Đồng thời cạo một mảng lông ở vị trí khác **không chườm lạnh** để đối chứng.
>
> Dự đoán nếu giả thuyết đúng: mảng được chườm lạnh mọc lông **đen**, mảng đối chứng mọc lông **trắng**. Có thể làm thêm thí nghiệm ngược: cạo lông đen ở tai rồi giữ ấm vùng đó, lông mọc lại sẽ **trắng**.
>
> Lưu ý: con thỏ có lông đen ở lưng sau thí nghiệm **không** truyền "lông lưng đen" cho con, vì kiểu gene không đổi.

## 2. Thành tựu chọn, tạo giống bằng các phương pháp lai hữu tính

### 2.1. Khái quát về chọn, tạo giống vật nuôi, cây trồng

**Giống là gì?** Theo SGK tr. 85:

- **Giống cây trồng** là một quần thể cây trồng **phân biệt được** với các quần thể cùng loài khác nhờ ít nhất một đặc tính di truyền được, **đồng nhất** về hình thái, **ổn định** qua các chu kì nhân giống, và có **giá trị canh tác, giá trị sử dụng**.
- **Giống vật nuôi** là quần thể vật nuôi cùng loài, cùng nguồn gốc, có ngoại hình và cấu trúc di truyền tương tự nhau, được hình thành, củng cố, phát triển **do tác động của con người**. Giống phải có **số lượng đủ lớn** để nhân giống và truyền được đặc điểm của giống cho đời sau.
- **Dòng** là một nhóm vật nuôi **trong một giống**, mang đặc điểm chung của giống nhưng có thêm **đặc điểm riêng đã ổn định**.

> [!meo] Nhớ định nghĩa giống cây trồng bằng 4 chữ
> **Khác** (phân biệt được) – **Đều** (đồng nhất) – **Bền** (ổn định qua các đời nhân giống) – **Có ích** (giá trị canh tác, sử dụng).

**Chọn giống** và **tạo giống** khác nhau thế nào?

- **Chọn giống**: con người **phát hiện** những cá thể có đặc điểm di truyền ưa thích (có sẵn trong tự nhiên hoặc trong quần thể), rồi cho chúng lai với nhau để tạo ra các **dòng, giống thuần chủng**. Việc này đã được làm từ xa xưa, khi con người chưa biết gì về gene.
- **Tạo giống** bằng lai hữu tính thường gồm 3 bước (Hình 3):
  1. **Tạo ra các dòng thuần chủng** khác nhau.
  2. **Lai các dòng** với nhau để tìm các cá thể có **tổ hợp** các đặc tính mong muốn (biến dị tổ hợp).
  3. **Nhân giống và chọn lọc** để được giống thuần chủng mới.

Ngoài ra, các dòng, giống thuần chủng có thể được lai với nhau để tìm **tổ hợp lai** cho con lai có **ưu thế lai** cao. **Ưu thế lai** là hiện tượng con lai có năng suất, sức chống chịu, khả năng sinh trưởng **cao hơn hẳn** so với các dòng bố mẹ. Phép lai tạo con lai có ưu thế lai để sử dụng làm sản phẩm được gọi là **phép lai kinh tế**.

![Hình 3. Các bước tạo giống bằng lai hữu tính và nhánh lai kinh tế để lấy con lai có ưu thế lai](hinh-3-tao-giong.svg)

**Vì sao phải tạo dòng thuần trước khi lai?** Dòng thuần có kiểu gene **đồng hợp** ở hầu hết các gene, nên con cháu của nó giống hệt nhau và giống bố mẹ. Nhờ vậy, khi lai hai dòng thuần, con lai F~1~ **đồng nhất**, và nhà chọn giống biết chắc tổ hợp allele mình đang có. Dòng thuần được tạo bằng cách cho **tự thụ phấn** (ở thực vật) hoặc **giao phối gần** (ở động vật) qua nhiều thế hệ kết hợp chọn lọc.

> [!nen-tang] Tự thụ phấn làm tăng tỉ lệ đồng hợp (học kĩ ở Bài 18)
> Cây Aa tự thụ phấn cho ¼ AA : ½ Aa : ¼ aa. Cây đồng hợp tự thụ phấn chỉ cho cây đồng hợp. Vì vậy, mỗi thế hệ tự thụ phấn, **tỉ lệ dị hợp giảm đi một nửa**. Sau n thế hệ, từ cây Aa ban đầu:
> $$\text{tỉ lệ dị hợp} = \left(\tfrac12\right)^n, \qquad \text{tỉ lệ đồng hợp} = 1 - \left(\tfrac12\right)^n$$

> [!vi-du] Ví dụ 6
> Một nhà chọn giống có cây lúa dị hợp về một gene (Aa) và cho tự thụ phấn liên tiếp 3 thế hệ, không chọn lọc. Theo lí thuyết, ở thế hệ thứ 3, cây dị hợp chiếm bao nhiêu phần trăm? Điều này giải thích gì về bước 1 của quy trình tạo giống?

> [!goi-y] Gợi ý 1
> Mỗi thế hệ tự thụ phấn, tỉ lệ cây dị hợp còn lại bao nhiêu so với thế hệ trước?

> [!loi-giai] Lời giải
> Tỉ lệ dị hợp sau 3 thế hệ: $\left(\tfrac12\right)^3 = \tfrac18 = 12{,}5\%$. Tỉ lệ đồng hợp: $1 - \tfrac18 = 87{,}5\%$.
>
> Như vậy, chỉ cần tự thụ phấn vài thế hệ (kèm chọn lọc giữ lại cây mang tính trạng mong muốn), quần thể đã gần như toàn cây đồng hợp. Đó là cách tạo **dòng thuần** ở bước 1. Với nhiều gene cùng lúc, cần nhiều thế hệ hơn.

> [!vi-du] Ví dụ 7
> Hai dòng ngô thuần chủng D1 và D2 có năng suất lần lượt 5,5 tấn/ha và 6,5 tấn/ha. Con lai F~1~ (D1 × D2) đạt 8,4 tấn/ha trong cùng điều kiện.
>
> a) Năng suất F~1~ cao hơn trung bình của hai dòng bố mẹ bao nhiêu phần trăm? Cao hơn dòng bố mẹ tốt nhất bao nhiêu phần trăm (làm tròn đến hàng đơn vị)?
>
> b) Vì sao nông dân trồng ngô lai thường phải **mua hạt giống F~1~ mới** mỗi vụ, không để hạt thu hoạch làm giống cho vụ sau?

> [!goi-y] Gợi ý 1
> Trung bình bố mẹ = (5,5 + 6,5) : 2. Phần trăm cao hơn = (F~1~ − giá trị so sánh) : giá trị so sánh × 100%.

> [!goi-y] Gợi ý 2
> Hạt thu trên ruộng F~1~ là F~2~. Ở F~2~, tỉ lệ kiểu gene dị hợp thay đổi thế nào so với F~1~?

> [!loi-giai] Lời giải
> a) Trung bình bố mẹ = (5,5 + 6,5) : 2 = 6,0 tấn/ha. F~1~ cao hơn: (8,4 − 6,0) : 6,0 × 100% = **40%**.
>
> So với dòng tốt nhất (6,5): (8,4 − 6,5) : 6,5 × 100% ≈ 29,2% ≈ **29%**. F~1~ vượt cả dòng bố mẹ tốt nhất → có **ưu thế lai**.
>
> b) Ưu thế lai biểu hiện **cao nhất ở F~1~** (dị hợp ở nhiều cặp gene). Nếu để hạt F~1~ làm giống, đời F~2~ **phân li**, tỉ lệ dị hợp giảm, xuất hiện các cây đồng hợp có kiểu hình kém, ruộng không đồng đều và năng suất giảm. Vì thế con lai F~1~ chỉ dùng làm **sản phẩm thương phẩm** (lai kinh tế), không giữ làm giống.

> [!em-co-biet] Ngoài SGK: vì sao con lai F~1~ "khoẻ" hơn bố mẹ?
> Có hai cách giải thích phổ biến. Theo **giả thuyết siêu trội**, ở trạng thái **dị hợp**, hai allele khác nhau bổ sung chức năng cho nhau, nên con lai mang nhiều cặp gene dị hợp có sức sống cao hơn cả hai dạng đồng hợp. Theo **giả thuyết trội**, mỗi dòng thuần thường mang một số allele lặn có hại ở trạng thái đồng hợp. Khi lai hai dòng khác nhau, các allele lặn đó bị allele trội của dòng kia "che" đi.

### 2.2. Một số thành tựu chọn, tạo giống vật nuôi

- **Gà Đông Tảo** (Hưng Yên): giống gà đặc sản, nổi tiếng với đôi chân to, được hình thành qua quá trình **chọn lọc và nhân giống lâu đời**. Hiện nay được công nhận là **giống quốc gia** (SGK tr. 85, Hình 16.2a).
- **Lợn Landrace** (Đan Mạch): được lai tạo từ **giống lợn địa phương** với giống **Large White**, sau đó tiếp tục **lai tạo và chọn lọc** thành giống lợn **siêu nạc**, năng suất cao. Giống này được nhân giống phổ biến khắp thế giới, có cả ở Việt Nam.
- **Bò Blanc-Blue-Belgium (BBB)**: lai tạo từ giống bò thuần chủng của **Bỉ** với giống bò **Shorthorn** của **Anh**. Giống này có khả năng tăng trưởng cơ bắp **cao hơn 40%** so với bò bình thường, con đực trưởng thành nặng khoảng **900 – 1 250 kg** (SGK tr. 86).

Nhận xét: nhiều giống đặc sản Việt Nam là kết quả của **chọn lọc lâu đời** từ các biến dị có sẵn, còn nhiều giống cao sản trên thế giới là kết quả của **lai tạo kết hợp chọn lọc**.

> [!em-co-biet] Ngoài SGK: "cơ bắp kép" của bò BBB
> Bò BBB có khối cơ phát triển vượt trội (gọi là "cơ bắp kép") vì mang một đột biến làm mất chức năng của gene **myostatin**, là gene có vai trò **kìm hãm** sự phát triển cơ. Các nhà chọn giống đã giữ và nhân rộng đặc điểm này qua lai tạo và chọn lọc. So sánh với Bài 4: lợn siêu nạc cũng liên quan đến đột biến gene điều hoà làm tăng cơ bắp.

### 2.3. Một số thành tựu chọn, tạo giống cây trồng

**Ở Việt Nam**, thành tựu nổi bật nhất gần đây là giống **lúa ST25** (Sóc Trăng):

- Có khả năng **chống chịu bệnh**, cho **gạo hạt dài, thơm**, được công nhận là **gạo ngon nhất thế giới năm 2019** (SGK tr. 86, Hình 16.3).
- Nguồn gốc: từ một **cây lúa đột biến** có **thân màu tím, hạt dài** phát hiện trong giống lúa **CD20**. Từ cây đột biến này, các nhà khoa học **lai tạo hàng chục năm** với các dòng khác nhau, thu được nhiều giống lúa ST, trong đó có ST25.
- ST25 cho gạo thơm ngon khi trồng trong điều kiện **ruộng lúa kết hợp nuôi tôm**, theo **quy trình sản xuất lúa hữu cơ**. Đây lại là một ví dụ về giống – kĩ thuật – năng suất, chất lượng.

Các giống lúa khác trong SGK:

| Giống | Nơi trồng nhiều | Đặc điểm nổi bật |
|---|---|---|
| **Đài thơm 8** (do Công ty Cổ phần giống cây trồng Miền Nam lai tạo) | Đồng bằng sông Cửu Long, Đông Nam Bộ | Không bị đổ, bông to, gạo ngon. Chăm sóc tốt có thể đạt 10 tấn/ha |
| **Lúa lai KC06-1** | Đồng bằng sông Cửu Long, Đông Nam Bộ | Năng suất 8,5 – 10 tấn/ha, thuộc nhóm năng suất cao nhất trong các giống lúa chủ yếu ở Việt Nam |

Ngoài ra, nhiều giống cây ăn quả nổi tiếng như **nhãn lồng Hưng Yên**, **bưởi da xanh**, cam, táo… cũng được tạo ra bằng **chọn lọc** hoặc **lai tạo kết hợp với chọn lọc**.

> [!bay] ST25 không phải "giống tạo ra chỉ bằng lai"
> Điểm xuất phát của dòng lúa ST là một **thể đột biến** (thân tím, hạt dài) xuất hiện trong ruộng giống CD20. Sau đó mới là **lai tạo và chọn lọc** nhiều năm. Đề có thể hỏi: nguồn biến dị ban đầu là gì (đột biến), phương pháp chính là gì (lai tạo kết hợp chọn lọc).

> [!vi-du] Ví dụ 8
> Ghép mỗi thành tựu với phương pháp chủ yếu (dựa vào mô tả trong SGK và tên giống):
>
> (1) gà Đông Tảo; (2) lợn Landrace; (3) lúa ST25; (4) lúa lai KC06-1.
>
> Phương pháp: (a) chọn lọc và nhân giống lâu đời các biến dị có sẵn; (b) lai giữa các giống khác nhau rồi tiếp tục lai tạo, chọn lọc; (c) phát hiện thể đột biến tự nhiên rồi lai tạo, chọn lọc nhiều năm; (d) tạo con lai có ưu thế lai.

> [!goi-y] Gợi ý 1
> Đọc lại mục 2.2 và 2.3: giống nào xuất phát từ một cây đột biến? Giống nào có chữ "lai" ngay trong tên?

> [!loi-giai] Lời giải
> (1) – (a): gà Đông Tảo là sản phẩm chọn lọc, nhân giống lâu đời.
>
> (2) – (b): lợn địa phương Đan Mạch × Large White, rồi tiếp tục lai tạo, chọn lọc thành giống siêu nạc.
>
> (3) – (c): từ cây lúa đột biến thân tím, hạt dài trong giống CD20, lai tạo hàng chục năm.
>
> (4) – (d): KC06-1 là **lúa lai**, khai thác ưu thế lai để đạt năng suất 8,5 – 10 tấn/ha.

> [!ung-dung] Liên hệ các bài khác
> SGK bài này chỉ nói về thành tựu của **lai hữu tính**. Còn các phương pháp khác cũng tạo được giống mới: gây **đột biến** (Bài 4, Bài 12), dùng **bất dục đực tế bào chất** để sản xuất lúa lai (Bài 15), **công nghệ gene** tạo sinh vật biến đổi gene (Bài 5).

## Dạng bài thi hay gặp

### Dạng 1. Nhận biết thường biến, đột biến, biến dị tổ hợp

*Nhận biết:* đề mô tả một hiện tượng (hoặc một danh sách), hỏi đó là loại biến dị nào, hoặc "có bao nhiêu hiện tượng là thường biến".

*Phương pháp:*
1. Hỏi: các cá thể được so sánh có **cùng kiểu gene** không? Cùng một cây, các cành giâm, sinh đôi cùng trứng, cùng một dòng thuần → cùng kiểu gene.
2. Cùng kiểu gene, khác kiểu hình do điều kiện sống, xảy ra đồng loạt → **thường biến**.
3. Xuất hiện đột ngột ở một vài cá thể, liên quan thay đổi gene/NST, di truyền được → **đột biến**.
4. Kiểu hình mới ở đời con do **kết hợp lại** tính trạng của bố mẹ → **biến dị tổ hợp**.

> [!vi-du] Ví dụ 9
> Cho các hiện tượng:
>
> (1) Cây bàng rụng hết lá vào mùa đông, ra lá mới vào mùa xuân.
>
> (2) Trong một ruộng lúa, xuất hiện một cây bạch tạng, lá trắng, không có diệp lục.
>
> (3) Lai đậu hà lan hạt vàng, trơn với hạt xanh, nhăn, ở F~2~ xuất hiện cây hạt vàng, nhăn.
>
> (4) Cùng một giống ngô, ruộng được bón đủ phân cho bắp to hơn hẳn ruộng không bón.
>
> (5) Người sống lâu ở vùng núi cao có số lượng hồng cầu trong máu tăng.
>
> (6) Ở người, hội chứng Down do thừa một NST số 21.
>
> Hãy xếp các hiện tượng vào 3 nhóm: thường biến, đột biến, biến dị tổ hợp.

> [!goi-y] Gợi ý 1
> Hiện tượng nào xảy ra ở **mọi** cá thể trong cùng điều kiện và đổi lại được khi điều kiện đổi?

> [!goi-y] Gợi ý 2
> Hạt vàng, nhăn ở F~2~ có tính trạng nào "mới hoàn toàn" không, hay chỉ là ghép lại tính trạng của P?

> [!loi-giai] Lời giải
> - **Thường biến**: (1), (4), (5). Đều là phản ứng của cùng một kiểu gene trước điều kiện môi trường (mùa đông lạnh và khô, phân bón, không khí loãng ở núi cao), xảy ra đồng loạt và có thể đổi lại.
> - **Đột biến**: (2) (đột biến làm mất khả năng tạo diệp lục, chỉ xuất hiện ở một cây), (6) (đột biến số lượng NST).
> - **Biến dị tổ hợp**: (3). Vàng và nhăn đều có sẵn ở P, F~2~ chỉ tổ hợp lại.

*Bẫy:* (5) dễ bị nhầm là "đột biến thích nghi". Thực ra khi người đó về sống ở đồng bằng một thời gian, số hồng cầu lại giảm về mức bình thường. Đó là thường biến.

### Dạng 2. Giải thích hiện tượng và thiết kế thí nghiệm

*Nhận biết:* đề mô tả sinh vật đổi kiểu hình theo nhiệt độ, ánh sáng, độ pH, thức ăn… rồi hỏi giải thích, hoặc hỏi kết quả khi đổi điều kiện, hoặc yêu cầu đề xuất thí nghiệm kiểm chứng.

*Phương pháp:*
1. Xác định yếu tố môi trường thay đổi và kiểu hình thay đổi theo.
2. Giải thích theo chuỗi: **gene → enzyme/protein → kiểu hình**, trong đó yếu tố môi trường tác động lên **hoạt động của enzyme** hoặc **biểu hiện của gene**.
3. Thí nghiệm kiểm chứng: dùng **các cá thể cùng kiểu gene** (cùng cây, cành giâm, cùng con vật), **chỉ thay đổi một yếu tố**, có **lô đối chứng**.
4. Kết luận về di truyền: kiểu hình mới **không di truyền**. Cái di truyền là kiểu gene (mức phản ứng).

> [!vi-du] Ví dụ 10 (ví dụ kinh điển, ngoài SGK hiện hành)
> Ở cây hoa anh thảo (*Primula sinensis*), cây có kiểu gene AA trồng ở 20 °C cho hoa **đỏ**, nhưng trồng ở 35 °C lại cho hoa **trắng**. Cây có kiểu gene aa cho hoa trắng ở cả hai nhiệt độ.
>
> a) Lấy hạt của một cây AA đang ra hoa trắng ở 35 °C, đem gieo và trồng cây con ở 20 °C. Cây con ra hoa màu gì?
>
> b) Một cây hoa trắng không rõ nguồn gốc. Làm thế nào để biết nó có kiểu gene AA hay aa?

> [!goi-y] Gợi ý 1
> Cây AA hoa trắng truyền cho con "màu trắng" hay truyền allele A?

> [!goi-y] Gợi ý 2
> Câu b: cây AA và cây aa khác nhau ở điều kiện nhiệt độ nào?

> [!loi-giai] Lời giải
> a) Cây mẹ AA tự thụ phấn → hạt có kiểu gene **AA**. Trồng ở 20 °C → hoa **đỏ**. Màu trắng của cây mẹ ở 35 °C chỉ là thường biến, không di truyền.
>
> b) Giâm (hoặc gieo hạt tự thụ phấn) cây đó và trồng ở **20 °C**. Nếu ra hoa đỏ → kiểu gene **AA**. Nếu vẫn hoa trắng → **aa**. Ở 35 °C thì cả hai đều trắng, không phân biệt được.

*Bẫy:* kết luận "nhiệt độ cao gây đột biến A → a". Nếu là đột biến thì trở về 20 °C hoa vẫn trắng và di truyền cho con.

### Dạng 3. Đọc bảng, đồ thị năng suất theo điều kiện

*Nhận biết:* đề cho năng suất (chiều cao, khối lượng…) của **nhiều giống** ở **nhiều điều kiện**, hỏi giống nào có mức phản ứng rộng/hẹp, nên chọn giống nào cho vùng nào, hoặc tính chênh lệch, phần trăm.

*Phương pháp:*
1. Mỗi **hàng** (một giống) là một kiểu gene. Chênh lệch giữa giá trị lớn nhất và nhỏ nhất của hàng cho biết mức phản ứng **rộng hay hẹp** (trong các điều kiện đã thử).
2. Mỗi **cột** (một điều kiện) cho biết giống nào phù hợp nhất với điều kiện đó.
3. Nếu thứ hạng các giống **đổi chỗ** giữa các cột (đồ thị cắt nhau) → có tương tác kiểu gene – môi trường mạnh, phải chọn giống **theo vùng**.
4. Phần trăm tăng = (giá trị mới − giá trị cũ) : giá trị cũ × 100%.

> [!vi-du] Ví dụ 11
> Ba giống ngô được trồng thử ở ba vùng, năng suất (tấn/ha):
>
> | Giống | Đồng bằng thâm canh | Trung du | Vùng khô hạn |
> |---|---|---|---|
> | G1 | 9,8 | 7,1 | 3,2 |
> | G2 | 7,4 | 6,9 | 5,8 |
> | G3 | 8,6 | 7,8 | 4,5 |
>
> a) Giống nào có mức phản ứng về năng suất rộng nhất, hẹp nhất (trong ba vùng thử)?
>
> b) Nên khuyến cáo giống nào cho mỗi vùng?
>
> c) Năng suất trung bình ba vùng của G1 và G2 bằng nhau (6,7 tấn/ha). Có nên kết luận hai giống "tương đương" không?

> [!goi-y] Gợi ý 1
> Tính chênh lệch (lớn nhất − nhỏ nhất) cho từng hàng.

> [!goi-y] Gợi ý 2
> Câu b: đọc theo **cột**, chọn số lớn nhất của mỗi cột.

> [!loi-giai] Lời giải
> a) G1: 9,8 − 3,2 = **6,6**. G2: 7,4 − 5,8 = **1,6**. G3: 8,6 − 4,5 = **4,1**. Rộng nhất: **G1**. Hẹp nhất: **G2**.
>
> b) Đồng bằng thâm canh: **G1** (9,8). Trung du: **G3** (7,8). Vùng khô hạn: **G2** (5,8).
>
> c) **Không**. Trung bình bằng nhau nhưng G1 rất nhạy với điều kiện (9,8 ở đồng bằng, chỉ 3,2 ở vùng khô hạn), còn G2 ổn định. Trồng G1 ở vùng khô hạn sẽ mất mùa, trồng G2 ở đồng bằng thì "phí" đất tốt. Với tương tác kiểu gene – môi trường, phải so sánh **theo từng vùng**, không so trung bình.

*Bẫy:* chọn G1 cho mọi vùng vì "năng suất cao nhất bảng" hoặc vì "mức phản ứng rộng".

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Kiểu gene – môi trường – kiểu hình | Gene cung cấp thông tin tạo protein. Môi trường cung cấp nguyên liệu, tín hiệu điều hoà, có thể tác động trực tiếp. **KG + MT → KH** |
| Thường biến | Biến đổi kiểu hình của cùng một kiểu gene do môi trường. Đồng loạt, theo hướng xác định, **không di truyền**, giúp thích nghi. Ví dụ: hoa phù dung, sinh đôi cùng trứng, thỏ Himalaya |
| Mức phản ứng | Tập hợp các kiểu hình của **cùng một kiểu gene** ở các môi trường khác nhau. **Do kiểu gene quy định, di truyền được**. Ví dụ: ruồi giấm cánh cụt ở dưới 29 °C, cánh gần bình thường ở 31 °C |
| Bản chất di truyền tính trạng | Di truyền **mức phản ứng**, không di truyền tính trạng có sẵn |
| Rộng và hẹp | Tính trạng số lượng thường mức phản ứng rộng. Tính trạng chất lượng thường hẹp |
| Xác định mức phản ứng | Tạo nhiều cá thể **cùng kiểu gene** (giâm, chiết, nuôi cấy mô, dòng thuần, sinh đôi cùng trứng), đặt ở các môi trường khác nhau |
| Ứng dụng | Y học: PKU, galactosemia → chế độ ăn. Nông nghiệp: **giống = KG, kĩ thuật = MT, năng suất = KH**. Giáo dục, thể chất: dinh dưỡng, vận động, môi trường học tập |
| Tạo giống bằng lai hữu tính | (1) Tạo dòng thuần → (2) lai các dòng tìm tổ hợp mong muốn → (3) nhân giống, chọn lọc. **Lai kinh tế**: F~1~ ưu thế lai làm sản phẩm |
| Thành tựu vật nuôi | Gà Đông Tảo (chọn lọc lâu đời), lợn Landrace (Đan Mạch, lai + chọn lọc, siêu nạc), bò BBB (Bỉ × Shorthorn Anh, cơ bắp +40%) |
| Thành tựu cây trồng | ST25 (từ cây đột biến trong CD20, lai tạo hàng chục năm, gạo ngon nhất thế giới 2019), Đài thơm 8 (~10 tấn/ha), lúa lai KC06-1 (8,5 – 10 tấn/ha), nhãn lồng Hưng Yên, bưởi da xanh |

> [!ghi-nho] Ba câu chốt
> - Bố mẹ truyền cho con **kiểu gene**, không truyền **tính trạng có sẵn**. Kiểu gene quy định **mức phản ứng**, môi trường quyết định kiểu hình cụ thể trong mức đó.
> - Thường biến: cùng kiểu gene, khác môi trường → khác kiểu hình, **không di truyền**. Đột biến và biến dị tổ hợp: kiểu gene thay đổi, **di truyền được**.
> - Muốn năng suất cao phải có **giống tốt** (giới hạn cao) **và** **kĩ thuật đúng** (đạt gần giới hạn). Giống mới được tạo bằng **tạo dòng thuần → lai → chọn lọc**.
