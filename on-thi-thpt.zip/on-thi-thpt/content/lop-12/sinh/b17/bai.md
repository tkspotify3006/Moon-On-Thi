---
title: Thực hành: Thí nghiệm về thường biến ở cây trồng
thoi-gian: 30 phút
muc-tieu:
  - Trình bày được nguyên lí của thí nghiệm chứng minh thường biến (cùng kiểu gene, khác điều kiện môi trường, so sánh kiểu hình).
  - Giải thích được vì sao phải dùng cây nhân giống vô tính, vì sao phải có lô đối chứng và chỉ thay đổi một yếu tố môi trường.
  - Thực hiện được các bước trồng, chăm sóc, theo dõi rau muống ở lô đối chứng và lô thí nghiệm.
  - Xử lí được số liệu (giá trị trung bình, % so với đối chứng), rút ra kết luận và viết báo cáo thực hành.
  - Đọc và phân tích được bảng số liệu, biểu đồ của các thí nghiệm về thường biến trong đề thi.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Thường biến** là những biến đổi kiểu hình của **cùng một kiểu gene** dưới tác động của môi trường, **không** làm thay đổi kiểu gene (xem Bài 16).
> 2. Muốn chứng minh thường biến: lấy các cây **cùng kiểu gene** (nhân giống vô tính từ một cây), trồng ở **lô đối chứng** và **lô thí nghiệm** chỉ khác nhau **một** yếu tố môi trường, rồi so sánh kiểu hình.
> 3. SGK chọn **rau muống**, cắt cuống từ **một khóm mọc từ một hạt**, yếu tố thay đổi là **chế độ tưới nước** (đối chứng tưới mỗi ngày, thí nghiệm tưới 1 lần/tuần).
> 4. Chỉ tiêu theo dõi: **chiều cao trung bình** của cây và **khối lượng rau** khi thu hoạch. Xử lí bằng cách tính **% của lô thí nghiệm so với lô đối chứng**.
> 5. Khác biệt rõ rệt giữa hai lô chính là **thường biến**. Nếu không khác biệt thì phải xem lại thí nghiệm, hoặc rút ra ý nghĩa thực tiễn (ví dụ tiết kiệm nước tưới).

> [!nen-tang] Nhớ lại Bài 16
> - **Kiểu hình = kiểu gene + môi trường** (hai yếu tố tương tác với nhau).
> - **Thường biến**: cùng kiểu gene, môi trường khác nhau → kiểu hình khác nhau. Thường biến **không di truyền** vì kiểu gene không đổi.
> - **Mức phản ứng**: tập hợp các kiểu hình của **cùng một kiểu gene** ứng với các điều kiện môi trường khác nhau. Cái được di truyền là mức phản ứng chứ không phải một kiểu hình cố định.
>
> Bài 16 cho em khái niệm. Bài 17 cho em **cách chứng minh** khái niệm đó bằng thí nghiệm do chính em làm.

## 1. Mục đích và nguyên lí của thí nghiệm

### 1.1. Mục đích

Trồng cây để **tự tay chứng minh** rằng cùng một kiểu gene có thể cho các kiểu hình khác nhau khi môi trường khác nhau, tức là chứng minh **thường biến** có thật và đo được.

### 1.2. Nguyên lí — vì sao cách làm này chứng minh được thường biến?

Hãy nghĩ như một "thám tử". Em thấy hai cây rau, một cây cao, một cây thấp. Nguyên nhân có thể là:

- hai cây có **kiểu gene khác nhau** (biến dị di truyền), hoặc
- hai cây sống trong **môi trường khác nhau** (thường biến), hoặc
- cả hai.

Muốn khẳng định "chính môi trường gây ra khác biệt", ta phải **loại bỏ** khả năng thứ nhất và chỉ để lại **một** nguyên nhân môi trường duy nhất. Đó là toàn bộ logic của thí nghiệm:

| Thành phần | Trong thí nghiệm này | Vì sao |
|---|---|---|
| Giữ **kiểu gene** giống nhau | Các cây đều được nhân giống vô tính (giâm, chiết) từ **cùng một cây** | Loại bỏ khả năng khác biệt do gene |
| Chỉ thay đổi **một** yếu tố môi trường | Chế độ tưới nước | Nếu kiểu hình khác nhau thì chỉ có thể do yếu tố này |
| Giữ **mọi điều kiện khác** như nhau | Cùng loài, cùng tuổi, cùng số cây, cùng đất, phân, cách trồng, chăm sóc | Tránh "nhiễu", không để yếu tố khác xen vào |
| Có **lô đối chứng** | Luống tưới bình thường (mỗi ngày) | Làm "mốc" để so sánh |
| **Đo và so sánh** kiểu hình | Chiều cao trung bình, khối lượng rau thu hoạch | Biến khác biệt thành con số cụ thể |

Những điểm khác biệt **rõ rệt** về kiểu hình giữa cây ở hai lô chính là các **đặc điểm thường biến** (SGK tr. 88).

![Hình 1. Bố trí thí nghiệm: cuống rau từ cùng một khóm (một kiểu gene) được trồng ở hai luống chỉ khác nhau về chế độ tưới nước](hinh-1-bo-tri.svg)

**Vì sao phải dùng cây nhân giống vô tính?** Giâm cành, chiết cành là sinh sản vô tính, dựa trên **nguyên phân**, nên các cây con có kiểu gene **giống hệt** cây mẹ và giống hệt nhau. Nếu gieo nhiều hạt, mỗi hạt sinh ra từ sinh sản hữu tính (giảm phân + thụ tinh) nên mang một tổ hợp gene **khác nhau** (biến dị tổ hợp, xem Bài 8). Khi đó cây cao, cây thấp có thể do gene chứ không do môi trường.

**Vì sao các cuống phải lấy từ một khóm mọc từ MỘT hạt?** Một khóm rau muống ngoài vườn có thể gồm nhiều cây mọc từ nhiều hạt khác nhau (khác kiểu gene). Chỉ khi tất cả cuống đều từ **một cây ban đầu** (một hạt) thì mới chắc chắn cùng kiểu gene.

> [!bay]
> - "Trồng các hạt cùng một giống ở hai điều kiện khác nhau" **chưa** đủ chặt để chứng minh thường biến, vì các hạt có thể khác nhau về kiểu gene (đặc biệt ở cây giao phấn). Thí nghiệm chuẩn dùng cây **cùng kiểu gene** từ nhân giống vô tính.
> - Đề hay cài: "Lô đối chứng và lô thí nghiệm khác nhau về chế độ tưới **và** lượng phân bón". Sai, vì khi thay đổi **hai** yếu tố thì không biết khác biệt do yếu tố nào.

### 1.3. Chọn yếu tố môi trường nào?

Các yếu tố thường dùng để tạo thường biến ở cây trồng là **nước, phân bón, ánh sáng**. Người làm thí nghiệm chủ động tạo khác biệt bằng chế độ tưới, chế độ bón phân hoặc mức chiếu sáng giữa lô đối chứng và lô thí nghiệm. SGK chọn **chế độ tưới nước** vì đây là cách đơn giản, dễ làm nhất ở vườn trường hoặc vườn nhà.

> [!vi-du] Ví dụ 1
> Bạn Nam muốn chứng minh ánh sáng gây thường biến ở cây khoai lang. Nam đề xuất: lấy 10 hạt khoai lang gieo dưới nắng, 10 ngọn khoai lang giâm trong bóng râm, bón phân cho luống trong bóng râm nhiều hơn để "bù" thiếu sáng. Hãy chỉ ra các lỗi trong thiết kế và sửa lại.

> [!goi-y] Gợi ý 1
> Kiểm tra từng điều kiện của thí nghiệm chuẩn. Kiểu gene của các cây ở hai lô có chắc giống nhau không?

> [!goi-y] Gợi ý 2
> Ngoài ánh sáng, giữa hai lô còn bao nhiêu điểm khác nhau (cách tạo cây, phân bón)?

> [!loi-giai] Lời giải
> Lỗi 1: một lô trồng từ hạt (sinh sản hữu tính, kiểu gene có thể khác nhau), một lô trồng từ ngọn giâm. Kiểu gene không đồng nhất và tuổi, cách tạo cây cũng khác.
>
> Lỗi 2: hai lô khác nhau cả ánh sáng **và** phân bón, nên không biết khác biệt do yếu tố nào.
>
> Sửa lại: giâm các ngọn cắt từ **một cây** khoai lang, chia đều số ngọn cùng tuổi vào hai lô. Lô đối chứng trồng ngoài nắng như bình thường, lô thí nghiệm che bớt ánh sáng. Đất, phân, nước, khoảng cách, chăm sóc ở hai lô **giống hệt nhau**.

## 2. Chuẩn bị

| Nhóm | Cụ thể | Dùng để |
|---|---|---|
| Dụng cụ | Cuốc, xẻng; dụng cụ tưới (vòi, bình tưới, máy bơm…) | Làm đất, trồng, tưới |
| Địa điểm | Vườn trường hoặc vườn nhà | Làm hai luống trồng |
| Nguyên liệu | Phân hữu cơ sinh học, phân NPK | Bón lót, bón thúc như nhau ở hai luống |
| Mẫu vật | Cây **giâm, chiết cành được**: khoai lang, rau ngót, rau muống, dâu tằm… | Tạo nhiều cây cùng kiểu gene |

> [!meo] Vì sao chọn rau muống, khoai lang, rau ngót?
> Các cây này **giâm cành rất dễ** (cắt đoạn thân cắm xuống đất là ra rễ), **lớn nhanh** (vài tuần đã thấy khác biệt) và **sẵn có** ở địa phương. Đó là ba tiêu chí khi chọn đối tượng thí nghiệm thường biến.

## 3. Cách tiến hành (với rau muống)

Mỗi bước dưới đây đều phục vụ hai nguyên tắc: **cùng kiểu gene** và **chỉ khác một yếu tố**.

| Bước | Làm gì (tóm tắt theo SGK tr. 89) | Vì sao làm như vậy |
|---|---|---|
| a) Chuẩn bị đất | Chọn đất thịt nhiều mùn, nhặt cỏ, xới tơi, bón lót phân hữu cơ. Lên **hai luống** cao 20–30 cm, rộng 1 m, dài 1,5 m, cách nhau 1 m. Làm đất trước khi trồng 7–10 ngày | Hai luống **cùng kích thước, cùng đất, cùng phân** để môi trường giống nhau. Luống cách nhau 1 m để nước tưới luống này không thấm sang luống kia. Làm đất sớm để phân kịp hoai, đất ổn định |
| b) Trồng cây | Ngắt cuống già dài khoảng 15 cm từ **một khóm mọc từ một hạt**. Cắm sâu 4–5 cm, cây cách cây 15 cm, ấn nhẹ đất, tránh dập cuống. Lúc đầu tưới **như nhau** ở cả hai luống, nắng gắt thì che bớt | Cùng kiểu gene, cùng tuổi, cùng mật độ. Tưới như nhau giai đoạn đầu để mọi cây ra rễ, sống tốt. Nếu khác chế độ tưới ngay từ đầu, cây ở luống khô có thể chết, khi đó ta đo "tỉ lệ sống" chứ không còn đo được sinh trưởng |
| c) Chế độ tưới | Khi cây con ở hai luống đã sinh trưởng bình thường mới tách chế độ: **đối chứng tưới mỗi ngày một lần**, **thí nghiệm tưới 1 lần mỗi tuần** (cùng lượng nước và cùng thời điểm trong ngày như đối chứng). Làm cỏ, bón phân… như nhau | Đây là **yếu tố duy nhất** khác nhau giữa hai lô. Cùng lượng nước mỗi lần tưới, cùng giờ tưới để chỉ "tần suất tưới" là thay đổi |
| d) Theo dõi | Đo định kì (sau 3 tuần hoặc 1 tháng): **chiều cao trung bình** (từ gốc đến ngọn) và **khối lượng rau** (kg) khi thu hoạch | Đo **nhiều cây** rồi lấy trung bình để giảm sai số do từng cây. Đo định kì để thấy khác biệt tăng dần theo thời gian |
| e) Xử lí kết quả | Tính chỉ tiêu ở lô thí nghiệm **bằng bao nhiêu %** so với lô đối chứng | Biến khác biệt thành con số so sánh được (mục 4) |

> [!bay] Lỗi thường gặp khi làm thật
> - Cuống lấy từ nhiều khóm khác nhau (có thể khác kiểu gene).
> - Tách chế độ tưới ngay khi vừa trồng, làm cây luống thí nghiệm chết hàng loạt.
> - Hai luống sát nhau, nước tưới ngấm sang. Một luống bị bóng cây che, luống kia nắng (thêm yếu tố ánh sáng).
> - **Trời mưa**: mưa tưới đều cả hai luống, làm mất khác biệt về nước. Mùa mưa cần che mưa cho luống thí nghiệm hoặc làm thí nghiệm vào mùa khô.
> - Chỉ đo 1–2 cây, hoặc chọn đo "cây đẹp nhất" ở mỗi luống, khiến số liệu thiếu khách quan.

> [!ung-dung]
> Nhà nông thường nói "nhất nước, nhì phân, tam cần, tứ giống". Thí nghiệm này cho em thấy bằng số liệu: **cùng một giống** (cùng kiểu gene) nhưng chế độ nước khác thì năng suất khác hẳn. Năng suất là **kiểu hình**, và nó phụ thuộc cả giống lẫn kĩ thuật canh tác.

## 4. Xử lí và giải thích kết quả

### 4.1. Tính giá trị trung bình và % so với đối chứng

Mỗi cây trong cùng một luống vẫn hơi khác nhau một chút (vị trí, đất chỗ tơi chỗ chặt, sai số khi đo…). Vì vậy ta **không** so sánh từng cây, mà so sánh **giá trị trung bình** của cả lô:

$$\overline{x}=\frac{x_1+x_2+\dots+x_n}{n}$$

Sau đó tính chỉ tiêu ở lô thí nghiệm **bằng bao nhiêu phần trăm** so với lô đối chứng:

$$\text{\% so với đối chứng}=\frac{\overline{x}_{\text{TN}}}{\overline{x}_{\text{ĐC}}}\times 100\%$$

Có thể tính thêm **mức chênh lệch**:

$$\text{mức giảm (\%)}=\frac{\overline{x}_{\text{ĐC}}-\overline{x}_{\text{TN}}}{\overline{x}_{\text{ĐC}}}\times 100\%$$

> [!vi-du] Ví dụ 2
> Sau 4 tuần tách chế độ tưới, một nhóm học sinh đo chiều cao 6 cây rau muống mỗi luống (cm):
>
> | Lô | Cây 1 | Cây 2 | Cây 3 | Cây 4 | Cây 5 | Cây 6 |
> |---|---|---|---|---|---|---|
> | Đối chứng | 42 | 45 | 40 | 44 | 43 | 46 |
> | Thí nghiệm | 30 | 33 | 29 | 35 | 31 | 32 |
>
> Tính chiều cao trung bình mỗi lô (làm tròn đến hàng phần mười) và chiều cao trung bình của lô thí nghiệm bằng bao nhiêu % so với đối chứng. Rút ra kết luận.

> [!goi-y] Gợi ý 1
> Cộng 6 giá trị của mỗi lô rồi chia cho 6.

> [!goi-y] Gợi ý 2
> Lấy trung bình lô thí nghiệm chia trung bình lô đối chứng, nhân 100%. Dùng giá trị chưa làm tròn để tính phần trăm.

> [!loi-giai] Lời giải
> Bước 1: Đối chứng: tổng = 260 cm → trung bình = 260 : 6 ≈ **43,3 cm**.
>
> Bước 2: Thí nghiệm: tổng = 190 cm → trung bình = 190 : 6 ≈ **31,7 cm**.
>
> Bước 3: % so với đối chứng = 190/260 × 100% ≈ **73,1%**, tức chiều cao giảm khoảng 26,9%.
>
> Kết luận: các cây có **cùng kiểu gene**, chỉ khác chế độ tưới, mà lô tưới thưa có chiều cao chỉ bằng khoảng 73% lô đối chứng. Khác biệt này là **thường biến** do thiếu nước gây ra. Thêm nữa, cây thấp nhất ở lô đối chứng (40 cm) vẫn cao hơn cây cao nhất ở lô thí nghiệm (35 cm), nên khác biệt là rõ rệt, khó do ngẫu nhiên.

> [!vi-du] Ví dụ 3
> Khi thu hoạch, luống đối chứng (diện tích 1,5 m²) cho 4,8 kg rau, luống thí nghiệm cùng diện tích cho 3,6 kg. Tính năng suất mỗi luống theo kg/m² và khối lượng rau ở lô thí nghiệm bằng bao nhiêu % lô đối chứng.

> [!goi-y] Gợi ý 1
> Năng suất = khối lượng thu được : diện tích.

> [!loi-giai] Lời giải
> Đối chứng: 4,8 : 1,5 = **3,2 kg/m²**. Thí nghiệm: 3,6 : 1,5 = **2,4 kg/m²**.
>
> % so với đối chứng = 3,6/4,8 × 100% = **75%** (giảm 25%). Hai luống cùng diện tích nên so sánh khối lượng hay so sánh năng suất đều cho cùng tỉ lệ.

> [!em-co-biet]
> Các nhà khoa học không dừng ở việc "nhìn thấy trung bình khác nhau", mà dùng **kiểm định thống kê** (như T-test) để biết khác biệt đó có đủ lớn để không phải do ngẫu nhiên hay không. Học sinh chưa học phương pháp này nên SGK cho dùng % so với đối chứng. Ý tưởng chung vẫn là: **càng đo nhiều cây, khác biệt giữa hai lô càng lớn so với dao động bên trong mỗi lô, thì kết luận càng đáng tin**.

### 4.2. Đọc biểu đồ theo thời gian

![Hình 2. Chiều cao trung bình của rau muống ở hai luống sau 2, 4 và 6 tuần (số liệu giả định)](hinh-2-ket-qua.svg)

Đọc Hình 2, em rút ra được ba điều:

1. **Sau 2 tuần**, hai lô gần như bằng nhau (18 và 17 cm), vì giai đoạn đầu hai luống được tưới như nhau và chế độ tưới mới vừa tách ra.
2. **Khác biệt tăng dần** theo thời gian: chênh 8 cm sau 4 tuần, chênh 16 cm sau 6 tuần. Tác động của thiếu nước tích lũy dần.
3. Lô thí nghiệm **vẫn lớn**, chỉ lớn chậm hơn. Kiểu gene không đổi, cây chỉ "điều chỉnh" kiểu hình theo điều kiện nước. Đó đúng là bản chất của thường biến: biến đổi **đồng loạt, theo cùng một hướng** ở mọi cá thể cùng kiểu gene sống trong cùng điều kiện.

> [!bay]
> Nếu đem cuống của cây ở lô thí nghiệm (cây thấp) trồng lại trong điều kiện tưới mỗi ngày, cây con sẽ cao **như lô đối chứng**. "Tính thấp" không được truyền lại vì kiểu gene không đổi. Thường biến **không di truyền** và **không** phải nguyên liệu cho chọn giống hay tiến hóa.

### 4.3. Trả lời câu hỏi thu hoạch

**Câu a) Hai lô không khác nhau đáng kể thì điều chỉnh thí nghiệm thế nào?**

Trước hết, xem lại xem thí nghiệm có bị "nhiễu" không: trời mưa làm mất khác biệt về nước, đất luống thí nghiệm giữ ẩm tốt quá, hai luống quá gần nhau. Sau đó có thể:

- **Tăng mức chênh lệch** của yếu tố môi trường (ví dụ thí nghiệm tưới thưa hơn nữa, hoặc che mưa cho luống thí nghiệm). Mức chênh quá nhỏ thì vẫn nằm trong khoảng cây "chịu được", kiểu hình chưa đổi.
- **Kéo dài thời gian** theo dõi, vì khác biệt tích lũy dần (Hình 2).
- **Tăng số cây** được đo để giá trị trung bình chính xác hơn.
- Chọn **chỉ tiêu nhạy hơn** (ví dụ khối lượng rau thu được, số lá, độ dài lóng), hoặc đổi sang yếu tố môi trường khác (phân bón, ánh sáng).

**Câu b) Kết quả hai lô về cơ bản như nhau thì có ý nghĩa thực tiễn gì?**

Nghĩa là trong **khoảng điều kiện** đã thử, tính trạng đó (chiều cao, năng suất) **ít chịu ảnh hưởng** của tần suất tưới. Khi đó người trồng có thể **giảm số lần tưới** mà năng suất gần như không đổi, tiết kiệm nước, công lao động, chi phí, rất có ý nghĩa ở vùng khô hạn. Cần lưu ý: kết luận chỉ đúng trong khoảng điều kiện đã thử, chưa chắc đúng nếu hạn nặng hơn.

### 4.4. Mẫu báo cáo thực hành

> [!ghi-nho] Báo cáo gồm 3 phần
> 1. **Mục đích**: chứng minh thường biến ở cây trồng (nêu rõ cây, yếu tố môi trường).
> 2. **Kết quả và giải thích**: bảng số liệu từng cây, giá trị trung bình, % so với đối chứng, biểu đồ cột. Giải thích: cùng kiểu gene, khác chế độ nước → khác kiểu hình → thường biến.
> 3. **Trả lời câu hỏi** a) và b) như mục 4.3.

## Dạng bài thi hay gặp

### Dạng 1. Nhận xét thiết kế thí nghiệm

*Nhận biết:* đề mô tả cách bố trí, hỏi "cách nào đúng", "lỗi ở đâu", "lô nào là đối chứng", "yếu tố nào là biến thay đổi".

*Phương pháp:* kiểm tra lần lượt bốn câu hỏi:
1. Các cây có **cùng kiểu gene** không (nhân giống vô tính từ một cây)?
2. Có **lô đối chứng** không?
3. Giữa các lô có **đúng một** yếu tố môi trường khác nhau không?
4. Có đo **nhiều cây** và so sánh **trung bình** không?

> [!vi-du] Ví dụ 4
> Để chứng minh thường biến về màu hoa ở cây cẩm tú cầu (hoa đổi màu theo độ pH của đất), cách bố trí nào hợp lí nhất?
> (1) Gieo hạt cẩm tú cầu vào hai chậu đất có pH khác nhau. (2) Giâm các cành cắt từ một cây cẩm tú cầu vào hai chậu đất có pH khác nhau, các điều kiện khác như nhau. (3) Giâm cành từ hai cây cẩm tú cầu khác màu vào cùng loại đất. (4) Giâm cành từ một cây vào hai chậu khác nhau cả pH đất và lượng nước tưới.

> [!goi-y] Gợi ý 1
> Loại cách có thể khác kiểu gene (hạt, hai cây khác nhau).

> [!goi-y] Gợi ý 2
> Trong các cách còn lại, cách nào chỉ có một yếu tố khác nhau?

> [!loi-giai] Lời giải
> (1) sai: hạt có thể khác kiểu gene. (3) sai: hai cây khác màu có thể khác kiểu gene, lại cùng đất (không có yếu tố môi trường thay đổi). (4) sai: thay đổi hai yếu tố cùng lúc. Chỉ **(2)** đúng: cùng kiểu gene, chỉ khác pH đất.

*Bẫy:* "cùng một giống" chưa chắc "cùng kiểu gene". Hạt của cây giao phấn thường khác kiểu gene.

### Dạng 2. Đọc bảng số liệu, biểu đồ

*Nhận biết:* cho bảng/biểu đồ chỉ tiêu ở lô đối chứng và lô thí nghiệm, hỏi tính trung bình, %, mức chênh lệch, hoặc nhận định đúng/sai.

*Phương pháp:*
1. Xác định lô nào là đối chứng (điều kiện bình thường).
2. Tính trung bình mỗi lô (nếu đề cho từng cây).
3. Tính % = TN/ĐC × 100% hoặc mức giảm = (ĐC − TN)/ĐC × 100%. Đọc kĩ đề hỏi "bằng bao nhiêu %" hay "giảm bao nhiêu %".
4. Kết luận gắn với thường biến (cùng kiểu gene, khác môi trường).

> [!vi-du] Ví dụ 5
> Dựa vào Hình 2, tính mức tăng chiều cao trung bình từ tuần 2 đến tuần 6 của mỗi lô. Mức tăng của lô thí nghiệm bằng bao nhiêu % mức tăng của lô đối chứng (làm tròn đến hàng đơn vị)?

> [!goi-y] Gợi ý 1
> Mức tăng = chiều cao tuần 6 − chiều cao tuần 2.

> [!loi-giai] Lời giải
> Đối chứng: 52 − 18 = 34 cm. Thí nghiệm: 36 − 17 = 19 cm.
>
> 19/34 × 100% ≈ **56%**. So với tỉ lệ chiều cao tuần 6 (36/52 ≈ 69%), tốc độ lớn bị ảnh hưởng còn mạnh hơn, vì giai đoạn đầu hai lô gần như bằng nhau.

*Bẫy:* nhầm "bằng 75%" với "giảm 75%". Nhầm chia ngược (ĐC/TN).

### Dạng 3. Phân biệt thường biến với biến dị di truyền trong kết quả thí nghiệm

*Nhận biết:* đề cho một hiện tượng xảy ra trong thí nghiệm, hỏi đó là thường biến hay đột biến, có di truyền không.

*Phương pháp:* thường biến xuất hiện **đồng loạt** ở **mọi** cây cùng kiểu gene trong cùng điều kiện, **theo một hướng**, **mất đi** khi đưa về điều kiện cũ, **không di truyền**. Một cây **riêng lẻ** có đặc điểm lạ, vẫn giữ khi đổi điều kiện và truyền cho cây giâm từ nó thì có thể là **đột biến**.

> [!vi-du] Ví dụ 6
> Trong luống rau muống đối chứng, có **một** cây lá có những vệt trắng, dù mọi cây khác bình thường. Giâm cành từ cây này ra luống mới, các cây con đều có lá vệt trắng. Đây có phải thường biến không?

> [!goi-y] Gợi ý 1
> Các cây khác trong cùng luống, cùng kiểu gene, cùng điều kiện có biểu hiện như vậy không?

> [!loi-giai] Lời giải
> Không phải thường biến. Mọi cây trong luống cùng kiểu gene và cùng môi trường nhưng chỉ **một** cây biểu hiện, và đặc điểm được **truyền qua sinh sản vô tính** sang điều kiện mới. Đây là biến dị **di truyền**, nhiều khả năng là đột biến (đột biến soma, hoặc đột biến gene ngoài nhân ở lục lạp gây lá đốm, xem Bài 15).

*Bẫy:* đặc điểm truyền qua **giâm cành** chưa chắc truyền qua **hạt** (đột biến soma), nhưng chắc chắn không phải thường biến.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Mục đích | Chứng minh thường biến: cùng kiểu gene, khác môi trường → khác kiểu hình |
| Mẫu vật | Cây giâm, chiết được (rau muống, khoai lang, rau ngót, dâu tằm). Cuống từ **một** khóm mọc từ **một** hạt |
| Lô đối chứng | Tưới mỗi ngày (bình thường) |
| Lô thí nghiệm | Tưới 1 lần/tuần. Mọi điều kiện khác giữ nguyên |
| Thời điểm tách chế độ | Khi cây con đã sinh trưởng bình thường |
| Chỉ tiêu | Chiều cao trung bình (gốc → ngọn), khối lượng rau thu hoạch (kg) |
| Xử lí | Trung bình mỗi lô, % TN so với ĐC (nhà khoa học dùng T-test) |
| Không khác biệt | Kiểm tra nhiễu (mưa…), tăng mức chênh, kéo dài thời gian, tăng số cây |
| Ý nghĩa thực tiễn | Tính trạng ít phụ thuộc chế độ tưới → giảm tưới, tiết kiệm nước |

**Công thức:** $\overline{x}=\dfrac{\sum x_i}{n}$ · % so với ĐC $=\dfrac{\overline{x}_{\text{TN}}}{\overline{x}_{\text{ĐC}}}\times100\%$ · mức giảm $=\dfrac{\overline{x}_{\text{ĐC}}-\overline{x}_{\text{TN}}}{\overline{x}_{\text{ĐC}}}\times100\%$.

**Sơ đồ chương 3 (SGK tr. 90) trong một dòng:** kiểu gene gồm gene trong nhân (sinh sản hữu tính → biến dị tổ hợp → nguyên liệu cho tiến hóa, chọn giống) và gene ngoài nhân (di truyền theo dòng mẹ). Kiểu gene **tương tác** với môi trường: mỗi môi trường cho một kiểu hình, tập hợp các kiểu hình của một kiểu gene là **mức phản ứng**.
