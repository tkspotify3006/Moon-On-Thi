---
title: Gene, quá trình truyền đạt thông tin di truyền và hệ gene
thoi-gian: 50 phút
muc-tieu:
  - Nêu được khái niệm gene; mô tả được cấu trúc chung của gene (vùng điều hoà, vùng mã hoá, vùng kết thúc); phân biệt gene ở sinh vật nhân sơ và nhân thực (gene không phân mảnh – gene phân mảnh, exon – intron); phân loại gene theo chức năng (gene cấu trúc, gene điều hoà).
  - Phát biểu được khái niệm hệ gene; nêu được một số thành tựu và ứng dụng của việc giải trình tự hệ gene người.
  - Trình bày được phiên mã là quá trình tổng hợp RNA dựa trên mạch khuôn của gene (RNA polymerase, chiều tổng hợp, NTBS); giải thích được sự hoàn thiện mRNA ở sinh vật nhân thực.
  - Phân biệt được cấu trúc và chức năng của mRNA, tRNA, rRNA; nêu được khái niệm và ý nghĩa của phiên mã ngược.
  - Nêu được khái niệm mã di truyền và các đặc điểm của mã di truyền; trình bày được các giai đoạn của dịch mã và vai trò của ribosome, tRNA, polyribosome.
  - Vẽ và giải thích được sơ đồ DNA → RNA → protein → tính trạng (kể cả phiên mã ngược).
  - Giải được các dạng bài: viết trình tự mRNA, anticodon, chuỗi amino acid từ mạch khuôn (dùng bảng mã di truyền); tính số codon, amino acid, liên kết peptide, số ribonucleotide mỗi loại; gene phân mảnh; số loại bộ ba và tỉ lệ bộ ba.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Gene** là một đoạn DNA mang thông tin quy định một sản phẩm: **chuỗi polypeptide** hoặc **RNA**. Gene gồm 3 vùng: **vùng điều hoà** (ở đầu **3'** của mạch khuôn, chứa **promoter**) – **vùng mã hoá** – **vùng kết thúc** (ở đầu **5'** của mạch khuôn). Gene nhân thực thường **phân mảnh**: **exon** (được dịch mã) xen kẽ **intron** (không được dịch mã).
> 2. **Phiên mã**: **RNA polymerase** bám promoter, đọc **mạch khuôn theo chiều 3' → 5'**, tổng hợp mRNA **chiều 5' → 3'** theo NTBS **A – U, T – A, G – C, C – G**. Ở nhân thực, tiền mRNA được gắn **mũ (đầu 5')**, **đuôi poly A (đầu 3')**, **cắt intron – nối exon** → mRNA trưởng thành.
> 3. **Mã di truyền** là **mã bộ ba** trên mRNA: 64 bộ ba = **61 mã hoá amino acid** + **3 kết thúc (UAA, UAG, UGA)**; **AUG** là bộ ba mở đầu (mã hoá Met). Đặc điểm: đọc **liên tục** từng bộ ba, không chồng gối; **đặc hiệu**; **thoái hoá**; **phổ biến** (có ngoại lệ).
> 4. **Dịch mã** ở ribosome: khởi đầu (tiểu phần nhỏ + Met-tRNA ở AUG + tiểu phần lớn) → kéo dài (tRNA vào **A**, tạo liên kết peptide, ribosome dịch **5' → 3'** một bộ ba, tRNA qua **P** rồi ra ở **E**) → kết thúc (gặp bộ ba kết thúc, **yếu tố giải phóng** tách chuỗi). Nhiều ribosome cùng dịch một mRNA = **polyribosome**.
> 5. Dòng thông tin: **DNA → mRNA → protein → tính trạng**; trường hợp đặc biệt **RNA → DNA** (phiên mã ngược, ví dụ HIV, telomerase). **Hệ gene** = toàn bộ DNA trong tế bào của một sinh vật; hệ gene người hơn **3,2 tỉ cặp nucleotide**, khoảng **21 300 gene** mã hoá protein.

> [!nen-tang] Nhớ lại: Bài 1 và Sinh học 10
> - DNA có hai mạch **đối song song**; mỗi mạch có chiều **5' → 3'**; hai mạch kết cặp theo NTBS **A – T, G – C** (xem Bài 1).
> - **RNA** có đường **ribose**, base **A, U, G, C** (U thay cho T), thường **một mạch**. Đơn phân của RNA gọi là **ribonucleotide**.
> - **Protein** được cấu tạo từ khoảng **20 loại amino acid**, nối nhau bằng **liên kết peptide** thành chuỗi polypeptide. Một chuỗi có m amino acid thì có **m − 1** liên kết peptide.
> - Mọi enzyme tổng hợp nucleic acid (DNA polymerase, RNA polymerase) đều chỉ gắn đơn phân mới vào **đầu 3'** của mạch đang kéo dài → mạch mới luôn dài ra theo chiều **5' → 3'**.

**Câu hỏi mở bài.** Trong nhân tế bào gan và tế bào cơ của em, DNA giống hệt nhau. Vậy mà tế bào gan làm ra albumin, tế bào cơ làm ra actin và myosin. Thông tin nằm "im" trong DNA đã được **đọc ra** và **biến thành protein** bằng cách nào — mà DNA không hề rời khỏi nhân? Bài này đi theo đường đi của thông tin: từ **gene** → **mRNA** → **protein**.

## 1. Gene

### 1.1. Khái niệm gene

**Gene** là một đoạn của phân tử DNA mang thông tin quy định **một loại sản phẩm** nhất định. Sản phẩm đó có thể là:

- một **chuỗi polypeptide** (qua trung gian mRNA) — ví dụ gene insulin, gene hemoglobin;
- hoặc một phân tử **RNA** được dùng trực tiếp — ví dụ gene quy định tRNA, rRNA.

Gene có hai mạch, nhưng khi tế bào "đọc" gene để tạo RNA, **chỉ một mạch** được dùng làm khuôn:

| Mạch | Tên gọi | Vai trò |
|---|---|---|
| Mạch được RNA polymerase dùng làm khuôn | **mạch khuôn** (đề thi hay gọi **mạch gốc**) | Quyết định trình tự RNA theo NTBS |
| Mạch còn lại | **mạch mã hoá** (đề thi hay gọi **mạch bổ sung**) | Có trình tự **giống** RNA tạo ra (chỉ khác T thay cho U) |

**Vì sao mạch còn lại lại được gọi là "mạch mã hoá"?** mRNA bổ sung với mạch khuôn; mạch mã hoá cũng bổ sung với mạch khuôn. Hai thứ cùng bổ sung với một mạch thì giống nhau. Nhìn mạch mã hoá là "thấy ngay" trình tự mRNA, tức thấy ngay các bộ ba mã hoá — nên gọi là mạch mã hoá.

### 1.2. Cấu trúc chung của một gene

Một gene mã hoá protein điển hình có **ba vùng** nối tiếp nhau (SGK tr. 9, Hình 2.1):

| Vùng | Vị trí | Chức năng |
|---|---|---|
| **Vùng điều hoà** | ở **đầu 3' của mạch khuôn** | Chứa **promoter** — trình tự để RNA polymerase nhận biết, bám vào và khởi động phiên mã; có các vùng cho **protein điều hoà** bám vào để bật/tắt gene |
| **Vùng mã hoá** | nằm kế tiếp vùng điều hoà | Mang thông tin quy định trình tự **amino acid** của chuỗi polypeptide (hoặc trình tự của RNA) |
| **Vùng kết thúc** | ở **đầu 5' của mạch khuôn** | Mang **tín hiệu kết thúc phiên mã** |

**Vì sao vùng điều hoà phải nằm ở đầu 3' của mạch khuôn?** RNA polymerase tổng hợp RNA theo chiều 5' → 3', nên nó phải "bò" trên mạch khuôn theo chiều **3' → 5'** (hai mạch luôn ngược chiều). Muốn đọc hết gene, nó phải xuất phát từ đầu 3' của mạch khuôn — đó chính là chỗ đặt "bến xuất phát" promoter. Vùng kết thúc nằm ở cuối đường đi, tức đầu 5' của mạch khuôn.

![Hình 1. Cấu trúc gene. (a) Ở sinh vật nhân sơ: nhiều vùng mã hoá liền nhau dùng chung một vùng điều hoà và một vùng kết thúc. (b) Ở sinh vật nhân thực: vùng mã hoá phân mảnh, các exon xen kẽ các intron](hinh-1-cau-truc-gene.svg)

**Gene ở sinh vật nhân sơ và nhân thực khác nhau thế nào?** (SGK tr. 10, Hình 2.2)

| Đặc điểm | Nhân sơ (vi khuẩn) | Nhân thực |
|---|---|---|
| Vùng mã hoá | **liên tục** (không có intron): bắt đầu bằng bộ ba mở đầu, tiếp theo là các bộ ba mã hoá amino acid, kết thúc bằng bộ ba kết thúc | phần lớn **phân mảnh**: các đoạn được dịch mã (**exon**) xen kẽ các đoạn không được dịch mã (**intron**); mở đầu và kết thúc đều là exon |
| Tổ chức | các gene thường xếp thành **nhóm**, vùng mã hoá nằm liền kề, **dùng chung** một vùng điều hoà và một vùng kết thúc | mỗi gene thường có vùng điều hoà và vùng kết thúc **riêng** |
| Hệ quả | một lần phiên mã cho **một mRNA mang thông tin của nhiều gene** | mỗi gene cho **một loại mRNA riêng** |

> [!bay]
> - "Vùng điều hoà nằm ở đầu 5' của gene" — câu này **mơ hồ** và hay bị cài sai. Hãy luôn quy về **mạch khuôn**: điều hoà ở **3'** mạch khuôn, kết thúc ở **5'** mạch khuôn. (Nếu nhìn theo mạch mã hoá thì ngược lại.)
> - Intron **có** được phiên mã (có mặt trong tiền mRNA) nhưng **không** được dịch mã vì bị cắt bỏ trước khi mRNA ra khỏi nhân. Đề hay viết "intron không được phiên mã" — **sai**.
> - Vùng điều hoà **không** được phiên mã; nó chỉ là chỗ để RNA polymerase và protein điều hoà bám vào.

> [!vi-du] Ví dụ 1
> Một gene được vẽ nằm ngang, **vùng điều hoà ở bên trái**. Mạch trên có đầu 5' ở bên trái, mạch dưới có đầu 3' ở bên trái. a) Mạch nào là mạch khuôn? b) mRNA được tổng hợp theo hướng nào (trái → phải hay phải → trái)? c) Trình tự mRNA giống mạch nào?

> [!goi-y] Gợi ý 1
> Vùng điều hoà luôn ở đầu **3'** của mạch khuôn. Mạch nào có đầu 3' ở bên trái?

> [!goi-y] Gợi ý 2
> RNA polymerase xuất phát từ vùng điều hoà, đi dọc gene về phía vùng kết thúc. mRNA bổ sung với mạch khuôn thì giống mạch còn lại.

> [!loi-giai] Lời giải
> a) Vùng điều hoà ở bên trái mà nó nằm ở đầu 3' của mạch khuôn → mạch khuôn có đầu 3' ở bên trái → **mạch dưới** là mạch khuôn.
>
> b) RNA polymerase đi từ vùng điều hoà (trái) sang vùng kết thúc (phải), tức đi trên mạch khuôn theo chiều 3' → 5'. mRNA dài ra **từ trái sang phải**, đầu 5' của mRNA ở bên trái.
>
> c) mRNA bổ sung với mạch dưới nên **giống mạch trên** (mạch mã hoá), chỉ thay T bằng U. Cả hai đều có đầu 5' ở bên trái.

### 1.3. Phân loại gene

SGK phân loại theo hai tiêu chí (SGK tr. 10):

- **Theo chức năng của sản phẩm:**
  - **gene cấu trúc**: sản phẩm tham gia **cấu tạo** hoặc **thực hiện chức năng** của tế bào (protein cấu trúc, enzyme, hormone, tRNA, rRNA…);
  - **gene điều hoà**: sản phẩm có nhiệm vụ **điều hoà sự biểu hiện của gene khác** (bật/tắt, tăng/giảm). Em sẽ gặp lại ở Bài 3 (operon *lac*).
- **Theo cấu trúc vùng mã hoá:**
  - **gene không phân mảnh**: vùng mã hoá liên tục, không chứa intron (điển hình ở nhân sơ);
  - **gene phân mảnh**: vùng mã hoá chứa intron (phần lớn gene nhân thực).

> [!ghi-nho] Trả lời câu Luyện tập SGK tr. 17
> **Câu 1.** "Bất cứ trình tự nucleotide nào chỉ dẫn cho tế bào tạo ra RNA đều là gene" — định nghĩa này **chưa chặt chẽ**. Đúng là mọi gene đều được phiên mã ra RNA. Nhưng gene phải là **một đoạn DNA hoàn chỉnh** (có vùng điều hoà, vùng mã hoá, vùng kết thúc) quy định **một sản phẩm xác định** (một chuỗi polypeptide hoặc một RNA). Một promoter đứng riêng, hay một exon đứng riêng, cũng "góp phần" tạo RNA nhưng chỉ là **một phần** của gene.
>
> **Câu 2.** Biết tổng số nucleotide vùng mã hoá của gene **nhân thực** thì **không** tính được số amino acid, vì vùng mã hoá có cả **intron** — mà intron bị cắt bỏ, không được dịch mã. Phải biết tổng số nucleotide của các **exon** (Dạng 2, Ví dụ 8).
>
> **Câu 3.** Nếu gene vi khuẩn phần lớn là gene phân mảnh thì quá trình gene → protein sẽ **dài hơn**: phải thêm bước cắt intron, nối exon, và phải chờ mRNA hoàn thiện mới dịch mã được — không còn "phiên mã đến đâu dịch mã đến đó".

## 2. Hệ gene

### 2.1. Khái niệm hệ gene

**Hệ gene (genome)** là **tập hợp tất cả vật chất di truyền (DNA)** trong tế bào của một sinh vật. Hệ gene gồm cả các gene **và** các đoạn DNA **không phải gene**: vùng nằm giữa các gene, các trình tự lặp lại, đầu mút NST…; ở tế bào nhân thực còn có DNA trong ti thể (và lục lạp ở thực vật).

**Vì sao "tập hợp tất cả các gene" chưa phải là hệ gene?** (Dừng lại và suy ngẫm, SGK tr. 11.) Vì hệ gene còn chứa rất nhiều DNA không thuộc gene nào: theo số liệu SGK, exon, intron và vùng điều hoà cộng lại chỉ khoảng một phần tư hệ gene người, riêng exon chỉ khoảng 1,5%. Hệ gene là "cả cuốn sách", còn các gene chỉ là "những câu có nghĩa" nằm rải rác trong đó.

Người ta biết được hệ gene của một loài là nhờ **giải trình tự** — đọc ra trình tự nucleotide của toàn bộ DNA trong tế bào, từ đó tìm vị trí, cấu trúc và chức năng của từng gene.

### 2.2. Thành tựu và ứng dụng của giải trình tự hệ gene người

**Một số con số** (SGK tr. 10–11):

| Nội dung | Số liệu |
|---|---|
| Kích thước hệ gene người | hơn **3,2 tỉ cặp nucleotide**, trên **23 cặp NST**; giải trình tự xong năm **2004**, độ chính xác tới 99,999% |
| Số gene mã hoá protein | khoảng **gần 21 300** |
| Exon của các gene mã hoá protein + vùng mã hoá rRNA, tRNA | khoảng **1,5%** hệ gene |
| Các vùng điều hoà của tất cả các gene | khoảng **5%** hệ gene |
| Tất cả các intron | xấp xỉ **20%** hệ gene |
| Một gene người trung bình | dài khoảng **27 000 cặp nucleotide**, có khoảng **10 exon** |

**Ứng dụng:**

- **Y học:** biết một người có mang gene bệnh hay không để **phòng và chữa bệnh sớm**; biết khối u mang gene ung thư nào để chọn **thuốc hướng đích** ức chế đúng sản phẩm của gene đó → điều trị hiệu quả hơn.
- **Pháp y:** tìm thủ phạm trong vụ án, xác định danh tính nạn nhân trong tai nạn, xác định quan hệ họ hàng.
- **Nghiên cứu tiến hoá:** so sánh hệ gene các loài; hệ gene càng giống nhau thì quan hệ họ hàng càng gần, vì các loài đó mới tách nhau chưa lâu, chưa kịp tích luỹ nhiều đột biến khác nhau. Ví dụ: trong các loài linh trưởng, **tinh tinh** gần loài người nhất.

**Nhận xét từ bảng:** 1,5% của 3,2 tỉ là khoảng 48 triệu cặp nucleotide exon; chia cho khoảng 21 300 gene thì mỗi gene chỉ có khoảng 2 250 cặp nucleotide exon — chừng 8% chiều dài trung bình của một gene (27 000 cặp). Phần lớn chiều dài gene người là intron, vì vậy bước **cắt intron** ở sinh vật nhân thực rất quan trọng.

> [!ung-dung]
> Ở Việt Nam, nhiều bệnh viện đã làm **xét nghiệm gene** cho bệnh nhân ung thư phổi: nếu khối u mang đột biến ở gene *EGFR*, bác sĩ dùng thuốc hướng đích ức chế protein EGFR, thường hiệu quả hơn và ít tác dụng phụ hơn hoá trị thông thường. Các xét nghiệm sàng lọc trước sinh không xâm lấn (lấy máu mẹ) cũng dựa trên giải trình tự DNA.

## 3. Quá trình truyền đạt thông tin di truyền từ gene tới protein

Hình dung DNA như **bản thiết kế gốc** cất kín trong "kho" là nhân tế bào. Tế bào không mang bản gốc ra công trường (ribosome ở tế bào chất), mà **chép ra bản sao làm việc** (mRNA) — đó là **phiên mã**. Sau đó, ở công trường, bản sao được "đọc" để lắp ráp các amino acid thành protein — đó là **dịch mã**.

### 3.1. Phiên mã

**Phiên mã** là quá trình tổng hợp **RNA** dựa trên **mạch khuôn** của gene. Ở nhân thực, phiên mã diễn ra trong **nhân tế bào**. SGK chia thành ba bước (SGK tr. 11, Hình 2.3):

1. **Khởi đầu:** một số protein bám vào **vùng điều hoà**, thu hút **RNA polymerase** tới bám vào **promoter** trên mạch khuôn. Đoạn DNA ở đó được tháo xoắn, hai mạch tách ra để lộ mạch khuôn.
2. **Kéo dài:** RNA polymerase trượt trên mạch khuôn theo chiều **3' → 5'**, lắp các ribonucleotide tự do vào đầu 3' của mạch RNA đang tổng hợp → mRNA dài ra theo chiều **5' → 3'**. Nguyên tắc bổ sung:

| Mạch khuôn (DNA) | A | T | G | C |
|---|---|---|---|---|
| mRNA | **U** | A | C | G |

3. **Kết thúc:** khi RNA polymerase gặp **tín hiệu kết thúc** (ở đầu 5' của mạch khuôn) thì dừng lại, mRNA được giải phóng. Đoạn DNA vừa phiên mã xong đóng xoắn lại.

![Hình 2. Phiên mã và hoàn thiện mRNA ở sinh vật nhân thực. Trên: RNA polymerase đọc mạch khuôn 3' → 5', tổng hợp RNA 5' → 3'. Dưới: tiền mRNA được gắn mũ, gắn đuôi poly A, cắt intron, nối exon thành mRNA trưởng thành](hinh-2-phien-ma.svg)

**So sánh nhanh với tái bản DNA (Bài 1)** — chỗ đề rất hay hỏi:

| | Tái bản DNA | Phiên mã |
|---|---|---|
| Khuôn | **cả hai** mạch, **toàn bộ** phân tử DNA | **một** mạch (mạch khuôn), **từng gene** |
| Enzyme chính | DNA polymerase (cần **đoạn mồi**) | RNA polymerase (**không cần** mồi, tự tháo xoắn) |
| NTBS | A – T, G – C | A~khuôn~ – **U**, T~khuôn~ – A, G – C |
| Số lần | một lần trong mỗi chu kì tế bào | một gene có thể phiên mã **nhiều lần** khi tế bào cần nhiều sản phẩm |
| Sản phẩm | 2 DNA con | RNA mạch đơn |

**Phiên mã ở nhân sơ và nhân thực.** Về cơ bản giống nhau, nhưng:

- **Nhân sơ:** thường phiên mã **vài gene cùng lúc** thành **một mRNA**; không có màng nhân ngăn cách nên **phiên mã đến đâu, ribosome dịch mã đến đó**.
- **Nhân thực:** phiên mã tạo ra **tiền mRNA** (mRNA sơ khai), rồi được **hoàn thiện** trong nhân:
  - gắn **mũ 7-methylguanine** vào **đầu 5'**;
  - gắn **đuôi poly A** (chuỗi nhiều nucleotide loại adenine) vào **đầu 3'**;
  - **cắt bỏ intron, nối các exon** lại với nhau.

  Kết quả là **mRNA trưởng thành**, đi qua lỗ màng nhân ra tế bào chất, tới ribosome để dịch mã.
- Với gene quy định rRNA: tiền RNA sau khi tạo thành được **cắt ra thành các loại rRNA** khác nhau.

**Thông tin từ gene có được truyền nguyên vẹn sang RNA không?** (Dừng lại và suy ngẫm, SGK tr. 13.) Ở bước phiên mã, tiền mRNA bổ sung **chính xác** với đoạn mạch khuôn được phiên mã — thông tin được chép đúng. Nhưng (1) vùng điều hoà **không** được phiên mã; (2) ở nhân thực, mRNA trưởng thành đã **mất các intron** và có thêm mũ, đuôi poly A. Vì vậy mRNA trưởng thành **không còn** là bản sao nguyên vẹn của gene — nó chỉ giữ lại phần thông tin cần cho dịch mã.

> [!vi-du] Ví dụ 2
> Một đoạn mạch khuôn của gene có trình tự 3'-TAC GGA TTC ACT-5'. Viết trình tự đoạn mRNA tương ứng và trình tự đoạn mạch mã hoá của gene.

> [!goi-y] Gợi ý 1
> mRNA ngược chiều mạch khuôn: dưới đầu 3' của mạch khuôn là đầu 5' của mRNA. Thay từng nucleotide theo A → U, T → A, G → C, C → G.

> [!goi-y] Gợi ý 2
> Mạch mã hoá cũng bổ sung với mạch khuôn, nên giống hệt mRNA, chỉ đổi U thành T.

> [!loi-giai] Lời giải
> Bước 1: Mạch khuôn 3'-TAC GGA TTC ACT-5'
>
> Bước 2: mRNA (viết thẳng hàng bên dưới): **5'-AUG CCU AAG UGA-3'**. Vì mạch khuôn đã cho được viết theo chiều 3' → 5' nên mRNA đọc ra ngay theo chiều 5' → 3', không cần đảo.
>
> Bước 3: Mạch mã hoá: **5'-ATG CCT AAG TGA-3'**.

> [!meo]
> Đề cho mạch khuôn viết **3' → 5'** → chỉ cần "đổi chữ" là ra mRNA 5' → 3'. Đề cho mạch khuôn viết **5' → 3'** → đổi chữ xong phải **đảo ngược** cả dãy. Đề cho **mạch mã hoá** → không đổi chữ, chỉ thay T bằng U.

### 3.2. Một số loại RNA — sản phẩm của phiên mã

Có ba loại RNA chủ chốt tham gia truyền thông tin từ gene tới protein (SGK tr. 12–13):

| Loại RNA | Cấu trúc | Chức năng |
|---|---|---|
| **mRNA** (RNA thông tin) | mạch đơn, **dạng thẳng**. Ở nhân sơ, một mRNA thường chứa trình tự mã hoá của **vài gene**; ở nhân thực, mỗi gene tạo một loại mRNA riêng | **Khuôn cho dịch mã**: mang thông tin từ gene tới ribosome |
| **tRNA** (RNA vận chuyển) | mạch đơn nhưng có những đoạn **tự bắt cặp** với nhau → cấu trúc **ba thuỳ**. Một thuỳ mang **bộ ba đối mã (anticodon)**; hai thuỳ kia liên kết với protein của ribosome. **Đầu 3'** có trình tự đặc hiệu để gắn **amino acid** | **Vận chuyển amino acid** tới ribosome và "đọc" codon bằng anticodon |
| **rRNA** (RNA ribosome) | mạch đơn, các loại khác nhau về số lượng và trình tự nucleotide; được phiên mã từ một gene rồi **cắt ra** thành các loại rRNA | **Cấu tạo nên ribosome**. Ví dụ rRNA 16S của vi khuẩn bắt cặp với đoạn mRNA nằm trước bộ ba mở đầu, giúp ribosome nhận ra mã mở đầu |

Một vài con số SGK nêu: mỗi loại amino acid có tRNA vận chuyển riêng, nên tế bào cần **tối thiểu 20 loại tRNA**; thực tế đa số tế bào có **30 – 40 loại** tRNA. Tế bào nhân sơ thường có **3 loại rRNA** do **một** gene quy định; tế bào nhân thực có **4 loại rRNA** do **hai** gene quy định.

**Vì sao tRNA phải có hai "đầu" khác nhau?** tRNA là "người phiên dịch" giữa hai ngôn ngữ. Một đầu (anticodon) "nói" ngôn ngữ nucleotide để khớp với codon trên mRNA. Đầu kia (đầu 3') "cầm" amino acid — ngôn ngữ protein. Nhờ đó, codon nào sẽ gọi đến đúng amino acid đó.

> [!bay]
> - **Codon** (bộ ba mã hoá) nằm trên **mRNA**; **anticodon** (bộ ba đối mã) nằm trên **tRNA**; còn bộ ba trên mạch khuôn của gene thường gọi là **triplet**. Đề hay tráo các tên này.
> - Anticodon **bổ sung và ngược chiều** với codon: codon 5'-AUG-3' khớp với anticodon **3'-UAC-5'** (nếu viết theo chiều 5' → 3' thì là 5'-CAU-3'). Lưu ý anticodon cũng có trình tự giống triplet trên mạch khuôn, chỉ thay T bằng U.

### 3.3. Phiên mã ngược

**Phiên mã ngược** là quá trình tổng hợp **DNA** dựa trên **khuôn RNA**, do **enzyme phiên mã ngược** thực hiện. DNA tạo ra có trình tự bổ sung đặc hiệu với RNA khuôn (A~RNA~ – T, U~RNA~ – A, G – C, C – G). Gặp ở đâu (SGK tr. 13)?

- **Một số virus có vật chất di truyền là RNA** (như HIV): vào tế bào, RNA của virus được phiên mã ngược thành DNA, rồi DNA này **cài vào DNA của tế bào chủ**.
- **Enzyme telomerase** ở tế bào sinh giao tử: telomerase mang sẵn một đoạn RNA, dùng nó làm khuôn để kéo dài DNA ở **đầu mút NST**. Nhờ vậy, đoạn đầu mút bị ngắn đi qua các lần tái bản được phục hồi trong giao tử, để hợp tử có NST đầu mút đầy đủ (SGK Hình 2.5).

**Ý nghĩa ứng dụng:**

- Dùng enzyme phiên mã ngược (gốc virus) để tổng hợp **cDNA** từ **mRNA trưởng thành**. cDNA **không có intron** → dùng để **chuyển gene của sinh vật nhân thực vào vi khuẩn** (vi khuẩn không biết cắt intron). Ví dụ: sản xuất insulin người bằng vi khuẩn (Bài 5).
- **Xét nghiệm virus** có hệ gene RNA như HIV, SARS-CoV-2: phải phiên mã ngược RNA virus thành DNA rồi mới nhân bản được bằng PCR (xét nghiệm RT-PCR).

> [!vi-du] Ví dụ 3
> Một đoạn RNA của virus có trình tự 5'-GAUUCA-3'. Viết trình tự đoạn DNA được enzyme phiên mã ngược tổng hợp từ khuôn này, theo chiều 5' → 3'.

> [!goi-y] Gợi ý 1
> Bổ sung: A → T, U → A, G → C, C → G. Mạch DNA mới ngược chiều khuôn.

> [!goi-y] Gợi ý 2
> Viết thẳng hàng bên dưới (3' → 5'), rồi đảo lại để đọc theo chiều 5' → 3'.

> [!loi-giai] Lời giải
> Khuôn 5'-GAUUCA-3' → DNA bổ sung viết thẳng hàng: 3'-CTAAGT-5' → viết lại theo chiều 5' → 3': **5'-TGAATC-3'**.

### 3.4. Mã di truyền

**Mã di truyền** là bộ các **bộ ba nucleotide trên mRNA** quy định các amino acid trong protein. Mỗi bộ ba gọi là một **codon** (đơn vị mã di truyền).

**Vì sao phải là mã bộ ba?** mRNA chỉ có 4 loại "chữ" (A, U, G, C), nhưng phải mã hoá khoảng 20 loại amino acid:

- nếu 1 nucleotide mã hoá 1 amino acid: chỉ có 4^1^ = 4 mã — quá ít;
- nếu 2 nucleotide: 4^2^ = 16 mã — vẫn chưa đủ 20;
- nếu 3 nucleotide: 4^3^ = **64** mã — dư đủ. Đây là "từ" ngắn nhất đáp ứng được.

Trong 64 bộ ba (SGK tr. 14, Bảng 2.1):

- **61** bộ ba mã hoá amino acid;
- **3** bộ ba **kết thúc** (**UAA, UAG, UGA**) — không mã hoá amino acid, báo hiệu dừng dịch mã;
- **AUG** là **bộ ba mở đầu**: vừa báo hiệu chỗ bắt đầu dịch mã, vừa mã hoá amino acid **methionine (Met)** ở nhân thực (**formylmethionine – fMet** ở nhân sơ).

**Bảng mã di truyền** (nucleotide thứ nhất – hàng; thứ hai – cột; trong mỗi ô, bốn tên lần lượt ứng với nucleotide thứ ba **U, C, A, G**; KT = kết thúc):

| 1 \ 2 | U | C | A | G |
|---|---|---|---|---|
| **U** | Phe Phe Leu Leu | Ser Ser Ser Ser | Tyr Tyr KT KT | Cys Cys KT Trp |
| **C** | Leu Leu Leu Leu | Pro Pro Pro Pro | His His Gln Gln | Arg Arg Arg Arg |
| **A** | Ile Ile Ile Met | Thr Thr Thr Thr | Asn Asn Lys Lys | Ser Ser Arg Arg |
| **G** | Val Val Val Val | Ala Ala Ala Ala | Asp Asp Glu Glu | Gly Gly Gly Gly |

Ví dụ cách tra: codon **GAC** → hàng G, cột A, vị trí thứ hai (C) → **Asp**. Đề thi **luôn cho** bảng mã (thường là bảng rút gọn gồm vài codon cần dùng); em không cần học thuộc, nhưng phải **tra nhanh và đúng chiều 5' → 3'**.

**Năm đặc điểm của mã di truyền** (SGK tr. 14):

| Đặc điểm | Nội dung | Ví dụ |
|---|---|---|
| **Mã bộ ba** | ba nucleotide liền kề quy định một amino acid | AGU mã hoá Ser |
| **Đọc liên tục** | đọc từ bộ ba mở đầu, theo chiều 5' → 3', **lần lượt từng bộ ba**, không chồng gối, không bỏ cách | 5'-AUGGUUGCC-3' đọc là AUG – GUU – GCC |
| **Đặc hiệu** | mỗi bộ ba chỉ mã hoá **một** loại amino acid | UAU chỉ mã hoá Tyr |
| **Thoái hoá** | **nhiều bộ ba** cùng mã hoá **một** amino acid | Ala có 4 bộ ba: GCU, GCC, GCA, GCG |
| **Phổ biến (vạn năng)** | về cơ bản mọi sinh vật dùng chung một bộ mã, **trừ một số ngoại lệ** | ti thể người: UGA mã hoá Trp, AUA mã hoá Met, AGA và AGG là bộ ba kết thúc |

> [!bay]
> - **Đặc hiệu** là "một bộ ba → một amino acid"; **thoái hoá** là "một amino acid ← nhiều bộ ba". Hai đặc điểm này **không mâu thuẫn** — đề rất hay tráo định nghĩa của hai đặc điểm.
> - Chỉ có **Met** (AUG) và **Trp** (UGG) là có **một** bộ ba duy nhất. Các amino acid khác có từ 2 đến 6 bộ ba.
> - "Mã di truyền phổ biến" **không** có nghĩa là tuyệt đối không có ngoại lệ. Câu "mã di truyền của mọi sinh vật hoàn toàn giống nhau, không có ngoại lệ" là **sai**.

> [!vi-du] Ví dụ 4
> Một đoạn mRNA có trình tự 5'-GC AUG GCA UUU AGC UGA CC-3'. Dùng bảng mã di truyền, xác định đoạn chuỗi polypeptide được tổng hợp. Chuỗi có bao nhiêu amino acid?

> [!goi-y] Gợi ý 1
> Dịch mã không bắt đầu từ nucleotide đầu tiên của mRNA mà từ **bộ ba mở đầu AUG**. Tìm AUG đầu tiên tính từ đầu 5'.

> [!goi-y] Gợi ý 2
> Từ AUG, cắt liên tục từng bộ ba cho đến khi gặp bộ ba kết thúc. Bộ ba kết thúc không cho amino acid.

> [!loi-giai] Lời giải
> Bước 1: Bỏ "GC" phía trước; khung đọc bắt đầu tại AUG: AUG – GCA – UUU – AGC – UGA.
>
> Bước 2: Tra bảng: AUG = Met, GCA = Ala, UUU = Phe, AGC = Ser, UGA = kết thúc.
>
> Kết luận: chuỗi **Met – Ala – Phe – Ser**, gồm **4** amino acid. "CC" ở cuối nằm sau bộ ba kết thúc, không được dịch mã.

> [!em-co-biet]
> Năm 1961, Marshall Nirenberg cho dịch mã một mRNA nhân tạo chỉ gồm toàn U (poly U) trong ống nghiệm và thu được chuỗi chỉ gồm toàn phenylalanine → codon đầu tiên được "giải mã" là **UUU = Phe**. Chỉ vài năm sau, toàn bộ 64 codon đã được xác định. Dạng bài "mRNA nhân tạo từ vài loại nucleotide" (Dạng 3) bắt nguồn từ chính các thí nghiệm này.

### 3.5. Quá trình dịch mã

**Dịch mã** là quá trình tổng hợp **protein** dựa trên trình tự nucleotide của **mRNA**, diễn ra ở **ribosome** trong tế bào chất. Mỗi ribosome gồm **tiểu phần nhỏ** và **tiểu phần lớn**; khi chưa dịch mã, hai tiểu phần nằm tách rời. Trên ribosome hoàn chỉnh có ba vị trí cho tRNA: **A** (nơi tRNA mang amino acid đi vào), **P** (nơi giữ tRNA mang chuỗi polypeptide đang dài ra), **E** (lối ra của tRNA đã "trả" amino acid).

Trước khi dịch mã, mỗi amino acid được **gắn vào đầu 3' của tRNA tương ứng** (nhờ enzyme đặc hiệu), tạo phức hợp **amino acid – tRNA**.

**Giai đoạn khởi đầu** (SGK Hình 2.6):

1. **Tiểu phần nhỏ** của ribosome bám vào mRNA ở vị trí **bộ ba mở đầu AUG**.
2. tRNA mang amino acid mở đầu (Met; fMet ở nhân sơ), có anticodon **3'-UAC-5'**, khớp bổ sung với AUG.
3. **Tiểu phần lớn** gắn vào → **ribosome hoàn chỉnh**; Met-tRNA nằm ở vị trí **P**, vị trí A còn trống, sẵn sàng đón tRNA tiếp theo.

**Giai đoạn kéo dài chuỗi polypeptide** (SGK Hình 2.7) — lặp lại theo chu kì:

1. tRNA mang amino acid thứ hai có anticodon khớp với codon tiếp theo đi vào **vị trí A**.
2. Hình thành **liên kết peptide** giữa amino acid ở vị trí A với amino acid (hoặc chuỗi) ở vị trí **P**.
3. Ribosome **dịch chuyển một bộ ba** trên mRNA theo chiều **5' → 3'**: tRNA ở P (đã trả amino acid) sang **E** rồi rời ribosome; tRNA ở A (đang mang chuỗi) sang **P**; vị trí A trống, đón tRNA mới.

Như vậy, mỗi tRNA đi qua ribosome theo đường **A → P → E** rồi ra ngoài; tRNA rời đi có thể lại gắn amino acid khác cùng loại để vận chuyển tiếp.

**Giai đoạn kết thúc** (SGK Hình 2.8): khi ribosome tới **bộ ba kết thúc** (UAA, UAG hoặc UGA), không có tRNA nào khớp với nó. Thay vào đó, một **protein gọi là yếu tố giải phóng** bám vào, cắt chuỗi polypeptide khỏi ribosome; ribosome **tách thành hai tiểu phần**. Sau đó, chuỗi polypeptide được **cắt bỏ amino acid mở đầu** và trải qua các **biến đổi hoá học** khác (cuộn gấp, gắn thêm nhóm chức…) mới trở thành protein có chức năng.

![Hình 3. Giai đoạn kéo dài của dịch mã: tRNA mang amino acid vào vị trí A, anticodon khớp với codon; liên kết peptide hình thành giữa amino acid ở A và chuỗi ở P; ribosome dịch chuyển trên mRNA theo chiều 5' → 3'](hinh-3-dich-ma.svg)

**Polyribosome (polysome).** Thường có **nhiều ribosome cùng dịch mã trên một mRNA**: ribosome đầu tiên trượt đi một đoạn thì ribosome sau bám vào AUG và bắt đầu. Mỗi ribosome tạo **một chuỗi polypeptide**; vì cùng đọc một mRNA nên các chuỗi này **giống hệt nhau**. Nhờ polysome, từ một mRNA, tế bào làm ra **nhiều protein trong thời gian ngắn**.

**Vì sao gọi là "dịch mã"?** (Dừng lại và suy ngẫm, SGK tr. 16.) Phiên mã là **chép lại** thông tin trong cùng một "ngôn ngữ" nucleotide (DNA → RNA), giống chép một trang sách bằng nét chữ khác. Dịch mã thì **chuyển** thông tin từ ngôn ngữ 4 chữ cái (nucleotide) sang ngôn ngữ 20 chữ cái (amino acid), giống **dịch** một văn bản sang thứ tiếng khác — cần có "từ điển" (mã di truyền) và "phiên dịch viên" (tRNA).

**Đếm trong dịch mã** — xét một mRNA có **n codon** kể cả bộ ba kết thúc:

| Đại lượng | Công thức | Vì sao |
|---|---|---|
| Số amino acid môi trường cung cấp cho 1 chuỗi (= số lượt tRNA) | **n − 1** | bộ ba kết thúc không có tRNA |
| Số liên kết peptide hình thành khi tổng hợp 1 chuỗi | **n − 2** | chuỗi n − 1 amino acid có n − 2 liên kết |
| Số amino acid của protein hoàn chỉnh (đã cắt Met mở đầu) | **n − 2** | bớt thêm 1 amino acid |
| k ribosome trượt qua một lần | k chuỗi; **k(n − 1)** amino acid | mỗi ribosome tạo 1 chuỗi giống nhau |

> [!vi-du] Ví dụ 5
> Một đoạn mRNA có trình tự 5'-AUG UUU GGC AAA UAG-3'. a) Viết trình tự amino acid của đoạn chuỗi polypeptide tương ứng. b) Viết anticodon (theo chiều 3' → 5') của các tRNA tham gia. c) Khi tổng hợp đoạn chuỗi này, có bao nhiêu liên kết peptide được hình thành?

> [!goi-y] Gợi ý 1
> Tra bảng từng codon; UAG là bộ ba gì?

> [!goi-y] Gợi ý 2
> Anticodon bổ sung với codon (A – U, G – C) và ngược chiều. Bộ ba kết thúc có tRNA nào không?

> [!loi-giai] Lời giải
> a) AUG = Met, UUU = Phe, GGC = Gly, AAA = Lys, UAG = kết thúc → **Met – Phe – Gly – Lys**.
>
> b) Chỉ 4 codon đầu có tRNA: **3'-UAC-5', 3'-AAA-5', 3'-CCG-5', 3'-UUU-5'**.
>
> c) Chuỗi 4 amino acid → **3** liên kết peptide.

> [!bay]
> - Ribosome dịch chuyển trên mRNA theo chiều **5' → 3'**, không phải 3' → 5'.
> - tRNA vào ở **A**, rời đi ở **E** — không phải vào ở P.
> - Trong polysome, mỗi ribosome tạo **một** chuỗi, các chuỗi **giống nhau** (không phải mỗi ribosome tạo một đoạn của cùng một chuỗi, cũng không phải tạo các protein khác nhau).
> - Yếu tố giải phóng là **protein**, không phải tRNA.

### 3.6. Mối quan hệ DNA – RNA – protein

Ghép tất cả lại (SGK tr. 16, Hình 2.9):

- Thông tin di truyền được **truyền từ tế bào này sang tế bào khác** nhờ **tái bản DNA** (Bài 1).
- Trong mỗi tế bào, thông tin được **biểu hiện** theo một chiều: **DNA → (phiên mã) → mRNA → (dịch mã) → protein → tính trạng**.
- Trường hợp đặc biệt: **RNA → DNA** nhờ **phiên mã ngược** (HIV, telomerase).
- Tất cả các quá trình này đều dựa trên **nguyên tắc bổ sung** A – T/U, G – C.

![Hình 4. Sơ đồ truyền đạt thông tin di truyền ở cấp phân tử: tái bản, phiên mã, dịch mã; mũi tên nét đứt là phiên mã ngược (trường hợp đặc biệt)](hinh-4-truyen-thong-tin.svg)

**Gene quy định tính trạng như thế nào?** Trình tự nucleotide của gene → quy định trình tự ribonucleotide của mRNA → quy định trình tự amino acid của protein → protein (enzyme, protein cấu trúc, hormone…) trực tiếp tạo nên đặc điểm của tế bào và cơ thể. Ví dụ: gene quy định enzyme tạo sắc tố melanin; gene hỏng → không có enzyme → không tạo được sắc tố → bạch tạng.

| Quá trình | Khuôn | Nguyên liệu | Enzyme / bộ máy | Nơi diễn ra (nhân thực) | Sản phẩm |
|---|---|---|---|---|---|
| Tái bản | 2 mạch DNA | nucleotide | DNA polymerase… | nhân | DNA |
| Phiên mã | mạch khuôn của gene | ribonucleotide | RNA polymerase | nhân | RNA |
| Dịch mã | mRNA | amino acid | ribosome, tRNA | tế bào chất | chuỗi polypeptide |
| Phiên mã ngược | RNA | nucleotide | enzyme phiên mã ngược | (virus trong tế bào chủ; telomerase ở nhân) | DNA |

> [!em-co-biet] RNA nhỏ điều hoà gene (SGK tr. 17)
> Ngoài mRNA, tRNA, rRNA, tế bào còn có các RNA rất ngắn như **miRNA** và **siRNA**. Chúng bắt cặp bổ sung với một đoạn mRNA của gene đích, tạo đoạn RNA mạch kép → mRNA đó bị phân huỷ hoặc không dịch mã được. Hệ gene người có hàng nghìn gene mã hoá các RNA nhỏ như vậy. Đây là ví dụ cho thấy có những gene mà sản phẩm cuối cùng là **RNA**, không phải protein.

> [!ung-dung]
> - **Vaccine mRNA** (như vaccine COVID-19): đưa vào tế bào một mRNA mang thông tin của protein gai virus. Tế bào người tự **dịch mã** ra protein gai → hệ miễn dịch "học" nhận diện virus. mRNA này không vào nhân, không được phiên mã ngược nên không thay đổi DNA của người tiêm.
> - Nhiều **kháng sinh** (như streptomycin, tetracycline) bám vào ribosome **vi khuẩn**, chặn dịch mã của vi khuẩn. Ribosome người khác ribosome vi khuẩn nên ít bị ảnh hưởng.
> - Thuốc điều trị HIV gồm nhóm **ức chế enzyme phiên mã ngược**: virus không chuyển được RNA thành DNA nên không cài được vào NST tế bào người.

## Dạng bài thi hay gặp

> [!ghi-nho] Công thức — gene **không phân mảnh** (vi khuẩn) có vùng mã hoá N nucleotide (2 mạch)
> | Đại lượng | Công thức |
> |---|---|
> | Số ribonucleotide của mRNA | $\dfrac{N}{2}$ |
> | Số codon (kể cả bộ ba kết thúc) | $n = \dfrac{N}{2 \cdot 3} = \dfrac{N}{6}$ |
> | Amino acid môi trường cung cấp cho 1 chuỗi | $\dfrac{N}{6} - 1$ |
> | Amino acid của protein hoàn chỉnh; liên kết peptide hình thành khi tổng hợp 1 chuỗi | $\dfrac{N}{6} - 2$ |
> | Ribonucleotide mỗi loại của mRNA | rU = A~khuôn~, rA = T~khuôn~, rG = C~khuôn~, rC = G~khuôn~ |
> | Gene phiên mã k lần | môi trường cung cấp $k \cdot \dfrac{N}{2}$ ribonucleotide; mỗi loại nhân k |
>
> Chiều dài mRNA (nhân sơ) bằng chiều dài vùng mã hoá của gene: mỗi ribonucleotide ứng với 0,34 nm.

### Dạng 1. Từ mạch khuôn → mRNA → anticodon → chuỗi amino acid

*Nhận biết:* đề cho trình tự một mạch của gene (có ghi 5', 3') và một **bảng mã rút gọn**; hỏi trình tự mRNA, anticodon, hoặc trình tự amino acid.

*Phương pháp:*
1. Xác định mạch đã cho là **mạch khuôn** hay **mạch mã hoá**.
2. Viết mRNA theo chiều **5' → 3'** (mẹo ở mục 3.1).
3. Tìm **AUG** đầu tiên tính từ đầu 5'; cắt từng bộ ba đến khi gặp bộ ba kết thúc.
4. Tra bảng mã; anticodon = bổ sung với codon, viết 3' → 5'.

> [!vi-du] Ví dụ 6
> Một đoạn mạch khuôn của gene ở vi khuẩn có trình tự 3'-TAC CAA GTT CGG ATC-5'. Cho bảng mã rút gọn:
>
> | Codon | AUG | GUU | CAA | GCC | UAG |
> |---|---|---|---|---|---|
> | Amino acid | Met | Val | Gln | Ala | KT |
>
> a) Viết trình tự mRNA. b) Viết trình tự amino acid của đoạn chuỗi polypeptide. c) Viết anticodon của tRNA mang Gln.

> [!goi-y] Gợi ý 1
> Mạch khuôn viết 3' → 5' → chỉ cần đổi chữ (A → U, T → A, G → C, C → G) là ra mRNA 5' → 3'.

> [!goi-y] Gợi ý 2
> Gln ứng với codon CAA. Anticodon bổ sung, ngược chiều.

> [!loi-giai] Lời giải
> a) mRNA: **5'-AUG GUU CAA GCC UAG-3'**.
>
> b) Met – Val – Gln – Ala (UAG là bộ ba kết thúc) → **Met – Val – Gln – Ala**.
>
> c) Codon 5'-CAA-3' → anticodon **3'-GUU-5'**.
>
> Kiểm tra: anticodon 3'-GUU-5' giống triplet tương ứng trên mạch khuôn 3'-GTT-5', chỉ thay T bằng U ✓.

*Bẫy:* đọc mạch khuôn như mRNA (chỉ đổi T thành U) — ra Tyr – … sai hoàn toàn; đọc mRNA theo chiều 3' → 5'; quên dừng ở bộ ba kết thúc hoặc dịch cả bộ ba kết thúc thành amino acid.

### Dạng 2. Đếm codon, amino acid, liên kết peptide, ribonucleotide

*Nhận biết:* cho chiều dài, số nucleotide của gene (hoặc từng mạch), số exon – intron, số lần phiên mã, số ribosome; hỏi các đại lượng của mRNA và protein.

*Phương pháp:*
1. Tìm số nucleotide **một mạch** của vùng được dịch mã (với gene phân mảnh: chỉ cộng các **exon**).
2. Chia 3 → số codon n (kể cả bộ ba kết thúc).
3. Áp dụng bảng: n − 1, n − 2…; nhân với số lần phiên mã, số ribosome nếu có.

> [!vi-du] Ví dụ 7
> Vùng mã hoá của một gene ở vi khuẩn dài 489,6 nm. Mạch khuôn của vùng này có A = 300, T = 420, G = 360, C = 360. Gene phiên mã 3 lần; mỗi mRNA có 5 ribosome trượt qua một lần. Theo lí thuyết, tính: a) số ribonucleotide mỗi loại môi trường cung cấp cho phiên mã; b) số amino acid môi trường cung cấp để tổng hợp các chuỗi polypeptide từ **một** mRNA; c) số amino acid của mỗi protein hoàn chỉnh.

> [!goi-y] Gợi ý 1
> Số nucleotide một mạch = 489,6 : 0,34. mRNA bổ sung với mạch khuôn: rU = A~khuôn~, rA = T~khuôn~, rC = G~khuôn~, rG = C~khuôn~.

> [!goi-y] Gợi ý 2
> Số codon = số ribonucleotide của mRNA : 3. Mỗi ribosome tạo 1 chuỗi cần n − 1 amino acid.

> [!loi-giai] Lời giải
> Bước 1: Mỗi mạch có 489,6 : 0,34 = 1440 nucleotide (kiểm tra: 300 + 420 + 360 + 360 = 1440 ✓). mRNA có 1440 ribonucleotide → n = 1440 : 3 = 480 codon.
>
> a) Mỗi mRNA: rU = 300, rA = 420, rC = 360, rG = 360. Ba lần phiên mã: **rU = 900, rA = 1260, rC = 1080, rG = 1080**.
>
> b) Mỗi chuỗi cần 480 − 1 = 479 amino acid; 5 ribosome → 5 × 479 = **2395** amino acid.
>
> c) Protein hoàn chỉnh: 480 − 2 = **478** amino acid.

> [!vi-du] Ví dụ 8 (gene phân mảnh)
> Vùng mã hoá của một gene ở sinh vật nhân thực gồm 4 exon và 3 intron xen kẽ. Số cặp nucleotide của các exon lần lượt là 150, 240, 312, 198; của các intron lần lượt là 400, 520, 380. Exon cuối chứa bộ ba kết thúc. Chỉ xét vùng mã hoá (bỏ qua mũ và đuôi poly A). Tính: a) số ribonucleotide của tiền mRNA và của mRNA trưởng thành; b) số amino acid của protein hoàn chỉnh.

> [!goi-y] Gợi ý 1
> Tiền mRNA chứa **cả exon lẫn intron**; mRNA trưởng thành chỉ còn **exon**.

> [!goi-y] Gợi ý 2
> Số codon tính trên mRNA trưởng thành. Protein hoàn chỉnh: bỏ bộ ba kết thúc và amino acid mở đầu.

> [!loi-giai] Lời giải
> a) Tổng exon: 150 + 240 + 312 + 198 = 900; tổng intron: 400 + 520 + 380 = 1300. Tiền mRNA: 900 + 1300 = **2200** ribonucleotide; mRNA trưởng thành: **900** ribonucleotide.
>
> b) Số codon = 900 : 3 = 300 → protein hoàn chỉnh có 300 − 2 = **298** amino acid.
>
> Nhận xét: phần được dịch mã chỉ chiếm 900 : 2200 ≈ 41% tiền mRNA.

*Bẫy:* tính số codon từ **tổng N của hai mạch** mà quên chia 2; với gene phân mảnh, cộng cả intron; quên trừ bộ ba kết thúc; nhầm "số amino acid môi trường cung cấp" (n − 1) với "số amino acid của protein hoàn chỉnh" (n − 2).

### Dạng 3. Số loại bộ ba và tỉ lệ bộ ba

*Nhận biết:* "mRNA nhân tạo chỉ gồm các loại nucleotide…", "có tối đa bao nhiêu loại bộ ba", "tỉ lệ bộ ba chứa…".

*Phương pháp:*
1. Với k loại nucleotide: có $k^3$ loại bộ ba. Muốn đếm bộ ba **mã hoá amino acid**: trừ đi các bộ ba kết thúc (UAA, UAG, UGA) **chỉ khi** chúng tạo được từ các loại nucleotide đã cho.
2. Tỉ lệ một bộ ba = tích tỉ lệ từng nucleotide (vì các nucleotide được ghép ngẫu nhiên). Nếu không quy định thứ tự (ví dụ "2A và 1U") thì nhân thêm số cách sắp xếp.

> [!vi-du] Ví dụ 9
> Một mRNA nhân tạo được tổng hợp từ ba loại ribonucleotide A, U, C. Hỏi có tối đa bao nhiêu loại bộ ba? Bao nhiêu loại trong đó mã hoá amino acid?

> [!goi-y] Gợi ý 1
> Mỗi vị trí trong bộ ba có 3 cách chọn.

> [!goi-y] Gợi ý 2
> Trong UAA, UAG, UGA, bộ ba nào chỉ gồm A, U, C?

> [!loi-giai] Lời giải
> Số loại bộ ba = 3^3^ = **27**. Trong ba bộ ba kết thúc, chỉ **UAA** tạo được từ A, U, C (UAG, UGA cần G). Vậy số loại bộ ba mã hoá amino acid = 27 − 1 = **26**.

> [!vi-du] Ví dụ 10
> Một mRNA nhân tạo được tổng hợp ngẫu nhiên từ hỗn hợp ribonucleotide loại A và U với tỉ lệ A : U = 4 : 1. Theo lí thuyết, tính: a) tỉ lệ bộ ba chứa 2 A và 1 U; b) tỉ lệ bộ ba kết thúc.

> [!goi-y] Gợi ý 1
> Tỉ lệ A = 4/5, U = 1/5. "2 A và 1 U" gồm các bộ ba AAU, AUA, UAA.

> [!goi-y] Gợi ý 2
> Với chỉ A và U, bộ ba kết thúc nào có thể xuất hiện?

> [!loi-giai] Lời giải
> a) Mỗi bộ ba có 2 A, 1 U có tỉ lệ (4/5)^2^ × (1/5) = 16/125; có 3 vị trí cho U → 3 × 16/125 = 48/125 = **38,4%**.
>
> b) Chỉ có UAA: (1/5) × (4/5)^2^ = 16/125 = **12,8%**.

*Bẫy:* quên trừ bộ ba kết thúc; trừ cả ba bộ ba kết thúc khi đề thiếu G; quên nhân số cách sắp xếp vị trí.

### Dạng 4. Đúng/Sai về cơ chế; đọc hình phiên mã – dịch mã

*Nhận biết:* đề cho hình (chạc phiên mã, ribosome có các vị trí E – P – A, sơ đồ gene có exon/intron) hoặc mô tả một thí nghiệm, kèm 4 phát biểu.

*Phương pháp:*
1. Trên hình, xác định **chiều 5' – 3'** của từng mạch trước tiên; mạch khuôn là mạch có đầu 3' ở phía vùng điều hoà/promoter.
2. Kiểm từng phát biểu theo **bảng so sánh** (tái bản – phiên mã – dịch mã; nhân sơ – nhân thực).
3. Cảnh giác với các từ tuyệt đối "tất cả", "luôn", "chỉ".

> [!vi-du] Ví dụ 11
> Trên hình chụp một tế bào vi khuẩn, người ta thấy một đoạn DNA mà từ đó nhiều sợi mRNA đang mọc ra, trên mỗi sợi mRNA đã có nhiều ribosome bám. Xét các phát biểu: (1) Phiên mã và dịch mã đang diễn ra đồng thời. (2) Các sợi mRNA ngắn hơn nằm gần promoter hơn. (3) Các ribosome trên cùng một mRNA tạo ra các chuỗi polypeptide có trình tự khác nhau. (4) Hình ảnh tương tự cũng thấy được ở gene trong nhân tế bào người. Phát biểu nào đúng?

> [!goi-y] Gợi ý 1
> Ở vi khuẩn không có màng nhân: mRNA vừa được tổng hợp đã có thể được ribosome bám vào. RNA polymerase đi từ promoter về vùng kết thúc — mRNA dài ra dần.

> [!goi-y] Gợi ý 2
> Ở người, mRNA phải hoàn thiện trong nhân rồi mới ra tế bào chất gặp ribosome.

> [!loi-giai] Lời giải
> (1) **Đúng** — nhân sơ: phiên mã đến đâu, dịch mã đến đó.
>
> (2) **Đúng** — RNA polymerase nào mới xuất phát từ promoter thì sợi mRNA của nó mới ngắn.
>
> (3) **Sai** — cùng đọc một mRNA nên các chuỗi giống hệt nhau.
>
> (4) **Sai** — ở tế bào nhân thực, phiên mã ở nhân, dịch mã ở tế bào chất, không xảy ra đồng thời trên cùng một sợi mRNA.

*Bẫy:* nhầm chiều dịch chuyển của RNA polymerase (trên mạch khuôn 3' → 5') với chiều tổng hợp mRNA (5' → 3'); cho rằng intron "không được phiên mã"; cho rằng bộ ba kết thúc có tRNA tương ứng.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Gene | Đoạn DNA mang thông tin quy định một sản phẩm: chuỗi polypeptide hoặc RNA |
| Cấu trúc gene | Vùng điều hoà (3' mạch khuôn, có promoter) – vùng mã hoá – vùng kết thúc (5' mạch khuôn) |
| Nhân sơ – nhân thực | Không phân mảnh, nhiều gene chung vùng điều hoà – phân mảnh (exon/intron), vùng điều hoà riêng |
| Phân loại | Gene cấu trúc / gene điều hoà; gene không phân mảnh / phân mảnh |
| Hệ gene | Toàn bộ DNA trong tế bào; người: > 3,2 tỉ cặp nucleotide, ~21 300 gene mã hoá protein, exon ~1,5% |
| Phiên mã | RNA polymerase; khuôn 3' → 5'; mRNA 5' → 3'; A – U, T – A, G – C, C – G |
| Hoàn thiện mRNA (nhân thực) | Mũ 7-methylguanine (5'), đuôi poly A (3'), cắt intron – nối exon |
| RNA | mRNA: khuôn dịch mã; tRNA: anticodon + mang amino acid (đầu 3'); rRNA: cấu tạo ribosome |
| Phiên mã ngược | RNA → DNA; HIV, telomerase; tạo cDNA, xét nghiệm virus RNA |
| Mã di truyền | Bộ ba; 61 mã hoá + 3 kết thúc (UAA, UAG, UGA); AUG mở đầu (Met); liên tục – đặc hiệu – thoái hoá – phổ biến |
| Dịch mã | Khởi đầu (AUG, Met-tRNA ở P) → kéo dài (A → P → E, ribosome đi 5' → 3') → kết thúc (yếu tố giải phóng); polysome |
| Dòng thông tin | DNA → mRNA → protein → tính trạng; RNA → DNA (đặc biệt) |

Công thức đếm: xem khung đầu mục **Dạng bài thi hay gặp** và bảng "Đếm trong dịch mã" (mục 3.5).
