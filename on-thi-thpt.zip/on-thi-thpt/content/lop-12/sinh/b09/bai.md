---
title: Mở rộng học thuyết Mendel
thoi-gian: 40 phút
muc-tieu:
  - Giải thích được vì sao các allele của cùng một gene có thể quan hệ trội hoàn toàn, trội không hoàn toàn hoặc đồng trội (ví dụ hoa mõm chó, nhóm máu ABO).
  - Giải thích được cách sản phẩm của các gene khác nhau tương tác với nhau: gián tiếp qua một con đường chuyển hoá hoặc cộng gộp tạo tính trạng số lượng.
  - Vận dụng sơ đồ lai, bảng tổ hợp giao tử và xác suất để giải bài tập về trội không hoàn toàn, nhóm máu ABO, tương tác gene và tính trạng số lượng.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mendel giả định: 1 gene → 1 tính trạng, gene chỉ có 2 allele, trội hoàn toàn. Thực tế phong phú hơn nhiều.
> 2. **Trội không hoàn toàn**: dị hợp có kiểu hình trung gian → F~2~ phân li **1 : 2 : 1** (kiểu hình trùng kiểu gene).
> 3. **Đồng trội**: dị hợp biểu hiện cả hai allele. Ví dụ I^A^I^B^ → nhóm máu AB. Gene ABO có **3 allele**, 6 kiểu gene, 4 nhóm máu.
> 4. **Nhiều gene – một tính trạng**: các enzyme do nhiều gene mã hoá cùng tham gia một **con đường chuyển hoá**; một gene hỏng (đồng hợp lặn) là chặn cả con đường (SGK gọi là tương tác **át chế**).
> 5. **Cộng gộp**: mỗi allele trội góp một "đơn vị" như nhau → kiểu hình phụ thuộc **tổng số allele trội** → tính trạng số lượng (chiều cao, màu da, năng suất…).

Ở Bài 8, em đã thấy quy luật Mendel giải thích rất gọn tỉ lệ 3 : 1 và 9 : 3 : 3 : 1. Nhưng để có những tỉ lệ "đẹp" ấy, Mendel đã chọn những tính trạng đơn giản nhất: **mỗi tính trạng do một gene**, **mỗi gene chỉ có hai allele**, và **allele trội lấn át hoàn toàn allele lặn**.

Các nghiên cứu về sau cho thấy thế giới sống phức tạp hơn:

- Một gene có thể có **nhiều hơn hai allele** (ví dụ gene nhóm máu ABO có 3 allele).
- Một gene có thể ảnh hưởng tới **nhiều tính trạng** khác nhau (người ta gọi là gene đa hiệu).
- Ngược lại, một tính trạng có thể do **nhiều gene** cùng quy định.

Điểm mấu chốt để hiểu cả bài: gene không trực tiếp "tạo ra" tính trạng. Gene → **protein** (enzyme, protein cấu trúc…) → tính trạng. Vì vậy, khi nói "các allele tương tác với nhau", thực chất là **các sản phẩm protein của chúng tương tác** với nhau (SGK tr. 46). Hiểu theo lượng và chức năng của protein, em sẽ tự giải thích được mọi trường hợp dưới đây.

> [!nen-tang] Nhắc lại từ Bài 8
> - Mỗi cơ thể lưỡng bội mang **2 allele** của một gene (một từ bố, một từ mẹ). Khi giảm phân, 2 allele phân li, mỗi giao tử nhận **1 allele**.
> - Cơ thể dị hợp **n** cặp gene phân li độc lập tạo $2^n$ loại giao tử với tỉ lệ bằng nhau.
> - Hai cơ thể dị hợp 2 cặp lai với nhau → **4 × 4 = 16** tổ hợp, chia thành 9 A_B_ : 3 A_bb : 3 aaB_ : 1 aabb.

## 1. Tương tác giữa các allele thuộc cùng một gene

Trong một gene, giữa hai allele có thể có ba kiểu quan hệ: **trội hoàn toàn** (như Mendel đã thấy), **trội không hoàn toàn** và **đồng trội**.

### 1.1. Trội không hoàn toàn

**Quan sát.** Ở cây hoa mõm chó, lai cây hoa đỏ thuần chủng với cây hoa trắng thuần chủng, F~1~ không đỏ cũng không trắng mà **toàn hoa hồng** – màu nằm giữa hai bố mẹ. Hiện tượng này gọi là **trội không hoàn toàn** (còn gọi là **di truyền trung gian**). Cho F~1~ tự thụ phấn, F~2~ xuất hiện lại cả ba màu theo tỉ lệ **1 đỏ : 2 hồng : 1 trắng** (SGK tr. 46, Hình 9.1).

![Hình 1. Trội không hoàn toàn ở hoa mõm chó: F₁ hồng, F₂ phân li 1 : 2 : 1](hinh-troi-khong-hoan-toan.svg)

Kí hiệu như SGK: allele A~1~ (đỏ), A~2~ (trắng).

| Kiểu gene | A~1~A~1~ | A~1~A~2~ | A~2~A~2~ |
|---|---|---|---|
| Số allele "làm màu" | 2 | 1 | 0 |
| Kiểu hình | đỏ | hồng | trắng |

**Vì sao F~1~ lại hồng?** Hãy hình dung allele A~1~ mã hoá enzyme tạo sắc tố đỏ, còn A~2~ không tạo được sắc tố. Cây A~1~A~1~ có "hai phần" enzyme → đủ sắc tố → đỏ. Cây A~1~A~2~ chỉ có "một phần" → lượng sắc tố **không đủ** để đỏ thẫm → hồng. Nói cách khác, sản phẩm của một allele A~1~ không đủ để lấn át hoàn toàn sự biểu hiện của allele kia.

So sánh với trội hoàn toàn: ở đậu hà lan, cây Aa có kiểu hình **giống hệt** cây AA vì chỉ một allele A đã tạo đủ sản phẩm.

> [!meo] Dấu hiệu nhận ra trội không hoàn toàn
> - F~1~ (con lai của hai dòng thuần) mang kiểu hình **trung gian**.
> - F~2~ có **3 kiểu hình** tỉ lệ 1 : 2 : 1 (thay vì 3 : 1). Tỉ lệ kiểu hình **trùng** tỉ lệ kiểu gene.
> - Nhìn kiểu hình là biết ngay kiểu gene → không cần lai phân tích.

> [!bay] Trội không hoàn toàn KHÔNG phải "di truyền pha trộn"
> Thấy F~1~ hồng, nhiều bạn nghĩ màu đỏ và trắng đã "hoà lẫn" vào nhau. Sai! Nếu pha trộn thật, F~2~ chỉ toàn hồng. Thực tế F~2~ lại xuất hiện cây **đỏ** và cây **trắng** y như ông bà → allele A~1~, A~2~ vẫn tồn tại nguyên vẹn, riêng rẽ – đúng như quy luật phân li của Mendel (Bài 8).

> [!vi-du] Ví dụ 1
> Ở hoa mõm chó (A~1~ đỏ, A~2~ trắng, trội không hoàn toàn), lai cây hoa hồng với cây hoa đỏ. Xác định tỉ lệ kiểu hình ở đời con.

> [!goi-y] Gợi ý 1
> Cây hồng có kiểu gene gì? Cây đỏ có kiểu gene gì? Mỗi cây cho mấy loại giao tử?

> [!goi-y] Gợi ý 2
> Cây đỏ A~1~A~1~ chỉ cho một loại giao tử A~1~. Vậy kiểu gene đời con phụ thuộc hoàn toàn vào giao tử của cây hồng.

> [!loi-giai] Lời giải
> Bước 1. P: A~1~A~2~ (hồng) × A~1~A~1~ (đỏ).
>
> Bước 2. Giao tử: cây hồng cho ½ A~1~ : ½ A~2~; cây đỏ cho 100% A~1~.
>
> Bước 3. Đời con: ½ A~1~A~1~ : ½ A~1~A~2~.
>
> Kết luận: **1 hoa đỏ : 1 hoa hồng**.

### 1.2. Đồng trội

**Đồng trội** là khi cơ thể dị hợp biểu hiện **cả hai** allele, mỗi allele cho kiểu hình riêng của nó – không phải trung gian, mà là "có cả hai".

Ví dụ kinh điển: **nhóm máu ABO** ở người (SGK tr. 47). Gene này có tới **3 allele**:

- I^A^: quy định kháng nguyên **A** trên bề mặt hồng cầu;
- I^B^: quy định kháng nguyên **B**;
- I^O^: không tạo được kháng nguyên A hay B.

Người I^A^I^B^ có **cả** kháng nguyên A **và** kháng nguyên B trên hồng cầu → nhóm máu **AB**. Đó là đồng trội: hai allele cùng "lên tiếng", không allele nào lấn allele nào.

Còn giữa I^A^ (hay I^B^) và I^O^ là quan hệ **trội hoàn toàn**: người I^A^I^O^ vẫn có kháng nguyên A như người I^A^I^A^.

![Hình 2. Bảng tổ hợp ba allele của gene nhóm máu ABO và nhóm máu tương ứng](hinh-abo.svg)

| Nhóm máu | Kháng nguyên trên hồng cầu | Kiểu gene |
|---|---|---|
| A | A | I^A^I^A^, I^A^I^O^ |
| B | B | I^B^I^B^, I^B^I^O^ |
| AB | A và B | I^A^I^B^ |
| O | không có | I^O^I^O^ |

Tóm gọn thứ bậc: **I^A^ = I^B^ > I^O^**.

**Vì sao có 6 kiểu gene?** Mỗi người chỉ mang 2 trong 3 allele. Số cách chọn: 3 kiểu đồng hợp (I^A^I^A^, I^B^I^B^, I^O^I^O^) + 3 kiểu dị hợp (I^A^I^B^, I^A^I^O^, I^B^I^O^) = 6.

> [!meo] Đếm nhanh số kiểu gene khi gene có n allele
> Số kiểu gene $= \dfrac{n(n+1)}{2}$, trong đó $n$ kiểu đồng hợp và $\dfrac{n(n-1)}{2}$ kiểu dị hợp. Với $n = 3$: $\dfrac{3\cdot 4}{2} = 6$.

> [!bay] Hai lỗi hay gặp với nhóm máu
> - Nhóm A **chưa chắc** là I^A^I^A^ – có thể là I^A^I^O^. Muốn biết, phải nhìn bố mẹ hoặc con cái: có người thân nhóm O là dấu hiệu người đó mang I^O^.
> - Nhóm **O** và nhóm **AB** thì chắc chắn kiểu gene (I^O^I^O^ và I^A^I^B^). Người nhóm AB **không thể** có con nhóm O, vì không có I^O^ để cho.

> [!vi-du] Ví dụ 2
> Bố có nhóm máu AB, mẹ có nhóm máu O. Các con của họ có thể có những nhóm máu nào, với tỉ lệ bao nhiêu? Có thể sinh con nhóm máu giống bố hoặc giống mẹ không?

> [!goi-y] Gợi ý 1
> Nhóm AB và nhóm O đều chỉ ứng với **một** kiểu gene. Viết ra rồi lập giao tử.

> [!goi-y] Gợi ý 2
> Mẹ I^O^I^O^ chỉ cho giao tử I^O^. Bố cho I^A^ hoặc I^B^.

> [!loi-giai] Lời giải
> P: I^A^I^B^ × I^O^I^O^.
>
> Giao tử: bố ½ I^A^ : ½ I^B^; mẹ 100% I^O^.
>
> Con: ½ I^A^I^O^ (nhóm A) : ½ I^B^I^O^ (nhóm B).
>
> Kết luận: con chỉ có thể là nhóm **A** hoặc **B** (mỗi nhóm ½); **không** thể là nhóm AB (giống bố) hay nhóm O (giống mẹ).

> [!ung-dung] Truyền máu
> Kháng nguyên A, B trên hồng cầu chính là thứ hệ miễn dịch của người nhận "soi" khi truyền máu. Truyền nhầm nhóm, kháng thể của người nhận có thể làm ngưng kết hồng cầu được truyền vào – rất nguy hiểm. Vì vậy, xét nghiệm nhóm máu luôn là bước bắt buộc trước khi truyền máu.

> [!em-co-biet] Không có trong SGK nhưng có thể gặp trong tài liệu tham khảo
> **Gene gây chết**: có những allele khi ở trạng thái đồng hợp làm cá thể chết từ giai đoạn phôi. Khi đó phép lai Aa × Aa chỉ còn 2 loại con sống theo tỉ lệ **2 : 1** thay vì 3 : 1 (vì nhóm ¼ AA đã chết). Ví dụ hay được nhắc là màu lông vàng ở chuột.

## 2. Tương tác giữa các allele thuộc các gene khác nhau

Bây giờ ta chuyển sang trường hợp **nhiều gene cùng quy định một tính trạng**. Sản phẩm của các gene khác nhau có thể "gặp nhau" theo hai cách chính (SGK tr. 47–48):

- **Gián tiếp**: mỗi gene mã hoá một enzyme cho một bước trong cùng **một con đường chuyển hoá**.
- **Cộng gộp**: mỗi allele trội góp một lượng nhỏ sản phẩm, các lượng này **cộng dồn** tạo ra kiểu hình.

(Ngoài ra, các chuỗi polypeptide do nhiều gene mã hoá còn có thể cùng ghép thành **một protein**, ví dụ hemoglobin gồm chuỗi α và chuỗi β do hai gene khác nhau mã hoá.)

### 2.1. Sản phẩm của các gene tương tác gián tiếp với nhau

**Mô hình (SGK Hình 9.2).** Màu vỏ một loài ốc được tạo ra qua chuỗi phản ứng:

![Hình 3. Hai enzyme do hai gene quy định cùng tham gia một con đường chuyển hoá tạo màu vỏ ốc](hinh-con-duong.svg)

- Allele **A** mã hoá enzyme A biến chất I (không màu) thành chất II (không màu).
- Allele **B** mã hoá enzyme B biến chất II thành chất III (sắc tố nâu).
- Allele **a**, **b** là allele đột biến mất chức năng, không tạo được enzyme.

Hãy đi theo "dây chuyền sản xuất":

| Kiểu gene | Enzyme A? | Enzyme B? | Chất cuối cùng | Màu vỏ |
|---|---|---|---|---|
| A_B_ | có | có | chất III | **nâu** |
| A_bb | có | không | dừng ở chất II | trắng |
| aaB_ | không | có (nhưng không có chất II để dùng) | dừng ở chất I | trắng |
| aabb | không | không | dừng ở chất I | trắng |

**Điều quan trọng:** hai enzyme không hề "chạm" vào nhau – chúng tương tác **gián tiếp**: sản phẩm của bước trước là nguyên liệu của bước sau. Chỉ cần **một** gene bị hỏng hoàn toàn (đồng hợp lặn aa hoặc bb) là dây chuyền đứt → vỏ trắng. Gene hỏng ấy đã "chặn" sự biểu hiện của gene còn lại, nên SGK gọi kiểu này là **tương tác át chế**.

**Từ cơ chế suy ra tỉ lệ.** Cho hai ốc dị hợp AaBb lai với nhau (hai gene nằm trên hai cặp NST khác nhau):

- 9 A_B_ → nâu;
- 3 A_bb + 3 aaB_ + 1 aabb = 7 → trắng.

→ F~2~: **9 nâu : 7 trắng**. Vẫn đủ 16 tổ hợp như phép lai hai tính trạng của Mendel, chỉ là các nhóm kiểu gene được "gom" lại theo kiểu hình.

> [!meo] Tổng tỉ lệ = 16 → nghĩ ngay đến 2 gene
> Nếu tỉ lệ kiểu hình đời con cộng lại bằng 16 (9 + 7, 9 + 3 + 4,…) dù chỉ xét **một** tính trạng, thì F~1~ đã cho 4 loại giao tử (tỉ lệ ngang nhau) mỗi bên → F~1~ dị hợp **2 cặp gene** phân li độc lập, cùng quy định tính trạng đó. Việc còn lại là ghép 4 nhóm 9 A_B_ : 3 A_bb : 3 aaB_ : 1 aabb vào các kiểu hình.

> [!bay] Cùng một hiện tượng, hai cái tên
> SGK Kết nối tri thức gọi kiểu tương tác qua con đường chuyển hoá là **tương tác át chế**, vì gene bị đột biến mất chức năng "át chế" sự biểu hiện của gene kia (SGK tr. 48). Nhiều sách tham khảo cũ lại gọi riêng trường hợp 9 : 7 như trên là "tương tác **bổ sung**" (hai gene bổ sung cho nhau mới cho màu), còn chữ "át chế" trong sách cũ thường dùng cho các tỉ lệ khác như 12 : 3 : 1, 13 : 3, 9 : 3 : 4. Đừng hoảng khi gặp tên khác: hãy **đọc cơ chế** đề bài mô tả rồi lập bảng như trên – tỉ lệ luôn tính ra đúng.

> [!vi-du] Ví dụ 3
> Ở loài ốc theo mô hình trên, người ta có hai dòng ốc vỏ trắng thuần chủng khác nhau là AAbb và aaBB. Lai chúng với nhau được F~1~; cho F~1~ giao phối với nhau được F~2~.
>
> a) F~1~ có màu gì? Vì sao "trắng × trắng" lại ra màu khác?
>
> b) Trong 1600 ốc F~2~, dự kiến có khoảng bao nhiêu ốc vỏ nâu?

> [!goi-y] Gợi ý 1
> F~1~ có kiểu gene AaBb. Nó có đủ cả enzyme A lẫn enzyme B không?

> [!goi-y] Gợi ý 2
> F~1~ × F~1~ là AaBb × AaBb → tỉ lệ nâu là bao nhiêu phần 16?

> [!loi-giai] Lời giải
> a) AAbb × aaBB → F~1~: AaBb. F~1~ có allele A (tạo enzyme A) và allele B (tạo enzyme B) → dây chuyền thông suốt → **vỏ nâu**. Mỗi dòng bố mẹ hỏng một khâu khác nhau; con lai nhận khâu tốt từ bên này bù cho khâu hỏng của bên kia.
>
> b) AaBb × AaBb → nâu (A_B_) chiếm $\dfrac{9}{16}$. Số ốc nâu ≈ $1600 \cdot \dfrac{9}{16} = 900$ con.

> [!em-co-biet] Các tỉ lệ khác của F₂ (không có trong SGK Kết nối tri thức)
> Tuỳ cách các sản phẩm gene tương tác, 16 tổ hợp của AaBb × AaBb có thể được gom thành nhiều tỉ lệ. Sách tham khảo hay nêu: 9 : 6 : 1, 9 : 3 : 4, 12 : 3 : 1, 13 : 3, 15 : 1 (và 1 : 4 : 6 : 4 : 1 của cộng gộp hai gene ở mục 2.2). Cách giải luôn giống nhau: **viết 4 nhóm 9 : 3 : 3 : 1 rồi gán kiểu hình theo cơ chế đề cho** – không cần học thuộc từng tỉ lệ.

### 2.2. Sản phẩm của các gene tương tác trực tiếp theo kiểu cộng gộp

**Quan sát.** Chiều cao, màu da, màu tóc ở người không chia thành vài "loại" rõ rệt như hoa đỏ – hoa trắng, mà biến đổi **liên tục** từ thấp đến cao, từ sáng đến sẫm. Lí do: những tính trạng này do **rất nhiều gene** quy định.

**Cơ chế.** Lấy màu da làm ví dụ (SGK tr. 48). Giả sử có 3 gene A, B, D:

- Mỗi allele trội (A, B hay D đều như nhau) tạo ra **một lượng nhỏ, bằng nhau** sắc tố melanin.
- Allele lặn (a, b, d) không tạo sắc tố.
- Màu da phụ thuộc vào **tổng số allele trội** trong kiểu gene, chứ không phụ thuộc đó là allele nào.

Như vậy AABbdd, AaBbDd, aaBBDd… đều có 3 allele trội → cùng một màu da. Người AABBDD (6 allele trội) da sẫm nhất; người aabbdd (0 allele trội) da sáng nhất.

Kiểu tương tác mà các allele trội **cộng dồn** tác động như thế gọi là **tương tác cộng gộp**; tính trạng do nhiều gene cộng gộp quy định gọi là **tính trạng số lượng**. Phần lớn các tính trạng kinh tế như tốc độ sinh trưởng, năng suất, cân nặng… đều là tính trạng số lượng.

**Phép lai AaBbDd × AaBbDd** (3 gene trên 3 cặp NST khác nhau):

- Mỗi bên cho $2^3 = 8$ loại giao tử → $8 \times 8 = 64$ tổ hợp.
- Mỗi con nhận 6 allele (3 từ bố, 3 từ mẹ); mỗi allele có xác suất $\dfrac12$ là trội.
- Số allele trội ở con có thể là 0, 1, 2, …, 6 → **7 nhóm kiểu hình**, tỉ lệ **1 : 6 : 15 : 20 : 15 : 6 : 1**.

![Hình 4. Phân bố tỉ lệ kiểu hình ở đời con AaBbDd × AaBbDd theo số allele trội](hinh-cong-gop.svg)

**Vì sao lại là 1, 6, 15, 20…?** Có 6 "ô" allele, mỗi ô trội hay lặn với xác suất ½. Số cách để đúng $k$ ô là trội chính là số tổ hợp chập $k$ của 6:

Tỉ lệ con có đúng $k$ allele trội:

$$P(k) = \frac{C_6^k}{2^6} = \frac{C_6^k}{64}$$

Ví dụ: $C_6^0 = 1$, $C_6^1 = 6$, $C_6^2 = 15$, $C_6^3 = 20$. Tổng quát, nếu đời con nhận tổng cộng $n$ allele **từ các cặp dị hợp** của bố mẹ thì

$$P(k) = \frac{C_n^k}{2^n}.$$

Đồ thị có dạng **hình chuông**: nhóm trung bình đông nhất, hai cực (rất sáng, rất sẫm) hiếm nhất. Càng nhiều gene, các bậc càng sát nhau, đồ thị càng "mượt" – đó là lí do ta thấy chiều cao, màu da biến đổi gần như liên tục.

> [!meo] Bấm máy tính
> Trên Casio fx-580VN X, $C_6^3$: bấm `6` `SHIFT` `÷` (nCr) `3` `=` → 20. Rồi chia cho 64.

> [!vi-du] Ví dụ 4
> Ở một loài cây, chiều cao do 3 gene A, B, D phân li độc lập, tương tác cộng gộp. Cây aabbdd cao 150 cm; mỗi allele trội làm cây cao thêm 10 cm.
>
> a) Cây AABBDD cao bao nhiêu? Lai cây cao nhất với cây thấp nhất được F~1~; F~1~ cao bao nhiêu?
>
> b) Cho F~1~ tự thụ phấn. Tính tỉ lệ cây cao 170 cm ở F~2~.

> [!goi-y] Gợi ý 1
> Chiều cao = 150 + 10 × (số allele trội). Cây 170 cm có mấy allele trội?

> [!goi-y] Gợi ý 2
> F~1~ là AaBbDd. F~2~: tỉ lệ cây có $k$ allele trội là $\dfrac{C_6^k}{64}$.

> [!loi-giai] Lời giải
> a) AABBDD có 6 allele trội: 150 + 6 · 10 = **210 cm**. F~1~ (AABBDD × aabbdd) là AaBbDd, có 3 allele trội: 150 + 3 · 10 = **180 cm** – đúng bằng trung bình hai bố mẹ.
>
> b) Cây 170 cm có (170 − 150) : 10 = 2 allele trội. Tỉ lệ $= \dfrac{C_6^2}{64} = \dfrac{15}{64}$.

> [!ung-dung] Chọn giống cây trồng, vật nuôi
> Năng suất lúa, sản lượng sữa, cân nặng lợn… là tính trạng số lượng, do nhiều gene cộng gộp. Vì thế nhà chọn giống không mong "một phép lai là xong" mà phải chọn lọc qua nhiều thế hệ để tích luỹ dần các allele có lợi. Tính trạng số lượng cũng chịu ảnh hưởng khá mạnh của điều kiện nuôi trồng (phân bón, thức ăn…), nên giống tốt vẫn cần chăm sóc tốt.

## Dạng bài thi hay gặp

### Dạng 1. Nhận biết kiểu quan hệ giữa các allele của một gene

*Nhận biết:* đề cho một tính trạng, lai hai dòng thuần, cho kiểu hình F~1~ và tỉ lệ F~2~.

*Phương pháp:*
1. F~2~ có tổng **4** tổ hợp (3 : 1 hoặc 1 : 2 : 1) → một gene, hai allele, F~1~ dị hợp.
2. F~1~ giống một bên bố mẹ, F~2~ 3 : 1 → trội hoàn toàn.
3. F~1~ trung gian, F~2~ 1 : 2 : 1 → trội không hoàn toàn.
4. F~1~ biểu hiện **cả hai** đặc điểm của bố mẹ (ví dụ cả kháng nguyên A và B) → đồng trội.

> [!vi-du] Ví dụ 5
> Ở một loài hoa, lai cây hoa đỏ thuần chủng với cây hoa trắng thuần chủng được F~1~ toàn hoa hồng. Cho F~1~ tự thụ phấn được F~2~. Người ta muốn thu được đời con có 100% cây hoa hồng. Cần chọn cặp bố mẹ nào ở F~2~?

> [!goi-y] Gợi ý 1
> F~1~ hồng, trung gian → trội không hoàn toàn. Viết kiểu gene của cây đỏ, hồng, trắng.

> [!goi-y] Gợi ý 2
> Con chắc chắn dị hợp khi nào? Khi một bên chỉ cho A~1~, bên kia chỉ cho A~2~.

> [!loi-giai] Lời giải
> F~1~ hoa hồng (trung gian) → trội không hoàn toàn: A~1~A~1~ đỏ, A~1~A~2~ hồng, A~2~A~2~ trắng.
>
> Muốn 100% con A~1~A~2~ thì một bên phải luôn cho A~1~ (cây đỏ A~1~A~1~), bên kia luôn cho A~2~ (cây trắng A~2~A~2~).
>
> Kết luận: chọn **cây hoa đỏ × cây hoa trắng** ở F~2~. (Lai hồng × hồng sẽ lại ra 1 : 2 : 1.)

*Bẫy:* thấy "3 kiểu hình" vội nghĩ có 2 gene. Hãy **cộng tỉ lệ**: 1 + 2 + 1 = 4 tổ hợp → vẫn chỉ một gene.

### Dạng 2. Nhóm máu ABO – bài toán cha mẹ và con

*Nhận biết:* cho nhóm máu của một số người trong gia đình, hỏi kiểu gene hoặc xác suất sinh con có nhóm máu nào đó.

*Phương pháp:*
1. Ghi ngay kiểu gene chắc chắn: nhóm O = I^O^I^O^, nhóm AB = I^A^I^B^.
2. Người nhóm A (hoặc B) có **bố, mẹ hoặc con nhóm O** → chắc chắn mang I^O^ (dị hợp).
3. Nếu chưa chắc, tính xác suất kiểu gene (ví dụ ⅓ đồng hợp : ⅔ dị hợp khi bố mẹ người đó đều dị hợp).
4. Lập giao tử, nhân xác suất. Các lần sinh độc lập nhau → nhân xác suất từng lần.

> [!vi-du] Ví dụ 6
> Một người đàn ông nhóm máu A có mẹ nhóm máu O. Vợ anh nhóm máu B, có bố nhóm máu O. Tính:
>
> a) Xác suất cặp vợ chồng này sinh một con nhóm máu AB.
>
> b) Xác suất họ sinh hai con đều có nhóm máu O.

> [!goi-y] Gợi ý 1
> Người chồng nhận gì từ mẹ nhóm O? Người vợ nhận gì từ bố nhóm O?

> [!goi-y] Gợi ý 2
> Cả hai đều dị hợp. Lập bảng 2 × 2 giao tử.

> [!loi-giai] Lời giải
> Chồng nhóm A, nhận I^O^ từ mẹ → I^A^I^O^. Vợ nhóm B, nhận I^O^ từ bố → I^B^I^O^.
>
> I^A^I^O^ × I^B^I^O^ → ¼ I^A^I^B^ (AB) : ¼ I^A^I^O^ (A) : ¼ I^B^I^O^ (B) : ¼ I^O^I^O^ (O).
>
> a) P(con AB) = **¼**.
>
> b) Mỗi lần sinh độc lập: P(2 con đều O) = ¼ × ¼ = **1/16**.

*Bẫy:* "bố A × mẹ B thì con chỉ có A, B hoặc AB" – sai, nếu cả hai dị hợp vẫn sinh được con nhóm O.

### Dạng 3. Tương tác qua con đường chuyển hoá – từ cơ chế đến tỉ lệ (và ngược lại)

*Nhận biết:* một tính trạng nhưng tỉ lệ F~2~ có tổng 16; hoặc đề mô tả các enzyme nối tiếp nhau.

*Phương pháp:*
1. Tổng = 16 → F~1~ dị hợp 2 cặp (AaBb), phân li độc lập.
2. Viết 9 A_B_ : 3 A_bb : 3 aaB_ : 1 aabb.
3. Gán kiểu hình theo cơ chế (có enzyme nào → tạo đến chất nào).
4. Nếu đề cho số liệu thô, chia cho tổng rồi nhân 16 để ra tỉ lệ gần đúng.

> [!vi-du] Ví dụ 7
> Cho cây hoa đỏ F~1~ tự thụ phấn, F~2~ thu được 562 cây hoa đỏ và 438 cây hoa trắng. Biết màu đỏ chỉ xuất hiện khi có đủ hai enzyme do allele A và allele B mã hoá.
>
> a) Xác định tỉ lệ kiểu hình F~2~ và kiểu gene F~1~.
>
> b) Trong số cây hoa trắng ở F~2~, cây thuần chủng chiếm tỉ lệ bao nhiêu?

> [!goi-y] Gợi ý 1
> Tổng 1000 cây. Đổi 562 và 438 thành "phần 16".

> [!goi-y] Gợi ý 2
> Hoa trắng gồm A_bb, aaB_, aabb. Trong đó, kiểu gene đồng hợp cả hai cặp là những kiểu nào?

> [!loi-giai] Lời giải
> a) $\dfrac{562}{1000} \cdot 16 \approx 9$; $\dfrac{438}{1000} \cdot 16 \approx 7$ → F~2~ ≈ **9 đỏ : 7 trắng**, tổng 16 → F~1~ là **AaBb**.
>
> b) Hoa trắng chiếm 7/16, gồm: AAbb, Aabb, aaBB, aaBb, aabb. Thuần chủng là AAbb, aaBB, aabb, mỗi kiểu 1/16 → tổng 3/16.
>
> Tỉ lệ cần tìm $= \dfrac{3/16}{7/16} = \dfrac{3}{7}$.

*Bẫy:* câu hỏi "**trong số** cây hoa trắng" – phải chia cho 7/16, không lấy 3/16 làm đáp số.

### Dạng 4. Tương tác cộng gộp – đếm allele trội

*Nhận biết:* "mỗi allele trội làm tăng/thêm…", "tính trạng số lượng", chiều cao/khối lượng/màu da theo bậc.

*Phương pháp:*
1. Đổi kiểu hình cần tìm ra **số allele trội** $k$ (từ công thức kiểu hình = giá trị nền + $k$ × đơn vị).
2. Đếm số allele trội **chắc chắn** con nhận được (từ các cặp đồng hợp trội AA, BB…) và số "ô" $n$ có thể trội hoặc lặn (từ các cặp dị hợp, mỗi ô xác suất ½).
3. Tính $P = \dfrac{C_n^{\,k'}}{2^n}$ với $k'$ = $k$ trừ số allele trội chắc chắn.

> [!vi-du] Ví dụ 8
> Chiều cao cây do 3 gene A, B, D phân li độc lập, tương tác cộng gộp; cây aabbdd cao 100 cm, mỗi allele trội cao thêm 5 cm. Phép lai AaBbDd × AaBBdd cho đời con có tỉ lệ cây cao 115 cm là bao nhiêu?

> [!goi-y] Gợi ý 1
> 115 cm ứng với mấy allele trội? Mẹ AaBBdd luôn cho con allele nào ở gene B? ở gene D?

> [!goi-y] Gợi ý 2
> Đếm số "ô" thật sự còn ngẫu nhiên: bố cho 3 ô, mẹ cho mấy ô?

> [!loi-giai] Lời giải
> 115 cm → (115 − 100) : 5 = **3** allele trội.
>
> Mẹ AaBBdd luôn cho B (1 allele trội chắc chắn) và luôn cho d. Ô ngẫu nhiên: 3 ô từ bố (A/a, B/b, D/d) + 1 ô từ mẹ (A/a) → $n = 4$.
>
> Cần thêm $3 - 1 = 2$ allele trội trong 4 ô: $P = \dfrac{C_4^2}{2^4} = \dfrac{6}{16} = \dfrac{3}{8}$.

*Bẫy:* quên allele trội "cho không" từ cặp đồng hợp BB, hoặc tính cả cặp dd (luôn lặn) vào $n$.

## Tóm tắt

| Kiểu tương tác | Bản chất | Ví dụ (SGK) | Dấu hiệu / tỉ lệ đặc trưng |
|---|---|---|---|
| Trội hoàn toàn | 1 allele trội đã đủ sản phẩm | Màu hoa đậu hà lan | F~2~ 3 : 1 |
| Trội không hoàn toàn | 1 allele trội không đủ sản phẩm → trung gian | Màu hoa mõm chó | F~1~ trung gian; F~2~ 1 : 2 : 1 |
| Đồng trội | Dị hợp biểu hiện cả hai allele | I^A^I^B^ → nhóm AB | 3 allele, 6 kiểu gene, 4 nhóm máu |
| Tương tác gián tiếp (át chế, theo SGK) | Các enzyme nối tiếp trong một con đường chuyển hoá; một gene hỏng chặn cả con đường | Màu vỏ ốc | AaBb × AaBb → 9 nâu : 7 trắng (tổng 16) |
| Cộng gộp | Mỗi allele trội góp một phần như nhau; kiểu hình theo tổng số allele trội | Màu da, chiều cao | AaBbDd × AaBbDd → 1 : 6 : 15 : 20 : 15 : 6 : 1; $P(k)=\frac{C_n^k}{2^n}$ |

> [!ghi-nho] Ba câu chốt
> - Gene → protein → tính trạng: "allele tương tác" là **sản phẩm** của chúng tương tác.
> - Một tính trạng mà tổng tỉ lệ là **16** → 2 gene; **64** → 3 gene.
> - Bài nhóm máu: chốt kiểu gene chắc chắn (O, AB, người có thân nhân nhóm O) trước, rồi mới tính xác suất.
