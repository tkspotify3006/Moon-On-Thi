---
title: Di truyền giới tính và di truyền liên kết với giới tính
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm NST giới tính và di truyền giới tính; phân biệt NST giới tính với NST thường.
  - Phân tích được cơ chế xác định giới tính (kiểu XX – XY, ZZ – ZW, XX – XO; theo mức bội thể; theo nhiệt độ) và giải thích vì sao tỉ lệ đực : cái trong tự nhiên thường xấp xỉ 1 : 1.
  - Nêu được quan điểm của bản thân về việc điều khiển giới tính ở người theo ý muốn.
  - Nêu được bối cảnh và trình bày được cách bố trí thí nghiệm của Morgan ở ruồi giấm (lai thuận, lai nghịch), từ đó nêu được khái niệm di truyền liên kết với giới tính.
  - Phân biệt được đặc điểm di truyền của gene trên NST X (di truyền chéo) và gene trên NST Y (di truyền thẳng).
  - Vận dụng để viết sơ đồ lai, tính tỉ lệ kiểu hình theo giới, tính xác suất sinh con mắc bệnh liên kết X ở người và giải thích các ứng dụng trong chăn nuôi.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **NST giới tính** mang gene quy định giới tính **và cả** những gene không liên quan đến giới. Ở người: nữ **XX**, nam **XY**; X và Y chỉ tương đồng ở hai đầu mút, phần lớn còn lại **không tương đồng**.
> 2. Giới tính thường do **tổ hợp NST giới tính** quyết định: XX – XY (người, thú, ruồi giấm), ZZ – ZW (chim, bướm, một số cá), XX – XO (châu chấu). Một số loài phụ thuộc mức bội thể (ong) hay nhiệt độ (rùa, cá sấu).
> 3. Tỉ lệ đực : cái ≈ **1 : 1** vì giới dị giao tử (XY) cho hai loại giao tử với **tỉ lệ ngang nhau**, thụ tinh ngẫu nhiên.
> 4. **Morgan** (1910): màu mắt ruồi giấm do gene trên **X, không có allele trên Y** → kết quả **lai thuận khác lai nghịch**, kiểu hình **phân bố khác nhau ở hai giới**, gene của bố truyền cho con gái rồi sang cháu trai (**di truyền chéo**). Gene trên Y (không có trên X) truyền từ bố cho 100% con trai (**di truyền thẳng**).
> 5. Ứng dụng: nhận biết **sớm** đực – cái nhờ tính trạng do gene trên NST giới tính; giải thích vì sao bệnh do allele lặn trên X (máu khó đông, mù màu) gặp **chủ yếu ở nam**.

Ở Bài 8, mọi phép lai của Mendel cho kết quả **giống nhau dù đảo vai bố mẹ**: cây hoa tím làm mẹ hay làm bố, F~1~ vẫn toàn hoa tím. Đó là vì các gene Mendel nghiên cứu nằm trên **NST thường** – thứ mà bố và mẹ đều có hai chiếc như nhau.

Nhưng có một cặp NST **không giống nhau** giữa hai giới: cặp NST giới tính. Gene nằm trên cặp này sẽ được "phân phát" cho con trai và con gái theo những cách khác nhau. Bài này trả lời hai câu hỏi:

- Vì sao sinh ra là trai hay gái, đực hay cái? Và vì sao số đực và số cái thường xấp xỉ bằng nhau?
- Những tính trạng **không liên quan đến giới** (màu mắt, khả năng đông máu, khả năng nhìn màu…) nhưng do gene trên NST giới tính quy định thì di truyền như thế nào?

> [!nen-tang] Nhắc lại từ Bài 7 và Bài 8
> - Trong tế bào lưỡng bội, NST xếp thành **cặp tương đồng**, một chiếc từ bố, một chiếc từ mẹ. Bộ NST người: 2n = 46 = **22 cặp NST thường + 1 cặp NST giới tính**.
> - Khi giảm phân, hai chiếc của mỗi cặp **phân li** về hai giao tử khác nhau (quy luật phân li). Thụ tinh **ngẫu nhiên** khôi phục lại các cặp.
> - Lai thuận – lai nghịch: đảo vai trò bố mẹ của hai dòng (dòng 1 làm mẹ × dòng 2 làm bố, rồi dòng 2 làm mẹ × dòng 1 làm bố). Với gene trên NST thường, hai phép lai cho kết quả **như nhau**.

## 1. Di truyền giới tính

### 1.1. Nhiễm sắc thể giới tính

**NST giới tính** là NST chứa các gene quy định giới tính của sinh vật. Nhưng nó không chỉ chứa gene "làm nên giới": trên NST X của người còn có hàng trăm gene khác, quy định khả năng đông máu, khả năng phân biệt màu… Chính những gene "ở nhờ" này tạo nên hiện tượng di truyền liên kết với giới tính ở phần 2.

Tuỳ loài, cặp NST giới tính có thể:

- **tương đồng** về hình dạng, kích thước: ví dụ ở muỗi *Aedes aegypti* (truyền bệnh sốt xuất huyết), hai chiếc của cặp NST giới tính trông giống nhau, chỉ khác nhau ở **một gene**;
- **không tương đồng**: khác nhau về kích thước và trình tự gene, như cặp XY ở người;
- thậm chí có loài mang **nhiều cặp** NST giới tính (SGK tr. 50 nêu ví dụ chim cánh cụt; ví dụ được biết đến nhiều nhất là thú mỏ vịt với 5 cặp NST giới tính).

**Cặp X và Y ở người** (SGK tr. 50, Hình 10.1). X lớn, mang rất nhiều gene; Y nhỏ hơn hẳn, mang ít gene. Hai chiếc chỉ giống nhau ở **hai đoạn ngắn ở hai đầu** (vùng tương đồng, kí hiệu PAR1 và PAR2) – nhờ hai đoạn này mà X và Y bắt cặp được với nhau khi giảm phân. Phần còn lại là **vùng không tương đồng**: gene trên đoạn này của X thì Y không có, và ngược lại.

![Hình 1. Sơ đồ cặp NST X và Y ở người: hai vùng tương đồng ở hai đầu, vùng không tương đồng ở giữa; gene SRY nằm trên vùng không tương đồng của Y](hinh-1-nst-xy.svg)

Trên vùng không tương đồng của Y có gene **SRY** – "công tắc" quyết định giới tính nam: có SRY hoạt động, tuyến sinh dục của phôi phát triển thành tinh hoàn.

| | NST thường | NST giới tính |
|---|---|---|
| Số cặp (ở người) | 22 cặp | 1 cặp |
| Giữa hai giới | giống nhau | khác nhau (nữ XX, nam XY) |
| Hai chiếc trong cặp | luôn tương đồng | ở người: XX tương đồng, XY phần lớn không tương đồng |
| Gene mang | gene quy định tính trạng thường | gene quy định giới tính **và** một số gene quy định tính trạng thường |

> [!bay] "NST giới tính chỉ chứa gene quy định giới tính" – SAI
> Đây là câu Đúng/Sai rất hay gặp. NST giới tính mang **cả** gene quy định tính trạng thường (màu mắt ruồi, máu khó đông, mù màu ở người…). Ngược lại, NST giới tính cũng có mặt trong **tế bào sinh dưỡng** (tế bào da, tế bào gan…), không chỉ trong tế bào sinh dục.

### 1.2. Cơ chế xác định giới tính

**Di truyền giới tính** là sự di truyền các NST giới tính – những NST quy định đặc điểm giới tính – từ thế hệ này sang thế hệ sau. Kí hiệu A là **NST thường** (SGK Bảng 10.1; ví dụ 44A = 44 NST thường), ta có ba kiểu thường gặp:

| Kiểu | Con cái | Con đực | Gặp ở |
|---|---|---|---|
| XX – XY | XX | XY | người (44A + XX / 44A + XY), thú, ruồi giấm |
| ZZ – ZW | **ZW** | **ZZ** | chim (gà…), một số loài cá, côn trùng (bướm, tằm) |
| XX – XO | XX | XO (chỉ một chiếc X) | châu chấu, dế, một số côn trùng |

Một cách gọi hay dùng trong đề: giới có hai NST giới tính giống nhau (XX, ZZ) là **giới đồng giao tử** – chỉ cho một loại giao tử về NST giới tính; giới XY, ZW, XO là **giới dị giao tử** – cho hai loại.

> [!bay] Chim ngược với người
> Ở gà, vịt, chim bồ câu, tằm…: **con mái** mới là giới dị giao tử **ZW**, con trống là ZZ. Vì thế ở chim, giới tính của con do **trứng** của mẹ quyết định (trứng mang Z hay W), không phải do tinh trùng như ở người.

Ngoài NST giới tính, giới tính còn có thể được quyết định bởi:

- **Mức bội thể**: ở ong mật, kiến, trứng được thụ tinh (2n) → con cái; trứng không được thụ tinh (n) → con đực.
- **Nhiệt độ môi trường** khi ấp trứng: ở một số loài rùa, cá sấu, nhiệt độ trong giai đoạn phát triển phôi quyết định con non thành đực hay cái.

**Ở người: có Y là nam.** Dù cùng kiểu XX – XY, các loài có thể xác định giới tính bằng cơ chế khác nhau. Ở người, hợp tử **có NST Y** (mang SRY) phát triển thành con trai, **không có Y** thành con gái; quá trình này gồm nhiều gene tương tác phức tạp. Bằng chứng rõ là các trường hợp rối loạn phân li NST giới tính trong giảm phân của bố hoặc mẹ:

- Người **XXY** (thừa một X) vẫn là **nam** (hội chứng Klinefelter) – vì có Y.
- Người **XO** (chỉ một X) là **nữ** (hội chứng Turner) – vì không có Y.

Như vậy ở người, **số lượng X không quyết định giới**, sự **có mặt của Y** mới quyết định.

> [!em-co-biet] Ruồi giấm khác người
> Ruồi giấm cũng có kiểu XX – XY nhưng giới tính phụ thuộc vào **tỉ lệ** giữa số NST X và số bộ NST thường. Ruồi XO là ruồi đực (bất thụ), còn ruồi XXY lại là ruồi cái. Đây là ví dụ cho câu của SGK "cùng một kiểu XX – XY nhưng cơ chế xác định giới tính khác nhau".

### 1.3. Vì sao tỉ lệ đực : cái thường xấp xỉ 1 : 1?

Xét ở người (Hình 2):

- Mẹ 44A + XX giảm phân → **mọi** trứng đều mang 22A + X.
- Bố 44A + XY giảm phân → cặp XY phân li, tạo **hai loại tinh trùng** 22A + X và 22A + Y với số lượng **ngang nhau** (½ : ½).
- Thụ tinh ngẫu nhiên: trứng gặp tinh trùng X → XX (gái); gặp tinh trùng Y → XY (trai).

→ Xác suất sinh con trai = xác suất sinh con gái = **½**.

![Hình 2. Cơ chế xác định giới tính ở người: bố cho hai loại tinh trùng X và Y với tỉ lệ ngang nhau nên con trai : con gái ≈ 1 : 1](hinh-2-xac-dinh-gioi-tinh.svg)

Tỉ lệ 1 : 1 chỉ đúng khi có đủ ba điều kiện: hai loại giao tử của giới dị giao tử tạo ra **ngang nhau**, có **khả năng thụ tinh như nhau**, và các hợp tử XX, XY có **sức sống như nhau**; ngoài ra số cá thể phải **đủ lớn**. Vì vậy trong thực tế tỉ lệ chỉ **xấp xỉ** 1 : 1 (ở người, tự nhiên sinh ra khoảng 104–106 bé trai trên 100 bé gái), và một gia đình nhỏ có thể toàn trai hoặc toàn gái mà chẳng có gì bất thường.

> [!bay] Giới tính do ai quyết định?
> Ở người, con là trai hay gái phụ thuộc vào **tinh trùng của bố** mang X hay Y – trứng của mẹ lúc nào cũng mang X. Quan niệm "trách người mẹ không sinh được con trai" là **sai về khoa học**. (Còn ở gà thì ngược lại: trứng của gà mái quyết định.)

> [!vi-du] Ví dụ 1
> Một cặp vợ chồng bình thường đã có hai con gái.
>
> a) Xác suất để đứa con thứ ba của họ là con trai bằng bao nhiêu?
>
> b) Nếu họ dự định sinh 3 con, xác suất để có cả con trai lẫn con gái là bao nhiêu?

> [!goi-y] Gợi ý 1
> Lần sinh trước có ảnh hưởng gì tới loại tinh trùng gặp trứng ở lần sau không?

> [!goi-y] Gợi ý 2
> "Có cả trai lẫn gái" là phần bù của "toàn trai" hoặc "toàn gái".

> [!loi-giai] Lời giải
> a) Mỗi lần sinh là một lần thụ tinh **độc lập**, xác suất con trai luôn bằng ½. Hai con gái đã sinh không làm thay đổi xác suất này → P = **½**.
>
> b) P(3 con đều trai) = $\left(\tfrac12\right)^3 = \tfrac18$; P(3 con đều gái) = $\tfrac18$.
>
> P(có cả trai và gái) = $1 - \tfrac18 - \tfrac18 = \tfrac34$.

> [!vi-du] Ví dụ 2
> Châu chấu cái có bộ NST 2n = 24 (22A + XX). Hỏi châu chấu đực có bao nhiêu NST trong tế bào sinh dưỡng? Châu chấu đực tạo ra những loại tinh trùng nào, mỗi loại có bao nhiêu NST?

> [!goi-y] Gợi ý 1
> Châu chấu thuộc kiểu XX – XO: con đực thiếu hẳn một chiếc NST giới tính.

> [!loi-giai] Lời giải
> Con đực: 22A + X → **23 NST**.
>
> Khi giảm phân, chiếc X không có cặp nên đi về **một** cực: một nửa số tinh trùng là 11A + X (**12 NST**), nửa còn lại là 11A (kí hiệu 11A + O, **11 NST**). Trứng luôn là 11A + X.
>
> → Con cái (22A + XX) : con đực (22A + X) ≈ 1 : 1 – vẫn đúng quy luật ở mục 1.3.

### 1.4. Điều khiển giới tính – nên hay không?

Hiểu cơ chế xác định giới tính, con người có thể **chủ động** điều khiển tỉ lệ đực : cái.

- **Trong chăn nuôi**, đó là việc rất có lợi: nuôi bò sữa, gà đẻ trứng cần nhiều con cái; nuôi lấy thịt nhiều khi cần con đực vì lớn nhanh hơn. (Xem cách làm ở mục 3.)
- **Ở người** thì khác hẳn. Việc chọn giới tính thai nhi theo ý muốn đã gây **mất cân bằng giới tính khi sinh**: theo các số liệu thống kê dân số những năm gần đây, ở Việt Nam có khoảng 111–112 bé trai trên 100 bé gái, cao hơn rõ rệt mức tự nhiên (khoảng 104–106). Hệ quả lâu dài: các dự báo cho thấy trong vài chục năm tới có thể dư thừa hàng triệu nam giới khó tìm bạn đời, kéo theo nhiều vấn đề xã hội. Vì vậy, pháp luật Việt Nam **nghiêm cấm lựa chọn giới tính thai nhi dưới mọi hình thức**.

> [!ung-dung] Em nghĩ sao?
> SGK yêu cầu em nêu **quan điểm của bản thân** về việc điều khiển giới tính ở người. Một câu trả lời tốt thường có ba ý: (1) cơ sở khoa học – giới tính do tinh trùng X hay Y quyết định, tự nhiên cân bằng ≈ 1 : 1; (2) hậu quả khi can thiệp hàng loạt – mất cân bằng giới tính, hệ luỵ xã hội; (3) thái độ – tôn trọng quy luật tự nhiên, bình đẳng giới, tuân thủ pháp luật; kĩ thuật chỉ nên dùng trong y học khi có chỉ định (ví dụ phòng tránh bệnh di truyền liên kết giới tính) và theo quy định.

## 2. Di truyền liên kết với giới tính

Sự di truyền của các tính trạng **không liên quan đến đặc điểm giới** nhưng do gene nằm trên **NST giới tính** quy định gọi là **di truyền liên kết với giới tính**. Hiện tượng này được Thomas Hunt Morgan phát hiện đầu tiên khi nghiên cứu màu mắt ở ruồi giấm (*Drosophila melanogaster*).

### 2.1. Thí nghiệm của Morgan ở ruồi giấm

**Bối cảnh.** Năm 1910, trong phòng thí nghiệm nuôi hàng nghìn ruồi mắt đỏ (kiểu dại), Morgan tình cờ phát hiện **một con ruồi đực mắt trắng**. Ông lai con đực này với ruồi cái mắt đỏ, rồi tiến hành tiếp các phép lai **thuận** và **nghịch** (SGK tr. 52, Hình 10.2). Ruồi giấm là đối tượng lí tưởng: dễ nuôi, vòng đời ngắn (khoảng 10–14 ngày), đẻ nhiều, có nhiều đột biến dễ quan sát và chỉ có 2n = 8.

**Kết quả** (tóm tắt):

| | Lai thuận | Lai nghịch |
|---|---|---|
| P (thuần chủng) | ♀ mắt đỏ × ♂ mắt trắng | ♀ mắt trắng × ♂ mắt đỏ |
| F~1~ | 100% mắt đỏ (cả ♀ và ♂) | ♀ 100% mắt đỏ; ♂ 100% mắt trắng |
| F~2~ (F~1~ × F~1~) | ♀: 100% đỏ; ♂: ½ đỏ, ½ trắng → chung **3 đỏ : 1 trắng**, mắt trắng **chỉ có ở con đực** | ♀: ½ đỏ, ½ trắng; ♂: ½ đỏ, ½ trắng → chung **1 : 1** ở cả hai giới |

**Có gì "lạ" so với Mendel?**

1. Lai thuận và lai nghịch cho kết quả **khác nhau** – điều không bao giờ xảy ra với gene trên NST thường.
2. Kiểu hình **phân bố không đều ở hai giới**: ở lai thuận, F~2~ vẫn có tỉ lệ 3 : 1 như Mendel, nhưng **tất cả** ruồi mắt trắng đều là con đực.
3. Ở lai nghịch, con đực F~1~ mắt trắng giống **mẹ**, con cái F~1~ mắt đỏ giống **bố** – tính trạng của bố mẹ "đi chéo" sang con khác giới.

**Giả thuyết của Morgan.** Màu mắt liên quan đến giới tính → gene quy định màu mắt nằm trên **NST X**, ở **vùng không tương đồng** với Y (Y không mang allele tương ứng). Kí hiệu: allele **A** (mắt đỏ) trội hoàn toàn so với **a** (mắt trắng).

Vì Y không có allele, kiểu gene được viết **kèm NST giới tính**:

| Giới | Kiểu gene có thể có | Kiểu hình |
|---|---|---|
| ♀ (XX) | X^A^X^A^, X^A^X^a^ | mắt đỏ |
| | X^a^X^a^ | mắt trắng |
| ♂ (XY) | X^A^Y | mắt đỏ |
| | X^a^Y | mắt trắng |

Điểm mấu chốt: con **đực chỉ có một allele** cho gene này. Chỉ cần một allele a là biểu hiện ngay mắt trắng – không có allele A nào "che" giúp. Con cái phải có **hai** allele a mới mắt trắng.

**Kiểm tra giả thuyết bằng sơ đồ lai.**

*Lai thuận:* P: X^A^X^A^ (♀ đỏ) × X^a^Y (♂ trắng)

- Giao tử P: ♀ 100% X^A^; ♂ ½ X^a^ : ½ Y.
- F~1~: ½ X^A^X^a^ (♀ đỏ) : ½ X^A^Y (♂ đỏ) → **100% mắt đỏ**.
- F~1~ × F~1~: X^A^X^a^ × X^A^Y. Giao tử: ♀ ½ X^A^ : ½ X^a^; ♂ ½ X^A^ : ½ Y.
- F~2~: ¼ X^A^X^A^ : ¼ X^A^X^a^ : ¼ X^A^Y : ¼ X^a^Y → **3 đỏ : 1 trắng**, mắt trắng (X^a^Y) **toàn là đực**.

![Hình 3. Sơ đồ phép lai thuận và lai nghịch của Morgan: gene quy định màu mắt nằm trên NST X](hinh-3-morgan.svg)

*Lai nghịch:* P: X^a^X^a^ (♀ trắng) × X^A^Y (♂ đỏ)

- F~1~: ½ X^A^X^a^ (♀ đỏ) : ½ X^a^Y (♂ trắng).
- F~1~ × F~1~: X^A^X^a^ × X^a^Y → F~2~: ¼ X^A^X^a^ (♀ đỏ) : ¼ X^a^X^a^ (♀ trắng) : ¼ X^A^Y (♂ đỏ) : ¼ X^a^Y (♂ trắng).

Sơ đồ lai khớp hoàn toàn với số liệu → giả thuyết được chấp nhận. Đây cũng là bằng chứng mạnh mẽ đầu tiên cho thấy **gene nằm trên NST**.

> [!meo] Viết giao tử khi có NST giới tính
> - Giới XX: viết như cặp gene bình thường, X^A^X^a^ → ½ X^A^ : ½ X^a^.
> - Giới XY: **Y luôn là một "loại giao tử"**: X^a^Y → ½ X^a^ : ½ Y. Tinh trùng mang Y không mang allele nào của gene này.
> - Lập bảng tổ hợp xong, **tách kết quả theo giới**: con nhận Y là đực, con nhận X của bố là cái.

> [!bay] Hai lỗi kinh điển
> - Viết kiểu gene con đực là "X^A^Y^a^" hay "Aa" – sai, vì Y **không** mang allele của gene trên vùng không tương đồng của X.
> - Câu hỏi "tỉ lệ ruồi đực mắt trắng" khác "tỉ lệ mắt trắng **trong số** ruồi đực". Ở F~2~ lai thuận: ruồi đực mắt trắng chiếm ¼ **tổng số**, nhưng chiếm ½ **số con đực**.

> [!vi-du] Ví dụ 3
> Ở ruồi giấm, A (mắt đỏ) trội hoàn toàn so với a (mắt trắng), gene nằm trên vùng không tương đồng của NST X. Cho ruồi cái mắt đỏ dị hợp lai với ruồi đực mắt trắng. Theo lí thuyết, xác định tỉ lệ kiểu hình ở đời con theo từng giới.

> [!goi-y] Gợi ý 1
> Ruồi cái đỏ dị hợp: X^A^X^a^. Ruồi đực mắt trắng: X^a^Y. Mỗi bên cho mấy loại giao tử?

> [!goi-y] Gợi ý 2
> Lập bảng 2 × 2: hàng là trứng (X^A^, X^a^), cột là tinh trùng (X^a^, Y).

> [!loi-giai] Lời giải
> P: X^A^X^a^ × X^a^Y. Giao tử: ♀ ½ X^A^ : ½ X^a^; ♂ ½ X^a^ : ½ Y.
>
> Con: ¼ X^A^X^a^ : ¼ X^a^X^a^ : ¼ X^A^Y : ¼ X^a^Y.
>
> - Ruồi cái: ½ mắt đỏ : ½ mắt trắng.
> - Ruồi đực: ½ mắt đỏ : ½ mắt trắng.
>
> Chung: 1 đỏ : 1 trắng, phân bố **đều** ở hai giới. Lưu ý: chỉ nhìn kết quả phép lai này, em không phân biệt được gene trên X với gene trên NST thường (Aa × aa cũng cho 1 : 1) – muốn chắc chắn phải dùng **lai thuận nghịch** (Dạng 2).

### 2.2. Đặc điểm di truyền của gene trên NST X

Từ thí nghiệm Morgan, rút ra đặc điểm của gene nằm trên vùng không tương đồng của X:

1. **Kết quả lai thuận và lai nghịch khác nhau.**
2. **Tỉ lệ kiểu hình khác nhau ở hai giới.** Tính trạng do allele **lặn** dễ biểu hiện ở giới **XY** (chỉ cần một allele), ít biểu hiện ở giới XX (cần hai allele).
3. **Di truyền chéo**: con trai nhận X **từ mẹ** (vì Y lấy từ bố), con gái nhận một X từ bố. Gene trên X của **ông ngoại** → **mẹ** (thường mang gene mà không biểu hiện) → **cháu trai**.

![Hình 4. Di truyền chéo (gene trên X) và di truyền thẳng (gene trên Y) qua ba thế hệ](hinh-4-cheo-thang.svg)

**Ở người.** Nhiều bệnh do allele lặn trên X:

- **Máu khó đông** (hemophilia): thiếu yếu tố đông máu, vết thương nhỏ cũng chảy máu kéo dài.
- **Mù màu** (đỏ – lục): không phân biệt được màu đỏ và màu lục.

Kí hiệu như bài toán: allele **M** (bình thường) trội hoàn toàn so với **m** (mù màu), hoặc **H**/**h** cho máu khó đông.

| Giới | Bình thường | Mang gene (không biểu hiện) | Bị bệnh |
|---|---|---|---|
| Nữ | X^H^X^H^ | X^H^X^h^ | X^h^X^h^ |
| Nam | X^H^Y | — | X^h^Y |

**Vì sao bệnh gặp chủ yếu ở nam?** Giả sử trong quần thể cứ 100 chiếc X thì có 1 chiếc mang h. Nam chỉ có một X → khoảng **1/100** nam bị bệnh. Nữ cần **cả hai** X đều mang h → chỉ khoảng 1/100 × 1/100 = **1/10 000** nữ bị bệnh. Đó là lí do bệnh máu khó đông, mù màu "gần như chỉ thấy ở đàn ông".

Không phải bệnh liên kết X nào cũng do allele lặn: **bệnh còi xương do giảm phosphate máu** do allele **trội** trên X quy định. Bố bị bệnh (X^D^Y) sẽ truyền X^D^ cho **tất cả** con gái → 100% con gái bị bệnh, con trai thì không (con trai nhận Y của bố).

> [!vi-du] Ví dụ 4
> Một người phụ nữ nhìn màu bình thường có bố bị mù màu, lấy chồng nhìn màu bình thường. Biết bệnh do allele lặn m trên vùng không tương đồng của X. Theo lí thuyết:
>
> a) Xác suất cặp vợ chồng này sinh con gái bị mù màu là bao nhiêu?
>
> b) Xác suất sinh một con trai bị mù màu là bao nhiêu? Trong số các con trai, tỉ lệ bị mù màu là bao nhiêu?

> [!goi-y] Gợi ý 1
> Người bố mù màu (X^m^Y) đã truyền cho con gái chiếc X nào?

> [!goi-y] Gợi ý 2
> Con gái luôn nhận X^M^ từ người chồng bình thường. Vậy con gái có thể bị bệnh không?

> [!loi-giai] Lời giải
> Vợ bình thường nhưng nhận X^m^ từ bố → **X^M^X^m^**. Chồng bình thường: **X^M^Y**.
>
> Con: ¼ X^M^X^M^ : ¼ X^M^X^m^ : ¼ X^M^Y : ¼ X^m^Y.
>
> a) Con gái nào cũng nhận X^M^ của bố → **không** có con gái mù màu: xác suất = **0**.
>
> b) Xác suất sinh một con **trai bị bệnh** (X^m^Y) = **¼**. Trong số con trai: $\dfrac{1/4}{1/2} = \dfrac12$.
>
> Nhận xét: allele m đi từ **ông ngoại** → **mẹ** (mang gene) → **cháu trai** – đúng kiểu di truyền chéo.

### 2.3. Di truyền liên kết với NST Y

Gene nằm trên vùng **không tương đồng của Y** (X không có allele tương ứng) thì:

- chỉ biểu hiện ở **giới XY**;
- truyền từ bố cho **100% con trai**, rồi từ con trai sang cháu trai… – gọi là **di truyền thẳng**. Con gái không bao giờ nhận được.

Hiện tượng này **khá hiếm** vì Y mang rất ít gene. Ở người, ví dụ được nêu trong SGK là tính trạng **có túm lông trên vành tai**, phát hiện ở một gia đình người Ấn Độ, luôn di truyền từ bố cho con trai. Kí hiệu kiểu gene: XY^a^ (nam có túm lông), XY^A^ (bình thường).

> [!bay] Gene trên X hay trên Y?
> - Tính trạng **chỉ ở nam** và truyền **bố → tất cả con trai** → gene trên **Y**.
> - Tính trạng **gặp ở cả hai giới** (dù nam nhiều hơn), bố bị bệnh không truyền cho con trai mà truyền qua con gái → gene trên **X**.
> - "Bệnh gặp nhiều ở nam" **không** có nghĩa là gene nằm trên Y.

> [!em-co-biet] Gene trên vùng tương đồng của X và Y
> Gene nằm ở vùng tương đồng (PAR) thì có allele trên **cả** X và Y, kí hiệu như X^A^Y^a^. Gene loại này di truyền gần giống gene trên NST thường, nhưng vẫn có thể cho kết quả lai thuận nghịch khác nhau. SGK Kết nối tri thức không đi sâu dạng này.

## 3. Ứng dụng của di truyền liên kết với giới tính

### 3.1. Phân biệt sớm giới tính vật nuôi

Ở nhiều loài, con đực và con cái có giá trị kinh tế khác nhau. Nếu nhận ra giới tính **thật sớm** (từ trứng, từ khi mới nở) thì người nuôi giữ lại đúng giới cần, tiết kiệm thức ăn, chuồng trại. Mẹo là chọn một tính trạng **dễ nhìn** (hình thái, màu sắc…) do gene trên **NST giới tính** quy định để làm **dấu chuẩn**.

- **Tằm dâu** (kiểu ZZ – ZW): dựa vào **màu sắc trứng** do gene trên NST giới tính quy định, người ta phân biệt trứng sẽ nở ra tằm đực hay tằm cái, giữ lại trứng tằm **đực** để nuôi vì tằm đực cho **nhiều tơ hơn** (SGK tr. 53).
- **Muỗi sốt rét**: các nhà khoa học dùng đột biến **chuyển đoạn** để chuyển gene **kháng thuốc trừ sâu** từ NST thường sang **NST Y**. Chỉ muỗi đực có Y nên chỉ con đực mang gene kháng thuốc → cho muỗi tiếp xúc với bề mặt có thuốc, con cái chết, còn lại toàn con đực. Muỗi đực được làm **bất thụ** rồi thả ra tự nhiên: chúng giao phối với muỗi cái hoang dã nhưng không sinh con → giảm số lượng muỗi (biện pháp thả con đực bất thụ).

> [!vi-du] Ví dụ 5
> Ở gà, allele B (lông vằn) trội hoàn toàn so với b (lông không vằn), gene nằm trên vùng không tương đồng của NST **Z**. Một trại gà muốn nhìn màu lông của gà con mới nở là biết ngay trống hay mái. Hãy chọn phép lai phù hợp và giải thích.

> [!goi-y] Gợi ý 1
> Ở gà, con **mái** là ZW, con trống là ZZ. Gà mái chỉ có một Z.

> [!goi-y] Gợi ý 2
> Muốn con trống và con mái khác màu nhau thì con trống nên nhận Z^B^ từ bố hay mẹ? Gà mái con nhận Z của ai?

> [!loi-giai] Lời giải
> Gà mái con (ZW) nhận W từ mẹ nên nhận Z **từ bố**; gà trống con (ZZ) nhận một Z từ mẹ, một Z từ bố.
>
> Chọn **gà trống không vằn Z^b^Z^b^ × gà mái vằn Z^B^W**:
>
> - Giao tử: trống 100% Z^b^; mái ½ Z^B^ : ½ W.
> - Con: ½ Z^B^Z^b^ (**trống, vằn**) : ½ Z^b^W (**mái, không vằn**).
>
> → Gà con lông vằn là trống, không vằn là mái. Nếu lai ngược lại (trống vằn Z^B^Z^B^ × mái không vằn Z^b^W) thì mọi gà con đều vằn – không phân biệt được.

> [!meo] Phân biệt gene trên Z với gene trên NST thường (câu hỏi SGK tr. 53)
> Dùng **lai thuận nghịch**: nếu hai phép lai cho kết quả giống nhau → gene trên NST thường; khác nhau, có sự phân bố kiểu hình khác nhau giữa trống và mái → gene trên Z. Quy tắc chọn phép lai "sexing" như Ví dụ 5: **giới đồng giao tử mang tính trạng lặn × giới dị giao tử mang tính trạng trội**.

### 3.2. Trong y học

Hiểu quy luật di truyền liên kết X, bác sĩ tư vấn di truyền có thể tính **xác suất** con mắc bệnh, nhận ra người phụ nữ **mang gene** (bình thường nhưng có thể truyền bệnh) từ phả hệ gia đình, để chủ động sàng lọc, chẩn đoán trước sinh. Đồng thời, các bất thường số lượng NST giới tính (XO, XXY…) có thể được phát hiện bằng phân tích bộ NST (Bài 7).

> [!em-co-biet] Bất hoạt NST X
> Nữ có hai X, nam một X – vậy sản phẩm của các gene trên X ở nữ có gấp đôi nam không? Không. Ở người và thú, trong mỗi tế bào của giới cái chỉ **một X hoạt động**, X còn lại phần lớn bị **bất hoạt** (co xoắn lại thành một khối nhỏ). Nhờ đó lượng sản phẩm gene trên X ở hai giới như nhau. Mỗi tế bào bất hoạt **ngẫu nhiên** X của bố hoặc của mẹ – vì thế mèo cái dị hợp về gene màu lông trên X có bộ lông "tam thể" loang lổ, và mèo tam thể hầu như luôn là mèo cái.

## Dạng bài thi hay gặp

### Dạng 1. Viết sơ đồ lai, tính tỉ lệ kiểu hình theo giới

*Nhận biết:* đề cho gene nằm trên vùng không tương đồng của X (hoặc Z), cho kiểu hình/kiểu gene P, hỏi tỉ lệ ở đời con, thường kèm "ở giới đực", "trong số con cái"…

*Phương pháp:*
1. Viết kiểu gene P **kèm NST giới tính** (X^A^X^a^, X^a^Y; chim: Z^B^W).
2. Viết giao tử, nhớ **Y (hoặc W) là một loại giao tử** không mang allele.
3. Lập bảng tổ hợp, **tách kết quả theo giới**.
4. Đọc kĩ mẫu số: "trong tổng số con" hay "trong số con đực/cái".

> [!vi-du] Ví dụ 6
> Ở ruồi giấm, A (mắt đỏ) trội hoàn toàn so với a (mắt trắng), gene trên vùng không tương đồng của X. Cho F~1~ của phép lai thuận của Morgan (X^A^X^a^ × X^A^Y) giao phối được F~2~; tiếp tục cho các ruồi F~2~ giao phối ngẫu nhiên với nhau được F~3~. Theo lí thuyết, ruồi mắt trắng chiếm tỉ lệ bao nhiêu ở F~3~?

> [!goi-y] Gợi ý 1
> Viết F~2~ tách theo giới: con cái gồm những kiểu gene nào, tỉ lệ bao nhiêu trong số con cái? Con đực thì sao?

> [!goi-y] Gợi ý 2
> Giao phối ngẫu nhiên → tính tỉ lệ **giao tử** của cả giới cái và cả giới đực, rồi nhân.

> [!loi-giai] Lời giải
> F~2~: ♀ ½ X^A^X^A^ : ½ X^A^X^a^; ♂ ½ X^A^Y : ½ X^a^Y.
>
> Giao tử cái: X^a^ = ½ · ½ = ¼, X^A^ = ¾.
>
> Giao tử đực: X^A^ = ¼, X^a^ = ¼, Y = ½.
>
> Mắt trắng ở F~3~: cái X^a^X^a^ = ¼ · ¼ = $\tfrac{1}{16}$; đực X^a^Y = ¼ · ½ = $\tfrac{1}{8}$.
>
> Tổng: $\tfrac{1}{16} + \tfrac{2}{16} = \tfrac{3}{16} = 0{,}1875$.

*Bẫy:* coi giao tử đực chỉ gồm X^A^, X^a^ (½ mỗi loại) mà quên Y; hoặc chọn mẫu số sai.

### Dạng 2. Nhận biết gene nằm trên NST X

*Nhận biết:* đề cho kết quả lai (thường là số liệu thô theo giới) và hỏi gene nằm ở đâu, hoặc cho lai thuận nghịch.

*Phương pháp – các dấu hiệu gene trên vùng không tương đồng của X:*
1. Lai thuận và lai nghịch cho kết quả **khác nhau**.
2. Tỉ lệ kiểu hình ở **hai giới khác nhau**; ví dụ F~2~ chung 3 : 1 nhưng kiểu hình lặn **chỉ có ở giới XY**.
3. Con **đực** (XY) có kiểu hình **giống mẹ** khi mẹ đồng hợp lặn (di truyền chéo).
4. Loại trừ: gene trên **Y** thì tính trạng chỉ có ở giới XY, truyền bố → 100% con đực; gene trên **NST thường** thì hai giới như nhau và lai thuận = lai nghịch.

> [!vi-du] Ví dụ 7
> Ở một loài côn trùng (con cái XX, con đực XY), lai con cái cánh dài thuần chủng với con đực cánh ngắn được F~1~ toàn cánh dài. Cho F~1~ giao phối với nhau, F~2~ thu được: 402 con cái cánh dài; 198 con đực cánh dài; 201 con đực cánh ngắn. Biết tính trạng do một gene có hai allele quy định. Xác định vị trí của gene và kiểu gene của F~1~.

> [!goi-y] Gợi ý 1
> Tính tỉ lệ chung, rồi tách riêng từng giới. Hai giới có giống nhau không?

> [!goi-y] Gợi ý 2
> Kiểu hình cánh ngắn xuất hiện ở giới nào? Nếu gene trên NST thường, con cái cánh ngắn phải chiếm bao nhiêu?

> [!loi-giai] Lời giải
> Chung: dài : ngắn = (402 + 198) : 201 ≈ 600 : 200 = **3 : 1** → một gene, cánh dài (A) trội hoàn toàn so với cánh ngắn (a), F~1~ dị hợp.
>
> Theo giới: con cái 100% cánh dài; con đực ≈ 1 dài : 1 ngắn. Cánh ngắn **chỉ có ở con đực** → kiểu hình phân bố khác nhau ở hai giới. Tính trạng có ở cả hai giới (cánh dài), nên gene không nằm trên Y. Vậy gene nằm trên **vùng không tương đồng của X**.
>
> F~1~: X^A^X^a^ × X^A^Y (đúng như lai thuận của Morgan).

*Bẫy:* thấy tỉ lệ chung 3 : 1 liền kết luận "gene trên NST thường" mà không tách giới.

### Dạng 3. Xác suất sinh con mắc bệnh liên kết X (phả hệ đơn giản)

*Nhận biết:* bệnh máu khó đông, mù màu… cho thông tin vài thế hệ trong gia đình, hỏi xác suất.

*Phương pháp:*
1. Ghi ngay kiểu gene **chắc chắn**: nam bình thường X^H^Y, nam bệnh X^h^Y; nữ bệnh X^h^X^h^.
2. Nữ bình thường mà **bố bị bệnh** hoặc **có con trai bị bệnh** → chắc chắn X^H^X^h^.
3. Nữ bình thường chỉ có **anh/em trai** bị bệnh (bố mẹ bình thường) → mẹ cô là X^H^X^h^, nên cô là X^H^X^H^ hay X^H^X^h^ **mỗi khả năng ½**.
4. Nhân xác suất kiểu gene với xác suất sinh con mang kiểu hình cần tìm. Phân biệt "sinh con trai bị bệnh" (mẫu số: tất cả con) với "con trai của họ bị bệnh" (mẫu số: con trai).

> [!vi-du] Ví dụ 8
> Một người phụ nữ bình thường có em trai bị máu khó đông, bố mẹ cô đều bình thường. Cô lấy một người chồng bình thường. Bệnh do allele lặn h trên vùng không tương đồng của X. Theo lí thuyết, tính xác suất:
>
> a) đứa con đầu lòng của họ bị máu khó đông;
>
> b) đứa con đầu lòng là con trai và bị máu khó đông, biết rằng người vợ có kiểu gene dị hợp.

> [!goi-y] Gợi ý 1
> Em trai X^h^Y nhận X^h^ từ ai? Từ đó suy ra kiểu gene của mẹ cô gái.

> [!goi-y] Gợi ý 2
> Cô gái nhận X^H^ từ bố chắc chắn, nhận X^H^ hay X^h^ từ mẹ mỗi khả năng ½.

> [!loi-giai] Lời giải
> Em trai X^h^Y nhận X^h^ từ mẹ → mẹ X^H^X^h^, bố X^H^Y. Cô gái: ½ X^H^X^H^ : ½ X^H^X^h^. Chồng: X^H^Y.
>
> a) Chỉ khi vợ là X^H^X^h^ mới sinh được con bệnh: X^H^X^h^ × X^H^Y → con bệnh (X^h^Y) = ¼.
>
> P = ½ · ¼ = $\tfrac18$.
>
> b) Vợ đã chắc chắn X^H^X^h^ → P(con trai bị bệnh) = **¼** (không nhân thêm ½ nữa).

*Bẫy:* quên xác suất ½ kiểu gene của người vợ (câu a); hoặc nhân thêm ½ "con trai" hai lần.

### Dạng 4. Kết hợp gene trên X với gene trên NST thường

*Nhận biết:* hai tính trạng, một do gene trên NST thường, một do gene trên X (hai gene phân li độc lập vì nằm trên hai cặp NST khác nhau).

*Phương pháp:* tách riêng từng gene, tính xác suất từng phần rồi **nhân** (như phân li độc lập ở Bài 8).

> [!vi-du] Ví dụ 9
> Ở người, bệnh bạch tạng do allele lặn a trên NST thường; bệnh mù màu do allele lặn m trên vùng không tương đồng của X. Một người chồng bình thường có em gái bị bạch tạng, bố mẹ anh đều bình thường. Người vợ bình thường có bố bị cả hai bệnh. Theo lí thuyết, xác suất để đứa con đầu lòng của họ không mắc bệnh nào trong hai bệnh là bao nhiêu?

> [!goi-y] Gợi ý 1
> Tách hai gene. Gene bạch tạng: chồng là AA hay Aa với xác suất bao nhiêu? Vợ chắc chắn là gì?

> [!goi-y] Gợi ý 2
> Gene mù màu: chồng X^M^Y; vợ nhận X^m^ từ bố.

> [!loi-giai] Lời giải
> *Bạch tạng:* bố mẹ chồng Aa × Aa (vì có con gái aa) → chồng bình thường: ⅓ AA : ⅔ Aa. Vợ nhận a từ bố → Aa.
>
> P(con aa) = ⅔ · ¼ = $\tfrac16$ → P(không bạch tạng) = $\tfrac56$.
>
> *Mù màu:* X^M^Y × X^M^X^m^ → P(con mù màu) = ¼ → P(không mù màu) = ¾.
>
> P(không mắc bệnh nào) = $\tfrac56 \cdot \tfrac34 = \tfrac58 = 0{,}625$.

*Bẫy:* tính chồng Aa với xác suất ½ thay vì ⅔ (người bình thường thì đã loại khả năng aa).

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| NST giới tính | Mang gene quy định giới tính và cả gene tính trạng thường; ở người XY chỉ tương đồng ở hai đầu (PAR), SRY trên Y |
| Kiểu xác định giới tính | XX – XY (người, thú, ruồi giấm); ZZ – ZW (chim, tằm: **mái ZW**); XX – XO (châu chấu); mức bội thể (ong); nhiệt độ (rùa, cá sấu) |
| Tỉ lệ 1 : 1 | Giới dị giao tử cho 2 loại giao tử ½ : ½, thụ tinh ngẫu nhiên, sức sống như nhau |
| Gene trên X (không có trên Y) | Lai thuận ≠ lai nghịch; hai giới khác nhau; di truyền **chéo**; tính trạng lặn biểu hiện nhiều ở giới XY |
| Gene trên Y (không có trên X) | Chỉ ở giới XY; bố → 100% con trai; di truyền **thẳng** |
| Morgan, lai thuận | X^A^X^A^ × X^a^Y → F~1~ 100% đỏ → F~2~ 3 đỏ : 1 trắng, trắng toàn đực |
| Morgan, lai nghịch | X^a^X^a^ × X^A^Y → F~1~ ♀ đỏ, ♂ trắng → F~2~ 1 : 1 ở cả hai giới |
| Ứng dụng | Sexing sớm (màu trứng tằm, gene trên Y ở muỗi; gà: trống lặn × mái trội); tư vấn di truyền bệnh máu khó đông, mù màu |

> [!ghi-nho] Ba câu chốt
> - Viết kiểu gene **kèm NST giới tính**; giới XY chỉ có **một** allele (X^a^Y đã biểu hiện lặn).
> - Lai thuận ≠ lai nghịch, hai giới khác tỉ lệ → nghĩ ngay đến gene trên **X**; chỉ giới XY, bố → con trai → gene trên **Y**.
> - Bài xác suất: chốt kiểu gene người phụ nữ (bố bệnh / con trai bệnh → chắc chắn mang gene; chỉ có anh em trai bệnh → ½), rồi đọc kĩ mẫu số.
