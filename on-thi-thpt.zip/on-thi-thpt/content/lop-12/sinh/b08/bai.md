---
title: Học thuyết di truyền của Mendel
thoi-gian: 45 phút
muc-tieu:
  - Nêu được bối cảnh ra đời các thí nghiệm của Mendel và vì sao ông bác bỏ thuyết di truyền pha trộn.
  - Trình bày được cách Mendel chọn đối tượng, bố trí và tiến hành thí nghiệm lai (dòng thuần chủng, lai thuận nghịch, theo dõi qua nhiều thế hệ, thống kê số liệu).
  - Giải thích được kết quả lai một tính trạng, lai hai tính trạng; phát biểu được quy luật phân li và quy luật phân li độc lập.
  - Trình bày được cơ sở tế bào học của hai quy luật dựa trên mối quan hệ giữa nguyên phân, giảm phân và thụ tinh.
  - Giải được các dạng bài: tỉ lệ giao tử, kiểu gene, kiểu hình đời con; tìm kiểu gene của P; tính xác suất.
  - Nêu được vì sao học thuyết Mendel đặt nền móng cho di truyền học hiện đại.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Mendel dùng **dòng thuần chủng**, lai rồi theo dõi **từng tính trạng qua nhiều thế hệ**, **đếm và thống kê** con lai → phát hiện các tỉ lệ 3 : 1 và 9 : 3 : 3 : 1.
> 2. Mỗi tính trạng do **một cặp nhân tố di truyền** (nay gọi là **cặp allele** của một gene) quy định; chúng **không hòa trộn** vào nhau.
> 3. **Quy luật phân li**: khi tạo giao tử, hai allele của một cặp phân li đồng đều → mỗi giao tử chỉ chứa **một** allele (Aa → ½A : ½a).
> 4. **Quy luật phân li độc lập**: các cặp allele nằm trên **các cặp NST tương đồng khác nhau** phân li độc lập → AaBb cho 4 loại giao tử bằng nhau; F~2~ = (3 : 1)^2^ = 9 : 3 : 3 : 1.
> 5. Cơ sở tế bào học: sự **phân li của cặp NST tương đồng** và sự **sắp xếp ngẫu nhiên** của các cặp NST ở kì giữa giảm phân I, cộng với **thụ tinh ngẫu nhiên**.

> [!nen-tang] Nhớ lại từ Bài 7 và lớp 10
> - Trong tế bào sinh dưỡng, NST tồn tại thành **từng cặp tương đồng** (một chiếc từ bố, một chiếc từ mẹ).
> - Mỗi gene nằm ở một vị trí xác định trên NST gọi là **locus**. Ở cùng một locus trên cặp NST tương đồng có thể là hai phiên bản khác nhau của gene — đó là các **allele** (ví dụ A và a).
> - **Giảm phân**: NST nhân đôi một lần, tế bào chia hai lần. Ở **giảm phân I**, hai chiếc của cặp NST tương đồng tách nhau về hai tế bào con; ở **giảm phân II**, hai chromatid chị em tách nhau. Kết quả: mỗi giao tử chỉ mang **một chiếc** của mỗi cặp NST.
> - **Thụ tinh**: giao tử đực (n) + giao tử cái (n) → hợp tử (2n), khôi phục lại từng cặp NST.
>
> Bài này cho em thấy: chính cách NST "di chuyển" trong giảm phân và thụ tinh tạo ra các tỉ lệ mà Mendel đã đếm được từ hơn 150 năm trước.

## 1. Bối cảnh ra đời thí nghiệm của Mendel

Gregor Johann Mendel (1822 – 1884) là một nhà giáo, nhà khoa học tự nhiên người Séc. Ông được học cách làm thực nghiệm và dùng **toán học** để giải thích hiện tượng tự nhiên — một điều rất hiếm ở các nhà sinh học thời đó.

**Quan niệm phổ biến lúc bấy giờ: thuyết di truyền pha trộn.** Nhiều người tin rằng vật chất di truyền giống như chất lỏng (như máu): con lai là "hỗn hợp" của bố và mẹ, giống như pha mực xanh với nước trắng thì được màu xanh nhạt — và **không bao giờ tách lại được**.

Nhưng Mendel quan sát thấy nhiều đặc điểm được truyền **nguyên vẹn** qua các thế hệ: có những đặc điểm "biến mất" ở con rồi lại **hiện ra y hệt** ở cháu. Nếu là pha trộn thì điều đó không thể xảy ra. Để tìm ra cơ chế thật, ông tiến hành thí nghiệm trên nhiều loài (đậu hà lan, ong mật…), từ đó bác bỏ thuyết pha trộn và đề xuất **thuyết di truyền hạt** — vật chất di truyền là những "hạt" (nhân tố) riêng rẽ, không hòa lẫn.

> [!em-co-biet]
> Công trình của Mendel công bố năm 1866 gần như bị lãng quên suốt 34 năm. Đến năm 1900, ba nhà khoa học ở ba nước khác nhau độc lập "tìm lại" được các quy luật này — lúc đó người ta mới hiểu tầm vóc của ông.

### 1.1. Phương pháp nghiên cứu của Mendel — vì sao ông thành công?

Mendel không có kính hiển vi điện tử, không biết DNA là gì. Ông thành công nhờ **cách làm**:

| Bước | Mendel làm gì | Vì sao quan trọng |
|---|---|---|
| 1. Chọn đối tượng | Đậu hà lan: tự thụ phấn nghiêm ngặt, vòng đời ngắn, nhiều hạt, nhiều tính trạng tương phản rõ | Dễ tạo dòng thuần, dễ lai, số lượng con lai đủ lớn để thống kê |
| 2. Tạo dòng thuần chủng | Cho cây tự thụ phấn qua nhiều thế hệ đến khi đời con giống hệt bố mẹ | Bảo đảm bố mẹ "sạch", kết quả lai không bị nhiễu |
| 3. Lai và theo dõi | Lai các dòng khác nhau ở **một** hoặc **hai** tính trạng; theo dõi riêng từng tính trạng qua F~1~, F~2~, F~3~; làm cả **lai thuận và lai nghịch** | Tách bài toán phức tạp thành bài toán đơn giản |
| 4. Đếm và thống kê | Đếm hàng nghìn cây/hạt, tính tỉ lệ | Thấy được quy luật ẩn sau con số (3 : 1, 9 : 3 : 3 : 1) |
| 5. Giả thuyết → kiểm chứng | Đề xuất giả thuyết, rồi dự đoán và làm **phép lai kiểm nghiệm** | Đây là phương pháp khoa học thực nghiệm chuẩn mực |

Cách làm này ngày nay gọi là **phương pháp phân tích các thế hệ lai**.

> [!bay]
> Đề thi hay hỏi "yếu tố nào **không** thuộc phương pháp của Mendel". Các đáp án như "quan sát NST dưới kính hiển vi", "phân tích trình tự DNA", "gây đột biến" đều **không** phải — Mendel chỉ dùng lai, đếm và toán xác suất.

## 2. Thí nghiệm lai một tính trạng — quy luật phân li

### 2.1. Bố trí và kết quả thí nghiệm

Mendel làm 7 phép lai một tính trạng (màu hoa, hình dạng hạt, màu hạt, hình dạng quả, màu quả, chiều cao cây, vị trí hoa). Mỗi tính trạng có **hai đặc tính tương phản** (hoa tím – hoa trắng, hạt trơn – hạt nhăn…). Xét tính trạng màu hoa (SGK tr. 41):

- **Cách lai:** ở cây làm mẹ, cắt bỏ nhị từ khi hoa chưa nở (để không tự thụ phấn), rồi lấy hạt phấn của cây làm bố rắc lên đầu nhụy. Làm cả lai thuận (♀ tím × ♂ trắng) và lai nghịch (♀ trắng × ♂ tím).
- **P** (thuần chủng): hoa tím × hoa trắng.
- **F~1~**: 100% hoa tím (lai thuận hay nghịch đều như nhau).
- **F~2~** (cho F~1~ tự thụ phấn): xuất hiện lại hoa trắng, tỉ lệ ≈ **3 tím : 1 trắng**. (Số liệu thật của Mendel: 705 tím : 224 trắng ≈ 3,15 : 1.)
- **F~3~** (cho từng cây F~2~ tự thụ phấn):
  - cây hoa trắng F~2~ → 100% trắng;
  - trong số cây hoa tím F~2~: **1/3** cho đời con toàn tím, **2/3** cho đời con phân li 3 tím : 1 trắng (giống F~1~).

Đặc tính hiện ra ở F~1~ (hoa tím) gọi là **trội**; đặc tính bị "che" ở F~1~ và chỉ hiện lại ở F~2~ (hoa trắng) gọi là **lặn**.

### 2.2. Mendel giải thích như thế nào?

Hãy suy luận giống Mendel:

1. Hoa trắng "biến mất" ở F~1~ nhưng **hiện lại y nguyên** ở F~2~ (không phải trắng nhạt hay tím nhạt) → yếu tố quy định màu trắng vẫn nằm trong F~1~, **không bị hòa tan**. Thuyết pha trộn sai.
2. Kết quả F~3~ cho thấy hoa tím F~2~ có **hai loại**: loại "thuần" (chiếm 1/3) và loại "giống F~1~" (chiếm 2/3). Vậy F~2~ thực chất là: **1 tím thuần : 2 tím giống F~1~ : 1 trắng thuần**.

Từ đó Mendel đề xuất **giả thuyết**:

- Mỗi tính trạng do **một cặp nhân tố di truyền** quy định: một nhân tố từ bố, một từ mẹ. Kí hiệu chữ in hoa cho nhân tố trội (A), chữ thường cho nhân tố lặn (a).
- Các nhân tố tồn tại **riêng rẽ**, không pha trộn, được truyền nguyên vẹn qua giao tử.
- Khi tạo giao tử, mỗi giao tử chỉ nhận **một** nhân tố của cặp. Cây F~1~ (Aa) tạo **2 loại giao tử A và a với tỉ lệ bằng nhau**.
- Thụ tinh là sự kết hợp **ngẫu nhiên** của giao tử đực và cái.

Viết thành sơ đồ lai:

=> P~tc~: AA (tím) × aa (trắng)

=> G~P~: A ……… a

=> F~1~: Aa (100% tím)

=> F~1~ × F~1~: Aa × Aa

Mỗi bên cho ½A : ½a. Ta kẻ **bảng Punnett** (hàng: giao tử cái, cột: giao tử đực):

| ♀ \ ♂ | ½ A | ½ a |
|---|---|---|
| **½ A** | ¼ AA (tím) | ¼ Aa (tím) |
| **½ a** | ¼ Aa (tím) | ¼ aa (trắng) |

→ F~2~: kiểu gene **1 AA : 2 Aa : 1 aa**; kiểu hình **3 tím : 1 trắng**.

**Vì sao lại là 3 : 1?** Vì hai sự kiện độc lập: giao tử đực mang A với xác suất ½, giao tử cái mang A với xác suất ½. Xác suất để cây con là aa = ½ × ½ = ¼. Còn lại ¾ có ít nhất một A → hoa tím (A **át hoàn toàn** a).

### 2.3. Các thuật ngữ cần dùng thành thạo

| Thuật ngữ | Nghĩa | Ví dụ |
|---|---|---|
| Gene | Đoạn DNA mang thông tin mã hoá một sản phẩm (RNA hoặc chuỗi polypeptide), qua đó quy định tính trạng; chính là "nhân tố di truyền" của Mendel | gene quy định màu hoa |
| Allele | Các phiên bản khác nhau của cùng một gene, nằm ở cùng locus | A (tím), a (trắng) |
| Kiểu gene | Tổ hợp các allele của cơ thể (về gene đang xét) | AA, Aa, aa |
| Kiểu hình | Đặc điểm biểu hiện ra bên ngoài | hoa tím, hoa trắng |
| Đồng hợp (thuần chủng) | Hai allele của cặp giống nhau | AA, aa |
| Dị hợp | Hai allele của cặp khác nhau | Aa |
| Trội hoàn toàn | Allele trội át hẳn allele lặn: Aa có kiểu hình giống AA | Aa → tím như AA |

> [!bay]
> - "Thuần chủng" là **đồng hợp** — gồm cả AA **và** aa. Cây hoa trắng (aa) cũng là thuần chủng!
> - Kiểu hình trội (tím) có thể là AA **hoặc** Aa — nhìn bề ngoài không phân biệt được. Muốn biết phải lai phân tích (mục 2.4).
> - Trong số cây tím F~2~, cây thuần chủng chiếm **1/3** chứ không phải 1/4 (1/4 là tính trên **toàn bộ** F~2~).

### 2.4. Kiểm chứng giả thuyết — phép lai phân tích

Mendel dự đoán: nếu F~1~ thật sự cho ½A : ½a, thì khi lai F~1~ với cây **đồng hợp lặn** aa (chỉ cho giao tử a), đời con phải là ½ tím : ½ trắng.

=> Aa × aa → 1 Aa (tím) : 1 aa (trắng)

Kết quả thực tế khớp đúng dự đoán, và lặp lại với 6 tính trạng khác. Giả thuyết được xác nhận.

**Lai phân tích** là phép lai giữa cá thể mang **kiểu hình trội** (chưa biết kiểu gene) với cá thể mang **kiểu hình lặn** (chắc chắn đồng hợp lặn). Vì cây lặn chỉ cho một loại giao tử mang allele lặn, nên **kiểu hình đời con phản ánh trực tiếp các loại giao tử** của cây trội:

| Kết quả lai phân tích | Kết luận về cây trội |
|---|---|
| 100% trội | đồng hợp AA (thuần chủng) |
| 1 trội : 1 lặn | dị hợp Aa |

> [!ung-dung]
> Nhà chọn giống muốn biết một con bò đực giống (kiểu hình trội) có thuần chủng không trước khi dùng để nhân giống đàn: cho nó giao phối với nhiều con cái mang tính trạng lặn. Nếu đời con xuất hiện con mang tính trạng lặn → con đực dị hợp, không dùng làm giống thuần. Ở cây tự thụ phấn được, có thể cho **tự thụ phấn**: cây thuần chủng cho đời con đồng nhất.

### 2.5. Quy luật phân li và cơ sở tế bào học

**Quy luật phân li** (diễn đạt theo ngôn ngữ hiện đại): *Mỗi tính trạng do một cặp allele quy định, một có nguồn gốc từ bố, một từ mẹ; chúng tồn tại riêng rẽ, không pha trộn. Khi hình thành giao tử, hai allele của cặp phân li đồng đều về các giao tử, nên mỗi giao tử chỉ chứa một allele.*

Vì sao lại như vậy? Vì **gene nằm trên NST**. Cặp allele A, a nằm ở cùng một locus trên **cặp NST tương đồng**:

![Hình 1. Cơ sở tế bào học của quy luật phân li: cặp allele A, a phân li theo cặp NST tương đồng trong giảm phân](hinh-1-phan-li.svg)

- Kì trung gian: mỗi NST nhân đôi thành 2 chromatid → A nhân đôi thành 2 bản A, a thành 2 bản a.
- Giảm phân I: hai chiếc NST của cặp tương đồng **tách nhau** → một tế bào nhận A A, tế bào kia nhận a a.
- Giảm phân II: hai chromatid tách nhau → 4 giao tử: **2 mang A, 2 mang a**, tức ½A : ½a.

Như vậy, "sự phân li của cặp nhân tố di truyền" mà Mendel suy ra từ con số **chính là sự phân li của cặp NST tương đồng trong giảm phân**. Thụ tinh ngẫu nhiên giữa các giao tử khôi phục lại cặp allele ở hợp tử.

**Ba quá trình nối tiếp nhau thành một vòng:** hợp tử Aa → **nguyên phân** nhiều lần tạo cơ thể, mọi tế bào (kể cả tế bào sinh giao tử) đều mang đúng cặp Aa như hợp tử → **giảm phân** tách cặp Aa, mỗi giao tử nhận một allele → **thụ tinh** ghép hai giao tử, tạo lại cặp allele ở thế hệ sau. Nhờ vậy cặp allele được truyền nguyên vẹn qua các thế hệ.

> [!vi-du] Ví dụ 1
> Ở đậu hà lan, allele B quy định hạt trơn trội hoàn toàn so với b quy định hạt nhăn. Cho cây hạt trơn F~1~ (Bb) tự thụ phấn được F~2~. Chọn ngẫu nhiên một hạt trơn ở F~2~ đem gieo rồi cho cây đó lai phân tích. Tính xác suất để đời con xuất hiện hạt nhăn.

> [!goi-y] Gợi ý 1
> F~2~ có 1 BB : 2 Bb : 1 bb. Hạt trơn gồm những kiểu gene nào, mỗi loại chiếm bao nhiêu **trong số hạt trơn**?

> [!goi-y] Gợi ý 2
> Lai phân tích chỉ cho hạt nhăn khi cây đem lai là Bb. Khi đó, xác suất mỗi hạt con là nhăn bằng bao nhiêu? Đề hỏi "đời con **xuất hiện** hạt nhăn" — chỉ cần cây là Bb (với số hạt đủ nhiều).

> [!loi-giai] Lời giải
> Bước 1: Bb × Bb → F~2~: 1/4 BB : 2/4 Bb : 1/4 bb.
>
> Bước 2: Trong số hạt trơn (BB + Bb = 3/4): BB chiếm (1/4) : (3/4) = **1/3**, Bb chiếm **2/3**.
>
> Bước 3: BB × bb → 100% trơn (không có hạt nhăn); Bb × bb → 1 trơn : 1 nhăn (có hạt nhăn).
>
> Kết luận: xác suất đời con xuất hiện hạt nhăn = xác suất cây đó là Bb = **2/3**.

> [!vi-du] Ví dụ 2
> Cho toàn bộ cây F~2~ ở thí nghiệm màu hoa (1 AA : 2 Aa : 1 aa) tự thụ phấn. Tính tỉ lệ cây hoa trắng ở F~3~.

> [!goi-y] Gợi ý 1
> Mỗi nhóm kiểu gene tự thụ phấn riêng. Nhóm nào cho hoa trắng, với tỉ lệ bao nhiêu trong nhóm đó?

> [!goi-y] Gợi ý 2
> Nhân tỉ lệ của nhóm trong F~2~ với tỉ lệ hoa trắng mà nhóm đó sinh ra, rồi cộng lại.

> [!loi-giai] Lời giải
> - AA (chiếm 1/4) tự thụ → 0 hoa trắng.
> - Aa (chiếm 1/2) tự thụ → 1/4 hoa trắng → đóng góp 1/2 × 1/4 = 1/8.
> - aa (chiếm 1/4) tự thụ → 100% trắng → đóng góp 1/4.
>
> Tỉ lệ hoa trắng ở F~3~ = 1/8 + 1/4 = **3/8**, hoa tím = 5/8.

## 3. Thí nghiệm lai hai tính trạng — quy luật phân li độc lập

### 3.1. Thí nghiệm và kết quả

Mendel lai hai dòng thuần chủng khác nhau ở **hai** tính trạng: màu hạt và hình dạng hạt (SGK tr. 43). Trong bài này ta kí hiệu: **A** – hạt vàng, **a** – hạt xanh; **B** – vỏ trơn, **b** – vỏ nhăn. (SGK dùng chữ Y/y cho màu và R/r cho hình dạng — chỉ khác tên gọi, bản chất như nhau.)

- **P~tc~**: hạt vàng, trơn (AABB) × hạt xanh, nhăn (aabb).
- **F~1~**: 100% hạt vàng, trơn (AaBb).
- **F~2~** (F~1~ tự thụ phấn): 4 loại kiểu hình với tỉ lệ ≈ **9 vàng, trơn : 3 vàng, nhăn : 3 xanh, trơn : 1 xanh, nhăn**. (Số liệu của Mendel: 315 : 101 : 108 : 32 — tổng 556 hạt.)

Ở F~2~ xuất hiện hai kiểu hình **mới** không có ở P: vàng – nhăn và xanh – trơn. Đó là **biến dị tổ hợp** — do các tính trạng của bố và mẹ được "tổ hợp lại" theo cách mới.

**Mấu chốt — xét riêng từng tính trạng ở F~2~:**

- Màu hạt: vàng : xanh = (9 + 3) : (3 + 1) = **3 : 1**.
- Hình dạng: trơn : nhăn = (9 + 3) : (3 + 1) = **3 : 1**.

Và điều thú vị: (3 vàng : 1 xanh) × (3 trơn : 1 nhăn) = 9 vàng, trơn : 3 vàng, nhăn : 3 xanh, trơn : 1 xanh, nhăn — đúng tỉ lệ thu được!

$$\left(\tfrac34+\tfrac14\right)^2=\tfrac{9}{16}+\tfrac{3}{16}+\tfrac{3}{16}+\tfrac{1}{16}$$

Theo quy tắc nhân xác suất: **tỉ lệ một kiểu hình chung = tích tỉ lệ các tính trạng hợp thành nó** — chỉ đúng khi hai tính trạng di truyền **độc lập** với nhau. Đây chính là điều Mendel phát hiện ra.

### 3.2. Giải thích bằng giả thuyết và bảng Punnett

Mendel đề xuất: **các cặp nhân tố di truyền quy định các tính trạng khác nhau phân li độc lập với nhau khi tạo giao tử.**

Nghĩa là cây F~1~ AaBb: cặp Aa cho ½A : ½a, **đồng thời và độc lập** cặp Bb cho ½B : ½b. Ghép lại được 4 loại giao tử, mỗi loại ½ × ½ = ¼:

=> AaBb → ¼ AB : ¼ Ab : ¼ aB : ¼ ab

Thụ tinh ngẫu nhiên giữa 4 loại giao tử đực và 4 loại giao tử cái → **4 × 4 = 16 tổ hợp**, mỗi tổ hợp có xác suất 1/16:

![Hình 2. Bảng Punnett phép lai AaBb × AaBb: 16 tổ hợp, 9 kiểu gene, 4 kiểu hình theo tỉ lệ 9 : 3 : 3 : 1](hinh-2-punnett.svg)

Đếm trong bảng:

| Kiểu hình | Kiểu gene (số ô) | Tỉ lệ |
|---|---|---|
| Vàng, trơn (A-B-) | 1 AABB, 2 AABb, 2 AaBB, 4 AaBb | 9/16 |
| Vàng, nhăn (A-bb) | 1 AAbb, 2 Aabb | 3/16 |
| Xanh, trơn (aaB-) | 1 aaBB, 2 aaBb | 3/16 |
| Xanh, nhăn (aabb) | 1 aabb | 1/16 |

→ F~2~ có **9 kiểu gene** (= 3 × 3) và **4 kiểu hình** (= 2 × 2).

> [!meo] Không cần kẻ bảng 16 ô
> Tách từng cặp rồi nhân: Aa × Aa → (1AA : 2Aa : 1aa); Bb × Bb → (1BB : 2Bb : 1bb).
> Ví dụ tỉ lệ kiểu gene AaBb = 2/4 × 2/4 = 4/16 = 1/4; tỉ lệ AAbb = 1/4 × 1/4 = 1/16.
> Kí hiệu "A-" nghĩa là "AA hoặc Aa" (kiểu hình trội), tỉ lệ 3/4.

**Kiểm chứng** — lai phân tích F~1~:

=> AaBb × aabb → 1 AaBb : 1 Aabb : 1 aaBb : 1 aabb

tức **1 vàng, trơn : 1 vàng, nhăn : 1 xanh, trơn : 1 xanh, nhăn**. Kết quả thực tế đúng như vậy → F~1~ thật sự tạo 4 loại giao tử với tỉ lệ bằng nhau.

### 3.3. Quy luật phân li độc lập và cơ sở tế bào học

**Quy luật phân li độc lập:** *Các cặp allele quy định các tính trạng khác nhau phân li độc lập với nhau trong quá trình hình thành giao tử.*

**Vì sao chúng "độc lập"?** Vì cặp A, a và cặp B, b nằm trên **hai cặp NST tương đồng khác nhau**. Ở kì giữa giảm phân I, các cặp NST tương đồng xếp thành hai hàng trên mặt phẳng xích đạo, và **mỗi cặp tự xoay hướng một cách ngẫu nhiên**, không phụ thuộc cặp kia:

![Hình 3. Cơ sở tế bào học của quy luật phân li độc lập: hai cách sắp xếp ngẫu nhiên của hai cặp NST ở kì giữa giảm phân I tạo 4 loại giao tử ngang nhau](hinh-3-phan-li-doc-lap.svg)

- Cách 1 (khoảng 50% số tế bào): A cùng phía với B → giao tử **AB** và **ab**.
- Cách 2 (khoảng 50% số tế bào): A cùng phía với b → giao tử **Ab** và **aB**.

Tính trên rất nhiều tế bào sinh giao tử → 4 loại giao tử, mỗi loại ¼. Sau đó **thụ tinh ngẫu nhiên** tạo ra 16 tổ hợp.

> [!ghi-nho] Điều kiện để các cặp gene phân li độc lập
> - Mỗi cặp gene nằm trên **một cặp NST tương đồng riêng** (khác nhau).
> - Giảm phân diễn ra bình thường; các giao tử và hợp tử có sức sống ngang nhau; số cá thể đủ lớn (để tỉ lệ thực tế gần tỉ lệ lí thuyết).
>
> Thêm điều kiện để có tỉ lệ kiểu hình 3 : 1, 9 : 3 : 3 : 1: mỗi gene quy định một tính trạng và trội hoàn toàn.

> [!bay]
> Hai gene nằm trên **cùng một** NST thì **không** phân li độc lập (chúng có xu hướng đi cùng nhau — em sẽ học ở bài liên kết gene). Đề thi hay cài ý "phân li độc lập xảy ra với mọi cặp gene" — **sai**.

### 3.4. Mở rộng cho n cặp gene dị hợp phân li độc lập

Mỗi cặp dị hợp Aa đóng góp: 2 loại giao tử; khi tự thụ (Aa × Aa) cho 3 kiểu gene, 2 kiểu hình (3 : 1). Có **n cặp** dị hợp phân li độc lập thì **nhân lên n lần**:

| Đại lượng (cơ thể dị hợp n cặp; tự thụ phấn) | Công thức | n = 1 | n = 2 | n = 3 |
|---|---|---|---|---|
| Số loại giao tử | 2^n^ | 2 | 4 | 8 |
| Số tổ hợp giao tử ở đời con | 4^n^ | 4 | 16 | 64 |
| Số loại kiểu gene | 3^n^ | 3 | 9 | 27 |
| Số loại kiểu hình (trội hoàn toàn) | 2^n^ | 2 | 4 | 8 |
| Tỉ lệ phân li kiểu hình | (3 : 1)^n^ | 3 : 1 | 9 : 3 : 3 : 1 | 27 : 9 : 9 : 9 : 3 : 3 : 3 : 1 |

> [!vi-du] Ví dụ 3
> Một cơ thể có kiểu gene AaBBDd giảm phân bình thường, các cặp gene phân li độc lập. Cơ thể này tạo ra bao nhiêu loại giao tử? Tỉ lệ giao tử aBd là bao nhiêu?

> [!goi-y] Gợi ý 1
> Cặp đồng hợp BB chỉ cho **một** loại giao tử. Chỉ cặp dị hợp mới "nhân đôi" số loại giao tử.

> [!goi-y] Gợi ý 2
> Tỉ lệ một loại giao tử = tích tỉ lệ từng allele trong giao tử đó: a (từ Aa), B (từ BB), d (từ Dd).

> [!loi-giai] Lời giải
> Bước 1: Số cặp dị hợp: Aa và Dd → 2 cặp → số loại giao tử = 2^2^ = **4** (ABD, ABd, aBD, aBd).
>
> Bước 2: Tỉ lệ aBd = ½ (a) × 1 (B) × ½ (d) = **1/4**.

> [!bay]
> Công thức 2^n^ chỉ đếm **cặp dị hợp**. AaBBDd có 3 cặp gene nhưng chỉ 2 cặp dị hợp → 4 loại giao tử, không phải 8.

## 4. Ý nghĩa của học thuyết Mendel

**Vì sao Mendel được coi là "cha đẻ" của di truyền học hiện đại?**

- Ông chứng minh vật chất di truyền là **các đơn vị riêng rẽ** (nhân tố di truyền), truyền nguyên vẹn qua các thế hệ — nay ta biết đó là **gene**, các phiên bản là **allele**, nằm trên NST và có bản chất là DNA.
- Các nghiên cứu sau này về NST, giảm phân, DNA đều **khẳng định** hai ý cốt lõi của ông: mỗi tính trạng do một cặp nhân tố quy định, mỗi giao tử chỉ nhận một nhân tố của cặp; các cặp nhân tố phân li độc lập khi tạo giao tử.
- Ông đưa **phương pháp định lượng** (thống kê, xác suất) và **phương pháp thực nghiệm** (giả thuyết → dự đoán → kiểm chứng) vào sinh học.

**Ý nghĩa thực tiễn:**

- Quy luật phân li độc lập giải thích vì sao sinh sản hữu tính tạo ra **vô số biến dị tổ hợp** (với n cặp gene dị hợp có thể tạo 2^n^ loại giao tử) → nguồn nguyên liệu cho tiến hóa và chọn giống.
- Trong **chọn giống**: lai các giống rồi chọn tổ hợp gene mong muốn (ví dụ giống lúa vừa năng suất cao vừa kháng bệnh); dùng lai phân tích hoặc tự thụ phấn để kiểm tra độ thuần chủng.
- Trong **y học**: dự đoán xác suất sinh con mắc bệnh di truyền do gene lặn (bạch tạng, phenylketonuria…) để tư vấn di truyền.

> [!ung-dung]
> Bệnh bạch tạng ở người do allele lặn trên NST thường. Hai vợ chồng đều bình thường nhưng cùng mang allele bệnh (Aa) thì **mỗi lần sinh**, xác suất con bị bệnh là 1/4 — không phải "cứ 4 đứa thì có đúng 1 đứa bệnh". Mỗi lần sinh là một sự kiện độc lập.

> [!em-co-biet]
> Nếu lai hoa đỏ thuần chủng với hoa trắng thuần chủng mà F~1~ toàn hoa hồng, nhiều người nghĩ "đúng là pha trộn rồi!". Nhưng nếu cho F~1~ hồng tự thụ, F~2~ lại xuất hiện cả hoa đỏ và hoa trắng y như P (tỉ lệ 1 đỏ : 2 hồng : 1 trắng) → các allele vẫn **không hòa lẫn**, chỉ là allele đỏ **trội không hoàn toàn**. Em sẽ học kĩ ở Bài 9.

## Dạng bài thi hay gặp

> [!ghi-nho] Chìa khóa chung: TÁCH RIÊNG – TÍNH RIÊNG – NHÂN LẠI
> Khi các cặp gene phân li độc lập: tách phép lai thành từng cặp gene, tính tỉ lệ cho từng cặp, rồi **nhân** các tỉ lệ (và **cộng** các trường hợp loại trừ nhau).
>
> | Phép lai một cặp | Kiểu gene đời con | Kiểu hình (trội hoàn toàn) |
> |---|---|---|
> | AA × AA, AA × aa, aa × aa | 1 loại | 100% một kiểu |
> | AA × Aa | 1 AA : 1 Aa | 100% trội |
> | Aa × Aa | 1 AA : 2 Aa : 1 aa | 3 trội : 1 lặn |
> | Aa × aa | 1 Aa : 1 aa | 1 trội : 1 lặn |

### Dạng 1. Tính tỉ lệ giao tử, kiểu gene, kiểu hình ở đời con

*Nhận biết:* cho kiểu gene của P (có thể 3–4 cặp gene), hỏi số loại / tỉ lệ một loại giao tử, kiểu gene, kiểu hình.

*Phương pháp:*
1. Viết riêng từng cặp: ví dụ AaBbDd × AaBbdd → (Aa × Aa)(Bb × Bb)(Dd × dd).
2. Mỗi cặp: tìm số kiểu gene, số kiểu hình, tỉ lệ cần thiết (dùng bảng trên).
3. Số loại = **tích** số loại của từng cặp; tỉ lệ = **tích** tỉ lệ của từng cặp.

> [!vi-du] Ví dụ 4
> Cho phép lai P: AaBbDd × AaBbdd. Biết mỗi gene quy định một tính trạng, trội hoàn toàn, các cặp gene phân li độc lập. Hãy xác định: a) số loại kiểu gene và kiểu hình ở đời con; b) tỉ lệ kiểu gene AaBbDd; c) tỉ lệ kiểu hình trội cả ba tính trạng.

> [!goi-y] Gợi ý 1
> Tách thành (Aa × Aa), (Bb × Bb), (Dd × dd). Cặp Dd × dd cho mấy kiểu gene, mấy kiểu hình?

> [!goi-y] Gợi ý 2
> Aa × Aa: 3 kiểu gene, 2 kiểu hình; Aa chiếm 1/2; A- chiếm 3/4. Dd × dd: 2 kiểu gene, 2 kiểu hình; Dd chiếm 1/2; D- chiếm 1/2.

> [!loi-giai] Lời giải
> a) Số kiểu gene = 3 × 3 × 2 = **18**; số kiểu hình = 2 × 2 × 2 = **8**.
>
> b) AaBbDd = ½ × ½ × ½ = **1/8**.
>
> c) A-B-D- = ¾ × ¾ × ½ = **9/32**.

*Bẫy:* quên rằng cặp Dd × dd chỉ cho **2** kiểu gene (không phải 3); nhầm "số loại giao tử" với "số kiểu gene".

### Dạng 2. Tìm kiểu gene của P từ tỉ lệ đời con

*Nhận biết:* cho tỉ lệ kiểu hình đời con (dạng 3 : 3 : 1 : 1, 1 : 1 : 1 : 1, 37,5% : 12,5%…), hỏi kiểu gene của bố mẹ.

*Phương pháp:*
1. Xét **riêng từng tính trạng** ở đời con, tính tỉ lệ trội : lặn.
2. Suy ra phép lai của từng cặp: 3 : 1 → Aa × Aa; 1 : 1 → Aa × aa; 100% trội → ít nhất một bên là AA (AA × AA, AA × Aa hoặc AA × aa); 100% lặn → aa × aa.
3. Kiểm tra lại: tích các tỉ lệ riêng có bằng tỉ lệ chung không (để chắc chắn phân li độc lập), rồi ghép kiểu gene P.

| Tỉ lệ kiểu hình chung | Tách thành | Phép lai P thường gặp |
|---|---|---|
| 9 : 3 : 3 : 1 | (3 : 1)(3 : 1) | AaBb × AaBb |
| 3 : 3 : 1 : 1 | (3 : 1)(1 : 1) | AaBb × Aabb hoặc AaBb × aaBb |
| 1 : 1 : 1 : 1 | (1 : 1)(1 : 1) | AaBb × aabb hoặc Aabb × aaBb |
| 3 : 1 | (3 : 1)(100% trội) | ví dụ AaBB × AaBB hoặc AaBb × AaBB |

> [!vi-du] Ví dụ 5
> Ở cà chua, A – quả đỏ trội hoàn toàn so với a – quả vàng; B – thân cao trội hoàn toàn so với b – thân thấp; hai cặp gene phân li độc lập. Cho cây quả đỏ, thân cao (cây X) lai với cây Y thu được đời con: 37,5% đỏ, cao : 37,5% đỏ, thấp : 12,5% vàng, cao : 12,5% vàng, thấp. Tìm kiểu gene của X và Y.

> [!goi-y] Gợi ý 1
> Đổi ra tỉ lệ số nguyên: 37,5 : 37,5 : 12,5 : 12,5 = 3 : 3 : 1 : 1. Bây giờ xét riêng màu quả, rồi riêng chiều cao.

> [!goi-y] Gợi ý 2
> Màu quả: đỏ : vàng = 75% : 25% = 3 : 1. Chiều cao: cao : thấp = 50% : 50% = 1 : 1. Mỗi tỉ lệ ứng với phép lai nào?

> [!loi-giai] Lời giải
> Bước 1: Màu quả 3 đỏ : 1 vàng → Aa × Aa.
>
> Bước 2: Chiều cao 1 cao : 1 thấp → Bb × bb.
>
> Bước 3: Kiểm tra: (3 : 1)(1 : 1) = 3 : 3 : 1 : 1 — khớp, đúng là phân li độc lập.
>
> Bước 4: X có kiểu hình đỏ, cao nên X mang cả A và B → X là **AaBb**; khi đó Y là **Aabb** (quả đỏ, thân thấp).

*Bẫy:* quên dùng **kiểu hình của P** để chọn cách ghép. Ở ví dụ này cách ghép là duy nhất, nhưng với (Aa × aa)(Bb × bb) có hai cách: AaBb × aabb hoặc Aabb × aaBb — khi đó phải dựa vào kiểu hình P để chọn; nếu đề không cho kiểu hình P thì phải liệt kê đủ cả hai khả năng.

### Dạng 3. Xác suất trong di truyền (gia đình, chọn cá thể)

*Nhận biết:* "xác suất sinh con…", "lấy ngẫu nhiên một cây… xác suất…", thường ở bệnh di truyền người do gene lặn trên NST thường.

*Phương pháp:*
1. Xác định kiểu gene **có thể có** của bố, mẹ và **xác suất** của từng khả năng. Người bình thường có bố mẹ bình thường nhưng anh/chị/em ruột bị bệnh → bố mẹ đều Aa → người đó là **1/3 AA : 2/3 Aa** (vì đã biết người đó không bị bệnh).
2. Xác suất cần tìm = (xác suất bố mẹ có kiểu gene phù hợp) × (xác suất sinh con như đề hỏi).
3. Con trai/con gái: nhân thêm ½. Nhiều con: mỗi lần sinh độc lập → nhân; nếu không quy định thứ tự → nhân thêm số cách sắp xếp.

> [!vi-du] Ví dụ 6
> Bệnh bạch tạng do allele lặn a trên NST thường quy định. Người chồng bị bạch tạng. Người vợ bình thường, có bố mẹ bình thường nhưng em trai bị bạch tạng. Tính xác suất cặp vợ chồng này sinh con đầu lòng bị bạch tạng.

> [!goi-y] Gợi ý 1
> Chồng chắc chắn là aa. Bố mẹ của vợ bình thường mà sinh con bị bệnh → bố mẹ vợ có kiểu gene gì?

> [!goi-y] Gợi ý 2
> Vợ bình thường nên vợ thuộc nhóm (AA hoặc Aa) của phép lai Aa × Aa: tỉ lệ 1/3 AA : 2/3 Aa. Chỉ khi vợ là Aa mới có thể sinh con aa.

> [!loi-giai] Lời giải
> Bước 1: Bố mẹ vợ đều Aa → vợ (bình thường) có xác suất là Aa bằng 2/3.
>
> Bước 2: Nếu vợ là Aa: aa × Aa → ½ aa. Nếu vợ là AA: không thể sinh con bệnh.
>
> Bước 3: Xác suất con đầu lòng bị bạch tạng = 2/3 × 1/2 = **1/3**.

*Bẫy:* lấy xác suất vợ mang allele bệnh là 1/2 hoặc 3/4 (sai). Phải loại kiểu gene aa vì đã biết vợ bình thường → 2/3.

### Dạng 4. Bài nhiều cặp gene: đếm theo số tính trạng trội / số cặp dị hợp

*Nhận biết:* "tỉ lệ cá thể mang **k** tính trạng trội", "tỉ lệ kiểu gene có **k** cặp dị hợp" ở phép lai có nhiều cặp gene dị hợp.

*Phương pháp:* với n cặp gene, mỗi cặp có xác suất p cho "trường hợp được chọn" và 1 − p cho trường hợp còn lại. Chọn ra k cặp trong n cặp có $C_n^k$ cách:

$$P = C_n^k \cdot p^k (1-p)^{n-k}$$

- AaBbDd… tự thụ, k tính trạng **trội**: p = 3/4.
- AaBbDd… tự thụ, k cặp **dị hợp**: p = 1/2 (vì Aa chiếm 1/2 ở Aa × Aa).

> [!vi-du] Ví dụ 7
> Cho cơ thể AaBbDdEe tự thụ phấn; mỗi gene quy định một tính trạng, trội hoàn toàn, các cặp gene phân li độc lập. Tính tỉ lệ đời con có kiểu hình mang đúng 3 tính trạng trội và 1 tính trạng lặn.

> [!goi-y] Gợi ý 1
> Mỗi cặp Aa × Aa: tỉ lệ trội 3/4, lặn 1/4. Tính trạng lặn có thể rơi vào cặp nào trong 4 cặp?

> [!goi-y] Gợi ý 2
> Có 4 cách chọn tính trạng lặn ($C_4^1 = 4$). Mỗi cách có xác suất (3/4)^3^ × (1/4).

> [!loi-giai] Lời giải
> $P = C_4^3\cdot\left(\tfrac34\right)^3\cdot\tfrac14 = 4\cdot\tfrac{27}{64}\cdot\tfrac14 = \tfrac{27}{64}\approx 0{,}42$.

*Bẫy:* quên nhân với số cách chọn $C_n^k$ — chỉ tính (3/4)^3^ × 1/4 = 27/256 là sai.

> [!meo] Bấm máy Casio fx-580VN X
> Dùng phím **nCr**: gõ `4` `SHIFT` `÷` (nCr) `3` × (3 ÷ 4)^3^ × (1 ÷ 4) = 0,421875. Máy cho phân số luôn nếu em bấm `S⇔D`: 27/64.

## Tóm tắt

| | Lai một tính trạng | Lai hai tính trạng |
|---|---|---|
| P thuần chủng | AA × aa | AABB × aabb |
| F~1~ | 100% Aa (trội) | 100% AaBb (trội cả hai) |
| Giao tử F~1~ | ½A : ½a | ¼AB : ¼Ab : ¼aB : ¼ab |
| F~2~ kiểu gene | 1 : 2 : 1 (3 loại) | (1 : 2 : 1)^2^ (9 loại) |
| F~2~ kiểu hình | 3 : 1 | 9 : 3 : 3 : 1 = (3 : 1)^2^ |
| Lai phân tích F~1~ | 1 : 1 | 1 : 1 : 1 : 1 |
| Quy luật | Phân li: mỗi giao tử chỉ chứa một allele của cặp | Phân li độc lập: các cặp allele phân li độc lập khi tạo giao tử |
| Cơ sở tế bào học | Phân li của cặp NST tương đồng ở giảm phân I | Các cặp NST tương đồng xếp và phân li ngẫu nhiên, độc lập ở giảm phân I; thụ tinh ngẫu nhiên |
| Điều kiện | — | Các cặp gene nằm trên các cặp NST tương đồng khác nhau |

**Công thức nhanh** (n cặp gene dị hợp, phân li độc lập, trội hoàn toàn, tự thụ phấn): giao tử 2^n^ loại · kiểu gene 3^n^ loại · kiểu hình 2^n^ loại · tỉ lệ kiểu hình (3 : 1)^n^ · tỉ lệ k tính trạng trội $C_n^k\left(\tfrac34\right)^k\left(\tfrac14\right)^{n-k}$.

**Phương pháp Mendel:** dòng thuần → lai → theo dõi từng tính trạng qua nhiều thế hệ → thống kê → giả thuyết → lai kiểm nghiệm.
