---
title: Cấu trúc và chức năng của nhiễm sắc thể
thoi-gian: 40 phút
muc-tieu:
  - Mô tả được hình thái NST (tâm động, đầu mút, vai, NST đơn – NST kép gồm hai chromatid) và phân biệt bộ NST lưỡng bội – đơn bội, NST thường – NST giới tính.
  - Dựa vào sơ đồ, trình bày được cấu trúc siêu hiển vi của NST qua kì trung gian, kì đầu và kì giữa (sợi DNA 2 nm → chuỗi nucleosome 10 nm → các vòng sợi gắn trên khung NST → chromatid khoảng 700 nm).
  - Giải thích được vì sao NST dãn xoắn ở kì trung gian và co xoắn cực đại ở kì giữa.
  - Trình bày được NST là vật chất di truyền: gene nằm kế tiếp nhau trên NST, mỗi gene ở một vị trí xác định gọi là locus; các allele ở cùng locus trên cặp NST tương đồng.
  - Giải thích được vai trò của nguyên phân, giảm phân và thụ tinh trong việc truyền đạt thông tin di truyền qua các thế hệ tế bào và cơ thể; thấy được sự vận động của NST là cơ sở của các quy luật di truyền, biến dị tổ hợp và biến dị số lượng NST.
  - Giải được các dạng bài: đếm số NST, chromatid, tâm động qua các kì phân bào; tính số nucleosome, chiều dài DNA, số phân tử histone; tính số NST môi trường cung cấp khi nguyên phân.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Ở sinh vật nhân thực, NST được tạo bởi **DNA + protein histone**. Đơn vị cơ bản là **nucleosome**: một đoạn DNA quấn quanh khối protein histone.
> 2. **Kì trung gian**: NST là **chuỗi nucleosome** đường kính khoảng **10 nm** (phân tử DNA chỉ khoảng 2 nm). Vùng nucleosome xếp sát nhau là **dị nhiễm sắc**, vùng xếp thưa là **nguyên nhiễm sắc** (gene đang hoạt động).
> 3. **Kì đầu**: protein **condensin** tạo **khung NST**, sợi 10 nm cuộn thành các vòng gắn vào khung; **kì giữa**: co xoắn **cực đại**, mỗi chromatid dày khoảng **700 nm**.
> 4. NST **mang** gene: mỗi gene ở một vị trí xác định gọi là **locus**; ngoài gene còn có trình tự **tâm động** (gắn thoi phân bào) và **đầu mút** (bảo vệ NST).
> 5. NST **truyền đạt** thông tin di truyền: nguyên phân giữ nguyên bộ NST qua các thế hệ tế bào; giảm phân + thụ tinh giữ bộ NST qua các thế hệ cơ thể và tạo **tổ hợp gene mới**.

> [!nen-tang] Nhớ lại từ lớp 10: nguyên phân và giảm phân
> - **Kì trung gian** (trước khi phân bào): DNA nhân đôi → mỗi NST thành **NST kép** gồm **2 chromatid** (nhiễm sắc tử) giống hệt nhau, dính nhau ở **tâm động**.
> - **Nguyên phân** (tế bào sinh dưỡng, tế bào sinh dục sơ khai): NST nhân đôi 1 lần, tế bào chia 1 lần. Kì giữa: các NST kép xếp **một hàng** ở mặt phẳng xích đạo; kì sau: hai chromatid của mỗi NST kép tách nhau ở tâm động → 2 NST đơn đi về hai cực. Kết quả: 1 tế bào 2n → **2 tế bào 2n** giống hệt tế bào mẹ.
> - **Giảm phân** (tế bào sinh dục chín): NST nhân đôi 1 lần, tế bào chia **2 lần**. Kì đầu I: các NST kép tương đồng tiếp hợp, có thể **trao đổi chéo**. Kì giữa I: xếp **hai hàng**. Kì sau I: mỗi NST **kép** của cặp tương đồng đi về một cực (tâm động **chưa** tách). Giảm phân II diễn ra như nguyên phân: hai chromatid tách nhau. Kết quả: 1 tế bào 2n → **4 tế bào n**.
> - **Thụ tinh**: giao tử n + giao tử n → hợp tử 2n.
>
> Bài 8 (học thuyết Mendel) sẽ dùng chính các bước này để giải thích tỉ lệ 3 : 1 và 9 : 3 : 3 : 1, nên em cần nắm chắc ngay từ bài này.

**Câu hỏi mở bài.** Tổng chiều dài 46 phân tử DNA trong một tế bào người vào khoảng **2 m**, trong khi nhân tế bào chỉ rộng vài micromet (1 µm = một phần triệu mét). Nếu nhân to bằng quả bóng đá thì sợi DNA dài cỡ… vài chục kilômét! Làm sao "cuộn" được ngần ấy DNA vào nhân mà các gene vẫn **đọc được** khi cần? Câu trả lời nằm ở cấu trúc của NST.

## 1. Cấu trúc siêu hiển vi của nhiễm sắc thể

### 1.1. NST là gì? Hình thái NST

**Nhiễm sắc thể** (NST) là cấu trúc nằm trong nhân tế bào, **bắt màu đậm** với những thuốc nhuộm đặc hiệu cho DNA — vì thế mới có tên "nhiễm sắc thể" (thể bắt màu).

Dưới **kính hiển vi quang học**, hình thái NST thấy **rõ nhất ở kì giữa** của phân bào, vì lúc này NST co xoắn tối đa (dày, ngắn, tách rời nhau). Một NST kép ở kì giữa có các phần:

![Hình 1. Hình thái NST kép ở kì giữa và ba dạng NST theo vị trí tâm động](hinh-1-hinh-thai.svg)

| Bộ phận | Đặc điểm | Vai trò |
|---|---|---|
| **Tâm động** | Chỗ "thắt eo" của NST | Nơi NST **gắn với thoi phân bào** → NST di chuyển về các cực khi phân bào |
| **Đầu mút** | Hai đầu tận cùng của NST | **Bảo vệ** NST, giúp các NST không dính vào nhau |
| **Vai (cánh)** | Phần NST hai bên tâm động | Chứa phần lớn các gene |
| **Chromatid** (nhiễm sắc tử) | Hai "nửa" giống hệt nhau của NST kép, dính nhau ở tâm động | Mỗi chromatid chứa **một phân tử DNA**; khi tâm động tách (kì sau nguyên phân, kì sau II), hai chromatid tách nhau đi về hai tế bào con |

Tùy **vị trí tâm động**, NST ở kì giữa có dạng **tâm giữa** (hai vai dài bằng nhau), **tâm lệch** (một vai dài, một vai ngắn) hoặc **tâm mút** (tâm động nằm sát một đầu, một vai rất ngắn).

**NST đơn và NST kép — phân biệt thật kĩ:**

- **NST đơn**: chỉ gồm 1 chromatid ↔ chứa **1 phân tử DNA**. Có ở kì trung gian **trước** khi DNA nhân đôi (pha G~1~), ở kì sau và kì cuối của nguyên phân, kì sau II và kì cuối II của giảm phân.
- **NST kép**: gồm **2 chromatid** dính nhau ở tâm động ↔ chứa **2 phân tử DNA** giống hệt nhau. Có từ khi DNA nhân đôi xong (cuối kì trung gian) đến hết kì giữa nguyên phân; trong giảm phân thì kéo dài đến hết kì giữa II.

> [!meo] Đếm "đầu người" bằng tâm động
> Muốn biết tế bào có bao nhiêu NST, hãy **đếm tâm động**: mỗi NST (đơn hay kép) có đúng **một** tâm động. Số chromatid chỉ khác 0 khi NST ở trạng thái kép, và bằng **2 × số NST kép**.

### 1.2. Bộ NST của loài

Mỗi loài có một **bộ NST đặc trưng** về số lượng, hình thái và cấu trúc.

- Trong tế bào sinh dưỡng (tế bào xôma), NST tồn tại thành **từng cặp tương đồng**: hai chiếc giống nhau về hình dạng, kích thước và trình tự các gene, **một chiếc có nguồn gốc từ bố, một chiếc từ mẹ**. Bộ NST gồm các cặp tương đồng gọi là **bộ lưỡng bội (2n)**.
- Giao tử chỉ chứa **một chiếc** của mỗi cặp: **bộ đơn bội (n)**.
- **NST thường**: các cặp giống nhau ở hai giới. **NST giới tính**: cặp khác nhau giữa hai giới, mang gene xác định giới tính (ví dụ ở người: nữ XX, nam XY — em sẽ học kĩ ở Bài 10).

| Loài | 2n | n |
|---|---|---|
| Người | 46 (22 cặp NST thường + 1 cặp NST giới tính) | 23 |
| Ruồi giấm | 8 | 4 |
| Đậu hà lan | 14 | 7 |
| Lúa nước | 24 | 12 |
| Ngô | 20 | 10 |

> [!bay]
> - Số lượng NST **không** phản ánh mức độ tiến hóa: tinh tinh có 2n = 48, nhiều hơn người (2n = 46). Cái làm nên sự khác biệt là **gene** trên NST.
> - "Cặp NST tương đồng" (một chiếc từ bố, một từ mẹ, có thể mang **allele khác nhau**) khác với "hai chromatid chị em" (sinh ra do nhân đôi, giống hệt nhau). Đề rất hay đánh tráo hai khái niệm này.

> [!em-co-biet] NST của sinh vật nhân sơ
> Vi khuẩn không có nhân hoàn chỉnh. "NST" của chúng thường chỉ là **một phân tử DNA mạch kép, dạng vòng**, nằm ở vùng nhân, **không** liên kết với histone thành nucleosome như ở sinh vật nhân thực. Vì vậy mọi nội dung về nucleosome, tâm động, khung NST… trong bài này là của **sinh vật nhân thực**.

> [!ung-dung] Bộ NST người (karyotype)
> Người ta nuôi tế bào bạch cầu, dừng phân bào ở kì giữa, nhuộm màu rồi chụp ảnh và **sắp xếp 23 cặp NST** theo kích thước, vị trí tâm động. Bảng xếp này gọi là **karyotype** (bộ NST). Nhìn vào karyotype, bác sĩ phát hiện được thừa/thiếu NST (ví dụ 3 chiếc NST số 21 trong hội chứng Down) — em sẽ gặp lại ở Bài 12 và Bài 13.

### 1.3. Kì trung gian: chuỗi nucleosome 10 nm

Bây giờ ta "phóng to" NST bằng **kính hiển vi điện tử** (SGK tr. 36–37, Hình 7.1). Đi từ nhỏ đến lớn:

1. **Phân tử DNA** mạch kép: đường kính khoảng **2 nm**.
2. DNA **quấn quanh** các khối protein **histone** tạo thành các hạt gọi là **nucleosome**. Giữa hai nucleosome liền kề là một đoạn **DNA nối**.
3. Các nucleosome nối tiếp nhau như **chuỗi hạt cườm** → **chuỗi nucleosome** (sợi nhiễm sắc) đường kính khoảng **10 nm**.

Ở kì trung gian, NST tồn tại chủ yếu dưới dạng chuỗi nucleosome 10 nm này, nhưng không đều nhau:

| | Dị nhiễm sắc | Nguyên nhiễm sắc |
|---|---|---|
| Cách xếp nucleosome | **Sát nhau**, đặc | **Cách xa nhau**, thưa |
| Gene | Không chứa gene (như vùng **tâm động, đầu mút**) hoặc chứa gene **bị bất hoạt** | Thường chứa các gene **đang hoạt động** |

**Vì sao NST phải dãn xoắn tối đa ở kì trung gian?** Đây là lúc tế bào "làm việc": DNA cần **nhân đôi**, gene cần **phiên mã** để tổng hợp protein. Muốn thế, các enzyme (DNA polymerase, RNA polymerase…) phải **tiếp cận được** mạch DNA. Nucleosome nằm thưa, tách rời nhau thì "chỗ trống" để enzyme bám vào nhiều hơn. Ngược lại, vùng nucleosome nén chặt (dị nhiễm sắc) thì enzyme khó chen vào → gene ở đó "im lặng".

> [!em-co-biet] Nucleosome bên trong có gì?
> SGK chỉ nói nucleosome gồm DNA và protein histone. Các đề thi và sách tham khảo thường cho thêm số liệu (đề sẽ nêu rõ khi cần dùng):
> - Lõi nucleosome là khối cầu gồm **8 phân tử histone**; đoạn DNA quấn quanh lõi khoảng **1¾ vòng**, dài khoảng **146 cặp nucleotide**.
> - Mỗi đoạn DNA nối thường gắn thêm **1 phân tử histone H1**.
> - Mỗi cặp nucleotide dài **0,34 nm** (= 3,4 Å) dọc theo trục DNA.
>
> Nhiều tài liệu cũ còn mô tả các mức "sợi 30 nm, sợi 300 nm". SGK Kết nối tri thức trình bày theo mô hình mới hơn: sợi 10 nm cuộn thành **vòng** gắn lên **khung protein**. Khi làm bài, em **ưu tiên số liệu theo SGK và theo dữ kiện của đề**.

### 1.4. Kì đầu: condensin dựng "khung", sợi 10 nm cuộn thành vòng

Khi tế bào bước vào phân bào, NST phải được **thu gọn** lại. SGK mô tả:

- Các protein nhỏ dạng **vòng** gọi là **condensin** (gồm **condensin II** và **condensin I**) liên kết với nhau tạo nên **khung NST** (bộ khung protein dọc theo NST).
- Sợi nhiễm sắc 10 nm **luồn qua các vòng condensin**, tạo thành rất nhiều **vòng nhỏ** chĩa ra phía ngoài khung — giống như sợi dây được gom lại thành từng **búi vòng** gắn dọc một que.
- Nhờ vậy **chiều dài NST giảm mạnh**, còn **chiều rộng tăng dần**.

### 1.5. Kì giữa: co xoắn cực đại, chromatid khoảng 700 nm

Toàn bộ khung NST (cùng các vòng sợi gắn trên nó) **tiếp tục xoắn lại và nén chặt**. Các vòng sợi 10 nm xếp **sát** nhau, nhô dài ra → NST **ngắn nhất, dày nhất** ở kì giữa: mỗi **chromatid** có đường kính khoảng **700 nm**.

![Hình 2. Các mức cấu trúc siêu hiển vi của NST ở sinh vật nhân thực (sơ đồ đơn giản hóa)](hinh-2-cau-truc.svg)

**Vì sao NST phải co xoắn cực đại ở kì giữa?** Ở kì sau, NST (hoặc chromatid) sẽ bị thoi phân bào **kéo về hai cực**. Nếu DNA vẫn là những sợi mảnh dài hàng centimet thì chúng sẽ **rối vào nhau và đứt gãy** khi bị kéo — giống như kéo hai cuộn len chưa quấn gọn. Co xoắn thành những "khối" gọn, chắc giúp NST **phân li đồng đều, chính xác** về các tế bào con. (Đây cũng là lí do kì giữa là lúc quan sát và đếm NST dễ nhất.)

> [!bay]
> - Đường kính **2 nm** là của **phân tử DNA**; **10 nm** là của **chuỗi nucleosome**; **700 nm** là của **một chromatid ở kì giữa**. Đề hay tráo các con số này.
> - Co xoắn cực đại xảy ra ở **kì giữa**, không phải kì đầu (kì đầu mới **bắt đầu** co xoắn).
> - Ở kì giữa, gene **hầu như không phiên mã** vì DNA bị nén quá chặt — đừng chọn phát biểu "ở kì giữa gene phiên mã mạnh nhất".

> [!vi-du] Ví dụ 1
> Hãy sắp xếp các cấu trúc sau theo thứ tự đường kính **tăng dần** và cho biết mỗi cấu trúc là dạng tồn tại chủ yếu của NST ở kì nào: (1) chromatid của NST kép; (2) phân tử DNA; (3) chuỗi nucleosome.

> [!goi-y] Gợi ý 1
> Nhớ ba con số của SGK: 2 nm, 10 nm, 700 nm. Cái nào là "nguyên liệu", cái nào là "thành phẩm" sau khi cuộn gọn?

> [!goi-y] Gợi ý 2
> Kì trung gian NST dãn xoắn (để gene làm việc); kì giữa co xoắn cực đại (để phân li).

> [!loi-giai] Lời giải
> Thứ tự tăng dần: **(2) DNA khoảng 2 nm → (3) chuỗi nucleosome khoảng 10 nm → (1) chromatid khoảng 700 nm**.
>
> - Chuỗi nucleosome 10 nm là dạng chủ yếu ở **kì trung gian**.
> - Chromatid 700 nm là dạng co xoắn cực đại ở **kì giữa**.
> - Phân tử DNA 2 nm là "sợi gốc" có ở mọi kì (luôn quấn quanh histone).

> [!vi-du] Ví dụ 2
> Một đoạn chuỗi nucleosome gồm **20 nucleosome**. Mỗi nucleosome có một đoạn DNA dài 146 cặp nucleotide quấn quanh lõi gồm 8 phân tử histone; giữa hai nucleosome liền kề có một đoạn DNA nối dài 50 cặp nucleotide, mỗi đoạn nối gắn 1 phân tử histone H1. Hai đầu của đoạn chuỗi đều là nucleosome. Tính: a) tổng số cặp nucleotide và chiều dài (µm) của đoạn DNA; b) tổng số phân tử histone.

> [!goi-y] Gợi ý 1
> 20 hạt xếp thành một hàng, hai đầu là hạt → có bao nhiêu **khoảng giữa** hai hạt liền kề? (Giống bài "trồng cây hai đầu đường".)

> [!goi-y] Gợi ý 2
> Chiều dài DNA = số cặp nucleotide × 0,34 nm; đổi 1 µm = 1000 nm.

> [!loi-giai] Lời giải
> Bước 1: Số đoạn nối = 20 − 1 = **19**.
>
> Bước 2: Tổng số cặp nucleotide = 20 × 146 + 19 × 50 = 2920 + 950 = **3870** cặp.
>
> Bước 3: Chiều dài = 3870 × 0,34 = 1315,8 nm ≈ **1,32 µm**.
>
> Bước 4: Số histone = 20 × 8 (lõi) + 19 × 1 (H1) = **179** phân tử.

## 2. Chức năng của nhiễm sắc thể

### 2.1. Mang thông tin di truyền — gene, locus, allele

Mỗi NST chứa **một phân tử DNA** rất dài (hai phân tử nếu là NST kép). Trên phân tử DNA đó có **nhiều gene nằm kế tiếp nhau** dọc theo chiều dài NST, giống các ngôi nhà nối tiếp nhau trên một con phố.

- **Locus**: **vị trí xác định** của một gene trên NST (như "số nhà" của gene).
- **Allele**: ở cùng một locus trên **cặp NST tương đồng**, hai chiếc NST có thể mang các trình tự nucleotide khác nhau của cùng một gene — đó là các **allele** của gene (ví dụ A và a).

![Hình 3. Vị trí các gene trên một cặp NST kép tương đồng: mỗi gene ở một locus; hai chromatid chị em mang allele giống nhau](hinh-3-locus.svg)

Nhìn Hình 3, em rút ra ba điều mà đề thi rất hay hỏi:

1. Ở locus A, chiếc NST bên trái mang **A**, chiếc bên phải mang **a** → cặp allele **dị hợp** Aa. Ở locus B cả hai chiếc đều mang **B** → đồng hợp BB.
2. **Hai chromatid chị em** của cùng một NST kép mang allele **giống hệt nhau** (A và A), vì chúng sinh ra do nhân đôi.
3. Các gene trên **cùng một NST** (ví dụ A, B, D) nằm theo một **trình tự** nhất định; chúng thường được di truyền **cùng nhau** (em sẽ học ở Bài 11).

**Không phải NST nào cũng "đông dân" như nhau.** Số lượng gene và cách phân bố gene trên các NST trong cùng một bộ **rất khác nhau**: có NST chứa nhiều gene xếp khá dày, có NST chứa ít gene và các gene nằm xa nhau.

**Ngoài gene, NST còn có các trình tự nucleotide đặc biệt:**

- Trình tự ở **đầu mút**: bảo vệ NST (không bị phân hủy, không dính vào NST khác).
- Trình tự **tâm động**: là nơi gắn với thoi phân bào, giúp NST **di chuyển** được khi tế bào phân chia.

Như vậy NST chính là **vật chất di truyền ở cấp độ tế bào**: nó chứa DNA mang gene, và bảo đảm DNA đó được phân chia chính xác.

> [!bay]
> "Gene" và "allele" không giống nhau: **gene** là đoạn DNA ở một locus (gene quy định màu hoa); **allele** là các **phiên bản** của gene đó (A – hoa tím, a – hoa trắng). Hai allele của một gene luôn ở **cùng locus** trên **hai chiếc** của cặp NST tương đồng — không bao giờ ở hai locus khác nhau.

### 2.2. Truyền đạt thông tin di truyền qua các thế hệ tế bào và cơ thể

Mang gene thôi chưa đủ — gene phải được **chép lại và chia đều** cho thế hệ sau. NST làm được điều này nhờ sự **vận động** của nó trong ba quá trình:

| Quá trình | NST làm gì | Ý nghĩa di truyền |
|---|---|---|
| **Nguyên phân** | Nhân đôi 1 lần, chia đều về 2 tế bào con | Các tế bào con có bộ NST **giống hệt** tế bào mẹ → thông tin di truyền được truyền **nguyên vẹn** qua các thế hệ tế bào. Ở loài sinh sản vô tính, đó cũng là cách truyền qua các thế hệ **cơ thể** |
| **Giảm phân** | Nhân đôi 1 lần, chia 2 lần; các cặp tương đồng **phân li**, các NST khác cặp **tổ hợp tự do**, có thể **trao đổi chéo** | Tạo giao tử mang bộ **n**, với **rất nhiều tổ hợp gene khác nhau** |
| **Thụ tinh** | Giao tử n + giao tử n | Khôi phục bộ **2n** đặc trưng của loài; các giao tử kết hợp ngẫu nhiên → thêm nhiều tổ hợp gene mới |

**Vì sao cơ thể đa bào cần bộ NST lưỡng bội?** Nhờ nguyên phân, **mọi tế bào cơ thể** đều có bộ NST 2n như nhau, tức là **mỗi gene có hai bản sao** (hai allele). Nếu một bản bị đột biến hỏng, bản còn lại thường vẫn hoạt động → đột biến **ít gây hại** cho cơ thể hơn.

**Vì sao con cái không giống hệt bố mẹ?** Gene được truyền **nguyên vẹn** (mỗi allele vẫn là chính nó), nhưng được **xáo trộn thành tổ hợp mới** qua giảm phân và thụ tinh. Nhờ đó các thế hệ sau đa dạng, có thể **thích nghi** với những điều kiện môi trường khác nhau.

> [!ghi-nho] Sự vận động của NST là "cơ sở" của các hiện tượng di truyền
> - **Tự nhân đôi** → mỗi tế bào con nhận đủ bộ gene.
> - **Phân li** của cặp NST tương đồng ở giảm phân I → mỗi giao tử chỉ nhận một allele của cặp → **quy luật phân li** (Bài 8).
> - **Tổ hợp tự do** của các cặp NST khác nhau → **quy luật phân li độc lập**, tạo **biến dị tổ hợp** (Bài 8).
> - **Trao đổi chéo** (tái tổ hợp) giữa các chromatid không chị em của cặp tương đồng → **hoán vị gene** (Bài 11).
> - Nếu NST **phân li không bình thường** → giao tử thừa hoặc thiếu NST → **biến dị số lượng NST** (Bài 12).

> [!vi-du] Ví dụ 3
> Một loài có bộ NST 2n = 6, kí hiệu ba cặp NST tương đồng là Aa, Bb, Dd (mỗi chữ là một chiếc NST). Giả sử giảm phân bình thường, không có trao đổi chéo. a) Cơ thể này tạo được tối đa bao nhiêu loại giao tử? Liệt kê. b) Một tế bào sinh tinh của cơ thể này tạo được tối đa bao nhiêu loại tinh trùng?

> [!goi-y] Gợi ý 1
> Mỗi cặp tương đồng cho giao tử nhận **một** trong hai chiếc. Ba cặp xếp hàng ở kì giữa I **độc lập** với nhau.

> [!goi-y] Gợi ý 2
> Một tế bào sinh tinh ở kì giữa I chỉ có **một** cách sắp xếp cụ thể. Một cách xếp cho ra bao nhiêu loại giao tử?

> [!loi-giai] Lời giải
> a) Mỗi cặp cho 2 khả năng, 3 cặp độc lập → 2^3^ = **8 loại**: ABD, ABd, AbD, Abd, aBD, aBd, abD, abd.
>
> b) Một tế bào sinh tinh có một cách xếp cố định ở kì giữa I, ví dụ (A B D | a b d) → sau giảm phân cho 4 tinh trùng thuộc **2 loại** (ABD và abd). Muốn có đủ 8 loại cần **nhiều** tế bào với các cách xếp khác nhau.
>
> Với người (n = 23), số loại giao tử do riêng tổ hợp tự do của NST đã là 2^23^ ≈ 8,4 triệu — đó là lí do anh chị em ruột (trừ sinh đôi cùng trứng) không giống hệt nhau.

## Dạng bài thi hay gặp

### Dạng 1. Đếm số NST, chromatid, tâm động, phân tử DNA qua các kì phân bào

*Nhận biết:* "Một tế bào (2n = …) đang ở kì … của nguyên phân/giảm phân. Có bao nhiêu NST / chromatid / tâm động…?" hoặc ngược lại: cho số đếm được, hỏi 2n hay kì phân bào.

*Phương pháp:*
1. Xác định NST đang **đơn hay kép** ở kì đó.
2. Số NST = **số tâm động**; số chromatid = 2 × số NST kép (NST đơn → 0 chromatid); số phân tử DNA (trong nhân) = số chromatid nếu NST kép, = số NST nếu NST đơn.
3. Tra bảng dưới (tính cho **một tế bào**):

| Kì | Số NST | Trạng thái | Số chromatid | Số tâm động | Số DNA |
|---|---|---|---|---|---|
| Trung gian – trước nhân đôi (G~1~) | 2n | đơn | 0 | 2n | 2n |
| Trung gian – sau nhân đôi; kì đầu, kì giữa nguyên phân | 2n | kép | 4n | 2n | 4n |
| Kì sau nguyên phân | **4n** | đơn | 0 | 4n | 4n |
| Kì cuối nguyên phân (mỗi tế bào con) | 2n | đơn | 0 | 2n | 2n |
| Kì đầu I, kì giữa I, kì sau I | 2n | kép | 4n | 2n | 4n |
| Kì cuối I (mỗi tế bào con); kì đầu II, kì giữa II | **n** | kép | 2n | n | 2n |
| Kì sau II | 2n | đơn | 0 | 2n | 2n |
| Kì cuối II (mỗi giao tử) | n | đơn | 0 | n | n |

> [!meo] Chỉ cần nhớ hai "cú nhảy"
> - Số NST chỉ **tăng gấp đôi** khi tâm động **tách** (kì sau nguyên phân, kì sau II).
> - Số NST chỉ **giảm một nửa** khi tế bào **chia** (kì cuối). Nhân đôi DNA ở kì trung gian **không** làm tăng số NST — chỉ biến NST đơn thành NST kép.

> [!vi-du] Ví dụ 4
> Ở lúa nước (2n = 24), xét một tế bào đang giảm phân bình thường. Tính số NST (ghi rõ đơn/kép), số chromatid và số tâm động trong tế bào ở: a) kì sau I; b) kì sau II.

> [!goi-y] Gợi ý 1
> Ở kì sau I, tâm động **đã tách chưa**? Hai chiếc của cặp tương đồng đi về hai cực, nhưng mỗi chiếc vẫn là NST kép.

> [!goi-y] Gợi ý 2
> Ở kì sau II, tế bào đang xét là tế bào con của lần phân bào I (chỉ còn n NST kép), giờ tâm động tách.

> [!loi-giai] Lời giải
> a) Kì sau I: tế bào chưa chia, tâm động chưa tách → **24 NST kép**, 24 × 2 = **48 chromatid**, **24 tâm động**.
>
> b) Kì sau II: tế bào có n = 12 NST kép, tâm động tách → **24 NST đơn**, **0 chromatid**, **24 tâm động**.

*Bẫy:* (1) Cho rằng kì sau I có 4n NST đơn (nhầm với nguyên phân). (2) Một tế bào có "10 NST kép xếp một hàng" có thể là kì giữa nguyên phân với 2n = 10, **hoặc** kì giữa II với 2n = 20 — đừng vội kết luận. (3) Đề hỏi "kì trung gian" mà không nói rõ: thường hiểu là **sau khi** DNA đã nhân đôi (NST kép); đọc kĩ đề.

### Dạng 2. Tính số nucleosome, chiều dài DNA, số phân tử histone

*Nhận biết:* đề cho số nucleosome, số cặp nucleotide quấn quanh mỗi lõi, độ dài đoạn nối; hỏi chiều dài DNA, số histone hoặc ngược lại.

*Phương pháp:*
1. Gọi N là số nucleosome. Nếu hai đầu chuỗi là nucleosome: số đoạn nối = **N − 1**. Nếu đề nói chuỗi gồm N "đơn vị lặp lại" (mỗi đơn vị = 1 nucleosome + 1 đoạn nối) thì số đoạn nối = N.
2. Tổng số cặp nucleotide = N × (số cặp quấn mỗi lõi) + (số đoạn nối) × (số cặp mỗi đoạn nối).
3. Chiều dài = số cặp nucleotide × **0,34 nm**. Đổi đơn vị: 1 µm = 10^3^ nm; 1 mm = 10^6^ nm.
4. Số histone = N × 8 + (số đoạn nối) × 1 (nếu đề cho mỗi đoạn nối có 1 H1).

> [!vi-du] Ví dụ 5
> Một phân tử DNA dài **5,1 cm** nằm trong một NST. Ở kì giữa, NST này dài khoảng 6 µm. a) Phân tử DNA có bao nhiêu cặp nucleotide? b) Chiều dài DNA gấp bao nhiêu lần chiều dài NST ở kì giữa?

> [!goi-y] Gợi ý 1
> Đổi về cùng đơn vị nm: 1 cm = 10^7^ nm.

> [!goi-y] Gợi ý 2
> Số cặp nucleotide = chiều dài ÷ 0,34 nm. Tỉ lệ nén = chiều dài DNA ÷ chiều dài NST (cùng đơn vị).

> [!loi-giai] Lời giải
> a) 5,1 cm = 5,1 × 10^7^ nm → số cặp nucleotide = 5,1 × 10^7^ ÷ 0,34 = **1,5 × 10^8^** cặp.
>
> b) 5,1 cm = 51 000 µm → tỉ lệ = 51 000 ÷ 6 = **8 500 lần**.
>
> Nghĩa là DNA đã được "gấp gọn" khoảng 8 500 lần — trả lời được câu hỏi mở bài: nhờ quấn quanh histone và cuộn xoắn nhiều mức.

*Bẫy:* (1) Quên trừ 1 khi đếm đoạn nối (N nucleosome hai đầu là hạt → N − 1 đoạn nối). (2) Dùng 3,4 nm thay vì **0,34 nm** (hoặc 3,4 **Å**) cho một cặp nucleotide → sai gấp 10 lần. (3) Quên histone H1 ở đoạn nối, hoặc tính 8 phân tử H1 cho mỗi đoạn nối.

### Dạng 3. Số tế bào con và số NST môi trường cung cấp khi nguyên phân

*Nhận biết:* "x tế bào (2n = …) nguyên phân liên tiếp k lần…".

*Phương pháp:*
- Số tế bào con = **x · 2^k^**.
- Tổng số NST trong các tế bào con = x · 2^k^ · 2n.
- Số NST môi trường cung cấp (tương đương) = tổng NST cuối − tổng NST ban đầu = **x · 2n · (2^k^ − 1)**.

> [!vi-du] Ví dụ 6
> Ba tế bào sinh dưỡng của đậu hà lan (2n = 14) cùng nguyên phân liên tiếp 4 lần. Tính số tế bào con tạo ra và số NST môi trường nội bào cung cấp.

> [!goi-y] Gợi ý 1
> Mỗi lần nguyên phân, số tế bào nhân đôi. Sau 4 lần, một tế bào cho bao nhiêu tế bào?

> [!goi-y] Gợi ý 2
> Phần NST "mới" = NST có ở cuối − NST có sẵn ở đầu.

> [!loi-giai] Lời giải
> Bước 1: Số tế bào con = 3 × 2^4^ = **48**.
>
> Bước 2: Số NST trong 48 tế bào con = 48 × 14 = 672; ban đầu có 3 × 14 = 42.
>
> Bước 3: Số NST môi trường cung cấp = 672 − 42 = **630** (= 3 × 14 × (2^4^ − 1)).

*Bẫy:* dùng 2^k^ thay cho (2^k^ − 1), tức quên trừ phần NST có sẵn trong tế bào mẹ.

### Dạng 4. Đúng/Sai về cấu trúc và chức năng NST

*Nhận biết:* 4 phát biểu về nucleosome, các mức xoắn, dị/nguyên nhiễm sắc, locus, vai trò của phân bào.

*Phương pháp:* đối chiếu từng phát biểu với **bốn "mỏ neo"**: (1) ba con số 2 – 10 – 700 nm; (2) dãn xoắn ↔ gene hoạt động, co xoắn ↔ phân li; (3) mỗi gene một locus, allele ở cùng locus trên cặp tương đồng; (4) nguyên phân giữ nguyên bộ NST, giảm phân + thụ tinh tạo tổ hợp mới và khôi phục 2n.

> [!vi-du] Ví dụ 7
> Xét các phát biểu sau về NST ở sinh vật nhân thực, phát biểu nào đúng, phát biểu nào sai? a) Vùng nguyên nhiễm sắc có các nucleosome nằm sát nhau và chứa các gene bị bất hoạt. b) Condensin là các protein dạng vòng tạo nên khung NST ở kì đầu. c) Hai chromatid chị em của một NST kép thường mang hai allele khác nhau của cùng một gene. d) Nhờ nguyên phân, các tế bào trong cơ thể đa bào đều có bộ NST lưỡng bội như nhau.

> [!goi-y] Gợi ý 1
> "Nguyên" nhiễm sắc — nucleosome "thưa", gene "nguyên vẹn hoạt động"; "dị" nhiễm sắc — nucleosome "đặc".

> [!goi-y] Gợi ý 2
> Hai chromatid chị em sinh ra bằng cách nào? Bản sao có giống bản gốc không?

> [!loi-giai] Lời giải
> a) **Sai** — đó là đặc điểm của **dị nhiễm sắc**; vùng nguyên nhiễm sắc có nucleosome cách xa nhau, chứa gene đang hoạt động.
>
> b) **Đúng** — condensin I và II liên kết tạo khung NST, sợi 10 nm cuộn thành vòng gắn vào khung.
>
> c) **Sai** — hai chromatid chị em sinh ra do nhân đôi nên mang allele **giống nhau** (trừ khi có đột biến hoặc trao đổi chéo). Allele khác nhau nằm trên **hai chiếc NST tương đồng**.
>
> d) **Đúng** — nguyên phân chia đều bộ NST đã nhân đôi cho hai tế bào con.

## Tóm tắt

| Mức cấu trúc (nhân thực) | Kích thước (theo SGK) | Ghi chú |
|---|---|---|
| Phân tử DNA | khoảng 2 nm | quấn quanh histone |
| Chuỗi nucleosome (sợi nhiễm sắc) | khoảng 10 nm | dạng chủ yếu ở **kì trung gian**; dị nhiễm sắc (đặc) – nguyên nhiễm sắc (thưa, gene hoạt động) |
| Vòng sợi 10 nm gắn trên khung NST (condensin) | — | hình thành ở **kì đầu**; NST ngắn lại, rộng ra |
| Chromatid ở kì giữa | khoảng 700 nm | **co xoắn cực đại**, thuận lợi cho phân li |

**Chức năng:** mang thông tin di truyền (gene ở locus xác định; trình tự tâm động, đầu mút) và truyền đạt thông tin di truyền (nguyên phân – qua thế hệ tế bào; giảm phân + thụ tinh – qua thế hệ cơ thể, tạo tổ hợp gene mới).

**Công thức nhanh:**
- Số NST = số tâm động; NST kép → số chromatid = 2 × số NST.
- Nguyên phân: kì sau 4n đơn; giảm phân: kì cuối I còn n kép, kì sau II 2n đơn.
- Nucleosome: tổng cặp nucleotide = N × (cặp/lõi) + (N − 1) × (cặp/đoạn nối); chiều dài = số cặp × 0,34 nm; histone = 8N + (N − 1).
- x tế bào nguyên phân k lần: x · 2^k^ tế bào con; NST môi trường cung cấp x · 2n · (2^k^ − 1).
- n cặp NST tương đồng phân li độc lập → 2^n^ loại giao tử (không trao đổi chéo).
