---
title: Đột biến gene
thoi-gian: 40 phút
muc-tieu:
  - Nêu được khái niệm đột biến gene, đột biến điểm, thể đột biến; phân biệt đột biến gene với đột biến nhiễm sắc thể.
  - Phân biệt được các dạng đột biến điểm (thay thế, thêm, mất một cặp nucleotide) và hậu quả của từng dạng đối với chuỗi polypeptide (đồng nghĩa, sai nghĩa, vô nghĩa, dịch khung).
  - Phân tích được nguyên nhân (tự phát, tác nhân vật lí, hoá học, sinh học) và cơ chế phát sinh đột biến gene (sai sót khi tái bản, 5-bromouracil, tia UV, chất chèn vào DNA).
  - Trình bày được vai trò của đột biến gene trong nghiên cứu di truyền, chọn giống và tiến hoá; nêu được biện pháp phòng tránh đột biến gene gây bệnh ở người.
  - Giải được các dạng bài: xác định dạng đột biến từ thay đổi số nucleotide, chiều dài, số liên kết hydrogen; xác định thay đổi của chuỗi amino acid khi đột biến ở bộ ba thứ n (dùng bảng mã rút gọn); số lần tái bản và số gene đột biến do 5-BU.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Đột biến gene** là sự thay đổi **trình tự nucleotide** trong gene. Đột biến chỉ liên quan đến **một cặp nucleotide** gọi là **đột biến điểm**. Cá thể mang gene đột biến **đã biểu hiện** ra kiểu hình gọi là **thể đột biến**.
> 2. Ba dạng đột biến điểm: **thay thế** một cặp nucleotide, **thêm** một cặp, **mất** một cặp. Thay thế không đổi chiều dài; thêm/mất làm chiều dài thay đổi 0,34 nm.
> 3. Hậu quả lên chuỗi polypeptide: thay thế → **đồng nghĩa** (không đổi amino acid), **sai nghĩa** (đổi một amino acid) hoặc **vô nghĩa** (xuất hiện bộ ba kết thúc sớm); thêm/mất → **dịch khung** (đổi mọi amino acid từ chỗ đột biến trở đi).
> 4. Nguyên nhân: **sai sót tự phát khi tái bản DNA** hoặc **tác nhân đột biến** vật lí (tia UV), hoá học (5-BU, HNO~2~, EMS, acridine, dioxin), sinh học (virus). 5-BU gây thay thế **A – T → G – C**, cần **ít nhất 3 lần tái bản**.
> 5. Đột biến gene tạo ra **allele mới** → là **nguồn nguyên liệu** cho tiến hoá và chọn giống, đồng thời là "công cụ" giúp các nhà khoa học tìm hiểu chức năng của gene.

> [!nen-tang] Nhớ lại từ Bài 1 và Bài 2
> - DNA gồm hai mạch ngược chiều, bắt cặp bổ sung: **A – T bằng 2 liên kết hydrogen**, **G – C bằng 3 liên kết hydrogen**. Mỗi cặp nucleotide dài **0,34 nm**. Công thức: $N = 2A + 2G$; $H = 2A + 3G$; $L = \frac{N}{2}\times 0{,}34$ nm (xem Bài 1).
> - Gene → (phiên mã) → mRNA → (dịch mã) → chuỗi polypeptide. mRNA **bổ sung với mạch khuôn** và có trình tự **giống mạch mã hoá** (chỉ thay T bằng U).
> - Mã di truyền là **mã bộ ba**, đọc **liên tục** từ bộ ba mở đầu AUG theo chiều 5' → 3', không chồng gối. Mã có tính **thoái hoá**: nhiều codon cùng mã hoá một amino acid (ví dụ Ala: GCU, GCC, GCA, GCG). Ba bộ ba **kết thúc**: UAA, UAG, UGA (xem Bài 2).
>
> Bài này hỏi một câu đơn giản: **nếu một "chữ cái" trong gene bị đổi, thêm hay mất thì chuyện gì xảy ra?**

## 1. Khái niệm và các dạng đột biến gene

### 1.1. Khái niệm

Hãy hình dung gene là một **câu văn** viết bằng 4 chữ cái A, T, G, C, được đọc theo từng "từ" 3 chữ (codon). **Đột biến gene** là khi câu văn đó bị **chép sai**: một chữ bị đổi, thêm vào hay rơi mất, hoặc nhiều chữ cùng bị thay đổi.

- **Đột biến gene**: sự thay đổi **trình tự nucleotide** trong gene. Đột biến có thể liên quan đến một hoặc nhiều cặp nucleotide.
- **Đột biến điểm**: đột biến chỉ làm thay đổi **một cặp nucleotide** trong gene. Bài này (và đề thi) chủ yếu xét loại này.
- Đột biến gene có thể làm thay đổi kiểu hình **hoặc không** (mục 1.3 sẽ giải thích vì sao).
- **Thể đột biến**: cá thể mang gene đột biến **đã biểu hiện** thành kiểu hình khác thường.

Mỗi lần gene bị đột biến là một lần **allele mới** ra đời. Ví dụ: gene quy định chuỗi β-globin ban đầu chỉ có allele bình thường; một đột biến điểm đã tạo ra allele gây bệnh hồng cầu hình liềm (mục 1.3). Vì vậy, **đột biến gene là nguồn gốc của mọi allele**.

> [!bay]
> - Mang gene đột biến **chưa chắc** là thể đột biến. Đột biến **lặn** (a) xuất hiện ở cơ thể AA tạo ra Aa: kiểu hình vẫn bình thường → **chưa phải** thể đột biến. Chỉ khi có kiểu gene aa (hoặc X^a^Y ở giới XY, xem Bài 10) mới biểu hiện. Đột biến **trội** thì biểu hiện ngay → thể đột biến.
> - Đột biến gene là biến đổi **bên trong một gene** (cấp phân tử), thường không nhìn thấy dưới kính hiển vi. Đột biến NST (Bài 12) làm thay đổi **cấu trúc hoặc số lượng NST** — liên quan đến cả một đoạn NST chứa nhiều gene, nhiều trường hợp quan sát được dưới kính hiển vi.

> [!em-co-biet]
> Đột biến gene trong tự nhiên rất hiếm: với mỗi gene, tần số đột biến tự phát thường chỉ khoảng 10^-6^ – 10^-4^ (một phần triệu đến một phần vạn) mỗi thế hệ. Nhưng một cơ thể có hàng chục nghìn gene, một quần thể có rất nhiều cá thể → mỗi thế hệ vẫn xuất hiện khá nhiều allele mới. (Số liệu này không có trong SGK, chỉ để em hình dung.)

### 1.2. Các dạng đột biến điểm

Dựa trên **cơ chế phát sinh**, đột biến điểm gồm ba dạng (SGK tr. 23):

![Hình 1. Ba dạng đột biến điểm trên một đoạn gene: thay thế, thêm và mất một cặp nucleotide](hinh-1-cac-dang.svg)

| Dạng | Ví dụ (một mạch) | ΔN | ΔL | ΔH |
|---|---|---|---|---|
| **Thay thế** một cặp | ATG**C**AA → ATG**T**AA | không đổi | không đổi | tuỳ cặp (bảng dưới) |
| **Thêm** một cặp | ATGCAA → ATG**G**CAA | + 2 | + 0,34 nm | + 2 (A – T) / + 3 (G – C) |
| **Mất** một cặp | ATGCAA → ATCAA (mất G) | − 2 | − 0,34 nm | − 2 (A – T) / − 3 (G – C) |

**Vì sao số liên kết hydrogen thay đổi như vậy?** Mỗi cặp A – T góp 2 liên kết, mỗi cặp G – C góp 3 liên kết. Chỉ cần nhìn xem cặp nào "đi ra", cặp nào "đi vào":

| Thay thế | Thay đổi H | Số nucleotide mỗi loại |
|---|---|---|
| A – T → T – A hoặc G – C → C – G (cùng loại cặp, đảo chiều) | **0** | không đổi |
| A – T → G – C | **+ 1** (2 → 3) | A, T giảm 1; G, C tăng 1 |
| G – C → A – T | **− 1** (3 → 2) | G, C giảm 1; A, T tăng 1 |

> [!meo] Đọc nhanh từ ΔL và ΔH
> - **L không đổi** → thay thế. ΔH = 0 / + 1 / − 1 ứng với cùng loại / A – T → G – C / G – C → A – T.
> - **L tăng 0,34 nm** (N + 2) → thêm: ΔH = + 2 là thêm A – T, + 3 là thêm G – C.
> - **L giảm 0,34 nm** (N − 2) → mất: ΔH = − 2 là mất A – T, − 3 là mất G – C.

> [!vi-du] Ví dụ 1
> Gene B có 2400 nucleotide, trong đó có 700 nucleotide loại A. Gene B bị đột biến điểm thành allele b. Allele b có chiều dài bằng gene B nhưng có 2901 liên kết hydrogen. Xác định dạng đột biến và số nucleotide mỗi loại của allele b.

> [!goi-y] Gợi ý 1
> Tính số G của gene B từ $N = 2A + 2G$, rồi tính $H = 2A + 3G$. So sánh với 2901.

> [!goi-y] Gợi ý 2
> Chiều dài không đổi → loại thêm, mất. H thay đổi bao nhiêu thì ứng với kiểu thay thế nào?

> [!loi-giai] Lời giải
> Bước 1: Gene B: A = T = 700; G = C = (2400 − 2 × 700) : 2 = 500.
>
> Bước 2: H~B~ = 2 × 700 + 3 × 500 = 1400 + 1500 = 2900.
>
> Bước 3: Chiều dài không đổi → đột biến **thay thế**; H tăng 2901 − 2900 = 1 → thay **một cặp A – T bằng một cặp G – C**.
>
> Kết luận: allele b có **A = T = 699; G = C = 501**.

### 1.3. Hậu quả của đột biến điểm lên chuỗi polypeptide

Gene đột biến → mRNA đột biến → chuỗi polypeptide có thể thay đổi. Mức độ thay đổi phụ thuộc vào **dạng** đột biến và **vị trí** của nó. Xét một đoạn mRNA bình thường mã hoá Met – Glu – Ser – Trp – His:

![Hình 2. Hậu quả của các dạng đột biến điểm lên chuỗi polypeptide: đồng nghĩa, sai nghĩa, vô nghĩa và dịch khung](hinh-2-hau-qua.svg)

| Kiểu hậu quả | Xảy ra khi | Ví dụ (codon trên mRNA) | Chuỗi polypeptide |
|---|---|---|---|
| **Đồng nghĩa** (im lặng) | thay thế tạo codon mới mã hoá **cùng** amino acid | GAA → GA**G** (đều Glu) | không đổi |
| **Sai nghĩa** (nhầm nghĩa) | thay thế tạo codon mã hoá amino acid **khác** | GAA → G**U**A (Glu → Val) | đổi **một** amino acid |
| **Vô nghĩa** | thay thế biến codon mã hoá thành **bộ ba kết thúc** | UGG → UG**A** (Trp → KT) | **ngắn lại** (dừng sớm) |
| **Dịch khung** | **thêm hoặc mất** một cặp nucleotide trong vùng mã hoá | mất G đầu codon 2 → Met – **Lys – Ala – Gly**… (Hình 2) | đổi **mọi** amino acid từ vị trí đột biến trở đi |

**Vì sao thêm/mất một cặp lại "nguy hiểm" hơn thay thế?** Nhớ lại: mã di truyền đọc **liên tục từng bộ ba**, không có "dấu cách". Thử với câu chữ: "CON MEO DEN BAT CHU OT". Đổi một chữ: "CON MEO **V**EN BAT CHU OT" — vẫn hiểu gần hết. Nhưng mất một chữ: "CON MEO ENB ATC HUO T…" — **từ chỗ đó trở đi mọi từ đều sai**. Đó là **dịch khung đọc**. Ngoài ra, khung đọc mới rất dễ gặp bộ ba kết thúc sớm.

**Vì sao nhiều đột biến thay thế không gây hại?** Có ba lí do:

1. **Mã thoái hoá**: nhiều codon cùng mã hoá một amino acid, và chúng thường chỉ khác nhau ở **nucleotide thứ ba** (GCU, GCC, GCA, GCG đều là Ala). Thay thế ở vị trí thứ ba thường là đồng nghĩa.
2. Đột biến xảy ra ở vùng **không mã hoá amino acid** (intron, vùng giữa các gene… — xem Bài 2) thường không làm thay đổi chuỗi polypeptide.
3. Đột biến sai nghĩa thay một amino acid bằng amino acid có **tính chất tương tự**, hoặc ở vị trí **không quan trọng** với chức năng của protein.

> [!bay]
> - Thêm/mất ở **gần cuối** gene (ví dụ ngay trước bộ ba kết thúc) chỉ ảnh hưởng ít amino acid cuối → hậu quả nhẹ hơn thêm/mất ở **gần đầu** gene (ngay sau AUG). Đề hay hỏi "đột biến ở vị trí nào gây hậu quả **lớn nhất**" → thêm/mất một cặp ở **bộ ba thứ hai** (ngay sau bộ ba mở đầu).
> - Đột biến ở **bộ ba mở đầu** AUG (ví dụ AUG → AUA) có thể làm gene **không được dịch mã**. Đột biến biến **bộ ba kết thúc** thành codon mã hoá (ví dụ UAA → CAA) làm chuỗi polypeptide **dài ra**.
> - Mất **ba** cặp nucleotide liên tiếp thuộc **cùng một** bộ ba thì chỉ mất **một** amino acid, **không** dịch khung — nhưng đó không còn là đột biến điểm.

> [!vi-du] Ví dụ 2
> Bệnh hồng cầu hình liềm ở người: ở codon quy định amino acid thứ 6 của chuỗi β-globin, codon bình thường là 5'-GAG-3' (Glu) bị biến đổi thành 5'-GUG-3' (Val). Xác định: a) dạng đột biến điểm trên gene và loại hậu quả lên chuỗi polypeptide; b) số liên kết hydrogen và chiều dài gene thay đổi thế nào?

> [!goi-y] Gợi ý 1
> mRNA giống mạch mã hoá (thay U bằng T). Từ GAG → GUG, mạch mã hoá đổi GAG → GTG. Cặp nucleotide ở vị trí giữa thay đổi từ cặp nào sang cặp nào?

> [!goi-y] Gợi ý 2
> Trên mạch mã hoá A đổi thành T, thì ở mạch khuôn đối diện T đổi thành A. Cặp cũ và cặp mới có cùng số liên kết hydrogen không?

> [!loi-giai] Lời giải
> a) Mạch mã hoá: 5'-GAG-3' → 5'-GTG-3'; mạch khuôn tương ứng: 3'-CTC-5' → 3'-CAC-5'. Cặp **A – T bị thay bằng cặp T – A** → đột biến **thay thế một cặp nucleotide**. Glu bị thay bằng Val, các amino acid khác giữ nguyên → đột biến **sai nghĩa**.
>
> b) Cặp A – T và cặp T – A đều có 2 liên kết hydrogen → **H không đổi**; thay thế nên **chiều dài không đổi**.
>
> Chỉ một amino acid bị đổi, nhưng Val kị nước làm các phân tử hemoglobin dính kết với nhau thành sợi khi thiếu oxygen → hồng cầu biến dạng hình liềm, dễ vỡ, gây thiếu máu và tắc mạch máu nhỏ.

> [!ung-dung] Mở rộng (ngoài SGK)
> Bệnh hồng cầu hình liềm là bệnh di truyền do allele **lặn** trên NST thường (HbS). Ở các vùng nhiều sốt rét (châu Phi), người dị hợp mang một allele HbS lại **ít bị sốt rét nặng** hơn người bình thường → allele "có hại" lại có lợi trong môi trường đó. Đây là ví dụ cho thấy giá trị của một đột biến **phụ thuộc vào môi trường** (mục 1.4).

### 1.4. Các cách phân loại khác

Ngoài cách phân loại theo cơ chế (thay thế, thêm, mất), có thể phân loại đột biến gene theo nhiều tiêu chí khác (SGK tr. 23):

| Tiêu chí | Các loại | Giải thích |
|---|---|---|
| Biểu hiện ở thể dị hợp | **Trội / lặn** | Allele đột biến trội biểu hiện ngay ở thể dị hợp; allele lặn chỉ biểu hiện ở thể đồng hợp |
| Ảnh hưởng tới sức sống, sinh sản | **Có lợi / có hại / trung tính** | Đa số có hại hoặc trung tính; một số ít có lợi |
| Ảnh hưởng tới trình tự amino acid | **Có / không** làm thay đổi trình tự amino acid | Đồng nghĩa (không đổi); sai nghĩa, vô nghĩa, dịch khung (có đổi) |

**Vì sao phần lớn đột biến gene có hại?** Protein của sinh vật hiện nay đã được chọn lọc tự nhiên "tinh chỉnh" qua hàng triệu năm, nên một thay đổi ngẫu nhiên giống như đổi ngẫu nhiên một chi tiết trong chiếc đồng hồ đang chạy tốt — thường làm hỏng hơn là làm tốt lên. Tuy vậy, tính có lợi hay có hại chỉ là **tương đối**: tuỳ **môi trường** và **tổ hợp gene** mà đột biến đó nằm trong (ví dụ HbS ở vùng sốt rét).

## 2. Nguyên nhân và cơ chế phát sinh đột biến gene

### 2.1. Nguyên nhân

Đột biến gene có thể **tự phát** hoặc do **tác nhân đột biến** (SGK tr. 24):

| Nguyên nhân | Ví dụ | Thường gây |
|---|---|---|
| **Tự phát** | sai sót ngẫu nhiên của enzyme DNA polymerase khi tái bản | đột biến điểm các loại |
| **Tác nhân hoá học** | **5-bromouracil (5-BU, SGK viết 5-BrU)**, HNO~2~, ethyl methane sulfonate (EMS) | thay thế cặp nucleotide |
| | acridine (như acridine orange), dioxin — chất chèn vào DNA | thêm hoặc mất một cặp nucleotide |
| **Tác nhân vật lí** | **tia tử ngoại (UV)** | thêm hoặc mất một cặp nucleotide |
| | tia X, tia gamma | đứt gãy cả hai mạch DNA → thường dẫn tới **đột biến cấu trúc NST** (Bài 12) |
| **Tác nhân sinh học** | một số virus (ví dụ virus viêm gan B) chèn hệ gene của chúng vào hệ gene người | đột biến gene; một số tác nhân sinh học làm đứt gãy DNA → đột biến NST |

**Vì sao không có tác nhân đột biến, gene vẫn bị đột biến?** Mỗi lần tế bào người phân chia, DNA polymerase phải lắp ráp khoảng 6 tỉ nucleotide. Dù rất chính xác và có cơ chế tự "đọc sửa", enzyme vẫn thỉnh thoảng lắp nhầm. Phần lớn đột biến tự phát là do sai sót này.

> [!bay] "Chất độc màu cam" trong SGK
> SGK tr. 24 viết "chất độc màu cam (acridine orange) và dioxin có thể chèn vào DNA". Cần hiểu đúng hai tên dễ lẫn:
> - **Acridine orange** là một **thuốc nhuộm** họ acridine có màu cam, phân tử dẹt nên chèn được vào giữa các cặp base.
> - Ở Việt Nam, "chất độc màu cam" thường dùng để chỉ **chất diệt cỏ** rải trong chiến tranh (Agent Orange), mà chất gây hại chính trong đó là **dioxin**.
>
> Khi làm bài, em chỉ cần nhớ: acridine và dioxin (theo SGK) gây đột biến **thêm hoặc mất một cặp nucleotide**.

> [!bay]
> Đề hay hỏi "tác nhân nào **thường** gây đột biến cấu trúc NST hơn là đột biến gene" → **tia X, tia gamma** (làm đứt gãy hai mạch DNA). Còn tia UV thường gây đột biến **gene** dạng thêm/mất cặp nucleotide.

### 2.2. Cơ chế phát sinh

**a) Đột biến thêm hoặc mất một cặp nucleotide**

- **Sai sót khi tái bản**: nếu một nucleotide trên mạch khuôn được "đọc" **hai lần** → mạch mới **thừa** một nucleotide; nếu một nucleotide **bị bỏ qua**, không làm khuôn → mạch mới **thiếu** một nucleotide. Lần tái bản sau, mạch mới này lại làm khuôn → tạo ra DNA con **thêm hoặc mất hẳn một cặp** nucleotide.
- **Tia UV**: làm hai base **T đứng cạnh nhau trên cùng một mạch** liên kết với nhau (tạo "cầu nối" T – T), khiến mạch DNA bị cong, vênh. Khi tế bào sửa chữa chỗ hỏng này, sai sót thường dẫn đến thêm hoặc mất một cặp nucleotide.
- **Chất chèn vào DNA** (acridine, dioxin — theo SGK): các phân tử dẹt này **lách vào giữa các cặp base**, làm khoảng cách giữa hai cặp giãn ra như có thêm một "bậc thang" → khi tái bản dễ thêm hoặc mất nucleotide.

![Hình 3. Tia UV làm hai T kề nhau trên cùng một mạch liên kết với nhau; khi tái bản hoặc sửa chữa sai có thể dẫn tới thêm hoặc mất một cặp nucleotide](hinh-3-uv.svg)

> [!bay]
> Hai T bị tia UV nối với nhau nằm **trên cùng một mạch** và **đứng cạnh nhau** — không phải hai T ở hai mạch đối diện (hai mạch đối diện nhau thì T bắt cặp với A, không có T – T).

**b) Đột biến thay thế cặp nucleotide**

Một số chất có cấu trúc **giống base bình thường** (gọi là chất tương tự base) có thể được lắp vào mạch mới khi tái bản và gây bắt cặp sai. Ví dụ điển hình là **5-bromouracil (5-BU)** — có cấu trúc giống T:

![Hình 4. Cơ chế gây đột biến thay thế A – T bằng G – C của 5-BU qua 3 lần tái bản](hinh-4-5bu.svg)

| Lần tái bản | Chuyện gì xảy ra ở vị trí đang xét |
|---|---|
| Lần 1 | 5-BU (giống T) được lắp vào mạch mới, đối diện **A** → cặp **A – 5-BU** |
| Lần 2 | Mạch chứa 5-BU làm khuôn; 5-BU chuyển sang dạng hiếm và bắt cặp với **G** → cặp **G – 5-BU** (tiền đột biến) |
| Lần 3 | Mạch chứa G làm khuôn → G bắt cặp với C → cặp **G – C**: **gene đột biến** |

Kết quả: **A – T → G – C**, cần **ít nhất 3 lần tái bản** mới xuất hiện gene đột biến hoàn chỉnh.

**Tiền đột biến** là biến đổi mới xảy ra trên **một mạch** (như G – 5-BU). Ở giai đoạn này, hệ thống enzyme **sửa chữa DNA** của tế bào còn có thể phát hiện và sửa lại. Nếu không được sửa, qua tái bản nó trở thành đột biến trên **cả hai mạch** và được truyền cho các tế bào con.

> [!em-co-biet] Bắt cặp sai tự phát do base dạng hiếm
> Không cần chất lạ, chính các base bình thường thỉnh thoảng cũng tồn tại ở **dạng hiếm** (dạng hỗ biến) có vị trí liên kết hydrogen khác thường. Ví dụ G ở dạng hiếm (kí hiệu G*) bắt cặp với **T** thay vì C: G* – C → (lần 1) G* – T → (lần 2) **A – T**. Dạng này gây thay thế G – C → A – T sau **2 lần tái bản**. HNO~2~ làm biến đổi base (ví dụ biến A thành chất bắt cặp với C) cũng theo kiểu "đổi đối tác bắt cặp" như vậy.

> [!vi-du] Ví dụ 3
> Một gene ở vi khuẩn tái bản trong môi trường có 5-BU. Giả sử 5-BU chỉ tác động lên đúng một cặp A – T của gene. a) Gene cần tái bản **ít nhất** mấy lần để xuất hiện gene đột biến? b) Gene đột biến có số liên kết hydrogen và chiều dài thay đổi thế nào so với gene ban đầu?

> [!goi-y] Gợi ý 1
> Lần đầu 5-BU phải được "lắp" vào mạch mới (đối diện với base nào?). Sau đó nó phải "đổi đối tác" ở một lần tái bản, rồi cần thêm một lần nữa để có cặp bình thường mới.

> [!goi-y] Gợi ý 2
> Kết quả cuối cùng là cặp A – T được thay bằng cặp gì? Mỗi cặp có mấy liên kết hydrogen?

> [!loi-giai] Lời giải
> a) Lần 1: A – 5-BU; lần 2: G – 5-BU; lần 3: G – C → cần **ít nhất 3 lần** tái bản.
>
> b) Thay một cặp A – T (2 liên kết) bằng một cặp G – C (3 liên kết) → gene đột biến có số liên kết hydrogen **tăng 1**; đột biến thay thế nên **chiều dài không đổi**.

## 3. Vai trò của đột biến gene

### 3.1. Trong nghiên cứu di truyền

Muốn biết một chiếc máy hoạt động thế nào, người thợ có thể **tháo bỏ từng bộ phận** rồi xem máy hỏng ở đâu. Các nhà di truyền học làm tương tự: so sánh **thể đột biến** (mang gene hỏng) với cá thể bình thường để biết gene đó làm gì. Nhờ thể đột biến, người ta tìm ra chức năng của nhiều gene và nhiều quy luật di truyền (Mendel, Morgan đều nghiên cứu các dạng đột biến ở đậu hà lan, ruồi giấm).

**Lai các dòng đột biến với nhau** cho biết:

- tính trạng đột biến là **trội hay lặn**;
- hai dòng có cùng một kiểu hình đột biến là do đột biến ở **cùng một gene** hay ở **hai gene khác nhau**.

Ý thứ hai được giải thích như sau. Giả sử để nghe bình thường cần **cả hai** gene A và B hoạt động (một con đường gồm hai bước). Bố điếc do đột biến lặn ở gene A (aaBB), mẹ điếc do đột biến lặn ở gene B (AAbb):

=> AAbb (điếc) × aaBB (điếc) → AaBb (100% nghe bình thường)

Con nhận allele A **lành** từ mẹ và allele B **lành** từ bố → hai gene "bù" cho nhau → nghe bình thường. Ngược lại, nếu bố và mẹ cùng đột biến ở **một** gene (aa × aa) thì mọi con đều aa → đều điếc. (SGK tr. 25.)

> [!vi-du] Ví dụ 4
> Từ một giống hoa đỏ thuần chủng, người ta thu được ba dòng đột biến hoa trắng thuần chủng (1, 2, 3); mỗi dòng mang **một** đột biến lặn. Lai từng cặp dòng với nhau, F~1~ thu được: dòng 1 × dòng 2 → 100% hoa đỏ; dòng 1 × dòng 3 → 100% hoa trắng; dòng 2 × dòng 3 → 100% hoa đỏ. Các đột biến của ba dòng nằm trên bao nhiêu gene khác nhau?

> [!goi-y] Gợi ý 1
> F~1~ hoa đỏ nghĩa là hai dòng "bù" được cho nhau → đột biến ở hai gene **khác** nhau. F~1~ hoa trắng nghĩa là gì?

> [!goi-y] Gợi ý 2
> Nhóm các dòng có đột biến ở **cùng một gene** lại với nhau.

> [!loi-giai] Lời giải
> - Dòng 1 × dòng 3 → trắng: không bù được → đột biến **cùng một gene** (giả sử gene A: cả hai dòng là aaBB).
> - Dòng 1 × dòng 2 → đỏ và dòng 2 × dòng 3 → đỏ: dòng 2 đột biến ở gene **khác** (AAbb).
>
> Kết luận: các đột biến nằm trên **2 gene**: gene thứ nhất (dòng 1, 3) và gene thứ hai (dòng 2).

### 3.2. Trong chọn giống

Từ xa xưa, con người đã **chọn lọc những thể đột biến tự nhiên có ích** ở cây trồng, vật nuôi để tạo giống mới (SGK tr. 25):

- Ở cải hoang dại, một đột biến làm xuất hiện **bộ ba kết thúc sớm** (đột biến vô nghĩa) khiến chồi phân nhánh rất mạnh; con người chọn lọc dạng này và tạo ra **súp lơ trắng, súp lơ xanh**. Nhánh không mang đột biến này được chọn lọc theo hướng khác thành **bắp cải, cải xoăn**. Tất cả đều có chung tổ tiên!
- Một đột biến ở **gene điều hoà** làm tăng lượng cơ bắp được phát hiện ở lợn và được chọn lọc thành giống **lợn siêu nạc**.

Ngày nay, người ta còn **chủ động gây đột biến** bằng tác nhân vật lí, hoá học rồi chọn lọc các thể đột biến có lợi (em sẽ học ở các bài sau).

> [!ung-dung]
> Ví dụ trên cho thấy đột biến "có hại" hay "có lợi" còn tuỳ **mục đích của con người**: chồi phân nhánh quá mức có thể bất lợi cho cây hoang dại, nhưng lại cho ta bông súp lơ to, ăn ngon.

### 3.3. Trong tiến hoá

Đột biến gene là **nguồn nguyên liệu sơ cấp** của tiến hoá:

- Đột biến liên tục tạo ra **allele mới**; qua sinh sản hữu tính các allele được tổ hợp lại thành vô số kiểu gene (biến dị tổ hợp — nguyên liệu thứ cấp). Chọn lọc tự nhiên giữ lại các tổ hợp thích nghi. Từ một vài dạng sống sơ khai, sau hàng tỉ năm đã hình thành sinh giới đa dạng như ngày nay.
- Đột biến gene tạo nên **sự khác biệt giữa các loài**. Ví dụ: protein của gene *FOXP2* (SGK ghi là *FOX2*) ở người chỉ khác của tinh tinh **2 trong 715** amino acid, nhưng góp phần giúp loài người có **tiếng nói** mà các loài linh trưởng khác không có.
- Đột biến ở một số gene **có thể dẫn đến hình thành loài mới**. Ví dụ: ở ốc thuộc chi *Bradybaena*, đột biến làm **đổi chiều xoắn vỏ** khiến ốc đột biến không giao phối được với ốc bình thường → **cách li sinh sản** → loài mới.

**Vì sao đột biến gene — dù phần lớn có hại — vẫn là nguyên liệu chủ yếu của tiến hoá?** (Dừng lại và suy ngẫm, SGK tr. 25.)

1. So với đột biến NST, đột biến gene **phổ biến hơn** (tính trên toàn bộ các gene, các cá thể) và thường **ít ảnh hưởng nghiêm trọng** đến sức sống, sinh sản hơn.
2. Phần lớn đột biến gene là **lặn**, "ẩn" ở thể dị hợp, không bị chọn lọc loại bỏ ngay → được tích luỹ, lan truyền trong quần thể, chờ điều kiện thuận lợi.
3. Giá trị của đột biến là **tương đối**: khi môi trường thay đổi, một allele trước đây có hại hoặc trung tính có thể trở nên có lợi.

> [!bay]
> "Đột biến gene là nguồn nguyên liệu **sơ cấp**"; "biến dị tổ hợp là nguồn nguyên liệu **thứ cấp**". Đột biến tạo ra allele mới; biến dị tổ hợp **không** tạo allele mới, chỉ sắp xếp lại các allele đã có.

## 4. Phòng tránh đột biến gene gây bệnh ở người

Câu hỏi mở đầu bài: liệu có cách phòng chống đột biến gene gây bệnh? Dựa vào **nguyên nhân** (mục 2.1), ta có thể giảm nguy cơ bằng cách **hạn chế tiếp xúc với tác nhân đột biến** (Luyện tập và vận dụng, SGK tr. 26):

| Tác nhân | Có ở đâu | Cách phòng tránh |
|---|---|---|
| Tia UV | ánh nắng mặt trời, đặc biệt buổi trưa | che chắn (mũ, áo dài tay, kính), dùng kem chống nắng, tránh nắng gắt 10 – 15 giờ |
| Hoá chất | khói thuốc lá; thực phẩm nướng cháy, chiên lại dầu nhiều lần; hạt, lạc bị mốc (aflatoxin); thuốc bảo vệ thực vật, dioxin | không hút thuốc; không ăn đồ mốc, cháy; dùng thực phẩm rõ nguồn gốc; bảo hộ khi tiếp xúc hoá chất |
| Virus | virus viêm gan B (có thể chèn hệ gene vào tế bào gan, gây ung thư gan), HPV (ung thư cổ tử cung) | **tiêm vaccine** (viêm gan B, HPV); không dùng chung kim tiêm, dao cạo; quan hệ tình dục an toàn |
| Tia phóng xạ | chụp X-quang không cần thiết, nơi có nguồn phóng xạ | chỉ chụp khi bác sĩ chỉ định; tuân thủ quy định an toàn bức xạ |

**Vì sao ung thư da thường gặp ở người tiếp xúc nhiều với nắng?** Tia UV gây đột biến gene ở **tế bào da**. Nếu đột biến rơi vào các gene kiểm soát sự phân chia tế bào, tế bào có thể phân chia không ngừng → khối u. Vì đột biến xảy ra ở **tế bào sinh dưỡng** (không phải tế bào sinh giao tử), bệnh **không truyền cho con** qua sinh sản.

> [!em-co-biet]
> Ngoài phòng tránh, khám sàng lọc định kì giúp phát hiện sớm các khối u do đột biến gene (ví dụ ung thư gan ở người nhiễm virus viêm gan B). Ở Việt Nam, vaccine viêm gan B được tiêm cho trẻ sơ sinh trong 24 giờ đầu sau sinh trong chương trình tiêm chủng mở rộng.

## Dạng bài thi hay gặp

> [!ghi-nho] Bảng tra nhanh đột biến điểm
> | Dạng | ΔN | ΔL | ΔH | Hậu quả thường gặp |
> |---|---|---|---|---|
> | Thay cùng loại cặp (A – T ↔ T – A; G – C ↔ C – G) | 0 | 0 | 0 | đồng nghĩa / sai nghĩa / vô nghĩa |
> | Thay A – T → G – C | 0 | 0 | + 1 | như trên |
> | Thay G – C → A – T | 0 | 0 | − 1 | như trên |
> | Thêm A – T / G – C | + 2 | + 0,34 nm | + 2 / + 3 | dịch khung |
> | Mất A – T / G – C | − 2 | − 0,34 nm | − 2 / − 3 | dịch khung |

### Dạng 1. Xác định dạng đột biến từ số nucleotide, chiều dài, liên kết hydrogen

*Nhận biết:* đề cho thông tin gene ban đầu (chiều dài, số nucleotide, % một loại, số liên kết hydrogen) và thông tin của allele đột biến (H, L, hoặc số nucleotide mỗi loại); hỏi dạng đột biến hoặc số nucleotide mỗi loại sau đột biến. Bài nâng cao thêm: cặp gene dị hợp tái bản k lần, tính số nucleotide môi trường cung cấp.

*Phương pháp:*
1. Tính đầy đủ A, T, G, C, N, H của gene ban đầu (công thức Bài 1).
2. So sánh: ΔL (hoặc ΔN) cho biết thay thế / thêm / mất; ΔH cho biết loại cặp (bảng tra nhanh).
3. Viết lại số nucleotide mỗi loại của allele đột biến.
4. Nếu cặp allele tái bản k lần: môi trường cung cấp loại X = (X~allele 1~ + X~allele 2~) × (2^k^ − 1).

> [!vi-du] Ví dụ 5
> Gene A dài 408 nm và có 3120 liên kết hydrogen. Gene A bị đột biến điểm thành allele a; allele a có chiều dài bằng gene A nhưng ít hơn gene A một liên kết hydrogen. a) Xác định dạng đột biến. b) Tính số nucleotide mỗi loại của allele a. c) Một tế bào có kiểu gene Aa nguyên phân 2 lần liên tiếp. Tính số nucleotide loại A và loại G môi trường cung cấp cho các lần tái bản của cặp gene này.

> [!goi-y] Gợi ý 1
> N = 408 : 0,34 × 2. Giải hệ: 2A + 2G = N và 2A + 3G = 3120.

> [!goi-y] Gợi ý 2
> Chiều dài không đổi, H giảm 1 → thay cặp nào bằng cặp nào? Nguyên phân 2 lần → mỗi gene tái bản 2 lần → môi trường cung cấp (2^2^ − 1) lần số nucleotide của **mỗi** allele.

> [!loi-giai] Lời giải
> Bước 1: N = 408 : 0,34 × 2 = 2400 → A + G = 1200; 2A + 3G = 3120 → G = 3120 − 2400 = 720; A = 480.
>
> Bước 2 (câu a): L không đổi, H giảm 1 → **thay một cặp G – C bằng một cặp A – T**.
>
> Bước 3 (câu b): allele a: **A = T = 481; G = C = 719**.
>
> Bước 4 (câu c): Cặp Aa tái bản 2 lần:
> - A~mt~ = (480 + 481) × (2^2^ − 1) = 961 × 3 = **2883**;
> - G~mt~ = (720 + 719) × 3 = 1439 × 3 = **4317**.

*Bẫy:* quên rằng tế bào Aa chứa **cả hai** allele (cộng cả hai); dùng 2^k^ thay cho 2^k^ − 1; nhầm H giảm 1 với "mất một cặp" (mất cặp thì H giảm 2 hoặc 3 **và** chiều dài giảm).

### Dạng 2. Xác định chuỗi amino acid khi đột biến ở bộ ba thứ n

*Nhận biết:* đề cho trình tự một mạch của gene (hoặc mRNA) và **bảng mã rút gọn**; mô tả đột biến tại một nucleotide / một bộ ba; hỏi chuỗi amino acid sau đột biến hoặc loại hậu quả.

*Phương pháp:*
1. Viết mRNA bình thường (5' → 3') từ mạch đã cho (xem Bài 2, Dạng 1), tìm AUG, chia bộ ba.
2. Áp đột biến **lên đúng mạch đề cho**, rồi viết lại mRNA đột biến. Đột biến trên mạch khuôn thì codon thay đổi theo kiểu **bổ sung** (khuôn T → A thì codon A → U…).
3. Thay thế: chỉ tra lại **một** codon. Thêm/mất: chia lại bộ ba **từ vị trí đột biến trở đi** (dịch khung) và tra đến khi gặp bộ ba kết thúc hoặc hết đoạn.
4. Kết luận: đồng nghĩa / sai nghĩa / vô nghĩa / dịch khung.

> [!vi-du] Ví dụ 6
> Một đoạn mạch khuôn của gene ở vi khuẩn: 3'-TAC CTT AAC GGA ATT-5'. Cho bảng mã rút gọn:
>
> | Codon | AUG | GAA | GUA | UUG | CUU | CCU | CCC | AAU | UGC | UAA, UAG |
> |---|---|---|---|---|---|---|---|---|---|---|
> | Amino acid | Met | Glu | Val | Leu | Leu | Pro | Pro | Asn | Cys | KT |
>
> Xác định trình tự amino acid của đoạn polypeptide bình thường và trong từng trường hợp đột biến trên **mạch khuôn**: (1) bộ ba thứ 2 CTT → CAT; (2) bộ ba thứ 3 AAC → ATC; (3) bộ ba thứ 4 GGA → GGG; (4) mất nucleotide C đầu tiên của bộ ba thứ 2.

> [!goi-y] Gợi ý 1
> mRNA bình thường: 5'-AUG GAA UUG CCU UAA-3'. Ở mỗi trường hợp, viết lại codon bị ảnh hưởng (bổ sung với triplet mới).

> [!goi-y] Gợi ý 2
> Trường hợp (4): mất một nucleotide → mRNA mất nucleotide G ở đầu codon thứ 2. Viết lại cả đoạn mRNA phía sau rồi chia bộ ba lại từ AUG.

> [!loi-giai] Lời giải
> Bình thường: mRNA 5'-AUG GAA UUG CCU UAA-3' → **Met – Glu – Leu – Pro** (UAA kết thúc).
>
> (1) CTT → CAT: codon GAA → **GUA** → Met – **Val** – Leu – Pro → **sai nghĩa**.
>
> (2) AAC → ATC: codon UUG → **UAG** (kết thúc) → **Met – Glu** → **vô nghĩa**, chuỗi ngắn lại.
>
> (3) GGA → GGG: codon CCU → **CCC**, vẫn là Pro → Met – Glu – Leu – Pro → **đồng nghĩa**.
>
> (4) mRNA mới: 5'-AUG AAU UGC CUU AA…-3' → **Met – Asn – Cys – Leu – …** → **dịch khung**: mọi amino acid sau Met đều đổi; bộ ba kết thúc UAA cũ bị "phá" nên chuỗi còn kéo dài tới khi gặp bộ ba kết thúc khác.

*Bẫy:* áp đột biến lên mạch khuôn nhưng quên lấy bổ sung khi viết codon; với dịch khung, chỉ đổi một amino acid rồi dừng (sai — phải chia lại **toàn bộ** phần phía sau); thấy hai codon khác nhau (UUG, CUU) liền cho là hai amino acid khác nhau mà không tra bảng (cả hai đều là Leu).

### Dạng 3. Cơ chế phát sinh: số lần tái bản, số gene đột biến

*Nhận biết:* đề cho tác nhân (5-BU, base dạng hiếm G*…) và số lần tái bản; hỏi dạng đột biến, số lần tái bản tối thiểu, hoặc số gene đột biến tạo ra.

*Phương pháp:*
1. Vẽ cây tái bản: mỗi phân tử DNA tách hai mạch, **mỗi mạch** làm khuôn tạo một DNA con.
2. Chỉ theo dõi **mạch mang base bất thường** và các mạch "con cháu" của nó; các mạch khác cho DNA bình thường.
3. Đếm số DNA mang cặp mới ở cả hai mạch (gene đột biến) ở lần tái bản cần hỏi.

| Tác nhân | Dạng đột biến | Số lần tái bản tối thiểu |
|---|---|---|
| 5-BU | A – T → G – C | 3 |
| G* (G dạng hiếm) | G – C → A – T | 2 |

> [!vi-du] Ví dụ 7
> Một phân tử DNA tái bản 4 lần. Ở lần tái bản thứ nhất, một phân tử 5-BU được lắp vào mạch mới, đối diện với một nucleotide loại A; từ lần tái bản thứ hai trở đi môi trường không còn 5-BU, và mỗi khi làm khuôn, 5-BU đều bắt cặp với G. Theo lí thuyết, sau 4 lần tái bản có bao nhiêu phân tử DNA mang gene đột biến (cặp G – C ở vị trí đang xét)?

> [!goi-y] Gợi ý 1
> Lần 1 cho 2 DNA: một DNA A – 5-BU, một DNA bình thường. Chỉ DNA có 5-BU mới "sinh ra" đột biến. Mạch A của nó cho con cháu bình thường.

> [!goi-y] Gợi ý 2
> Lần 2: mạch 5-BU tạo DNA G – 5-BU. Từ đây, mạch G tạo ra DNA G – C; DNA G – C tái bản tiếp chỉ sinh ra G – C. Còn mạch 5-BU mỗi lần lại tạo một DNA G – 5-BU mới.

> [!loi-giai] Lời giải
> - Sau lần 2: 1 DNA G – 5-BU (tiền đột biến), 3 DNA bình thường.
> - Sau lần 3: DNA G – 5-BU tách mạch → 1 DNA **G – C** + 1 DNA G – 5-BU.
> - Sau lần 4: DNA G – C → 2 DNA G – C; DNA G – 5-BU → 1 DNA **G – C** mới + 1 DNA G – 5-BU.
>
> Số DNA mang gene đột biến = 2 + 1 = **3** (trong tổng 2^4^ = 16 DNA; còn 1 DNA chứa 5-BU và 12 DNA bình thường).
>
> Nhận xét: với giả thiết như trên, sau k lần tái bản (k ≥ 2) có $2^{k-2} - 1$ gene đột biến.

> [!bay] Công thức chỉ đúng với giả thiết của đề
> Công thức trên cần đủ ba điều: chỉ **một** phân tử 5-BU được lắp vào ở **lần tái bản thứ nhất**; sau đó môi trường **không còn** 5-BU; và **mỗi lần** làm khuôn, 5-BU đều bắt cặp với G. Đây là giả thiết mà các đề thi thường dùng.
>
> Nếu đề cho giả thiết khác thì phải vẽ lại cây tái bản. Ví dụ, 5-BU chỉ bắt cặp với G **một lần** (ở lần tái bản thứ 2), sau đó lại bắt cặp với A. Khi đó chỉ mạch G sinh ra gene đột biến, nên số gene đột biến là $2^{k-3}$ (k ≥ 3).

*Bẫy:* tính cả DNA G – 5-BU là gene đột biến (nó mới là **tiền đột biến**, chưa phải cặp G – C hoàn chỉnh); quên rằng mạch A ban đầu vẫn cho các DNA bình thường.

> [!meo] Câu Đúng/Sai về đột biến gene
> Gặp các nhận định dạng "luôn", "mọi", "tất cả" (ví dụ "đột biến gene **luôn** làm thay đổi chuỗi polypeptide", "đột biến gene **luôn** có hại", "mọi đột biến gene đều được biểu hiện ngay thành thể đột biến") → gần như chắc chắn **Sai**. Hãy tìm một phản ví dụ: đột biến đồng nghĩa, đột biến ở intron, đột biến lặn ở thể dị hợp, HbS ở vùng sốt rét.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Đột biến gene | thay đổi trình tự nucleotide trong gene; đột biến điểm: liên quan **một cặp** nucleotide |
| Thể đột biến | cá thể mang gene đột biến **đã biểu hiện** ra kiểu hình |
| Dạng (theo cơ chế) | thay thế; thêm; mất một cặp nucleotide |
| Hậu quả lên polypeptide | thay thế → đồng nghĩa / sai nghĩa / vô nghĩa; thêm, mất → dịch khung |
| Phân loại khác | trội / lặn; có lợi / có hại / trung tính; có / không đổi trình tự amino acid |
| Nguyên nhân | tự phát (sai sót tái bản); vật lí (UV; tia X, γ → chủ yếu đột biến NST); hoá học (5-BU, HNO~2~, EMS, acridine, dioxin); sinh học (virus) |
| Cơ chế thêm/mất | nucleotide làm khuôn 2 lần / không làm khuôn; UV nối hai T kề nhau trên một mạch; chất chèn vào DNA |
| Cơ chế thay thế | chất tương tự base: 5-BU → A – T thành G – C qua 3 lần tái bản (lần 2: tiền đột biến) |
| Vai trò | nghiên cứu (chức năng gene, trội/lặn, cùng gene hay khác gene); chọn giống (súp lơ, lợn siêu nạc); tiến hoá (nguyên liệu sơ cấp, *FOXP2*, ốc *Bradybaena*) |
| Phòng tránh | tránh UV, hoá chất độc, khói thuốc, thực phẩm mốc/cháy; tiêm vaccine viêm gan B, HPV |

**Sơ đồ chung:** tác nhân (hoặc sai sót tự phát) → biến đổi một mạch (tiền đột biến) → không được sửa → tái bản → đột biến gene (allele mới) → mRNA đổi → chuỗi polypeptide đổi (hoặc không) → có thể biểu hiện thành thể đột biến.

**Công thức:** $\Delta L = \pm 0{,}34$ nm khi thêm/mất một cặp; $\Delta H \in \{0;\ \pm 1\}$ khi thay thế, $\pm 2$ (A – T) hoặc $\pm 3$ (G – C) khi thêm/mất; cặp allele tái bản k lần: $X_{mt} = (X_1 + X_2)(2^k - 1)$.
