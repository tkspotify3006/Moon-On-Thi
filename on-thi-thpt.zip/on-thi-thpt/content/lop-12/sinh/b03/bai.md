---
title: Điều hoà biểu hiện gene
thoi-gian: 40 phút
muc-tieu:
  - Nêu được điều hoà biểu hiện gene là gì và vì sao tế bào cần "bật/tắt" gene đúng lúc, đúng lượng.
  - Trình bày được thí nghiệm của Monod và Jacob trên vi khuẩn E. coli và kết luận rút ra từ thí nghiệm.
  - Mô tả được cấu trúc operon lac (promoter, operator, các gene lacZ, lacY, lacA) và vai trò của gene điều hoà lacI.
  - Giải thích được hoạt động của operon lac khi môi trường không có và có lactose; dự đoán được biểu hiện của operon khi đột biến ở gene điều hoà, operator, promoter hoặc gene cấu trúc.
  - Phân tích được ý nghĩa của điều hoà biểu hiện gene đối với tế bào và đối với quá trình phát triển cá thể.
  - Nêu được một số ứng dụng của điều hoà biểu hiện gene trong y dược, trồng trọt, chăn nuôi.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Điều hoà biểu hiện gene** là điều khiển để gene có được biểu hiện hay không, biểu hiện **lúc nào** và tạo ra **bao nhiêu** sản phẩm, phù hợp với nhu cầu của tế bào.
> 2. **Operon *lac*** của *E. coli* gồm **promoter (P)** – **operator (O)** – ba gene cấu trúc ***lacZ, lacY, lacA***. Gene điều hoà ***lacI*** nằm **ngoài** operon, luôn tạo ra **protein ức chế**.
> 3. **Không có lactose**: protein ức chế bám vào **O** → RNA polymerase không phiên mã được → ba gene cấu trúc **"tắt"**.
> 4. **Có lactose**: đồng phân của lactose bám vào protein ức chế làm nó **đổi cấu hình**, rời khỏi O → RNA polymerase phiên mã ba gene thành **một mRNA chung** → ba gene cấu trúc **luôn có số lần phiên mã bằng nhau**.
> 5. Ý nghĩa: **tiết kiệm năng lượng**, giúp tế bào **thích nghi** với môi trường, giúp tế bào **biệt hoá** trong phát triển cá thể; trục trặc điều hoà có thể gây **ung thư**, dị dạng.

> [!nen-tang] Nhớ lại từ Bài 2
> - Mỗi gene có **vùng điều hoà** (chứa **promoter** — nơi RNA polymerase bám vào để khởi động phiên mã), **vùng mã hoá** và **vùng kết thúc**.
> - Ở **vi khuẩn**, nhiều gene có chức năng liên quan thường **xếp liền nhau** và **dùng chung một vùng điều hoà** → được phiên mã cùng lúc thành một mRNA.
> - Theo chức năng, có **gene cấu trúc** (sản phẩm tham gia cấu tạo hoặc chức năng của tế bào, ví dụ enzyme) và **gene điều hoà** (sản phẩm điều khiển sự biểu hiện của gene khác).
> - Vi khuẩn **không có màng nhân**, gene **không phân mảnh** → mRNA vừa được phiên mã đã có thể được ribosome bám vào dịch mã ngay.
>
> Bài này trả lời câu hỏi: gene **có** đó, nhưng **khi nào** nó được phiên mã?

## 1. Điều hoà biểu hiện gene là gì?

### 1.1. Tế bào không "mở" tất cả gene cùng lúc

Mỗi tế bào người chứa khoảng 21 300 gene mã hoá protein (Bài 2), nhưng **tại một thời điểm, chỉ một phần** trong số đó hoạt động. Tế bào gan và tế bào thần kinh của em có **cùng một bộ gene**, vậy mà tế bào gan tạo ra enzyme khử độc, còn tế bào thần kinh tạo chất dẫn truyền thần kinh. Khác nhau là vì mỗi loại tế bào **"bật" những nhóm gene khác nhau**.

Hãy hình dung bộ gene như một **thư viện công thức nấu ăn**. Nhà bếp (tế bào) không nấu tất cả món mỗi ngày — chỉ nấu món cần, đúng lúc, đúng lượng. Cơ chế quyết định "hôm nay nấu món nào, nấu bao nhiêu" chính là **điều hoà biểu hiện gene**.

**Điều hoà biểu hiện gene** (còn gọi là điều hoà hoạt động gene) là quá trình điều khiển để gene **có được biểu hiện hay không**, biểu hiện **vào lúc nào** và tạo ra **lượng sản phẩm bao nhiêu**, phù hợp với nhu cầu của tế bào và điều kiện môi trường.

**Vì sao phải điều hoà?** Tổng hợp protein rất tốn kém. Theo SGK (tr. 20), vi khuẩn *E. coli* dùng tới khoảng **90%** lượng ATP nó tạo ra cho việc tổng hợp protein. Nếu tế bào sản xuất cả những enzyme không dùng đến thì năng lượng và nguyên liệu sẽ bị lãng phí rất lớn.

### 1.2. Điều hoà diễn ra ở những cấp độ nào? (mở rộng ngoài SGK)

Sản phẩm của gene đi qua nhiều bước: DNA → (phiên mã) → mRNA → (dịch mã) → protein. **Ở bước nào tế bào cũng có thể điều chỉnh**, vì vậy người ta thường chia các cấp độ điều hoà như sau:

| Cấp độ | Tế bào điều chỉnh điều gì | Ví dụ |
|---|---|---|
| Trước phiên mã | Mức độ "mở" của nhiễm sắc thể: đoạn DNA co xoắn chặt thì RNA polymerase khó tiếp cận | gắn nhóm methyl vào DNA làm gene "im lặng" (xem Em có biết, mục 3) |
| **Phiên mã** | Gene có được phiên mã không, phiên mã nhiều hay ít | **operon *lac*** (mục 2) |
| Sau phiên mã | Chế biến mRNA (cắt intron, nối exon…), thời gian tồn tại của mRNA | RNA nhỏ (miRNA) làm mRNA bị phân huỷ (Bài 2) |
| Dịch mã | mRNA có được ribosome dịch mã không, dịch mã nhiều hay ít | hồng cầu non chỉ dịch mã mạnh mRNA của globin khi có đủ nhân heme |
| Sau dịch mã | Protein có được hoạt hoá, giữ lại hay bị phân giải | insulin được tạo ra ở dạng tiền chất, phải cắt bớt một đoạn mới có hoạt tính |

- Ở **sinh vật nhân sơ** (vi khuẩn), điều hoà chủ yếu diễn ra ở **cấp độ phiên mã** — và operon *lac* là ví dụ điển hình.
- Ở **sinh vật nhân thực**, điều hoà phức tạp hơn nhiều, diễn ra ở **nhiều cấp độ** (DNA nằm trong nhân, liên kết với histone, gene phân mảnh, mRNA phải chế biến…).

> [!bay]
> SGK Kết nối tri thức không có mục riêng về "các cấp độ điều hoà", nhưng đề thi đôi khi hỏi: "Ở sinh vật nhân sơ, điều hoà hoạt động gene diễn ra **chủ yếu** ở cấp độ nào?" → **phiên mã**. Đừng chọn "dịch mã" chỉ vì thấy protein là sản phẩm cuối cùng.

## 2. Thí nghiệm phát hiện ra operon *lac* ở vi khuẩn *E. coli*

Những người tiên phong nghiên cứu điều hoà hoạt động gene là hai nhà khoa học người Pháp **Jacques Monod** và **François Jacob**. Vào những năm 1950, họ làm việc với vi khuẩn đường ruột *E. coli* và đặt câu hỏi: **vì sao chỉ khi có đường lactose, vi khuẩn mới tạo ra các enzyme phân giải lactose?**

### 2.1. Thí nghiệm của Monod và Jacob

**Bối cảnh.** *E. coli* "thích" dùng đường đơn giản. Lactose (đường sữa, một disaccharide) chỉ được dùng khi có mặt trong môi trường. Muốn dùng lactose, vi khuẩn cần ba enzyme:

| Enzyme | Chức năng |
|---|---|
| **β-galactosidase** | phân giải lactose |
| **permease** | vận chuyển lactose vào tế bào |
| **transacetylase** | (về sau mới biết) tham gia khử độc cho tế bào |

**Bố trí thí nghiệm** (đọc SGK tr. 18 để đối chiếu):

- **Lô đối chứng:** nuôi *E. coli* trong môi trường **không có lactose**, có các **amino acid đánh dấu phóng xạ**.
- **Lô thí nghiệm:** nuôi *E. coli* trong môi trường **có lactose**, cũng có amino acid đánh dấu phóng xạ.
- Sau đó đo lượng ba enzyme **có đánh dấu phóng xạ** trong tế bào.

**Vì sao phải dùng amino acid đánh dấu phóng xạ?** Vì protein **mới được tổng hợp** trong thời gian thí nghiệm sẽ lấy các amino acid này làm nguyên liệu nên **mang dấu phóng xạ**. Đo lượng enzyme phóng xạ tức là đo **lượng enzyme tế bào vừa mới tạo ra**, chứ không lẫn với enzyme có sẵn từ trước. Đây là cách "chụp ảnh" hoạt động của gene.

![Hình 1. Kết quả thí nghiệm của Monod và Jacob (sơ đồ minh hoạ): lô có lactose tạo ra lượng lớn cả ba enzyme mới](hinh-1-thi-nghiem.svg)

**Kết quả:**
- Lô đối chứng: ba enzyme đánh dấu phóng xạ xuất hiện với lượng **không đáng kể**.
- Lô thí nghiệm: lượng cả ba enzyme **tăng mạnh**.

**Kết luận:** lactose đã **kích hoạt** tế bào tổng hợp **đồng thời** cả ba enzyme β-galactosidase, permease và transacetylase.

Tiếp tục dùng nhiều **dòng đột biến** khác nhau, Monod và Jacob xác định được **ba gene quy định ba enzyme này nằm liền nhau** trên một vùng của phân tử DNA. Từ đó, hai ông đề xuất **thuyết operon** để giải thích cơ chế điều hoà biểu hiện gene ở vi khuẩn.

> [!em-co-biet]
> Với phát hiện này, Monod và Jacob (cùng André Lwoff) nhận giải Nobel Sinh lí học hoặc Y học năm 1965. Operon *lac* trở thành mô hình đầu tiên giải thích được **gene được bật/tắt như thế nào** — nền móng cho cả ngành sinh học phân tử về điều hoà gene sau này.

### 2.2. Cấu trúc operon *lac*

**Operon** là một nhóm gene cấu trúc nằm liền nhau, có chức năng liên quan, **cùng chịu sự điều khiển của một vùng điều hoà chung** nên được phiên mã cùng lúc.

**Operon *lac*** gồm hai phần:

| Thành phần | Kí hiệu | Vai trò |
|---|---|---|
| **Promoter** (vùng khởi động) | P | nơi **RNA polymerase** nhận biết, bám vào và **khởi động phiên mã** các gene cấu trúc |
| **Operator** (vùng vận hành) | O | nơi **protein ức chế** bám vào để **ngăn cản phiên mã** |
| Gene cấu trúc ***lacZ*** | Z | quy định enzyme **β-galactosidase** |
| Gene cấu trúc ***lacY*** | Y | quy định enzyme **permease** |
| Gene cấu trúc ***lacA*** | A | quy định enzyme **transacetylase** |

P và O hợp thành **vùng điều hoà** của operon; ba gene Z, Y, A là **các gene cấu trúc**.

Operon *lac* được điều khiển bởi **gene điều hoà *lacI*** (sách cũ và nhiều đề thi kí hiệu là **R**). Gene này quy định **protein ức chế** (SGK kí hiệu lacI, không in nghiêng).

> [!bay] Ba điều đề thi rất hay cài bẫy
> 1. **Gene điều hoà *lacI* KHÔNG thuộc operon *lac*.** Nó nằm ở vị trí khác trên DNA, có promoter riêng. Operon *lac* chỉ gồm **P, O, Z, Y, A**.
> 2. **Protein ức chế bám vào O**, không phải vào P; **RNA polymerase bám vào P**, không phải vào O.
> 3. **Lactose không bám vào DNA.** Lactose (chính xác là đồng phân của nó) bám vào **protein ức chế**.

> [!meo] Quy ước viết tên
> Tên **gene** viết **in nghiêng** (*lacZ*, *lacI*); **protein** là sản phẩm của gene được kí hiệu bằng tên gene nhưng **không in nghiêng** (protein ức chế lacI). Nhìn kiểu chữ là biết đề đang nói về gene hay protein.

### 2.3. Operon *lac* hoạt động thế nào?

Điều quan trọng nhất cần nhớ: **gene điều hoà *lacI* luôn hoạt động**, dù có hay không có lactose. Nghĩa là tế bào **luôn có sẵn** protein ức chế. Câu hỏi chỉ là: protein ức chế đó **có bám được vào O hay không**.

**a) Khi môi trường không có lactose**

![Hình 2. Operon lac khi môi trường không có lactose (sơ đồ tự vẽ, đối chiếu SGK Hình 3.1)](hinh-2-khong-lactose.svg)

1. Gene *lacI* được phiên mã, dịch mã tạo ra **protein ức chế**.
2. Protein ức chế **liên kết với operator (O)**.
3. Protein ức chế nằm chắn ở O khiến **RNA polymerase không thể liên kết với promoter** để tiến hành phiên mã.
4. → Ba gene *lacZ, lacY, lacA* **không được phiên mã** → không tạo ra ba enzyme.

Hợp lí chưa? Không có lactose thì tạo enzyme phân giải lactose để làm gì — tắt đi để **tiết kiệm năng lượng**.

**b) Khi môi trường có lactose**

![Hình 3. Operon lac khi môi trường có lactose (sơ đồ tự vẽ, đối chiếu SGK Hình 3.2)](hinh-3-co-lactose.svg)

1. Một lượng nhỏ lactose vào tế bào được chuyển thành **đồng phân của lactose**.
2. Đồng phân này **liên kết với protein ức chế**, làm protein ức chế **thay đổi cấu hình** (hình dạng không gian).
3. Protein ức chế bị biến dạng **không còn liên kết được với operator** → rời khỏi O.
4. RNA polymerase **liên kết với promoter** và phiên mã ba gene *lacZ, lacY, lacA* thành **một phân tử mRNA chung**.
5. Vì vi khuẩn không có màng nhân, gene không phân mảnh, **mRNA được phiên mã đến đâu thì ribosome dịch mã đến đó** → tạo ra β-galactosidase, permease và transacetylase để vận chuyển và phân giải lactose.

**c) Khi lactose bị phân giải hết**

Không còn đồng phân lactose bám vào protein ức chế → protein ức chế **trở lại cấu hình ban đầu**, lại bám vào O → operon **tắt**. Tế bào chỉ sản xuất enzyme **khi cần và trong lúc cần**. Chất có tác dụng "bật" operon như lactose được gọi là **chất cảm ứng**.

> [!ghi-nho] So sánh hai trạng thái
> | | Không có lactose | Có lactose |
> |---|---|---|
> | Gene điều hoà *lacI* | **phiên mã**, tạo protein ức chế | **phiên mã**, tạo protein ức chế |
> | Protein ức chế | hoạt động, **bám vào O** | bị đồng phân lactose bám vào, **đổi cấu hình**, không bám được O |
> | RNA polymerase | không phiên mã được | bám P, phiên mã Z, Y, A |
> | Ba enzyme | không tạo ra (lượng không đáng kể) | tạo ra nhiều |

**Vì sao môi trường có lactose thì protein ức chế lại không bám vào operator?** (Dừng lại và suy ngẫm, SGK tr. 20.) Vì protein ức chế có **hai vị trí**: một vị trí nhận biết trình tự O trên DNA và một vị trí bám đồng phân của lactose. Khi đồng phân lactose bám vào, toàn bộ phân tử protein **thay đổi hình dạng**, vị trí nhận biết O bị "méo" đi, không còn khớp với trình tự O nữa — giống chìa khoá bị cong không tra vừa ổ khoá.

> [!vi-du] Ví dụ 1
> Sắp xếp các sự kiện sau theo đúng trình tự xảy ra khi đưa *E. coli* từ môi trường không có lactose sang môi trường có lactose:
> - (1) RNA polymerase bám vào promoter và phiên mã các gene Z, Y, A.
> - (2) Đồng phân của lactose liên kết với protein ức chế.
> - (3) Protein ức chế thay đổi cấu hình, rời khỏi operator.
> - (4) Ribosome dịch mã tạo ra β-galactosidase, permease, transacetylase.

> [!goi-y] Gợi ý 1
> Muốn RNA polymerase phiên mã được thì vật cản ở O phải bị gỡ ra trước. Cái gì làm vật cản rời đi?

> [!goi-y] Gợi ý 2
> Lactose → bám protein ức chế → protein ức chế đổi dạng → … → … .

> [!loi-giai] Lời giải
> Bước 1: Lactose (đồng phân) phải bám vào protein ức chế trước: **(2)**.
>
> Bước 2: Protein ức chế đổi cấu hình, rời O: **(3)**.
>
> Bước 3: O được giải phóng, RNA polymerase phiên mã Z, Y, A: **(1)**.
>
> Bước 4: mRNA được dịch mã thành ba enzyme: **(4)**.
>
> Trình tự đúng: **(2) → (3) → (1) → (4)**.

### 2.4. Vì sao ba gene cấu trúc luôn có số lần phiên mã bằng nhau?

Ba gene Z, Y, A **dùng chung một promoter và một operator**. Mỗi lần RNA polymerase khởi động ở P, nó chạy liền một mạch qua Z, Y, A và tạo **một phân tử mRNA chung** mang thông tin của cả ba gene. Vì vậy:

- Gene Z phiên mã **k** lần thì gene Y và gene A cũng phiên mã đúng **k** lần.
- Số phân tử mRNA mang thông tin của Z = số mang thông tin của Y = số mang thông tin của A = k.
- Gene điều hoà *lacI* có promoter **riêng** nên số lần phiên mã của nó **không liên quan** tới số lần phiên mã của Z, Y, A.

> [!bay]
> - "Gene điều hoà phiên mã 10 lần thì gene Z cũng phiên mã 10 lần" → **sai**. *lacI* không thuộc operon.
> - "Ba gene Z, Y, A có số lần **phiên mã** bằng nhau" → **đúng**. Nhưng số **chuỗi polypeptide** tạo ra từ mỗi gene **chưa chắc** bằng nhau (mỗi đoạn mã hoá trên mRNA có thể được số ribosome dịch mã khác nhau) — trừ khi đề cho giả thiết.
> - Ở trạng thái "tắt", vẫn có một lượng **rất nhỏ** enzyme được tạo ra (SGK: "lượng không đáng kể"), vì thỉnh thoảng protein ức chế rời khỏi O trong thoáng chốc. Đề thi phổ thông thường coi là "không phiên mã".

> [!vi-du] Ví dụ 2
> Trong một tế bào *E. coli* nuôi ở môi trường có lactose, người ta đếm được trong một khoảng thời gian, gene *lacY* đã phiên mã 15 lần, gene *lacI* phiên mã 4 lần. Hỏi trong thời gian đó, gene *lacZ* và gene *lacA* mỗi gene phiên mã bao nhiêu lần?

> [!goi-y] Gợi ý 1
> Gene nào nằm trong operon và dùng chung promoter với *lacY*?

> [!goi-y] Gợi ý 2
> Con số 4 của *lacI* có liên quan gì không?

> [!loi-giai] Lời giải
> *lacZ*, *lacY*, *lacA* cùng thuộc operon, được phiên mã chung thành một mRNA → mỗi lần phiên mã là cả ba gene cùng được phiên mã.
>
> Vậy *lacZ* phiên mã **15 lần**, *lacA* phiên mã **15 lần**. Số 4 của *lacI* là dữ kiện gây nhiễu (gene điều hoà có promoter riêng).

### 2.5. Dự đoán hậu quả khi operon *lac* bị đột biến

Đây là phần đề thi khai thác nhiều nhất. Cách nghĩ luôn là: **đột biến làm hỏng "bộ phận" nào → bộ phận đó còn làm được nhiệm vụ không → hậu quả cho phiên mã Z, Y, A**.

| Vị trí đột biến | Bộ phận hỏng thế nào | Không có lactose | Có lactose |
|---|---|---|---|
| (Bình thường) | — | **không** phiên mã | **có** phiên mã |
| Gene điều hoà *lacI* (hoặc promoter của *lacI*) | không tạo ra protein ức chế, **hoặc** protein ức chế không bám được O | **có** phiên mã | **có** phiên mã |
| Gene điều hoà *lacI* | protein ức chế vẫn bám O nhưng **không liên kết được với lactose** | **không** phiên mã | **không** phiên mã |
| Operator O | protein ức chế **không bám được** vào O | **có** phiên mã | **có** phiên mã |
| Promoter P | RNA polymerase **không bám được** vào P | **không** phiên mã | **không** phiên mã |
| Một gene cấu trúc (ví dụ *lacA*) | chỉ hỏng enzyme do gene đó quy định | **không** phiên mã | **có** phiên mã; hai gene còn lại vẫn tạo enzyme bình thường, enzyme của gene bị đột biến có thể mất chức năng |

**Giải thích hai dòng quan trọng:**

- **Đột biến làm hỏng O** → protein ức chế "không có chỗ đậu" → không gì chặn RNA polymerase → operon **luôn bật**, kể cả khi không có lactose. Tế bào lãng phí năng lượng.
- **Đột biến làm hỏng P** → RNA polymerase "không có bến xuất phát" → operon **luôn tắt**, kể cả khi có lactose. Vi khuẩn không dùng được lactose.

Bài tập SGK tr. 22 hỏi: môi trường không có lactose mà operon *lac* vẫn hoạt động thì có thể hỏng bộ phận nào? Theo bảng, có hai khả năng: **gene điều hoà *lacI*** (không tạo được protein ức chế, hoặc protein ức chế không bám được O) **hoặc operator O** (protein ức chế không bám được). Hỏng P hay hỏng một gene cấu trúc đều **không** giải thích được.

> [!meo] Nhớ nhanh bằng câu "O hỏng – mở mãi; P hỏng – tắt mãi"
> - Hỏng **"cái phanh"** (protein ức chế hoặc chỗ bám O) → xe chạy liên tục (luôn phiên mã).
> - Hỏng **"cái máy"** (P, chỗ bám của RNA polymerase) → xe không bao giờ chạy (không phiên mã).
> - Hỏng **"chỗ nhận tín hiệu lactose"** của protein ức chế → phanh bị kẹt cứng (không phiên mã).

> [!bay]
> - Đột biến ở một gene cấu trúc **không làm thay đổi** việc operon bật/tắt (theo cách xét của đề thi phổ thông) — chỉ làm enzyme do gene đó quy định có thể bị thay đổi.
> - Đột biến **thay thế cặp nucleotide** trong *lacI* có thể **không** làm thay đổi protein ức chế (do tính thoái hoá của mã di truyền — Bài 2). Khi đó operon vẫn hoạt động bình thường. Câu "mọi đột biến ở gene điều hoà đều làm operon phiên mã liên tục" là **sai**.

> [!vi-du] Ví dụ 3
> Một chủng *E. coli* đột biến được nuôi trong hai môi trường. Kết quả đo lượng β-galactosidase mới tạo ra:
>
> | Môi trường | Chủng bình thường | Chủng đột biến |
> |---|---|---|
> | Không có lactose | rất ít | nhiều |
> | Có lactose | nhiều | nhiều |
>
> a) Chủng đột biến có thể bị đột biến ở những vị trí nào của hệ thống operon *lac*?
> b) Nếu đột biến nằm ở promoter của operon thì kết quả trên có xảy ra không?

> [!goi-y] Gợi ý 1
> Không có lactose mà vẫn tạo nhiều enzyme → "cái phanh" đã hỏng. Phanh gồm những bộ phận nào?

> [!goi-y] Gợi ý 2
> Phanh gồm: protein ức chế (do *lacI* tạo ra) và chỗ để nó bám (O).

> [!loi-giai] Lời giải
> a) Chủng đột biến luôn phiên mã Z, Y, A dù không có lactose → protein ức chế không ngăn được phiên mã. Có thể do:
> - **gene điều hoà *lacI*** (hoặc promoter của *lacI*) bị đột biến → không tạo protein ức chế, hoặc protein ức chế không bám được O;
> - **operator O** bị đột biến → protein ức chế không bám được.
>
> b) Nếu promoter P của operon hỏng thì RNA polymerase không bám được, operon **luôn tắt** → cả hai môi trường đều rất ít enzyme. Kết quả của bảng **không** xảy ra.

## 3. Ý nghĩa và ứng dụng thực tiễn của điều hoà biểu hiện gene

### 3.1. Ý nghĩa

**a) Đối với tế bào**

- **Tiết kiệm năng lượng và nguyên liệu.** Tế bào chỉ tổng hợp sản phẩm của gene **khi cần**, với **lượng vừa đủ**. Operon *lac* là ví dụ: không có lactose thì không làm enzyme phân giải lactose.
- **Thích nghi với môi trường thay đổi.** Khi điều kiện thay đổi, tế bào bật những gene phù hợp. Ví dụ: gặp **nhiệt độ cao bất thường**, tế bào kích hoạt các gene tạo **protein chống sốc nhiệt** (giúp các protein khác không bị biến tính); **tế bào miễn dịch** chỉ bật gene tổng hợp **kháng thể** khi tiếp xúc với mầm bệnh.

**Ý nghĩa của việc điều hoà nhiều gene cùng lúc kiểu operon** (Luyện tập SGK tr. 22): ba enzyme cùng phục vụ **một việc** (dùng lactose) nên cần có mặt **cùng lúc**: có permease đưa lactose vào mà không có β-galactosidase phân giải thì vô ích. Gom ba gene dưới **một "công tắc"** giúp:
- chỉ cần một tín hiệu (lactose) là bật cả ba → phản ứng **nhanh, đồng bộ**;
- ba enzyme được tạo ra **cùng lúc, cùng tỉ lệ**, không thiếu, không thừa;
- tiết kiệm: chỉ cần một vùng điều hoà, một protein ức chế cho cả ba gene.

**b) Đối với quá trình phát triển cá thể (sinh vật đa bào)**

Từ **một hợp tử**, qua nguyên phân tạo ra hàng nghìn tỉ tế bào với **cùng một hệ gene**. Vậy mà chúng trở thành tế bào cơ, tế bào da, tế bào thần kinh… Vì sao?

- Ngay từ những lần phân chia đầu, các tế bào con nhận **các tín hiệu điều hoà khác nhau** từ tế bào chất của hợp tử (tế bào chất không phân chia đồng đều).
- Trong quá trình phát triển, mỗi tế bào lại nhận tín hiệu từ **các tế bào xung quanh**.
- → Mỗi loại tế bào **bật/tắt các nhóm gene khác nhau** → tạo ra các tế bào **chuyên hoá** (biệt hoá) khác nhau, hình thành mô, cơ quan, cơ thể hoàn chỉnh.

Nếu điều hoà trong phát triển bị **trục trặc**, phôi có thể chết hoặc cơ thể sinh ra bị **dị dạng**.

**Ví dụ về ung thư.** Ở người, gene **proto-oncogene** bình thường tạo ra lượng sản phẩm **vừa đủ** (thường là protein kích thích tế bào phân chia). Khi gene này **hoạt động quá mức**, nó trở thành **gene gây ung thư (oncogene)**. Sản phẩm dư thừa kích thích tế bào **phân chia không kiểm soát** → khối u, bệnh ung thư. Đây là ví dụ cho thấy: gene không hỏng về trình tự sản phẩm, chỉ **điều hoà sai về lượng** cũng có thể gây bệnh.

> [!bay]
> "Các tế bào khác nhau trong cùng một cơ thể có hệ gene khác nhau nên có chức năng khác nhau" → **sai**. Chúng có **cùng hệ gene**; khác nhau là ở **những gene nào được biểu hiện**.

> [!vi-du] Ví dụ 4
> Tế bào hồng cầu non của người tổng hợp rất nhiều hemoglobin, còn tế bào tuyến tuỵ tổng hợp insulin. Bạn An cho rằng: "Tế bào hồng cầu non không có gene insulin, tế bào tuyến tuỵ không có gene hemoglobin." Ý kiến này đúng hay sai? Giải thích.

> [!goi-y] Gợi ý 1
> Hai loại tế bào này cùng bắt nguồn từ đâu? Nguyên phân có làm thay đổi bộ gene không?

> [!goi-y] Gợi ý 2
> Nếu bộ gene giống nhau thì điều gì làm sản phẩm khác nhau?

> [!loi-giai] Lời giải
> Ý kiến **sai**. Mọi tế bào sinh dưỡng đều sinh ra từ một hợp tử qua nguyên phân nên có **cùng hệ gene**: tế bào hồng cầu non vẫn có gene insulin, tế bào tuyến tuỵ vẫn có gene hemoglobin.
>
> Sự khác nhau là do **điều hoà biểu hiện gene**: trong hồng cầu non, gene hemoglobin được bật mạnh, gene insulin bị tắt; trong tế bào tuyến tuỵ thì ngược lại. Đây chính là cơ sở của sự **biệt hoá tế bào**.

### 3.2. Ứng dụng thực tiễn

Hiểu được gene **bật/tắt như thế nào**, con người có thể chủ động can thiệp:

| Lĩnh vực | Ứng dụng | Ví dụ |
|---|---|---|
| **Y dược** | Sản xuất thuốc **ức chế sản phẩm của gene gây bệnh** khi gene đó biểu hiện quá mức | Ung thư vú do gene thụ thể estrogen alpha (*ERα*) biểu hiện quá mức → dùng **tamoxifen**, chất ức chế đặc hiệu thụ thể ERα (SGK tr. 21) |
| **Y học** | Nuôi cấy **tế bào gốc**, xử lí để biệt hoá thành các loại tế bào khác nhau (chữa bệnh, thử thuốc) | biệt hoá tế bào gốc thành tế bào cơ tim, tế bào thần kinh để thử tác dụng của thuốc |
| **Y học** | Bổ sung sản phẩm khi gene không tạo đủ | trẻ **lùn bẩm sinh** do thiếu hormone sinh trưởng được điều trị để đạt chiều cao gần bình thường |
| **Trồng trọt** | Chủ động bật/tắt gene ở cây trồng | nuôi cấy tế bào thực vật trong môi trường có **chất hoạt hoá gene** để tế bào phân chia, tái sinh thành cây con; dùng **chế độ chiếu sáng** để điều khiển cây **ra hoa** đúng vụ |
| **Chăn nuôi** | Dùng hormone điều khiển gene quy định giới tính | xử lí trứng **cá rô phi** đã thụ tinh bằng hormone sinh dục đực (testosterone) → gần 100% cá đực, lớn nhanh, nhiều thịt |

> [!ung-dung]
> Nghề trồng thanh long ở Bình Thuận dùng **bóng đèn thắp sáng ban đêm** vào mùa đông. Ánh sáng kéo dài làm cây "tưởng" là ngày dài → bật các gene điều khiển ra hoa → có quả trái vụ, bán được giá cao. Đây chính là ứng dụng "dùng chế độ chiếu sáng để điều khiển gene" mà SGK nhắc tới.

> [!vi-du] Ví dụ 5
> Một bệnh nhân ung thư vú được xét nghiệm thấy tế bào ung thư có **rất nhiều thụ thể estrogen alpha (ERα)**. Bác sĩ chỉ định thuốc tamoxifen. Hãy giải thích cơ sở của chỉ định này dựa trên kiến thức điều hoà biểu hiện gene.

> [!goi-y] Gợi ý 1
> "Rất nhiều thụ thể ERα" cho thấy gene *ERα* đang biểu hiện như thế nào?

> [!goi-y] Gợi ý 2
> Tamoxifen tác động vào gene hay vào sản phẩm của gene?

> [!loi-giai] Lời giải
> Bước 1: Lượng thụ thể ERα rất lớn → gene *ERα* **biểu hiện quá mức** (điều hoà bị rối loạn).
>
> Bước 2: Thụ thể ERα nhận tín hiệu estrogen, kích thích tế bào phân chia → quá nhiều thụ thể thì tế bào phân chia mất kiểm soát.
>
> Bước 3: Tamoxifen là chất **ức chế đặc hiệu thụ thể ERα** — nó không sửa gene mà **chặn sản phẩm của gene** → giảm tín hiệu phân chia → kìm hãm khối u.
>
> Kết luận: hiểu được gene nào biểu hiện quá mức giúp chọn đúng thuốc ức chế sản phẩm của gene đó. Bệnh nhân ung thư vú **không** có nhiều ERα thì tamoxifen ít tác dụng — vì vậy phải xét nghiệm trước.

> [!em-co-biet] Thức ăn của mẹ có thể thay đổi biểu hiện gene ở con (SGK tr. 22)
> Một số vị trí cytosine trên DNA có thể được gắn thêm **nhóm methyl (CH~3~)**. Methyl hoá thường làm gene **"im lặng"** mà **không làm thay đổi trình tự nucleotide**. Những thay đổi biểu hiện gene kiểu này có thể truyền cho thế hệ sau và được gọi là **di truyền biểu sinh**. Thí nghiệm trên chuột cho thấy: chuột mẹ mang thai được ăn thức ăn giàu nhóm methyl (như folic acid) sinh con có kiểu hình khác hẳn chuột mẹ ăn thiếu nhóm methyl, dù gene của chuột con giống nhau. Folic acid cũng là vi chất phụ nữ mang thai được khuyên bổ sung (chủ yếu để phòng dị tật ống thần kinh ở thai nhi).

## Dạng bài thi hay gặp

> [!ghi-nho] Chìa khoá chung cho mọi câu về operon *lac*
> 1. Xác định **bộ phận**: *lacI* (ngoài operon) → protein ức chế; P ↔ RNA polymerase; O ↔ protein ức chế; Z, Y, A ↔ ba enzyme.
> 2. Hỏi **"có lactose không?"** → protein ức chế có bám O không?
> 3. Nếu có đột biến: bộ phận đó **mất chức năng gì** → suy ra Z, Y, A **có được phiên mã không**.

### Dạng 1. Đúng/Sai về cấu trúc và cơ chế operon *lac*

*Nhận biết:* "Xét các phát biểu về operon *lac* ở *E. coli*…", "Mô hình cấu trúc operon *lac* gồm…", "Khi môi trường không có lactose thì…".

*Phương pháp:*
1. Gạch chân **chủ ngữ** của câu (gene điều hoà, protein ức chế, RNA polymerase, lactose…) và **nơi tác động** (P hay O).
2. Đối chiếu với bảng "So sánh hai trạng thái" (mục 2.3).
3. Kiểm tra các từ **"luôn", "chỉ khi", "thuộc operon"** — bẫy thường nằm ở đây.

> [!vi-du] Ví dụ 6
> Xét các phát biểu sau về operon *lac* ở *E. coli*:
> - (1) Gene điều hoà *lacI* là một thành phần của operon *lac*.
> - (2) Khi môi trường không có lactose, gene điều hoà vẫn phiên mã tạo ra protein ức chế.
> - (3) Khi môi trường có lactose, lactose liên kết với vùng vận hành O làm RNA polymerase bám được vào promoter.
> - (4) Các gene *lacZ*, *lacY*, *lacA* có số lần phiên mã bằng nhau.
> Có bao nhiêu phát biểu đúng?

> [!goi-y] Gợi ý 1
> Operon *lac* gồm những thành phần nào? *lacI* có nằm trong đó không?

> [!goi-y] Gợi ý 2
> Ở phát biểu (3), lactose bám vào đâu: DNA hay protein?

> [!loi-giai] Lời giải
> - (1) **Sai** — *lacI* nằm ngoài operon; operon *lac* gồm P, O, Z, Y, A.
>
> - (2) **Đúng** — *lacI* luôn hoạt động, có hay không có lactose.
>
> - (3) **Sai** — lactose (đồng phân) bám vào **protein ức chế**, không bám vào O.
>
> - (4) **Đúng** — ba gene dùng chung P, O, được phiên mã chung thành một mRNA.
>
> Có **2** phát biểu đúng.

*Bẫy:* câu đúng một nửa — ví dụ "lactose làm protein ức chế bất hoạt và **bám vào promoter**" (nửa đầu đúng, nửa sau sai). Đọc **đến hết câu**.

### Dạng 2. Dự đoán biểu hiện của operon khi có đột biến

*Nhận biết:* "Một chủng đột biến…", "Nếu vùng vận hành bị đột biến…", "trong trường hợp nào các gene cấu trúc phiên mã ngay cả khi không có lactose?", hoặc cho bảng kết quả đo enzyme ở các chủng.

*Phương pháp:*
1. Xác định bộ phận bị đột biến và **chức năng mất đi** (dùng bảng mục 2.5).
2. Xét **riêng** từng điều kiện: không lactose / có lactose.
3. Với bảng số liệu: so với chủng bình thường, chủng nào "**luôn bật**" (hỏng *lacI* hoặc O), chủng nào "**luôn tắt**" (hỏng P, hoặc protein ức chế không nhận lactose), chủng nào bật/tắt bình thường nhưng một enzyme bị hỏng (đột biến gene cấu trúc).

> [!vi-du] Ví dụ 7
> Người ta phân tích bốn chủng *E. coli* (I, II, III, IV), mỗi chủng mang một đột biến ở một vị trí khác nhau trong số: gene *lacI*, vùng O, vùng P, gene *lacA*. Kết quả đo enzyme (dấu + là có enzyme hoạt động, dấu – là không có hoặc không đáng kể):
>
> | Chủng | β-galactosidase (không lactose) | β-galactosidase (có lactose) | transacetylase (có lactose) |
> |---|---|---|---|
> | I | – | – | – |
> | II | + | + | + |
> | III | – | + | – (có protein nhưng không hoạt động) |
> | IV | + | + | + |
>
> Biết đột biến ở *lacI* làm mất protein ức chế. Chủng nào là đột biến vùng P, chủng nào là đột biến ở gene *lacA*? Có thể phân biệt chủng II và IV chỉ dựa vào bảng này không?

> [!goi-y] Gợi ý 1
> Chủng nào "luôn tắt" cả ba enzyme? Chủng nào bật/tắt bình thường nhưng chỉ hỏng riêng một enzyme?

> [!goi-y] Gợi ý 2
> Mất protein ức chế và hỏng O cho kết quả giống hay khác nhau?

> [!loi-giai] Lời giải
> Bước 1: Chủng I không tạo enzyme kể cả khi có lactose → operon luôn tắt → **đột biến vùng P** (RNA polymerase không bám được).
>
> Bước 2: Chủng III bật/tắt bình thường (không lactose: không có β-galactosidase; có lactose: có), nhưng transacetylase tạo ra không hoạt động → **đột biến gene *lacA***.
>
> Bước 3: Chủng II và IV đều "luôn bật" → một chủng mất protein ức chế (*lacI*), chủng kia hỏng O. Hai kiểu đột biến này cho **cùng kiểu kết quả** trong bảng nên **không phân biệt được** chủng nào là chủng nào chỉ dựa vào số liệu này.

*Bẫy:* nhầm "đột biến P → luôn phiên mã". Nhớ: P là chỗ **RNA polymerase** bám; hỏng P thì **không** phiên mã được.

### Dạng 3. Đọc hình operon

*Nhận biết:* đề cho sơ đồ có các ô đánh số (1), (2), (3)… hoặc chữ cái trên DNA và các phân tử xung quanh, hỏi tên/chức năng.

*Phương pháp:*
1. Tìm **thứ tự trên DNA**: gene điều hoà (thường vẽ tách riêng, có đường nét đứt) – P – O – Z – Y – A.
2. Phân tử bám vào **ô ngay trước các gene cấu trúc** là protein ức chế → ô đó là **O**; phân tử bám ô trước O là **RNA polymerase** → ô đó là **P**.
3. Phân tử nhỏ bám vào protein ức chế → lactose (chất cảm ứng).

> [!vi-du] Ví dụ 8
> Một sơ đồ operon *lac* vẽ trên DNA theo thứ tự từ trái sang phải: đoạn (1) nằm tách riêng, nối bằng nét đứt, rồi đến đoạn (2), đoạn (3), sau đó là ba gene cấu trúc. Một phân tử (4) hình chữ U đang bám ở đoạn (3); một phân tử lớn (5) đứng ở bên trái đoạn (2) nhưng có dấu ✗ trên mũi tên. Hãy gọi tên (1) đến (5) và cho biết môi trường có lactose hay không.

> [!goi-y] Gợi ý 1
> Đoạn nào đứng ngay trước ba gene cấu trúc và là chỗ bám của protein ức chế?

> [!goi-y] Gợi ý 2
> Dấu ✗ nghĩa là phân tử (5) không bám được để phiên mã. Vì sao?

> [!loi-giai] Lời giải
> - (1) gene điều hoà *lacI* (nằm ngoài operon); (2) promoter P; (3) operator O; (4) protein ức chế; (5) RNA polymerase.
>
> Protein ức chế đang bám O, RNA polymerase bị chặn → đây là trạng thái **môi trường không có lactose** (đối chiếu Hình 2).

### Dạng 4. Tính số lần phiên mã, dịch mã của các gene trong operon

*Nhận biết:* "gene Z phiên mã k lần…", "số phân tử mRNA…", "số chuỗi polypeptide…", "số amino acid môi trường cung cấp…".

*Phương pháp:*
1. **Z, Y, A**: số lần phiên mã **bằng nhau** (= số mRNA chung). Gene điều hoà: **độc lập**.
2. Số chuỗi polypeptide của một gene = (số mRNA) × (số ribosome dịch mã đoạn mã hoá của gene đó trên mỗi mRNA).
3. Số amino acid môi trường cung cấp cho **một chuỗi** = $\dfrac{N}{6} - 1$ với N là số nucleotide **hai mạch** của vùng mã hoá (kể cả bộ ba kết thúc) — công thức Bài 2.

> [!vi-du] Ví dụ 9
> Giả sử vùng mã hoá của gene *lacY* có 1 254 cặp nucleotide (kể cả bộ ba kết thúc). Trong một tế bào *E. coli* ở môi trường có lactose, operon *lac* được phiên mã 3 lần; trên mỗi phân tử mRNA, đoạn mã hoá permease được 6 ribosome dịch mã một lần. Tính:
> a) số chuỗi polypeptide permease được tạo ra;
> b) số amino acid môi trường cung cấp để tạo các chuỗi permease đó.

> [!goi-y] Gợi ý 1
> Số phân tử mRNA có đoạn mã hoá permease bằng số lần phiên mã của operon. Mỗi mRNA cho mấy chuỗi permease?

> [!goi-y] Gợi ý 2
> 1 254 cặp nucleotide → N = 2 508 nucleotide. Một chuỗi cần $\dfrac{N}{6} - 1$ amino acid.

> [!loi-giai] Lời giải
> a) Số mRNA = 3; mỗi mRNA cho 6 chuỗi permease → 3 × 6 = **18 chuỗi**.
>
> b) Một chuỗi cần: $\dfrac{2\,508}{6} - 1 = 418 - 1 = 417$ amino acid.
>
> Tổng: 18 × 417 = **7 506** amino acid.

*Bẫy:* dùng số lần phiên mã của gene điều hoà để tính cho Z, Y, A; quên trừ 1 cho bộ ba kết thúc (bộ ba kết thúc không mã hoá amino acid).

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Điều hoà biểu hiện gene | Điều khiển gene có biểu hiện không, lúc nào, bao nhiêu sản phẩm. Nhân sơ: chủ yếu ở cấp phiên mã; nhân thực: nhiều cấp độ |
| Thí nghiệm Monod – Jacob | Có lactose → lượng cả 3 enzyme (đánh dấu phóng xạ) tăng mạnh, **đồng thời** → 3 gene liền nhau, chung một cơ chế điều hoà |
| Cấu trúc operon *lac* | **P** (RNA polymerase bám) – **O** (protein ức chế bám) – ***lacZ*** (β-galactosidase) – ***lacY*** (permease) – ***lacA*** (transacetylase). Gene điều hoà ***lacI*** nằm **ngoài** operon |
| Không có lactose | Protein ức chế bám O → không phiên mã Z, Y, A |
| Có lactose | Đồng phân lactose bám protein ức chế → đổi cấu hình, rời O → phiên mã Z, Y, A thành một mRNA chung → dịch mã ngay |
| Số lần phiên mã | Z = Y = A; *lacI* độc lập, luôn phiên mã |
| Đột biến | Hỏng *lacI* (mất ức chế) hoặc O → **luôn bật**; hỏng P → **luôn tắt**; protein ức chế không nhận lactose → **luôn tắt**; hỏng gene cấu trúc → chỉ hỏng enzyme đó |
| Ý nghĩa | Tiết kiệm năng lượng; thích nghi môi trường; biệt hoá tế bào trong phát triển; rối loạn → ung thư, dị dạng |
| Ứng dụng | Thuốc ức chế sản phẩm gene gây bệnh (tamoxifen), tế bào gốc, điều trị lùn bẩm sinh, cây ra hoa trái vụ, cá rô phi toàn đực |
