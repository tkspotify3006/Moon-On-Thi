---
title: DNA và cơ chế tái bản DNA
thoi-gian: 45 phút
muc-tieu:
  - Mô tả được cấu trúc hoá học của DNA: đơn phân nucleotide, mạch polynucleotide nối bằng liên kết phosphodiester, chiều 5' → 3', chuỗi xoắn kép theo mô hình Watson – Crick (đối song song, nguyên tắc bổ sung, liên kết hydrogen, kích thước).
  - Dựa vào cấu trúc, trình bày được chức năng của DNA: mang, bảo quản và truyền đạt thông tin di truyền; giải thích được vì sao protein không thể là vật chất di truyền.
  - Nêu được ý nghĩa của các cặp kết cặp đặc hiệu A – T và G – C.
  - Phân tích được cơ chế tái bản DNA (điểm khởi đầu, chạc sao chép, vai trò của các enzyme, mạch liên tục – mạch gián đoạn, đoạn Okazaki) theo nguyên tắc bổ sung và bán bảo toàn; so sánh tái bản ở sinh vật nhân sơ và nhân thực.
  - Giải thích được tái bản DNA là quá trình tự sao thông tin di truyền từ tế bào mẹ sang tế bào con, từ thế hệ này sang thế hệ sau.
  - Giải được các dạng bài: tính số nucleotide, chiều dài, khối lượng, số liên kết hydrogen; xác định chiều và trình tự mạch; tính số phân tử con, số mạch mới, số nucleotide môi trường cung cấp sau k lần tái bản (kể cả bài N^15^/N^14^); số đoạn mồi – đoạn Okazaki.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. DNA gồm **hai mạch polynucleotide**; đơn phân là **nucleotide** (đường deoxyribose + nhóm phosphate + một trong 4 base **A, T, G, C**). Trong mỗi mạch, các nucleotide nối nhau bằng **liên kết phosphodiester**, mạch có chiều **5' → 3'**.
> 2. Hai mạch **ngược chiều nhau (đối song song)**, liên kết với nhau theo **nguyên tắc bổ sung**: **A – T bằng 2** liên kết hydrogen, **G – C bằng 3** liên kết hydrogen. Xoắn kép: đường kính **2 nm**, mỗi chu kì xoắn **3,4 nm** gồm **10 cặp** nucleotide (mỗi cặp 0,34 nm).
> 3. Nhờ cấu trúc đó, DNA **mang, bảo quản và truyền đạt** thông tin di truyền: trình tự nucleotide là "chữ viết", xoắn kép giữ bền, nguyên tắc bổ sung cho phép sao chép chính xác.
> 4. **Tái bản**: bắt đầu ở **điểm khởi đầu sao chép (Ori)**, tạo chạc chữ Y; enzyme tách mạch mở xoắn → **RNA polymerase** (primase) làm **đoạn mồi** → **DNA polymerase** gắn nucleotide vào đầu **3'-OH**, chỉ theo chiều **5' → 3'** → một mạch **liên tục**, mạch kia **gián đoạn** (đoạn **Okazaki**) → loại mồi, lấp chỗ trống → **enzyme nối (ligase)** nối các đoạn.
> 5. Tái bản theo **nguyên tắc bổ sung** và **bán bảo toàn**: 1 DNA → 2 DNA con giống hệt mẹ, mỗi DNA con có 1 mạch cũ + 1 mạch mới. Nhân sơ: **1** điểm khởi đầu; nhân thực: **nhiều** điểm khởi đầu.

> [!nen-tang] Nhớ lại từ lớp 10: thành phần hoá học của tế bào
> - Các đại phân tử sinh học: carbohydrate, lipid, **protein** (đơn phân là amino acid) và **nucleic acid** (DNA, RNA). Nucleic acid được cấu tạo theo **nguyên tắc đa phân**: nhiều đơn phân giống nhau về cấu trúc chung nối thành chuỗi dài.
> - Đơn phân của nucleic acid là **nucleotide**, gồm 3 thành phần: **đường pentose** (5 carbon), **nhóm phosphate** và **base nitrogen** (base chứa nitrogen).
> - DNA: đường **deoxyribose**, base **A, T, G, C**. RNA: đường **ribose**, base **A, U, G, C** (U thay cho T); RNA thường chỉ có một mạch.
> - Base có hai nhóm: **purine** (A, G — kích thước lớn, 2 vòng) và **pyrimidine** (T, C, U — kích thước nhỏ, 1 vòng).
> - **Liên kết hydrogen** là liên kết yếu, dễ đứt và dễ tạo lại; còn **liên kết cộng hoá trị** (như liên kết phosphodiester) bền hơn nhiều.
>
> Bài này cho em thấy: chỉ từ 4 loại "viên gạch" nucleotide, DNA chứa được toàn bộ thông tin di truyền và tự sao chép được — điều mà protein không làm được.

**Câu hỏi mở bài.** Từ một hợp tử, cơ thể người tạo ra hàng chục nghìn tỉ tế bào; mỗi lần tế bào phân chia, khoảng **3 tỉ cặp nucleotide** phải được sao chép, thế mà các tế bào con vẫn mang thông tin di truyền gần như giống hệt nhau. Một phân tử cần có cấu trúc như thế nào để vừa **chứa** được khối lượng thông tin khổng lồ ấy, vừa **giữ** nó an toàn, lại vừa **tự sao** chính xác được? Bài này trả lời câu hỏi đó.

## 1. Cấu trúc và chức năng của DNA

### 1.1. Đơn phân: nucleotide

Mỗi nucleotide của DNA gồm ba phần gắn với nhau:

| Thành phần | Đặc điểm | Ghi chú |
|---|---|---|
| Đường deoxyribose | đường 5 carbon, đánh số C1' đến C5' | gắn base ở C1', gắn phosphate ở C5' |
| Nhóm phosphate | mang điện tích âm | làm DNA tích điện âm |
| Base nitrogen | một trong 4 loại: **A** (adenine), **T** (thymine), **G** (guanine), **C** (cytosine) | 4 loại nucleotide chỉ khác nhau ở base |

Vì 4 loại nucleotide chỉ khác nhau ở base, người ta gọi tên nucleotide theo base: nucleotide loại A, loại T, loại G, loại C. Mỗi nucleotide có khối lượng trung bình khoảng **300 đvC** — con số này dùng khi tính khối lượng DNA.

### 1.2. Mạch polynucleotide và chiều 5' → 3'

Các nucleotide nối nhau thành một chuỗi dài gọi là **mạch polynucleotide**. Liên kết nối hai nucleotide liền kề là **liên kết phosphodiester**: nhóm phosphate gắn ở C5' của nucleotide sau liên kết với nhóm –OH ở C3' của đường thuộc nucleotide trước.

Kết quả là mỗi mạch có **"xương sống" đường – phosphate** chạy dọc ở ngoài, còn các base chĩa vào trong. Hai đầu của mạch **khác nhau**:

- một đầu còn **nhóm phosphate tự do ở C5'** → gọi là **đầu 5'**;
- đầu kia còn **nhóm –OH tự do ở C3'** → gọi là **đầu 3'**.

Vì vậy mạch DNA có **chiều**, giống như một dòng chữ có chiều đọc. Quy ước viết trình tự **từ đầu 5' sang đầu 3'**, ví dụ 5'-ATGCCA-3'.

**Đếm liên kết phosphodiester.** Giữa hai nucleotide liền kề có 1 liên kết, nên một mạch có x nucleotide thì có **x − 1** liên kết. Một phân tử DNA mạch thẳng có N nucleotide (mỗi mạch N/2) có **N − 2** liên kết phosphodiester; DNA dạng vòng (của vi khuẩn, plasmid) thì khép kín nên có đúng **N** liên kết.

### 1.3. Chuỗi xoắn kép theo mô hình Watson – Crick

Năm 1953, James Watson và Francis Crick đề xuất mô hình cấu trúc DNA (SGK tr. 6, Hình 1.1). Các đặc điểm chính:

**a) Hai mạch liên kết với nhau theo nguyên tắc bổ sung (NTBS).** Base của mạch này liên kết với base đối diện của mạch kia bằng **liên kết hydrogen**, theo quy tắc:

- **A** chỉ liên kết với **T** bằng **2** liên kết hydrogen;
- **G** chỉ liên kết với **C** bằng **3** liên kết hydrogen.

**Vì sao lại là A – T, G – C mà không phải A – G?** Mỗi cặp luôn gồm **một purine (to) + một pyrimidine (nhỏ)**, nên mọi bậc "thang" có chiều rộng bằng nhau → xoắn kép có đường kính **đều 2 nm** suốt chiều dài. Nếu A ghép với G (to + to) thì chỗ đó phình ra; T ghép với C (nhỏ + nhỏ) thì chỗ đó thắt lại — phân tử sẽ méo mó, kém bền. Ngoài ra, chỉ các cặp A – T và G – C mới có vị trí các nhóm nguyên tử "khớp nhau" để tạo liên kết hydrogen.

**b) Hai mạch đối song song (ngược chiều nhau).** Nếu mạch 1 chạy 5' → 3' từ trên xuống thì mạch 2 chạy 3' → 5' từ trên xuống.

![Hình 1. Cấu trúc DNA. Trên: một đoạn DNA "duỗi thẳng" — hai mạch đối song song, xương sống đường – phosphate ở ngoài, các cặp base bổ sung ở trong. Dưới: kích thước chuỗi xoắn kép](hinh-1-cau-truc.svg)

**c) Xoắn đều quanh một trục.** Hai mạch xoắn quanh nhau như một chiếc thang dây bị vặn xoắn: tay vịn là xương sống đường – phosphate, bậc thang là các cặp base. Kích thước theo SGK (phần dưới Hình 1):

| Đại lượng | Giá trị |
|---|---|
| Đường kính chuỗi xoắn | **2 nm** |
| Khoảng cách giữa hai cặp nucleotide liền kề (dọc trục) | **0,34 nm** (= 3,4 Å) |
| Một chu kì xoắn (một vòng xoắn) | dài **3,4 nm**, gồm **10 cặp** nucleotide |

> [!bay]
> - **0,34 nm** là của **một cặp** nucleotide; **3,4 nm** là của **một chu kì xoắn** (10 cặp). Nhầm hai số này làm kết quả sai gấp 10 lần.
> - Chiều dài DNA tính theo **số cặp** (= N/2), không phải theo tổng số nucleotide N — vì hai nucleotide của một cặp nằm **ngang hàng**, không nối tiếp nhau theo chiều dài.
> - Liên kết hydrogen nằm **giữa hai mạch**; liên kết phosphodiester nằm **trong một mạch**. Đề hay tráo hai loại liên kết này.

### 1.4. Hệ quả của nguyên tắc bổ sung

Vì A luôn đi với T và G luôn đi với C:

- Trong cả phân tử: **A = T**, **G = C**. Suy ra $A + G = T + C = \dfrac{N}{2}$, tức **%A + %G = 50%**.
- Giữa hai mạch: **A~1~ = T~2~, T~1~ = A~2~, G~1~ = C~2~, C~1~ = G~2~** (chỉ số 1, 2 chỉ mạch 1, mạch 2).
- Do đó $A = T = A_1 + A_2$ và $G = C = G_1 + G_2$. Nếu tính % theo **từng mạch** thì %A = (%A~1~ + %A~2~) : 2.
- **Biết trình tự một mạch là suy ra được trình tự mạch kia.** Đây chính là "bí mật" giúp DNA tự sao chép (mục 2).

Tỉ lệ $\dfrac{A+T}{G+C}$ thì **khác nhau giữa các loài** — đặc trưng cho loài. Còn tỉ lệ $\dfrac{A+G}{T+C}$ của DNA mạch kép **luôn bằng 1**.

> [!vi-du] Ví dụ 1
> Một mạch của đoạn DNA có trình tự 5'-AGC TTA CGT-3'. Viết trình tự mạch bổ sung theo quy ước (chiều 5' → 3').

> [!goi-y] Gợi ý 1
> Viết từng base bổ sung ngay dưới base của mạch đã cho: A ↔ T, G ↔ C. Đầu nào của mạch mới nằm dưới đầu 5' của mạch đã cho?

> [!goi-y] Gợi ý 2
> Hai mạch đối song song: dưới đầu 5' là đầu 3'. Sau khi viết xong, phải **đảo ngược** để đọc lại từ 5' sang 3'.

> [!loi-giai] Lời giải
> Bước 1: Mạch đã cho: 5'-AGC TTA CGT-3'
>
> Bước 2: Mạch bổ sung (viết thẳng hàng bên dưới): 3'-TCG AAT GCA-5'
>
> Bước 3: Viết lại theo quy ước từ 5' → 3' (đọc ngược từ phải sang trái): **5'-ACG TAA GCT-3'**.

> [!bay]
> Nhiều bạn chỉ thay A ↔ T, G ↔ C rồi ghi "5'-TCG AAT GCA-3'" — sai chiều. Mạch bổ sung luôn **ngược chiều** mạch gốc. Trong đề trắc nghiệm, phương án sai chiều thường được cài sẵn.

### 1.5. Cấu trúc phù hợp với chức năng

DNA có chức năng **mang, bảo quản và truyền đạt thông tin di truyền**. Mỗi đặc điểm cấu trúc "phục vụ" một chức năng:

| Đặc điểm cấu trúc | Chức năng tương ứng | Vì sao |
|---|---|---|
| Cấu tạo theo **nguyên tắc đa phân**, 4 loại nucleotide sắp xếp theo trình tự rất đa dạng | **Mang** thông tin | 4 loại nucleotide như 4 "chữ cái"; trình tự chữ cái "ghi mã" mọi thông tin quy định cấu trúc, chức năng của tế bào. Một đoạn chỉ 10 nucleotide đã có 4^10^ ≈ 1 triệu trình tự khác nhau |
| **Xoắn kép**, xương sống đường – phosphate bền ở ngoài, base được "giấu" bên trong | **Bảo quản** thông tin | Cấu trúc bền vững, ít bị hư hỏng; nếu một mạch bị hỏng, mạch kia còn làm "bản gốc" để sửa |
| Các base kết cặp theo **NTBS** | **Truyền đạt** thông tin sang RNA và protein | Thông tin trên DNA được phiên mã sang mRNA, rồi mRNA được dịch mã thành protein (Bài 2) |
| Kết cặp **đặc hiệu A – T, G – C** khi tái bản | **Truyền đạt** qua các thế hệ tế bào và cơ thể | Mỗi mạch làm khuôn tạo ra đúng mạch bổ sung → bản sao gần như giống hệt |

**Ý nghĩa của các cặp kết cặp đặc hiệu A – T và G – C** (yêu cầu cần đạt của SGK):

1. Bảo đảm **đường kính chuỗi xoắn ổn định** (purine + pyrimidine) → cấu trúc bền.
2. Liên kết hydrogen **yếu từng cái nhưng rất nhiều** → hai mạch vừa giữ chặt nhau, vừa **dễ tách ra** khi cần tái bản hay phiên mã.
3. Từ một mạch suy ra **chính xác** mạch còn lại → tái bản, phiên mã chính xác; sửa sai được khi một mạch bị hỏng.
4. G – C có 3 liên kết hydrogen, A – T chỉ có 2 → DNA càng **nhiều cặp G – C càng bền** với nhiệt.

**Vì sao protein tạo nên tính trạng nhưng không thể là vật chất di truyền?** Protein rất đa dạng (20 loại amino acid), nhưng các amino acid **không kết cặp bổ sung** với nhau. Vì vậy protein **không thể tự làm khuôn để sao chép chính nó** — không truyền được thông tin cho thế hệ sau. Protein cũng kém bền, dễ biến tính khi gặp nhiệt độ cao hay thay đổi pH. Protein là "sản phẩm" được làm theo "bản thiết kế" là DNA.

> [!ung-dung]
> Vi khuẩn sống ở suối nước nóng (70 – 90 °C) thường có DNA giàu cặp G – C hơn vi khuẩn sống ở nhiệt độ thường — nhiều liên kết hydrogen hơn giúp hai mạch không bị tách rời vì nhiệt. Trong phòng thí nghiệm, người ta đun nóng DNA để tách hai mạch: DNA càng giàu G – C thì càng cần nhiệt độ cao.

### 1.6. Các công thức tính về cấu trúc DNA

Gọi **N** là tổng số nucleotide của đoạn DNA (gene). Mọi công thức đều suy ra từ cấu trúc ở trên:

| Đại lượng | Công thức | Vì sao |
|---|---|---|
| Tổng số nucleotide | $N = 2A + 2G$ | A = T, G = C |
| Số nucleotide mỗi mạch | $\dfrac{N}{2}$ (= số cặp) | hai mạch dài bằng nhau |
| Chiều dài | $L = \dfrac{N}{2}\times 0{,}34$ (nm) | mỗi cặp dài 0,34 nm |
| Số chu kì xoắn | $C = \dfrac{N}{20}$ | mỗi chu kì 10 cặp = 20 nucleotide |
| Khối lượng | $M = N \times 300$ (đvC) | mỗi nucleotide ≈ 300 đvC |
| Số liên kết hydrogen | $H = 2A + 3G$ | A – T: 2; G – C: 3 |
| Số liên kết phosphodiester | $N - 2$ (mạch thẳng); $N$ (mạch vòng) | mỗi mạch $\frac{N}{2} - 1$ |

Đổi đơn vị: 1 µm = 10^3^ nm = 10^4^ Å; 1 nm = 10 Å.

> [!vi-du] Ví dụ 2
> Một gene có 2400 nucleotide, trong đó nucleotide loại A chiếm 30%. Tính: a) số nucleotide mỗi loại; b) chiều dài gene (nm); c) số liên kết hydrogen; d) khối lượng và số chu kì xoắn của gene.

> [!goi-y] Gợi ý 1
> A = T và %A + %G = 50%. Từ %A = 30% suy ra %G. Nhân với N để ra số lượng.

> [!goi-y] Gợi ý 2
> Chiều dài tính theo **số cặp** N/2 nhân 0,34 nm. Liên kết hydrogen: mỗi cặp A – T góp 2, mỗi cặp G – C góp 3.

> [!loi-giai] Lời giải
> a) A = T = 30% × 2400 = **720**; %G = 50% − 30% = 20% → G = C = 20% × 2400 = **480**.
>
> b) L = (2400 : 2) × 0,34 = 1200 × 0,34 = **408 nm**.
>
> c) H = 2A + 3G = 2 × 720 + 3 × 480 = 1440 + 1440 = **2880**.
>
> d) M = 2400 × 300 = **720 000 đvC**; C = 2400 : 20 = **120** chu kì xoắn.

> [!vi-du] Ví dụ 3
> Một gene dài 306 nm. Trên mạch 1 của gene có: A~1~ = 15%, T~1~ = 25%, G~1~ = 35% số nucleotide của mạch. Tính số nucleotide mỗi loại trên mạch 2 và trên cả gene, rồi tính số liên kết hydrogen của gene.

> [!goi-y] Gợi ý 1
> Số nucleotide mỗi mạch = L : 0,34. %C~1~ = 100% − (15% + 25% + 35%).

> [!goi-y] Gợi ý 2
> Dùng NTBS giữa hai mạch: A~2~ = T~1~, T~2~ = A~1~, G~2~ = C~1~, C~2~ = G~1~. Rồi A = A~1~ + A~2~, G = G~1~ + G~2~.

> [!loi-giai] Lời giải
> Bước 1: Số nucleotide mỗi mạch = 306 : 0,34 = 900. Mạch 1: A~1~ = 135, T~1~ = 225, G~1~ = 315, C~1~ = 100% − 75% = 25% → C~1~ = 225.
>
> Bước 2: Mạch 2: A~2~ = T~1~ = **225**; T~2~ = A~1~ = **135**; G~2~ = C~1~ = **225**; C~2~ = G~1~ = **315**.
>
> Bước 3: Cả gene: A = T = 135 + 225 = **360**; G = C = 315 + 225 = **540**. (Kiểm tra: 2 × 360 + 2 × 540 = 1800 = 2 × 900 ✓.)
>
> Bước 4: H = 2 × 360 + 3 × 540 = 720 + 1620 = **2340**.

> [!meo]
> Đề thường cho % theo **một mạch**. Muốn ra % của **cả gene**, lấy trung bình cộng hai mạch: %A = (%A~1~ + %A~2~) : 2 = (%A~1~ + %T~1~) : 2. Ở Ví dụ 3: %A = (15% + 25%) : 2 = 20% → nhanh hơn nhiều.

## 2. Tái bản DNA

**Tái bản DNA** (nhân đôi DNA, sao chép DNA) là quá trình tạo ra hai phân tử DNA con giống hệt phân tử DNA mẹ. Ở sinh vật nhân thực, tái bản diễn ra trong **nhân tế bào**, vào **pha S của kì trung gian** — trước khi tế bào phân chia — để mỗi tế bào con nhận được một bộ DNA đầy đủ.

Quá trình bắt đầu ở một vị trí nhất định gọi là **điểm khởi đầu sao chép (Ori)** và diễn ra **theo hai hướng ngược nhau** từ điểm đó, tạo nên một **đơn vị tái bản** (trông như một "con mắt" hay "bong bóng"). Hai đầu của đơn vị tái bản là hai **chạc sao chép hình chữ Y**. SGK chia quá trình thành hai giai đoạn: **khởi đầu sao chép** và **tổng hợp mạch mới** (trình bày cho sinh vật nhân sơ).

![Hình 2. Một đơn vị tái bản: từ điểm khởi đầu, hai chạc sao chép đi về hai phía; ở mỗi chạc có một mạch mới liên tục và một mạch mới gián đoạn](hinh-2-don-vi-tai-ban.svg)

### 2.1. Giai đoạn khởi đầu sao chép

- Một số protein và enzyme bám vào **Ori**. **Enzyme tách mạch** (helicase) phá vỡ các **liên kết hydrogen**, tháo xoắn và tách DNA thành hai mạch đơn ở cả hai phía của Ori → hình thành hai chạc sao chép chữ Y.
- **RNA polymerase** (enzyme tổng hợp mồi, còn gọi là **primase**) dùng mạch DNA làm khuôn tổng hợp một đoạn **RNA ngắn** gọi là **đoạn mồi**. Đoạn mồi cung cấp **đầu 3'-OH tự do** cho DNA polymerase bắt đầu làm việc.

**Vì sao cần đoạn mồi?** DNA polymerase **không tự bắt đầu** được một mạch mới từ con số 0. Nó chỉ biết **gắn thêm** nucleotide vào một đầu 3'-OH có sẵn — giống như người xếp hàng chỉ đứng nối sau người đã có mặt. Đoạn mồi RNA chính là "người đứng đầu hàng".

### 2.2. Giai đoạn tổng hợp mạch DNA mới

- Mạch DNA được tách ra đến đâu, **DNA polymerase** tổng hợp mạch mới đến đó. Nó gắn các nucleotide tự do của môi trường nội bào vào **đầu 3'** của đoạn mồi (hoặc của mạch đang kéo dài), theo **NTBS** với mạch khuôn: A của khuôn ghép với T tự do, T với A, G với C, C với G.
- Vì nucleotide mới luôn được gắn vào **đầu 3'**, mạch mới chỉ kéo dài theo **chiều 5' → 3'**. Mạch mới ngược chiều với mạch khuôn, nên DNA polymerase "đọc" mạch khuôn theo chiều 3' → 5'.

**Vì sao có mạch liên tục và mạch gián đoạn?** Đây là chỗ khó nhất của bài — hãy suy luận từng bước:

1. Hai mạch khuôn **ngược chiều** nhau.
2. Chạc sao chép mở ra **về một phía**.
3. Cả hai mạch mới đều **chỉ** được kéo dài theo chiều 5' → 3'.

Vậy:

- Trên mạch khuôn có chiều **3' → 5'** (tính theo hướng chạc mở), mạch mới kéo dài **cùng hướng** chạc mở → chạc mở đến đâu, tổng hợp nối tiếp đến đó → **mạch liên tục** (chỉ cần 1 đoạn mồi ở đầu).
- Trên mạch khuôn có chiều **5' → 3'**, mạch mới phải kéo dài **ngược hướng** chạc mở. Nó không thể "chạy theo" chạc, nên mỗi khi chạc mở thêm một đoạn, tế bào lại đặt **một đoạn mồi mới** và tổng hợp **một đoạn ngắn** quay ngược về phía sau → **mạch gián đoạn**, gồm nhiều đoạn ngắn gọi là **đoạn Okazaki**.

![Hình 3. Hoạt động của các enzyme tại một chạc sao chép (chạc mở sang phải)](hinh-3-chac-tai-ban.svg)

- Sau khi các đoạn Okazaki được tổng hợp, **DNA polymerase loại bỏ đoạn mồi** RNA và tổng hợp đoạn DNA thay thế vào chỗ trống.
- Cuối cùng, **enzyme nối (ligase)** tạo liên kết phosphodiester nối các đoạn Okazaki thành mạch hoàn chỉnh.

| Enzyme / protein | Việc làm |
|---|---|
| Enzyme tách mạch (helicase) | Phá liên kết hydrogen, tháo xoắn, tách hai mạch, tạo chạc chữ Y |
| RNA polymerase (primase) | Tổng hợp **đoạn mồi RNA** có đầu 3'-OH |
| DNA polymerase | Gắn nucleotide vào đầu 3'-OH theo NTBS, kéo dài mạch mới chiều 5' → 3'; loại bỏ đoạn mồi và thay bằng DNA |
| Enzyme nối (ligase) | Nối các đoạn Okazaki (tạo liên kết phosphodiester) |

> [!bay]
> - "Mạch liên tục được tổng hợp theo chiều 5' → 3', mạch gián đoạn theo chiều 3' → 5'" — **sai**. **Cả hai** mạch mới đều tổng hợp theo chiều 5' → 3'; chỉ khác là mạch gián đoạn được tổng hợp **từng đoạn, ngược hướng chạc mở**.
> - Đoạn mồi là **RNA**, do **RNA polymerase** tổng hợp — không phải do DNA polymerase.
> - Mạch liên tục và mạch gián đoạn **không** phải là "mạch khuôn". Đó là hai **mạch mới**. Ở hai chạc của cùng một đơn vị tái bản, mạch mới trên **cùng một mạch khuôn** là mạch liên tục ở chạc này nhưng gián đoạn ở chạc kia (Hình 2).
> - Enzyme tách mạch phá **liên kết hydrogen**; ligase tạo **liên kết phosphodiester**.

**Đếm đoạn mồi.** Mỗi đoạn Okazaki cần 1 đoạn mồi; mỗi mạch liên tục cũng cần 1 đoạn mồi. Một đơn vị tái bản có 2 chạc → 2 mạch liên tục. Nên:

> [!ghi-nho]
> **Số đoạn mồi = số đoạn Okazaki + 2 × số đơn vị tái bản**

### 2.3. Kết quả: nguyên tắc bán bảo toàn

Kết thúc tái bản, từ một DNA mẹ tạo ra **hai DNA con giống nhau và giống DNA mẹ**. Trong mỗi DNA con có **một mạch cũ** (của mẹ, làm khuôn) và **một mạch mới** được tổng hợp — gọi là **nguyên tắc bán bảo toàn** ("giữ lại một nửa").

Tóm lại, tái bản DNA diễn ra theo hai nguyên tắc:

- **Nguyên tắc bổ sung**: nucleotide tự do ghép với nucleotide của mạch khuôn (A – T, G – C) → mạch mới đúng là bản "đối chiếu" của mạch khuôn.
- **Nguyên tắc bán bảo toàn**: mỗi DNA con giữ lại một mạch của mẹ.

**Vì sao hai DNA con giống hệt nhau và giống mẹ?** DNA con 1 = mạch cũ 1 + mạch bổ sung của mạch 1 = đúng bằng mạch 1 + mạch 2 của mẹ. Tương tự với DNA con 2. Bộ máy tái bản lại hoạt động rất chính xác (DNA polymerase còn tự "đọc lại" và sửa nucleotide gắn nhầm), nên thông tin di truyền được truyền đạt **gần như nguyên vẹn**.

![Hình 4. Nguyên tắc bán bảo toàn qua hai lần tái bản: hai mạch cũ (màu cam) luôn nằm ở hai DNA con khác nhau](hinh-4-ban-bao-toan.svg)

> [!em-co-biet] Thí nghiệm Meselson – Stahl (1958)
> Hai nhà khoa học nuôi vi khuẩn *E. coli* nhiều thế hệ trong môi trường chứa **N^15^** (đồng vị nặng của nitrogen) để mọi DNA đều "nặng", rồi chuyển sang môi trường **N^14^** (nhẹ). Ly tâm DNA để tách theo khối lượng:
> - sau 1 thế hệ: chỉ có một băng DNA **trung gian** (N^15^/N^14^);
> - sau 2 thế hệ: một nửa trung gian, một nửa **nhẹ** (N^14^/N^14^).
>
> Kết quả này đúng như dự đoán của **bán bảo toàn**, và bác bỏ giả thuyết "bảo toàn" (DNA mẹ giữ nguyên, DNA con hoàn toàn mới — khi đó sau 1 thế hệ phải có băng nặng và băng nhẹ). Đây là cơ sở của dạng bài N^15^/N^14^ ở phần cuối.

### 2.4. Tái bản ở sinh vật nhân sơ và nhân thực

| Đặc điểm | Nhân sơ (vi khuẩn) | Nhân thực |
|---|---|---|
| DNA | thường là **một phân tử vòng**, kích thước nhỏ | nhiều phân tử **mạch thẳng**, rất dài, liên kết với protein trong NST |
| Số điểm khởi đầu (Ori) trên một phân tử | **một** → một đơn vị tái bản | **nhiều** → nhiều đơn vị tái bản, tái bản **đồng thời ở nhiều vùng** |
| Loại DNA polymerase | ít loại | **nhiều loại** hơn |
| Giống nhau | NTBS, bán bảo toàn; tổng hợp 5' → 3'; mạch liên tục và gián đoạn; cần đoạn mồi; cần các enzyme tách mạch, RNA polymerase, DNA polymerase, ligase | |

**Vì sao nhân thực cần nhiều điểm khởi đầu?** DNA nhân thực dài gấp hàng trăm, hàng nghìn lần DNA vi khuẩn, mà tốc độ của mỗi chạc có hạn. Nếu chỉ có một Ori, một NST người có thể phải mất nhiều tuần mới sao chép xong. Nhờ hàng nghìn điểm khởi đầu hoạt động cùng lúc, toàn bộ hệ gene người được sao chép chỉ trong vài giờ.

> [!em-co-biet]
> DNA vòng của *E. coli* dài khoảng 4,6 triệu cặp nucleotide, chỉ có một Ori. Hai chạc đi về hai phía, mỗi chạc gắn khoảng 1 000 nucleotide/giây trên mỗi mạch, nên mất khoảng 4,6 triệu : 2 : 1 000 ≈ 2 300 giây ≈ 38 phút để sao chép xong. Trong khi đó chạc sao chép ở người chậm hơn nhiều (vài chục nucleotide/giây).

## 3. Ý nghĩa của tái bản DNA

- **Đối với tế bào và cơ thể:** tái bản DNA diễn ra trước mỗi lần phân bào. Nhờ đó, hai tế bào con nhận được bộ DNA giống hệt tế bào mẹ → thông tin di truyền được truyền đạt ổn định **qua các thế hệ tế bào** (nguyên phân, giúp cơ thể sinh trưởng, tái tạo mô).
- **Đối với loài:** qua tái bản, giảm phân và thụ tinh, thông tin di truyền được truyền **từ thế hệ cơ thể này sang thế hệ sau**. Ở loài sinh sản vô tính, con cháu nhận bản sao gần như nguyên vẹn của DNA bố/mẹ.
- Tái bản là **cơ chế tự sao** — đặc tính chỉ có ở vật chất di truyền. Một số ít sai sót không được sửa trong tái bản lại là nguồn phát sinh **đột biến gene** (Bài 4).

> [!ung-dung] Tái bản DNA trong ống nghiệm
> - **Kĩ thuật PCR** mô phỏng tái bản DNA trong ống nghiệm: đun nóng để tách hai mạch (phá liên kết hydrogen), hạ nhiệt cho đoạn mồi bám vào, rồi DNA polymerase chịu nhiệt tổng hợp mạch mới. Mỗi chu kì, số bản sao **tăng gấp đôi** → sau 30 chu kì, từ một vài phân tử có thể thu được hàng tỉ bản sao.
> - Ứng dụng: nhân bản DNA từ mẫu vật rất nhỏ ở hiện trường để **truy tìm thủ phạm, xác định danh tính nạn nhân**; nhân DNA của tác nhân gây bệnh từ vật nuôi, cây trồng, người bệnh để **chẩn đoán** (xét nghiệm virus, vi khuẩn); là bước cần thiết của **giải trình tự gene, hệ gene** và **công nghệ di truyền** (Bài 5).
> - **Thuốc kháng sinh**: nhiều enzyme tái bản của vi khuẩn khác với enzyme cùng loại ở tế bào người. Một số kháng sinh (như nhóm quinolone) ức chế riêng enzyme tháo xoắn DNA (gyrase) của vi khuẩn → vi khuẩn không nhân lên được, trong khi tế bào người ít bị ảnh hưởng. Chọn đúng "mục tiêu chỉ vi khuẩn mới có" là cách giảm tác dụng không mong muốn của thuốc.

## Dạng bài thi hay gặp

> [!ghi-nho] Công thức tái bản — một DNA tái bản k lần liên tiếp
> | Đại lượng | Công thức |
> |---|---|
> | Số DNA con | $2^k$ |
> | Số mạch đơn trong các DNA con | $2 \cdot 2^k = 2^{k+1}$ |
> | Số mạch mới được tổng hợp | $2^{k+1} - 2$ |
> | Số DNA con còn chứa mạch cũ của mẹ | luôn là **2** |
> | Số DNA con hoàn toàn mới (cả hai mạch mới) | $2^k - 2$ |
> | Số nucleotide môi trường cung cấp | $N\,(2^k - 1)$; từng loại: $A_{mt} = T_{mt} = A\,(2^k - 1)$, $G_{mt} = C_{mt} = G\,(2^k - 1)$ |
> | Số liên kết hydrogen bị phá vỡ | $H\,(2^k - 1)$ |
>
> **Vì sao là $2^k - 1$?** Sau k lần có $2^k$ DNA, nhưng **một DNA** (tính bằng hai mạch cũ) là của mẹ có sẵn — môi trường chỉ phải cung cấp phần còn lại, tương đương $2^k - 1$ DNA. Mỗi DNA đang có bị tách mạch một lần ở mỗi lần tái bản, nên tổng số lần tách mạch là $1 + 2 + 4 + \dots + 2^{k-1} = 2^k - 1$ → đó cũng là hệ số của số liên kết hydrogen bị phá vỡ.

### Dạng 1. Tính các đại lượng cấu trúc của DNA

*Nhận biết:* cho một vài dữ kiện (chiều dài, khối lượng, số chu kì xoắn, % một loại nucleotide, số liên kết hydrogen…), hỏi các đại lượng còn lại.

*Phương pháp:*
1. Tìm **N** trước tiên (từ L, M, C hoặc từ hệ phương trình).
2. Dùng %A + %G = 50% (hoặc A + G = N/2) để tìm từng loại.
3. Áp dụng công thức cần tính. Nếu đề cho theo **mạch**, dùng A~1~ = T~2~, G~1~ = C~2~… rồi cộng hai mạch.

> [!vi-du] Ví dụ 4
> Một gene có 3240 liên kết hydrogen. Hiệu số giữa nucleotide loại G với một loại nucleotide khác bằng 20% số nucleotide của gene. Tính số nucleotide mỗi loại và chiều dài của gene (nm).

> [!goi-y] Gợi ý 1
> "Một loại nucleotide khác" mà hiệu với G khác 0 thì chỉ có thể là A (hoặc T, vì A = T). Viết hai phương trình: %G − %A = 20% và %G + %A = 50%.

> [!goi-y] Gợi ý 2
> Biết %A, %G thì H = 2A + 3G = 2 × (%A × N) + 3 × (%G × N). Giải ra N.

> [!loi-giai] Lời giải
> Bước 1: %G − %A = 20%, %G + %A = 50% → %G = 35%, %A = 15%.
>
> Bước 2: H = 2 × 0,15N + 3 × 0,35N = 1,35N = 3240 → N = **2400**.
>
> Bước 3: A = T = 15% × 2400 = **360**; G = C = 35% × 2400 = **840**. (Kiểm tra: 2 × 360 + 3 × 840 = 720 + 2520 = 3240 ✓.)
>
> Bước 4: L = (2400 : 2) × 0,34 = **408 nm**.

> [!meo]
> Luôn kiểm tra N là **số nguyên chẵn** (và số nucleotide mỗi loại là số nguyên). Nếu ra N lẻ hoặc không nguyên, gần như chắc chắn em đã tính sai hoặc đọc nhầm đề (ví dụ dùng 3,4 nm thay cho 0,34 nm).

*Bẫy:* quên rằng %A + %G = 50% (không phải 100%); dùng N thay cho N/2 khi tính chiều dài; nhầm 0,34 nm với 3,4 nm.

### Dạng 2. Xác định chiều và trình tự mạch; đọc hình chạc tái bản

*Nhận biết:* cho trình tự một mạch (có ghi đầu 5', 3'), hoặc một hình/mô tả chạc sao chép; hỏi trình tự mạch bổ sung, mạch mới, hoặc mạch nào liên tục, đoạn Okazaki ở đâu, đầu 3' của mạch mới hướng về đâu.

*Phương pháp:*
1. Mạch mới luôn **bổ sung** và **ngược chiều** với mạch khuôn; viết đáp án theo chiều 5' → 3'.
2. Với hình chạc: xác định **hướng chạc mở** (về phía DNA chưa tách). Trên mạch khuôn, đi theo hướng chạc mở mà gặp chiều **3' → 5'** → mạch mới trên khuôn đó **liên tục**; gặp **5' → 3'** → **gián đoạn**.
3. Đầu 3' của mạch liên tục luôn **hướng về phía chạc** (đang kéo dài); mỗi đoạn Okazaki kéo dài **ra xa chạc**.

> [!vi-du] Ví dụ 5
> Một chạc sao chép đang mở dần sang **bên trái**. Mạch khuôn phía trên có đầu 5' ở bên trái, đầu 3' ở bên phải. Hỏi: mạch mới tổng hợp trên khuôn phía trên là liên tục hay gián đoạn? Mạch đó kéo dài theo hướng nào?

> [!goi-y] Gợi ý 1
> Mạch mới ngược chiều khuôn: khuôn trên 5' (trái) → 3' (phải), vậy mạch mới bắt cặp với nó có đầu 3' ở bên trái hay bên phải?

> [!goi-y] Gợi ý 2
> Mạch mới chỉ kéo dài về phía đầu 3' của chính nó. Hướng đó trùng hay ngược với hướng chạc mở (sang trái)?

> [!loi-giai] Lời giải
> Bước 1: Khuôn trên: 5' (trái) — 3' (phải) → mạch mới bổ sung: 3' (trái) — 5' (phải).
>
> Bước 2: Mạch mới kéo dài theo chiều 5' → 3', tức **từ phải sang trái**.
>
> Bước 3: Chạc cũng mở sang trái → mạch mới kéo dài **cùng hướng** chạc mở → đó là **mạch liên tục**, đầu 3' hướng về phía chạc (bên trái).
>
> (Cách nhanh: đi theo hướng chạc mở — từ phải sang trái — trên khuôn trên ta đi từ đầu 3' về đầu 5', tức gặp chiều 3' → 5' → mạch liên tục.)

*Bẫy:* xác định nhầm hướng chạc mở; quên rằng **cùng một mạch khuôn** nhưng ở hai chạc của một đơn vị tái bản thì mạch mới trên nó một bên liên tục, một bên gián đoạn.

### Dạng 3. Tái bản k lần; bài N^15^/N^14^

*Nhận biết:* "tái bản (nhân đôi) k lần", "môi trường cung cấp", "số mạch mới", "vi khuẩn chứa N^15^ chuyển sang môi trường N^14^"…

*Phương pháp:*
1. Tính N, A, G của DNA mẹ (Dạng 1).
2. Dùng bảng công thức ở đầu mục này.
3. Bài đồng vị: **theo dõi từng mạch đơn**, không theo dõi cả phân tử. Mỗi lần tái bản, mỗi mạch cũ (dù loại gì) đi vào một DNA con và ghép với **một mạch mới mang nguyên tố của môi trường lúc đó**.

> [!vi-du] Ví dụ 6
> Một phân tử DNA có 3000 nucleotide, trong đó có 900 nucleotide loại A. Phân tử này tái bản liên tiếp 3 lần. Tính: a) số DNA con và số mạch mới được tổng hợp; b) số nucleotide mỗi loại môi trường cung cấp; c) số liên kết hydrogen bị phá vỡ.

> [!goi-y] Gợi ý 1
> G = N/2 − A. Số DNA con 2^3^; số mạch mới = tổng số mạch trừ 2 mạch cũ.

> [!goi-y] Gợi ý 2
> Môi trường cung cấp tương đương 2^3^ − 1 = 7 phân tử DNA. Liên kết hydrogen bị phá vỡ cũng nhân với 7.

> [!loi-giai] Lời giải
> a) Số DNA con = 2^3^ = **8**; số mạch mới = 2 × 8 − 2 = **14**.
>
> b) G = 1500 − 900 = 600. A~mt~ = T~mt~ = 900 × 7 = **6300**; G~mt~ = C~mt~ = 600 × 7 = **4200** (tổng 21 000 = 3000 × 7 ✓).
>
> c) H = 2 × 900 + 3 × 600 = 3600 → số liên kết hydrogen bị phá vỡ = 3600 × 7 = **25 200**.

> [!vi-du] Ví dụ 7 (N^15^/N^14^ — chuyển qua lại hai môi trường)
> Một vi khuẩn *E. coli* có phân tử DNA vùng nhân chỉ chứa N^14^. Nuôi vi khuẩn này trong môi trường chỉ có N^15^ cho phân chia 2 lần, rồi chuyển toàn bộ vi khuẩn con sang môi trường chỉ có N^14^ cho phân chia thêm 1 lần. Xét các DNA vùng nhân thu được: a) có bao nhiêu phân tử chứa N^15^? b) có bao nhiêu phân tử chỉ chứa N^14^?

> [!goi-y] Gợi ý 1
> Sau 2 lần trong N^15^: có 4 DNA = 8 mạch. Trong 8 mạch đó có mấy mạch N^14^ (mạch gốc) và mấy mạch N^15^?

> [!goi-y] Gợi ý 2
> Lần tái bản trong N^14^: **mỗi mạch** trong 8 mạch đi vào một DNA con riêng và ghép với một mạch mới N^14^. DNA con chứa N^15^ khi mạch cũ của nó là N^15^.

> [!loi-giai] Lời giải
> Bước 1: Sau 2 lần trong N^15^: 2^2^ = 4 DNA, gồm 8 mạch: **2 mạch N^14^** (hai mạch gốc) và 8 − 2 = **6 mạch N^15^** (mạch mới).
>
> Bước 2: Phân chia 1 lần trong N^14^: 8 DNA con, mỗi DNA con = 1 mạch cũ + 1 mạch mới N^14^.
>
> a) DNA chứa N^15^ = số mạch cũ N^15^ = **6** (đều là N^15^/N^14^).
>
> b) DNA chỉ chứa N^14^ = số mạch cũ N^14^ = **2**.
>
> Kiểm tra: 6 + 2 = 8 = 2^3^ ✓.

*Bẫy:* (1) Áp dụng máy móc "luôn có 2 DNA chứa mạch cũ" cho bài chuyển môi trường hai chiều — sai, vì các mạch được tổng hợp ở môi trường thứ nhất cũng trở thành "mạch cũ" ở môi trường thứ hai. (2) Đề có **a** phân tử DNA ban đầu (hoặc a vi khuẩn) → nhân mọi kết quả với a. (3) Phân biệt "chứa N^15^" (có ít nhất một mạch N^15^) với "chỉ chứa N^15^" (cả hai mạch N^15^).

### Dạng 4. Đơn vị tái bản, đoạn mồi, đoạn Okazaki, thời gian tái bản

*Nhận biết:* cho số đơn vị tái bản (số Ori), số đoạn Okazaki; hoặc tốc độ chạc sao chép; hỏi số đoạn mồi, thời gian.

*Phương pháp:*
1. Số đoạn mồi = số đoạn Okazaki + 2 × số đơn vị tái bản.
2. Thời gian: mỗi đơn vị tái bản có **2 chạc chạy ngược nhau**, mỗi chạc chỉ phải sao chép **một nửa** đơn vị. Thời gian = (số cặp nucleotide của đơn vị : 2) : tốc độ một chạc.

> [!vi-du] Ví dụ 8
> Khi một phân tử DNA ở sinh vật nhân thực tái bản một lần, có 8 đơn vị tái bản hoạt động và tổng số 240 đoạn Okazaki được tạo ra. Tính số đoạn mồi cần cho quá trình này.

> [!goi-y] Gợi ý 1
> Mỗi đoạn Okazaki cần một đoạn mồi. Ngoài ra còn mạch nào cần mồi?

> [!goi-y] Gợi ý 2
> Mỗi đơn vị tái bản có 2 chạc, mỗi chạc có 1 mạch liên tục, mỗi mạch liên tục cần 1 đoạn mồi.

> [!loi-giai] Lời giải
> Số đoạn mồi = 240 + 2 × 8 = **256**.

*Bẫy:* cộng thêm 1 thay vì 2 cho mỗi đơn vị tái bản; hoặc quên nhân 2 với **số đơn vị** khi DNA nhân thực có nhiều Ori.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Đơn phân | Nucleotide = deoxyribose + phosphate + base (A, T, G, C) |
| Một mạch | Nối bằng liên kết **phosphodiester**; có chiều **5' → 3'** |
| Hai mạch | **Đối song song**; NTBS: **A = T (2 liên kết H)**, **G ≡ C (3 liên kết H)** |
| Kích thước | Đường kính 2 nm; 1 cặp = 0,34 nm; 1 chu kì = 10 cặp = 3,4 nm |
| Chức năng | Mang – bảo quản – truyền đạt thông tin di truyền |
| Tái bản: nơi, lúc | Nhân tế bào (nhân thực) / vùng nhân (nhân sơ); trước phân bào (pha S) |
| Tái bản: nguyên tắc | Bổ sung + bán bảo toàn |
| Tái bản: diễn biến | Ori → tách mạch (helicase) → đoạn mồi (RNA polymerase) → DNA polymerase kéo dài 5' → 3' → mạch liên tục + đoạn Okazaki → loại mồi, lấp chỗ trống → ligase nối |
| Kết quả | 1 DNA mẹ → 2 DNA con giống hệt mẹ, mỗi con có 1 mạch cũ + 1 mạch mới |
| Nhân sơ – nhân thực | 1 Ori – nhiều Ori; ít – nhiều loại DNA polymerase |
| Ý nghĩa | Truyền đạt thông tin di truyền ổn định qua các thế hệ tế bào và cơ thể |

**Công thức nhanh:**
- $N = 2A + 2G$; %A + %G = 50%; $L = \frac{N}{2}\times 0{,}34$ nm; $C = \frac{N}{20}$; $M = 300N$ đvC; $H = 2A + 3G$.
- Tái bản k lần: $2^k$ DNA con; $2^{k+1} - 2$ mạch mới; môi trường cung cấp $N(2^k - 1)$ nucleotide; phá vỡ $H(2^k - 1)$ liên kết hydrogen.
- Số đoạn mồi = số đoạn Okazaki + 2 × số đơn vị tái bản.
