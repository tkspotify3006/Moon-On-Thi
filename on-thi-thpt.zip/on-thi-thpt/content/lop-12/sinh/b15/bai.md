---
title: Di truyền gene ngoài nhân
thoi-gian: 35 phút
muc-tieu:
  - Trình bày được bối cảnh Correns tiến hành thí nghiệm ở cây hoa bốn giờ (*Mirabilis jalapa*) vào năm 1909.
  - Mô tả được thí nghiệm lai giữa các cành lá xanh, lá trắng, lá khảm và giải thích được vì sao gene không chỉ có trong nhân mà còn có ở ngoài nhân (trong ti thể, lục lạp).
  - Nêu được các đặc điểm di truyền của gene ngoài nhân và phân biệt được với gene trên NST thường, gene liên kết với giới tính.
  - Nêu được các ứng dụng của di truyền gene ngoài nhân trong y học, nông nghiệp, nghiên cứu tiến hóa và pháp y.
  - Vận dụng để nhận biết gene ngoài nhân từ kết quả lai thuận nghịch, dự đoán kiểu hình đời con và đọc phả hệ bệnh do gene ti thể.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Năm 1909, **Correns** lai các cành lá xanh, lá trắng, lá khảm của cây **hoa bốn giờ**: màu lá của đời con **luôn theo cây mẹ**, không phụ thuộc cây bố.
> 2. Nguyên nhân: tính trạng do **gene ngoài nhân** quy định, tức gene nằm trên DNA vòng, nhỏ của **lục lạp** và **ti thể**. Hợp tử nhận tế bào chất **gần như hoàn toàn từ trứng**, nên con mang gene ngoài nhân của mẹ.
> 3. Đặc điểm: **lai thuận và lai nghịch cho kết quả khác nhau**, đời con **giống mẹ ở cả hai giới** (di truyền theo dòng mẹ). Gene không tồn tại thành cặp allele, **một allele cũng biểu hiện**. Lục lạp, ti thể chia **ngẫu nhiên, không đều** nên con cùng mẹ có thể khác nhau. Không có tái tổ hợp gene ngoài nhân khi thụ tinh.
> 4. Phân biệt với gene trên **X**: gene trên X cũng cho lai thuận ≠ lai nghịch nhưng kiểu hình **khác nhau giữa hai giới**. Gene ngoài nhân thì con đực và con cái đều giống mẹ.
> 5. Ứng dụng: phòng **bệnh ti thể** (kĩ thuật thay ti thể), **bất dục đực tế bào chất** để tạo lúa lai, giải trình tự **DNA ti thể** để truy nguồn gốc loài người và giám định hài cốt.

SGK mở đầu bài bằng một câu đố: ở người có **bệnh cơ ti thể** (cơ yếu dần, thoái hoá). Khi **mẹ** bị bệnh thì **mọi** con đều bị, dù bố có bệnh hay không. Còn khi chỉ **bố** bị bệnh thì sao? Theo các quy luật em đã học (Bài 8 – 11), mỗi gene có hai allele, một từ bố, một từ mẹ, nên bố và mẹ phải "góp phần" ngang nhau. Hiện tượng "chỉ mẹ quyết định" rõ ràng không khớp. Bài này giải thích vì sao.

> [!nen-tang] Nhắc lại từ Sinh học 10 và Bài 8, Bài 10
> - **Ti thể** (ở mọi tế bào nhân thực) và **lục lạp** (ở tế bào thực vật) là hai bào quan có **DNA riêng**. DNA này là phân tử **mạch kép, dạng vòng, nhỏ**, giống DNA của vi khuẩn. Ti thể, lục lạp còn có ribosome riêng và tự **phân chia** để tăng số lượng.
> - **Trứng** là tế bào lớn, chứa rất nhiều tế bào chất và rất nhiều ti thể. **Tinh trùng** (hay nhân tinh trùng trong ống phấn) góp gần như chỉ **nhân**. Ti thể ít ỏi của tinh trùng nếu lọt vào trứng thì cũng thường bị phân hủy.
> - **Lai thuận nghịch**: đảo vai trò bố mẹ của hai dòng (dòng 1 làm mẹ × dòng 2 làm bố, rồi dòng 2 làm mẹ × dòng 1 làm bố). Gene trên NST thường cho hai kết quả **như nhau** (Bài 8). Gene trên X cho hai kết quả **khác nhau** và phân bố khác nhau ở hai giới (Bài 10).

## 1. Thí nghiệm của Correns về di truyền gene ngoài nhân

### 1.1. Bối cảnh ra đời thí nghiệm

Năm **1900**, ba nhà thực vật học là Hugo de Vries, Erich von Tschermak và **Carl Correns**, mỗi người làm thí nghiệm trên một loài cây khác nhau, đã độc lập **"tìm lại"** các quy luật của Mendel. Từ đó các nhà khoa học tin rằng tính trạng nào cũng do cặp allele trong nhân quy định và tuân theo quy luật phân li.

Nhưng chỉ chín năm sau (**1909**), chính Correns lại phát hiện một trường hợp "không chịu nghe lời Mendel" ở cây **hoa bốn giờ** (*Mirabilis jalapa*). Ở loài này, trên **cùng một cây** có thể có ba loại cành với màu lá khác nhau:

- cành toàn **lá xanh**;
- cành toàn **lá trắng** (không có diệp lục);
- cành **lá khảm** (lá xanh có những vệt, mảng trắng) (SGK tr. 78, Hình 15.1).

Correns muốn biết màu lá được truyền cho đời con như thế nào. Vì ba loại cành nằm trên cùng một cây, ông có thể lấy **hạt phấn** từ hoa trên cành này thụ phấn cho **hoa** trên cành kia, theo mọi tổ hợp.

### 1.2. Thí nghiệm

Kết quả (SGK tr. 79, Bảng 15.1 nêu 6 phép lai giữa các loại cành khác nhau) được tóm tắt trong Hình 1. Hình vẽ thêm 3 ô thụ phấn giữa hai cành cùng loại để em thấy trọn bức tranh.

![Hình 1. Kết quả lai giữa các loại cành ở cây hoa bốn giờ: mỗi hàng (cùng một loại cành làm mẹ) cho cùng một kết quả, dù hạt phấn lấy từ cành nào](hinh-1-correns.svg)

Đọc hình theo hai cách:

- **Đi theo một hàng** (giữ nguyên mẹ, đổi bố): F~1~ **không đổi**. Hoa trên cành xanh luôn cho cây con lá xanh, kể cả khi nhận hạt phấn của cành trắng.
- **Đi theo một cột** (giữ nguyên bố, đổi mẹ): F~1~ **thay đổi theo mẹ**. Hạt phấn của cành xanh thụ cho hoa cành trắng thì được toàn cây lá trắng.

Đặc biệt, hai phép lai "♀ lá xanh × ♂ lá trắng" và "♀ lá trắng × ♂ lá xanh" là một cặp **lai thuận nghịch**. Kết quả của chúng **ngược nhau**: phép thứ nhất cho toàn lá xanh, phép thứ hai cho toàn lá trắng. Nếu gene nằm trong nhân (trên NST thường), cả hai phép lai phải cho F~1~ **giống nhau**.

> [!vi-du] Ví dụ 1
> Một bạn cho rằng: "Ở phép lai ♀ lá xanh × ♂ lá trắng, F~1~ toàn lá xanh, vậy lá xanh là tính trạng **trội** hoàn toàn so với lá trắng, đúng quy luật Mendel". Em hãy dùng thêm một phép lai trong Hình 1 để chỉ ra chỗ sai của lập luận này.

> [!goi-y] Gợi ý 1
> Nếu lá xanh trội, F~1~ của phép lai **ngược lại** (♀ lá trắng × ♂ lá xanh) phải có kiểu hình gì?

> [!goi-y] Gợi ý 2
> Thực tế, phép lai ngược lại cho kết quả gì?

> [!loi-giai] Lời giải
> Nếu lá xanh là tính trạng trội do gene trên NST thường, thì dù cây lá xanh làm bố hay làm mẹ, F~1~ cũng phải **toàn lá xanh**.
>
> Nhưng phép lai **nghịch** ♀ lá trắng × ♂ lá xanh lại cho F~1~ **toàn lá trắng**. Hai phép lai thuận nghịch cho kết quả khác nhau, và ở cả hai phép lai, F~1~ đều **giống mẹ**.
>
> Kết luận: không thể nói "xanh trội, trắng lặn". Màu lá ở đây **không di truyền theo quy luật Mendel** mà **theo mẹ**. Một phép lai lẻ thì chưa đủ để kết luận, phải xét **cả cặp lai thuận nghịch**.

Từ các kết quả này, Correns kết luận: màu lá ở cây hoa bốn giờ **không di truyền theo quy luật Mendel** mà **di truyền theo mẹ**. Từ đây xuất hiện thuật ngữ **"di truyền theo dòng mẹ"**.

> [!em-co-biet] Cây con lá trắng sống được bao lâu?
> Cành lá trắng trên cây mẹ vẫn sống được vì được các cành xanh "nuôi" qua mạch rây. Còn cây con mọc từ hạt mà toàn lá trắng thì không quang hợp được, nên chỉ sống đến khi hết chất dự trữ trong hạt rồi chết.

### 1.3. Giải thích thí nghiệm

Những nghiên cứu sau Correns cho thấy màu lá ở đây do **gene nằm trong lục lạp** quy định. Gene nằm trong lục lạp và ti thể ở tế bào chất được gọi chung là **gene ngoài nhân**.

**a) Vì sao con giống mẹ?** Khi thụ tinh, hợp tử nhận **nhân** từ cả bố và mẹ, nhưng nhận **tế bào chất** (kèm theo lục lạp, ti thể) **hầu như chỉ từ trứng** của mẹ. Tinh trùng (ở thực vật là nhân tinh trùng trong ống phấn) góp vào gần như chỉ có nhân. Vì thế gene ngoài nhân của con là gene ngoài nhân **của mẹ**, và con mang tính trạng giống mẹ.

**b) Vì sao lá xanh, lá trắng, lá khảm?**

- **Cành lá xanh**: các lục lạp mang allele **bình thường**, quy định enzyme xúc tác phản ứng tổng hợp diệp lục.
- **Cành lá trắng**: lục lạp mang allele **đột biến**, enzyme hỏng, không tạo được diệp lục.
- **Cành lá khảm**: tế bào chứa **cả hai loại** lục lạp, bình thường và đột biến.

**c) Vì sao mẹ lá khảm cho đời con có cả ba loại?** Khi tế bào phân chia, nhân được chia rất "công bằng" nhờ thoi phân bào: mỗi tế bào con nhận đủ bộ NST. Còn lục lạp thì **không** có cơ chế như vậy. Chúng được chia **ngẫu nhiên và không đều** về các tế bào con (Hình 2). Sau nhiều lần nguyên phân, có tế bào chỉ còn lục lạp bình thường, có tế bào chỉ còn lục lạp đột biến, có tế bào vẫn còn cả hai. Tế bào trứng của cây mẹ khảm cũng vậy, nên hạt sinh ra có thể mọc thành cây xanh, trắng hoặc khảm.

![Hình 2. Lục lạp được chia ngẫu nhiên, không đều qua các lần nguyên phân, tạo ra tế bào toàn lục lạp bình thường, toàn lục lạp đột biến, hoặc còn cả hai loại](hinh-2-phan-chia-luc-lap.svg)

> [!bay] "Mẹ khảm thì con có tỉ lệ 1 xanh : 2 khảm : 1 trắng" – SAI
> Lục lạp chia **ngẫu nhiên**, không theo cặp allele, nên **không có tỉ lệ cố định** như Mendel. Đề chỉ có thể hỏi đời con **có những loại kiểu hình nào** (xanh, trắng, khảm), không hỏi tỉ lệ chính xác.

> [!vi-du] Ví dụ 2
> Trên một cây hoa bốn giờ có cả ba loại cành. Lấy hạt phấn từ hoa trên **cành lá khảm** thụ phấn cho hoa trên **cành lá xanh** của **chính cây đó**. Hạt thu được mọc thành cây con có màu lá thế nào? Vì sao không cần quan tâm cây này là "cây khảm"?

> [!goi-y] Gợi ý 1
> Tế bào trứng nằm trong hoa trên cành nào? Tế bào chất của nó chứa loại lục lạp nào?

> [!goi-y] Gợi ý 2
> Hạt phấn có góp lục lạp cho hợp tử không?

> [!loi-giai] Lời giải
> Trứng được tạo ra từ hoa trên **cành lá xanh**, nên tế bào chất của trứng chỉ chứa lục lạp **bình thường**. Hạt phấn từ cành khảm chỉ góp nhân, không góp lục lạp.
>
> → Hợp tử chỉ có lục lạp bình thường → cây con **toàn lá xanh**.
>
> Điều quyết định là tế bào chất của **chính tế bào trứng**, tức là loại **cành** mang hoa làm mẹ, chứ không phải "cả cây" là cây khảm. Đó là lí do Correns phải ghi rõ hoa nằm trên cành nào.

## 2. Đặc điểm di truyền gene ngoài nhân

Từ thí nghiệm của Correns và những nghiên cứu sau đó, sự di truyền của tính trạng do gene ngoài nhân quy định có các đặc điểm sau. Với mỗi đặc điểm, em hãy nhớ **vì sao**.

| Đặc điểm | Vì sao? |
|---|---|
| 1. **Lai thuận và lai nghịch cho kết quả khác nhau**. Tính trạng di truyền **theo dòng mẹ** và biểu hiện ở **cả hai giới** | Con nhận tế bào chất từ mẹ, dù con là đực hay cái |
| 2. Vai trò của giao tử đực và giao tử cái **không ngang nhau**: vai trò chủ yếu thuộc về **tế bào chất của giao tử cái** | Trứng có nhiều tế bào chất, tinh trùng gần như chỉ góp nhân |
| 3. Gene ngoài nhân **không tồn tại thành cặp allele** như gene trong nhân, **chỉ cần một allele** là biểu hiện ra kiểu hình | Mỗi ti thể, lục lạp mang DNA vòng riêng với nhiều bản sao, không có "chiếc tương đồng" từ bố |
| 4. Con của **cùng một mẹ** có thể nhận **số lượng các allele khác nhau**, nên có thể có **kiểu hình khác nhau** | Ti thể, lục lạp chia ngẫu nhiên, không đều khi phân bào |
| 5. **Không có sự tái tổ hợp** gene ngoài nhân trong quá trình thụ tinh | Gene ngoài nhân chỉ đến từ một phía (mẹ), không có sự kết hợp hai bộ gene ngoài nhân |

> [!bay] Đừng nói "gene ngoài nhân là trội" hay "lặn"
> Khái niệm trội – lặn chỉ dùng khi có **cặp allele** trong cùng một tế bào (Aa). Gene ngoài nhân không có cặp, nên lá trắng ở đời con của mẹ lá trắng không phải vì "trắng trội". Chỉ đơn giản là con chỉ có lục lạp của mẹ.

**Hệ quả quan trọng: kiểu hình đời sau không bị "pha" đi.** Ở gene trong nhân, F~1~ dị hợp tự thụ phấn sẽ cho F~2~ phân li 3 : 1. Ở gene ngoài nhân, F~1~ nhận toàn bộ tế bào chất từ mẹ, nên F~1~ tự thụ phấn vẫn cho F~2~ **giống F~1~**, không phân li theo tỉ lệ Mendel.

> [!vi-du] Ví dụ 3
> Ở một loài thực vật, màu lá do gene trong lục lạp quy định (lục lạp bình thường cho lá xanh, lục lạp đột biến cho lá vàng, cây lá vàng vẫn sống được). Cho cây ♀ lá xanh × cây ♂ lá vàng được F~1~.
>
> a) F~1~ có màu lá thế nào? Cho F~1~ tự thụ phấn, F~2~ thế nào?
>
> b) Lấy hạt phấn của F~1~ thụ cho cây mẹ lá vàng. Đời con có màu lá thế nào?

> [!goi-y] Gợi ý 1
> Mỗi lần lai, chỉ cần hỏi: **ai làm mẹ**? Mẹ có loại lục lạp nào?

> [!goi-y] Gợi ý 2
> Ở câu b, F~1~ làm bố. Bố có góp lục lạp không?

> [!loi-giai] Lời giải
> a) Mẹ lá xanh → F~1~ **100% lá xanh**. F~1~ tự thụ phấn: cây mẹ chính là F~1~ lá xanh → F~2~ **100% lá xanh**, không có tỉ lệ 3 : 1.
>
> b) Mẹ lá vàng, F~1~ chỉ làm bố → đời con **100% lá vàng**, dù bố lá xanh.
>
> Nhận xét: lá xanh của F~1~ không "lấn át" được gì khi F~1~ làm bố. Đây chính là điểm khác cốt lõi với gene trội trong nhân.

### 2.1. Phân biệt gene ngoài nhân với gene trong nhân

Đây là phần đề thi rất hay hỏi. Ba trường hợp đều có thể cho F~1~ "giống mẹ" ở **một** phép lai, nên em phải nhìn **cả cặp lai thuận nghịch** và **từng giới**.

| | Gene trên NST thường | Gene trên X (không có allele trên Y) | Gene ngoài nhân |
|---|---|---|---|
| Lai thuận và lai nghịch | **giống nhau** | **khác nhau** | **khác nhau** |
| Kiểu hình ở hai giới | như nhau | **khác nhau** (thường gặp: đực giống mẹ, cái giống bố khi mẹ mang tính trạng lặn) | như nhau, **cả đực và cái đều giống mẹ** |
| Vai trò của bố, mẹ | ngang nhau | X của bố chỉ truyền cho con gái | chủ yếu là mẹ |
| Tồn tại thành cặp allele? | có | có ở giới XX, giới XY chỉ có một | không |
| Tỉ lệ kiểu hình ở F~2~ | theo Mendel (3 : 1…) | 3 : 1 hoặc 1 : 1, khác nhau theo giới | giống mẹ (F~1~), không theo tỉ lệ Mendel |
| Thay nhân bằng nhân khác (mở rộng) | tính trạng đổi theo nhân | tính trạng đổi theo nhân | tính trạng **giữ nguyên** theo tế bào chất |

> [!bay] "Lai thuận nghịch khác nhau → gene ngoài nhân" – CHƯA ĐỦ
> Gene trên NST X (thí nghiệm Morgan, Bài 10) cũng cho lai thuận nghịch khác nhau. Muốn kết luận gene ngoài nhân, phải thấy thêm: **mọi con** (cả đực lẫn cái) đều có kiểu hình **giống mẹ** ở **cả hai** phép lai.

> [!meo] Phép thử "thay nhân" (mở rộng, ngoài SGK)
> Một cách nhận biết gene ngoài nhân là **lai trở lại liên tiếp**: lấy con cái của mỗi đời lai với con đực của một dòng khác qua nhiều thế hệ. Nhân của dòng mẹ ban đầu bị thay dần bởi nhân của dòng bố (mỗi đời giảm một nửa), nhưng tế bào chất vẫn là của dòng mẹ ban đầu. Nếu tính trạng vẫn **không đổi** sau nhiều đời như vậy, nó do gene **ngoài nhân** quy định.

> [!vi-du] Ví dụ 4
> Lấy cây ♀ dòng M lai với cây ♂ dòng N được F~1~. Lấy F~1~ làm mẹ, lai trở lại với ♂ dòng N được thế hệ B~1~. Lấy B~1~ làm mẹ, lai tiếp với ♂ dòng N được B~2~, rồi tương tự được B~3~. Theo lí thuyết, ở B~3~:
>
> a) bộ gene **trong nhân** có trung bình bao nhiêu phần trăm có nguồn gốc từ dòng M?
>
> b) gene **ngoài nhân** có nguồn gốc từ dòng nào?

> [!goi-y] Gợi ý 1
> F~1~ có một nửa bộ gene nhân từ M. Mỗi lần lai với ♂ N, con nhận một nửa bộ gene nhân từ mẹ (trong đó có phần của M) và một nửa từ N.

> [!goi-y] Gợi ý 2
> Còn tế bào chất thì con nhận từ ai qua mỗi đời?

> [!loi-giai] Lời giải
> a) F~1~: $\tfrac12$ nhân từ M. Mỗi lần lai trở lại, phần của M giảm một nửa:
>
> B~1~: $\tfrac14$, B~2~: $\tfrac18$, B~3~: $\left(\tfrac12\right)^4 = \tfrac{1}{16} = 6{,}25\%$.
>
> b) Qua mọi thế hệ, cây mẹ luôn là "con cháu theo dòng mẹ" của M (F~1~ → B~1~ → B~2~ → B~3~), nên gene ngoài nhân của B~3~ **100% từ dòng M**.
>
> Như vậy sau vài thế hệ, ta có cây mang **nhân gần như của N** trong **tế bào chất của M**. Đây chính là cách các nhà chọn giống "chuyển" một tính trạng tế bào chất (ví dụ bất dục đực, mục 3.2) sang một giống mới.

> [!em-co-biet] Ngoài SGK: "ảnh hưởng của mẹ" không phải là di truyền ngoài nhân
> Ở ốc sên *Lymnaea*, chiều xoắn của vỏ con (xoắn phải hay xoắn trái) lại do **kiểu gene trong nhân của mẹ** quyết định, vì sản phẩm của gene này đã được mẹ đưa sẵn vào trứng. Kiểu hình con cũng "theo mẹ", nhưng gene nằm **trong nhân** nên vẫn phân li theo Mendel, chỉ là biểu hiện chậm một thế hệ. SGK không học hiện tượng này. Em chỉ cần nhớ: "di truyền ngoài nhân" là khi **gene** nằm trong ti thể, lục lạp.

## 3. Ứng dụng của di truyền gene ngoài nhân

Hiểu biết về gene ngoài nhân được dùng trong nghiên cứu tiến hóa, y học, nông nghiệp, pháp y…

### 3.1. Trong y học

Ở người, một số bệnh (phần lớn là bệnh hiếm gặp) do gene trong **ti thể** quy định. SGK kể đến bệnh **cơ ti thể**, **hội chứng Leigh** (thoái hóa hệ thần kinh sớm) và một số trường hợp tiểu đường, tim mạch, Alzheimer… (SGK tr. 80). Ti thể là "nhà máy năng lượng" của tế bào, nên khi gene ti thể hỏng, các mô cần nhiều năng lượng như **cơ, thần kinh, tim** bị ảnh hưởng nặng nhất.

**Đọc phả hệ bệnh do gene ti thể** (Hình 3):

- Mẹ bệnh → **tất cả** con (cả trai lẫn gái) đều bệnh.
- Bố bệnh, mẹ bình thường → **không** con nào bị bệnh, vì bố không truyền ti thể cho con.
- Bệnh gặp ở **cả nam và nữ**, nhưng chỉ đi tiếp theo **dòng nữ**.

![Hình 3. Phả hệ một bệnh do gene ti thể: người mẹ số 2 và số 6 truyền bệnh cho mọi con, người bố số 4 bị bệnh nhưng các con đều bình thường](hinh-3-pha-he-ti-the.svg)

> [!bay] Phả hệ bệnh ti thể và bệnh liên kết X
> - Bệnh do allele **lặn trên X**: mẹ bệnh thì **mọi con trai** bệnh, nhưng con gái có thể bình thường (nhận X bình thường từ bố).
> - Bệnh do allele **trội trên X**: **bố** bệnh thì **mọi con gái** bệnh.
> - Bệnh do **gene ti thể**: mẹ bệnh thì **mọi con** bệnh (cả trai lẫn gái), bố bệnh thì không truyền cho con nào.

Trong thực tế, mức độ bệnh giữa các con có thể **nặng nhẹ khác nhau**. Nguyên nhân là đặc điểm 4: trong tế bào trứng của mẹ có cả ti thể bình thường và ti thể đột biến với tỉ lệ khác nhau. Trong các bài tập, để đơn giản, đề thường cho "theo lí thuyết, mẹ bệnh thì mọi con đều bệnh" như SGK.

> [!vi-du] Ví dụ 5
> Dựa vào phả hệ ở Hình 3 (bệnh do gene ti thể).
>
> a) Người số 9 lấy chồng bình thường. Theo lí thuyết, xác suất con của họ bị bệnh là bao nhiêu?
>
> b) Người số 10 lấy chồng bình thường. Theo lí thuyết, xác suất con của họ bị bệnh là bao nhiêu?
>
> c) Trong phả hệ, những người nào chắc chắn mang ti thể đột biến?

> [!goi-y] Gợi ý 1
> Người số 9 nhận ti thể từ ai? Mẹ của số 9 (số 3) có bệnh không?

> [!goi-y] Gợi ý 2
> Câu c: ai bị bệnh thì chắc chắn mang ti thể đột biến. Người bình thường có "mang gene bệnh mà không biểu hiện" như allele lặn không?

> [!loi-giai] Lời giải
> a) Số 9 là con của bố bệnh (4) và mẹ bình thường (3). Ti thể của số 9 đến từ mẹ số 3, nên số 9 **không** mang ti thể đột biến. Con của số 9 nhận ti thể từ số 9 → xác suất bị bệnh = **0**.
>
> b) Số 10 bị bệnh (nhận ti thể đột biến từ mẹ số 6). Con của số 10 nhận ti thể của mẹ → xác suất bị bệnh = **1** (100%).
>
> c) Theo lí thuyết của bài, người bị bệnh là người mang ti thể đột biến: số **2, 4, 5, 6, 10, 11**. Người bình thường không mang. Gene ngoài nhân không có trạng thái "dị hợp mang gene lặn" như gene trong nhân.

**Kĩ thuật thay ti thể ("em bé ba cha mẹ").** Với người phụ nữ mang ti thể đột biến, các nhà khoa học có thể giúp chị sinh con khỏe mạnh như sau (SGK tr. 81, Hình 15.3):

1. Lấy **nhân** từ tế bào trứng của người mẹ (nhân không có lỗi, lỗi nằm ở ti thể).
2. Lấy trứng của một **người cho trứng** khỏe mạnh, **loại bỏ nhân** của trứng này, giữ lại tế bào chất có ti thể bình thường.
3. Chuyển nhân của người mẹ vào trứng đã loại nhân ở bước 2, rồi cho **thụ tinh** với tinh trùng của người chồng.

Năm 2016, một nhóm bác sĩ đã dùng kĩ thuật này tại Mexico để giúp một người mẹ mang gene đột biến gây hội chứng Leigh sinh ra một bé trai khỏe mạnh.

> [!vi-du] Ví dụ 6
> Một em bé được sinh ra nhờ kĩ thuật thay ti thể nói trên.
>
> a) DNA trong nhân và DNA ti thể của em bé lần lượt có nguồn gốc từ những ai?
>
> b) Nếu em bé là con gái, sau này lớn lên lấy chồng bình thường, con của cô có nguy cơ mắc hội chứng Leigh do ti thể của bà ngoại không?

> [!goi-y] Gợi ý 1
> Nhân của hợp tử được tạo từ nhân trứng và nhân tinh trùng. Tế bào chất của hợp tử là của trứng nào?

> [!loi-giai] Lời giải
> a) **DNA nhân**: một nửa từ **mẹ** (nhân trứng được chuyển sang), một nửa từ **bố** (tinh trùng). **DNA ti thể**: 100% từ **người cho trứng**.
>
> b) **Không**. Cô gái mang ti thể bình thường của người cho trứng. Khi sinh con, cô truyền chính các ti thể bình thường này cho con. Ti thể đột biến của người mẹ ban đầu đã bị loại ra từ bước tách nhân. (Nếu em bé là con trai thì càng không truyền ti thể cho con.)

> [!em-co-biet] Ngoài SGK: hệ gene ti thể người nhỏ đến đâu?
> DNA ti thể người dài khoảng **16 569 cặp nucleotide**, chứa **37 gene** (13 gene mã hóa chuỗi polypeptide của chuỗi hô hấp, 22 gene tRNA, 2 gene rRNA). So với hệ gene nhân khoảng 3,2 tỉ cặp nucleotide thì rất nhỏ. Nhưng mỗi tế bào có hàng trăm đến hàng nghìn ti thể, mỗi ti thể lại có vài bản sao DNA, nên số bản sao DNA ti thể trong một tế bào lớn hơn rất nhiều so với số bản sao của một gene trong nhân (chỉ 2 bản).

### 3.2. Trong nông nghiệp

Ở thực vật có hiện tượng **bất dục đực tế bào chất**: do **đột biến gene trong ti thể**, cây **không tạo được hạt phấn hữu thụ**, nhưng việc hình thành **trứng** vẫn bình thường. Hiện tượng này đã được tìm thấy ở hơn 140 loài.

**Vì sao nó quý?** Lúa là cây **lưỡng tính, tự thụ phấn**. Muốn lai hai giống lúa, người ta phải **khử đực** (cắt bỏ bao phấn) ở từng hoa của cây mẹ rồi rắc phấn của cây bố. Việc này tốn rất nhiều công, không thể làm trên đồng ruộng lớn. Nếu dùng **dòng lúa bất dục đực** làm mẹ, cây mẹ không tự thụ phấn được, nên chỉ cần trồng xen với dòng bố, hạt thu trên cây mẹ chắc chắn là **hạt lai**. Nhờ đó đã tạo ra nhiều giống lúa lai năng suất cao, chất lượng tốt như **VT 505, MV2, Long Hương 8117**… (SGK tr. 81).

> [!em-co-biet] Ngoài SGK: hệ thống "lúa lai ba dòng"
> Nếu F~1~ cũng bất dục đực (vì nhận tế bào chất bất dục của mẹ) thì ruộng lúa lai sẽ không có hạt! Người ta giải quyết bằng một **gene phục hồi hữu dục** nằm **trong nhân** (kí hiệu R, trội). Thường dùng 3 dòng:
> - **dòng A** (bất dục đực): tế bào chất bất dục (S), nhân rr.
> - **dòng B** (duy trì): tế bào chất bình thường (N), nhân rr, hữu dục. Dòng B dùng để nhân giống dòng A.
> - **dòng R** (phục hồi): nhân RR, hữu dục.

> [!vi-du] Ví dụ 7 (mở rộng)
> Dùng giả thiết của hệ "ba dòng" ở khung trên (ngoài SGK): cây có tế bào chất (N) luôn hữu dục. Cây có tế bào chất (S) bất dục đực nếu nhân là rr, hữu dục nếu nhân có ít nhất một allele R. Theo lí thuyết:
>
> a) Lai dòng A (làm mẹ) × dòng B (làm bố). Đời con có tế bào chất, kiểu gene nhân và khả năng tạo hạt phấn thế nào?
>
> b) Lai dòng A (làm mẹ) × dòng R (làm bố). F~1~ (lúa lai thương phẩm) có hạt phấn hữu thụ không?

> [!goi-y] Gợi ý 1
> Tế bào chất của con: hỏi mẹ. Kiểu gene nhân của con: ghép như Mendel (một allele từ mẹ, một từ bố).

> [!loi-giai] Lời giải
> a) Tế bào chất từ mẹ A: **(S)**. Nhân: r (từ A) + r (từ B) = **rr**. → (S)rr **bất dục đực**, giống hệt dòng A. Đó là cách "nhân giống" dòng A mà vẫn giữ được tính bất dục.
>
> b) Tế bào chất: **(S)** từ mẹ. Nhân: r (từ A) + R (từ R) = **Rr**. Có allele R phục hồi → F~1~ **hữu dục**, tự thụ phấn bình thường để cho hạt trên ruộng.

### 3.3. Trong nghiên cứu tiến hóa và pháp y

Hệ gene ti thể có ba đặc điểm khiến nó trở thành "công cụ" rất tốt:

- **Nhiều bản sao** trong mỗi tế bào → dù mẫu (xương, răng, tóc) đã bị phân hủy nặng, vẫn dễ còn sót những đoạn DNA ti thể nguyên vẹn để giải trình tự.
- **Di truyền theo dòng mẹ** và **không tái tổ hợp** → DNA ti thể của con gần như **giống hệt** của mẹ, của bà ngoại… Những khác biệt chỉ do đột biến tích lũy qua rất nhiều thế hệ.
- Vì vậy, so sánh trình tự DNA ti thể cho biết hai người, hai nhóm sinh vật **gần nhau** đến đâu theo dòng mẹ.

**Tiến hóa.** Các nhà khoa học giải trình tự DNA ti thể để xây dựng **cây phân loại**, tìm nguồn gốc các chủng tộc người. So sánh DNA ti thể tách từ xương hóa thạch của các loài người đã tuyệt chủng với DNA ti thể của người hiện đại cho thấy loài người xuất hiện ở **châu Phi**, rồi phát tán ra các châu lục khác.

**Pháp y.** Giải trình tự DNA ti thể giúp xác định **hài cốt liệt sĩ**, nhận dạng nạn nhân trong các vụ tai nạn, xác định quan hệ huyết thống. Muốn so sánh, phải lấy mẫu của người **cùng dòng mẹ** với người cần xác định.

> [!vi-du] Ví dụ 8
> Cần xác định một bộ hài cốt có phải là của liệt sĩ Q (nam) hay không bằng cách so sánh DNA ti thể. Mẹ liệt sĩ Q đã mất. Những người thân còn sống gồm: (1) chị gái ruột của Q, (2) con trai của Q, (3) con gái của chị gái Q, (4) con trai của anh trai Q, (5) dì ruột (em gái của mẹ Q). Những người nào cho mẫu so sánh được?

> [!goi-y] Gợi ý 1
> DNA ti thể của Q là của mẹ Q. Ai cũng mang DNA ti thể của mẹ Q (hoặc của bà ngoại Q)?

> [!goi-y] Gợi ý 2
> Con của Q nhận ti thể từ ai? Con của anh trai Q nhận ti thể từ ai?

> [!loi-giai] Lời giải
> DNA ti thể của Q đến từ mẹ Q, mẹ Q lại nhận từ bà ngoại Q.
>
> - (1) Chị gái ruột: cùng mẹ → **dùng được**.
> - (2) Con trai của Q: nhận ti thể từ **vợ** Q → không dùng được.
> - (3) Con gái của chị gái: ti thể từ chị gái, tức từ mẹ Q → **dùng được**.
> - (4) Con trai của anh trai: ti thể từ **vợ của anh trai** → không dùng được.
> - (5) Dì ruột: cùng mẹ với mẹ Q (bà ngoại Q) → **dùng được**.
>
> Đáp số: **(1), (3), (5)**. Mẹo: chỉ đi theo các mũi tên **mẹ → con**.

> [!ung-dung] Tìm hài cốt liệt sĩ ở Việt Nam
> Việt Nam còn nhiều hài cốt liệt sĩ chưa xác định được danh tính. Ở nhiều trường hợp, bố mẹ liệt sĩ đã mất, mẫu xương lại bị hủy hoại sau nhiều chục năm trong đất. DNA ti thể với nhiều bản sao và di truyền theo dòng mẹ giúp so sánh với anh chị em ruột, cháu gọi bằng cậu, dì… của liệt sĩ.

## Dạng bài thi hay gặp

### Dạng 1. Nhận biết gene ngoài nhân từ kết quả lai thuận nghịch

*Nhận biết:* đề cho kết quả của cặp lai thuận nghịch (hoặc của một phép lai rồi hỏi phép lai ngược lại), hỏi tính trạng do gene nằm ở đâu.

*Phương pháp:*
1. So sánh hai phép lai. **Giống nhau** → gene trên **NST thường** (trong nhân).
2. **Khác nhau** → xét từng giới:
   - đời con, **cả đực và cái**, đều **giống mẹ** ở cả hai phép lai → **gene ngoài nhân** (tế bào chất);
   - kiểu hình **khác nhau giữa hai giới** (con đực giống mẹ, con cái giống bố ở phép lai mẹ mang tính trạng lặn) → gene trên **X**.
3. Nếu có thêm F~2~: gene ngoài nhân cho F~2~ giống mẹ F~1~, không có tỉ lệ 3 : 1.

> [!vi-du] Ví dụ 9
> Ở một loài côn trùng (con cái XX, con đực XY), xét ba tính trạng, mỗi tính trạng có hai dạng ở hai dòng thuần chủng P và Q (P mang dạng thứ nhất, Q mang dạng thứ hai). Kết quả lai thuận nghịch như sau:
>
> | Tính trạng | ♀ P × ♂ Q | ♀ Q × ♂ P |
> |---|---|---|
> | Màu thân | 100% thân xám (cả đực và cái) | 100% thân xám (cả đực và cái) |
> | Màu mắt | 100% mắt đỏ (cả đực và cái) | cái: 100% mắt đỏ, đực: 100% mắt nâu |
> | Khả năng chịu thuốc | 100% chịu thuốc (cả đực và cái) | 100% không chịu thuốc (cả đực và cái) |
>
> Biết dòng P có thân xám, mắt đỏ, chịu thuốc. Xác định vị trí gene quy định mỗi tính trạng.

> [!goi-y] Gợi ý 1
> Với mỗi hàng, hai cột có giống nhau không?

> [!goi-y] Gợi ý 2
> Ở hàng nào kết quả khác nhau, hãy so sánh con đực với con cái, rồi so với mẹ.

> [!loi-giai] Lời giải
> - **Màu thân**: thuận = nghịch → gene trên **NST thường**, thân xám trội hoàn toàn.
> - **Màu mắt**: thuận ≠ nghịch. Ở phép lai ♀ Q (mắt nâu) × ♂ P (mắt đỏ), con cái mắt đỏ giống bố, con đực mắt nâu giống mẹ → kiểu hình **khác nhau giữa hai giới** → gene trên **vùng không tương đồng của X**, đỏ trội.
> - **Khả năng chịu thuốc**: thuận ≠ nghịch, và ở cả hai phép lai **mọi con** (đực lẫn cái) đều giống **mẹ** → gene **ngoài nhân** (thường là gene ti thể).

*Bẫy:* chỉ nhìn phép lai ♀ P × ♂ Q thì cả ba tính trạng đều "100% giống mẹ"! Phải xem phép lai nghịch mới phân biệt được.

### Dạng 2. Xác định kiểu hình đời con khi có gene ngoài nhân

*Nhận biết:* đề nói rõ tính trạng do gene trong ti thể/lục lạp (hoặc "di truyền theo dòng mẹ"), có thể kèm thêm gene trong nhân.

*Phương pháp:*
1. **Tính trạng do gene ngoài nhân**: chỉ nhìn **mẹ**. Mẹ thuần một loại → con 100% giống mẹ. Mẹ có cả hai loại (khảm) → con có thể có nhiều loại, không có tỉ lệ xác định.
2. **Tính trạng do gene trong nhân**: tính như Mendel (Bài 8 – 11).
3. Hai loại gene di truyền **độc lập** với nhau → tỉ lệ chung = tích các tỉ lệ.

> [!vi-du] Ví dụ 10
> Ở cây cải dầu, khả năng kháng thuốc diệt cỏ atrazine do gene trong lục lạp quy định (một ví dụ thực tế, ngoài SGK: các dòng cải dầu kháng atrazine mang đột biến ở một gene lục lạp và di truyền theo dòng mẹ). Chiều cao cây do gene trong nhân quy định, allele A (thân cao) trội hoàn toàn so với a (thân thấp). Lai cây ♀ kháng thuốc, thân thấp với cây ♂ không kháng thuốc, thân cao thuần chủng được F~1~. Theo lí thuyết:
>
> a) F~1~ có kiểu hình thế nào?
>
> b) Cho F~1~ tự thụ phấn được F~2~. Tỉ lệ kiểu hình ở F~2~ là bao nhiêu?
>
> c) Lấy hạt phấn của F~1~ thụ cho cây không kháng thuốc, thân thấp. Tỉ lệ kiểu hình ở đời con là bao nhiêu?

> [!goi-y] Gợi ý 1
> Tách hai tính trạng. Kháng thuốc: ai làm mẹ ở mỗi phép lai? Chiều cao: P là aa × AA.

> [!goi-y] Gợi ý 2
> Câu c: F~1~ là Aa nhưng chỉ làm bố.

> [!loi-giai] Lời giải
> a) Kháng thuốc: mẹ kháng → F~1~ **100% kháng**. Chiều cao: aa × AA → **Aa**, thân cao. F~1~: **100% kháng thuốc, thân cao**.
>
> b) F~1~ tự thụ: mẹ là F~1~ kháng → F~2~ 100% kháng. Aa × Aa → 3 cao : 1 thấp. F~2~: **3 kháng, cao : 1 kháng, thấp**.
>
> c) Mẹ không kháng → con 100% **không kháng**. aa × Aa → 1 cao : 1 thấp. Đời con: **1 không kháng, cao : 1 không kháng, thấp**.

*Bẫy:* tính kháng thuốc thành "trội" rồi áp tỉ lệ 3 : 1 cho cả tính trạng ngoài nhân.

### Dạng 3. Phả hệ bệnh do gene ti thể

*Nhận biết:* phả hệ có đặc điểm: **mọi** con của người mẹ bệnh đều bệnh, con của người bố bệnh (vợ bình thường) đều bình thường, bệnh gặp ở cả hai giới.

*Phương pháp:*
1. Kiểm tra quy luật: mẹ bệnh → mọi con bệnh? bố bệnh → không con nào bệnh? Nếu đúng cả hai thì là gene ti thể.
2. Loại trừ: nếu có một người mẹ bệnh mà có con bình thường thì không phải gene ti thể (theo lí thuyết).
3. Tính xác suất: chỉ cần xét **người mẹ**. Mẹ bệnh → xác suất con bệnh = 1. Mẹ bình thường → xác suất = 0. Nếu có thêm bệnh do gene trong nhân, tính riêng rồi nhân.

> [!vi-du] Ví dụ 11
> Một bệnh hiếm gặp ở người được ghi nhận trong một dòng họ: ông A bị bệnh, vợ ông bình thường, sinh hai con gái và một con trai đều bình thường. Bà B bị bệnh, chồng bà bình thường, sinh hai con trai và hai con gái đều bị bệnh. Một con gái của bà B lấy chồng bình thường, sinh hai con đều bị bệnh.
>
> a) Bệnh này nhiều khả năng do gene nằm ở đâu? Vì sao có thể loại trừ gene lặn trên X và gene trội trên X?
>
> b) Một con trai của bà B lấy vợ bình thường. Theo lí thuyết, xác suất họ sinh con bị bệnh là bao nhiêu?

> [!goi-y] Gợi ý 1
> Gene trội trên X: bố bệnh thì con gái thế nào? Gene lặn trên X: mẹ bệnh, bố bình thường thì con gái thế nào?

> [!goi-y] Gợi ý 2
> Con trai của bà B có truyền ti thể cho con không?

> [!loi-giai] Lời giải
> a) Mọi con của mẹ bệnh đều bệnh, con của bố bệnh đều bình thường, cả nam và nữ đều mắc → di truyền **theo dòng mẹ**, gene nằm trong **ti thể**.
>
> - Loại **trội trên X**: nếu vậy, ông A bệnh phải truyền X mang allele bệnh cho **mọi con gái**. Nhưng hai con gái của ông A đều bình thường.
> - Loại **lặn trên X**: nếu vậy, con gái của bà B (bệnh) với chồng bình thường phải nhận X bình thường của bố, nên **không bị bệnh**. Nhưng hai con gái của bà B đều bệnh.
>
> b) Con trai không truyền ti thể cho con. Vợ bình thường → con nhận ti thể bình thường → xác suất = **0**.

*Bẫy:* thấy "mẹ bệnh → con trai bệnh" là kết luận ngay "lặn trên X". Phải xem cả **con gái** và con của **bố** bệnh.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Correns (1909), cây hoa bốn giờ | Lai các cành xanh, trắng, khảm: F~1~ luôn **giống cành làm mẹ**. Mẹ khảm → con có cả xanh, trắng, khảm |
| Gene ngoài nhân | Nằm trên DNA **vòng, nhỏ** của **ti thể, lục lạp** |
| Vì sao theo mẹ | Hợp tử nhận tế bào chất **hầu như chỉ từ trứng** |
| Đặc điểm | Lai thuận ≠ lai nghịch, con **giống mẹ ở cả hai giới**. Vai trò chính là tế bào chất của giao tử cái. **Một allele đã biểu hiện**. Con cùng mẹ có thể khác nhau (chia ngẫu nhiên). Không tái tổ hợp khi thụ tinh |
| Phân biệt với gene trên X | Gene trên X: lai thuận ≠ nghịch nhưng **hai giới khác nhau**. Gene ngoài nhân: hai giới như nhau, đều giống mẹ |
| Phả hệ bệnh ti thể | Mẹ bệnh → **mọi con** bệnh. Bố bệnh → không truyền |
| Y học | Bệnh cơ ti thể, hội chứng Leigh… Kĩ thuật **thay ti thể**: nhân của mẹ + tế bào chất của người cho trứng |
| Nông nghiệp | **Bất dục đực tế bào chất** (gene ti thể): không cần khử đực khi lai, tạo lúa lai (VT 505, MV2, Long Hương 8117) |
| Tiến hóa, pháp y | DNA ti thể nhiều bản sao, theo dòng mẹ, không tái tổ hợp: truy nguồn gốc loài người (châu Phi), xác định hài cốt, huyết thống **theo dòng mẹ** |

> [!ghi-nho] Ba câu chốt
> - Gene ngoài nhân: **chỉ hỏi mẹ**. Mẹ thế nào, con (cả đực và cái) thế ấy.
> - Lai thuận ≠ lai nghịch: nếu **mọi con giống mẹ** → ngoài nhân. Nếu **hai giới khác nhau** → gene trên X.
> - Phả hệ: mẹ bệnh → mọi con bệnh, bố bệnh → không con nào bệnh → **gene ti thể**. Mẫu so sánh DNA ti thể phải lấy từ người **cùng dòng mẹ**.
