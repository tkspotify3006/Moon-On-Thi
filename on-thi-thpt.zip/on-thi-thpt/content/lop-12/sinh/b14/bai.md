---
title: Thực hành: Quan sát một số dạng đột biến nhiễm sắc thể
thoi-gian: 30 phút
muc-tieu:
  - Thực hành quan sát được đột biến NST trên tiêu bản cố định (hoặc trên ảnh chụp bộ NST).
  - Giải thích được nguyên lí: so sánh số lượng, hình dạng, kích thước NST của tiêu bản đột biến với bộ NST bình thường cùng loài.
  - Sử dụng đúng kính hiển vi với các vật kính 10×, 40×, 100× (vật kính dầu) và giải thích được vì sao làm theo trình tự đó.
  - Đọc được kết quả quan sát để kết luận dạng đột biến (lệch bội, đa bội, mất đoạn, lặp đoạn…), biết giới hạn của phương pháp.
  - Trả lời được các câu hỏi thu hoạch: vì sao phần lớn đột biến NST có hại, cách kiểm chứng một cây nghi là thể đa bội.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. **Mục đích:** nhận ra đột biến NST bằng mắt, dưới kính hiển vi, trên **tiêu bản cố định** (tế bào đã dừng ở **kì giữa**, đã nhuộm màu).
> 2. **Nguyên lí:** trong bộ 2n bình thường, NST tồn tại thành **cặp tương đồng giống nhau** về hình dạng, kích thước (trừ cặp NST giới tính). Lệch khỏi "bản chuẩn" đó → có đột biến.
> 3. **Cách đọc:** đếm **số lượng** (khác 2n → lệch bội hoặc đa bội), rồi so **từng cặp** (một chiếc ngắn hơn, dài hơn, tâm động lệch chỗ → đột biến cấu trúc).
> 4. **Kính hiển vi:** vật kính **10×** (tìm) → **40×** (đưa vào giữa) → nhỏ **dầu soi** → **100×** + chỉ dùng **ốc vi cấp**. Xong phải **lau dầu**.
> 5. **Giới hạn:** chỉ thấy đột biến **đủ lớn** để làm đổi số lượng, chiều dài, vị trí tâm động. **Đột biến gene** và nhiều đột biến cấu trúc nhỏ **không** thấy được.

> [!nen-tang] Nhớ lại từ Bài 7 và Bài 12
> - NST quan sát rõ nhất ở **kì giữa** của nguyên phân: NST đã nhân đôi (gồm **2 chromatid** dính nhau ở **tâm động**) và **co xoắn cực đại**.
> - Vị trí tâm động chia NST thành **hai vai**. Tâm động ở giữa thì hai vai gần bằng nhau, tâm động lệch thì một vai ngắn một vai dài. Vị trí tâm động là một "dấu vân tay" giúp nhận ra từng NST.
> - Bốn dạng đột biến cấu trúc (mất, lặp, đảo, chuyển đoạn) và hai nhóm đột biến số lượng (lệch bội, đa bội): xem **Bài 12**. Cách lập bộ NST đồ (karyotype) người: xem **Bài 13**, mục 2.3.

**Câu hỏi mở bài.** Trong Bài 12 và Bài 13, em đã biết hội chứng Down là do thừa một NST 21. Nhưng làm sao bác sĩ "nhìn thấy" được một chiếc NST thừa trong hàng chục chiếc NST bé xíu, mà không cần biết trình tự gene nào? Bài thực hành này trả lời câu hỏi đó: em sẽ đọc bộ NST giống như người ta đọc một tấm ảnh chụp.

## 1. Mục đích và chuẩn bị

### 1.1. Mục đích

Quan sát, nhận biết được một số dạng **đột biến NST** trên **tiêu bản cố định** (hoặc ảnh chụp bộ NST) bằng cách so sánh với bộ NST **bình thường** cùng loài (SGK tr. 75).

### 1.2. Dụng cụ và mẫu vật — mỗi thứ dùng để làm gì?

| Dụng cụ, mẫu vật | Dùng để | Ghi chú |
|---|---|---|
| Kính hiển vi quang học (vật kính 10×, 40×, 100×) | phóng đại tế bào để thấy NST | độ phóng đại = thị kính × vật kính, ví dụ 10 × 100 = **1 000 lần** |
| Dầu soi kính | nhỏ giữa vật kính 100× và tiêu bản | giúp ảnh rõ, sắc nét (xem mục 2.3) |
| Giấy lau kính chuyên dụng | lau dầu sau khi soi | giấy thường làm xước thấu kính |
| Tiêu bản cố định bộ NST **bình thường** và bộ NST **đột biến** của một số loài | đối tượng quan sát, có "mẫu chuẩn" để so | tế bào đã dừng ở kì giữa, NST đã nhuộm màu |
| Ảnh chụp bộ NST bình thường và đột biến; kéo cắt giấy | khi không có kính đủ tốt: cắt từng NST trên ảnh, xếp thành cặp để so sánh | đây chính là cách lập bộ NST đồ thủ công |

Tiêu bản **cố định** là tiêu bản mà tế bào đã được hoá chất "giữ nguyên" hình dạng, cấu trúc, NST đã được nhuộm màu và dán kín, dùng được nhiều năm. Nhờ vậy, trên lớp em không phải tự nuôi cấy, xử lí, nhuộm tế bào như ở phương pháp di truyền tế bào (Bài 13).

## 2. Nguyên lí — vì sao nhìn được đột biến NST?

### 2.1. "Bản chuẩn" để so sánh

Trong tế bào sinh dưỡng bình thường của loài lưỡng bội, NST tồn tại thành **từng cặp tương đồng**: hai chiếc trong một cặp **giống nhau về hình dạng và kích thước** (cùng chiều dài, cùng vị trí tâm động), một chiếc từ bố, một chiếc từ mẹ. Ngoại lệ duy nhất là **cặp NST giới tính** ở giới dị giao (ví dụ X và Y ở người nam khác hẳn nhau về kích thước).

Vì vậy, chỉ cần biết bộ NST bình thường của loài (số lượng 2n, hình dạng từng cặp), em có thể so một tế bào bất kì với "bản chuẩn" đó, giống như so một bộ bài với bộ bài đủ để tìm lá thừa, lá thiếu, lá bị rách.

> [!bay] Khác nhau chưa chắc là đột biến
> - Ở người **nam**, X và Y khác nhau rõ về kích thước. Đó là **bình thường**, không phải đột biến cấu trúc.
> - Ở một số loài (ví dụ một số loài châu chấu), con đực chỉ có **một** NST X (kiểu XO), nên bộ NST con đực **lẻ một chiếc** là bình thường của loài.
>
> Vì vậy luôn phải so với bộ NST **bình thường cùng loài, cùng giới**.

### 2.2. Ba câu hỏi khi nhìn một bộ NST

Khi quan sát, em lần lượt trả lời ba câu hỏi (SGK tr. 75):

1. **Tổng số NST có bằng 2n không?** Nếu khác 2n → đột biến **số lượng**.
   - Khác 2n **một vài chiếc**, thừa/thiếu ở một hoặc vài cặp → **lệch bội** (2n + 1, 2n − 1…).
   - Tổng số là **bội số của n** lớn hơn 2 (3n, 4n…), **mọi** nhóm tương đồng đều có 3 (hoặc 4) chiếc → **đa bội**.
2. **Hai chiếc trong mỗi cặp có dài bằng nhau không?** Một chiếc **ngắn hơn** → nghĩ đến **mất đoạn**. Một chiếc **dài hơn** → nghĩ đến **lặp đoạn**.
3. **Vị trí tâm động có giống nhau không?** Chiều dài bằng nhau mà tâm động **lệch chỗ** (tỉ lệ hai vai khác đi) → **đảo đoạn chứa tâm động**. Hai cặp **không tương đồng** cùng lúc có một chiếc đổi chiều dài (một dài ra, một ngắn đi) → **chuyển đoạn** giữa hai NST.

![Hình 1. Dấu hiệu nhận biết các dạng đột biến cấu trúc khi so hai chiếc của một cặp NST (sơ đồ, NST ở kì giữa)](hinh-1-cau-truc.svg)

![Hình 2. So sánh bộ NST bình thường (giả sử 2n = 6) với thể ba, thể một và thể tam bội](hinh-2-so-luong.svg)

(Bảng tra nhanh "dấu hiệu → kết luận" nằm ở mục **Tóm tắt** cuối bài.)

> [!bay] Đếm thấy "một chiếc dài hơn" — đã chắc là lặp đoạn chưa?
> Một NST dài ra có thể do **lặp đoạn**, cũng có thể do **nhận thêm đoạn từ NST khác** (chuyển đoạn). Muốn phân biệt, phải nhìn **cả bộ NST**: nếu có một NST không tương đồng khác bị ngắn đi → chuyển đoạn. Đề thi thường cho thêm câu "các NST khác bình thường" để em chốt là lặp đoạn.

### 2.3. Giới hạn của phương pháp: cái gì KHÔNG nhìn thấy?

Kính hiển vi quang học, dù phóng đại 1 000 lần, chỉ cho em thấy **hình dạng ngoài** của NST: số lượng, chiều dài, vị trí tâm động. Vì vậy:

- **Đột biến gene** (thay thế, mất, thêm một cặp nucleotide — Bài 4) **không** nhìn thấy được: NST vẫn y nguyên về hình dạng. Bệnh bạch tạng, hồng cầu hình liềm… không phát hiện bằng cách này (Bài 13).
- **Đảo đoạn không chứa tâm động**: chiều dài và vị trí tâm động **không đổi** → rất khó nhận ra nếu chỉ nhìn hình dạng. **Chuyển đoạn trong một NST** cũng giữ nguyên chiều dài, nên thường khó nhận ra.
- **Mất đoạn, lặp đoạn quá nhỏ**: chênh lệch chiều dài không đủ để mắt nhận ra.

> [!em-co-biet] Nhuộm băng: "mã vạch" của NST
> Các phòng xét nghiệm di truyền dùng kĩ thuật **nhuộm băng**: sau khi xử lí, mỗi NST hiện lên các vạch sáng – tối xen kẽ theo một trật tự đặc trưng, giống mã vạch trên bao bì. Nhờ đó, một đoạn bị đảo hay bị chuyển chỗ làm "mã vạch" đổi thứ tự và có thể nhận ra. Còn những đột biến nhỏ hơn nữa phải dùng các kĩ thuật phân tử như giải trình tự DNA.

## 3. Cách tiến hành và vì sao làm như vậy

### 3.1. Năm bước quan sát

| Bước | Làm gì (SGK tr. 75) | Vì sao |
|---|---|---|
| 1 | Đặt tiêu bản lên bàn kính, đưa vùng có mẫu vật vào giữa thị trường | ánh sáng tập trung ở giữa, ảnh rõ nhất ở giữa |
| 2 | Dùng vật kính **10×**, tìm tế bào có bộ NST **phân tán đều**, đưa vào giữa thị trường | độ phóng đại nhỏ → **thị trường rộng**, dễ "dò bản đồ" tìm tế bào tốt. NST phân tán đều thì không chồng lên nhau, đếm mới chính xác |
| 3 | Chuyển sang vật kính **40×**, chỉnh để bộ NST cần xem nằm **chính giữa**. Nhỏ **một giọt dầu soi** lên vùng đó | khi tăng độ phóng đại, thị trường thu hẹp lại quanh tâm. Nếu bộ NST lệch ra rìa ở 40×, sang 100× sẽ "mất dấu" |
| 4 | Chuyển sang vật kính **100×**, chỉ chỉnh bằng **ốc vi cấp** | vật kính 100× khi lấy nét nằm **rất sát** tiêu bản. Vặn ốc sơ cấp (nâng hạ nhanh) dễ làm vật kính đâm vỡ tiêu bản, xước thấu kính |
| 5 | Quan sát, **đếm** số lượng và xem **cấu trúc** NST, so với bộ NST bình thường cùng loài, ghi vào bảng kết quả | so sánh với "bản chuẩn" là cốt lõi của nguyên lí (mục 2) |

**Vì sao phải nhỏ dầu soi ở vật kính 100×?** Ánh sáng đi từ tiêu bản (thuỷ tinh) ra **không khí** rồi mới vào vật kính sẽ bị **khúc xạ, lệch hướng**. Với vật kính 100× (thấu kính rất nhỏ, đặt rất gần mẫu), phần ánh sáng lệch đi này bị mất khá nhiều, ảnh tối và nhoè. Dầu soi có tính chất quang học gần giống thuỷ tinh, lấp kín khe không khí → ánh sáng đi gần như thẳng vào vật kính → ảnh **sáng và nét** hơn, thấy được những chi tiết nhỏ như tâm động.

> [!bay] Ba lỗi thao tác hay bị hỏi
> - Bắt đầu ngay bằng vật kính 100× → thị trường quá hẹp, gần như không tìm thấy tế bào cần xem.
> - Lấy nét ở 100× bằng **ốc sơ cấp** → dễ vỡ tiêu bản, hỏng vật kính.
> - Quên **lau dầu** trên vật kính và tiêu bản sau khi dùng 100× → dầu khô bám lại, làm hỏng vật kính (SGK tr. 76).

> [!ung-dung] Không có kính 100× đủ tốt thì sao?
> SGK gợi ý dùng **ảnh chụp** bộ NST bình thường và bộ NST đột biến cùng loài, photo cho học sinh. Em có thể **cắt rời từng NST** trên ảnh rồi xếp thành cặp theo chiều dài giảm dần, giống cách lập bộ NST đồ (Bài 13). Cách này rất trực quan: chiếc "lẻ cặp" hay chiếc "ngắn bất thường" sẽ lộ ra ngay. Nếu có thiết bị nối kính hiển vi với máy chiếu, cả lớp có thể cùng quan sát trên màn hình lớn.

> [!vi-du] Ví dụ 1
> Bạn An soi tiêu bản bộ NST như sau: (1) đặt tiêu bản, chuyển ngay sang vật kính 100× cho "rõ nhất"; (2) không thấy gì nên vặn ốc sơ cấp hạ vật kính xuống; (3) nhỏ dầu soi sau khi đã thấy NST. a) Chỉ ra các chỗ sai và hậu quả. b) Sắp xếp lại các thao tác cho đúng.

> [!goi-y] Gợi ý 1
> Độ phóng đại càng lớn thì thị trường càng rộng hay càng hẹp? Ở vật kính 100×, vật kính cách tiêu bản xa hay gần?

> [!goi-y] Gợi ý 2
> Dầu soi phải có mặt **trước** khi vật kính 100× làm việc, vì nó là "cầu nối" ánh sáng giữa tiêu bản và vật kính.

> [!loi-giai] Lời giải
> a) Sai (1): dùng 100× ngay từ đầu, thị trường rất hẹp nên khó tìm thấy tế bào có bộ NST phù hợp. Sai (2): ở 100× vật kính rất sát tiêu bản, vặn ốc sơ cấp dễ làm vỡ tiêu bản, xước vật kính. Sai (3): thiếu dầu soi thì ảnh ở 100× tối, nhoè, khó thấy NST ngay từ đầu.
>
> b) Thứ tự đúng: đặt tiêu bản, đưa mẫu vào giữa thị trường → vật kính 10×, tìm tế bào có NST phân tán đều → vật kính 40×, đưa bộ NST vào chính giữa → nhỏ một giọt dầu soi → chuyển sang 100×, chỉnh ốc vi cấp → quan sát, đếm, ghi kết quả → lau sạch dầu bằng giấy lau chuyên dụng.

### 3.2. Ghi kết quả

Kết quả ghi theo mẫu Bảng 14.1 (SGK tr. 76) gồm bốn cột: **loài** · **hình ảnh quan sát được** (tiêu bản bình thường và tiêu bản đột biến) · **nhận xét** khi so với bộ NST bình thường · **kết luận** dạng đột biến. Một dòng mẫu (số liệu tự đặt):

| Loài | Hình ảnh quan sát | Nhận xét khi so với bộ bình thường | Kết luận |
|---|---|---|---|
| Loài thực vật X (2n = 12) | Tiêu bản bình thường: 12 NST, 6 cặp. Tiêu bản đột biến: 13 NST | cặp số 4 có 3 chiếc giống nhau, các cặp khác đủ 2 chiếc | thể ba (2n + 1) ở cặp số 4 |

> [!meo] Đếm NST không bị sót, không bị trùng
> Chia thị trường (hoặc ảnh) thành bốn góc, đếm xong góc nào đánh dấu góc đó trên hình vẽ phác. Các lỗi đếm khác: xem mục 5.

## 4. Đọc kết quả và giải thích

Đây là phần đề thi hay hỏi nhất. Quy trình chung:

1. **Đếm tổng số NST**, so với 2n của loài.
2. **Xếp NST thành nhóm** giống nhau về chiều dài và vị trí tâm động (mỗi nhóm bình thường có 2 chiếc).
3. Tìm nhóm **thừa/thiếu chiếc** (lệch bội), hay **mọi nhóm** đều thừa (đa bội), hay số chiếc đủ nhưng **một chiếc khác hình dạng** (cấu trúc).
4. Kết luận và **giải thích bằng cơ chế** (Bài 12): ví dụ thể ba do một cặp NST không phân li trong giảm phân của bố hoặc mẹ.

> [!vi-du] Ví dụ 2
> Một loài thực vật có 2n = 12. Quan sát tiêu bản tế bào đầu rễ (kì giữa nguyên phân) của bốn cây, kết quả:
>
> | Cây | Tổng số NST | Mô tả |
> |---|---|---|
> | P | 12 | 6 cặp, mỗi cặp hai chiếc giống nhau, riêng cặp số 2 có một chiếc ngắn hơn hẳn chiếc kia, tâm động ở cùng vị trí |
> | Q | 18 | 6 nhóm, mỗi nhóm 3 chiếc giống nhau |
> | R | 11 | cặp số 5 chỉ có một chiếc, các cặp khác bình thường |
> | S | 12 | 6 cặp, hai chiếc của cặp số 3 dài bằng nhau nhưng một chiếc có tâm động gần đầu mút hơn hẳn chiếc kia |
>
> Hãy kết luận dạng đột biến ở mỗi cây và giải thích.

> [!goi-y] Gợi ý 1
> Bước đầu tiên: so tổng số với 12. Cây nào khác 12, khác bao nhiêu? 18 là bao nhiêu lần n?

> [!goi-y] Gợi ý 2
> Với cây có đúng 12 NST, xét **chiều dài** và **vị trí tâm động** của hai chiếc trong cặp bất thường.

> [!loi-giai] Lời giải
> n = 6.
>
> **P:** 12 NST = 2n, số lượng bình thường. Cặp số 2 có một chiếc ngắn hơn → **mất đoạn** (đột biến cấu trúc).
>
> **Q:** 18 = 3 × 6 = **3n**, mọi nhóm có 3 chiếc → **thể tam bội** (đa bội lẻ). Có thể do giao tử 2n (giảm phân rối loạn ở tất cả các cặp) kết hợp với giao tử n.
>
> **R:** 11 = 2n − 1, cặp số 5 thiếu một chiếc → **thể một** (lệch bội), do cặp số 5 không phân li trong giảm phân ở bố hoặc mẹ, tạo giao tử n − 1.
>
> **S:** 12 NST, chiều dài không đổi nhưng vị trí tâm động thay đổi → **đảo đoạn chứa tâm động**.

### 4.1. Đọc ảnh bộ NST người

SGK (tr. 76, Hình 14.1) đưa ảnh chụp một bộ NST người và hỏi: đây có phải bộ NST đột biến không, nếu có thì khả năng cao nhất là loại đột biến gì? Cách làm:

1. **Đếm** cẩn thận (đếm theo từng vùng ảnh). Người bình thường có **46** NST.
2. Nếu đếm được **47**: bộ NST thừa một chiếc → **thể ba** (lệch bội). Khả năng cao nhất là **thể ba NST 21 (hội chứng Down)**, vì trong các thể ba NST thường ở người, gần như chỉ thể ba NST 21 phát triển được thành người sống tới tuổi trưởng thành (SGK tr. 64), và nó cũng là thể ba gặp nhiều nhất. Muốn khẳng định cần xếp cặp: tìm nhóm NST nhỏ có **3 chiếc** giống nhau.
3. Nếu đếm được 47 nhưng chiếc thừa là NST giới tính (XXY, XXX) → Klinefelter hoặc hội chứng ba X. Nếu đếm được **45** và chỉ có một X → Turner (Bài 13).

> [!bay] Ảnh nhỏ, NST chồng nhau → đếm dễ lệch
> Trong ảnh in, nhiều NST nằm sát hoặc chéo lên nhau. Hai NST chồng nhau dễ bị đếm thành một, một NST cong dễ bị đếm thành hai. Vì vậy, kết luận từ ảnh chỉ là "khả năng cao nhất". Ở phòng xét nghiệm, người ta đếm **nhiều tế bào** và lập bộ NST đồ để khẳng định.

> [!vi-du] Ví dụ 3
> Ảnh chụp bộ NST từ tế bào bạch cầu của một bé trai cho thấy 47 NST. Khi cắt ảnh và xếp cặp, nhóm NST nhỏ nhất (cặp 21, 22) có tổng cộng 5 chiếc, trong đó 3 chiếc giống hệt nhau. Cặp NST giới tính gồm một chiếc X và một chiếc Y. a) Kết luận về bộ NST của bé. b) Có thể dùng chính tiêu bản này để biết bé có mắc thêm bệnh bạch tạng hay không?

> [!goi-y] Gợi ý 1
> Bình thường cặp 21 và cặp 22 có tổng cộng 4 chiếc. Thừa 1 chiếc thuộc cặp nào? XY có bình thường ở bé trai không?

> [!goi-y] Gợi ý 2
> Bệnh bạch tạng do đột biến gene hay đột biến NST? Kính hiển vi quang học có thấy được thay đổi một cặp nucleotide không?

> [!loi-giai] Lời giải
> a) 47 NST, thừa một chiếc thuộc nhóm nhỏ nhất, ba chiếc giống hệt nhau → thể ba ở cặp 21 hoặc 22. Với bé sống bình thường, khả năng cao nhất là **thể ba NST 21 – hội chứng Down**. Cặp XY bình thường của nam → không có lệch bội NST giới tính. Kí hiệu: 47,XY,+21.
>
> b) **Không.** Bạch tạng là bệnh do **đột biến gene** lặn, NST vẫn bình thường về số lượng và hình dạng. Muốn biết phải dùng xét nghiệm sinh hoá hoặc phân tích DNA.

## 5. Lỗi thường gặp khi quan sát và cách xử lí

| Lỗi | Hậu quả | Cách tránh |
|---|---|---|
| Kết luận từ **một** tế bào thấy thiếu NST | dễ kết luận sai "thể một": khi làm tiêu bản, tế bào có thể bị vỡ, một vài NST bị **trôi lệch** ra ngoài hoặc bị che | đếm nhiều tế bào, kết luận theo số đếm **lặp lại nhiều lần** |
| Đếm ở tế bào có NST chồng chéo | đếm thừa hoặc thiếu | chọn tế bào NST phân tán đều (bước 2) |
| Chỉ nhìn chiều dài, bỏ qua vị trí tâm động | bỏ sót đảo đoạn chứa tâm động | xét cả chiều dài **và** tỉ lệ hai vai |

Hai lỗi đọc kết quả khác (nhầm cặp X–Y là đột biến, thấy chiếc dài hơn là kết luận ngay lặp đoạn) đã nêu trong các khung *Bẫy* ở mục 2.

> [!em-co-biet] Thể khảm
> Đôi khi các tế bào trong **cùng một người** khác nhau: ví dụ phần lớn tế bào có 46 NST, một phần có 47 NST. Đó là **thể khảm**, xảy ra khi NST không phân li trong một lần **nguyên phân** ở giai đoạn phôi sớm. Đây cũng là lí do phòng xét nghiệm phải đếm nhiều tế bào: một tế bào lạ chưa đủ để kết luận, nhưng một tỉ lệ đáng kể tế bào lạ lặp lại thì có ý nghĩa.

## 6. Thu hoạch — trả lời câu hỏi báo cáo

Báo cáo thực hành gồm ba phần: **mục đích**, **kết quả** (Bảng 14.1), **trả lời câu hỏi** (SGK tr. 76). Hai câu hỏi trong sách:

### 6.1. Tại sao phần lớn đột biến NST là có hại?

Ý chính để em tự viết câu trả lời:

- Mỗi NST mang **rất nhiều gene**. Đột biến NST không chỉ chạm vào một gene như đột biến gene, mà làm thay đổi **cả một đoạn, cả một NST hoặc cả bộ NST** → ảnh hưởng **cùng lúc nhiều gene**.
- Cơ thể hoạt động bình thường nhờ **sự cân bằng** về số lượng bản sao giữa các gene (sản phẩm của các gene phải có tỉ lệ phù hợp với nhau). Mất đoạn, lặp đoạn, lệch bội làm một nhóm gene có số bản sao khác hẳn các gene còn lại → **mất cân bằng gene** → rối loạn tổng hợp protein, rối loạn phát triển → giảm sức sống, dị tật, bất thụ, thậm chí chết.
- Mất đoạn còn làm **mất hẳn** một số gene. Đảo đoạn, chuyển đoạn có điểm đứt rơi vào giữa gene thì làm **hỏng gene** đó, và thể dị hợp thường **giảm khả năng sinh sản** do giảm phân tạo nhiều giao tử mất cân bằng (Bài 12).

### 6.2. Cây to khác thường — đột biến gì và kiểm chứng thế nào?

> [!vi-du] Ví dụ 4
> Trong một ruộng cây trồng lưỡng bội, người ta phát hiện một cây có thân, lá và các cơ quan sinh dưỡng to hơn hẳn các cây khác. Biết chắc cây này mang đột biến NST. a) Đó có thể là loại đột biến gì? b) Đề xuất cách kiểm chứng. c) Nếu loài có 2n = 10 thì kết quả nào xác nhận giả thuyết?

> [!goi-y] Gợi ý 1
> Loại đột biến NST nào làm tăng hàm lượng DNA trong **mọi** tế bào, khiến tế bào to ra, cơ quan sinh dưỡng to ra? (Bài 12, mục 3.2.)

> [!goi-y] Gợi ý 2
> Kiểm chứng "đa bội" = đếm số NST. Muốn đếm NST cần tế bào đang **phân chia** — lấy ở bộ phận nào của cây? Cần so sánh với cái gì?

> [!loi-giai] Lời giải
> a) Khả năng cao nhất là **thể đa bội** (tự đa bội, ví dụ 3n, 4n). Số bộ NST tăng → hàm lượng DNA tăng → tế bào to, cơ quan sinh dưỡng to, sinh trưởng mạnh.
>
> b) Lấy **đầu rễ** (hoặc đỉnh sinh trưởng) của cây nghi đột biến và của một cây bình thường cùng loài, làm tiêu bản tế bào đang nguyên phân. Quan sát tế bào ở **kì giữa**, đếm số NST và xếp thành nhóm tương đồng, so sánh hai cây.
>
> c) Cây bình thường có 10 NST, 5 cặp. Nếu cây to có **15** NST (5 nhóm × 3 chiếc) → tam bội. Nếu có **20** NST (5 nhóm × 4 chiếc) → tứ bội. Có thể bổ sung quan sát: thể tam bội thường hầu như không tạo hạt, thể tứ bội vẫn tạo hạt.

> [!bay] Cây to ≠ chắc chắn đa bội
> Cây to hơn cũng có thể do **môi trường** (đất tốt, đủ nước, đủ ánh sáng — thường biến, Bài 16) hoặc do đột biến gene. Vì vậy câu hỏi SGK nói rõ "biết chắc cây bị đột biến NST". Phương pháp **khẳng định** là đếm số NST trên tiêu bản. Đo kích thước tế bào khí khổng, hạt phấn chỉ là dấu hiệu **gợi ý**, chưa đủ để kết luận.

## Dạng bài thi hay gặp

### Dạng 1. Đọc kết quả quan sát → kết luận dạng đột biến

*Nhận biết:* đề cho 2n của loài và mô tả (hoặc hình, bảng) số lượng, hình dạng NST quan sát được trên tiêu bản; hỏi dạng đột biến, cơ chế, hoặc số NST ở một kì phân bào.

*Phương pháp:*
1. So tổng số với 2n: lệch một vài chiếc → lệch bội; bội số của n lớn hơn 2 → đa bội.
2. Tổng số = 2n: so chiều dài và vị trí tâm động trong từng cặp (mục 2.2, Hình 1).
3. Nếu hỏi số NST/chromatid ở các kì: tính số NST trong tế bào sinh dưỡng của thể đột biến, rồi áp dụng quy luật nguyên phân (Bài 12, Dạng 2).

> [!vi-du] Ví dụ 5
> Ở một loài thực vật lưỡng bội có 2n = 26, tiêu bản tế bào đầu rễ của một cây đột biến cho thấy ở kì giữa nguyên phân có 27 NST kép, trong đó cặp số 9 có 3 chiếc, các cặp khác có 2 chiếc. a) Cây thuộc thể đột biến nào? b) Ở kì sau của lần nguyên phân này, tế bào có bao nhiêu NST đơn? c) Cây này có thể được tạo ra từ giao tử nào của bố mẹ?

> [!goi-y] Gợi ý 1
> 27 = 26 + 1, chỉ cặp số 9 thừa. Ở kì sau nguyên phân, mỗi NST kép tách thành 2 NST đơn.

> [!goi-y] Gợi ý 2
> Hợp tử 2n + 1 = giao tử (n + 1) + giao tử n. Giao tử n + 1 sinh ra do đâu?

> [!loi-giai] Lời giải
> a) 27 = 2n + 1, cặp số 9 có 3 chiếc → **thể ba** (lệch bội).
>
> b) Kì sau: 27 × 2 = **54** NST đơn.
>
> c) Giao tử **n + 1** = 14 NST (thừa một chiếc NST số 9), tạo ra khi cặp NST số 9 không phân li trong giảm phân ở bố hoặc mẹ, kết hợp với giao tử bình thường **n** = 13 NST.

*Bẫy:* thấy "27 NST" là nghĩ ngay "thể ba" mà không xem số chiếc từng cặp. Nếu 27 NST mà có hai cặp có 3 chiếc và một cặp chỉ có 1 chiếc thì đó là thể đột biến khác (2n + 1 + 1 − 1), không phải thể ba đơn.

### Dạng 2. Thao tác, nguyên lí của thí nghiệm (thường ở câu Đúng–Sai)

*Nhận biết:* "Khi thực hành quan sát đột biến NST trên tiêu bản cố định, xét các phát biểu…".

*Phương pháp:* thuộc **trình tự 10× → 40× → dầu soi → 100× (ốc vi cấp) → lau dầu**, hiểu **vì sao** từng bước (mục 3.1). Nhớ các ý "chốt":
- tiêu bản cố định, tế bào ở **kì giữa**;
- so với bộ NST **bình thường cùng loài**;
- chỉ thấy đột biến **NST**, **không** thấy đột biến gene;
- cặp NST giới tính khác nhau ở giới dị giao là **bình thường**.

*Ví dụ:* xem lại **Ví dụ 1** (mục 3.1) về các lỗi thao tác và **Ví dụ 3b** (mục 4.1) về giới hạn của phương pháp. Bài luyện tập cuối bài có câu Đúng–Sai đúng dạng này.

*Bẫy:* đề cài "nhỏ dầu soi khi dùng vật kính 10×" hoặc "quan sát tiêu bản phát hiện được bệnh máu khó đông, bạch tạng" — đều **sai**.

### Dạng 3. Tình huống thực tế: thiết kế cách kiểm chứng, xử lí số liệu nhiều tế bào

*Nhận biết:* "làm thế nào để xác định…", "kết quả đếm ở nhiều tế bào…", "tỉ lệ…%".

*Phương pháp:*
1. Xác định cần **đếm gì** (số NST, hình dạng cặp nào) và **so với gì** (đối chứng bình thường cùng loài).
2. Chọn **mẫu đang phân chia** (đầu rễ, đỉnh sinh trưởng ở thực vật; bạch cầu nuôi cấy ở người).
3. Với số liệu nhiều tế bào: kết luận theo **giá trị lặp lại nhiều nhất**, coi vài tế bào lệch lẻ tẻ là có thể do làm tiêu bản.

> [!vi-du] Ví dụ 6
> Một nhóm học sinh đếm NST ở 20 tế bào kì giữa của tiêu bản đầu rễ một cây thuộc loài có 2n = 16. Kết quả: 17 tế bào có 32 NST, 2 tế bào có 31 NST, 1 tế bào có 30 NST. a) Cây này nhiều khả năng thuộc dạng nào? b) Giải thích vì sao có vài tế bào ít NST hơn. c) Tính tỉ lệ phần trăm số tế bào có số NST đúng với kết luận.

> [!goi-y] Gợi ý 1
> Giá trị lặp lại nhiều nhất là bao nhiêu? So với 2n = 16 thì gấp mấy lần n?

> [!goi-y] Gợi ý 2
> Nếu cây thật sự là thể đột biến có 31 NST thì có phải hầu hết tế bào đều 31 không?

> [!loi-giai] Lời giải
> a) 17/20 tế bào có 32 NST. n = 8 nên 32 = 4n → nhiều khả năng là **thể tứ bội**.
>
> b) Các tế bào 31, 30 NST chỉ chiếm số ít, lẻ tẻ. Nhiều khả năng một vài NST bị trôi ra ngoài, bị che hoặc bị đếm sót khi làm tiêu bản, quan sát. Không thể kết luận cây mang thêm đột biến lệch bội.
>
> c) Tỉ lệ = 17 : 20 × 100% = **85%**.

*Bẫy:* lấy trung bình số NST (≈ 31,8) rồi làm tròn, hoặc kết luận cây là thể khảm từ 3 tế bào lẻ.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Mục đích | quan sát đột biến NST trên tiêu bản cố định (hoặc ảnh chụp) |
| Nguyên lí | NST bộ 2n tồn tại thành cặp giống nhau (trừ cặp giới tính); so số lượng, hình dạng, kích thước với bộ bình thường cùng loài |
| Mẫu | tế bào ở kì giữa (NST co xoắn cực đại), đã nhuộm; đối chứng là tiêu bản bình thường |
| Trình tự kính | 10× (tìm, NST phân tán đều) → 40× (đưa vào giữa) → nhỏ dầu soi → 100× + ốc vi cấp → lau dầu |
| Đọc kết quả | khác 2n một vài chiếc: lệch bội · bội số của n: đa bội · đủ 2n mà một chiếc ngắn/dài/tâm động lệch: mất đoạn/lặp đoạn/đảo đoạn chứa tâm động · hai cặp không tương đồng cùng đổi chiều dài: chuyển đoạn |
| Không thấy được | đột biến gene; đảo đoạn không chứa tâm động; đột biến cấu trúc rất nhỏ |
| Lỗi hay gặp | kết luận từ một tế bào; đếm tế bào NST chồng chéo; nhầm X–Y là đột biến; quên lau dầu |
| Thu hoạch | đột biến NST có hại vì ảnh hưởng nhiều gene, mất cân bằng gene · cây to bất thường → nghi đa bội, kiểm chứng bằng đếm NST tế bào đầu rễ |
