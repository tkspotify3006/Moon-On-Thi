---
title: Saccharose và maltose
thoi-gian: 35 phút
muc-tieu:
  - Viết được công thức cấu tạo dạng mạch vòng (và dạng mở vòng của maltose); gọi đúng tên liên kết α-1,2-glycoside, α-1,4-glycoside.
  - Giải thích được vì sao saccharose chỉ có dạng mạch vòng, còn maltose mở vòng được.
  - Trình bày được tính chất hóa học của saccharose (với Cu(OH)~2~, thủy phân); suy ra tính chất của maltose từ cấu tạo.
  - Mô tả hiện tượng thí nghiệm saccharose với Cu(OH)~2~ và giải thích.
  - Nêu được trạng thái tự nhiên, ứng dụng của saccharose, maltose; giải được bài toán thủy phân – tráng bạc có hiệu suất.
---
> [!ghi-nho] Bài này trong 5 dòng
> 1. Saccharose và maltose đều là **disaccharide**, cùng công thức phân tử **C~12~H~22~O~11~** (là đồng phân của nhau).
> 2. **Saccharose** = α-glucose + β-fructose, nối bằng liên kết **α-1,2-glycoside** → không còn –OH hemiacetal → **chỉ có dạng mạch vòng**.
> 3. **Maltose** = glucose + glucose, nối bằng liên kết **α-1,4-glycoside** → gốc thứ hai còn –OH hemiacetal → **mở vòng được, có nhóm –CHO**.
> 4. Cả hai hòa tan Cu(OH)~2~ → dung dịch **xanh lam**; cả hai bị **thủy phân**. Chỉ **maltose** tráng bạc trực tiếp; saccharose thì **không**.
> 5. Saccharose (đường mía, củ cải đường, thốt nốt) → chất tạo ngọt. Maltose (mạch nha, từ thủy phân tinh bột) → sản xuất bia, bánh kẹo.

## 1. Cấu tạo phân tử

> [!nen-tang] Nhớ lại Bài 4: –OH hemiacetal và liên kết glycoside
> - Glucose khép vòng 6 cạnh. Nguyên tử C1 (C của nhóm –CHO cũ) mang một nhóm –OH "đặc biệt" gọi là **–OH hemiacetal**. Ở fructose, nhóm tương ứng nằm ở C2, gọi là **–OH hemiketal**.
> - Nhờ nhóm –OH này mà vòng **mở ra – đóng lại** được: vòng mở ra thì lại có nhóm –CHO (glucose) hay nhóm C=O (fructose).
> - Nhóm –OH hemiacetal phản ứng được với nhóm –OH của chất khác (ví dụ CH~3~OH có HCl khan) và tách nước. Cầu nối C–O–C tạo thành gọi là **liên kết glycoside**.
> - Khi –OH hemiacetal đã "bận" làm liên kết glycoside thì vòng ở gốc đó **bị khóa**, không mở được nữa.

Disaccharide là hai monosaccharide nối với nhau bằng **một liên kết glycoside**, đồng thời tách ra **một phân tử nước**:

=> C~6~H~12~O~6~ + C~6~H~12~O~6~ → C~12~H~22~O~11~ + H~2~O

Vì vậy saccharose và maltose có cùng công thức phân tử C~12~H~22~O~11~. Chúng khác nhau ở **hai gốc nào** và **nối ở vị trí nào**. Chính điểm khác này quyết định tính chất.

### 1.1. Saccharose

Saccharose gồm **một gốc α-glucose** và **một gốc β-fructose**. Liên kết glycoside nối **C1 của glucose** với **C2 của fructose** qua một nguyên tử O. SGK gọi là **liên kết α-1,2-glycoside** (SGK tr. 25).

![Hình 1. Cấu tạo phân tử saccharose (gốc fructose được vẽ lật lại để C2 nằm bên trái, gần gốc glucose)](saccharose.svg)

Cách đọc tên liên kết **α-1,2**:
- **α**: nhóm –OH ở C1 của glucose ở dạng α (nằm phía dưới vòng) khi tạo liên kết;
- **1,2**: nối C**1** của gốc thứ nhất (glucose) với C**2** của gốc thứ hai (fructose).

Bây giờ em để ý: C1 của glucose mang –OH hemiacetal, C2 của fructose mang –OH hemiketal. Trong saccharose, **cả hai nhóm "đặc biệt" này đều đã bị dùng** để tạo liên kết. Phân tử không còn nhóm –OH hemiacetal (hay hemiketal) nào. Vì thế **không gốc nào mở vòng được**. Saccharose **chỉ tồn tại ở dạng mạch vòng**, không có nhóm –CHO.

Đếm nhóm –OH: gốc glucose còn 4 nhóm (C2, C3, C4, C6), gốc fructose còn 4 nhóm (C1, C3, C4, C6). Tổng cộng saccharose có **8 nhóm –OH**, nhiều nhóm nằm kề nhau.

### 1.2. Maltose

Maltose gồm **hai gốc glucose**. Liên kết glycoside nối **C1 của gốc thứ nhất** (dạng α) với **C4 của gốc thứ hai**, gọi là **liên kết α-1,4-glycoside** (SGK tr. 25).

![Hình 2. Maltose: dạng mạch vòng và dạng mở vòng](maltose.svg)

Khác saccharose ở chỗ: gốc glucose thứ hai dùng nhóm –OH **ở C4** (một nhóm –OH bình thường) để nối. Nhóm **–OH hemiacetal ở C1 của gốc thứ hai vẫn còn tự do**. Nhờ vậy vòng của gốc này mở ra được và xuất hiện nhóm **–CHO**. Maltose tồn tại **đồng thời ở dạng mạch vòng và dạng mở vòng**, chuyển hóa qua lại.

Nhóm –OH hemiacetal tự do có thể ở dạng α hoặc β, nên SGK vẽ nó bằng nét lượn sóng. Maltose cũng có **8 nhóm –OH** (mỗi gốc 4 nhóm).

### 1.3. So sánh nhanh cấu tạo

| | **Saccharose** | **Maltose** |
|---|---|---|
| Công thức phân tử | C~12~H~22~O~11~ | C~12~H~22~O~11~ |
| Các gốc | α-glucose + β-fructose | glucose + glucose |
| Liên kết | α-1,2-glycoside | α-1,4-glycoside |
| Còn –OH hemiacetal tự do? | **Không** | **Có** (ở gốc glucose thứ hai) |
| Mở vòng được? | Không, chỉ có dạng mạch vòng | Có, tạo nhóm –CHO |
| Số nhóm –OH | 8 | 8 |

> [!bay] Ba chỗ hay nhầm
> - Saccharose là **α-1,2**, không phải α-1,4. Maltose mới là **α-1,4**.
> - Saccharose gồm glucose **và fructose**; maltose gồm **hai glucose**.
> - "Không có –CHO" không có nghĩa là "không có –OH". Saccharose vẫn có tới 8 nhóm –OH.

> [!vi-du] Ví dụ 1
> Cho các chất: glucose, fructose, saccharose, maltose. Chất nào trong phân tử dạng mạch vòng **không còn** nhóm –OH hemiacetal (hoặc hemiketal)? Chất đó có mở vòng được không?

> [!goi-y] Gợi ý 1
> Monosaccharide dạng vòng luôn còn nhóm –OH hemiacetal (glucose ở C1) hay hemiketal (fructose ở C2). Chỉ cần xét hai disaccharide.

> [!goi-y] Gợi ý 2
> Xem liên kết glycoside nối những carbon nào. Nếu cả hai carbon "đặc biệt" (C1 của glucose, C2 của fructose) đều tham gia liên kết thì sao?

> [!loi-giai] Lời giải
> - Glucose, fructose: còn –OH hemiacetal/hemiketal.
> - Maltose: liên kết α-1,4 dùng C1 của gốc thứ nhất và C4 (–OH thường) của gốc thứ hai, nên C1 của gốc thứ hai vẫn còn –OH hemiacetal.
> - Saccharose: liên kết α-1,2 dùng đúng C1 của glucose và C2 của fructose.
>
> **Kết luận:** chỉ **saccharose** không còn –OH hemiacetal/hemiketal nên **không mở vòng được**.

## 2. Tính chất hóa học của saccharose

Từ cấu tạo, ta **dự đoán** trước:
- Có nhiều nhóm –OH kề nhau → có **tính chất của polyalcohol** (giống glycerol, glucose).
- Có liên kết glycoside → **bị thủy phân**, cắt đôi thành hai monosaccharide.
- **Không** có nhóm –CHO, cũng không mở vòng để tạo –CHO → **không** có tính chất của aldehyde (không tráng bạc, không làm mất màu nước bromine).

### 2.1. Tính chất của polyalcohol: phản ứng với Cu(OH)~2~

**Thí nghiệm** (SGK tr. 26): cho dung dịch NaOH vào ống nghiệm, thêm vài giọt dung dịch CuSO~4~, lắc nhẹ. Sau đó thêm dung dịch saccharose và lắc đều.

**Hiện tượng:**
- Khi trộn NaOH với CuSO~4~: xuất hiện **kết tủa xanh** Cu(OH)~2~.
- Khi thêm saccharose: kết tủa **tan dần**, tạo **dung dịch màu xanh lam**.

**Giải thích:** các nhóm –OH kề nhau của saccharose "ôm" lấy ion Cu^2+^, tạo hợp chất tan có màu xanh lam. Đây là phản ứng chung của các chất có **từ 2 nhóm –OH kề nhau trở lên**.

=> 2C~12~H~22~O~11~ + Cu(OH)~2~ → (C~12~H~21~O~11~)~2~Cu + 2H~2~O

Tỉ lệ cần nhớ: **2 mol saccharose hòa tan 1 mol Cu(OH)~2~**.

> [!bay] Phản ứng xảy ra ở nhiệt độ thường
> Đây là tính chất polyalcohol, làm ở **nhiệt độ thường**. Nếu **đun nóng** hỗn hợp Cu(OH)~2~/NaOH với saccharose thì **không** có kết tủa đỏ gạch Cu~2~O (saccharose không có –CHO). Glucose, maltose thì có.

> [!vi-du] Ví dụ 2
> Cho 10,26 g saccharose vào ống nghiệm chứa Cu(OH)~2~ dư trong môi trường kiềm. Tính khối lượng Cu(OH)~2~ tối đa bị hòa tan.

> [!goi-y] Gợi ý 1
> Đổi ra mol: M~saccharose~ = 342 g/mol.

> [!goi-y] Gợi ý 2
> Theo phương trình, số mol Cu(OH)~2~ bằng **một nửa** số mol saccharose.

> [!loi-giai] Lời giải
>
> Bước 1: n~saccharose~ = 10,26 : 342 = 0,03 mol.
>
> Bước 2: n~Cu(OH)2~ = 0,03 : 2 = 0,015 mol.
>
> Bước 3: m = 0,015 × 98 = **1,47 g**.

### 2.2. Phản ứng thủy phân

Đun saccharose với dung dịch acid loãng (H^+^ làm xúc tác), hoặc cho enzyme tác dụng, liên kết glycoside bị cắt. Một phân tử nước "chen vào" chỗ cắt:

=> C~12~H~22~O~11~ + H~2~O → C~6~H~12~O~6~ + C~6~H~12~O~6~

Đọc là: saccharose + nước → glucose + fructose (điều kiện: H^+^, t° hoặc enzyme).

Đây chính là câu hỏi hay của SGK (tr. 26): *vì sao dung dịch saccharose không tráng bạc, nhưng đun với acid loãng xong thì lại tráng bạc được?*
- **Trước** khi đun: saccharose không có –CHO, không mở vòng được → không phản ứng với thuốc thử Tollens.
- **Sau** khi đun: dung dịch chứa **glucose và fructose**. Cả hai đều bị thuốc thử Tollens oxi hóa (fructose chuyển thành glucose trong môi trường kiềm của thuốc thử) → có bạc bám vào thành ống.

Mỗi monosaccharide cho 2 Ag, nên ta có sơ đồ tính nhanh:

=> 1 saccharose → 1 glucose + 1 fructose → **4 Ag**

> [!bay] Phải trung hòa acid trước khi tráng bạc
> Thuốc thử Tollens chứa NH~3~ và phức bạc, bị acid phá hủy. Vì vậy sau khi thủy phân bằng acid phải **trung hòa** (ví dụ bằng NaHCO~3~) rồi mới cho thuốc thử Tollens. Đề thi thí nghiệm hay hỏi bước này.

> [!vi-du] Ví dụ 3
> Đun nóng dung dịch chứa 25,65 g saccharose với dung dịch H~2~SO~4~ loãng. Hiệu suất thủy phân là 75%. Trung hòa dung dịch rồi cho tác dụng với lượng dư dung dịch AgNO~3~ trong NH~3~ (thuốc thử Tollens), đun nhẹ. Tính khối lượng Ag thu được.

> [!goi-y] Gợi ý 1
> Chỉ phần saccharose **đã bị thủy phân** mới tạo ra chất tráng bạc. Phần saccharose còn lại không tráng bạc.

> [!goi-y] Gợi ý 2
> Mỗi mol saccharose bị thủy phân → 1 mol glucose + 1 mol fructose → 4 mol Ag.

> [!loi-giai] Lời giải
>
> Bước 1: n~saccharose~ = 25,65 : 342 = 0,075 mol.
>
> Bước 2: n(saccharose bị thủy phân) = 0,075 × 75% = 0,05625 mol.
>
> Bước 3: n~Ag~ = 4 × 0,05625 = 0,225 mol.
>
> Bước 4: m~Ag~ = 0,225 × 108 = **24,3 g**.

> [!em-co-biet] Thắng đường làm nước màu
> Khi đun nóng saccharose khan đến khoảng 185 °C, đường nóng chảy rồi bị phân hủy một phần, tạo hỗn hợp màu nâu, thơm, gọi là **caramel**. Món "thắng nước màu" để kho cá, kho thịt chính là quá trình này. Đun quá lửa thì đường cháy thành than, có vị đắng.

### 2.3. Còn maltose thì sao?

SGK chỉ trình bày cấu tạo maltose, nhưng đề thi thường hỏi tính chất của nó. Em **suy ra từ cấu tạo** là được, rất logic:
- Có nhiều –OH kề nhau → **hòa tan Cu(OH)~2~** ở nhiệt độ thường, tạo dung dịch xanh lam (giống saccharose).
- Có liên kết glycoside → **bị thủy phân** (acid hoặc enzyme), nhưng chỉ cho **một loại** sản phẩm:

=> C~12~H~22~O~11~ + H~2~O → 2C~6~H~12~O~6~

Đọc là: maltose + nước → 2 glucose.

- Mở vòng được, có nhóm –CHO → có **tính chất của aldehyde** như glucose: **tráng bạc** với thuốc thử Tollens, khử Cu(OH)~2~ trong kiềm khi đun nóng (kết tủa đỏ gạch Cu~2~O), làm **mất màu nước bromine**.

Mỗi phân tử maltose chỉ có **một** nhóm –CHO (ở gốc thứ hai). Vì vậy, khi tráng bạc trực tiếp:

=> 1 maltose → **2 Ag**

Còn nếu thủy phân hoàn toàn rồi mới tráng bạc:

=> 1 maltose → 2 glucose → **4 Ag**

> [!ghi-nho] Bảng "ai làm được gì"
> | Chất | Cu(OH)~2~ (thường) | Tollens | Nước Br~2~ | Thủy phân |
> |---|---|---|---|---|
> | Glucose | xanh lam | 2 Ag | mất màu | không |
> | Fructose | xanh lam | 2 Ag | **không** | không |
> | **Saccharose** | xanh lam | **không** | **không** | glucose + fructose |
> | **Maltose** | xanh lam | **2 Ag** | **mất màu** | 2 glucose |
>
> ("2 Ag" nghĩa là 1 mol chất cho 2 mol Ag.)

> [!bay] Fructose tráng bạc nhưng không làm mất màu nước bromine
> Môi trường của thuốc thử Tollens có tính kiềm (NH~3~), fructose chuyển thành glucose nên tráng bạc được. Nước bromine không có môi trường kiềm, nên fructose **không** làm mất màu. Đây là cách phân biệt glucose với fructose.

## 3. Trạng thái tự nhiên và ứng dụng

### 3.1. Saccharose

- **Tính chất vật lí:** chất rắn kết tinh, không màu, vị ngọt, **dễ tan trong nước**.
- **Trong tự nhiên:** thực vật tổng hợp saccharose từ glucose và fructose. Có nhiều nhất trong **cây mía**, **củ cải đường** và **hoa thốt nốt**. Vì thế nó còn được gọi là **đường mía**.
- **Ứng dụng:** chất tạo ngọt phổ biến nhất trong thực phẩm: bánh, kẹo, nước giải khát, đồ uống có gas, sữa…

Các dạng đường quen thuộc như đường cát, đường kính trắng, đường phèn, đường thốt nốt đều chủ yếu là saccharose. Chúng chỉ khác nhau ở độ tinh khiết và cách kết tinh.

**Sản xuất đường từ mía** (phần mở rộng, SGK hiện hành không trình bày; đọc để hiểu thực tế). Nước mía ép chứa khoảng 12–15% đường. Muốn thu được đường kính trắng, nhà máy phải loại tạp chất, tẩy màu rồi cho kết tinh:

![Hình 3. Sơ đồ sản xuất đường từ cây mía](san-xuat-duong.svg)

Vì sao lại làm từng bước như vậy?
- **Sữa vôi** Ca(OH)~2~ làm kết tủa các acid hữu cơ, protein… có trong nước mía.
- Vôi còn dư sẽ làm đường bị lẫn tạp chất, nên **sục CO~2~** để chuyển vôi thành CaCO~3~ kết tủa, rồi lọc bỏ.
- **SO~2~** (hoặc than hoạt tính) tẩy màu vàng nâu, cho dung dịch trong.
- **Cô đặc ở áp suất thấp** để nước bay hơi ở nhiệt độ thấp hơn, tránh đường bị cháy thành caramel.
- Phần còn lại sau kết tinh là **rỉ đường (mật rỉ)**, vẫn chứa đường, dùng lên men sản xuất ethanol. **Bã mía** dùng làm nhiên liệu đốt lò, làm giấy.

> [!vi-du] Ví dụ 4
> Một nhà máy ép 5 tấn mía. Mía chứa 12% saccharose về khối lượng. Hiệu suất thu hồi đường của cả quá trình là 80%. Tính khối lượng đường kính (coi là saccharose nguyên chất) thu được.

> [!goi-y] Gợi ý 1
> Tính lượng saccharose có sẵn trong mía trước, rồi mới nhân hiệu suất.

> [!loi-giai] Lời giải
>
> Bước 1: m(saccharose trong mía) = 5 000 × 12% = 600 kg.
>
> Bước 2: m(đường thu được) = 600 × 80% = **480 kg**.

> [!ung-dung] Chọn nguồn đường hợp lí cho sức khỏe
> Saccharose vào ruột được enzyme thủy phân thành glucose và fructose rồi mới hấp thu, nên làm đường huyết tăng khá nhanh. Tổ chức Y tế Thế giới (WHO) khuyên **đường tự do** (đường thêm vào thức ăn, nước uống) nên dưới 10% tổng năng lượng mỗi ngày, tức khoảng **50 g** với khẩu phần 2 000 kcal. Một lon nước ngọt có thể chứa 30–40 g đường. Ăn trái cây nguyên quả (có chất xơ) tốt hơn uống nước ngọt.

### 3.2. Maltose

- **Tính chất vật lí:** chất rắn, vị ngọt (kém ngọt hơn saccharose), dễ tan trong nước.
- **Trong tự nhiên:** có trong một số **hạt nảy mầm** (thóc, lúa mạch nảy mầm). Maltose chủ yếu được tạo ra khi **thủy phân tinh bột** nhờ enzyme (amylase).
- **Ứng dụng:** nguyên liệu **sản xuất bia**; chất tạo ngọt cho một số loại bánh kẹo. **Mạch nha** (kẹo mạch nha) chứa nhiều maltose, nên maltose còn gọi là **đường mạch nha**.

> [!ung-dung] Từ hạt lúa mạch đến bia
> Hạt lúa mạch được ủ cho nảy mầm, gọi là **malt**. Khi nảy mầm, hạt tạo ra enzyme amylase cắt tinh bột thành maltose. Sau đó maltose bị thủy phân thành glucose, nấm men lên men glucose thành ethanol và CO~2~. Tên "maltose" bắt nguồn chính từ chữ *malt*.

> [!em-co-biet] Ai ngọt hơn ai?
> Nếu lấy saccharose làm mốc thì fructose ngọt nhất, sau đó đến saccharose, rồi glucose, maltose kém ngọt hơn cả. Vì vậy mật ong và các loại quả chín giàu fructose có vị rất ngọt.

## Dạng bài thi hay gặp

### Dạng 1. Nhận biết, phân biệt các carbohydrate

**Nhận biết:** đề cho vài dung dịch (glucose, fructose, saccharose, maltose, có khi thêm glycerol, ethanol) và hỏi thuốc thử hoặc hiện tượng.

**Phương pháp:**
1. Dùng **Cu(OH)~2~ ở nhiệt độ thường** để tách nhóm có nhiều –OH kề nhau (xanh lam) khỏi nhóm không có (ethanol…).
2. Dùng **thuốc thử Tollens** để tách nhóm tráng bạc (glucose, fructose, maltose) khỏi saccharose.
3. Dùng **nước bromine** để tách chất có –CHO thật sự (glucose, maltose) khỏi fructose.
4. Glucose và maltose cho hiện tượng **giống nhau** với cả ba thuốc thử trên. Đề chỉ phân biệt hai chất này qua **tính toán định lượng** (1 mol maltose cho 2 mol Ag khi tráng bạc trực tiếp, nhưng cho 4 mol Ag nếu thủy phân hoàn toàn trước).

> [!vi-du] Ví dụ 5
> Có ba dung dịch riêng biệt: saccharose, maltose, fructose. Hãy chọn thứ tự thuốc thử để nhận biết từng dung dịch.

> [!goi-y] Gợi ý 1
> Cả ba đều hòa tan Cu(OH)~2~ ở nhiệt độ thường, nên Cu(OH)~2~ không giúp gì. Chất nào không tráng bạc?

> [!goi-y] Gợi ý 2
> Còn lại maltose và fructose đều tráng bạc. Thuốc thử nào phân biệt được chất có –CHO thật với fructose?

> [!loi-giai] Lời giải
>
> Bước 1: Cho thuốc thử Tollens vào cả ba, ngâm nước nóng. Ống **không** có bạc là **saccharose**.
>
> Bước 2: Với hai ống còn lại, cho nước bromine. Ống làm **mất màu** nước bromine là **maltose**. Ống không làm mất màu là **fructose**.

**Bẫy:** đừng dùng Cu(OH)~2~ ở nhiệt độ thường để phân biệt các đường với nhau, vì chất nào cũng cho xanh lam. Đừng quên fructose cũng tráng bạc.

### Dạng 2. Thủy phân rồi tráng bạc (có hiệu suất)

**Nhận biết:** "thủy phân … với hiệu suất H%, trung hòa rồi cho tác dụng với AgNO~3~/NH~3~ dư".

**Phương pháp:**
1. Tính số mol disaccharide ban đầu (M = 342).
2. Tách ra phần **đã thủy phân** (× H) và phần **còn lại** (× (1 − H)).
3. Đếm Ag: mỗi monosaccharide → 2 Ag; maltose còn dư → 2 Ag; **saccharose còn dư → 0 Ag**.
4. Cộng lại, nhân 108.

> [!vi-du] Ví dụ 6
> Thủy phân 34,2 g maltose với hiệu suất 60%. Trung hòa dung dịch rồi cho tác dụng với lượng dư thuốc thử Tollens. Tính khối lượng Ag thu được.

> [!goi-y] Gợi ý 1
> Sau thủy phân, dung dịch có những chất nào? Đừng quên phần maltose **chưa** bị thủy phân.

> [!goi-y] Gợi ý 2
> Glucose → 2 Ag. Maltose dư vẫn còn –CHO → 2 Ag.

> [!loi-giai] Lời giải
>
> Bước 1: n~maltose~ = 34,2 : 342 = 0,1 mol.
>
> Bước 2: maltose bị thủy phân 0,06 mol → 0,12 mol glucose; maltose còn lại 0,04 mol.
>
> Bước 3: n~Ag~ = 2 × 0,12 + 2 × 0,04 = 0,32 mol.
>
> Bước 4: m~Ag~ = 0,32 × 108 = **34,56 g**.

**Bẫy:** với maltose, phần dư vẫn tráng bạc. Nếu bỏ quên phần này em sẽ ra 25,92 g (sai). Ngược lại, với saccharose thì phần dư **không** tráng bạc.

> [!meo] Công thức nhanh
> Gọi n là số mol disaccharide ban đầu, H là hiệu suất thủy phân (dạng số thập phân):
> - Saccharose: n~Ag~ = 4nH.
> - Maltose: n~Ag~ = 4nH + 2n(1 − H) = 2n(1 + H).
>
> Với ví dụ trên: 2 × 0,1 × 1,6 = 0,32 mol. Hiểu cách đếm trước, công thức chỉ để kiểm tra lại.

### Dạng 3. Hỗn hợp saccharose và maltose

**Nhận biết:** hỗn hợp hai disaccharide; một phần tráng bạc trực tiếp, một phần thủy phân rồi tráng bạc.

**Phương pháp:**
1. Hai chất cùng M = 342 → tổng số mol = khối lượng : 342.
2. Tráng bạc **trực tiếp**: chỉ maltose phản ứng → n~maltose~ = n~Ag~ : 2.
3. Thủy phân **hoàn toàn** rồi tráng bạc: mỗi disaccharide (bất kể loại nào) → 4 Ag.

> [!vi-du] Ví dụ 7
> Hỗn hợp X gồm saccharose và maltose có khối lượng 68,4 g. Cho X tác dụng trực tiếp với thuốc thử Tollens dư, thu được 10,8 g Ag. Nếu thủy phân hoàn toàn X rồi trung hòa, cho tác dụng với thuốc thử Tollens dư thì thu được bao nhiêu gam Ag? Tính phần trăm khối lượng saccharose trong X.

> [!goi-y] Gợi ý 1
> Tráng bạc trực tiếp chỉ có maltose → tìm được số mol maltose.

> [!goi-y] Gợi ý 2
> Sau thủy phân hoàn toàn, mỗi disaccharide cho 2 monosaccharide, mỗi monosaccharide cho 2 Ag.

> [!loi-giai] Lời giải
>
> Bước 1: n~X~ = 68,4 : 342 = 0,2 mol.
>
> Bước 2: n~Ag~ (tráng bạc trực tiếp) = 10,8 : 108 = 0,1 mol → n~maltose~ = 0,05 mol → n~saccharose~ = 0,15 mol.
>
> Bước 3: thủy phân hoàn toàn: n~Ag~ = 4 × 0,2 = 0,8 mol → m~Ag~ = **86,4 g**.
>
> Bước 4: %m~saccharose~ = 0,15 × 342 : 68,4 × 100% = **75%**.

**Bẫy:** đề thường cho "thủy phân hoàn toàn" ở phần 2. Khi đó không cần biết tỉ lệ hai chất cũng tính được Ag.

### Dạng 4. Câu Đúng/Sai về cấu tạo – tính chất

**Nhận biết:** 4 ý liên quan đến liên kết, nhóm chức, khả năng mở vòng, hiện tượng thí nghiệm, đôi khi có 1 ý tính toán.

**Phương pháp:** với mỗi ý, tự hỏi 3 câu: *gốc gì? nối C nào với C nào? còn –OH hemiacetal không?* Rồi suy ra tính chất. Ý tính toán thì làm như Dạng 2, 3.

> [!vi-du] Ví dụ 8
> Xét các phát biểu:
>
> a) Saccharose và maltose là đồng phân của nhau.
>
> b) Trong phân tử maltose, hai gốc glucose nối với nhau bằng liên kết α-1,2-glycoside.
>
> c) Dung dịch saccharose làm mất màu nước bromine.
>
> d) Thủy phân hoàn toàn 0,1 mol maltose rồi tráng bạc với lượng dư thuốc thử Tollens thu được 0,4 mol Ag.
>
> Ý nào đúng, ý nào sai?

> [!goi-y] Gợi ý 1
> So công thức phân tử. Nhớ "saccharose 1,2 – maltose 1,4".

> [!goi-y] Gợi ý 2
> Saccharose có nhóm –CHO không? Maltose thủy phân ra mấy glucose?

> [!loi-giai] Lời giải
>
> a) **Đúng**: cùng C~12~H~22~O~11~, khác cấu tạo.
>
> b) **Sai**: maltose là α-**1,4**-glycoside; α-1,2 là của saccharose.
>
> c) **Sai**: saccharose không có –CHO, không mở vòng được.
>
> d) **Đúng**: 0,1 mol maltose → 0,2 mol glucose → 0,4 mol Ag.

## Tóm tắt

| | **Saccharose** | **Maltose** |
|---|---|---|
| Tên thường | đường mía | đường mạch nha |
| Công thức phân tử | C~12~H~22~O~11~ (M = 342) | C~12~H~22~O~11~ (M = 342) |
| Cấu tạo | α-glucose + β-fructose, **α-1,2-glycoside** | glucose + glucose, **α-1,4-glycoside** |
| Dạng tồn tại | chỉ mạch vòng | mạch vòng ⇄ mở vòng (có –CHO) |
| Cu(OH)~2~, nhiệt độ thường | xanh lam (2 : 1) | xanh lam |
| Tráng bạc trực tiếp | **không** | **có**: 1 → 2 Ag |
| Nước bromine | không | mất màu |
| Thủy phân (H^+^ hoặc enzyme) | → glucose + fructose (→ 4 Ag) | → 2 glucose (→ 4 Ag) |
| Nguồn | mía, củ cải đường, thốt nốt | hạt nảy mầm, thủy phân tinh bột |
| Ứng dụng | chất tạo ngọt thực phẩm | sản xuất bia, bánh kẹo |

**Sơ đồ suy luận cần thuộc:** *còn –OH hemiacetal?* → *mở vòng được?* → *có –CHO?* → *tráng bạc, mất màu nước bromine?*
