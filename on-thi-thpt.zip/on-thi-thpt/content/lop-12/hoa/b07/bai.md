---
title: Ôn tập chương 2
thoi-gian: 50 phút
muc-tieu:
  - Hệ thống hoá cấu tạo của glucose, fructose, saccharose, maltose, tinh bột, cellulose; gọi đúng loại liên kết glycoside và nhóm chức đặc trưng của từng chất.
  - Lập và dùng được bảng tính chất hoá học của cả chương (Cu(OH)~2~ ở nhiệt độ thường và khi đun nóng, thuốc thử Tollens, nước bromine, thuỷ phân, iodine, HNO~3~, nước Schweizer) để nhận biết và đếm số chất thoả mãn một tính chất.
  - Nắm được sơ đồ chuyển hoá: quang hợp → glucose → tinh bột, cellulose → (thuỷ phân) glucose → ethanol, lactic acid.
  - Giải thích được các hiện tượng thực tế liên quan đến carbohydrate (nhai cơm thấy ngọt, chuối chín tráng bạc, iodine với chuối xanh).
  - Giải được các bài toán tổng hợp: hỗn hợp nhiều carbohydrate với tráng bạc trước/sau thuỷ phân, chuỗi phản ứng có hiệu suất, cellulose nitrate.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. Ba loại carbohydrate: **monosaccharide** (glucose, fructose – C~6~H~12~O~6~), **disaccharide** (saccharose, maltose – C~12~H~22~O~11~), **polysaccharide** (tinh bột, cellulose – (C~6~H~10~O~5~)~n~).
> 2. Glucose: 5 –OH + 1 –CHO; vòng 6 cạnh, –OH hemiacetal ở C1. Fructose: 5 –OH + 1 C=O ở C2; vòng 5 cạnh.
> 3. Saccharose = α-glucose + β-fructose (**α-1,2**), không còn –OH hemiacetal → **không mở vòng**. Maltose = 2 glucose (**α-1,4**), còn –OH hemiacetal → **có –CHO**.
> 4. Amylose: α-1,4, không nhánh, xoắn. Amylopectin: α-1,4 + **α-1,6**, phân nhánh. Cellulose: **β-1,4**, mạch thẳng, mỗi mắt xích 3 –OH.
> 5. Nhiều –OH kề nhau (glucose, fructose, saccharose, maltose) → hoà tan Cu(OH)~2~ → **xanh lam**.
> 6. Có –CHO (glucose, maltose) hoặc chuyển được thành –CHO trong kiềm (fructose) → **tráng bạc**, Cu(OH)~2~/OH^−^ đun nóng → **Cu~2~O đỏ gạch**.
> 7. **Nước bromine** chỉ bị glucose, maltose làm mất màu; fructose **không**.
> 8. Thuỷ phân: saccharose → glucose + fructose; maltose, tinh bột, cellulose → **chỉ glucose**.
> 9. Riêng tinh bột + iodine → **xanh tím**. Riêng cellulose + HNO~3~ đặc/H~2~SO~4~ đặc → **cellulose nitrate**; cellulose tan trong **nước Schweizer**.
> 10. Tỉ lệ vàng: C~6~H~12~O~6~ → 2Ag; C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~; C~6~H~10~O~5~ (162) → C~6~H~12~O~6~ (180); 162 + 3HNO~3~ → 297. Đi xuôi nhân H, đi ngược chia H.

Bài này **không giảng lại từ đầu**. Em dùng nó để xâu chuỗi ba bài: Bài 4 (glucose, fructose), Bài 5 (saccharose, maltose), Bài 6 (tinh bột, cellulose). Chỗ nào chưa vững, bấm "xem Bài X" để quay lại.

## 1. Hệ thống hoá cấu tạo

### 1.1. Bức tranh toàn chương

Cả chương xoay quanh **một viên gạch**: gốc glucose (và một lần gốc fructose). Ghép 2 viên được disaccharide; ghép hàng nghìn viên được polysaccharide. Mỗi lần ghép thêm một viên thì tách ra một phân tử H~2~O, vì thế mới có các công thức C~12~H~22~O~11~ = 2C~6~H~12~O~6~ − H~2~O và mắt xích C~6~H~10~O~5~ = C~6~H~12~O~6~ − H~2~O.

![Hình 1. Hệ thống hoá chương 2: ba loại carbohydrate, sáu chất, nhóm chức hoặc liên kết glycoside đặc trưng, và các cặp đồng phân](he-thong.svg)

### 1.2. Bảng cấu tạo sáu chất

| | Glucose | Fructose | Saccharose | Maltose | Tinh bột | Cellulose |
|---|---|---|---|---|---|---|
| Loại | mono | mono | di | di | poly | poly |
| Công thức | C~6~H~12~O~6~ | C~6~H~12~O~6~ | C~12~H~22~O~11~ | C~12~H~22~O~11~ | (C~6~H~10~O~5~)~n~ | (C~6~H~10~O~5~)~n~ |
| Gốc tạo thành | — | — | α-glucose + β-fructose | 2 glucose | α-glucose | **β-glucose** |
| Liên kết glycoside | — | — | **α-1,2** | **α-1,4** | α-1,4 (+ α-1,6 ở amylopectin) | **β-1,4** |
| Nhóm chức (mạch hở) | 5 –OH, 1 **–CHO** | 5 –OH, 1 **C=O** (C2) | 8 –OH, không –CHO | 8 –OH, 1 –CHO (khi mở vòng) | nhiều –OH | 3 –OH/mắt xích |
| Còn –OH hemiacetal (hemiketal) tự do? | có (C1) | có (C2) | **không** | **có** (gốc thứ hai) | chỉ 1 ở đầu mạch (không đáng kể) | chỉ 1 ở đầu mạch (không đáng kể) |
| Xem lại | Bài 4 | Bài 4 | Bài 5 | Bài 5 | Bài 6 | Bài 6 |

**Vì sao dòng "còn –OH hemiacetal tự do?" lại quan trọng nhất?** Vì nó quyết định chất có **mở vòng** được không, tức là có nhóm **–CHO** (hoặc C=O) để thể hiện **tính khử** hay không. Cả chương chỉ có một chuỗi suy luận:

*còn –OH hemiacetal?* → *mở vòng được?* → *có –CHO?* → *tráng bạc, khử Cu(OH)~2~ khi đun nóng, làm mất màu nước bromine?*

Saccharose "mắc kẹt" ở bước đầu: liên kết α-1,2 dùng đúng C1 của glucose và C2 của fructose, hai vị trí "đặc biệt" đều bận. Tinh bột và cellulose cũng coi như không có tính khử, vì mạch dài hàng nghìn gốc chỉ còn một nhóm –OH hemiacetal ở đầu mạch (xem Bài 6).

> [!nen-tang] Gọi tên liên kết glycoside
> Tên liên kết = **cấu hình ở C1** của gốc dùng nhóm –OH hemiacetal (α hay β) + **số thứ tự hai carbon** được nối. Ví dụ α-1,4 là C1 (dạng α) của gốc trước nối qua O với C4 của gốc sau. Riêng saccharose là α-1,2 vì nối C1 của glucose với C2 của fructose (Bài 5).

### 1.3. Ba cặp chất dễ nhầm

| Cặp | Giống nhau | Khác nhau (chỗ đề hay hỏi) |
|---|---|---|
| Glucose – fructose | Đồng phân C~6~H~12~O~6~; hoà tan Cu(OH)~2~; tráng bạc; khử Cu(OH)~2~ khi đun nóng | Glucose có **–CHO**, vòng 6 cạnh; fructose có **C=O ở C2**, vòng 5 cạnh. Chỉ **glucose** làm mất màu nước bromine |
| Saccharose – maltose | Đồng phân C~12~H~22~O~11~; hoà tan Cu(OH)~2~; bị thuỷ phân | Saccharose: α-1,2, **không** tráng bạc, thuỷ phân → glucose + **fructose**. Maltose: α-1,4, **có** tráng bạc, thuỷ phân → **2 glucose** |
| Tinh bột – cellulose | Cùng dạng (C~6~H~10~O~5~)~n~; thuỷ phân hoàn toàn → glucose; không tráng bạc, không hoà tan Cu(OH)~2~ | **Không** phải đồng phân (n khác). Tinh bột: α, có nhánh (amylopectin), **iodine → xanh tím**. Cellulose: β-1,4, mạch thẳng, **+ HNO~3~**, tan trong **nước Schweizer** |

> [!bay] Đồng phân hay không?
> - Glucose và fructose: **có**. Saccharose và maltose: **có**.
> - Tinh bột và cellulose: **không**, dù viết chung (C~6~H~10~O~5~)~n~, vì giá trị n khác nhau.

## 2. Hệ thống hoá tính chất hoá học

### 2.1. Bảng tính chất tổng hợp

SGK (tr. 34) tổng kết 5 chất với 4 thuốc thử. Bảng dưới đây bổ sung **maltose** (suy từ cấu tạo, xem Bài 5) và các phản ứng riêng. Dấu "—" là không phản ứng (hoặc không có hiện tượng).

| Thuốc thử | Glucose | Fructose | Saccharose | Maltose | Tinh bột | Cellulose |
|---|---|---|---|---|---|---|
| Cu(OH)~2~, nhiệt độ thường | xanh lam | xanh lam | xanh lam | xanh lam | — | — |
| Cu(OH)~2~/OH^−^, đun nóng | Cu~2~O đỏ gạch | Cu~2~O đỏ gạch | — | Cu~2~O đỏ gạch | — | — |
| Thuốc thử Tollens, t° | Ag | Ag | — | Ag | — | — |
| Nước bromine | mất màu | — | — | mất màu | — | — |
| Thuỷ phân (H^+^ hoặc enzyme) | — | — | glucose + fructose | glucose | glucose | glucose |
| Dung dịch iodine | — | — | — | — | **xanh tím** | — |
| HNO~3~ đặc / H~2~SO~4~ đặc | — | — | — | — | — | **cellulose nitrate** |
| Nước Schweizer (dấu hiệu SGK chỉ nêu cho cellulose) | (tan sẵn trong nước) | (tan sẵn trong nước) | (tan sẵn trong nước) | (tan sẵn trong nước) | không xét | **tan** |

Hai chú thích nhỏ cho bảng:

- Glucose, fructose, saccharose, maltose vốn đã **tan trong nước**, nên dấu hiệu "tan trong nước Schweizer" chỉ dùng cho **cellulose**, chất không tan trong nước và dung môi thông thường. SGK không nói gì về tinh bột với nước Schweizer, nên ô đó để "không xét"; muốn nhận ra tinh bột thì dùng iodine.
- Phản ứng **lên men** (tạo ethanol hoặc lactic acid) SGK chỉ nêu với **glucose**. Glucose dạng vòng còn phản ứng với CH~3~OH/HCl khan tạo methyl glucoside (Bài 4).

**Đọc bảng theo cột nhóm chức** thay vì học thuộc từng ô:

1. **Hàng 1** (Cu(OH)~2~ thường) là phản ứng của **nhiều –OH kề nhau**: 4 đường tan đều có. Tinh bột, cellulose không tan nên không phản ứng.
2. **Hàng 2, 3** là phản ứng của **–CHO** trong môi trường **kiềm**: glucose, maltose có –CHO; fructose chuyển thành glucose trong kiềm nên cũng có.
3. **Hàng 4** cũng là phản ứng của –CHO nhưng nước bromine **không có kiềm**, nên fructose bị loại.
4. **Hàng 5** là phản ứng của **liên kết glycoside**: chỉ di- và polysaccharide có.
5. **Hàng 6, 7, 8** là phản ứng **riêng** của từng polysaccharide, dùng để nhận ra chúng.

> [!meo] Một câu thần chú cho cả bảng
> "**Bốn tan xanh lam – ba tráng bạc – hai mất màu bromine – bốn thuỷ phân.**"
> - 4 chất hoà tan Cu(OH)~2~: glucose, fructose, saccharose, maltose.
> - 3 chất tráng bạc: glucose, fructose, maltose.
> - 2 chất làm mất màu nước bromine: glucose, maltose.
> - 4 chất thuỷ phân: saccharose, maltose, tinh bột, cellulose.
>
> (Tính trong dãy 6 chất của chương. Đề thêm glycerol, ethanol, aldehyde… thì em phải đếm lại.)

### 2.2. Bảng tỉ lệ mol dùng trong tính toán

| Quá trình | Tỉ lệ |
|---|---|
| Hoà tan Cu(OH)~2~ (glucose, fructose, saccharose, maltose) | 2 phân tử đường : 1 Cu(OH)~2~ |
| Tráng bạc trực tiếp | glucose, fructose, maltose: 1 → **2Ag**; saccharose: **0** |
| Thuỷ phân hoàn toàn rồi tráng bạc | saccharose, maltose: 1 → **4Ag**; mắt xích C~6~H~10~O~5~: 1 → 2Ag |
| Khử Cu(OH)~2~/OH^−^, đun nóng | 1 chất có –CHO → 1 Cu~2~O |
| Nước bromine | glucose, maltose: 1 : 1 Br~2~ |
| Thuỷ phân tinh bột/cellulose | C~6~H~10~O~5~ (162) → C~6~H~12~O~6~ (180) |
| Lên men rượu | C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~ |
| Cellulose trinitrate | C~6~H~7~O~2~(OH)~3~ (162) + 3HNO~3~ → C~6~H~7~O~2~(ONO~2~)~3~ (297) + 3H~2~O |
| Quang hợp tạo tinh bột | 6nCO~2~ + 5nH~2~O → (C~6~H~10~O~5~)~n~ + 6nO~2~ |

> [!bay] Ba "con số 2" dễ quên
> - 1 glucose → **2** Ag (không phải 1).
> - 1 glucose → **2** C~2~H~5~OH + **2** CO~2~ (không phải 1).
> - 1 maltose (tráng bạc trực tiếp) → chỉ **2** Ag (không phải 4); sau thuỷ phân hoàn toàn mới → 4 Ag.

## 3. Sơ đồ chuyển hoá

Các chất trong chương không đứng riêng lẻ. Chúng nối với nhau thành một **vòng tuần hoàn**: cây lấy CO~2~ tạo đường, người và vi sinh vật "đốt" hoặc lên men đường, trả CO~2~ về khí quyển.

![Hình 2. Sơ đồ chuyển hoá giữa các carbohydrate (mũi tên cam: tổng hợp, lên men, chuyển hoá; mũi tên xanh: thuỷ phân)](chuyen-hoa.svg)

Các phương trình chính (xem Bài 4, 5, 6):

=> 6CO~2~ + 6H~2~O → C~6~H~12~O~6~ + 6O~2~    (ánh sáng, chất diệp lục)

=> (C~6~H~10~O~5~)~n~ + nH~2~O → nC~6~H~12~O~6~    (H^+^ hoặc enzyme, t°)

=> C~12~H~22~O~11~ (saccharose) + H~2~O → C~6~H~12~O~6~ (glucose) + C~6~H~12~O~6~ (fructose)    (H^+^ hoặc enzyme)

=> C~12~H~22~O~11~ (maltose) + H~2~O → 2C~6~H~12~O~6~ (glucose)    (H^+^ hoặc enzyme)

=> C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~    (enzyme)

=> C~6~H~12~O~6~ → 2CH~3~CH(OH)COOH    (enzyme)

=> [C~6~H~7~O~2~(OH)~3~]~n~ + 3nHNO~3~ → [C~6~H~7~O~2~(ONO~2~)~3~]~n~ + 3nH~2~O    (H~2~SO~4~ đặc, t°)

**Trong cơ thể người** (Bài 6): tinh bột → (α-amylase ở miệng) dextrin, maltose → (ruột non) glucose → máu → oxi hoá thành CO~2~ + H~2~O cung cấp năng lượng, phần dư → glycogen ở gan, cơ. Người không có enzyme cắt liên kết β-1,4 nên không tiêu hoá được cellulose.

> [!ung-dung] Ethanol sinh học: cả chương trong một nhà máy
> Nhà máy cồn từ sắn chạy đúng sơ đồ trên: nghiền sắn → hồ hoá tinh bột → thuỷ phân bằng enzyme thành glucose → lên men thành ethanol → chưng cất. Cồn từ rơm rạ, bã mía, mùn cưa (cellulose) khó hơn, vì cellulose khó thuỷ phân hơn tinh bột. Khí CO~2~ sinh ra được thu hồi làm nước giải khát có gas, đá khô.

## 4. Nhận biết các carbohydrate

### 4.1. Dấu hiệu "chỉ một chất có"

Trước khi lập quy trình, hãy tìm thuốc thử **chỉ một chất phản ứng**:

| Dấu hiệu riêng | Chất |
|---|---|
| Iodine → xanh tím | tinh bột |
| Tan trong nước Schweizer, không tan trong nước | cellulose |
| Hoà tan Cu(OH)~2~ nhưng **không** tráng bạc, **không** đỏ gạch khi đun | saccharose (trong 4 đường tan) |
| Tráng bạc nhưng **không** làm mất màu nước bromine | fructose |

Glucose và maltose cho **cùng hiện tượng** với mọi thuốc thử trong bảng. Đề chỉ phân biệt hai chất này bằng **định lượng**: cùng số mol, tráng bạc trực tiếp như nhau (2Ag), nhưng thuỷ phân hoàn toàn rồi tráng bạc thì maltose cho gấp đôi (4Ag) (xem Ví dụ 2).

### 4.2. Quy trình nhận biết mẫu

![Hình 3. Sơ đồ nhận biết năm dung dịch: hồ tinh bột, glycerol, saccharose, glucose, fructose](nhan-biet.svg)

Nguyên tắc chung:

1. Dùng thuốc thử có **hiện tượng riêng** trước (iodine cho tinh bột).
2. Chia nhóm bằng thuốc thử Tollens: nhóm **có tính khử** và nhóm **không có**.
3. Trong nhóm có tính khử: **nước bromine** tách glucose (và maltose) khỏi fructose.
4. Trong nhóm không có tính khử: **thuỷ phân rồi tráng bạc** tách saccharose khỏi các polyalcohol khác (glycerol).
5. Mỗi bước lấy **mẫu mới** của dung dịch, không đổ thuốc thử chồng lên ống đã dùng.

> [!bay] Thuốc thử "vô dụng"
> - Cu(OH)~2~ ở nhiệt độ thường **không** tách được 4 đường tan với nhau (đều xanh lam). Nó chỉ tách được đường khỏi alcohol đơn chức (ethanol).
> - Thuốc thử Tollens **không** tách được glucose với fructose.
> - Thuỷ phân **không** phân biệt được tinh bột với cellulose (đều ra glucose). Phải dùng iodine.

## 5. Lỗi sai hay gặp của cả chương

**Về cấu tạo**

- Ghi saccharose có liên kết α-1,4 (đúng là **α-1,2**); maltose mới là α-1,4.
- Nói "cellulose gồm các gốc α-glucose" (đúng là **β-glucose**, liên kết β-1,4).
- Nói "amylose phân nhánh" (chỉ **amylopectin** phân nhánh, nhờ liên kết α-1,6).
- Nói "tinh bột và cellulose là đồng phân".
- Nói "O trong vòng glucose là O của nhóm –CHO" (đúng là O của –OH ở C5).
- Đếm saccharose có 11 nhóm –OH (đúng là **8**; 11 là số nguyên tử O).

**Về tính chất**

- Cho rằng fructose không tráng bạc vì không có –CHO (thực tế **có**, nhờ chuyển thành glucose trong kiềm).
- Cho fructose làm mất màu nước bromine (**không**; SGK tr. 34 ghi rõ).
- Cho saccharose tráng bạc, hoặc tạo Cu~2~O khi đun với Cu(OH)~2~/NaOH (**không**).
- Lẫn hai hiện tượng của Cu(OH)~2~: **xanh lam** ở nhiệt độ thường (–OH kề nhau) và **đỏ gạch** khi đun nóng (–CHO).
- Quên **trung hoà acid** trước khi tráng bạc hoặc thử Cu(OH)~2~ sau thuỷ phân.
- Cho tinh bột hoà tan Cu(OH)~2~, hoặc cho cellulose phản ứng màu với iodine.
- Gọi cellulose nitrate là hợp chất nitro (đúng là **ester** của nitric acid).

**Về tính toán**

- Quên hệ số 2 (Ag, ethanol, CO~2~).
- Nhân hiệu suất khi đi ngược (phải **chia**).
- Đếm Ag của phần **saccharose chưa thuỷ phân** (bằng 0) hoặc quên Ag của phần **maltose chưa thuỷ phân** (vẫn 2Ag).
- Quên nhân hàm lượng % tinh bột/cellulose trong nguyên liệu.
- Coi độ rượu là phần trăm khối lượng (đúng là phần trăm **thể tích**).
- CO~2~ vào nước vôi: lấy n(CO~2~) = n(CaCO~3~) khi nước vôi **không dư**.

## 6. Bài tập tổng hợp

Các ví dụ dưới đây phối hợp kiến thức của nhiều bài. Hãy tự làm trước, mở từng gợi ý khi bí.

### 6.1. Đếm số chất thoả mãn tính chất

> [!vi-du] Ví dụ 1
> Cho các chất: glucose, fructose, saccharose, maltose, amylose, cellulose, glycerol.
>
> a) Có bao nhiêu chất làm mất màu nước bromine?
>
> b) Có bao nhiêu chất khi thuỷ phân hoàn toàn chỉ thu được **một loại** monosaccharide?
>
> c) Có bao nhiêu chất khử được Cu(OH)~2~ trong môi trường kiềm khi đun nóng, tạo kết tủa đỏ gạch?
>
> d) Có bao nhiêu chất hoà tan được Cu(OH)~2~ ở nhiệt độ thường?

> [!goi-y] Gợi ý 1
> Gắn mỗi câu hỏi với **một đặc điểm cấu tạo**: (a) –CHO thật, không cần kiềm; (b) có liên kết glycoside và chỉ gồm gốc glucose; (c) –CHO trong môi trường kiềm; (d) nhiều –OH kề nhau và tan trong nước.

> [!goi-y] Gợi ý 2
> Đừng quên glycerol: nó có 3 nhóm –OH kề nhau nhưng không có –CHO, không bị thuỷ phân.

> [!loi-giai] Lời giải
> a) Glucose, maltose → **2** chất. (Fructose không phản ứng vì nước bromine không có môi trường kiềm.)
>
> b) Maltose, amylose, cellulose (đều chỉ cho glucose) → **3** chất. Saccharose cho hai loại (glucose và fructose); glucose, fructose, glycerol không bị thuỷ phân.
>
> c) Glucose, fructose, maltose → **3** chất.
>
> d) Glucose, fructose, saccharose, maltose, glycerol → **5** chất. Amylose và cellulose không phản ứng.

### 6.2. Hỗn hợp nhiều carbohydrate và phản ứng tráng bạc

**Phương pháp chung:** đặt ẩn số mol mỗi chất. Viết **hai** phương trình theo hai thí nghiệm: tráng bạc **trực tiếp** (chỉ chất có tính khử) và **sau thuỷ phân** (mỗi gốc monosaccharide → 2Ag). Chú ý chất nào có M bằng nhau để gộp.

> [!vi-du] Ví dụ 2
> Hỗn hợp X gồm glucose và maltose. Cho X tác dụng với lượng dư thuốc thử Tollens, thu được 32,4 g Ag. Mặt khác, thuỷ phân hoàn toàn cùng lượng X trong môi trường acid, trung hoà rồi cho tác dụng với lượng dư thuốc thử Tollens, thu được 43,2 g Ag.
>
> a) Tính khối lượng của X.
>
> b) Tính phần trăm khối lượng maltose trong X.

> [!goi-y] Gợi ý 1
> Tráng bạc trực tiếp: glucose → 2Ag, maltose (có 1 nhóm –CHO) → 2Ag.

> [!goi-y] Gợi ý 2
> Sau thuỷ phân hoàn toàn, glucose vẫn là glucose (→ 2Ag), còn maltose → 2 glucose (→ 4Ag). Lấy hiệu hai lượng Ag sẽ ra ngay số mol maltose.

> [!loi-giai] Lời giải
> Gọi a, b lần lượt là số mol glucose, maltose.
>
> Tráng bạc trực tiếp: 2a + 2b = 32,4 : 108 = 0,3.
>
> Sau thuỷ phân: 2a + 4b = 43,2 : 108 = 0,4.
>
> Trừ hai phương trình: 2b = 0,1 → b = 0,05; a = 0,1.
>
> a) m(X) = 0,1 · 180 + 0,05 · 342 = 18 + 17,1 = **35,1 g**.
>
> b) %m(maltose) = 17,1 : 35,1 · 100% ≈ **48,7%**.
>
> Nhận xét: glucose và maltose cho cùng hiện tượng với mọi thuốc thử, nhưng **khác nhau về lượng Ag** sau thuỷ phân. Đây là cách duy nhất "nhận ra" maltose trong đề tính toán.

### 6.3. Chuỗi phản ứng có hiệu suất (tương tự SGK Câu 3)

> [!vi-du] Ví dụ 3
> Một cơ sở sản xuất ethanol sinh học từ vỏ trấu chứa 40,5% cellulose về khối lượng. Hiệu suất của cả quá trình (thuỷ phân và lên men) là 60%.
>
> a) Tính khối lượng ethanol thu được từ 1 tấn vỏ trấu.
>
> b) Muốn thu được 1 tấn ethanol thì cần bao nhiêu tấn vỏ trấu? (làm tròn đến hàng phần mười)

> [!goi-y] Gợi ý 1
> m(cellulose) = 1 000 · 40,5% = 405 kg. Viết sơ đồ theo mắt xích: C~6~H~10~O~5~ → C~6~H~12~O~6~ → 2C~2~H~5~OH.

> [!goi-y] Gợi ý 2
> Câu b là bài **đi ngược**, nhưng em đã có "năng suất" ở câu a (kg ethanol trên 1 tấn trấu), nên chỉ cần chia.

> [!loi-giai] Lời giải
> a) n(C~6~H~10~O~5~) = 405 : 162 = 2,5 kmol → n(C~2~H~5~OH) lí thuyết = 2 · 2,5 = 5 kmol.
>
> m(C~2~H~5~OH) = 5 · 46 · 0,6 = **138 kg**.
>
> b) 1 tấn trấu cho 138 kg ethanol → cần 1 000 : 138 ≈ 7,246 tấn ≈ **7,2 tấn** vỏ trấu.

> [!meo] Kiểm tra nhanh bằng "hệ số chuyển đổi"
> Từ 162 g mắt xích được tối đa 2 · 46 = 92 g ethanol, tức hệ số 92 : 162 ≈ 0,568. Vậy m(ethanol) = m(cellulose) · 0,568 · H = 405 · 0,568 · 0,6 ≈ 138 kg. Trên máy tính cầm tay, em nhập thẳng 405 × 92 ÷ 162 × 0,6.

### 6.4. Cellulose nitrate là hỗn hợp

Trong thực tế, cellulose nitrate thường là **hỗn hợp** các mắt xích đã ester hoá 1, 2 hoặc 3 nhóm –OH. Khi đó dùng **bảo toàn mắt xích** và **tăng khối lượng**: mỗi nhóm –OH đổi thành –ONO~2~ làm khối lượng tăng 62 − 17 = 45, và tiêu tốn 1 HNO~3~.

> [!vi-du] Ví dụ 4
> Cho 32,4 g cellulose phản ứng hoàn toàn với hỗn hợp HNO~3~ đặc và H~2~SO~4~ đặc (dư), thu được 56,7 g hỗn hợp gồm cellulose dinitrate và cellulose trinitrate.
>
> a) Tính số mol HNO~3~ đã phản ứng.
>
> b) Tính phần trăm khối lượng cellulose trinitrate trong hỗn hợp sản phẩm.

> [!goi-y] Gợi ý 1
> Số mắt xích không đổi: n(mắt xích) = 32,4 : 162. Khối lượng tăng = 56,7 − 32,4 chia cho 45 ra số nhóm –ONO~2~, cũng là số mol HNO~3~.

> [!goi-y] Gợi ý 2
> Gọi x, y là số mol mắt xích dinitrate (M = 252), trinitrate (M = 297). Lập hệ theo số mắt xích và số nhóm –ONO~2~.

> [!loi-giai] Lời giải
> n(mắt xích) = 32,4 : 162 = 0,2 mol.
>
> a) Khối lượng tăng = 56,7 − 32,4 = 24,3 g → n(–ONO~2~) = 24,3 : 45 = 0,54 mol = n(HNO~3~) phản ứng = **0,54 mol**.
>
> b) Hệ: x + y = 0,2 và 2x + 3y = 0,54 → y = 0,14; x = 0,06.
>
> Kiểm tra: 0,06 · 252 + 0,14 · 297 = 15,12 + 41,58 = 56,7 g. ✓
>
> %m(trinitrate) = 41,58 : 56,7 · 100% ≈ **73,3%**.

### 6.5. Nhận biết và giải thích hiện tượng

> [!vi-du] Ví dụ 5 (Đúng/Sai)
> Có 4 lọ mất nhãn chứa riêng các dung dịch: hồ tinh bột, saccharose, glucose, fructose. Một học sinh đề xuất các nhận định:
>
> a) Chỉ dùng dung dịch iodine là nhận ra được lọ hồ tinh bột.
>
> b) Dùng Cu(OH)~2~ ở nhiệt độ thường phân biệt được saccharose với glucose.
>
> c) Sau khi nhận ra hồ tinh bột, dùng thuốc thử Tollens sẽ nhận ra được saccharose.
>
> d) Có thể phân biệt glucose với fructose bằng Cu(OH)~2~ trong NaOH, đun nóng.

> [!goi-y] Gợi ý 1
> Với mỗi thuốc thử, viết hiện tượng của **từng** chất. Thuốc thử chỉ phân biệt được khi hiện tượng **khác nhau**.

> [!goi-y] Gợi ý 2
> Cu(OH)~2~/OH^−^ đun nóng và thuốc thử Tollens đều có môi trường kiềm. Fructose ra sao trong kiềm?

> [!loi-giai] Lời giải
> a) **Đúng**: chỉ tinh bột cho màu xanh tím.
>
> b) **Sai**: cả hai đều hoà tan Cu(OH)~2~ tạo dung dịch xanh lam.
>
> c) **Đúng**: trong 3 lọ còn lại, chỉ saccharose không tạo Ag.
>
> d) **Sai**: cả hai đều tạo Cu~2~O đỏ gạch. Phải dùng **nước bromine**: glucose làm mất màu, fructose thì không.

## 7. Đối chiếu bài tập SGK (tr. 34)

**Câu 1 (Đúng/Sai về 6 chất).** Dùng bảng ở mục 1.2 và Hình 1: đếm số chất mỗi loại; soát các nhóm –OH; nhớ glucose ⇌ fructose trong môi trường kiềm (Bài 4). Bài luyện cùng dạng: Ví dụ 1 ở trên và các câu Đúng/Sai trong đề luyện chương.

**Câu 2 (giải thích hiện tượng).** Ba hiện tượng đều nằm trên sơ đồ Hình 2:

- *Nhai kĩ cơm thấy ngọt*: enzyme α-amylase trong nước bọt cắt tinh bột thành dextrin và **maltose**, có vị ngọt (Bài 6).
- *Nước ép chuối chín tráng bạc*: khi chuối chín, tinh bột chuyển hoá thành các đường như **glucose, fructose** (và saccharose). Glucose, fructose có tính khử nên khử được thuốc thử Tollens.
- *Iodine lên lát chuối xanh → xanh tím*: chuối xanh còn rất nhiều **tinh bột**. Chuối càng chín, màu xanh tím càng nhạt.

> [!vi-du] Ví dụ 6 (tương tự Câu 2)
> Lấy hai mẫu: (1) dịch ép từ quả táo xanh, còn cứng; (2) dịch ép từ quả táo chín. Nhỏ dung dịch iodine vào mỗi mẫu, và cho mỗi mẫu tác dụng với thuốc thử Tollens. Dự đoán hiện tượng và giải thích.

> [!goi-y] Gợi ý 1
> Khi quả chín, chất dự trữ nào bị chuyển hoá và thành chất gì?

> [!loi-giai] Lời giải
> Mẫu (1): quả xanh nhiều tinh bột → iodine cho màu **xanh tím rõ**; ít đường khử → lớp bạc **mỏng** (hoặc rất ít).
>
> Mẫu (2): tinh bột đã chuyển phần lớn thành glucose, fructose → iodine cho màu **nhạt** (hoặc gần như không đổi); lượng đường khử nhiều → lớp bạc **dày, rõ**.

**Câu 3 (cồn sinh học từ mùn cưa).** Cùng dạng với Ví dụ 3: khối lượng nguyên liệu × % cellulose → số mol mắt xích → × 2 ra ethanol → × hiệu suất. Em hãy tự làm với số liệu trong SGK, rồi kiểm tra bằng "hệ số chuyển đổi" 92 : 162 ở khung mẹo.

## Tóm tắt

| | Glucose | Fructose | Saccharose | Maltose | Tinh bột | Cellulose |
|---|---|---|---|---|---|---|
| Liên kết / nhóm chức đặc trưng | –CHO | C=O (C2) | α-1,2 | α-1,4 | α-1,4; α-1,6 | β-1,4 |
| Cu(OH)~2~ thường | xanh lam | xanh lam | xanh lam | xanh lam | — | — |
| Tráng bạc (trực tiếp) | 2Ag | 2Ag | — | 2Ag | — | — |
| Nước bromine | mất màu | — | — | mất màu | — | — |
| Thuỷ phân | — | — | glu + fru | 2 glu | glu | glu |
| Phản ứng riêng | lên men; CH~3~OH/HCl | — | — | — | iodine: xanh tím | HNO~3~; nước Schweizer |

**Ba bước giải mọi bài toán của chương:**

1. Đổi ra **mol gốc** (glucose 180, disaccharide 342, mắt xích 162).
2. Dùng **tỉ lệ** ở bảng 2.2: Ag, Cu~2~O, Br~2~, ethanol, CO~2~, HNO~3~.
3. Xử lí **hiệu suất** (đi xuôi nhân, đi ngược chia; nhiều giai đoạn thì nhân các H) và **hàm lượng %** trong nguyên liệu.
