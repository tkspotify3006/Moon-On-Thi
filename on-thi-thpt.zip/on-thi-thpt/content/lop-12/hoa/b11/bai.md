---
title: Ôn tập chương 3
thoi-gian: 50 phút
muc-tieu:
  - Hệ thống hoá khái niệm, phân loại, tính chất vật lí và hoá học của amine, amino acid, peptide, protein; thấy được mối liên hệ "amine → amino acid → peptide → protein".
  - Lập và dùng được bảng phân biệt các chất trong chương theo thuốc thử (quỳ tím, HCl, NaOH, nước bromine, Cu(OH)~2~/NaOH, HNO~3~ đặc, nhiệt) để nhận biết và đếm số chất thoả mãn một tính chất.
  - Phân biệt được các cặp khái niệm dễ nhầm: bậc amine với bậc carbon, liên kết peptide với liên kết amide của polyamide, đông tụ với thuỷ phân, màu tím biuret với màu xanh lam.
  - Giải được các bài toán tổng hợp: hỗn hợp amine và amino acid với HCl, NaOH; bài hai giai đoạn (HCl rồi NaOH); thuỷ phân peptide hoàn toàn và không hoàn toàn.
  - Viết được phương trình hoá học của amine, amino acid, peptide với acid, base và xác định được các peptide sinh ra khi thuỷ phân không hoàn toàn.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. **Amine** = NH~3~ thay H bằng gốc hydrocarbon. Bậc amine = **số gốc gắn vào N**. Alkylamine (N gắn gốc alkyl) và arylamine (N gắn thẳng vào vòng benzene, như aniline).
> 2. Cặp electron chưa liên kết trên N → amine có **tính base yếu**. Alkylamine làm **quỳ hoá xanh**, aniline **không** đổi màu quỳ, nhưng vẫn tác dụng với HCl.
> 3. Phản ứng riêng của amine: methylamine tạo **kết tủa nâu đỏ** với FeCl~3~ và hoà tan Cu(OH)~2~ thành **dung dịch xanh lam**; alkylamine bậc một + HNO~2~ → alcohol + **N~2~↑**; aniline + nước bromine → **kết tủa trắng** (thế 3 H ở vị trí 2, 4, 6).
> 4. **Amino acid** = tạp chức, có cả –NH~2~ và –COOH, tồn tại chủ yếu ở dạng **ion lưỡng cực** → **chất rắn**, nóng chảy cao, tan tốt trong nước.
> 5. Amino acid **lưỡng tính** (tác dụng cả HCl và NaOH), bị **ester hoá**, có tính **điện di**. ε- và ω-amino acid **trùng ngưng** thành polyamide.
> 6. **Peptide** = các đơn vị **α-amino acid** nối bằng liên kết peptide –CO–NH–. n gốc thì có (n − 1) liên kết peptide. Tên viết từ **đầu N** đến **đầu C**.
> 7. Peptide bị **thuỷ phân** từng phần (ra peptide ngắn hơn, là các đoạn liên tiếp) hoặc hoàn toàn (ra α-amino acid). Từ **tripeptide** trở lên mới có **màu tím biuret**.
> 8. **Protein** = một hay nhiều chuỗi polypeptide. Dạng sợi **không tan**, dạng hình cầu **tan tạo dung dịch keo**. Protein đơn giản thuỷ phân hoàn toàn chỉ cho α-amino acid.
> 9. Protein: biuret → **tím**; HNO~3~ đặc → **rắn vàng**; **đông tụ** bởi nhiệt, acid, base, ion kim loại nặng (liên kết peptide vẫn còn).
> 10. Tính toán: R–NH~2~ + HCl **không tạo nước** (m muối = m + 36,5n); –COOH + NaOH **tạo nước** (mỗi nhóm tăng 22). Bài HCl rồi NaOH: n(NaOH) = n(HCl) + n(–COOH). Peptide n gốc: M = ΣM − 18(n − 1).

Bài này **không giảng lại từ đầu**. Em dùng nó để xâu chuỗi ba bài: Bài 8 (amine), Bài 9 (amino acid và peptide), Bài 10 (protein và enzyme). Chỗ nào chưa vững, hãy quay lại "xem Bài X".

## 1. Hệ thống hoá kiến thức

### 1.1. Bức tranh toàn chương: một nhóm –NH~2~ đi xuyên suốt

Cả chương xoay quanh **nguyên tử N còn một cặp electron chưa liên kết**. Hãy nhìn bốn loại chất như bốn bậc thang, mỗi bậc "lắp" thêm một chi tiết vào bậc trước:

1. Thay H của NH~3~ bằng gốc hydrocarbon → **amine**. Cặp electron trên N vẫn còn → amine là base, giống NH~3~.
2. Gắn thêm nhóm –COOH vào cùng phân tử → **amino acid**. Bây giờ phân tử vừa có "đầu base" vừa có "đầu acid", nên nó **lưỡng tính** và tự chuyển thành ion lưỡng cực.
3. Nối nhóm –COOH của α-amino acid này với nhóm –NH~2~ của α-amino acid kia, tách H~2~O → **peptide** với liên kết –CO–NH–.
4. Nối rất nhiều đơn vị, có thể gồm nhiều chuỗi → **protein**, phân tử khối hàng chục nghìn trở lên.

Đi ngược lại các bậc thang là **phản ứng thuỷ phân**: protein → polypeptide → peptide nhỏ → α-amino acid.

![Hình 1. Hệ thống hoá chương 3: từ ammonia đến amine, amino acid, peptide, protein; bên phải là tính chất đặc trưng của từng loại](he-thong.svg)

### 1.2. Bảng hệ thống bốn loại chất

SGK (tr. 49) có bảng tổng kết theo sáu hàng. Bảng dưới đây diễn đạt lại và thêm cột "xem lại".

| | Amine | Amino acid | Peptide | Protein |
|---|---|---|---|---|
| Khái niệm | Dẫn xuất của NH~3~, thay H bằng gốc hydrocarbon | Tạp chức, có –NH~2~ và –COOH | Các đơn vị α-amino acid nối bằng liên kết peptide | Cao phân tử, gồm một hay nhiều chuỗi polypeptide |
| Phân loại | Theo bậc: 1, 2, 3. Theo gốc: alkylamine, arylamine | (α-amino acid là quan trọng nhất) | Dipeptide, tripeptide… polypeptide | Đơn giản, phức tạp (có thành phần phi protein) |
| Vật lí | CH~3~NH~2~, (CH~3~)~2~NH, (CH~3~)~3~N, C~2~H~5~NH~2~: khí, tan tốt. Aniline: lỏng, ít tan | Rắn, nóng chảy cao, tan tốt trong nước | (SGK không nêu riêng) | Dạng sợi không tan; dạng hình cầu tan tạo dung dịch keo |
| Hoá học | Tính base yếu; tạo phức với Cu(OH)~2~; bậc một + HNO~2~; aniline thế bromine | Lưỡng tính; ester hoá; điện di; ε-, ω- trùng ngưng | Thuỷ phân; biuret (từ tripeptide) | Thuỷ phân; biuret; HNO~3~ đặc → vàng; đông tụ |
| Điều chế, ứng dụng | Alkyl hoá NH~3~; khử nitro. Aniline → dược phẩm, phẩm nhuộm, polymer | Bột ngọt (muối của glutamic acid); tơ nylon-6, nylon-7 | — | Thức ăn chính; enzyme; công nghệ sinh học |
| Xem lại | Bài 8 | Bài 9 | Bài 9 | Bài 10 |

**Đọc bảng theo hàng "Hoá học"**, em sẽ thấy mỗi tính chất đều có lí do từ cấu tạo:

- **Tính base** của amine và của nhóm –NH~2~ trong amino acid đều do **cặp electron trên N** nhận H^+^.
- **Tính acid** của amino acid do nhóm **–COOH** (giống acetic acid ở lớp 11).
- **Thuỷ phân** và **biuret** của peptide, protein đều do **liên kết peptide** –CO–NH–.
- **Đông tụ** là tính chất riêng của protein, vì chỉ phân tử khổng lồ có **hình dạng không gian** mới bị "phá dáng".

> [!nen-tang] Acid, base theo Brønsted – Lowry (lớp 11)
> - Acid **cho** H^+^, base **nhận** H^+^.
> - –NH~2~ nhận H^+^ thành –NH~3~^+^ (base); –COOH cho H^+^ thành –COO^−^ (acid).
> - Phản ứng của base yếu với acid mạnh (amine + HCl) **không tạo nước**. Phản ứng của acid với NaOH **tạo nước**.

## 2. Bảng so sánh – phân biệt

### 2.1. Một chất gặp nhiều thuốc thử

Bảng sau dùng để làm các câu "có bao nhiêu chất…" và câu nhận biết. Dấu "—" là không phản ứng hoặc không có hiện tượng nêu ở hàng đó. Ở hàng Cu(OH)~2~/NaOH, điều cần xét là có **màu tím biuret** hay không.

| Thuốc thử | CH~3~NH~2~ | C~6~H~5~NH~2~ | Glycine | Lysine | Glutamic acid | Gly-Ala | Gly-Ala-Gly | Lòng trắng trứng |
|---|---|---|---|---|---|---|---|---|
| Quỳ tím (dung dịch) | xanh | — | — | xanh | đỏ | (không xét) | (không xét) | (không xét) |
| Dung dịch HCl | tạo muối | tạo muối | tạo muối | tạo muối | tạo muối | thuỷ phân (đun nóng) | thuỷ phân (đun nóng) | thuỷ phân (đun nóng) |
| Dung dịch NaOH | — | — | tạo muối | tạo muối | tạo muối | thuỷ phân (đun nóng) | thuỷ phân (đun nóng) | thuỷ phân (đun nóng) |
| Nước bromine | — | **↓ trắng** | — | — | — | — | — | (không xét) |
| Cu(OH)~2~/NaOH | xanh lam (không phải biuret) | — | không tím | không tím | không tím | **không tím** | **tím** | **tím** |
| HNO~3~ đặc | (không xét) | (không xét) | (không xét) | (không xét) | (không xét) | (không xét) | (không xét) | **rắn vàng** |
| Đun nóng | — | — | — | — | — | — | — | **đông tụ** |

Ba điều cần rút ra từ bảng:

1. **HCl tác dụng với tất cả** các chất trong bảng (amine, amino acid có nhóm –NH~2~; peptide, protein bị thuỷ phân). Vì vậy câu hỏi "chất nào tác dụng với HCl" thường không phân loại được gì. Câu hỏi về **NaOH** mới phân loại: amine **không** tác dụng với NaOH.
2. **Quỳ tím** chỉ tách được ba nhóm: xanh (alkylamine, lysine), đỏ (glutamic acid), không đổi màu (aniline, glycine, alanine, valine).
3. **Cu(OH)~2~/NaOH** cho màu tím chỉ với **peptide có từ 2 liên kết peptide trở lên** và protein. Dipeptide và amino acid đều **không** cho màu tím.

> [!bay] Ba màu "xanh" và một màu tím
> - **Quỳ tím hoá xanh**: dung dịch có tính base (alkylamine, lysine).
> - **Dung dịch xanh lam** khi methylamine dư hoà tan Cu(OH)~2~: phức của Cu^2+^ với N của amine (Bài 8).
> - **Dung dịch xanh lam** khi glucose, glycerol, saccharose hoà tan Cu(OH)~2~: do nhiều nhóm –OH kề nhau (chương 2).
> - **Màu tím** với Cu(OH)~2~/NaOH: phản ứng **biuret** của peptide (từ tripeptide) và protein.

### 2.2. Những cặp dễ nhầm

| Cặp | Giống nhau | Khác nhau (chỗ đề hay hỏi) |
|---|---|---|
| Methylamine – aniline | Đều là amine bậc một, có tính base, tác dụng HCl | Methylamine: khí, quỳ **xanh**, tạo Fe(OH)~3~ với FeCl~3~, hoà tan Cu(OH)~2~. Aniline: lỏng, ít tan, **không** đổi màu quỳ, + nước bromine → **↓ trắng** |
| Bậc amine – bậc carbon | Đều đếm "số nhánh" | Bậc amine đếm **số gốc gắn vào N**. (CH~3~)~3~C–NH~2~ là amine **bậc một** dù N gắn vào C bậc ba |
| Amine – amino acid | Đều có nhóm –NH~2~, tác dụng HCl | Amine ít C ở thể khí, có mùi; amino acid là **chất rắn** kết tinh, không bay hơi (ion lưỡng cực). Amino acid tác dụng thêm với NaOH |
| HNO~2~ – HNO~3~ | Đều là acid chứa N | **Nitrous acid** HNO~2~: với alkylamine bậc một → alcohol + N~2~↑ (Bài 8). **Nitric acid** HNO~3~ đặc: với protein → chất rắn màu vàng (Bài 10) |
| Liên kết peptide – liên kết amide của polyamide | Cùng nhóm –CO–NH– | Liên kết peptide chỉ nối **hai đơn vị α-amino acid**. Capron (từ ε-amino acid) là polyamide, **không** phải polypeptide |
| Dipeptide – tripeptide | Đều bị thuỷ phân | Dipeptide có **1** liên kết peptide, **không** có màu biuret. Tripeptide có 2 liên kết, có màu tím |
| Gly-Ala – Ala-Gly | Cùng thành phần, cùng M = 146 | **Hai chất khác nhau**: đầu N lần lượt là Gly và Ala |
| Đông tụ – thuỷ phân protein | Đều làm protein "biến đổi" | **Đông tụ** chỉ phá hình dạng không gian, liên kết peptide **còn nguyên**, protein tách khỏi dung dịch. **Thuỷ phân** cắt liên kết peptide thành peptide nhỏ, amino acid |
| Protein đơn giản – phức tạp | Đều có chuỗi polypeptide | Tiêu chí duy nhất: có **thành phần phi protein** (nucleic acid, lipid, nhóm chứa sắt…) hay không. Không liên quan số chuỗi |

> [!meo] Hỏi "vì sao" để khỏi học thuộc
> Gặp một chất lạ trong đề, em hỏi ba câu: (1) có –NH~2~ gắn gốc gì? (base mạnh hay yếu); (2) có –COOH không? (tác dụng NaOH); (3) có bao nhiêu liên kết peptide? (thuỷ phân, biuret). Ba câu đó trả lời gần hết các hàng của bảng 2.1.

### 2.3. Bảng số liệu dùng trong tính toán

| Chất | M | Ghi chú |
|---|---|---|
| CH~3~NH~2~; C~2~H~5~NH~2~; C~6~H~5~NH~2~ | 31; 45; 93 | Amine no, đơn chức, mạch hở: M = 14n + 17 |
| C~6~H~2~Br~3~NH~2~ (kết tủa trắng) | 330 | 1 aniline + 3Br~2~ → 1 kết tủa + 3HBr |
| Gly; Ala; Val | 75; 89; 117 | 1 –NH~2~, 1 –COOH: M = 14n + 47 |
| Lys | 146 | **2** –NH~2~, 1 –COOH → 1 mol cần 2 mol HCl |
| Glu | 147 | 1 –NH~2~, **2** –COOH → 1 mol cần 2 mol NaOH |
| Gốc Gly; gốc Ala; gốc Val trong mạch | 57; 71; 99 | M(gốc) = M(amino acid) − 18 |
| Muối natri: Gly-Na; Ala-Na; Val-Na | 97; 111; 139 | M(muối) = M + 22 cho mỗi –COOH |
| Muối với HCl: Gly·HCl; Ala·HCl | 111,5; 125,5 | M(muối) = M + 36,5 cho mỗi –NH~2~ |

| Quá trình | Tỉ lệ, công thức |
|---|---|
| Amine đơn chức + HCl | n(amine) = n(HCl); m(muối) = m(amine) + m(HCl) |
| Amino acid + HCl | n(HCl) = số –NH~2~ × n; m(muối) = m + 36,5 · n(HCl) |
| Amino acid + NaOH | n(NaOH) = số –COOH × n; m(muối) = m + 22 · n(NaOH) |
| HCl trước, NaOH sau | n(NaOH) = n(HCl) + n(–COOH) |
| Peptide n gốc (Gly, Ala, Val) + NaOH | cần n NaOH, sinh 1 H~2~O |
| Peptide n gốc (Gly, Ala, Val) + HCl | cần n HCl và (n − 1) H~2~O |
| Thuỷ phân không hoàn toàn | Bảo toàn **số gốc** của từng loại amino acid |

## 3. Sơ đồ phản ứng của chương

Các phương trình tiêu biểu (xem lại Bài 8, 9, 10):

=> CH~3~NH~2~ + HCl → CH~3~NH~3~Cl

=> 3CH~3~NH~2~ + FeCl~3~ + 3H~2~O → Fe(OH)~3~↓ + 3CH~3~NH~3~Cl

=> CH~3~NH~2~ + HONO → CH~3~OH + N~2~↑ + H~2~O

=> C~6~H~5~NH~2~ + 3Br~2~ → C~6~H~2~Br~3~NH~2~↓ + 3HBr

=> H~2~N–CH~2~–COOH + HCl → ClH~3~N–CH~2~–COOH

=> H~2~N–CH~2~–COOH + NaOH → H~2~N–CH~2~–COONa + H~2~O

=> H~2~N–CH~2~–COOH + C~2~H~5~OH ⇌ H~2~N–CH~2~–COOC~2~H~5~ + H~2~O    (H~2~SO~4~ đặc, t°)

=> nH~2~N–[CH~2~]~5~–COOH → (–NH–[CH~2~]~5~–CO–)~n~ + nH~2~O    (t°)

=> Gly-Ala + 2NaOH → H~2~N–CH~2~–COONa + H~2~N–CH(CH~3~)–COONa + H~2~O

=> Gly-Ala + H~2~O + 2HCl → ClH~3~N–CH~2~–COOH + ClH~3~N–CH(CH~3~)–COOH

> [!ung-dung] Cả chương trong một bữa ăn
> Ăn cá: mùi tanh do trimethylamine, rửa bằng giấm hay chanh là "trung hoà amine" thành muối tan (Bài 8). Nấu canh cua: riêu nổi lên vì protein **đông tụ do nhiệt** (Bài 10). Trong dạ dày và ruột non, enzyme **thuỷ phân** protein thành α-amino acid. Cơ thể lại nối các amino acid đó thành protein của chính mình (Bài 9, 10). Bột ngọt nêm vào canh là muối natri của **glutamic acid** (Bài 9).

## 4. Nhận biết các chất trong chương

### 4.1. Dấu hiệu "chỉ một chất có"

| Dấu hiệu riêng | Chất |
|---|---|
| Nước bromine → kết tủa trắng (trong chương 3) | aniline |
| Quỳ tím hoá đỏ (trong các amino acid SGK) | glutamic acid |
| HNO~3~ đặc → chất rắn màu vàng; đun nóng → đông tụ | protein (lòng trắng trứng) |
| Cu(OH)~2~/NaOH → màu tím | peptide từ tripeptide trở lên, protein |
| HNO~2~, nhiệt độ thường → bọt khí N~2~ | alkylamine bậc một |
| FeCl~3~ → kết tủa nâu đỏ | alkylamine (dung dịch có OH^−^) |

### 4.2. Quy trình nhận biết mẫu

![Hình 2. Sơ đồ nhận biết bốn dung dịch methylamine, aniline, glycine, lòng trắng trứng bằng ba thuốc thử](nhan-biet.svg)

Nguyên tắc giống chương 2: dùng thuốc thử **chia nhóm** trước (quỳ tím), rồi dùng thuốc thử **có hiện tượng riêng** cho từng nhóm (biuret, nước bromine). Mỗi bước lấy **mẫu mới**.

> [!bay] Thuốc thử "vô dụng"
> - **HCl** không phân biệt được amine, amino acid (đều phản ứng, không có hiện tượng rõ).
> - **Quỳ tím** không tách được aniline với glycine (đều không đổi màu).
> - **Cu(OH)~2~/NaOH** không tách được dipeptide với amino acid (đều không có màu tím).

## 5. Lỗi sai hay gặp của cả chương

**Về khái niệm, cấu tạo**

- Lấy bậc của nguyên tử C để tính bậc amine. Bậc amine là **số gốc hydrocarbon gắn vào N**.
- Gọi benzylamine C~6~H~5~CH~2~NH~2~ là arylamine (N không gắn thẳng vào vòng → alkylamine).
- Nói "mọi amino acid đều là α-amino acid" (6-aminohexanoic acid là ε-amino acid).
- Đánh số tên thay thế: **C của –COOH là C1**, nên α ứng với số **2** (không phải 1).
- Nhầm Gly (glycine) với Glu (glutamic acid).
- Đếm tetrapeptide có 4 liên kết peptide (đúng là **3**). Insulin hai chuỗi 21 và 30 gốc có 20 + 29 = 49 liên kết, không phải 50.
- Coi liên kết –CO–NH– trong capron hay giữa β-amino acid là liên kết peptide.
- Coi Ala-Gly và Gly-Ala là cùng một chất.

**Về tính chất**

- Cho aniline làm quỳ tím hoá xanh, hoặc nói "aniline không có tính base".
- Cho rằng amine bậc hai, bậc ba cũng giải phóng N~2~ với HNO~2~ ở nhiệt độ thường.
- Viết kết tủa với nước bromine là monobromoaniline, hoặc cho benzene cũng làm mất màu nước bromine.
- Nói amino acid là chất lỏng, dễ bay hơi, có mùi như amine.
- Nhầm chiều điện di: **cation về cực âm**, anion về cực dương. Phải so pH với **pI**, không so với 7.
- Cho dipeptide có phản ứng màu biuret.
- Nói protein + Cu(OH)~2~ tạo dung dịch xanh lam (đúng là **màu tím**).
- Nói đông tụ là do liên kết peptide bị cắt (đó là thuỷ phân).
- Nói "protein tan tốt trong nước" mà không xét dạng sợi hay dạng hình cầu.
- Nói "enzyme hoạt động càng mạnh khi nhiệt độ càng cao".

**Về tính toán**

- Trừ 18 khi tính muối amine + HCl (phản ứng này **không tạo nước**).
- Quên Lys có **2** nhóm –NH~2~, Glu có **2** nhóm –COOH khi tính số mol HCl, NaOH.
- Bài hai giai đoạn: quên NaOH phải trung hoà cả **HCl đã cho vào trước**.
- Tính M(peptide) quên trừ 18(n − 1), hoặc quên lượng nước **lấy vào** khi thuỷ phân trong HCl.
- Cô cạn sau thuỷ phân trong NaOH **dư**: quên cộng khối lượng NaOH dư vào chất rắn.
- Dùng M(amino acid) thay cho M(gốc) khi tính % khối lượng gốc trong protein.
- Quên hệ số 3 của Br~2~, hoặc lấy M(kết tủa) = 333 thay vì 330.

## 6. Bài tập tổng hợp

Các ví dụ dưới đây phối hợp kiến thức của nhiều bài. Hãy tự làm trước, bí thì mở từng gợi ý.

### 6.1. Đếm số chất thoả mãn tính chất

> [!vi-du] Ví dụ 1
> Cho các chất: methylamine, aniline, glycine, lysine, glutamic acid, Gly-Ala, Gly-Ala-Val, albumin (lòng trắng trứng).
>
> a) Có bao nhiêu chất tác dụng được với dung dịch NaOH (đun nóng nếu cần)?
>
> b) Có bao nhiêu chất có phản ứng màu biuret?
>
> c) Trong năm chất đầu, có bao nhiêu chất mà dung dịch của nó làm quỳ tím hoá xanh?
>
> d) Có bao nhiêu chất tạo kết tủa trắng với nước bromine?

> [!goi-y] Gợi ý 1
> Gắn mỗi câu hỏi với **một đặc điểm cấu tạo**: (a) có –COOH hoặc có liên kết peptide bị thuỷ phân; (b) có từ 2 liên kết peptide; (c) dư nhóm base; (d) vòng benzene gắn –NH~2~.

> [!goi-y] Gợi ý 2
> Amine không có nhóm –COOH. Gly-Ala có mấy liên kết peptide?

> [!loi-giai] Lời giải
> a) Glycine, lysine, glutamic acid (có –COOH), Gly-Ala, Gly-Ala-Val, albumin (thuỷ phân trong kiềm) → **6** chất. Methylamine và aniline không tác dụng với NaOH.
>
> b) Gly-Ala-Val (2 liên kết peptide) và albumin → **2** chất. Gly-Ala chỉ có 1 liên kết peptide.
>
> c) Methylamine và lysine (2 nhóm –NH~2~, 1 nhóm –COOH) → **2** chất. Aniline, glycine không đổi màu quỳ, glutamic acid làm quỳ hoá đỏ.
>
> d) Chỉ aniline → **1** chất.

### 6.2. Hỗn hợp amine và amino acid với HCl, NaOH

**Phương pháp:** đặt ẩn số mol mỗi chất. **HCl** tác dụng với **mọi nhóm –NH~2~** (cả amine và amino acid). **NaOH** chỉ tác dụng với **nhóm –COOH** (amine không phản ứng). Hai phương trình số mol cho ngay hai ẩn.

> [!vi-du] Ví dụ 2
> Hỗn hợp X gồm glycine và methylamine. Cho m gam X tác dụng vừa đủ với 200 mL dung dịch HCl 1 M. Mặt khác, m gam X tác dụng vừa đủ với 120 mL dung dịch NaOH 1 M.
>
> a) Tính m.
>
> b) Tính khối lượng muối thu được khi cho m gam X tác dụng với HCl.
>
> c) Tính phần trăm khối lượng glycine trong X.

> [!goi-y] Gợi ý 1
> Chất nào trong X tác dụng với NaOH? Từ đó suy ra ngay số mol của chất đó.

> [!goi-y] Gợi ý 2
> Mỗi chất có 1 nhóm –NH~2~, nên n(HCl) = n(glycine) + n(methylamine). Muối với HCl không kèm nước.

> [!loi-giai] Lời giải
> Chỉ glycine tác dụng với NaOH → n(Gly) = n(NaOH) = 0,12 mol.
>
> n(HCl) = n(Gly) + n(CH~3~NH~2~) = 0,2 → n(CH~3~NH~2~) = 0,08 mol.
>
> a) m = 0,12 · 75 + 0,08 · 31 = 9 + 2,48 = **11,48 g**.
>
> b) m(muối) = 11,48 + 0,2 · 36,5 = **18,78 g**.
>
> c) %m(Gly) = 9 : 11,48 · 100% ≈ **78,4%**.

### 6.3. Bài hai giai đoạn: HCl trước, NaOH sau

> [!vi-du] Ví dụ 3
> Cho 16,2 g hỗn hợp E gồm alanine và lysine tác dụng vừa đủ với 200 mL dung dịch HCl 1 M, thu được dung dịch Y.
>
> a) Tính phần trăm khối lượng lysine trong E.
>
> b) Cho Y tác dụng vừa đủ với dung dịch NaOH. Tính số mol NaOH đã phản ứng và khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> Lysine có **2** nhóm –NH~2~. Lập hệ: 89a + 146b = 16,2 và a + 2b = 0,2.

> [!goi-y] Gợi ý 2
> Coi như NaOH tác dụng với **HCl** và với **các nhóm –COOH** của amino acid ban đầu. Muối cuối gồm NaCl và muối natri của hai amino acid.

> [!loi-giai] Lời giải
> Gọi a, b là số mol alanine, lysine: 89a + 146b = 16,2 và a + 2b = 0,2 → a = 0,1; b = 0,05.
>
> a) %m(Lys) = 0,05 · 146 : 16,2 · 100% = 7,3 : 16,2 · 100% ≈ **45,1%**.
>
> b) n(NaOH) = n(HCl) + n(–COOH) = 0,2 + (0,1 + 0,05) = **0,35 mol**.
>
> Muối gồm: NaCl 0,2 mol; H~2~N–CH(CH~3~)–COONa 0,1 mol (M = 111); muối natri của lysine 0,05 mol (M = 168).
>
> m(muối) = 0,2 · 58,5 + 0,1 · 111 + 0,05 · 168 = 11,7 + 11,1 + 8,4 = **31,2 g**.
>
> Kiểm tra bằng bảo toàn khối lượng: 16,2 + 7,3 + 0,35 · 40 − 0,35 · 18 = 31,2 g ✓ (mỗi NaOH phản ứng tạo một H~2~O).

> [!bay]
> Nếu chỉ tính NaOH phản ứng với amino acid (0,15 mol) là sai. HCl đã "nằm" trong muối ClH~3~N–…, nhưng gặp NaOH nó vẫn bị trung hoà, tạo NaCl.

### 6.4. Thuỷ phân peptide trong NaOH dư

> [!vi-du] Ví dụ 4
> Cho 12,25 g tripeptide Gly-Ala-Val vào dung dịch NaOH lấy dư 20% so với lượng cần phản ứng, đun nóng đến khi phản ứng hoàn toàn. Cô cạn dung dịch sau phản ứng.
>
> a) Gly-Ala-Val có phản ứng màu biuret không? Vì sao?
>
> b) Tính khối lượng chất rắn khan thu được.

> [!goi-y] Gợi ý 1
> M(Gly-Ala-Val) = 75 + 89 + 117 − 2 · 18. Tripeptide có 3 gốc, mỗi gốc 1 nhóm –COOH → cần bao nhiêu NaOH?

> [!goi-y] Gợi ý 2
> Chất rắn = 3 muối natri + **NaOH dư** (NaOH không bay hơi khi cô cạn). Hoặc dùng bảo toàn khối lượng: chỉ có 1 H~2~O tạo ra cho mỗi phân tử tripeptide.

> [!loi-giai] Lời giải
> a) **Có**: tripeptide có 2 liên kết peptide nên tạo phức màu tím với Cu(OH)~2~ trong môi trường kiềm.
>
> b) M = 75 + 89 + 117 − 36 = 245 → n = 12,25 : 245 = 0,05 mol.
>
> n(NaOH) cần = 3 · 0,05 = 0,15 mol; lấy dư 20% → n(NaOH) đã dùng = 0,18 mol, dư 0,03 mol.
>
> Muối: 0,05 · (97 + 111 + 139) = 17,35 g. NaOH dư: 0,03 · 40 = 1,2 g.
>
> m(chất rắn) = 17,35 + 1,2 = **18,55 g**.
>
> Kiểm tra: 12,25 + 0,18 · 40 − 0,05 · 18 = 18,55 g ✓.

### 6.5. Nhận biết và thí nghiệm (Đúng/Sai)

> [!vi-du] Ví dụ 5 (Đúng/Sai)
> Có bốn lọ mất nhãn, mỗi lọ chứa một dung dịch: methylamine, aniline, glycine, lòng trắng trứng. Một nhóm học sinh đưa ra các nhận định:
>
> a) Dùng quỳ tím nhận ra được lọ methylamine.
>
> b) Dùng Cu(OH)~2~ trong môi trường kiềm nhận ra được lọ lòng trắng trứng nhờ màu tím.
>
> c) Đun nóng từng lọ thì cả lọ glycine và lọ lòng trắng trứng đều có chất rắn tách ra.
>
> d) Sau khi nhận ra hai lọ trên, dùng nước bromine sẽ phân biệt được aniline với glycine.

> [!goi-y] Gợi ý 1
> Viết hiện tượng của **từng** chất với mỗi thuốc thử. Thuốc thử chỉ dùng được khi hiện tượng **khác nhau**.

> [!goi-y] Gợi ý 2
> Đông tụ khi đun nóng là tính chất của phân tử có hình dạng không gian phức tạp. Glycine có không?

> [!loi-giai] Lời giải
> a) **Đúng**: chỉ methylamine làm quỳ hoá xanh, ba lọ còn lại không đổi màu.
>
> b) **Đúng**: protein có phản ứng biuret. Aniline, glycine không cho màu tím.
>
> c) **Sai**: chỉ protein bị đông tụ khi đun nóng. Glycine là amino acid, đun dung dịch không có chất rắn tách ra.
>
> d) **Đúng**: aniline cho kết tủa trắng 2,4,6-tribromoaniline, glycine thì không.
>
> Toàn bộ quy trình được vẽ ở Hình 2.

## 7. Đối chiếu bài tập SGK (tr. 50)

**Câu 1 (đếm amine bậc hai).** Làm theo cách "chia số C cho các gốc quanh N" (Bài 8, mục 1.3): bậc hai là chia số C thành **2 gốc**, mỗi gốc ít nhất 1 C, nhớ gốc C~3~ có hai dạng (propyl, isopropyl). Em tự làm với C~3~H~9~N rồi đối chiếu kết quả "C~3~H~9~N có 4 đồng phân" ở Bài 8. Bài cùng dạng với C~4~H~11~N: Ví dụ 2 của Bài 8.

**Câu 2 (bốn phát biểu về amine).** Mỗi phát biểu ứng với một hàng của bảng 2.1 và bảng so sánh 2.2. Khi soát, nhớ: aniline **không** đổi màu quỳ; methylamine với Cu^2+^ là "kết tủa xanh rồi tan thành xanh lam"; methylamine với FeCl~3~ là **kết tủa nâu đỏ**; aniline với nước bromine là **kết tủa trắng**.

**Câu 3 (phát biểu không đúng về protein).** Soát bốn từ khoá của protein: thuỷ phân → α-amino acid; biuret → **tím** (không phải xanh lam); đông tụ bởi nhiệt, acid, base, ion kim loại nặng; HNO~3~ đặc → rắn vàng.

**Câu 4 (viết phương trình).** Bài tương tự:

> [!vi-du] Ví dụ 6
> Viết phương trình hoá học khi cho: (a) dung dịch ethylamine vào dung dịch HCl; (b) dung dịch valine vào dung dịch NaOH; (c) dung dịch Ala-Gly vào dung dịch HCl dư, đun nóng.

> [!goi-y] Gợi ý 1
> (a) amine nhận H^+^, không tạo nước. (b) H của –COOH được thay bằng Na, tạo nước.

> [!goi-y] Gợi ý 2
> (c) Liên kết peptide bị cắt (lấy 1 H~2~O), rồi **mỗi** amino acid sinh ra nhận 1 HCl.

> [!loi-giai] Lời giải
> => C~2~H~5~NH~2~ + HCl → C~2~H~5~NH~3~Cl
>
> => (CH~3~)~2~CH–CH(NH~2~)–COOH + NaOH → (CH~3~)~2~CH–CH(NH~2~)–COONa + H~2~O
>
> => Ala-Gly + H~2~O + 2HCl → ClH~3~N–CH(CH~3~)–COOH + ClH~3~N–CH~2~–COOH

**Câu 5 (thuỷ phân không hoàn toàn tetrapeptide).** Mỗi mảnh là một **đoạn liên tiếp** của chuỗi, giữ nguyên thứ tự. Bài tương tự:

> [!vi-du] Ví dụ 7
> Thuỷ phân không hoàn toàn tetrapeptide Val-Ala-Gly-Lys. Có thể thu được những dipeptide và tripeptide nào? Dipeptide Ala-Val có thể có trong sản phẩm không?

> [!goi-y] Gợi ý 1
> Tetrapeptide có 3 liên kết peptide. Dipeptide là hai gốc **đứng cạnh nhau**, đọc từ trái sang phải.

> [!goi-y] Gợi ý 2
> Tripeptide là ba gốc liên tiếp: bắt đầu từ gốc 1 hoặc gốc 2.

> [!loi-giai] Lời giải
> Dipeptide: **Val-Ala, Ala-Gly, Gly-Lys** (3 chất).
>
> Tripeptide: **Val-Ala-Gly, Ala-Gly-Lys** (2 chất).
>
> Ala-Val **không** thể có: trong chuỗi, Ala đứng **sau** Val. Đảo thứ tự là một chất khác.

## Tóm tắt

| | Amine | Amino acid | Peptide | Protein |
|---|---|---|---|---|
| Nhóm đặc trưng | –NH~2~, –NH–, hoặc N gắn 3 gốc | –NH~2~ và –COOH | –CO–NH– giữa α-amino acid | nhiều chuỗi polypeptide |
| Trạng thái | ít C: khí; aniline: lỏng | rắn, tan tốt | — | sợi: không tan; cầu: keo |
| Quỳ tím | alkylamine: xanh; aniline: không | Gly, Ala, Val: không; Lys: xanh; Glu: đỏ | — | — |
| HCl / NaOH | có / không | có / có | thuỷ phân / thuỷ phân | thuỷ phân / thuỷ phân |
| Phản ứng riêng | aniline + Br~2~ → ↓ trắng; bậc một + HNO~2~ → N~2~ | điện di; ester hoá; ε-, ω- trùng ngưng | biuret tím (từ tripeptide) | biuret tím; HNO~3~ → vàng; đông tụ |

**Bốn bước giải bài toán của chương:**

1. Viết đúng **số nhóm** –NH~2~, –COOH của từng chất (Lys 2 –NH~2~, Glu 2 –COOH; amine không có –COOH).
2. **HCl** cộng vào nhóm –NH~2~ không tạo nước; **NaOH** thế H của –COOH tạo nước.
3. Bài nhiều giai đoạn: n(NaOH) = n(HCl) + n(–COOH). Cô cạn thì nhớ NaOH dư, NaCl.
4. Peptide: M = ΣM − 18(n − 1). Thuỷ phân không hoàn toàn: **bảo toàn số gốc** từng loại amino acid.
