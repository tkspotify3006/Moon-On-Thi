---
title: Giới thiệu về carbohydrate. Glucose và fructose
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm carbohydrate, công thức chung thường gặp C~n~(H~2~O)~m~ và cách phân loại thành monosaccharide, disaccharide, polysaccharide.
  - Viết được công thức cấu tạo dạng mạch hở và dạng mạch vòng (α, β) của glucose, fructose; chỉ ra nhóm –OH hemiacetal (glucose), –OH hemiketal (fructose).
  - Trình bày được tính chất hoá học của glucose, fructose: tính chất polyalcohol (với Cu(OH)~2~), tính chất aldehyde (với Cu(OH)~2~/OH^−^ khi đun nóng, thuốc thử Tollens, nước bromine), phản ứng của nhóm –OH hemiacetal với CH~3~OH/HCl khan, phản ứng lên men.
  - Mô tả hiện tượng và giải thích được các thí nghiệm của glucose với Cu(OH)~2~, thuốc thử Tollens, nước bromine.
  - Nêu được trạng thái tự nhiên, tính chất vật lí, ứng dụng của glucose, fructose; giải được bài toán nhận biết, tráng bạc, lên men.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Carbohydrate** là hợp chất hữu cơ **tạp chức**, thường có công thức chung **C~n~(H~2~O)~m~**. Chia 3 loại: **monosaccharide** (không thuỷ phân), **disaccharide** (thuỷ phân → 2 monosaccharide), **polysaccharide** (thuỷ phân → nhiều monosaccharide).
> 2. **Glucose** và **fructose** là đồng phân, cùng công thức **C~6~H~12~O~6~**. Mạch hở: glucose có **5 –OH + 1 nhóm –CHO**; fructose có **5 –OH + 1 nhóm C=O (ketone)** ở C2.
> 3. Trong dung dịch, cả hai tồn tại chủ yếu ở **dạng mạch vòng α, β**. Glucose có –OH **hemiacetal** ở **C1** (vòng 6 cạnh); fructose có –OH **hemiketal** ở **C2** (vòng 5 cạnh).
> 4. Cả hai: hoà tan Cu(OH)~2~ → **xanh lam**; **tráng bạc**; khử Cu(OH)~2~/OH^−^ khi đun nóng → **Cu~2~O đỏ gạch**. Chỉ **glucose** làm **mất màu nước bromine**. Glucose (dạng vòng) còn tạo methyl glucoside với CH~3~OH/HCl khan.
> 5. Lên men: C~6~H~12~O~6~ → **2C~2~H~5~OH + 2CO~2~**. Tráng bạc: 1 C~6~H~12~O~6~ → **2Ag**. Hoà tan Cu(OH)~2~: **2** C~6~H~12~O~6~ : **1** Cu(OH)~2~.

## 1. Khái niệm và phân loại carbohydrate

### 1.1. Khái niệm

Cơm em ăn (tinh bột), đường trong ly nước mía (saccharose), vị ngọt của nho chín (glucose), sợi bông của áo (cellulose)… đều thuộc **một họ chất**: carbohydrate. Chương 2 sẽ đi lần lượt từ chất nhỏ nhất (glucose, fructose) đến các chất "khổng lồ" (tinh bột, cellulose).

Nhìn vào công thức cấu tạo mạch hở của glucose:

=> CH~2~OH–CHOH–CHOH–CHOH–CHOH–CH=O

em thấy phân tử có **nhiều nhóm hydroxy (–OH)** và **một nhóm aldehyde (–CH=O)**. Có hai loại nhóm chức khác nhau, nên glucose là hợp chất **tạp chức**. Fructose cũng vậy: nhiều nhóm –OH và một nhóm ketone (C=O).

> [!ghi-nho] Khái niệm
> **Carbohydrate** là những hợp chất hữu cơ **tạp chức**, thường có công thức chung **C~n~(H~2~O)~m~**.

**Vì sao lại là C~n~(H~2~O)~m~?** Thử viết lại công thức một vài chất: C~6~H~12~O~6~ = C~6~(H~2~O)~6~; C~12~H~22~O~11~ = C~12~(H~2~O)~11~. Trông như "carbon + nước", nên người xưa đặt tên là carbo-**hydrate** (hydrate là "ngậm nước"). Thật ra trong phân tử **không hề có phân tử nước**: các nguyên tử H và O nằm trong các nhóm –OH, –CHO… Cái tên vẫn được dùng vì đã quen.

> [!em-co-biet] Saccharide, glucide
> Carbohydrate còn được gọi là **saccharide** (gốc Hy Lạp, nghĩa là "đường") hoặc **glucide**. Vì thế tên nhiều chất trong chương này có đuôi "-saccharide" hoặc "-ose" (glucose, saccharose, cellulose…).

> [!bay] "Thường có", không phải "luôn luôn"
> - Có chất viết được dạng C~n~(H~2~O)~m~ nhưng **không phải** carbohydrate. Ví dụ acetic acid CH~3~COOH = C~2~(H~2~O)~2~, formaldehyde HCHO = C(H~2~O). Chúng chỉ có một loại nhóm chức.
> - Câu Đúng/Sai "Mọi chất có công thức C~n~(H~2~O)~m~ đều là carbohydrate" là **sai**.

### 1.2. Phân loại

Cách chia dựa vào **phản ứng thuỷ phân**, tức là phân tử có "cắt nhỏ" được thành các đơn vị đường đơn giản hơn hay không (SGK tr. 21).

![Hình 1. Phân loại carbohydrate theo phản ứng thuỷ phân](phan-loai.svg)

| Loại | Thuỷ phân hoàn toàn 1 phân tử cho | Ví dụ | Công thức |
|---|---|---|---|
| **Monosaccharide** | không bị thuỷ phân | glucose, fructose | C~6~H~12~O~6~ |
| **Disaccharide** | **2** phân tử monosaccharide | saccharose, maltose (Bài 5) | C~12~H~22~O~11~ |
| **Polysaccharide** | **nhiều** phân tử monosaccharide | tinh bột, cellulose (Bài 6) | (C~6~H~10~O~5~)~n~ |

Hãy hình dung monosaccharide như **một viên gạch**. Disaccharide là **hai viên gạch dính nhau**, polysaccharide là **cả bức tường**. Thuỷ phân là gỡ tường ra thành từng viên. Còn một viên gạch thì không gỡ thêm được nữa.

> [!vi-du] Ví dụ 1
> Cho các chất: glucose, saccharose, cellulose, fructose, maltose, tinh bột.
>
> a) Xếp các chất vào ba loại monosaccharide, disaccharide, polysaccharide.
>
> b) Viết công thức phân tử của saccharose và của tinh bột dưới dạng C~n~(H~2~O)~m~.

> [!goi-y] Gợi ý 1
> Chất nào không bị thuỷ phân? Chất nào thuỷ phân cho đúng 2 phân tử, chất nào cho rất nhiều phân tử monosaccharide?

> [!goi-y] Gợi ý 2
> Với (C~6~H~10~O~5~)~n~: mỗi mắt xích có 6 C và 5 "H~2~O". Nhân với n.

> [!loi-giai] Lời giải
> a) Monosaccharide: glucose, fructose. Disaccharide: saccharose, maltose. Polysaccharide: tinh bột, cellulose.
>
> b) Saccharose C~12~H~22~O~11~ = C~12~(H~2~O)~11~. Tinh bột (C~6~H~10~O~5~)~n~ = C~6n~(H~2~O)~5n~.

## 2. Cấu tạo phân tử glucose và fructose

### 2.1. Glucose

**a) Dạng mạch hở**

Glucose có công thức phân tử **C~6~H~12~O~6~**. Ở dạng mạch hở, 6 nguyên tử C nối thành **mạch thẳng, không nhánh**. Nguyên tử C1 thuộc nhóm **aldehyde –CH=O**. Năm nguyên tử C còn lại (C2 đến C6) **mỗi C mang một nhóm –OH**. Công thức cấu tạo viết gọn:

=> CH~2~OH[CHOH]~4~CH=O

Vậy glucose mạch hở có **5 nhóm hydroxy và 1 nhóm aldehyde**. Glucose là một **aldohexose** ("aldo" vì có nhóm aldehyde, "hexose" vì có 6 C).

> [!nen-tang] Nhóm chức đã học ở lớp 11
> - **Alcohol** có nhóm –OH. Alcohol có **nhiều nhóm –OH kề nhau** (như glycerol, ethylene glycol) hoà tan được Cu(OH)~2~ tạo dung dịch xanh lam.
> - **Aldehyde** có nhóm –CHO, có **tính khử**: bị thuốc thử Tollens oxi hoá (tạo Ag), bị Cu(OH)~2~/OH^−^ oxi hoá khi đun nóng (tạo Cu~2~O đỏ gạch), làm mất màu nước bromine.
> - **Ketone** có nhóm C=O nằm giữa mạch (nối với hai gốc carbon). Ketone **không** tráng bạc.

**b) Dạng mạch vòng**

Các nghiên cứu cho thấy glucose **không chỉ** có dạng mạch hở. Trong dung dịch, glucose chủ yếu tồn tại ở **hai dạng mạch vòng 6 cạnh**, gọi là **α-glucose** và **β-glucose**. Ba dạng (hở, α, β) **chuyển hoá qua lại** liên tục (SGK tr. 21).

![Hình 2. Glucose: dạng mạch hở chuyển hoá qua lại với hai dạng mạch vòng α, β. Vòng vẽ theo kiểu Haworth (nét đậm là cạnh gần người xem), bỏ các nguyên tử H gắn vào C vòng; SGK vẽ dạng phối cảnh gần dạng ghế (tr. 21)](glucose.svg)

**Vòng được tạo ra như thế nào?** Mạch carbon không thẳng đơ mà uốn cong được. Khi uốn, nhóm **–OH ở C5** tiến sát tới nhóm **C=O ở C1**. Nguyên tử O của nhóm –OH này "bắt" vào C1. Đồng thời liên kết đôi C=O mở ra, nguyên tử O của nó nhận H và trở thành một nhóm –OH mới gắn ở C1. Kết quả:

- Vòng gồm **5 nguyên tử C (C1 → C5) và 1 nguyên tử O**. Nguyên tử O trong vòng chính là O của nhóm –OH ở **C5** (màu xanh trong Hình 2), **không phải** O của nhóm –CHO.
- C1 mang một nhóm –OH mới, gọi là **nhóm –OH hemiacetal** (màu cam). Nhóm này khác 4 nhóm –OH còn lại: nó gắn vào C đồng thời liên kết với O trong vòng, nên hoạt động hơn hẳn.
- Phản ứng khép vòng là **thuận nghịch**: vòng mở ra thì nhóm –CHO xuất hiện trở lại.

**α và β khác nhau ở đâu?** Khi khép vòng, nhóm –OH mới ở C1 có thể nằm **phía dưới** hoặc **phía trên** mặt phẳng vòng. Trên hình vẽ Haworth (nhóm CH~2~OH ở C5 hướng lên):

- **α-glucose**: –OH hemiacetal hướng **xuống**, khác phía với nhóm CH~2~OH.
- **β-glucose**: –OH hemiacetal hướng **lên**, cùng phía với nhóm CH~2~OH.

Các nhóm –OH ở C2, C3, C4 thì giống nhau ở cả hai dạng: C2 xuống, C3 lên, C4 xuống.

> [!meo] Nhớ hướng các nhóm –OH của glucose
> Đi từ C1 đến C4 của **β-glucose**: **lên – xuống – lên – xuống**, so le đều nhau như răng cưa. Dạng **α** chỉ khác ở C1 ("đảo" nhóm đầu tiên xuống dưới). Câu nhớ nhanh: "**α** – **a**nh ở dưới, **β** – **b**ên trên".

> [!em-co-biet] Trong cốc nước đường
> Ở dung dịch glucose, khoảng 36% phân tử ở dạng α, khoảng 64% ở dạng β, dạng mạch hở chỉ chiếm chưa tới 1%. Dù dạng mạch hở rất ít, khi nó bị tiêu thụ trong phản ứng (ví dụ tráng bạc), cân bằng chuyển dịch, vòng lại mở ra bù vào. Nhờ đó toàn bộ glucose vẫn phản ứng hết.

> [!vi-du] Ví dụ 2
> Trả lời các câu hỏi về phân tử glucose:
>
> a) Ở dạng mạch hở và ở dạng mạch vòng, phân tử glucose có bao nhiêu nhóm –OH?
>
> b) Nhóm –OH hemiacetal gắn vào nguyên tử C số mấy? Nguyên tử O trong vòng có nguồn gốc từ nhóm chức nào của dạng mạch hở?
>
> c) Tính phần trăm khối lượng carbon trong glucose.

> [!goi-y] Gợi ý 1
> Khi khép vòng, nhóm –OH ở C5 "mất" vào vòng, nhưng nhóm C=O ở C1 lại "biến" thành một nhóm –OH mới.

> [!goi-y] Gợi ý 2
> M(C~6~H~12~O~6~) = 6·12 + 12·1 + 6·16.

> [!loi-giai] Lời giải
> a) Mạch hở: **5** nhóm –OH (ở C2 → C6) và 1 nhóm –CHO. Mạch vòng: vẫn **5** nhóm –OH (ở C1, C2, C3, C4, C6), trong đó nhóm ở C1 là –OH hemiacetal. Không có nhóm –CHO.
>
> b) Nhóm –OH hemiacetal gắn vào **C1**. Nguyên tử O trong vòng có nguồn gốc từ nhóm **–OH ở C5**.
>
> c) M = 180. %C = 72 : 180 · 100% = **40%**.

### 2.2. Fructose

Fructose cũng có công thức phân tử **C~6~H~12~O~6~**, nên fructose là **đồng phân** của glucose. Điểm khác: nhóm C=O nằm ở **C2** (giữa mạch), là nhóm **ketone**. Công thức mạch hở:

=> CH~2~OH[CHOH]~3~–CO–CH~2~OH

Fructose mạch hở có **5 nhóm hydroxy và 1 nhóm ketone**. Fructose là một **ketohexose**.

Fructose cũng khép vòng giống glucose: nhóm –OH ở **C5** cộng vào nhóm C=O ở **C2**. Lần này vòng chỉ có **5 cạnh** (4 C và 1 O), vì đếm từ C2 đến C5 chỉ có 4 nguyên tử C. Nhóm –OH mới sinh ra ở C2 gọi là **–OH hemiketal** (vì nó sinh ra từ nhóm ketone). Tương tự glucose có **α-fructose** (–OH hemiketal hướng xuống) và **β-fructose** (hướng lên). Nguyên tử C1 không nằm trong vòng mà là nhóm CH~2~OH gắn vào C2.

![Hình 3. Fructose: dạng mạch hở và hai dạng mạch vòng 5 cạnh α, β](fructose.svg)

| | Glucose | Fructose |
|---|---|---|
| Công thức phân tử | C~6~H~12~O~6~ | C~6~H~12~O~6~ |
| Nhóm chức (mạch hở) | 5 –OH + 1 **–CHO** (ở C1) | 5 –OH + 1 **C=O ketone** (ở C2) |
| Vòng | **6 cạnh** (5 C + 1 O) | **5 cạnh** (4 C + 1 O) |
| Nhóm –OH đặc biệt | –OH **hemiacetal** ở **C1** | –OH **hemiketal** ở **C2** |
| Các dạng | mạch hở ⇌ α ⇌ β | mạch hở ⇌ α ⇌ β |

### 2.3. Glucose và fructose chuyển hoá qua lại trong môi trường kiềm

Trong môi trường **kiềm** (có ion OH^−^), glucose và fructose có thể chuyển hoá thành nhau:

=> Glucose ⇌ Fructose    (OH^−^)

Điều này rất quan trọng để giải thích vì sao **fructose có nhóm ketone mà vẫn tráng bạc được** (mục 3.2). Thuốc thử Tollens và Cu(OH)~2~/NaOH đều có môi trường kiềm. Trong đó, fructose chuyển dần thành glucose, và glucose bị oxi hoá.

> [!bay] Ba lỗi hay gặp về cấu tạo
> - "Glucose chỉ tồn tại ở dạng mạch hở": **sai**. Trong dung dịch, glucose tồn tại chủ yếu ở dạng mạch vòng.
> - "O trong vòng glucose là O của nhóm –CHO": **sai**. Đó là O của nhóm –OH ở C5. O của nhóm –CHO trở thành O của nhóm –OH hemiacetal.
> - "Vòng fructose 6 cạnh giống glucose": **sai**. Fructose (trong SGK) có vòng **5 cạnh**, –OH hemiketal ở **C2**.

## 3. Tính chất hoá học

Muốn đoán tính chất, hãy nhìn nhóm chức (SGK tr. 22):

- **Nhiều nhóm –OH kề nhau** → tính chất **polyalcohol** (cả glucose và fructose).
- **Nhóm –CHO** (dạng mạch hở) → tính chất **aldehyde** (glucose). Fructose có nhóm ketone, nhưng vẫn có một số phản ứng giống aldehyde nhờ chuyển hoá thành glucose trong kiềm.
- **Nhóm –OH hemiacetal** (dạng mạch vòng) → phản ứng riêng với CH~3~OH/HCl khan.
- Ngoài ra, glucose còn bị **lên men** nhờ enzyme.

### 3.1. Tính chất polyalcohol: hoà tan Cu(OH)~2~

**Thí nghiệm** (SGK tr. 22, tóm tắt): cho dung dịch NaOH vào ống nghiệm, thêm vài giọt dung dịch CuSO~4~ thì có **kết tủa xanh** Cu(OH)~2~. Thêm dung dịch glucose rồi lắc ở **nhiệt độ thường**: kết tủa tan, dung dịch có màu **xanh lam**.

=> CuSO~4~ + 2NaOH → Cu(OH)~2~↓ + Na~2~SO~4~

=> 2C~6~H~12~O~6~ + Cu(OH)~2~ → (C~6~H~11~O~6~)~2~Cu + 2H~2~O

**Vì sao?** Hai nhóm –OH **kề nhau** trên hai C liền kề cùng "kẹp" lấy ion Cu^2+^, tạo phức chất tan, có màu xanh lam. Đây chính là phản ứng của glycerol mà em đã học ở lớp 11. Mỗi phân tử glucose thay 1 nguyên tử H bằng "nửa" nguyên tử Cu, nên **2 phân tử glucose** kết hợp với **1 Cu(OH)~2~**.

Fructose cũng có nhiều nhóm –OH kề nhau, nên cũng hoà tan Cu(OH)~2~ tạo dung dịch xanh lam.

> [!vi-du] Ví dụ 3
> Dung dịch chứa 36 g glucose hoà tan được tối đa bao nhiêu gam Cu(OH)~2~ ở nhiệt độ thường?

> [!goi-y] Gợi ý 1
> Tính n(glucose), rồi dùng tỉ lệ trong phương trình: 2 glucose : 1 Cu(OH)~2~.

> [!loi-giai] Lời giải
> n(glucose) = 36 : 180 = 0,2 mol → n(Cu(OH)~2~) = 0,2 : 2 = 0,1 mol.
>
> m(Cu(OH)~2~) = 0,1 · 98 = **9,8 g**.

### 3.2. Tính chất aldehyde

Nhóm –CHO của glucose dễ bị oxi hoá thành nhóm –COOH (hoặc muối –COO^−^). Vì vậy glucose có **tính khử**. SGK giới thiệu ba chất oxi hoá (SGK tr. 22–23).

**a) Oxi hoá bằng Cu(OH)~2~ trong môi trường kiềm, đun nóng**

Lấy ống nghiệm có dung dịch xanh lam ở thí nghiệm 3.1, **đun nóng**. Màu xanh lam mất dần, xuất hiện **kết tủa đỏ gạch** Cu~2~O.

=> CH~2~OH[CHOH]~4~CH=O + 2Cu(OH)~2~ + NaOH → CH~2~OH[CHOH]~4~COONa + Cu~2~O↓ + 3H~2~O    (t°)

Sản phẩm hữu cơ là **sodium gluconate**. Cu từ số oxi hoá +2 bị khử xuống +1 trong Cu~2~O.

> [!bay] Cùng thuốc thử, hai hiện tượng khác nhau
> - **Nhiệt độ thường**: dung dịch **xanh lam**. Đây là phản ứng của nhiều nhóm **–OH kề nhau** (tính polyalcohol), **không** phải phản ứng oxi hoá.
> - **Đun nóng** (trong kiềm): kết tủa **đỏ gạch** Cu~2~O. Đây là phản ứng **oxi hoá** nhóm –CHO (tính aldehyde).
> - Glycerol cho xanh lam nhưng đun nóng **không** tạo đỏ gạch. Đó là cách phân biệt glycerol với glucose bằng một thuốc thử.

**b) Phản ứng với thuốc thử Tollens (phản ứng tráng bạc)**

**Thuốc thử Tollens** được pha như sau: nhỏ từ từ dung dịch ammonia vào dung dịch AgNO~3~ cho đến khi kết tủa vừa tan hết. Dung dịch thu được chứa phức [Ag(NH~3~)~2~]OH. Thêm dung dịch glucose, ngâm ống nghiệm vào cốc nước nóng vài phút. Thành ống nghiệm phủ một lớp **bạc sáng như gương**.

=> CH~2~OH[CHOH]~4~CH=O + 2[Ag(NH~3~)~2~]OH → CH~2~OH[CHOH]~4~COONH~4~ + 2Ag↓ + 3NH~3~ + H~2~O    (t°)

Sản phẩm hữu cơ là **ammonium gluconate**. Ion Ag^+^ bị khử thành Ag kim loại. Tỉ lệ quan trọng nhất cho bài toán:

> [!ghi-nho] Tỉ lệ tráng bạc
> **1 mol C~6~H~12~O~6~** (glucose hoặc fructose) → **2 mol Ag**.

**c) Phản ứng với nước bromine**

Cho dung dịch glucose vào nước bromine loãng (màu vàng nâu nhạt) rồi lắc: **nước bromine mất màu**. Nhóm –CHO bị Br~2~ oxi hoá thành nhóm –COOH:

=> CH~2~OH[CHOH]~4~CH=O + Br~2~ + H~2~O → CH~2~OH[CHOH]~4~COOH + 2HBr

Sản phẩm hữu cơ là **gluconic acid**. Tỉ lệ: **1 glucose : 1 Br~2~**.

**d) Còn fructose thì sao?**

Fructose không có nhóm –CHO. Nhưng thuốc thử Tollens và Cu(OH)~2~/NaOH đều có **môi trường kiềm**. Trong kiềm, fructose chuyển hoá thành glucose (mục 2.3), rồi glucose bị oxi hoá. Kết quả: **fructose cũng tráng bạc** và **cũng khử Cu(OH)~2~ khi đun nóng** tạo Cu~2~O, với tỉ lệ y như glucose. Viết gọn cho fructose:

=> CH~2~OH[CHOH]~3~COCH~2~OH + 2[Ag(NH~3~)~2~]OH → CH~2~OH[CHOH]~4~COONH~4~ + 2Ag↓ + 3NH~3~ + H~2~O    (t°)

Còn nước bromine **không** có môi trường kiềm, nên fructose **không** chuyển thành glucose. Fructose **không làm mất màu nước bromine**. (SGK không nêu trực tiếp phản ứng của fructose với nước bromine; đây là kiến thức bổ sung nhưng rất hay gặp trong đề thi.)

> [!meo] Phân biệt glucose và fructose: dùng nước bromine
> | Thuốc thử | Glucose | Fructose |
> |---|---|---|
> | Cu(OH)~2~, nhiệt độ thường | xanh lam | xanh lam |
> | Thuốc thử Tollens, t° | kết tủa Ag | kết tủa Ag |
> | Cu(OH)~2~/OH^−^, t° | đỏ gạch Cu~2~O | đỏ gạch Cu~2~O |
> | **Nước bromine** | **mất màu** | **không hiện tượng** |
>
> Ba thuốc thử đầu cho kết quả giống nhau. Chỉ **nước bromine** tách được hai chất.

> [!vi-du] Ví dụ 4
> Cho 200 g dung dịch glucose 9% tác dụng hoàn toàn với lượng dư thuốc thử Tollens, đun nóng. Tính khối lượng Ag tạo thành.

> [!goi-y] Gợi ý 1
> Khối lượng chất tan = khối lượng dung dịch × C%.

> [!goi-y] Gợi ý 2
> 1 glucose → 2 Ag.

> [!loi-giai] Lời giải
> m(glucose) = 200 · 9% = 18 g → n(glucose) = 18 : 180 = 0,1 mol.
>
> n(Ag) = 2 · 0,1 = 0,2 mol → m(Ag) = 0,2 · 108 = **21,6 g**.

### 3.3. Tính chất của nhóm –OH hemiacetal

Ở dạng mạch vòng, nhóm **–OH hemiacetal** ở C1 hoạt động hơn hẳn 4 nhóm –OH còn lại. Khi đun glucose với **methanol** có mặt **HCl khan** (làm xúc tác), chỉ riêng nhóm –OH ở C1 bị thay bằng nhóm –OCH~3~, tách ra một phân tử nước. Sản phẩm gọi là **methyl glucoside** (SGK tr. 23).

![Hình 4. Glucose phản ứng với CH~3~OH (HCl khan): chỉ nhóm –OH hemiacetal ở C1 bị thay bằng –OCH~3~](methyl-glucoside.svg)

Từ α-glucose thu được **methyl α-glucoside**. Thực tế còn có cả methyl β-glucoside, vì vòng mở ra rồi đóng lại theo cả hai kiểu.

**Phản ứng này cho biết điều gì?**

1. Nó **chứng minh glucose có dạng mạch vòng**. Dạng mạch hở không có nhóm –OH nào "đặc biệt" như vậy.
2. Sau phản ứng, C1 bị "khoá" bởi nhóm –OCH~3~, nên **vòng không mở ra được nữa**. Methyl glucoside không còn nhóm –CHO tự do, không tráng bạc.
3. Cầu nối C1–O–C vừa tạo ra chính là kiểu **liên kết glycoside**. Ở Bài 5, em sẽ thấy nhóm –OH hemiacetal của một gốc glucose nối với nhóm –OH của một phân tử đường khác theo đúng cách này để tạo ra maltose, saccharose. Ở Bài 6, hàng nghìn gốc glucose nối với nhau như vậy thành tinh bột, cellulose.

> [!bay]
> - Phản ứng với CH~3~OH cần **HCl khan**. Có nước thì phản ứng ngược lại (thuỷ phân) chiếm ưu thế.
> - **Chỉ 1** nhóm –OH (ở C1) phản ứng, **không phải** cả 5 nhóm.

### 3.4. Phản ứng lên men

Dưới tác dụng của **enzyme** do các vi sinh vật khác nhau tiết ra, glucose bị lên men thành nhiều sản phẩm có ích (SGK tr. 23–24):

=> C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~    (enzyme; lên men rượu)

=> C~6~H~12~O~6~ → 2CH~3~CH(OH)COOH    (enzyme; lên men lactic)

- **Lên men rượu** (nhờ nấm men) cho **ethanol** và khí **CO~2~**. Đây là cơ sở làm rượu, bia, cồn sinh học. Khí CO~2~ cũng làm bột bánh mì nở xốp.
- **Lên men lactic** (nhờ vi khuẩn lactic) cho **lactic acid**. Đây là quá trình làm sữa chua, muối dưa, muối cà. Vị chua là của lactic acid.

> [!ghi-nho] Tỉ lệ lên men
> **1 glucose → 2 C~2~H~5~OH + 2 CO~2~**. Lên men lactic: **1 glucose → 2 lactic acid**.

> [!vi-du] Ví dụ 5
> Lên men 360 g glucose thành ethanol với hiệu suất 80%. Dẫn toàn bộ khí CO~2~ sinh ra vào dung dịch Ca(OH)~2~ dư.
>
> a) Tính khối lượng ethanol thu được.
>
> b) Tính khối lượng kết tủa tạo thành.

> [!goi-y] Gợi ý 1
> Đi xuôi từ glucose đến sản phẩm: lượng thực tế = lượng lí thuyết × H. Nhớ hệ số **2**.

> [!goi-y] Gợi ý 2
> Ca(OH)~2~ **dư** nên CO~2~ chỉ tạo CaCO~3~: n(CaCO~3~) = n(CO~2~).

> [!loi-giai] Lời giải
> n(glucose) = 360 : 180 = 2 mol. Glucose phản ứng thực tế = 2 · 0,8 = 1,6 mol.
>
> a) n(C~2~H~5~OH) = 2 · 1,6 = 3,2 mol → m = 3,2 · 46 = **147,2 g**.
>
> b) n(CO~2~) = 3,2 mol. CO~2~ + Ca(OH)~2~ → CaCO~3~↓ + H~2~O, nên n(CaCO~3~) = 3,2 mol → m = 3,2 · 100 = **320 g**.

## 4. Trạng thái tự nhiên, tính chất vật lí và ứng dụng

### 4.1. Glucose

**Tính chất vật lí.** Glucose là chất rắn kết tinh, không màu, **tan nhiều trong nước**, có **vị ngọt** (kém đường mía). Nó tan tốt vì có nhiều nhóm –OH tạo liên kết hydrogen với nước.

**Trạng thái tự nhiên.** Cây xanh tạo ra glucose nhờ **quang hợp**. Glucose có ở hầu hết các bộ phận của cây (lá, hoa, rễ…), nhiều nhất trong **quả chín**, đặc biệt là quả nho, nên glucose còn gọi là "đường nho". Trong **máu người**, lúc đói, nồng độ glucose của người trưởng thành khoẻ mạnh vào khoảng **4,4 – 7,2 mmol/L** (tức khoảng 80 – 130 mg/dL) (SGK tr. 24).

**Vai trò và ứng dụng.** Glucose là nguồn **cung cấp năng lượng** trực tiếp cho tế bào. Mỗi ứng dụng gắn với một tính chất:

| Ứng dụng | Dựa trên tính chất |
|---|---|
| Thực phẩm, đồ uống, bánh kẹo | vị ngọt, tan tốt, là chất dinh dưỡng |
| **Tráng gương, tráng ruột phích** | **tính khử** của nhóm –CHO (phản ứng tráng bạc) |
| Sản xuất **ethanol** | phản ứng **lên men** |
| **Dịch truyền tĩnh mạch glucose 5%** | dễ hấp thụ, cung cấp năng lượng nhanh cho người bệnh |

> [!ung-dung] Đổi đơn vị đường huyết
> Máy đo đường huyết ở Việt Nam hiện thường hiển thị mmol/L, còn nhiều tài liệu nước ngoài dùng mg/dL. Vì M(glucose) = 180 g/mol và 1 L = 10 dL, nên:
>
> 1 mmol/L = 180 mg/L = 18 mg/dL.
>
> Ví dụ: 5,4 mmol/L = 5,4 · 18 = **97,2 mg/dL**, nằm trong khoảng bình thường lúc đói.

> [!em-co-biet] Ngoài SGK: phản ứng cộng hydrogen
> Một số tài liệu tham khảo có thêm phản ứng khử glucose bằng H~2~ (xúc tác Ni, t°) tạo **sorbitol** CH~2~OH[CHOH]~4~CH~2~OH, một chất tạo ngọt dùng cho kẹo cao su. Phản ứng này **không có** trong SGK Kết nối tri thức, nhưng em có thể gặp trong đề tham khảo.

### 4.2. Fructose

**Tính chất vật lí.** Fructose là chất rắn, **dễ tan trong nước**, **vị rất ngọt** (ngọt hơn cả đường mía và glucose).

**Trạng thái tự nhiên.** Fructose có trong nhiều loại **trái cây** (táo, lựu, nho, lê…), một số **rau củ** (cà rốt, củ cải đường…), và đặc biệt nhiều trong **mật ong** (khoảng 40% khối lượng).

**Vai trò.** Giống glucose, fructose chủ yếu **cung cấp năng lượng** cho tế bào. Vì rất ngọt nên fructose (hay siro giàu fructose) được dùng nhiều trong thực phẩm, nước giải khát.

> [!ung-dung] Chọn nguồn đường hợp lí (mục "Em có thể", SGK tr. 24)
> - Đường trong **quả tươi** đi kèm chất xơ, vitamin, nước nên được hấp thụ từ từ. Nước ngọt đóng chai chứa nhiều đường tự do, hấp thụ rất nhanh.
> - Người bị **đái tháo đường** cần hạn chế đồ uống có đường, mật ong, quả quá ngọt, và nên theo dõi đường huyết theo hướng dẫn của bác sĩ.
> - Khi bị hạ đường huyết (vã mồ hôi, run tay, chóng mặt do đói), uống một cốc nước đường hoặc ăn vài viên kẹo sẽ giúp glucose vào máu nhanh.

## Dạng bài thi hay gặp

### Dạng 1. Nhận biết – phân biệt glucose, fructose và các chất đã học

**Nhận biết:** đề cho vài dung dịch mất nhãn (glucose, fructose, glycerol, ethanol, aldehyde…), hỏi thuốc thử hoặc thứ tự thuốc thử. Hoặc đề cho hiện tượng, hỏi chất.

**Phương pháp:**

1. Liệt kê nhóm chức của từng chất: nhiều –OH kề nhau? có –CHO (hoặc chuyển được thành –CHO)?
2. Dùng bảng dấu hiệu: Cu(OH)~2~ ở nhiệt độ thường → xanh lam (nhiều –OH kề nhau). Thuốc thử Tollens hoặc Cu(OH)~2~/OH^−^, t° → Ag, Cu~2~O (–CHO, cả fructose). **Nước bromine** → chỉ glucose (và aldehyde) làm mất màu.
3. Chọn thuốc thử sao cho **mỗi bước** tách được ít nhất một chất. Một thuốc thử cho cùng hiện tượng với hai chất thì không tách được hai chất đó.

> [!vi-du] Ví dụ 6
> Có 4 ống nghiệm không nhãn chứa riêng từng dung dịch: glucose, fructose, glycerol, ethanol. Hãy nêu cách nhận biết từng dung dịch.

> [!goi-y] Gợi ý 1
> Cu(OH)~2~ ở nhiệt độ thường tách được chất nào ra khỏi nhóm? (Chất nào **không** có nhiều nhóm –OH kề nhau?)

> [!goi-y] Gợi ý 2
> Ba chất còn lại đều cho xanh lam. Đun nóng: chất nào không tạo Cu~2~O? Cuối cùng, cặp glucose – fructose tách bằng thuốc thử nào?

> [!loi-giai] Lời giải
> Bước 1: cho Cu(OH)~2~ (trong NaOH) vào từng ống, lắc ở nhiệt độ thường. Ống **không** hoà tan Cu(OH)~2~ là **ethanol** (chỉ có 1 nhóm –OH). Ba ống còn lại tạo dung dịch xanh lam.
>
> Bước 2: đun nóng ba ống xanh lam. Ống **không** có kết tủa đỏ gạch là **glycerol**. Hai ống có kết tủa đỏ gạch là glucose và fructose.
>
> Bước 3: lấy mẫu mới của hai dung dịch, nhỏ vào nước bromine. Ống làm **mất màu** nước bromine là **glucose**. Ống còn lại là **fructose**.

> [!bay]
> - Dùng thuốc thử Tollens hoặc Cu(OH)~2~/OH^−^ đun nóng để phân biệt glucose với fructose là **sai**: cả hai cho cùng hiện tượng.
> - "Fructose không tráng bạc vì không có nhóm –CHO": **sai**. Trong môi trường kiềm của thuốc thử Tollens, fructose chuyển thành glucose.

### Dạng 2. Tráng bạc, khử Cu(OH)~2~, phản ứng với bromine

**Nhận biết:** đề cho khối lượng glucose/fructose (hoặc hỗn hợp, hoặc dung dịch có C%), hỏi khối lượng Ag, Cu~2~O, Br~2~… hoặc hỏi ngược.

**Phương pháp:**

1. Đổi ra mol C~6~H~12~O~6~ (M = 180). Dung dịch: m(chất tan) = m(dd) · C%.
2. Dùng tỉ lệ:
   - Tráng bạc: C~6~H~12~O~6~ → **2Ag** (glucose và fructose như nhau).
   - Cu(OH)~2~/OH^−^, t°: C~6~H~12~O~6~ → **1 Cu~2~O** (cũng là tỉ lệ 1 C~6~H~12~O~6~ : 2 Cu(OH)~2~).
   - Nước bromine: **chỉ glucose**, 1 glucose : 1 Br~2~.
   - Hoà tan Cu(OH)~2~ ở nhiệt độ thường: 2 C~6~H~12~O~6~ : 1 Cu(OH)~2~.
3. Hỗn hợp glucose + fructose: dùng Br~2~ để tìm riêng glucose, dùng Ag để tìm **tổng**.

> [!vi-du] Ví dụ 7
> Hỗn hợp X gồm glucose và fructose có khối lượng 36 g. X làm mất màu vừa đủ dung dịch chứa 24 g Br~2~. Mặt khác, cho X tác dụng hoàn toàn với thuốc thử Tollens dư.
>
> a) Tính phần trăm khối lượng glucose trong X.
>
> b) Tính khối lượng Ag thu được.

> [!goi-y] Gợi ý 1
> Chất nào trong X phản ứng với Br~2~? Tỉ lệ bao nhiêu?

> [!goi-y] Gợi ý 2
> Với thuốc thử Tollens, **cả hai** chất đều phản ứng, mỗi chất cho 2Ag. Hai chất cùng M = 180, nên chỉ cần tổng số mol.

> [!loi-giai] Lời giải
> a) n(Br~2~) = 24 : 160 = 0,15 mol → n(glucose) = 0,15 mol → m(glucose) = 27 g.
>
> %m(glucose) = 27 : 36 · 100% = **75%**.
>
> b) n(X) = 36 : 180 = 0,2 mol → n(Ag) = 2 · 0,2 = 0,4 mol → m(Ag) = 0,4 · 108 = **43,2 g**.

> [!bay]
> - Quên hệ số **2** của Ag (tính ra 21,6 g thay vì 43,2 g).
> - Cho fructose phản ứng với Br~2~, hoặc chỉ tính glucose khi tráng bạc hỗn hợp.

### Dạng 3. Lên men – hiệu suất – CO~2~ hấp thụ vào nước vôi

**Nhận biết:** lên men glucose (hoặc nguyên liệu chứa glucose) thành ethanol. Đề cho hiệu suất, cho CO~2~ hấp thụ vào Ca(OH)~2~ hoặc Ba(OH)~2~, hỏi khối lượng glucose, ethanol, kết tủa, hiệu suất…

**Phương pháp:**

1. Sơ đồ: C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~.
2. **Đi xuôi** (từ glucose tìm sản phẩm): **nhân** H. **Đi ngược** (từ sản phẩm tìm glucose cần dùng): **chia** H.
3. CO~2~ vào nước vôi:
   - Nước vôi **dư**: n(CO~2~) = n(CaCO~3~).
   - Lọc kết tủa, **đun nóng** dung dịch lại có kết tủa: n(CO~2~) = n(↓ lần 1) + **2**·n(↓ lần 2).
   - Đề cho "khối lượng dung dịch **giảm**" Δm so với ban đầu: m(CO~2~) = m(↓) − Δm. Nếu "dung dịch **tăng**": m(CO~2~) = m(↓) + Δm.
4. Rượu: V(ethanol) = m : D; V(rượu x°) = V(ethanol) · 100 : x.

> [!vi-du] Ví dụ 8
> Lên men m gam glucose với hiệu suất 75%. Hấp thụ toàn bộ khí CO~2~ sinh ra vào dung dịch nước vôi trong, thu được 30 g kết tủa, và khối lượng dung dịch giảm 3,6 g so với dung dịch nước vôi ban đầu. Tính m.

> [!goi-y] Gợi ý 1
> Dung dịch "mất" khối lượng kết tủa nhưng lại "nhận" khối lượng CO~2~. Δm(giảm) = m(↓) − m(CO~2~).

> [!goi-y] Gợi ý 2
> Có n(CO~2~) rồi thì n(glucose phản ứng) = n(CO~2~) : 2. Đi ngược tìm glucose ban đầu nên **chia** cho 0,75.

> [!loi-giai] Lời giải
> m(CO~2~) = 30 − 3,6 = 26,4 g → n(CO~2~) = 26,4 : 44 = 0,6 mol.
>
> (Kiểm tra: n(CaCO~3~) = 0,3 mol < 0,6 mol, nên một phần CO~2~ đã tạo Ca(HCO~3~)~2~. Đó là lí do đề không cho dùng n(CO~2~) = n(↓).)
>
> n(glucose phản ứng) = 0,6 : 2 = 0,3 mol → n(glucose ban đầu) = 0,3 : 0,75 = 0,4 mol.
>
> m = 0,4 · 180 = **72 g**.

> [!bay]
> - Thấy 30 g kết tủa liền lấy n(CO~2~) = 0,3 mol là sai, vì nước vôi **không dư**. Luôn đọc kĩ: "dư", "đun nóng thu thêm kết tủa", "khối lượng dung dịch giảm/tăng".
> - Nhân H khi đi ngược thì kết quả nhỏ hơn đáp án đúng. Tự hỏi: "Có hao hụt thì cần **nhiều hơn** hay **ít hơn**?"

### Dạng 4. Câu Đúng/Sai về cấu tạo và tính chất

**Nhận biết:** 4 ý về dạng mạch hở/vòng, α/β, nhóm –OH hemiacetal, thí nghiệm, ứng dụng. Ý càng về sau càng đòi hỏi suy luận.

**Phương pháp:** soát từng **từ khoá**: số nhóm –OH (5); vị trí nhóm C=O (C1 hay C2); vòng mấy cạnh (6 hay 5); –OH hemiacetal ở C nào; α/β (dưới/trên); "nhiệt độ thường" hay "đun nóng"; thuốc thử có kiềm hay không (Br~2~ thì không).

> [!vi-du] Ví dụ 9 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Glucose và fructose là đồng phân của nhau.
>
> b) Trong phân tử α-glucose, nhóm –OH ở C1 nằm cùng phía với nhóm CH~2~OH.
>
> c) Phản ứng của glucose với CH~3~OH (HCl khan) chứng tỏ glucose có dạng mạch vòng.
>
> d) Có thể phân biệt dung dịch glucose và dung dịch fructose bằng thuốc thử Tollens.

> [!goi-y] Gợi ý 1
> Nhớ câu "α – anh ở dưới". Nhóm CH~2~OH ở C5 hướng lên.

> [!goi-y] Gợi ý 2
> Thuốc thử Tollens có môi trường kiềm. Fructose sẽ ra sao trong kiềm?

> [!loi-giai] Lời giải
> a) **Đúng**: cùng công thức C~6~H~12~O~6~, khác cấu tạo.
>
> b) **Sai**: ở α-glucose, –OH ở C1 hướng xuống, **khác** phía với CH~2~OH. Cùng phía là β-glucose.
>
> c) **Đúng**: chỉ dạng mạch vòng mới có nhóm –OH hemiacetal phản ứng được với CH~3~OH/HCl khan.
>
> d) **Sai**: cả hai đều tráng bạc (fructose chuyển thành glucose trong môi trường kiềm). Phải dùng nước bromine.

## Tóm tắt

| | Glucose | Fructose |
|---|---|---|
| Phân loại | monosaccharide (aldohexose) | monosaccharide (ketohexose) |
| Công thức | C~6~H~12~O~6~; CH~2~OH[CHOH]~4~CHO | C~6~H~12~O~6~; CH~2~OH[CHOH]~3~COCH~2~OH |
| Mạch vòng | 6 cạnh, α và β; –OH hemiacetal ở C1 | 5 cạnh, α và β; –OH hemiketal ở C2 |
| Cu(OH)~2~, nhiệt độ thường | dung dịch xanh lam | dung dịch xanh lam |
| Cu(OH)~2~/OH^−^, t° | Cu~2~O đỏ gạch | Cu~2~O đỏ gạch |
| Thuốc thử Tollens | Ag (1 : 2) | Ag (1 : 2) |
| Nước bromine | **mất màu** → gluconic acid | **không** phản ứng |
| CH~3~OH/HCl khan | methyl glucoside | (SGK không xét) |
| Lên men | → 2C~2~H~5~OH + 2CO~2~; → 2 lactic acid | — |
| Tự nhiên | quả chín (nho), máu người (4,4 – 7,2 mmol/L lúc đói) | trái cây, rau củ, mật ong |
| Ứng dụng | thực phẩm, tráng gương/ruột phích, ethanol, dịch truyền 5% | thực phẩm, đồ uống; cung cấp năng lượng |

**Các tỉ lệ dùng trong tính toán:**

- Hoà tan Cu(OH)~2~: 2C~6~H~12~O~6~ + Cu(OH)~2~ → (C~6~H~11~O~6~)~2~Cu + 2H~2~O.
- Tráng bạc: C~6~H~12~O~6~ → 2Ag. Khử Cu(OH)~2~ khi đun nóng: C~6~H~12~O~6~ → Cu~2~O.
- Nước bromine (chỉ glucose): C~6~H~12~O~6~ + Br~2~.
- Lên men: C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~; hiệu suất: đi xuôi nhân H, đi ngược chia H.
- Đường huyết: 1 mmol/L = 18 mg/dL.
