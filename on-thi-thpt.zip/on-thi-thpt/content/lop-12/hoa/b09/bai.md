---
title: Amino acid và peptide
thoi-gian: 50 phút
muc-tieu:
  - Nêu được khái niệm amino acid, α-amino acid, amino acid thiên nhiên và amino acid thiết yếu; gọi được tên (thay thế, bán hệ thống, thông thường, kí hiệu) của glycine, alanine, valine, lysine, glutamic acid.
  - Giải thích được vì sao amino acid tồn tại chủ yếu ở dạng ion lưỡng cực, và từ đó suy ra tính chất vật lí (chất rắn, nóng chảy ở nhiệt độ cao, tan tốt trong nước).
  - Trình bày và viết được phương trình các phản ứng của amino acid: tính lưỡng tính (với HCl, NaOH), ester hoá, trùng ngưng của ε- và ω-amino acid.
  - Dự đoán được chiều di chuyển của amino acid trong điện trường ở các giá trị pH khác nhau (tính chất điện di).
  - Nêu được khái niệm peptide, liên kết peptide; viết được cấu tạo và tên viết tắt của peptide (đầu N → đầu C).
  - Trình bày được phản ứng thuỷ phân (hoàn toàn, không hoàn toàn) và phản ứng màu biuret của peptide; giải được các bài toán amino acid + HCl/NaOH, thuỷ phân peptide, đếm peptide.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Amino acid** = hợp chất tạp chức có **cả –NH~2~ và –COOH**. Amino acid thiên nhiên hầu hết là **α-amino acid** H~2~N–CH(R)–COOH. Năm chất cần thuộc: **Gly (75), Ala (89), Val (117), Lys (146), Glu (147)**.
> 2. Nhóm –COOH "chuyển" H^+^ sang –NH~2~ nên amino acid tồn tại chủ yếu dạng **ion lưỡng cực** H~3~N^+^–CH(R)–COO^−^ → **chất rắn, nóng chảy cao, tan tốt trong nước**.
> 3. Tính chất: **lưỡng tính** (tác dụng cả HCl và NaOH), **ester hoá** với alcohol, **trùng ngưng** (ε-, ω-amino acid → polyamide), **điện di**: pH < pI → cation, về **cực âm**; pH > pI → anion, về **cực dương**.
> 4. **Peptide** = các đơn vị **α-amino acid** nối nhau bằng **liên kết peptide –CO–NH–**. Peptide có n gốc thì có (n − 1) liên kết peptide. Viết tên từ **đầu N** (còn –NH~2~) đến **đầu C** (còn –COOH).
> 5. Peptide bị **thuỷ phân** (acid, base, enzyme) thành peptide nhỏ hơn hoặc amino acid. Peptide có **từ 2 liên kết peptide** (tripeptide trở lên) cho **màu tím** với Cu(OH)~2~/NaOH (phản ứng **biuret**); dipeptide thì **không**.

Bài 8 em đã gặp nhóm –NH~2~ có tính base. Lớp 11 em đã học nhóm –COOH có tính acid. Bây giờ hãy hình dung **một phân tử mang cả hai nhóm đó**: nó vừa là "amine", vừa là "acid". Đó là **amino acid**, viên gạch xây nên mọi protein trong cơ thể em. Nối các viên gạch lại với nhau, ta được **peptide** rồi **protein** (Bài 10).

## 1. Amino acid: khái niệm và danh pháp

### 1.1. Khái niệm

Quan sát năm amino acid quen thuộc dưới đây (SGK tr. 41, Hình 9.1), em sẽ thấy điểm chung: phân tử nào cũng có **ít nhất một nhóm –NH~2~ và ít nhất một nhóm –COOH**.

| Tên thông thường | Kí hiệu | Công thức cấu tạo | M |
|---|---|---|---|
| Glycine | Gly | H~2~N–CH~2~–COOH | 75 |
| Alanine | Ala | CH~3~–CH(NH~2~)–COOH | 89 |
| Valine | Val | (CH~3~)~2~CH–CH(NH~2~)–COOH | 117 |
| Lysine | Lys | H~2~N–[CH~2~]~4~–CH(NH~2~)–COOH | 146 |
| Glutamic acid | Glu | HOOC–[CH~2~]~2~–CH(NH~2~)–COOH | 147 |

> **Amino acid** là hợp chất hữu cơ **tạp chức**, trong phân tử chứa đồng thời nhóm amino (–NH~2~) và nhóm carboxyl (–COOH).

"Tạp chức" nghĩa là có **các nhóm chức khác loại** trong cùng phân tử (giống glucose có cả –OH và –CHO ở Bài 4).

**α-amino acid là gì?** Ta đánh dấu các nguyên tử C trong mạch bằng chữ Hy Lạp, bắt đầu từ **C ngay cạnh nhóm –COOH** là C **α**, rồi đến β, γ, δ, ε… Nếu nhóm –NH~2~ gắn vào C α thì đó là **α-amino acid**, công thức chung:

=> H~2~N–CH(R)–COOH    (R là H hoặc một nhóm nguyên tử)

Cả năm chất trong bảng đều là α-amino acid. Riêng **lysine** còn có thêm một nhóm –NH~2~ ở vị trí **ε** (đầu mạch).

**Amino acid trong cơ thể.** Amino acid **thiên nhiên** hầu hết là α-amino acid. Chỉ khoảng **20 amino acid** cấu tạo nên phần lớn protein của người, gọi là **amino acid tiêu chuẩn**. Trong số đó có những chất cơ thể người **không tự tổng hợp được**, phải lấy từ thức ăn (thịt, cá, trứng, sữa…), gọi là **amino acid thiết yếu**. Lysine và valine là hai amino acid thiết yếu có trong bảng trên.

> [!ung-dung] Vì sao bữa ăn cần đủ đạm và đa dạng?
> Cơ thể "lắp" protein từ khoảng 20 loại amino acid. Chỉ cần thiếu một loại thiết yếu là việc lắp ráp bị chững lại. Ngũ cốc thường nghèo lysine, còn đậu đỗ thì giàu lysine. Vì thế ăn **cơm kèm đậu, thịt, cá, trứng** giúp bù cho nhau đủ các amino acid thiết yếu.

### 1.2. Danh pháp

Tên amino acid đi từ **tên carboxylic acid tương ứng** (lớp 11). Có ba kiểu tên (SGK tr. 42, Bảng 9.1):

**a) Tên thay thế** (theo IUPAC):

> **Vị trí nhóm amino + amino + tên acid mạch chính**

Mạch chính là mạch C chứa nhóm –COOH; **C của nhóm –COOH là C1**. Nhóm –NH~2~ coi là nhóm thế, ghi số chỉ vị trí. Ví dụ CH~3~–CH(NH~2~)–COOH: mạch 3 C (propanoic acid), NH~2~ ở C2 → **2-aminopropanoic acid**.

**b) Tên bán hệ thống:**

> **Chữ Hy Lạp chỉ vị trí nhóm amino + amino + tên thông thường của acid**

Vị trí ghi bằng α, β, γ… (C α là C số 2). Ví dụ CH~3~–CH(NH~2~)–COOH: tên thường của CH~3~CH~2~COOH là propionic acid → **α-aminopropionic acid**.

**c) Tên thông thường và kí hiệu:** α-amino acid thiên nhiên thường gọi bằng tên riêng, viết tắt 3 chữ cái: glycine (Gly), alanine (Ala)…

| Công thức | Tên thay thế | Tên bán hệ thống | Tên thường |
|---|---|---|---|
| H~2~N–CH~2~–COOH | aminoethanoic acid | aminoacetic acid | glycine |
| CH~3~–CH(NH~2~)–COOH | 2-aminopropanoic acid | α-aminopropionic acid | alanine |
| (CH~3~)~2~CH–CH(NH~2~)–COOH | 2-amino-3-methylbutanoic acid | α-aminoisovaleric acid | valine |
| H~2~N–[CH~2~]~4~–CH(NH~2~)–COOH | 2,6-diaminohexanoic acid | α,ε-diaminocaproic acid | lysine |
| HOOC–[CH~2~]~2~–CH(NH~2~)–COOH | 2-aminopentane-1,5-dioic acid | α-aminoglutaric acid | glutamic acid |

> [!bay]
> - **Số 2 tương ứng với α**, không phải số 1. Đánh số thì C của –COOH là C1; còn chữ Hy Lạp bắt đầu từ C **bên cạnh** –COOH.
> - **Gly** là glycine, **Glu** là glutamic acid. Hai kí hiệu chỉ khác một chữ, đề rất hay "bẫy" chỗ này.

> [!meo] Nhớ phân tử khối bằng "Gly + nhóm CH~2~"
> Gly = 75. Mỗi nhóm CH~2~ thêm 14: Ala = 75 + 14 = **89**, Val = 89 + 2 · 14 = **117**. Lys = 146 (thêm một nhóm NH~2~ ở cuối mạch), Glu = 147 (thêm một nhóm COOH). Amino acid no, mạch hở, có 1 NH~2~ và 1 COOH: C~n~H~2n+1~NO~2~, **M = 14n + 47**.

> [!vi-du] Ví dụ 1
> Cho hai chất: (X) CH~3~–CH~2~–CH(NH~2~)–COOH và (Y) H~2~N–CH~2~–CH~2~–COOH.
>
> a) Gọi tên thay thế và tên bán hệ thống của X, Y.
>
> b) Chất nào là α-amino acid?

> [!goi-y] Gợi ý 1
> Đánh số từ C của –COOH (C1). X có mạch 4 C (butanoic acid), Y có mạch 3 C (propanoic acid). NH~2~ ở C nào?

> [!goi-y] Gợi ý 2
> Tên thường của CH~3~CH~2~CH~2~COOH là butyric acid, của CH~3~CH~2~COOH là propionic acid. C2 là α, C3 là β.

> [!loi-giai] Lời giải
> a) X: NH~2~ ở C2 → **2-aminobutanoic acid** (thay thế), **α-aminobutyric acid** (bán hệ thống).
>
> Y: NH~2~ ở C3 → **3-aminopropanoic acid**, **β-aminopropionic acid**.
>
> b) Chỉ **X** là α-amino acid (NH~2~ gắn vào C bên cạnh –COOH). Y là β-amino acid.

## 2. Đặc điểm cấu tạo và tính chất vật lí

### 2.1. Ion lưỡng cực

Trong cùng một phân tử amino acid có nhóm –COOH (cho được H^+^) và nhóm –NH~2~ (nhận được H^+^). Vậy điều gì xảy ra? H^+^ của nhóm –COOH **chuyển sang** nhóm –NH~2~ ngay trong phân tử:

=> H~2~N–CH(R)–COOH ⇌ H~3~N^+^–CH(R)–COO^−^

Dạng bên phải có **một đầu mang điện dương (–NH~3~^+^) và một đầu mang điện âm (–COO^−^)**, tổng điện tích bằng 0. Ta gọi đó là **ion lưỡng cực**. Amino acid **tồn tại chủ yếu ở dạng ion lưỡng cực** (SGK tr. 42). Để viết cho gọn, đề thi và SGK vẫn thường viết dạng phân tử H~2~N–CH(R)–COOH.

![Hình 1. a) Amino acid chuyển thành ion lưỡng cực; b) dạng tồn tại của glycine thay đổi theo pH](ion-luong-cuc.svg)

> [!nen-tang] Acid – base theo Brønsted – Lowry (lớp 11)
> - **Acid** là chất **cho** H^+^, **base** là chất **nhận** H^+^.
> - Nhóm –COOH là acid (cho H^+^ thành –COO^−^); nhóm –NH~2~ là base (nhận H^+^ thành –NH~3~^+^), giống amine ở Bài 8.
> - pH < 7: môi trường acid (nhiều H^+^); pH > 7: môi trường base (nhiều OH^−^).

### 2.2. Tính chất vật lí

Ở điều kiện thường, amino acid là **chất rắn**, dạng tinh thể **không màu**, có **nhiệt độ nóng chảy cao** (thường trên 200 °C, nhiều chất bị phân huỷ khi nóng chảy) và **tan tốt trong nước**.

**Vì sao?** Vì chúng là **ion lưỡng cực**. Giữa các ion có **lực hút tĩnh điện** mạnh, giống tinh thể muối ăn. Muốn làm nóng chảy phải tốn nhiều năng lượng. Các đầu mang điện cũng "hút" phân tử nước rất mạnh nên dễ tan.

So sánh để thấy rõ: glycine (M = 75) là chất rắn, nóng chảy trên 200 °C. Trong khi đó acetic acid (M = 60) là chất lỏng (nóng chảy ở khoảng 17 °C), còn propylamine (M = 59) là chất lỏng dễ bay hơi.

> [!bay]
> Đề hay cài: "amino acid là chất lỏng / dễ bay hơi / có mùi khai như amine". **Sai.** Amino acid có cấu tạo kiểu "muối nội phân tử", nên tính chất vật lí giống **muối** hơn là giống amine hay acid.

## 3. Tính chất hoá học của amino acid

Amino acid có **tính chất của từng nhóm** (–NH~2~ như amine, –COOH như carboxylic acid) và có **tính chất do cả hai nhóm cùng gây ra** (ion lưỡng cực, điện di, trùng ngưng).

### 3.1. Tính lưỡng tính

Nhóm –NH~2~ có tính base, nhóm –COOH có tính acid, nên amino acid **tác dụng được với cả acid mạnh và base mạnh**:

=> H~2~N–CH~2~–COOH + HCl → ClH~3~N–CH~2~–COOH

=> H~2~N–CH~2~–COOH + NaOH → H~2~N–CH~2~–COONa + H~2~O

Hãy để ý sự khác nhau:

- Với **HCl**: nhóm –NH~2~ nhận thêm HCl, **không tạo nước** (giống amine + HCl ở Bài 8) → **m(muối) = m(amino acid) + m(HCl)**.
- Với **NaOH**: H của –COOH được thay bằng Na, **có tạo nước** → mỗi nhóm –COOH làm khối lượng tăng 23 − 1 = **22**.

> [!vi-du] Ví dụ 2
> Cho 7,5 g glycine tác dụng vừa đủ với dung dịch NaOH. Tính khối lượng muối thu được. Nếu thay NaOH bằng dung dịch HCl (vừa đủ) thì thu được bao nhiêu gam muối?

> [!goi-y] Gợi ý 1
> n(Gly) = 7,5 : 75. Glycine có 1 nhóm –COOH và 1 nhóm –NH~2~.

> [!goi-y] Gợi ý 2
> Muối natri: H~2~N–CH~2~–COONa (M = 97). Muối với HCl: ClH~3~N–CH~2~–COOH (M = 75 + 36,5 = 111,5).

> [!loi-giai] Lời giải
> n(Gly) = 7,5 : 75 = 0,1 mol.
>
> Với NaOH: m(muối) = 0,1 · 97 = **9,7 g** (hoặc 7,5 + 0,1 · 22 = 9,7 g).
>
> Với HCl: m(muối) = 7,5 + 0,1 · 36,5 = **11,15 g**.

**Amino acid làm quỳ tím đổi màu không?** Hãy so số nhóm –NH~2~ với số nhóm –COOH:

| Amino acid | Số –NH~2~ : số –COOH | Môi trường | Quỳ tím |
|---|---|---|---|
| Glycine, alanine, valine | 1 : 1 | gần trung tính | không đổi màu |
| Lysine | 2 : 1 | base | hoá **xanh** |
| Glutamic acid | 1 : 2 | acid | hoá **đỏ** |

(SGK không có bảng này; đây là quy tắc bổ sung hay dùng trong đề thi.)

> [!meo] Đếm nhóm để đoán màu quỳ
> Nhiều NH~2~ hơn → xanh. Nhiều COOH hơn → đỏ. Bằng nhau → không đổi màu. Quy tắc này dùng tốt cho các amino acid trong SGK.

> [!ung-dung] Ổn định pH của máu
> Nhờ tính lưỡng tính, amino acid và protein "đỡ" được cả H^+^ lẫn OH^−^ lọt vào dung dịch. Đây là một lí do máu của em luôn giữ pH quanh 7,4 dù ta ăn đồ chua hay uống nước có ga.

> [!ung-dung] Bột ngọt là muối của glutamic acid
> Bột ngọt (mì chính) là **muối monosodium glutamate**, tức muối natri của glutamic acid, tạo vị "umami" đậm đà. Glutamic acid còn được dùng làm thuốc hỗ trợ thần kinh.

### 3.2. Phản ứng ester hoá

Nhóm –COOH của amino acid phản ứng với alcohol giống carboxylic acid (lớp 11). Ví dụ đun glycine với ethanol, có H~2~SO~4~ đặc làm xúc tác:

=> H~2~N–CH~2~–COOH + C~2~H~5~OH ⇌ H~2~N–CH~2~–COOC~2~H~5~ + H~2~O    (H~2~SO~4~ đặc, t°)

Sản phẩm là ester **ethyl aminoacetate** (M = 103). Vì môi trường có acid mạnh dư, thực tế nhóm –NH~2~ của ester bị chuyển thành dạng muối (SGK tr. 43).

### 3.3. Tính chất điện di

Ở Hình 1b, em thấy dạng tồn tại của glycine **phụ thuộc pH**:

- Ở **pH ≈ 6**, glycine chủ yếu là ion lưỡng cực, **tổng điện tích bằng 0**.
- Ở **pH thấp hơn** (môi trường nhiều H^+^), nhóm –COO^−^ nhận lại H^+^ → glycine thành **cation** H~3~N^+^–CH~2~–COOH.
- Ở **pH cao hơn** (môi trường nhiều OH^−^), nhóm –NH~3~^+^ nhường H^+^ → glycine thành **anion** H~2~N–CH~2~–COO^−^.

Nếu đặt dung dịch amino acid vào **điện trường** (hai điện cực): ion dương bị hút về **cực âm (−)**, ion âm bị hút về **cực dương (+)**, phân tử có tổng điện tích bằng 0 thì **hầu như không di chuyển**. Khả năng di chuyển khác nhau trong điện trường tuỳ theo pH như vậy gọi là **tính chất điện di** (SGK tr. 43).

Giá trị pH mà tại đó amino acid có tổng điện tích bằng 0 gọi là **điểm đẳng điện, kí hiệu pI** (mở rộng: SGK chỉ nêu ví dụ glycine ở pH ≈ 6, chưa định nghĩa pI). Khi cần, đề thi sẽ cho sẵn pI, ví dụ: Gly ≈ 6,0; Ala ≈ 6,0; Val ≈ 6,0; Lys ≈ 9,7; Glu ≈ 3,2.

> [!ghi-nho] Quy tắc điện di
> - **pH < pI** → amino acid nhận H^+^ → **cation** → di chuyển về **cực âm (−)**.
> - **pH = pI** → tổng điện tích bằng 0 → **hầu như không di chuyển**.
> - **pH > pI** → amino acid nhường H^+^ → **anion** → di chuyển về **cực dương (+)**.

![Hình 2. Điện di ở pH 6: lysine về cực âm, glutamic acid về cực dương, glycine hầu như đứng yên](dien-di.svg)

**Vì sao lysine có pI cao, glutamic acid có pI thấp?** Lysine có thêm một nhóm –NH~2~ (base), nên phải ở môi trường **khá base** (pH ≈ 9,7) mới "rút" bớt điện tích dương để tổng điện tích bằng 0. Glutamic acid có thêm một nhóm –COOH (acid), nên phải ở môi trường **khá acid** (pH ≈ 3,2) mới "bù" được điện tích âm dư để tổng điện tích bằng 0.

> [!bay]
> - Nhầm chiều: **cation đi về cực ÂM**, không phải về cực dương. Cứ nhớ "trái dấu thì hút nhau": ion dương về cực âm, ion âm về cực dương.
> - So sánh **pH của dung dịch** với **pI của chất**, không so pH với 7. Ví dụ ở pH = 5, glycine (pI ≈ 6) vẫn mang tổng điện tích dương nên đi về cực âm, dù pH = 5 không quá acid.

> [!vi-du] Ví dụ 3
> Cho pI của glycine, lysine, glutamic acid lần lượt là 5,97; 9,74; 3,22. Đặt hỗn hợp ba amino acid này vào điện trường.
>
> a) Ở pH = 6,0, chất nào di chuyển về cực âm, chất nào về cực dương?
>
> b) Ở pH = 2,0 thì sao? Ở pH = 11 thì sao?

> [!goi-y] Gợi ý 1
> So pH với pI của từng chất: pH nhỏ hơn pI thì chất đó là cation.

> [!goi-y] Gợi ý 2
> Glycine có pI = 5,97, rất sát 6,0, nên ở pH = 6,0 nó gần như không mang điện.

> [!loi-giai] Lời giải
> a) pH = 6,0:
> - Lysine: 6,0 < 9,74 → cation → về **cực âm**.
> - Glutamic acid: 6,0 > 3,22 → anion → về **cực dương**.
> - Glycine: pH ≈ pI → **hầu như không di chuyển**.
>
> b) pH = 2,0 nhỏ hơn pI của cả ba → cả ba là cation, **đều về cực âm**. pH = 11 lớn hơn pI của cả ba → cả ba là anion, **đều về cực dương**.

> [!ung-dung] Tách amino acid và protein bằng điện di
> Phòng xét nghiệm dùng **điện di** để tách các protein trong huyết thanh, hay tách các đoạn DNA (Sinh học 12). Chất nào mang điện khác nhau sẽ chạy với tốc độ, chiều khác nhau, tạo thành các vạch riêng biệt.

### 3.4. Phản ứng trùng ngưng

Khi đun nóng, các **ε-amino acid** và **ω-amino acid** (nhóm –NH~2~ ở cuối mạch) phản ứng với nhau: nhóm –COOH của phân tử này kết hợp với nhóm –NH~2~ của phân tử kia, **tách ra H~2~O**. Lặp lại rất nhiều lần, ta được một **polymer** có các liên kết –CO–NH– gọi là **polyamide**. Phản ứng vừa tạo polymer vừa tách phân tử nhỏ như vậy gọi là **phản ứng trùng ngưng**.

Ví dụ: 6-aminohexanoic acid (ε-aminocaproic acid) trùng ngưng thành **polycaproamide (capron, nylon-6)**:

=> nH~2~N–[CH~2~]~5~–COOH → (–NH–[CH~2~]~5~–CO–)~n~ + nH~2~O    (t°)

Tương tự, 7-aminoheptanoic acid (ω-aminoenanthic acid) trùng ngưng thành **polyenanthamide (nylon-7)**:

=> nH~2~N–[CH~2~]~6~–COOH → (–NH–[CH~2~]~6~–CO–)~n~ + nH~2~O    (t°)

> [!meo] Viết nhanh mắt xích
> Mắt xích = monomer **bỏ H** ở đầu –NH~2~ và **bỏ OH** ở đầu –COOH. Vì vậy M(mắt xích) = M(monomer) − 18. Ví dụ: 6-aminohexanoic acid M = 131 → mắt xích –NH–[CH~2~]~5~–CO– có M = 113.

> [!vi-du] Ví dụ 4
> Trùng ngưng 26,2 g 6-aminohexanoic acid với hiệu suất 80%. Tính khối lượng capron thu được.

> [!goi-y] Gợi ý 1
> Mỗi phân tử monomer khi vào mạch thì mất 1 phân tử H~2~O. Tính số mol monomer trước.

> [!goi-y] Gợi ý 2
> m(polymer) lí thuyết = n(monomer) · 113. Đi từ chất đầu ra sản phẩm thì nhân hiệu suất.

> [!loi-giai] Lời giải
> n(monomer) = 26,2 : 131 = 0,2 mol.
>
> m(capron) = 0,2 · 113 · 0,8 = **18,08 g**.
>
> (Cách khác: m(H~2~O) tách ra = 0,2 · 18 = 3,6 g → m lí thuyết = 26,2 − 3,6 = 22,6 g; nhân 0,8 được 18,08 g.)

> [!em-co-biet] Tơ nylon-6 trong đời sống
> Capron (nylon-6) bền, dai, nhẹ, được dùng làm lưới đánh cá, dây dù, chỉ khâu, vải may áo mưa. Em sẽ học kĩ hơn ở chương Polymer.

## 4. Peptide: khái niệm và cấu tạo

### 4.1. Khái niệm

Phản ứng giữa –COOH và –NH~2~ ở mục 3.4 cũng xảy ra giữa các **α-amino acid** (trong cơ thể, có enzyme xúc tác). Nối 2, 3, 4… phân tử α-amino acid như vậy, ta được **peptide**.

> **Peptide** là những hợp chất được cấu tạo từ các đơn vị **α-amino acid** liên kết với nhau qua **liên kết peptide –CO–NH–**.

- Liên kết peptide là liên kết **–CO–NH– giữa hai đơn vị α-amino acid**.
- Peptide chứa 2, 3, 4… đơn vị α-amino acid gọi là **dipeptide, tripeptide, tetrapeptide…**; chứa rất nhiều đơn vị gọi là **polypeptide**.
- Nối n đơn vị thì tạo **(n − 1) liên kết peptide**, đồng thời tách ra **(n − 1) phân tử H~2~O**.

=> M(peptide) = tổng M các amino acid − 18 · (n − 1)

Ví dụ: Gly-Ala có M = 75 + 89 − 18 = 146.

> [!bay]
> - Nhóm –CO–NH– tạo từ **β-amino acid** hay từ amino acid kiểu ε, ω **không** được gọi là liên kết peptide. Ví dụ H~2~N–CH~2~–CH~2~–CO–NH–CH~2~–COOH **không** phải dipeptide (gốc đầu là β-amino acid). Capron có liên kết –CO–NH– nhưng là polyamide, không phải polypeptide.
> - Tetrapeptide có **3** liên kết peptide, không phải 4.

### 4.2. Cấu tạo và cách viết tên

Cấu tạo của peptide được quyết định bởi **thứ tự** các α-amino acid trong mạch. Peptide mạch hở có hai đầu:

- **Đầu N**: gốc amino acid còn nhóm **–NH~2~ tự do**, viết ở **bên trái**.
- **Đầu C**: gốc amino acid còn nhóm **–COOH tự do**, viết ở **bên phải**.

Tên viết tắt của peptide = các kí hiệu amino acid nối bằng gạch ngang, **theo thứ tự từ đầu N đến đầu C**.

![Hình 3. Tripeptide Ala-Gly-Val: đầu N là Ala, đầu C là Val, có 2 liên kết peptide](peptide.svg)

Viết công thức cấu tạo của Ala-Gly-Val: viết lần lượt từng gốc từ trái sang phải, nối gốc trước (–CO–) với gốc sau (–NH–):

=> H~2~N–CH(CH~3~)–CO–NH–CH~2~–CO–NH–CH[CH(CH~3~)~2~]–COOH

> [!bay]
> **Thứ tự khác nhau là chất khác nhau.** Ala-Gly và Gly-Ala là **hai dipeptide khác nhau**: Ala-Gly có đầu N là Ala, còn Gly-Ala có đầu N là Gly. Tương tự, Ala-Gly-Val khác Val-Gly-Ala.

> [!vi-du] Ví dụ 5
> a) Viết tên viết tắt của tất cả các tripeptide mạch hở chứa đồng thời một gốc Gly, một gốc Ala và một gốc Val.
>
> b) Viết công thức cấu tạo của tripeptide có đầu N là Val và đầu C là Gly trong số đó.

> [!goi-y] Gợi ý 1
> Ba "viên gạch" khác nhau xếp vào 3 vị trí: vị trí 1 có 3 cách chọn, vị trí 2 còn 2 cách, vị trí 3 còn 1 cách.

> [!goi-y] Gợi ý 2
> Đầu N là Val, đầu C là Gly thì Ala ở giữa: Val-Ala-Gly.

> [!loi-giai] Lời giải
> a) Có 3 · 2 · 1 = **6 tripeptide**: Gly-Ala-Val, Gly-Val-Ala, Ala-Gly-Val, Ala-Val-Gly, Val-Gly-Ala, Val-Ala-Gly.
>
> b) Val-Ala-Gly: H~2~N–CH[CH(CH~3~)~2~]–CO–NH–CH(CH~3~)–CO–NH–CH~2~–COOH.

## 5. Tính chất hoá học của peptide

### 5.1. Phản ứng thuỷ phân

Thuỷ phân là phản ứng **ngược** với phản ứng tạo peptide: nước "cắt" liên kết peptide, trả lại nhóm –COOH và –NH~2~. Peptide bị thuỷ phân nhờ **acid, base hoặc enzyme**.

**a) Thuỷ phân hoàn toàn** → các α-amino acid tạo nên peptide. Ví dụ với enzyme:

=> Gly-Ala + H~2~O → H~2~N–CH~2~–COOH + CH~3~–CH(NH~2~)–COOH    (enzyme)

Trong **môi trường acid hoặc base**, amino acid sinh ra phản ứng tiếp với acid, base đó nên ta thu được **muối**. Với dipeptide Gly-Gly:

=> Gly-Gly + H~2~O + 2HCl → 2ClH~3~N–CH~2~–COOH

=> Gly-Gly + 2NaOH → 2H~2~N–CH~2~–COONa + H~2~O

> [!ghi-nho] Tỉ lệ khi thuỷ phân peptide có n gốc
> Áp dụng khi mỗi gốc có 1 nhóm –NH~2~ và 1 nhóm –COOH (như Gly, Ala, Val):
>
> - Thuỷ phân trong **NaOH**: X + **n**NaOH → muối + **1**H~2~O → m(muối) = m(X) + 40n · n(X) − 18 · n(X).
> - Thuỷ phân trong **HCl**: X + (n − 1) H~2~O + **n**HCl → muối → m(muối) = m(X) + 18(n − 1) · n(X) + 36,5n · n(X).
>
> **Vì sao trong NaOH chỉ ra 1 H~2~O?** Mỗi liên kết peptide bị cắt **lấy vào** 1 H~2~O (n − 1 phân tử), mỗi nhóm –COOH trung hoà NaOH **tạo ra** 1 H~2~O (n phân tử). Tính gộp: n − (n − 1) = **1** phân tử H~2~O được tạo ra.

**b) Thuỷ phân không hoàn toàn** → các **peptide ngắn hơn** (và amino acid). Mỗi mảnh là một **đoạn liên tiếp** của chuỗi ban đầu, giữ nguyên thứ tự.

![Hình 4. Thuỷ phân không hoàn toàn Gly-Ala-Gly-Val: các mảnh đều là đoạn liên tiếp của chuỗi](thuy-phan.svg)

> [!vi-du] Ví dụ 6
> Tetrapeptide X khi thuỷ phân hoàn toàn cho 2 mol glycine, 1 mol alanine và 1 mol valine (tính cho 1 mol X). Thuỷ phân không hoàn toàn X chỉ thu được ba dipeptide là Gly-Ala, Ala-Gly và Gly-Val. Xác định trình tự của X.

> [!goi-y] Gợi ý 1
> X có 4 gốc nên có 3 chỗ nối, tương ứng đúng 3 dipeptide. Hãy "ghép" các dipeptide sao cho gốc cuối của mảnh này trùng gốc đầu của mảnh sau.

> [!goi-y] Gợi ý 2
> Ala chỉ có 1 gốc. Nó đứng sau Gly (Gly-Ala) và đứng trước Gly (Ala-Gly). Val chỉ có trong Gly-Val và đứng sau Gly.

> [!loi-giai] Lời giải
> Ghép Gly-Ala với Ala-Gly (chung Ala) được Gly-Ala-Gly. Ghép tiếp với Gly-Val (chung Gly cuối) được **Gly-Ala-Gly-Val**.
>
> Kiểm tra: X gồm 2 Gly, 1 Ala, 1 Val ✓; các dipeptide liên tiếp là Gly-Ala, Ala-Gly, Gly-Val ✓. Đầu N là Gly, đầu C là Val.

> [!vi-du] Ví dụ 7
> Thuỷ phân hoàn toàn 14,6 g Gly-Ala trong dung dịch NaOH vừa đủ, đun nóng. Tính khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> M(Gly-Ala) = 75 + 89 − 18 = 146. Dipeptide có 2 gốc → cần bao nhiêu NaOH?

> [!goi-y] Gợi ý 2
> Hai muối là H~2~N–CH~2~–COONa (97) và H~2~N–CH(CH~3~)–COONa (111). Hoặc dùng bảo toàn khối lượng.

> [!loi-giai] Lời giải
> n(Gly-Ala) = 14,6 : 146 = 0,1 mol.
>
> Gly-Ala + 2NaOH → H~2~N–CH~2~–COONa + H~2~N–CH(CH~3~)–COONa + H~2~O
>
> m(muối) = 0,1 · 97 + 0,1 · 111 = **20,8 g**.
>
> (Bảo toàn khối lượng: 14,6 + 0,2 · 40 − 0,1 · 18 = 20,8 g ✓.)

### 5.2. Phản ứng màu biuret

**Thí nghiệm (SGK tr. 45).** Cho vào ống nghiệm khoảng 1 mL dung dịch NaOH 30% và vài giọt dung dịch CuSO~4~ 2%, lắc đều: xuất hiện **kết tủa xanh** Cu(OH)~2~. Thêm vài mL **dung dịch lòng trắng trứng** (chứa protein, tức polypeptide), lắc đều: hỗn hợp chuyển sang **màu tím** đặc trưng.

**Giải thích.** Cu(OH)~2~ trong môi trường kiềm gọi là **thuốc thử biuret**. Ion Cu^2+^ tạo **phức chất màu tím** với các nguyên tử N của **các liên kết peptide** nằm gần nhau trên mạch. Cần **ít nhất hai liên kết peptide** mới "kẹp" được Cu^2+^, vì vậy:

- Peptide có **từ 2 liên kết peptide trở lên** (tripeptide, tetrapeptide…, protein) → **màu tím**.
- **Dipeptide** (chỉ 1 liên kết peptide) và **amino acid** → **không** có màu tím.

Phản ứng biuret dùng để **nhận biết peptide (trừ dipeptide)** và protein.

> [!bay]
> - **Dipeptide không có phản ứng màu biuret.** Đây là câu hỏi "kinh điển" của đề thi.
> - Đừng nhầm với **màu xanh lam** của Cu(OH)~2~ với glucose, glycerol, saccharose (các nhóm –OH kề nhau, Bài 4–5). Peptide cho màu **tím**.

> [!vi-du] Ví dụ 8 (Đúng/Sai)
> Làm thí nghiệm: ống (1) có 1 mL NaOH 30% và 3 giọt CuSO~4~ 2%; thêm vào ống (1) khoảng 3 mL dung dịch lòng trắng trứng. Xét các phát biểu:
>
> a) Trước khi thêm lòng trắng trứng, ống (1) có kết tủa màu xanh.
>
> b) Sau khi thêm lòng trắng trứng, hỗn hợp có màu tím.
>
> c) Nếu thay lòng trắng trứng bằng dung dịch Gly-Ala thì cũng thấy màu tím.
>
> d) Có thể dùng phản ứng này để phân biệt dung dịch Gly-Ala-Val với dung dịch Gly-Val.

> [!goi-y] Gợi ý 1
> CuSO~4~ + NaOH tạo gì? Lòng trắng trứng chứa protein có nhiều liên kết peptide.

> [!goi-y] Gợi ý 2
> Đếm số liên kết peptide của Gly-Ala, Gly-Val, Gly-Ala-Val.

> [!loi-giai] Lời giải
> a) **Đúng**: CuSO~4~ + 2NaOH → Cu(OH)~2~↓ (xanh) + Na~2~SO~4~.
>
> b) **Đúng**: protein có nhiều liên kết peptide, tạo phức màu tím với Cu^2+^.
>
> c) **Sai**: Gly-Ala là dipeptide, chỉ có 1 liên kết peptide, không cho màu tím.
>
> d) **Đúng**: Gly-Ala-Val (2 liên kết peptide) cho màu tím, Gly-Val (dipeptide) thì không.

## Dạng bài thi hay gặp

### Dạng 1. Đếm số peptide

**Nhận biết:** đề hỏi "có bao nhiêu dipeptide / tripeptide…" tạo từ một số amino acid cho trước, hoặc "chứa đồng thời…".

**Phương pháp:**

1. Peptide là **dãy có thứ tự** các gốc (đầu N → đầu C), các gốc được lặp lại.
2. Từ **k** loại amino acid, số peptide có **n** gốc (cho phép lặp) = **k^n^**. Ví dụ từ Gly và Ala: số dipeptide = 2^2^ = 4 (Gly-Gly, Gly-Ala, Ala-Gly, Ala-Ala).
3. Peptide có n gốc, **mỗi gốc khác nhau, mỗi loại đúng 1 lần**: số peptide = **n!** = 1 · 2 · … · n (tripeptide: 6).
4. "Chứa **đồng thời** cả hai loại" = tổng số − số peptide chỉ chứa một loại.

> [!vi-du] Ví dụ 9
> Từ glycine và alanine có thể tạo ra bao nhiêu tripeptide mạch hở chứa **đồng thời** cả gốc Gly và gốc Ala?

> [!goi-y] Gợi ý 1
> Mỗi vị trí trong 3 vị trí có 2 lựa chọn → tổng cộng 2^3^ tripeptide.

> [!goi-y] Gợi ý 2
> Loại đi các tripeptide "thuần" chỉ có một loại amino acid.

> [!loi-giai] Lời giải
> Tổng số tripeptide từ 2 loại: 2^3^ = 8. Trừ Gly-Gly-Gly và Ala-Ala-Ala còn **6 tripeptide**: Gly-Gly-Ala, Gly-Ala-Gly, Ala-Gly-Gly, Ala-Ala-Gly, Ala-Gly-Ala, Gly-Ala-Ala.

> [!bay]
> Quên rằng **thứ tự quan trọng** (đếm Gly-Ala và Ala-Gly là một) → đáp số sai. Ngược lại, đừng đếm cùng một chuỗi hai lần.

### Dạng 2. Amino acid tác dụng với HCl, NaOH

**Nhận biết:** đề cho khối lượng amino acid và khối lượng muối, hoặc số mol HCl, NaOH đã phản ứng; hỏi công thức amino acid hay khối lượng muối.

**Phương pháp:**

1. Số nhóm –NH~2~ = n(HCl) : n(amino acid); số nhóm –COOH = n(NaOH) : n(amino acid).
2. Với HCl: **m(muối) = m(amino acid) + 36,5 · n(HCl)**.
3. Với NaOH (tăng giảm khối lượng): **m(muối) = m(amino acid) + 22 · n(NaOH)**.
4. **Bài 2 giai đoạn** (amino acid + HCl được dung dịch Y, Y + NaOH): coi như NaOH phản ứng với **cả HCl và amino acid ban đầu**: **n(NaOH) = n(HCl) + n(–COOH)**.
5. Tìm M → đối chiếu Gly 75, Ala 89, Val 117, Lys 146, Glu 147.

> [!vi-du] Ví dụ 10
> X là một α-amino acid. Cho 0,1 mol X tác dụng vừa đủ với dung dịch HCl, thu được 18,35 g muối. Mặt khác, 0,1 mol X tác dụng vừa đủ với 0,2 mol NaOH. Xác định X.

> [!goi-y] Gợi ý 1
> Giả sử X có 1 nhóm –NH~2~ thì n(HCl) = n(X) = 0,1 mol. Tính M(muối), rồi trừ 36,5 để được M(X).

> [!goi-y] Gợi ý 2
> Số nhóm –COOH = 0,2 : 0,1 = 2. Amino acid nào trong SGK có 1 NH~2~, 2 COOH và M = 147?

> [!loi-giai] Lời giải
> Với 1 nhóm –NH~2~: M(muối) = 18,35 : 0,1 = 183,5 → M(X) = 183,5 − 36,5 = 147.
>
> Số nhóm –COOH = n(NaOH) : n(X) = 2.
>
> X có 1 –NH~2~, 2 –COOH, M = 147 → X là **glutamic acid** HOOC–[CH~2~]~2~–CH(NH~2~)–COOH. (Nếu thử 2 nhóm –NH~2~ thì M(X) = 183,5 − 73 = 110,5, không nguyên → loại.)

> [!bay]
> Bài 2 giai đoạn: nhiều bạn chỉ tính NaOH phản ứng với amino acid mà **quên lượng HCl** đã cho vào trước. NaOH phải trung hoà cả HCl (dù HCl đã nằm trong muối).

### Dạng 3. Xác định amino acid từ phần trăm khối lượng

**Nhận biết:** đề cho %N, %O hoặc %C của một amino acid (thường là α-amino acid no, 1 –NH~2~, 1 –COOH).

**Phương pháp:** với 1 nguyên tử N: **M = 14 : %N**; với 2 nguyên tử O (1 –COOH): **M = 32 : %O**. Rồi dùng M = 14n + 47 hoặc đối chiếu bảng.

> [!vi-du] Ví dụ 11
> X là α-amino acid, phân tử có một nhóm –NH~2~ và một nhóm –COOH, trong đó nitrogen chiếm 15,73% khối lượng. Viết công thức cấu tạo và gọi tên thông thường của X.

> [!goi-y] Gợi ý 1
> M(X) = 14 : 0,1573.

> [!goi-y] Gợi ý 2
> 14n + 47 = M → n = ? "α" nghĩa là NH~2~ ở C bên cạnh COOH.

> [!loi-giai] Lời giải
> M(X) = 14 : 0,1573 ≈ 89 → 14n + 47 = 89 → n = 3 → C~3~H~7~NO~2~.
>
> X là α-amino acid → **CH~3~–CH(NH~2~)–COOH**, tên thường **alanine**. (Đồng phân H~2~N–CH~2~–CH~2~–COOH là β-amino acid nên loại.)

### Dạng 4. Thuỷ phân peptide

**Nhận biết:** đề cho khối lượng peptide, hỏi khối lượng muối/amino acid; hoặc cho hỗn hợp sản phẩm thuỷ phân không hoàn toàn, hỏi khối lượng peptide ban đầu.

**Phương pháp:**

1. Tính M(peptide) = tổng M amino acid − 18(n − 1).
2. Thuỷ phân hoàn toàn trong NaOH/HCl: dùng tỉ lệ ở khung ghi nhớ mục 5.1, hoặc bảo toàn khối lượng.
3. Thuỷ phân **không hoàn toàn**: **bảo toàn số gốc amino acid**. Đổi mỗi sản phẩm ra "số gốc": amino acid = 1, dipeptide = 2, tripeptide = 3… Tổng số mol gốc chia cho số gốc trong peptide ban đầu = số mol peptide.

> [!vi-du] Ví dụ 12
> Thuỷ phân không hoàn toàn m gam tetrapeptide Gly-Gly-Gly-Gly, thu được hỗn hợp gồm 22,5 g glycine, 26,4 g Gly-Gly và 18,9 g Gly-Gly-Gly. Tính m.

> [!goi-y] Gợi ý 1
> M: Gly = 75, Gly-Gly = 132, Gly-Gly-Gly = 189, tetrapeptide = 4 · 75 − 3 · 18 = 246.

> [!goi-y] Gợi ý 2
> Tổng số mol gốc Gly trong sản phẩm = 1 · n(Gly) + 2 · n(Gly-Gly) + 3 · n(Gly~3~). Số mol tetrapeptide = tổng đó chia 4.

> [!loi-giai] Lời giải
> n(Gly) = 22,5 : 75 = 0,3 mol; n(Gly-Gly) = 26,4 : 132 = 0,2 mol; n(Gly-Gly-Gly) = 18,9 : 189 = 0,1 mol.
>
> Tổng số mol gốc Gly = 0,3 + 2 · 0,2 + 3 · 0,1 = 1,0 mol → n(tetrapeptide) = 1,0 : 4 = 0,25 mol.
>
> m = 0,25 · 246 = **61,5 g**.

> [!bay]
> - Đừng cộng khối lượng các sản phẩm rồi coi là m. Thuỷ phân có **lấy thêm nước**, nên tổng khối lượng sản phẩm **lớn hơn** m (ở đây 67,8 g > 61,5 g).
> - Peptide chứa Glu (2 COOH) hoặc Lys (2 NH~2~) thì số mol NaOH, HCl phản ứng **khác** tỉ lệ "n NaOH", "n HCl" ở trên. Phải đếm theo số nhóm –COOH, –NH~2~.

### Dạng 5. Điện di (Đúng/Sai)

**Nhận biết:** đề cho pI của vài amino acid và pH của dung dịch đệm; hỏi chiều di chuyển, dạng tồn tại.

**Phương pháp:** với từng chất, so **pH với pI**: pH < pI → cation → cực âm; pH > pI → anion → cực dương; pH ≈ pI → hầu như đứng yên. Xem Ví dụ 3 ở mục 3.3.

> [!vi-du] Ví dụ 13 (Đúng/Sai)
> Cho pI: alanine 6,0; lysine 9,7; glutamic acid 3,2. Nhỏ hỗn hợp ba chất lên giữa một dải giấy thấm dung dịch đệm pH = 9,7 rồi nối hai đầu dải giấy với nguồn điện. Xét các phát biểu:
>
> a) Lysine hầu như không di chuyển.
>
> b) Alanine di chuyển về phía cực âm.
>
> c) Glutamic acid tồn tại chủ yếu ở dạng anion và di chuyển về phía cực dương.
>
> d) Ở pH này có thể tách được lysine ra khỏi hai chất còn lại.

> [!goi-y] Gợi ý 1
> So 9,7 với pI của từng chất.

> [!goi-y] Gợi ý 2
> Chất nào đứng yên, chất nào chạy đi? Hai nhóm đó có tách rời nhau không?

> [!loi-giai] Lời giải
> a) **Đúng**: pH = pI(Lys) → tổng điện tích ≈ 0.
>
> b) **Sai**: 9,7 > 6,0 → alanine là anion → về **cực dương**.
>
> c) **Đúng**: 9,7 > 3,2.
>
> d) **Đúng**: lysine ở lại vạch xuất phát, alanine và glutamic acid đều chạy về cực dương, nên lysine tách khỏi hai chất kia.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Amino acid | Tạp chức, có –NH~2~ và –COOH. Thiên nhiên: hầu hết α-amino acid H~2~N–CH(R)–COOH |
| 5 chất cần thuộc | Gly 75; Ala 89; Val 117; Lys 146 (2 NH~2~); Glu 147 (2 COOH) |
| Danh pháp | Thay thế: 2-aminopropanoic acid; bán hệ thống: α-aminopropionic acid; thường: alanine (Ala). Số 2 ứng với α |
| Cấu tạo | Ion lưỡng cực H~3~N^+^–CH(R)–COO^−^ |
| Vật lí | Rắn, kết tinh, không màu, nóng chảy cao, tan tốt trong nước |
| Lưỡng tính | + HCl → ClH~3~N–R–COOH (không tạo nước); + NaOH → H~2~N–R–COONa + H~2~O |
| Quỳ tím | Gly, Ala, Val: không đổi; Lys: xanh; Glu: đỏ |
| Ester hoá | Gly + C~2~H~5~OH ⇌ H~2~N–CH~2~–COOC~2~H~5~ + H~2~O (H~2~SO~4~ đặc) |
| Điện di | pH < pI: cation → cực âm; pH = pI: đứng yên; pH > pI: anion → cực dương |
| Trùng ngưng | ε-, ω-amino acid → polyamide + H~2~O. 6-aminohexanoic acid → capron (nylon-6) |
| Peptide | α-amino acid nối bằng –CO–NH–; n gốc → (n − 1) liên kết peptide; viết từ đầu N → đầu C |
| Thuỷ phân | Hoàn toàn → amino acid (hoặc muối); không hoàn toàn → đoạn peptide liên tiếp |
| Biuret | Cu(OH)~2~/NaOH + peptide có ≥ 2 liên kết peptide → màu tím. Dipeptide: không |

**Các công thức dùng trong tính toán:**

- Amino acid no, 1 –NH~2~, 1 –COOH: C~n~H~2n+1~NO~2~, M = 14n + 47.
- M(peptide n gốc) = ΣM(amino acid) − 18(n − 1).
- Amino acid + HCl: m(muối) = m + 36,5 · n(HCl). Amino acid + NaOH: m(muối) = m + 22 · n(NaOH).
- Hai giai đoạn (HCl rồi NaOH): n(NaOH) = n(HCl) + n(–COOH).
- Peptide n gốc + NaOH: cần n NaOH, tạo 1 H~2~O. Peptide n gốc + HCl: cần n HCl và (n − 1) H~2~O.
- Đếm peptide n gốc từ k loại amino acid: k^n^; n gốc khác nhau mỗi loại một lần: n!.
