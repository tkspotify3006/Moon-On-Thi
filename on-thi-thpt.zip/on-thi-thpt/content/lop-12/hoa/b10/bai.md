---
title: Protein và enzyme
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm protein, đặc điểm cấu tạo (một hay nhiều chuỗi polypeptide), phân biệt protein đơn giản và protein phức tạp.
  - Nêu được tính chất vật lí của protein: protein dạng sợi không tan trong nước, protein dạng hình cầu tan tạo dung dịch keo.
  - Trình bày được tính chất hoá học đặc trưng của protein: thuỷ phân, phản ứng màu biuret, phản ứng với nitric acid đặc, sự đông tụ bởi nhiệt, acid, base, ion kim loại nặng.
  - Mô tả hiện tượng và giải thích được thí nghiệm đông tụ lòng trắng trứng, phản ứng của lòng trắng trứng với HNO~3~ đặc; giải thích được hiện tượng đông tụ protein khi chế biến thực phẩm.
  - Nêu được vai trò của protein đối với sự sống; vai trò, đặc điểm xúc tác của enzyme và ứng dụng của enzyme trong công nghệ sinh học.
  - Giải được bài toán thuỷ phân protein (số gốc amino acid, phần trăm khối lượng, phân tử khối) và đọc được đồ thị hoạt tính enzyme theo nhiệt độ, pH.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Protein** = hợp chất **cao phân tử** gồm **một hay nhiều chuỗi polypeptide**. **Protein đơn giản** thuỷ phân chỉ cho α-amino acid; **protein phức tạp** = protein đơn giản + thành phần "phi protein" (nucleic acid, lipid…).
> 2. **Dạng sợi** (keratin, collagen, myosin) **không tan** trong nước. **Dạng hình cầu** (albumin, hemoglobin) **tan tạo dung dịch keo**.
> 3. **Thuỷ phân** (acid, base, enzyme) → cuối cùng là **α-amino acid**. **Biuret** Cu(OH)~2~/NaOH → **màu tím**. **HNO~3~ đặc** → **chất rắn màu vàng**.
> 4. **Đông tụ** bởi **nhiệt, acid, base, ion kim loại nặng** (Pb^2+^, Hg^2+^, Cu^2+^…) do cấu tạo ban đầu của protein bị phá vỡ: luộc trứng, nấu canh cua, làm sữa chua, đậu phụ.
> 5. **Enzyme**: phần lớn là **protein** xúc tác phản ứng sinh hoá; **chọn lọc cao**, **tốc độ rất lớn**, hoạt động mạnh nhất ở **nhiệt độ và pH tối ưu** (quá nóng → enzyme bị biến tính, mất hoạt tính).

Ở Bài 9, em đã nối các α-amino acid thành peptide. Nếu tiếp tục nối thêm hàng trăm, hàng nghìn đơn vị nữa, ta được những phân tử khổng lồ làm nên tóc, móng, cơ bắp, máu và cả các "cỗ máy" xúc tác trong tế bào. Đó là **protein**. Bài này trả lời ba câu hỏi: protein được cấu tạo thế nào, nó có những tính chất gì (vì sao luộc trứng thì lòng trắng đặc lại?), và enzyme, một loại protein đặc biệt, làm việc ra sao.

## 1. Protein: khái niệm và đặc điểm cấu tạo

### 1.1. Khái niệm

> [!nen-tang] Nhắc lại từ Bài 9
> - **Liên kết peptide** là nhóm –CO–NH– nối hai đơn vị **α-amino acid**.
> - Chuỗi có rất nhiều đơn vị α-amino acid gọi là **polypeptide**. Chuỗi có n gốc thì có **(n − 1) liên kết peptide**.
> - Mỗi chuỗi có **đầu N** (còn –NH~2~ tự do) và **đầu C** (còn –COOH tự do).

Hãy xem một protein nhỏ và nổi tiếng: **insulin**, hormone do tuyến tuỵ tiết ra để giúp tế bào hấp thụ glucose, giữ đường huyết ổn định (SGK tr. 46, Hình 10.1). Phân tử insulin gồm **hai chuỗi polypeptide**: chuỗi A có 21 đơn vị amino acid, chuỗi B có 30 đơn vị. Hai chuỗi được "khâu" vào nhau bằng các **cầu disulfide –S–S–** (tạo từ các gốc chứa lưu huỳnh). Dù là protein "nhỏ", insulin vẫn có phân tử khối khoảng 5 800, lớn hơn glucose (180) hơn 30 lần.

Từ ví dụ đó, ta có định nghĩa:

> **Protein** là hợp chất **cao phân tử** được cấu tạo từ **một hay nhiều chuỗi polypeptide**. Mỗi chuỗi polypeptide gồm các đơn vị **α-amino acid** nối với nhau bằng **liên kết peptide** theo **một trật tự xác định**.

**Vì sao chỉ khoảng 20 loại amino acid mà tạo ra được vô số protein khác nhau?** Hãy hình dung 20 loại amino acid như 20 chữ cái. Một protein là một "câu" dài hàng trăm chữ. Chỉ cần đổi **số lượng**, **loại** hay **trật tự** của một vài "chữ" là được một protein khác, với chức năng khác. Số cách sắp xếp như vậy gần như vô hạn.

![Hình 1. Từ amino acid đến protein: các α-amino acid nối thành chuỗi polypeptide; một hoặc nhiều chuỗi (có thể nối với nhau bằng cầu –S–S–) tạo thành phân tử protein](cau-tao.svg)

> [!em-co-biet] Các bậc cấu trúc của protein (mở rộng, SGK không yêu cầu)
> Chuỗi polypeptide không nằm duỗi thẳng mà còn cuộn xoắn, gấp nếp theo không gian. Sinh học thường mô tả 4 bậc: **bậc 1** là trình tự amino acid; **bậc 2** là đoạn mạch xoắn hoặc gấp nếp nhờ liên kết hydrogen; **bậc 3** là cả chuỗi cuộn lại thành khối; **bậc 4** là nhiều chuỗi ghép với nhau (như hemoglobin có 4 chuỗi). Chức năng của protein phụ thuộc vào **hình dạng không gian** này. Hiểu điều đó, em sẽ thấy dễ giải thích sự đông tụ (mục 3.3) và vì sao enzyme sợ nóng (mục 5.2).

> [!vi-du] Ví dụ 1
> Phân tử insulin gồm chuỗi A (21 đơn vị amino acid) và chuỗi B (30 đơn vị amino acid), hai chuỗi không nối với nhau bằng liên kết peptide.
>
> a) Một phân tử insulin có tổng cộng bao nhiêu đơn vị amino acid?
>
> b) Có bao nhiêu liên kết peptide trong một phân tử insulin?

> [!goi-y] Gợi ý 1
> Mỗi chuỗi được tính riêng: chuỗi có n gốc thì có (n − 1) liên kết peptide.

> [!goi-y] Gợi ý 2
> Cầu –S–S– nối hai chuỗi **không phải** liên kết peptide.

> [!loi-giai] Lời giải
> a) 21 + 30 = **51** đơn vị amino acid.
>
> b) Chuỗi A có 21 − 1 = 20 liên kết peptide, chuỗi B có 30 − 1 = 29. Tổng cộng: 20 + 29 = **49** liên kết peptide.
>
> (Nếu nhầm coi cả phân tử là một chuỗi 51 gốc thì sẽ ra 50, sai.)

### 1.2. Protein đơn giản và protein phức tạp

Dựa vào **sản phẩm thuỷ phân**, protein chia làm hai loại:

| Loại | Thành phần | Thuỷ phân hoàn toàn cho | Ví dụ |
|---|---|---|---|
| **Protein đơn giản** | Chỉ gồm các chuỗi polypeptide | Chỉ hỗn hợp **α-amino acid** | albumin (lòng trắng trứng), keratin, fibroin (tơ tằm) |
| **Protein phức tạp** | Protein đơn giản + thành phần **"phi protein"** | α-amino acid **và** các chất khác | nucleoprotein (kèm nucleic acid), lipoprotein (kèm lipid), hemoglobin (kèm nhóm chứa sắt) |

> [!bay]
> - "Protein phức tạp" **không** có nghĩa là protein có nhiều chuỗi hay phân tử khối lớn. Tiêu chí là **có thành phần phi protein** hay không. Insulin có 2 chuỗi nhưng vẫn là protein đơn giản.
> - Thuỷ phân hoàn toàn protein đơn giản chỉ thu được **α-amino acid**, không thu được β-, ε-amino acid hay peptide.

> [!vi-du] Ví dụ 2
> Hemoglobin (huyết sắc tố) chứa 0,34% sắt về khối lượng. Mỗi phân tử hemoglobin có 4 nguyên tử sắt. Tính phân tử khối gần đúng của hemoglobin.

> [!goi-y] Gợi ý 1
> Khối lượng sắt trong 1 mol hemoglobin là 4 · 56 = 224 g. Lượng này chiếm 0,34% của M.

> [!goi-y] Gợi ý 2
> Lập tỉ lệ: 224 = 0,34% · M.

> [!loi-giai] Lời giải
> M = 4 · 56 : 0,0034 ≈ **65 900**.
>
> Phân tử khối cỡ vài chục nghìn: đúng là hợp chất cao phân tử. Hemoglobin là protein phức tạp, vì ngoài phần protein còn có nhóm chứa sắt (nhóm heme).

## 2. Tính chất vật lí

Protein có hai hình dạng chính, và hình dạng quyết định protein có tan trong nước hay không:

- **Protein dạng hình sợi**: các chuỗi dài xếp song song, bện chặt vào nhau thành sợi. Ví dụ: **keratin** (tóc, móng, sừng), **collagen** (da, sụn, gân), **myosin** (cơ bắp). Loại này **không tan** trong nước và các dung môi thông thường.
- **Protein dạng hình cầu**: chuỗi cuộn gọn lại thành khối. Ví dụ: **albumin** (lòng trắng trứng), **hemoglobin** (máu). Loại này **tan được trong nước**, tạo thành **dung dịch keo**.

**Vì sao lại như vậy?** Protein dạng sợi có nhiệm vụ làm "khung đỡ" và bảo vệ, nên phải bền, không bị nước hoà tan. (Mở rộng:) Ở protein dạng hình cầu, phần lớn các nhóm phân cực, mang điện quay ra phía ngoài, hút các phân tử nước. Nhưng phân tử rất to, nên nó không tạo dung dịch thật như đường hay muối, mà phân tán thành **dung dịch keo**. Đó là lí do lòng trắng trứng khuấy với nước cho chất lỏng hơi sánh, đục nhẹ.

> [!ung-dung] Quan sát quanh em
> Tóc, móng tay ngâm nước cả ngày cũng không tan: đó là keratin, protein dạng sợi. Lòng trắng trứng sống hoà vào nước được: đó là albumin, protein dạng hình cầu. Hemoglobin cũng tan, nên nó đi theo máu để chở oxygen khắp cơ thể.

> [!bay]
> Đừng nói chung "protein tan tốt trong nước" hay "protein không tan trong nước". Phải xét **dạng sợi** (không tan) hay **dạng hình cầu** (tan tạo dung dịch keo).

## 3. Tính chất hoá học

### 3.1. Phản ứng thuỷ phân

Protein được tạo từ các chuỗi polypeptide, nên nó bị thuỷ phân **giống peptide** (Bài 9): nước cắt các liên kết peptide, xúc tác là **acid**, **base** hoặc **enzyme**. Quá trình đi **từng bước**:

=> Protein → polypeptide → … → peptide nhỏ → α-amino acid

**Thuỷ phân hoàn toàn** protein (đơn giản) thu được hỗn hợp các **α-amino acid**. Viết gọn cho một chuỗi n gốc:

=> Chuỗi polypeptide (n gốc) + (n − 1)H~2~O → n α-amino acid

Trong cơ thể, enzyme tiêu hoá cắt protein trong thức ăn thành amino acid: bắt đầu ở **dạ dày** (enzyme pepsin), rồi tiếp tục ở **ruột non** (enzyme trypsin và các enzyme khác). Amino acid được hấp thụ vào máu, rồi tế bào dùng chúng để "lắp" protein của chính cơ thể.

> [!meo] Hai công cụ cho bài toán thuỷ phân protein
> - **Số gốc amino acid X trong 1 phân tử protein** = n(X thu được) : n(protein).
> - **Khối lượng một gốc trong mạch** = M(amino acid) − 18. Ví dụ gốc Gly –NH–CH~2~–CO– có M = 57, gốc Ala có M = 71. Dùng để tính **phần trăm khối lượng gốc amino acid trong protein**.
> - Mạch protein rất dài nên số phân tử nước cần để thuỷ phân **gần bằng** số gốc amino acid (chỉ ít hơn một đơn vị cho mỗi chuỗi).

> [!vi-du] Ví dụ 3
> Thuỷ phân hoàn toàn 200 g protein X (phân tử khối 80 000) thu được 71,2 g alanine. Tính số gốc alanine trong một phân tử X.

> [!goi-y] Gợi ý 1
> Tính số mol X và số mol alanine (M = 89).

> [!goi-y] Gợi ý 2
> Mỗi phân tử X có k gốc Ala thì 1 mol X cho k mol Ala.

> [!loi-giai] Lời giải
> n(X) = 200 : 80 000 = 0,0025 mol; n(Ala) = 71,2 : 89 = 0,8 mol.
>
> Số gốc Ala trong một phân tử X = 0,8 : 0,0025 = **320**.

### 3.2. Phản ứng màu

**a) Phản ứng màu biuret.** Protein có rất nhiều liên kết peptide, nên giống tripeptide trở lên ở Bài 9, nó tác dụng với **Cu(OH)~2~ trong môi trường kiềm** (thuốc thử biuret) tạo **sản phẩm màu tím** đặc trưng. Ion Cu^2+^ tạo phức với các nguyên tử N của những liên kết peptide nằm gần nhau.

**b) Phản ứng với nitric acid đặc.** Nhỏ vài giọt dung dịch HNO~3~ đặc vào dung dịch lòng trắng trứng: xuất hiện **chất rắn màu vàng** (SGK tr. 47, Hình 10.2). Màu vàng này do **hai nguyên nhân** cùng lúc:

1. HNO~3~ **nitro hoá vòng benzene** trong các gốc amino acid có vòng thơm (như phenylalanine, tyrosine), tạo hợp chất nitro màu vàng.
2. Môi trường acid mạnh làm protein **đông tụ** (mục 3.3), nên sản phẩm tách ra ở dạng **rắn**.

> [!ung-dung] Vì sao HNO~3~ dây vào tay để lại vết vàng?
> Da tay chứa protein (keratin, collagen) có các gốc mang vòng benzene. Lỡ dây HNO~3~ đặc lên da sẽ thấy vết **vàng**, và vết này không rửa được, phải đợi lớp da mới thay thế. Đây cũng là lời nhắc: làm thí nghiệm với acid đặc phải đeo găng tay và kính bảo hộ.

> [!bay]
> - Protein + Cu(OH)~2~/NaOH cho màu **tím**, **không** phải dung dịch xanh lam. Màu xanh lam là của các chất có nhiều nhóm –OH kề nhau (glucose, saccharose, glycerol). Đây chính là dạng câu "phát biểu nào không đúng" ở phần Luyện tập của Bài 11 (SGK tr. 50).
> - Màu vàng với HNO~3~ không chỉ do đông tụ, mà **một phần** do phản ứng nitro hoá vòng benzene.

> [!vi-du] Ví dụ 4
> Có ba ống nghiệm không nhãn, đựng ba dung dịch: lòng trắng trứng, glucose, hồ tinh bột. Chỉ dùng **một** thuốc thử, hãy nhận biết từng dung dịch.

> [!goi-y] Gợi ý 1
> Thuốc thử nào cho màu khác nhau với protein (tím) và với chất có nhiều nhóm –OH kề nhau (xanh lam)?

> [!goi-y] Gợi ý 2
> Tinh bột có hoà tan Cu(OH)~2~ không? (Bài 6.)

> [!loi-giai] Lời giải
> Dùng Cu(OH)~2~ trong môi trường kiềm (cho NaOH vào CuSO~4~ để tạo Cu(OH)~2~), lắc ở nhiệt độ thường:
> - Ống có **màu tím**: lòng trắng trứng (phản ứng biuret).
> - Ống Cu(OH)~2~ tan, tạo **dung dịch xanh lam**: glucose.
> - Ống **không có hiện tượng** (Cu(OH)~2~ không tan): hồ tinh bột.

### 3.3. Sự đông tụ

**Thí nghiệm (SGK tr. 47).** Lấy hai ống nghiệm, mỗi ống chứa khoảng 2 mL dung dịch lòng trắng trứng.

- Ống (1): hơ nóng trên ngọn lửa đèn cồn 2–3 phút. Dung dịch **đục dần rồi đông lại thành khối màu trắng**.
- Ống (2): nhỏ vài giọt HNO~3~ đặc. Xuất hiện **chất rắn màu vàng** (đông tụ kèm nitro hoá, mục 3.2b).

**Giải thích.** Protein dạng hình cầu tan được là nhờ chuỗi polypeptide cuộn gọn theo một hình dạng nhất định, với các nhóm ưa nước hướng ra ngoài. Khi gặp **nhiệt**, **acid**, **base** hoặc **ion kim loại nặng** (Pb^2+^, Hg^2+^, Cu^2+^…), hình dạng ban đầu này **bị phá vỡ**. Các chuỗi duỗi ra, rối vào nhau và dính lại thành mảng, không còn hoà tan được trong nước nữa. Protein **tách ra khỏi dung dịch** thành chất rắn. Hiện tượng đó gọi là **sự đông tụ**.

![Hình 2. Sự đông tụ: protein hình cầu (tan) bị nhiệt, acid, base hay ion kim loại nặng phá vỡ cấu tạo ban đầu; các chuỗi duỗi ra, kết dính và tách khỏi dung dịch](dong-tu.svg)

> [!ghi-nho] Bốn tác nhân gây đông tụ protein
> **Nhiệt** – **acid** – **base** – **ion kim loại nặng**.

> [!bay]
> - Đông tụ **không phải** thuỷ phân. Khi đông tụ, các **liên kết peptide vẫn còn nguyên**; chỉ có hình dạng không gian của phân tử bị phá. Thuỷ phân mới cắt liên kết peptide thành amino acid.
> - Đông tụ do nhiệt **không trở lại** như cũ: trứng đã luộc, để nguội, cho vào nước khuấy kĩ vẫn không tan lại thành dung dịch.
> - Dung dịch glucose, nước cất, dung dịch NaCl loãng **không** làm đông tụ lòng trắng trứng.

> [!ung-dung] Đông tụ protein trong bếp nhà em
> - **Luộc trứng, rán trứng**: lòng trắng trong suốt chuyển sang trắng đục và đặc lại (đông tụ do nhiệt).
> - **Nấu canh cua**: cua giã, lọc lấy nước, nước này chứa protein tan. Khi đun, protein đông tụ, kết thành mảng xốp, nhẹ, **nổi lên** thành "riêu cua".
> - **Làm sữa chua**: vi khuẩn lactic lên men đường trong sữa thành **lactic acid**. Môi trường chua làm protein sữa (casein) đông tụ nên sữa **đặc sánh** lại.
> - **Làm đậu phụ**: đun sữa đậu nành rồi cho **nước chua** (hoặc chất làm đông) vào; protein đậu nành đông tụ, ép thành bánh đậu.
> - **Gỏi cá trộn chanh**: thịt cá sống chuyển sang màu trắng đục như đã chín, do acid trong chanh làm protein đông tụ (dù vi khuẩn, kí sinh trùng không chắc đã bị tiêu diệt hết).

> [!ung-dung] Vì sao muối kim loại nặng rất độc?
> Ion Pb^2+^, Hg^2+^, Cu^2+^… làm đông tụ protein, kể cả enzyme trong cơ thể, khiến enzyme mất khả năng xúc tác. Khi bị ngộ độc muối kim loại nặng qua đường ăn uống, một cách sơ cứu là cho uống **sữa** hoặc **lòng trắng trứng sống**. Protein trong đó "hứng" ion kim loại nặng và đông tụ trước, làm giảm lượng ion tấn công cơ thể. Sau đó phải đưa người bệnh đến cơ sở y tế ngay.

> [!vi-du] Ví dụ 5
> Cho dung dịch lòng trắng trứng vào bốn ống nghiệm. Ống (1) đun nóng; ống (2) thêm dung dịch CuSO~4~; ống (3) thêm dung dịch glucose; ống (4) thêm vài giọt HNO~3~ đặc. Ống nào có protein bị đông tụ? Ống nào cho chất rắn màu vàng?

> [!goi-y] Gợi ý 1
> Đối chiếu với bốn tác nhân: nhiệt, acid, base, ion kim loại nặng. Cu^2+^ có phải ion kim loại nặng không?

> [!goi-y] Gợi ý 2
> Màu vàng cần phản ứng nitro hoá vòng benzene.

> [!loi-giai] Lời giải
> - Ống (1): đông tụ do **nhiệt** → khối trắng.
> - Ống (2): đông tụ do ion kim loại nặng **Cu^2+^** → kết tủa.
> - Ống (3): glucose **không** làm đông tụ protein → không có hiện tượng.
> - Ống (4): đông tụ do acid, kèm nitro hoá → **chất rắn màu vàng**.
>
> Vậy ống (1), (2), (4) có đông tụ; chỉ ống (4) cho chất rắn màu vàng.

## 4. Vai trò của protein đối với sự sống

Gần như mọi hoạt động sống đều có protein tham gia. Có thể chia các vai trò thành mấy nhóm:

| Vai trò | Ví dụ |
|---|---|
| Xây dựng tế bào, mô | collagen trong da, sụn; keratin trong tóc, móng |
| Vận chuyển các chất | hemoglobin chở oxygen trong máu |
| Điều hoà trao đổi chất | hormone insulin điều hoà đường huyết |
| Xúc tác phản ứng sinh hoá | các **enzyme** (mục 5) |
| Bảo vệ cơ thể | kháng thể chống lại vi khuẩn, virus |
| Vận động | myosin, actin giúp cơ co |

Với con người, protein là **một trong những nguồn thức ăn chính**. Thức ăn giàu protein (thịt, cá, trứng, sữa, đậu đỗ) cung cấp các **amino acid thiết yếu** mà cơ thể không tự tổng hợp được (Bài 9), đồng thời cung cấp năng lượng.

> [!ung-dung] Chọn nguồn protein cho bữa ăn
> - Protein **động vật** (thịt, cá, trứng, sữa) thường có đủ các amino acid thiết yếu.
> - Protein **thực vật** (đậu nành, đậu xanh, lạc, gạo…) thường thiếu một vài amino acid thiết yếu, nhưng ăn **phối hợp** (cơm + đậu, xôi đậu) sẽ bù được cho nhau. Đậu nành là nguồn protein thực vật rất tốt.
> - Ăn cá, đậu thay bớt thịt đỏ giúp giảm chất béo bão hoà. Trẻ đang lớn, người ốm mới khỏi, người tập luyện cần nhiều protein hơn.

## 5. Enzyme

### 5.1. Khái niệm và vai trò

Ở các bài trước, em đã gặp nhiều phản ứng có **enzyme** làm xúc tác: thuỷ phân tinh bột, lên men glucose, thuỷ phân peptide. Vậy enzyme là gì?

> **Enzyme** là những chất, **phần lớn có bản chất là protein**, có khả năng **xúc tác** cho các phản ứng hoá học và sinh hoá, đặc biệt là trong cơ thể sinh vật.

Tên enzyme thường có đuôi **-ase**, gắn với chất hoặc kiểu phản ứng mà nó xúc tác: **amylase** cắt tinh bột (amylum), **lipase** thuỷ phân chất béo (lipid), **protease** thuỷ phân protein, **lactase** thuỷ phân lactose…

Không có enzyme, các phản ứng trong cơ thể ở 37 °C sẽ xảy ra quá chậm để duy trì sự sống. Enzyme giúp chúng xảy ra nhanh, đúng lúc, đúng chỗ.

> [!vi-du] Ví dụ 6
> Viết phương trình hoá học của ba phản ứng có enzyme làm xúc tác mà em đã học ở chương Carbohydrate và Bài 9.

> [!goi-y] Gợi ý 1
> Tinh bột trong miệng gặp enzyme nào? Glucose biến thành rượu nhờ gì?

> [!goi-y] Gợi ý 2
> Peptide thuỷ phân cũng có thể dùng xúc tác enzyme.

> [!loi-giai] Lời giải
> Ba ví dụ (còn có thể chọn phản ứng khác):
>
> => (C~6~H~10~O~5~)~n~ + nH~2~O → nC~6~H~12~O~6~    (enzyme)
>
> (Amylase cắt tinh bột chủ yếu thành maltose; maltose được enzyme maltase thuỷ phân tiếp thành glucose. Viết gộp thì ghi xúc tác là "enzyme".)
>
> => C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~    (enzyme, lên men rượu)
>
> => Gly-Ala + H~2~O → H~2~N–CH~2~–COOH + CH~3~–CH(NH~2~)–COOH    (enzyme)
>
> Ngoài ra: thuỷ phân saccharose thành glucose và fructose cũng có enzyme xúc tác.

### 5.2. Đặc điểm của xúc tác enzyme

**a) Tính chọn lọc cao.** Mỗi enzyme chỉ xúc tác cho **một hoặc một số ít phản ứng nhất định**. Amylase cắt được tinh bột nhưng "bó tay" với protein. Cơ thể người có enzyme cắt liên kết α-1,4-glycoside của tinh bột, nhưng không có enzyme cắt liên kết β-1,4-glycoside của cellulose, nên ta không tiêu hoá được cellulose (Bài 6).

**Vì sao chọn lọc như vậy?** (Mô hình mở rộng, dễ hình dung.) Mỗi enzyme có một vùng nhỏ gọi là **trung tâm hoạt động**, hình dạng của nó vừa khít với chất phản ứng (cơ chất) riêng của enzyme đó, giống **chìa khoá vừa ổ khoá**. Chất khác không "khớp" thì không được xúc tác.

![Hình 3. Mô hình "ổ khoá – chìa khoá": cơ chất vừa khít trung tâm hoạt động thì được enzyme biến đổi thành sản phẩm; chất khác không khớp nên không phản ứng](enzyme.svg)

**b) Hiệu quả xúc tác rất cao.** Tốc độ phản ứng có enzyme xúc tác thường **nhanh hơn rất nhiều lần** (có thể hàng triệu lần trở lên) so với cùng phản ứng đó dùng xúc tác hoá học thông thường. Lại chỉ cần một lượng enzyme rất nhỏ, ở nhiệt độ cơ thể và áp suất thường. Ví dụ: thuỷ phân tinh bột bằng acid cần đun nóng lâu, còn amylase trong nước bọt cắt tinh bột ngay trong miệng ở 37 °C.

**c) Nhiệt độ và pH tối ưu** (SGK chỉ nêu gián tiếp; đây là kiến thức hay gặp trong đề thi). Vì phần lớn enzyme là protein, nên hoạt tính của nó phụ thuộc mạnh vào điều kiện môi trường:

- **Nhiệt độ**: khi tăng nhiệt độ, phản ứng nhanh dần, đến một giá trị **nhiệt độ tối ưu** thì enzyme hoạt động mạnh nhất (enzyme người khoảng 37 °C). Tăng tiếp, enzyme bắt đầu bị **biến tính** (đông tụ do nhiệt, mục 3.3), hoạt tính **giảm nhanh**. Ở khoảng 60–70 °C hầu hết enzyme người **mất hoạt tính**, và để nguội cũng không hồi phục.
- **pH**: mỗi enzyme có một **pH tối ưu** riêng. Pepsin ở dạ dày hoạt động mạnh nhất ở môi trường rất acid (pH khoảng 2). Amylase nước bọt thích môi trường gần trung tính (pH khoảng 7). Trypsin ở ruột non thích môi trường hơi kiềm (pH khoảng 8). Lệch xa pH tối ưu, enzyme hoạt động yếu hoặc ngừng hẳn (acid, base cũng làm protein biến tính).

![Hình 4. Hoạt tính enzyme: a) theo nhiệt độ (enzyme người); b) theo pH (pepsin, amylase nước bọt, trypsin). Số liệu minh hoạ](hoat-tinh.svg)

> [!meo] Đọc đồ thị hoạt tính enzyme
> 1. **Đỉnh** đồ thị ứng với nhiệt độ hoặc pH **tối ưu**.
> 2. Theo nhiệt độ, đồ thị **không đối xứng**: bên trái lên từ từ (phản ứng nhanh dần khi nóng lên), bên phải **tụt rất nhanh** (enzyme bị biến tính).
> 3. Ở nhiệt độ thấp, enzyme chỉ hoạt động chậm, **không bị phá huỷ**: làm ấm lên thì hoạt động trở lại. Ở nhiệt độ quá cao, enzyme **bị phá huỷ**: làm nguội cũng không hồi phục. Đây là lí do bảo quản thực phẩm trong tủ lạnh, còn khử trùng thì đun sôi.

> [!vi-du] Ví dụ 7
> Dựa vào Hình 4a, trả lời:
>
> a) Enzyme hoạt động mạnh nhất ở nhiệt độ nào?
>
> b) So sánh hoạt tính ở 30 °C và ở 50 °C.
>
> c) Một mẫu enzyme được giữ ở 70 °C trong 10 phút rồi làm nguội về 37 °C. Hoạt tính lúc này thế nào? Một mẫu khác giữ ở 5 °C rồi làm ấm về 37 °C thì sao?

> [!goi-y] Gợi ý 1
> Tìm đỉnh đường cong và đọc các giá trị trên trục tung.

> [!goi-y] Gợi ý 2
> Nhiệt độ nào phá huỷ cấu tạo của enzyme (protein), nhiệt độ nào chỉ làm nó "chậm lại"?

> [!loi-giai] Lời giải
> a) Đỉnh đồ thị ở khoảng **37 °C**: nhiệt độ tối ưu.
>
> b) Ở 30 °C hoạt tính khoảng 78%, còn ở 50 °C chỉ khoảng 12%. Để so sánh công bằng, xét hai điểm cách đều 37 °C: ở 30 °C (thấp hơn 7 °C) hoạt tính còn khoảng 78%, còn ở 44 °C (cao hơn 7 °C) đồ thị đã tụt xuống khoảng 55%. Phía nhiệt độ cao hoạt tính giảm nhanh hơn hẳn, vì nhiệt độ cao làm enzyme bị biến tính.
>
> c) Sau khi ở 70 °C, enzyme đã bị **biến tính** (đông tụ), nên làm nguội về 37 °C hoạt tính **gần như bằng 0**. Mẫu ở 5 °C chỉ hoạt động chậm chứ không hỏng, làm ấm về 37 °C thì hoạt tính **trở lại gần 100%**.

### 5.3. Ứng dụng của enzyme trong công nghệ sinh học

Ngoài vai trò trong cơ thể, enzyme được con người khai thác ở nhiều ngành (SGK tr. 48):

- **Công nghiệp thực phẩm** (sản xuất, chế biến, bảo quản):
  - Amylase thuỷ phân tinh bột để nấu **mạch nha**, sản xuất glucose, bia, rượu.
  - Protease làm **mềm thịt**: đu đủ xanh (chứa papain), dứa (chứa bromelain) ướp thịt bò giúp thịt mềm hơn.
  - Lactase tạo ra **sữa không lactose** cho người không tiêu hoá được đường sữa.
  - Enzyme giúp làm trong nước quả, sản xuất nước mắm, tương, phô mai.
- **Công nghiệp dược phẩm**: sản xuất **enzyme thay thế** cho người thiếu enzyme (ví dụ thuốc hỗ trợ tiêu hoá chứa amylase, lipase, protease), enzyme vận chuyển thuốc, enzyme xúc tác một số giai đoạn sản xuất thuốc.
- **Kĩ thuật di truyền**: enzyme dùng để **cắt, nối** DNA, tạo ra thông tin di truyền mới hoặc sửa đổi thông tin di truyền có sẵn (em sẽ gặp lại ở Sinh học 12, phần công nghệ gene).
- **Đời sống hằng ngày**: **bột giặt sinh học** chứa protease (cắt vết máu, sữa, mồ hôi, là các chất protein) và lipase (cắt vết dầu mỡ).

> [!ung-dung] Dùng bột giặt sinh học cho đúng
> - Giặt bằng nước **ấm** (khoảng 30–40 °C) là tốt nhất. Nước **sôi** làm enzyme bị biến tính, mất tác dụng.
> - **Không** nên dùng giặt đồ **len, lụa tơ tằm**: len (keratin) và tơ tằm (fibroin) đều là **protein**, protease sẽ "ăn mòn" sợi vải.
> - Vết máu nên ngâm **nước lạnh** trước khi giặt. Nước nóng làm protein trong máu đông tụ, bám chặt vào sợi vải, khó tẩy hơn.

> [!em-co-biet] Enzyme trong nghề truyền thống
> Ông cha ta dùng enzyme từ rất lâu mà chưa biết tên: ủ men làm rượu, làm tương, nấu mạch nha từ mầm thóc (mầm thóc chứa nhiều amylase), muối cá làm nước mắm (enzyme trong ruột cá thuỷ phân protein thành amino acid tạo vị đậm).

## Dạng bài thi hay gặp

### Dạng 1. Đúng/Sai tổng hợp về protein – enzyme

**Nhận biết:** đề cho 4 phát biểu (hoặc một thí nghiệm kèm 4 ý) về khái niệm, phân loại, tính tan, phản ứng màu, đông tụ, thuỷ phân, enzyme. Đây là dạng **rất hay ra**.

**Phương pháp:** soát từng ý theo danh sách từ khoá:

1. Protein **đơn giản/phức tạp**: tiêu chí là có thành phần phi protein hay không.
2. **Tan hay không tan**: dạng sợi (keratin, collagen, myosin) không tan; dạng cầu (albumin, hemoglobin) tan → dung dịch keo.
3. **Màu**: biuret → **tím** (không phải xanh lam); HNO~3~ đặc → **rắn vàng** (nitro hoá + đông tụ). Dipeptide và amino acid không có màu biuret.
4. **Đông tụ**: 4 tác nhân nhiệt, acid, base, ion kim loại nặng; không cắt liên kết peptide.
5. **Thuỷ phân hoàn toàn** → α-amino acid.
6. **Enzyme**: phần lớn là protein; chọn lọc cao; nhanh hơn xúc tác hoá học nhiều lần; có nhiệt độ, pH tối ưu ("càng nóng càng tốt" là **sai**).

> [!vi-du] Ví dụ 8 (Đúng/Sai)
> Xét các phát biểu:
>
> a) Thuỷ phân hoàn toàn protein đơn giản thu được hỗn hợp các α-amino acid.
>
> b) Collagen trong da, sụn tan tốt trong nước tạo dung dịch keo.
>
> c) Khi đun nóng lòng trắng trứng, protein đông tụ vì các liên kết peptide bị cắt đứt.
>
> d) Mỗi enzyme thường chỉ xúc tác cho một hoặc một số phản ứng nhất định.

> [!goi-y] Gợi ý 1
> Collagen thuộc dạng sợi hay dạng cầu?

> [!goi-y] Gợi ý 2
> Đông tụ phá vỡ cái gì: hình dạng không gian hay liên kết peptide?

> [!loi-giai] Lời giải
> a) **Đúng**.
>
> b) **Sai**: collagen là protein dạng sợi, không tan trong nước.
>
> c) **Sai**: đông tụ chỉ phá vỡ cấu tạo (hình dạng) ban đầu; liên kết peptide vẫn còn. Cắt liên kết peptide là thuỷ phân.
>
> d) **Đúng**: đó là tính chọn lọc cao của enzyme.

### Dạng 2. Giải thích hiện tượng thực tế

**Nhận biết:** đề kể một hiện tượng trong đời sống (nấu ăn, làm sữa chua, sơ cứu ngộ độc, giặt giũ, bảo quản thực phẩm) và hỏi nguyên nhân, hoặc phát biểu nào giải thích đúng.

**Phương pháp:**

1. Xác định chất chính là **protein** hay **enzyme**.
2. Tìm **tác nhân**: nhiệt? acid (chanh, giấm, lactic acid)? base? ion kim loại nặng? Có tác nhân → nghĩ đến **đông tụ**.
3. Nếu là enzyme: xét **nhiệt độ, pH** có gần tối ưu không, và enzyme có **đúng** cơ chất không.

| Hiện tượng | Giải thích |
|---|---|
| Luộc trứng, nấu canh cua (riêu nổi) | Protein đông tụ do **nhiệt** |
| Sữa chua đặc lại; làm đậu phụ bằng nước chua | Protein đông tụ do **acid** |
| Uống sữa, lòng trắng trứng khi ngộ độc muối chì, thuỷ ngân | Protein trong sữa, trứng **đông tụ với ion kim loại nặng**, giảm ion tấn công cơ thể |
| HNO~3~ dây vào da → vàng | Nitro hoá vòng benzene trong protein của da + đông tụ |
| Nhai cơm lâu thấy ngọt | Amylase nước bọt thuỷ phân tinh bột → maltose |
| Bột giặt sinh học dùng nước ấm, không giặt len, lụa | Enzyme mất hoạt tính khi quá nóng; len, lụa là protein |
| Thực phẩm để tủ lạnh lâu hỏng | Nhiệt độ thấp làm enzyme (của vi khuẩn và của thực phẩm) hoạt động chậm |

> [!vi-du] Ví dụ 9
> Bạn Nam làm nước dứa tươi rồi trộn vào hỗn hợp gelatin (một loại protein lấy từ collagen) để làm thạch, để tủ lạnh mãi mà thạch không đông. Bạn Mai đun sôi nước dứa vài phút, để nguội rồi mới trộn, thì thạch đông bình thường. Giải thích.

> [!goi-y] Gợi ý 1
> Quả dứa chứa enzyme bromelain thuộc loại protease. Protease cắt gì?

> [!goi-y] Gợi ý 2
> Đun sôi ảnh hưởng thế nào tới enzyme?

> [!loi-giai] Lời giải
> Dứa tươi chứa **bromelain**, một enzyme protease. Nó **thuỷ phân** gelatin (protein) thành các mạch peptide ngắn, nên không tạo được mạng lưới để thạch đông lại.
>
> Khi đun sôi, bromelain (cũng là protein) bị **biến tính do nhiệt**, mất hoạt tính, không cắt gelatin nữa, nên thạch của Mai đông bình thường.
>
> (Cũng vì lí do này, người ta ướp thịt bò với dứa để thịt mềm hơn.)

> [!bay]
> - Phân biệt **"đông tụ"** (protein bị phá hình dạng, kết tủa) với **"thuỷ phân"** (protein bị cắt thành phần nhỏ). Ví dụ 9 là **thuỷ phân** nhờ enzyme, không phải đông tụ.
> - Nhiệt độ thấp chỉ làm enzyme **chậm lại**, không phá huỷ enzyme.

### Dạng 3. Bài toán thuỷ phân protein

**Nhận biết:** đề cho khối lượng protein, phân tử khối hoặc % khối lượng một nguyên tố, khối lượng amino acid thu được; hỏi phân tử khối, số gốc amino acid, phần trăm khối lượng.

**Phương pháp:**

1. **Phân tử khối từ % nguyên tố**: nếu mỗi phân tử có k nguyên tử X thì M = k · A(X) : %X.
2. **Số gốc amino acid**: số gốc = n(amino acid) : n(protein).
3. **% khối lượng gốc amino acid trong protein**: dùng **M gốc = M(amino acid) − 18** (gốc Gly 57, gốc Ala 71, gốc Val 99).
4. **Bảo toàn khối lượng**: m(amino acid) = m(protein) + m(H~2~O); với một chuỗi N gốc thì cần (N − 1) H~2~O.
5. **Từ nitrogen ra protein**: đa số protein chứa khoảng 16% N về khối lượng, nên m(protein) ≈ m(N) : 0,16 = 6,25 · m(N). (Mở rộng, dùng trong kiểm nghiệm thực phẩm; đề sẽ cho sẵn tỉ lệ.)

> [!vi-du] Ví dụ 10
> Thuỷ phân hoàn toàn 40 g một protein X chỉ thu được các α-amino acid, trong đó có 12 g glycine và 8,9 g alanine. Tính phần trăm khối lượng các gốc glycine và các gốc alanine trong X.

> [!goi-y] Gợi ý 1
> Trong mạch protein, glycine tồn tại dưới dạng **gốc** –NH–CH~2~–CO–, đã mất một phân tử H~2~O so với amino acid tự do.

> [!goi-y] Gợi ý 2
> Số mol gốc = số mol amino acid thu được. Khối lượng gốc Gly = 75 − 18 = 57; gốc Ala = 89 − 18 = 71.

> [!loi-giai] Lời giải
> n(Gly) = 12 : 75 = 0,16 mol; n(Ala) = 8,9 : 89 = 0,1 mol.
>
> %gốc Gly = 0,16 · 57 : 40 · 100% = **22,8%**.
>
> %gốc Ala = 0,1 · 71 : 40 · 100% = **17,75%**.
>
> (Nếu lấy thẳng 12 : 40 = 30% là sai, vì 12 g glycine đã bao gồm phần nước lấy thêm khi thuỷ phân.)

> [!bay]
> - Dùng M **amino acid** thay cho M **gốc** khi tính % trong protein → kết quả lớn hơn đáp án.
> - Insulin hay protein nhiều chuỗi: đếm liên kết peptide **theo từng chuỗi**.
> - Thuỷ phân **lấy thêm nước**, nên tổng khối lượng amino acid **lớn hơn** khối lượng protein ban đầu.

### Dạng 4. Đọc đồ thị, bảng số liệu hoạt tính enzyme

**Nhận biết:** đề cho đồ thị hoặc bảng: hoạt tính (hay tốc độ phản ứng, thời gian phản ứng) của enzyme theo nhiệt độ hoặc pH. Hỏi điều kiện tối ưu, so sánh, dự đoán khi đổi môi trường.

**Phương pháp:**

1. Xác định **đại lượng** trên trục: hoạt tính (càng lớn càng tốt) hay **thời gian phản ứng** (càng **nhỏ** thì enzyme càng mạnh).
2. Tìm đỉnh (hoặc đáy, nếu là thời gian) → giá trị tối ưu.
3. Liên hệ nơi enzyme làm việc: dạ dày pH ≈ 2, miệng pH ≈ 7, ruột non pH ≈ 8; cơ thể người 37 °C.
4. Nhớ: quá nóng → biến tính, **không hồi phục**; lạnh → chậm, **hồi phục** khi ấm lên.

> [!vi-du] Ví dụ 11
> Người ta trộn hồ tinh bột với dung dịch amylase ở các nhiệt độ khác nhau, rồi đo thời gian đến khi nhỏ iodine **không còn** màu xanh tím (tinh bột đã bị thuỷ phân hết).
>
> | Nhiệt độ (°C) | 20 | 30 | 40 | 50 | 60 | 80 |
> |---|---|---|---|---|---|---|
> | Thời gian (phút) | 12 | 6 | 3 | 5 | 15 | vẫn còn màu sau 60 phút |
>
> a) Ở nhiệt độ nào trong bảng, amylase hoạt động mạnh nhất?
>
> b) Vì sao ở 80 °C tinh bột gần như không bị thuỷ phân?

> [!goi-y] Gợi ý 1
> Enzyme càng mạnh thì tinh bột bị thuỷ phân hết càng **nhanh**: thời gian càng ngắn.

> [!goi-y] Gợi ý 2
> Amylase có bản chất là gì? Protein gặp nhiệt độ cao thì sao?

> [!loi-giai] Lời giải
> a) Thời gian ngắn nhất là 3 phút, ở **40 °C**: enzyme hoạt động mạnh nhất trong các nhiệt độ khảo sát.
>
> b) Amylase là protein. Ở 80 °C nó bị **biến tính** (đông tụ do nhiệt), mất hoạt tính xúc tác, nên tinh bột hầu như không bị thuỷ phân và iodine vẫn cho màu xanh tím.

> [!bay]
> Đọc nhầm trục: nếu đề cho **thời gian** phản ứng thì giá trị **nhỏ nhất** mới là tối ưu, không phải giá trị lớn nhất.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Khái niệm | Protein: hợp chất cao phân tử gồm **một hay nhiều chuỗi polypeptide** (α-amino acid nối bằng liên kết peptide theo trật tự xác định) |
| Phân loại | **Đơn giản**: thuỷ phân chỉ cho α-amino acid. **Phức tạp**: thêm thành phần phi protein (nucleic acid, lipid…) |
| Tính tan | Dạng sợi (keratin, collagen, myosin): không tan. Dạng cầu (albumin, hemoglobin): tan → dung dịch keo |
| Thuỷ phân | Acid, base, enzyme; từng bước; hoàn toàn → α-amino acid |
| Biuret | Cu(OH)~2~/NaOH → **tím** |
| HNO~3~ đặc | **Rắn vàng** (nitro hoá vòng benzene + đông tụ) |
| Đông tụ | Nhiệt, acid, base, ion kim loại nặng; phá vỡ cấu tạo ban đầu, liên kết peptide còn nguyên |
| Vai trò | Xây dựng tế bào, vận chuyển, điều hoà, xúc tác, bảo vệ; nguồn amino acid thiết yếu và năng lượng |
| Enzyme | Phần lớn là protein; **chọn lọc cao**; **nhanh hơn rất nhiều** xúc tác hoá học; có **nhiệt độ, pH tối ưu** |
| Ứng dụng enzyme | Thực phẩm (mạch nha, làm mềm thịt, sữa không lactose), dược phẩm (enzyme thay thế), kĩ thuật di truyền, bột giặt sinh học |

**Các công thức dùng trong tính toán:**

- Số liên kết peptide = Σ(số gốc mỗi chuỗi − 1).
- M(protein) = k · A(X) : %X (k nguyên tử X trong mỗi phân tử).
- Số gốc amino acid trong 1 phân tử = n(amino acid) : n(protein).
- M gốc trong mạch = M(amino acid) − 18 (Gly 57, Ala 71, Val 99).
- m(amino acid) = m(protein) + m(H~2~O).
