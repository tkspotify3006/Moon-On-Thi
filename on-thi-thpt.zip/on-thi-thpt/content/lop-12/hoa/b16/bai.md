---
title: Điện phân
thoi-gian: 50 phút
muc-tieu:
  - Hiểu điện phân là quá trình oxi hoá – khử xảy ra ở các điện cực nhờ dòng điện một chiều, phân biệt được điện phân với pin điện hoá.
  - Trình bày được nguyên tắc (thứ tự) điện phân nóng chảy và điện phân dung dịch: ở anode chất khử mạnh hơn bị oxi hoá trước, ở cathode chất oxi hoá mạnh hơn bị khử trước.
  - Viết được các quá trình ở điện cực và phương trình điện phân dung dịch CuSO~4~, NaCl (có và không có màng ngăn, tự điều chế nước Javel) và các muối khác.
  - Trình bày được giai đoạn điện phân aluminium oxide nóng chảy trong sản xuất nhôm, tinh luyện đồng bằng điện phân, mạ điện. Nêu được ứng dụng của điện phân trong thực tiễn.
  - (Mở rộng, đề thi hay dùng) Tính được khối lượng chất, thể tích khí, thời gian điện phân theo công thức n~e~ = It/F.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Điện phân** dùng dòng điện một chiều để ép một phản ứng oxi hoá – khử **không tự xảy ra** phải xảy ra. Điện năng chuyển thành hoá năng (ngược với pin).
> 2. Trong bình điện phân: **cathode là cực âm**, nơi xảy ra **sự khử**. **Anode là cực dương**, nơi xảy ra **sự oxi hoá**. Cation chạy về cathode, anion chạy về anode.
> 3. **Thứ tự:** ở cathode, chất oxi hoá mạnh hơn bị khử trước (Ag^+^ > Cu^2+^ > H^+^ > H~2~O). Ở anode, chất khử mạnh hơn bị oxi hoá trước (I^−^ > Br^−^ > Cl^−^ > H~2~O). Na^+^, K^+^, Mg^2+^, Al^3+^ và SO~4~^2−^, NO~3~^−^, F^−^ coi như không bị điện phân trong dung dịch.
> 4. **Ứng dụng:** điều chế kim loại (Na, Mg, Al bằng điện phân **nóng chảy**; Zn, Cu bằng điện phân dung dịch), **tinh chế đồng** (anode đồng thô tan dần), **mạ điện** (vật cần mạ làm cathode).
> 5. **Tính toán (mở rộng, ngoài SGK):** số mol electron trao đổi $n_e = \dfrac{It}{F}$ với F = 96 500 C/mol. Chia n~e~ lần lượt cho các quá trình theo đúng thứ tự.

> [!nen-tang] Nhắc lại từ Bài 15 và Hoá 10
> - **Chất khử** nhường electron (bị oxi hoá). **Chất oxi hoá** nhận electron (bị khử).
> - **Thế điện cực chuẩn E°** càng lớn thì dạng oxi hoá càng dễ bị khử (Ag^+^ > Cu^2+^ > 2H^+^ > … > Na^+^). E° càng nhỏ thì dạng khử càng dễ bị oxi hoá.
> - Trong **pin Galvani**, phản ứng tự xảy ra sinh ra dòng điện. Anode là nơi oxi hoá, cathode là nơi khử. Quy ước này **giữ nguyên** trong bình điện phân, chỉ có dấu của điện cực là đổi.
> - Chất điện li (NaCl, CuSO~4~…) khi **nóng chảy** hoặc **tan trong nước** đều phân li ra ion chuyển động tự do, nên dẫn được điện.

## 1. Hiện tượng điện phân

### 1.1. Khái niệm

Ở Bài 15, em đã thấy phản ứng Zn + Cu^2+^ **tự xảy ra** và có thể "bắt" electron chạy qua dây dẫn để sinh ra dòng điện. Còn phản ứng ngược lại, ví dụ tách muối ăn thành kim loại natri và khí chlorine, thì **không bao giờ tự xảy ra**. Natri cháy trong chlorine rất mãnh liệt, chứ NaCl không tự tách ra. Muốn tách, ta phải **bơm năng lượng điện** vào. Đó là ý tưởng của điện phân.

**Thí nghiệm điện phân NaCl nóng chảy** (SGK tr. 78). Nung NaCl đến nóng chảy (khoảng 800 °C), nhúng vào đó hai thanh than chì nối với hai cực của nguồn điện một chiều khoảng 7 V.

- Khi nóng chảy, mạng tinh thể bị phá vỡ, các ion chuyển động tự do: NaCl → Na^+^ + Cl^−^.
- Khi có điện, cation **Na^+^ bị hút về cực âm**, anion **Cl^−^ bị hút về cực dương** (trái dấu hút nhau).
- Ở cực âm, nguồn điện "bơm" electron vào. Na^+^ nhận electron: **Na^+^ + 1e → Na** (sự khử). Kim loại natri lỏng tạo thành.
- Ở cực dương, nguồn điện "hút" electron ra. Cl^−^ nhường electron: **2Cl^−^ → Cl~2~ + 2e** (sự oxi hoá). Khí chlorine màu vàng lục thoát ra.

Cộng hai quá trình (nhân quá trình khử với 2 để số electron bằng nhau):

=> 2NaCl → 2Na + Cl~2~    (điện phân nóng chảy)

> [!ghi-nho] Định nghĩa
> **Điện phân** là quá trình oxi hoá – khử xảy ra ở bề mặt các điện cực khi cho dòng điện một chiều, có hiệu điện thế đủ lớn, đi qua chất điện li **nóng chảy** (điện phân nóng chảy, viết tắt **đpnc**) hoặc **dung dịch** chất điện li (điện phân dung dịch, viết tắt **đpdd**).

**Vì sao phải cần điện?** Phản ứng trong bình điện phân là phản ứng **không tự xảy ra**. Nguồn điện đóng vai một "cái bơm electron": nó lấy electron từ anode (nơi chất khử buộc phải nhường electron) rồi đẩy sang cathode (nơi chất oxi hoá buộc phải nhận electron). Điện năng được chuyển thành hoá năng tích trữ trong sản phẩm (Na và Cl~2~ có năng lượng cao, gặp lại nhau sẽ phản ứng mãnh liệt).

**Tên gọi các điện cực.** Quy ước chung cho cả pin và bình điện phân: **cathode là nơi xảy ra sự khử**, **anode là nơi xảy ra sự oxi hoá**. Trong bình điện phân, cathode nối với cực âm của nguồn nên **cathode là cực âm**, anode là **cực dương**.

![Hình 1. Bình điện phân dung dịch CuSO~4~ với hai điện cực than chì: electron từ nguồn đi vào cathode (−), từ anode (+) đi về nguồn; trong dung dịch chỉ có ion di chuyển](binh-dien-phan.svg)

| | Pin điện hoá (Bài 15) | Bình điện phân (Bài 16) |
|---|---|---|
| Chuyển hoá năng lượng | Hoá năng → điện năng | Điện năng → hoá năng |
| Phản ứng | Tự xảy ra | Không tự xảy ra, cần nguồn điện |
| Anode | **Cực âm**, sự oxi hoá | **Cực dương**, sự oxi hoá |
| Cathode | **Cực dương**, sự khử | **Cực âm**, sự khử |
| Ví dụ | Zn + Cu^2+^ → Zn^2+^ + Cu | 2NaCl → 2Na + Cl~2~ (đpnc) |

> [!meo] Nhớ một lần, dùng cho cả hai bài
> "**A**node – **O**xi hoá" (hai nguyên âm), "**C**athode – **K**hử" (hai phụ âm). Điều này **không bao giờ đổi**. Chỉ có dấu đổi: điện phân thì "**C**athode – **Â**m" (cation chạy về cathode, như "**ca**tion về **ca**thode").

> [!bay]
> - "Trong điện phân, anode là cực âm": **sai**. Anode của bình điện phân nối với cực dương của nguồn, nên là **cực dương**. Anode là cực âm chỉ trong **pin**.
> - Electron **không** đi xuyên qua chất điện li. Electron đi trong dây dẫn và điện cực, còn trong chất lỏng chỉ có **ion** di chuyển.
> - Cation (ion dương) về **cathode**, anion (ion âm) về **anode**. Đừng đảo.

> [!vi-du] Ví dụ 1
> Người ta điều chế magnesium bằng cách điện phân MgCl~2~ nóng chảy với các điện cực trơ.
>
> a) Các ion di chuyển về điện cực nào?
>
> b) Viết quá trình xảy ra ở mỗi điện cực và phương trình điện phân.
>
> c) Có thể thay MgCl~2~ nóng chảy bằng dung dịch MgCl~2~ được không? Dự đoán.

> [!goi-y] Gợi ý 1
> MgCl~2~ nóng chảy phân li thành Mg^2+^ và Cl^−^. Ion dương về cực âm (cathode), ion âm về cực dương (anode).

> [!goi-y] Gợi ý 2
> Ở cathode: Mg^2+^ nhận mấy electron? Ở anode: hai ion Cl^−^ góp lại thành một phân tử Cl~2~. Ở câu c, trong dung dịch còn có một chất nữa cũng có thể nhận electron ở cathode.

> [!loi-giai] Lời giải
> a) MgCl~2~ → Mg^2+^ + 2Cl^−^. Ion Mg^2+^ về **cathode (cực âm)**, ion Cl^−^ về **anode (cực dương)**.
>
> b) Cathode: Mg^2+^ + 2e → Mg. Anode: 2Cl^−^ → Cl~2~ + 2e. Phương trình: MgCl~2~ → Mg + Cl~2~ (đpnc).
>
> c) **Không.** Trong dung dịch, nước cũng có mặt ở cathode và nước dễ bị khử hơn ion Mg^2+^ (Mg rất hoạt động). Kết quả là cathode chỉ thoát khí H~2~, không thu được Mg (xem mục 1.2).

### 1.2. Khi có nước tham gia

Trong **dung dịch**, ngoài các ion của chất tan còn có rất nhiều phân tử **nước**. Nước cũng có thể bị điện phân, với hai vai trò:

- Ở **cathode**, nước đóng vai **chất oxi hoá** (H trong H~2~O có số oxi hoá +1, bị khử xuống 0):

=> 2H~2~O + 2e → H~2~ + 2OH^−^

- Ở **anode**, nước đóng vai **chất khử** (O trong H~2~O có số oxi hoá −2, bị oxi hoá lên 0):

=> 2H~2~O → O~2~ + 4H^+^ + 4e

Hai quá trình này rất quan trọng: chúng giải thích vì sao **vùng cathode trở nên kiềm** (sinh OH^−^) và **vùng anode trở nên acid** (sinh H^+^) khi nước bị điện phân.

> [!meo] Kiểm tra nhanh quá trình của nước
> - Cathode "**H~2~ đi với OH^−^**": nhận 2e thì ra 1 H~2~ và 2 OH^−^.
> - Anode "**O~2~ đi với H^+^**": nhường 4e thì ra 1 O~2~ và 4 H^+^.
> - Cả hai đều cân bằng điện tích: 2 điện tích âm (của 2e) ↔ 2 OH^−^. 4 H^+^ ↔ 4e.

## 2. Nguyên tắc (thứ tự) điện phân

### 2.1. Điện phân dung dịch CuSO~4~ với điện cực trơ

**Điện cực trơ** là điện cực dẫn điện nhưng **không tham gia phản ứng** trong quá trình điện phân, ví dụ than chì (graphite), platinum.

**Thí nghiệm** (SGK tr. 79–80): rót dung dịch CuSO~4~ 0,5 M vào ống thuỷ tinh hình chữ U, nhúng hai thanh than chì, nối với nguồn điện một chiều 3 – 6 V trong khoảng 5 phút.

**Hiện tượng:**

- Ở **cathode**: có lớp **kim loại màu đỏ** (đồng) bám vào thanh than chì.
- Ở **anode**: có **bọt khí** không màu thoát ra (khí O~2~).
- Để lâu, màu **xanh** của dung dịch **nhạt dần** (Cu^2+^ bị tiêu thụ).

**Giải thích theo từng điện cực.**

- Ion SO~4~^2−^ và phân tử H~2~O ở anode. **Ai bị oxi hoá?** Trong SO~4~^2−^, sulfur đã ở số oxi hoá cao nhất +6, rất khó nhường thêm electron. Nước dễ bị oxi hoá hơn nhiều. Vậy:

=> Anode (+): 2H~2~O → O~2~ + 4H^+^ + 4e

- Ion Cu^2+^ và phân tử H~2~O ở cathode. **Ai bị khử?** Cu^2+^ có E° = +0,340 V, là chất oxi hoá khá mạnh, dễ bị khử hơn nước. Vậy:

=> Cathode (−): Cu^2+^ + 2e → Cu

**Phương trình điện phân.** Nhân quá trình ở cathode với 2 để cân bằng electron (4e), rồi cộng lại. Ion H^+^ sinh ra ở anode kết hợp với SO~4~^2−^ còn lại trong dung dịch thành H~2~SO~4~:

=> 2CuSO~4~ + 2H~2~O → 2Cu + O~2~ + 2H~2~SO~4~    (điện phân dung dịch)

SGK viết gọn hệ số theo 1 mol CuSO~4~: CuSO~4~ + H~2~O → Cu + ½O~2~ + H~2~SO~4~ (SGK tr. 79). Hai cách viết là một.

> [!bay]
> - Dung dịch sau điện phân CuSO~4~ có **H~2~SO~4~**, môi trường **acid** (pH giảm), chứ không trung tính.
> - Khí ở anode là **O~2~**, không phải SO~2~ hay SO~3~. Ion SO~4~^2−^ **không** bị điện phân.
> - Nếu tiếp tục điện phân **sau khi Cu^2+^ hết**, ở cathode nước bắt đầu bị khử, thoát khí H~2~ (gặp nhiều trong bài tính toán, xem Dạng 2).

### 2.2. Điện phân dung dịch NaCl với điện cực trơ

Dung dịch NaCl có: ion Na^+^, Cl^−^ và nước.

- **Cathode (−):** có Na^+^ và H~2~O. Natri là kim loại rất mạnh (E° = −2,713 V), ion Na^+^ cực kì khó bị khử. Nước bị khử thay:

=> 2H~2~O + 2e → H~2~ + 2OH^−^

- **Anode (+):** có Cl^−^ và H~2~O. Ion Cl^−^ bị oxi hoá:

=> 2Cl^−^ → Cl~2~ + 2e

**Phương trình điện phân** (có màng ngăn giữa hai điện cực):

=> 2NaCl + 2H~2~O → 2NaOH + H~2~ + Cl~2~    (điện phân dung dịch, có màng ngăn)

Na^+^ không tham gia phản ứng, nhưng kết hợp với OH^−^ sinh ra ở cathode thành NaOH. Vì vậy dung dịch quanh cathode có môi trường **kiềm**.

**Khi KHÔNG có màng ngăn.** Cl~2~ sinh ra ở anode khuếch tán sang vùng cathode và gặp NaOH, phản ứng ngay:

=> Cl~2~ + 2NaOH → NaCl + NaClO + H~2~O

Cộng hai phương trình, ta được phương trình tổng (không màng ngăn):

=> NaCl + H~2~O → NaClO + H~2~    (điện phân dung dịch, không màng ngăn)

Dung dịch thu được chứa **NaCl và NaClO**, chính là **nước Javel**. NaClO có tính oxi hoá mạnh nên **tẩy màu** và **sát khuẩn**.

> [!ung-dung] Tự điều chế nước Javel (thí nghiệm SGK tr. 81)
> Điện phân khoảng 80 mL dung dịch NaCl bão hoà trong cốc có nắp đậy, hai điện cực than chì, nguồn 3 – 6 V, khoảng 5 phút.
>
> - **Ở cả hai điện cực đều có bọt khí**: H~2~ ở cathode, Cl~2~ ở anode.
> - Cho một cánh hoa màu hồng vào vài mL dung dịch sau điện phân: **cánh hoa nhạt màu dần**. Lí do: dung dịch có NaClO, chất oxi hoá mạnh phá huỷ chất màu.
> - **Vì sao đậy nắp?** Khí Cl~2~ độc. Nắp giữ Cl~2~ lại, vừa tránh khí độc thoát ra phòng, vừa để Cl~2~ có thêm thời gian hoà tan và phản ứng với NaOH tạo NaClO.

> [!em-co-biet] Công nghiệp chlor – kiềm (mở rộng)
> Trong công nghiệp, người ta điện phân dung dịch NaCl bão hoà **có màng ngăn** (màng chỉ cho Na^+^ đi qua, ngăn Cl~2~ sang vùng cathode). Mỗi bình cho cùng lúc ba sản phẩm: **NaOH**, **Cl~2~** và **H~2~**. Đây là nguồn NaOH và chlorine chủ yếu trên thế giới, dùng để sản xuất xà phòng, giấy, PVC, khử trùng nước…

> [!bay]
> - Điện phân dung dịch NaCl **không thu được Na**. Muốn có Na phải điện phân **nóng chảy**.
> - Có màng ngăn: sản phẩm NaOH + H~2~ + Cl~2~. Không màng ngăn: NaClO (nước Javel) + H~2~. Đề hay hỏi chỗ này.
> - Vùng cathode có NaOH nên **làm quỳ tím hoá xanh**, nhỏ phenolphthalein thì **hoá hồng**.

### 2.3. Quy tắc chung về thứ tự điện phân

Hai thí nghiệm trên cho thấy: ở mỗi điện cực có **nhiều "ứng viên"** (ion của muối, ion H^+^, phân tử nước…), nhưng chất nào "dễ" hơn thì phản ứng trước. SGK tổng kết thành quy tắc (SGK tr. 81):

> [!ghi-nho] Thứ tự điện phân
> - **Tại cathode**, chất **oxi hoá mạnh hơn** bị **khử trước**.
> - **Tại anode**, chất **khử mạnh hơn** bị **oxi hoá trước**.
> - Ở điều kiện chuẩn, độ mạnh yếu được so sánh bằng **thế điện cực chuẩn** (vị trí cặp oxi hoá – khử trong dãy điện hoá).

**Thứ tự cụ thể cần thuộc (điện cực trơ):**

- **Cathode:** Au^3+^ > Ag^+^ > Hg^2+^ > Cu^2+^ > H^+^ > H~2~O. Đây chính là thứ tự E° giảm dần mà em đã học ở Bài 15.
- **Anode:** I^−^ > Br^−^ > Cl^−^ > H~2~O. Các anion CO~3~^2−^, NO~3~^−^, PO~4~^3−^, SO~4~^2−^, ClO~4~^−^ và F^−^ **coi như không bị điện phân**, nước bị oxi hoá thay.

![Hình 2. Thứ tự điện phân dung dịch với điện cực trơ: chất đứng trên bị điện phân trước; khi chất đó hết mới đến chất bên dưới](thu-tu-dien-phan.svg)

**Còn ion của các kim loại khác thì sao?** Thứ tự SGK ở trên chưa nhắc đến ion của các kim loại đứng trước hydrogen. Khi làm đề, em dùng **quy ước thường dùng** sau (ngoài SGK, rút ra từ thực nghiệm):

- Ion của kim loại **mạnh**, từ Al^3+^ trở về trước trong dãy điện hoá (K^+^, Na^+^, Ca^2+^, Mg^2+^, Al^3+^), **không bị khử** trong dung dịch. Nước bị khử thay, sinh H~2~. Các kim loại này chỉ điều chế được bằng **điện phân nóng chảy**.
- Ion của kim loại **trung bình**, từ Zn^2+^ trở về sau nhưng đứng trước H^+^ (Zn^2+^, Fe^2+^, Ni^2+^, Sn^2+^, Pb^2+^), **vẫn bị khử** thành kim loại ở cathode. Chúng bị khử **sau H^+^ của acid** nhưng **trước H~2~O**. Giữa chúng với nhau vẫn theo E°: ion có E° lớn hơn bị khử trước.
- Ion của kim loại **yếu** (Cu^2+^, Hg^2+^, Ag^+^, Au^3+^) bị khử trước H^+^, như thứ tự SGK.

Thứ tự đầy đủ ở cathode khi làm đề: Au^3+^ > Ag^+^ > Hg^2+^ > Cu^2+^ > H^+^ (acid) > Pb^2+^ > Sn^2+^ > Ni^2+^ > Fe^2+^ > Zn^2+^ > H~2~O. Ví dụ SGK: hơn một nửa lượng kẽm trên thế giới được sản xuất bằng điện phân dung dịch ZnSO~4~ (SGK tr. 82), tức là Zn^2+^ bị khử trước nước.

> [!bay]
> - "Từ Zn^2+^ trở đi bị khử" **không** có nghĩa là Zn^2+^ bị khử trước H^+^. Dung dịch chứa cả HCl và FeCl~2~ thì ở cathode H^+^ bị khử trước (thoát H~2~), hết H^+^ mới đến Fe^2+^.
> - Ion kim loại từ Al^3+^ trở về trước thì không bao giờ bị khử trong dung dịch, dù điện phân lâu đến đâu.

> [!em-co-biet] Vì sao Zn^2+^ vẫn bị khử dù E° âm?
> Theo E° thuần tuý, nước (và H^+^) đáng lẽ dễ bị khử hơn Zn^2+^. Nhưng trên thực tế, khí H~2~ rất khó hình thành trên bề mặt nhiều kim loại, phải cần thêm một "lực đẩy" điện thế. Vì vậy Zn^2+^, Fe^2+^, Ni^2+^ vẫn bị khử thành kim loại. SGK nhắc: thứ tự điện phân còn phụ thuộc vào **vật liệu và bề mặt điện cực**, nhất là với các quá trình tạo **sản phẩm khí** (SGK tr. 81).

> [!em-co-biet] Ion Fe^3+^ (mở rộng, hay gặp trong đề)
> Cặp Fe^3+^/Fe^2+^ có E° = +0,771 V, lớn hơn Cu^2+^/Cu (+0,340 V) nhưng nhỏ hơn Ag^+^/Ag (+0,799 V). Nên ở cathode thứ tự là: Ag^+^ > **Fe^3+^** > Cu^2+^ > H^+^ > Fe^2+^. Lưu ý Fe^3+^ chỉ bị khử về **Fe^2+^** trước (Fe^3+^ + 1e → Fe^2+^), chưa ra kim loại Fe.

**Phân loại theo sự thay đổi môi trường** (rất hay hỏi):

| Loại muối (điện cực trơ) | Ví dụ | Cathode | Anode | Dung dịch sau điện phân |
|---|---|---|---|---|
| Cation kim loại yếu + anion gốc acid có oxygen | CuSO~4~, AgNO~3~ | Kim loại | O~2~ | Sinh **acid**, pH giảm |
| Cation kim loại mạnh + Cl^−^, Br^−^ | NaCl, KBr | H~2~ | Cl~2~, Br~2~ | Sinh **base**, pH tăng |
| Cation kim loại yếu + Cl^−^ | CuCl~2~ | Kim loại | Cl~2~ | Muối giảm dần, không sinh acid hay base |
| Cation kim loại mạnh + anion gốc acid có oxygen | Na~2~SO~4~, KNO~3~ | H~2~ | O~2~ | Chỉ **nước** bị điện phân, muối được cô đặc |

> [!vi-du] Ví dụ 2
> Viết quá trình ở mỗi điện cực và phương trình điện phân dung dịch (điện cực trơ, có màng ngăn) của:
>
> a) AgNO~3~
>
> b) KBr
>
> c) Na~2~SO~4~

> [!goi-y] Gợi ý 1
> Liệt kê "ứng viên" ở từng cực: cation và H~2~O ở cathode, anion và H~2~O ở anode. Dùng thứ tự ở Hình 2 để chọn.

> [!goi-y] Gợi ý 2
> NO~3~^−^ và SO~4~^2−^ không bị điện phân, K^+^ và Na^+^ cũng vậy. Khi đó nước bị điện phân thay. Nhớ cân bằng electron trước khi cộng.

> [!loi-giai] Lời giải
> a) Cathode: Ag^+^ + 1e → Ag. Anode: 2H~2~O → O~2~ + 4H^+^ + 4e. Nhân quá trình ở cathode với 4:
>
> => 4AgNO~3~ + 2H~2~O → 4Ag + O~2~ + 4HNO~3~
>
> b) Cathode: 2H~2~O + 2e → H~2~ + 2OH^−^. Anode: 2Br^−^ → Br~2~ + 2e.
>
> => 2KBr + 2H~2~O → 2KOH + H~2~ + Br~2~
>
> c) Cathode: 2H~2~O + 2e → H~2~ + 2OH^−^ (nhân 2). Anode: 2H~2~O → O~2~ + 4H^+^ + 4e. H^+^ và OH^−^ sinh ra trung hoà nhau, thực chất là **điện phân nước**:
>
> => 2H~2~O → 2H~2~ + O~2~
>
> Thể tích H~2~ ở cathode gấp đôi thể tích O~2~ ở anode. Na~2~SO~4~ chỉ giúp dung dịch dẫn điện tốt.

> [!vi-du] Ví dụ 3
> Điện phân (điện cực trơ) dung dịch chứa đồng thời Cu(NO~3~)~2~, NaCl và NaBr. Sắp xếp thứ tự các quá trình xảy ra ở mỗi điện cực khi điện phân đến cùng.

> [!goi-y] Gợi ý 1
> Cathode: những ứng viên nào? Na^+^ có bị khử không? Anode: NO~3~^−^ có bị oxi hoá không?

> [!goi-y] Gợi ý 2
> Anode: Br^−^ mạnh hơn Cl^−^ (I^−^ > Br^−^ > Cl^−^). Khi một chất hết thì đến chất tiếp theo.

> [!loi-giai] Lời giải
> **Cathode (−):** Na^+^ không bị khử. Thứ tự: Cu^2+^ + 2e → Cu, sau khi Cu^2+^ hết thì 2H~2~O + 2e → H~2~ + 2OH^−^.
>
> **Anode (+):** NO~3~^−^ không bị điện phân. Thứ tự: 2Br^−^ → Br~2~ + 2e, rồi 2Cl^−^ → Cl~2~ + 2e, cuối cùng 2H~2~O → O~2~ + 4H^+^ + 4e.

## 3. Ứng dụng của phương pháp điện phân

### 3.1. Sản xuất kim loại

**Kim loại trung bình và yếu** (Zn, Ni, Cu…) có thể sản xuất bằng **điện phân dung dịch** muối của chúng. Ví dụ, phần lớn kẽm được sản xuất như sau (SGK tr. 82):

=> 2ZnSO~4~ + 2H~2~O → 2Zn + O~2~ + 2H~2~SO~4~    (điện phân dung dịch)

**Kim loại mạnh** (Na, K, Mg, Ca, Al…) chỉ sản xuất được bằng **điện phân nóng chảy** hợp chất ion của chúng (muối chloride, oxide…). Lí do: trong dung dịch, nước luôn bị khử trước ion của chúng.

**Sản xuất nhôm từ quặng bauxite** gồm hai giai đoạn chính:

- **Giai đoạn 1: tinh chế quặng.** Quặng bauxite có thành phần chính là Al~2~O~3~·2H~2~O, lẫn tạp chất (chủ yếu là oxide của sắt, silicon). Dùng phương pháp hoá học loại tạp chất, thu được Al~2~O~3~ tinh khiết.
- **Giai đoạn 2: điện phân Al~2~O~3~ nóng chảy.**

**Vấn đề:** Al~2~O~3~ nóng chảy ở **2 050 °C**, rất tốn năng lượng và khó tìm vật liệu chịu được. **Giải pháp:** trộn Al~2~O~3~ với **cryolite (Na~3~AlF~6~)**. Hỗn hợp nóng chảy chỉ ở **gần 1 000 °C**. Cryolite đem lại ba lợi ích:

1. **Hạ nhiệt độ nóng chảy**, tiết kiệm rất nhiều năng lượng.
2. Tạo chất lỏng **dẫn điện tốt** hơn.
3. Chất lỏng này **nhẹ hơn nhôm lỏng**, nổi lên trên, **ngăn nhôm lỏng tiếp xúc với không khí** (tránh bị oxi hoá trở lại).

**Thùng điện phân:** cathode là **tấm than chì lót ở đáy thùng**, anode là những **khối than chì** treo phía trên, nâng hạ được theo phương thẳng đứng. Nhôm lỏng nặng hơn nên đọng ở đáy, được tháo ra ngoài định kì.

![Hình 3. Sơ đồ thùng điện phân Al~2~O~3~ nóng chảy (vẽ đơn giản): nhôm lỏng tụ ở đáy (cathode), khí O~2~ sinh ra ở các khối anode than chì và đốt cháy dần anode](thung-al2o3.svg)

=> Cathode (−): Al^3+^ + 3e → Al

=> Anode (+): 2O^2−^ → O~2~ + 4e

=> 2Al~2~O~3~ → 4Al + 3O~2~    (điện phân nóng chảy, có mặt cryolite)

**Vì sao phải hạ dần anode?** Khí O~2~ sinh ra ở nhiệt độ rất cao **đốt cháy chính anode than chì** thành CO và CO~2~:

=> C + O~2~ → CO~2~

=> 2C + O~2~ → 2CO

Anode bị mòn dần, nên phải hạ thấp dần các khối anode và định kì thay anode mới.

> [!bay]
> - Cryolite **không** phải chất bị điện phân. Nó chỉ là "dung môi" giúp hạ nhiệt độ nóng chảy.
> - Khí thoát ra ở anode trong thực tế là **hỗn hợp O~2~, CO, CO~2~**, không chỉ O~2~.
> - Không điện phân dung dịch muối nhôm để lấy Al (nước bị khử thay). Không điện phân AlCl~3~ nóng chảy (mở rộng: AlCl~3~ là hợp chất cộng hoá trị, thăng hoa, không dẫn điện tốt).

### 3.2. Tinh chế kim loại

Kim loại thu được sau nhiệt luyện, thuỷ luyện, hoặc từ phế liệu thường còn lẫn tạp chất. Các kim loại như Zn, Ni, Co, Cu, Ag, Au… được tinh chế bằng điện phân với **anode làm bằng chính kim loại thô** đó (SGK tr. 83).

**Tinh chế đồng:** bình điện phân chứa dung dịch CuSO~4~ trong H~2~SO~4~. **Anode là đồng thô**, **cathode là lá đồng tinh khiết**.

=> Anode (+): Cu → Cu^2+^ + 2e    (anode tan dần)

=> Cathode (−): Cu^2+^ + 2e → Cu    (đồng tinh khiết bám vào)

**Vì sao ở đây anode lại tan, không thoát O~2~ như ở mục 2.1?** Vì anode bằng đồng không còn là điện cực trơ. Kim loại Cu là chất khử **mạnh hơn nhiều** so với H~2~O (và SO~4~^2−^), nên chính Cu ở anode bị oxi hoá trước. Đây cũng là quy tắc "chất khử mạnh hơn bị oxi hoá trước".

Kết quả: đồng **chuyển dời** từ anode (dạng thô) sang cathode (dạng tinh khiết). Lượng Cu^2+^ vào dung dịch ở anode bằng lượng Cu^2+^ rời dung dịch ở cathode, nên **nồng độ Cu^2+^ gần như không đổi**. Người ta gọi đây là điện phân với **anode tan** (hiện tượng "dương cực tan").

> [!em-co-biet] Tạp chất đi đâu? (mở rộng)
> Tạp chất **mạnh hơn** đồng (Zn, Fe, Ni) bị oxi hoá thành ion, đi vào dung dịch, nhưng **không bị khử** ở cathode (Cu^2+^ dễ bị khử hơn). Tạp chất **yếu hơn** đồng (Ag, Au, Pt) không bị oxi hoá, rơi xuống đáy thùng thành **bùn anode**. Bùn anode là nguồn thu hồi bạc, vàng rất có giá trị. Đồng tinh luyện đạt độ tinh khiết khoảng 99,9% trở lên, dùng làm dây dẫn điện.

![Hình 4. Điện phân với anode tan: kim loại M chuyển từ anode sang cathode (dùng cho tinh chế kim loại và mạ điện)](anode-tan.svg)

### 3.3. Mạ điện

**Mạ điện** là dùng điện phân để phủ một lớp kim loại mỏng lên bề mặt vật cần mạ, nhằm **trang trí** hoặc **chống ăn mòn**. Kim loại mạ thường là chromium, nickel, đồng, vàng, bạc, platinum…

Bình mạ điện gồm:

- **Cathode (−)**: **vật cần mạ** (vì ion kim loại bị khử và bám lên cathode).
- **Anode (+)**: **thanh kim loại dùng để mạ** (tan dần, bổ sung ion cho dung dịch).
- **Dung dịch điện phân**: dung dịch **muối của kim loại mạ**.

Ví dụ, mạ đồng lên một chiếc chìa khoá thép: chìa khoá nối với cực âm, thanh đồng nối với cực dương, dung dịch CuSO~4~ (SGK tr. 83). Các quá trình giống hệt tinh chế đồng (Hình 4).

**Độ dày lớp mạ** tỉ lệ thuận với **cường độ dòng điện** và **thời gian mạ**. Dòng lớn hơn hoặc mạ lâu hơn thì lớp mạ dày hơn (mục 4 cho cách tính).

> [!ung-dung] Đồ vật mạ điện quanh em
> - Vòi nước, tay nắm cửa, vành xe máy: mạ **chromium** hoặc **nickel**, sáng bóng và chống gỉ.
> - Trang sức, đồng hồ: mạ **vàng**, **bạc** để đẹp và rẻ hơn kim loại nguyên khối.
> - Đinh vít, bu lông mạ kẽm: lớp kẽm bảo vệ thép khỏi gỉ (xem Bài 22, Sự ăn mòn kim loại).
> - Bản mạch điện tử: mạ **đồng**, **vàng** ở chân tiếp xúc để dẫn điện tốt, không bị oxi hoá.

> [!bay]
> - Vật cần mạ phải làm **cathode** (cực âm). Nối nhầm vào anode thì vật bị **ăn mòn** chứ không được mạ.
> - Dung dịch phải chứa ion của **kim loại mạ** (mạ bạc dùng muối bạc, mạ nickel dùng muối nickel), không phải ion của vật cần mạ.

## 4. Tính toán trong điện phân (mở rộng: định luật Faraday)

SGK Hoá học 12 KNTT không đưa công thức tính lượng chất điện phân. Tuy nhiên, nhiều đề thi thử và đề luyện thi có câu tính toán điện phân, nên em cần nắm phần này.

### 4.1. Số mol electron trao đổi

**Ý tưởng:** dòng điện chính là dòng electron. Biết lượng điện đã chạy qua, ta biết có bao nhiêu electron đã được "bơm" qua mạch, từ đó suy ra lượng chất đã phản ứng ở điện cực.

- Điện lượng chạy qua mạch: **q = I·t** (coulomb, C), với I là cường độ dòng điện (A), t là thời gian (giây).
- Mỗi mol electron mang điện lượng **F = 96 500 C/mol** (hằng số Faraday).

$$n_e=\dfrac{I\,t}{F}$$

**Định luật bảo toàn electron trong điện phân:** số mol electron do anode "nhường" bằng số mol electron cathode "nhận" và bằng n~e~. Từ đó, với một quá trình M^n+^ + ne → M:

$$n_M=\dfrac{n_e}{n}\quad\Rightarrow\quad m=\dfrac{A\,I\,t}{n\,F}$$

(A là khối lượng mol của chất. Đây là **công thức Faraday**.)

> [!meo] Bảng "đổi electron ra chất" nên thuộc
> Với 1 mol electron:
>
> - Cathode: 1 mol Ag; 0,5 mol Cu; 0,5 mol H~2~; 1/3 mol Al.
> - Anode: 0,5 mol Cl~2~; 0,5 mol Br~2~; 0,25 mol O~2~.
>
> Số giây quen thuộc: 1 930 s × 5 A = 9 650 C = 0,1 mol e. Đề hay chọn số liệu để n~e~ ra số đẹp.

> [!bay]
> - **Thời gian phải đổi ra giây.** 1 giờ = 3 600 s, 1 phút = 60 s.
> - O~2~ cần **4e**, không phải 2e: n(O~2~) = n~e~ : 4.
> - Thể tích khí ở điều kiện chuẩn (25 °C, 1 bar): V = n · 24,79 L.

> [!vi-du] Ví dụ 4
> Điện phân dung dịch AgNO~3~ (dư) với điện cực trơ, cường độ dòng điện 2,5 A, trong 32 phút 10 giây. Tính khối lượng bạc bám ở cathode và thể tích khí thoát ra ở anode (đkc).

> [!goi-y] Gợi ý 1
> Đổi thời gian ra giây rồi tính n~e~ = It/F.

> [!goi-y] Gợi ý 2
> AgNO~3~ dư nên ở cathode chỉ có Ag^+^ bị khử. Ở anode, NO~3~^−^ không bị điện phân, nước bị oxi hoá, sinh O~2~ (4e).

> [!loi-giai] Lời giải
> t = 32 · 60 + 10 = 1 930 s. n~e~ = 2,5 · 1 930 : 96 500 = 0,05 mol.
>
> Cathode: Ag^+^ + 1e → Ag, n(Ag) = 0,05 mol, m(Ag) = 0,05 · 108 = **5,4 g**.
>
> Anode: 2H~2~O → O~2~ + 4H^+^ + 4e, n(O~2~) = 0,05 : 4 = 0,0125 mol, V = 0,0125 · 24,79 ≈ **0,31 L**.

### 4.2. Điện phân trong sản xuất

> [!vi-du] Ví dụ 5
> Một thùng điện phân Al~2~O~3~ nóng chảy làm việc với dòng điện 150 000 A liên tục trong 24 giờ. Giả sử toàn bộ điện lượng dùng để điện phân.
>
> a) Tính khối lượng nhôm thu được (theo tấn, làm tròn đến hàng phần trăm).
>
> b) Nếu toàn bộ O~2~ sinh ra đốt cháy anode than chì thành CO~2~, khối lượng than chì bị hao hụt là bao nhiêu kilogam?

> [!goi-y] Gợi ý 1
> t = 24 · 3 600 = 86 400 s. Tính n~e~, rồi n(Al) = n~e~ : 3.

> [!goi-y] Gợi ý 2
> n(O~2~) = n~e~ : 4. Mỗi mol O~2~ đốt cháy 1 mol C thành CO~2~.

> [!loi-giai] Lời giải
> a) n~e~ = 150 000 · 86 400 : 96 500 ≈ 134 300 mol.
>
> n(Al) = 134 300 : 3 ≈ 44 767 mol, m(Al) ≈ 44 767 · 27 ≈ 1 208 700 g ≈ **1,21 tấn**.
>
> b) n(O~2~) = 134 300 : 4 ≈ 33 575 mol. C + O~2~ → CO~2~ nên n(C) = n(O~2~) ≈ 33 575 mol, m(C) ≈ 33 575 · 12 ≈ 402 900 g ≈ **403 kg**.
>
> Cứ khoảng 1,2 tấn nhôm thì "ăn" mất khoảng 0,4 tấn than chì. Vì thế anode phải thay định kì.

> [!vi-du] Ví dụ 6 (vận dụng cao)
> Mạ nickel lên một tấm thép có tổng diện tích bề mặt cần mạ là 100 cm^2^. Dung dịch điện phân là NiSO~4~, anode bằng nickel, dòng điện 2 A. Lớp mạ dày 10 μm, khối lượng riêng của nickel là 8,9 g/cm^3^. Tính thời gian mạ (phút, làm tròn đến hàng phần mười). Coi hiệu suất 100%, Ni = 59.

> [!goi-y] Gợi ý 1
> Thể tích lớp mạ = diện tích × độ dày. Đổi 10 μm = 10 · 10^−4^ cm = 0,001 cm.

> [!goi-y] Gợi ý 2
> Tính khối lượng Ni, rồi n(Ni). Ni^2+^ + 2e → Ni nên n~e~ = 2n(Ni). Cuối cùng t = n~e~ · F : I.

> [!loi-giai] Lời giải
> V(Ni) = 100 · 0,001 = 0,1 cm^3^, m(Ni) = 0,1 · 8,9 = 0,89 g.
>
> n(Ni) = 0,89 : 59 ≈ 0,015085 mol, n~e~ = 2 · 0,015085 ≈ 0,030169 mol.
>
> t = 0,030169 · 96 500 : 2 ≈ 1 455,7 s ≈ **24,3 phút**.

## Dạng bài thi hay gặp

### Dạng 1. Xác định quá trình, sản phẩm ở các điện cực

**Nhận biết:** đề cho chất (nóng chảy hay dung dịch, có màng ngăn hay không), hỏi khí gì thoát ra, kim loại gì bám vào, môi trường dung dịch sau điện phân, phát biểu đúng/sai.

**Phương pháp:**

1. Xác định **nóng chảy** hay **dung dịch**. Nóng chảy thì không có nước. Dung dịch thì thêm H~2~O vào danh sách ứng viên ở **cả hai cực**.
2. Cathode (−): cation và H~2~O. Chọn theo thứ tự Ag^+^ > Cu^2+^ > H^+^ > (Ni^2+^, Fe^2+^, Zn^2+^) > H~2~O. Loại các ion K^+^, Na^+^, Ca^2+^, Mg^2+^, Al^3+^.
3. Anode (+): xét **anode có tan không**. Anode là kim loại (không trơ) thì kim loại đó bị oxi hoá. Anode trơ thì chọn theo I^−^ > Br^−^ > Cl^−^ > H~2~O, loại SO~4~^2−^, NO~3~^−^, F^−^...
4. Suy ra môi trường: H~2~O bị oxi hoá ở anode sinh H^+^ (acid). H~2~O bị khử ở cathode sinh OH^−^ (base).

> [!vi-du] Ví dụ 7
> Điện phân dung dịch X với điện cực trơ, thấy ở cathode **có khí thoát ra ngay từ đầu** và dung dịch sau điện phân làm quỳ tím hoá **đỏ**. Chất tan trong X có thể là chất nào trong số: KCl, CuSO~4~, K~2~SO~4~, H~2~SO~4~, HNO~3~, AgNO~3~?

> [!goi-y] Gợi ý 1
> Khí thoát ra ngay ở cathode nghĩa là không có ion kim loại nào bị khử trước H^+^ hay H~2~O. Loại các muối của Cu, Ag.

> [!goi-y] Gợi ý 2
> Với các chất còn lại, xét môi trường dung dịch sau khi điện phân: KCl sinh KOH, K~2~SO~4~ chỉ điện phân nước (trung tính). Còn H~2~SO~4~ và HNO~3~ thì sao?

> [!loi-giai] Lời giải
> - CuSO~4~, AgNO~3~: cathode có kim loại bám vào trước, chưa có khí ngay. **Loại.**
> - KCl: cathode có H~2~ ngay, nhưng dung dịch sinh KOH, quỳ hoá xanh. **Loại.**
> - K~2~SO~4~: điện phân nước, dung dịch vẫn trung tính. **Loại.**
> - H~2~SO~4~, HNO~3~: cathode 2H^+^ + 2e → H~2~ (có khí ngay), anode thoát O~2~. Thực chất là điện phân nước, acid được **cô đặc dần**, quỳ vẫn đỏ. **Thoả mãn.**
>
> Vậy X có thể là **H~2~SO~4~ hoặc HNO~3~**.

> [!bay]
> - Quên **anode tan**: nếu đề cho anode bằng Cu (hoặc kim loại khác không trơ) thì ở anode **kim loại tan ra**, không thoát O~2~ hay Cl~2~.
> - Điện phân dung dịch acid H~2~SO~4~ hay base NaOH: thực chất là **điện phân nước**, nồng độ chất tan **tăng dần**.

### Dạng 2. Tính khối lượng, thể tích, thời gian theo n~e~ = It/F (mở rộng)

**Nhận biết:** đề cho I, t (hoặc khối lượng cathode tăng, thể tích khí) với một muối.

**Phương pháp:**

1. Tính n~e~ = It/F (t tính bằng giây). Nếu đề cho khối lượng hay thể tích thì đi ngược để tìm n~e~ rồi t.
2. **Phân phối n~e~ theo thứ tự** ở mỗi điện cực. So n~e~ với lượng electron cần để khử hết ion kim loại. Nếu n~e~ lớn hơn thì phần electron dư khử nước (ra H~2~).
3. Ở anode cũng làm tương tự (Cl^−^ trước, hết Cl^−^ thì đến H~2~O ra O~2~).
4. Tính khối lượng, thể tích theo yêu cầu.

> [!vi-du] Ví dụ 8
> Điện phân 200 mL dung dịch CuSO~4~ 0,5 M bằng điện cực trơ, cường độ dòng điện 5 A, trong 4 632 giây. Tính tổng thể tích khí (đkc) thoát ra ở cả hai điện cực (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> n(Cu^2+^) = 0,1 mol, cần 0,2 mol electron để khử hết. So với n~e~.

> [!goi-y] Gợi ý 2
> Nếu n~e~ > 0,2 thì phần dư khử nước thành H~2~ ở cathode. Ở anode chỉ có nước bị oxi hoá suốt quá trình, sinh O~2~ = n~e~ : 4.

> [!loi-giai] Lời giải
> n~e~ = 5 · 4 632 : 96 500 = 0,24 mol. n(Cu^2+^) = 0,2 · 0,5 = 0,1 mol.
>
> **Cathode:** Cu^2+^ + 2e → Cu dùng 0,2 mol e (Cu^2+^ hết). Còn 0,04 mol e: 2H~2~O + 2e → H~2~ + 2OH^−^, n(H~2~) = 0,02 mol.
>
> **Anode:** 2H~2~O → O~2~ + 4H^+^ + 4e, n(O~2~) = 0,24 : 4 = 0,06 mol.
>
> Tổng khí: 0,02 + 0,06 = 0,08 mol, V = 0,08 · 24,79 ≈ **1,98 L**.

> [!bay]
> Quên khí H~2~ ở cathode sau khi Cu^2+^ hết thì chỉ tính được 0,06 mol O~2~, ra 1,49 L. Luôn so n~e~ với lượng ion kim loại trước khi tính.

### Dạng 3. Hỗn hợp muối, khối lượng dung dịch giảm (mở rộng)

**Nhận biết:** dung dịch chứa hai chất (thường gặp CuSO~4~ + NaCl), hỏi khối lượng dung dịch giảm, khí ở anode gồm những gì, pH dung dịch sau điện phân.

**Phương pháp:**

1. Tính n~e~. Chia electron ở **mỗi cực riêng rẽ** theo thứ tự (hai cực có cùng n~e~).
2. **Khối lượng dung dịch giảm** = tổng khối lượng các chất **rời khỏi dung dịch**: kim loại bám cathode + các khí thoát ra (Cl~2~, O~2~, H~2~).

> [!vi-du] Ví dụ 9
> Điện phân dung dịch chứa 0,06 mol CuSO~4~ và 0,08 mol NaCl (điện cực trơ, có màng ngăn) với dòng điện 5 A trong 1 930 giây. Giả sử khí không tan trong nước và nước bay hơi không đáng kể. Khối lượng dung dịch giảm bao nhiêu gam?

> [!goi-y] Gợi ý 1
> n~e~ = 0,1 mol. Cathode: Cu^2+^ cần 0,12 mol e mới hết. Vậy 0,1 mol e có khử hết Cu^2+^ không?

> [!goi-y] Gợi ý 2
> Anode: Cl^−^ (0,08 mol) dùng 0,08 mol e, sinh Cl~2~. Còn 0,02 mol e thì nước bị oxi hoá sinh O~2~.

> [!loi-giai] Lời giải
> n~e~ = 5 · 1 930 : 96 500 = 0,1 mol.
>
> **Cathode:** Cu^2+^ dư (cần 0,12 > 0,1), nên chỉ có Cu bám vào: n(Cu) = 0,1 : 2 = 0,05 mol. Chưa có H~2~.
>
> **Anode:** 2Cl^−^ → Cl~2~ + 2e: n(Cl~2~) = 0,04 mol (dùng 0,08 mol e). Còn 0,02 mol e: n(O~2~) = 0,02 : 4 = 0,005 mol.
>
> Khối lượng dung dịch giảm = 0,05 · 64 + 0,04 · 71 + 0,005 · 32 = 3,2 + 2,84 + 0,16 = **6,2 g**.

> [!bay]
> - Chỉ cộng những chất **rời khỏi** dung dịch. Không cộng H~2~SO~4~, NaOH… vì chúng vẫn nằm trong dung dịch.
> - Khí ở anode có thể là **hỗn hợp** Cl~2~ và O~2~. Đừng mặc định chỉ có Cl~2~.

### Dạng 4. Đúng/Sai về thí nghiệm điện phân và ứng dụng

**Nhận biết:** đề mô tả thí nghiệm (ống chữ U, cốc có nắp, cánh hoa, quỳ tím…) hoặc quy trình công nghiệp (sản xuất nhôm, tinh chế đồng, mạ điện), cho 4 phát biểu.

**Phương pháp:** với mỗi phát biểu, hỏi lần lượt: (1) đây là **cathode hay anode**, cực **âm hay dương**? (2) chất nào bị **khử/oxi hoá** theo thứ tự? (3) hiện tượng nhìn thấy được là gì (khí, kim loại bám, màu dung dịch, môi trường)? (4) nếu có số liệu thì kiểm bằng n~e~.

> [!vi-du] Ví dụ 10 (Đúng/Sai)
> Một học sinh mạ bạc cho chiếc nhẫn đồng: nhúng nhẫn và một thanh bạc vào dung dịch AgNO~3~, nối với nguồn điện một chiều. Xét các phát biểu:
>
> a) Chiếc nhẫn được nối với cực dương của nguồn điện.
>
> b) Ở thanh bạc xảy ra quá trình Ag → Ag^+^ + 1e.
>
> c) Trong quá trình mạ, nồng độ ion Ag^+^ trong dung dịch gần như không đổi.
>
> d) Với dòng điện 0,5 A trong 16 phút 5 giây, khối lượng bạc bám lên nhẫn là 0,54 g.

> [!goi-y] Gợi ý 1
> Vật cần mạ phải là nơi ion Ag^+^ **bị khử** thành Ag. Đó là cực nào?

> [!goi-y] Gợi ý 2
> Thanh bạc là anode tan. Lượng Ag^+^ sinh ra ở anode so với lượng bị khử ở cathode thế nào? Ý d: đổi 16 phút 5 giây ra giây.

> [!loi-giai] Lời giải
> a) **Sai**: nhẫn là vật cần mạ, phải làm **cathode**, tức nối với **cực âm**.
>
> b) **Đúng**: thanh bạc là anode tan, Ag bị oxi hoá thành Ag^+^ đi vào dung dịch.
>
> c) **Đúng**: Ag^+^ sinh ra ở anode bằng Ag^+^ bị khử ở cathode (cùng n~e~), nên nồng độ gần như không đổi.
>
> d) **Đúng**: t = 965 s, n~e~ = 0,5 · 965 : 96 500 = 0,005 mol, m(Ag) = 0,005 · 108 = 0,54 g.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Điện phân | Dòng điện một chiều gây phản ứng oxi hoá – khử không tự xảy ra; điện năng → hoá năng |
| Điện cực (bình điện phân) | Cathode = cực âm = sự khử; anode = cực dương = sự oxi hoá |
| Di chuyển ion | Cation → cathode; anion → anode; electron chỉ đi trong dây dẫn |
| Nước ở cathode | 2H~2~O + 2e → H~2~ + 2OH^−^ (vùng cathode kiềm) |
| Nước ở anode | 2H~2~O → O~2~ + 4H^+^ + 4e (vùng anode acid) |
| Thứ tự ở cathode | Au^3+^ > Ag^+^ > Hg^2+^ > (Fe^3+^) > Cu^2+^ > H^+^ > H~2~O (SGK); quy ước làm đề: Zn^2+^, Fe^2+^, Ni^2+^… bị khử sau H^+^, trước H~2~O; K^+^, Na^+^, Ca^2+^, Mg^2+^, Al^3+^ không bị khử trong dung dịch |
| Thứ tự ở anode (trơ) | I^−^ > Br^−^ > Cl^−^ > H~2~O; SO~4~^2−^, NO~3~^−^, CO~3~^2−^, PO~4~^3−^, ClO~4~^−^, F^−^ không bị điện phân |
| Anode tan | Anode kim loại (không trơ) bị oxi hoá trước: M → M^n+^ + ne |
| đpdd CuSO~4~ | 2CuSO~4~ + 2H~2~O → 2Cu + O~2~ + 2H~2~SO~4~ |
| đpdd NaCl có màng ngăn | 2NaCl + 2H~2~O → 2NaOH + H~2~ + Cl~2~ |
| đpdd NaCl không màng ngăn | NaCl + H~2~O → NaClO + H~2~ (nước Javel) |
| Sản xuất Al | 2Al~2~O~3~ → 4Al + 3O~2~ (đpnc, cryolite, gần 1 000 °C); anode than chì cháy dần |
| Tinh chế đồng | Anode đồng thô tan, cathode đồng tinh khiết; [Cu^2+^] gần như không đổi |
| Mạ điện | Vật cần mạ = cathode; kim loại mạ = anode; dung dịch muối kim loại mạ |
| Tính toán (mở rộng, ngoài SGK) | $n_e = It/F$, F = 96 500 C/mol, t (s); m = A·I·t/(n·F); n(O~2~) = n~e~/4 |
