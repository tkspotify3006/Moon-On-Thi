---
title: Ôn tập chương 4
thoi-gian: 50 phút
muc-tieu:
  - Hệ thống hoá các khái niệm của chương: polymer, monomer, mắt xích, hệ số polymer hoá, trùng hợp, trùng ngưng, ba kiểu phản ứng của polymer (cắt mạch, tăng mạch, giữ nguyên mạch).
  - Lập và dùng được bảng "polymer – monomer – phản ứng điều chế – loại vật liệu" cho các chất dẻo, tơ, cao su, keo dán trong SGK.
  - Phân biệt được các cặp dễ nhầm: tính dẻo và tính đàn hồi, nhiệt dẻo và nhiệt rắn, tơ tổng hợp và tơ bán tổng hợp, polyamide và nitron, buna-S và buna-N, PPF và poly(urea-formaldehyde).
  - Từ mắt xích suy ra monomer và phương pháp điều chế, viết được phương trình trùng hợp, trùng ngưng.
  - Giải được bài toán tổng hợp: nhận diện polymer qua hệ số polymer hoá, chuỗi sản xuất nhiều giai đoạn có hiệu suất (nối với chương 2), trùng ngưng tách nước, tỉ lệ mắt xích trong cao su.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. **Polymer** = phân tử rất lớn gồm nhiều **mắt xích**. Hệ số polymer hoá n = M(polymer) : M(mắt xích), chỉ là giá trị **trung bình**.
> 2. Tên gọi: **poly + tên monomer**, tên monomer có từ hai cụm trở lên thì đặt trong ngoặc: poly(vinyl chloride).
> 3. **Trùng hợp**: monomer có **C=C** hoặc **vòng kém bền**, không tách chất nào, m(polymer) = m(monomer).
> 4. **Trùng ngưng**: monomer có **≥ 2 nhóm chức**, tách ra H~2~O, mắt xích nhẹ hơn monomer.
> 5. Polymer rắn, **không có nhiệt độ nóng chảy xác định**. Nhiệt dẻo thì tái chế được, nhiệt rắn thì không.
> 6. Ba kiểu phản ứng: **cắt mạch** (nhiệt phân PS, thuỷ phân polyamide), **tăng mạch** (lưu hoá cao su), **giữ nguyên mạch** (phản ứng ở nhóm thế, ví dụ poly(vinyl acetate) + NaOH).
> 7. **Chất dẻo** (tính dẻo): PE, PP, PVC, PS, PMMA (trùng hợp), PPF (trùng ngưng). **Composite** = cốt + nền.
> 8. **Tơ** (sợi mảnh): tự nhiên (bông, len, tơ tằm), bán tổng hợp (visco, cellulose acetate), tổng hợp (nylon-6,6, capron, nitron).
> 9. **Cao su** (đàn hồi): tự nhiên là polyisoprene *cis*. Cao su tổng hợp **đều trùng hợp**: buna, buna-S, buna-N, isoprene, chloroprene.
> 10. **Keo dán**: nhựa vá săm, epoxy (hai thành phần), poly(urea-formaldehyde) (trùng ngưng).

Bài này **không giảng lại từ đầu**. Em dùng nó để xâu chuỗi hai bài: Bài 12 (Đại cương về polymer) và Bài 13 (Vật liệu polymer). Chỗ nào chưa vững, hãy quay lại đúng mục được dẫn.

## 1. Hệ thống hoá kiến thức

### 1.1. Bức tranh toàn chương

Cả chương trả lời ba câu hỏi nối tiếp nhau:

1. **Polymer là gì, gọi tên ra sao?** Chuỗi hạt dài gồm các mắt xích giống nhau (Bài 12, mục 1).
2. **Làm ra polymer bằng cách nào, nó có tính chất gì?** Trùng hợp hoặc trùng ngưng; ba kiểu phản ứng cắt, tăng, giữ nguyên mạch (Bài 12, mục 2–4).
3. **Dùng polymer làm gì?** Năm nhóm vật liệu, mỗi nhóm được gọi theo **tính chất nổi bật** (Bài 13).

![Hình 1. Hệ thống hoá chương 4: polymer (khái niệm, điều chế, tính chất) và năm nhóm vật liệu polymer](he-thong.svg)

**Vì sao cùng một polymer lại có mặt ở nhiều nhóm vật liệu?** Vì nhóm vật liệu phụ thuộc **cách gia công và tính chất sử dụng**, không chỉ phụ thuộc công thức. Ví dụ polyisoprene là cao su, nhưng hoà tan cao su trong xăng thì được **nhựa vá săm** (keo dán). Nylon-6,6 kéo sợi thì là tơ. Nhựa epoxy vừa làm **keo dán**, vừa làm **vật liệu nền** của composite.

### 1.2. Bảng tổng hợp polymer của chương

Bảng dưới gom tất cả polymer trong bảng hệ thống hoá của SGK (tr. 65), xếp theo loại vật liệu. Đây là bảng em nên chép lại vào vở và học thuộc cột "monomer" và "phản ứng".

| Polymer (tên khác) | Monomer | Phản ứng | M mắt xích | Vật liệu |
|---|---|---|---|---|
| PE | CH~2~=CH~2~ | trùng hợp | 28 | chất dẻo |
| PP | CH~2~=CH–CH~3~ | trùng hợp | 42 | chất dẻo |
| PVC | CH~2~=CHCl | trùng hợp | 62,5 | chất dẻo |
| PS | CH~2~=CH–C~6~H~5~ | trùng hợp | 104 | chất dẻo |
| PMMA (thuỷ tinh hữu cơ) | CH~2~=C(CH~3~)–COOCH~3~ | trùng hợp | 100 | chất dẻo |
| PPF (bakelite…) | C~6~H~5~OH + HCHO | trùng ngưng | 106 | chất dẻo |
| nylon-6,6 | H~2~N–[CH~2~]~6~–NH~2~ + HOOC–[CH~2~]~4~–COOH | trùng ngưng | 226 | tơ tổng hợp |
| capron | caprolactam, hoặc H~2~N–[CH~2~]~5~–COOH | trùng hợp mở vòng, hoặc trùng ngưng | 113 | tơ tổng hợp |
| nitron (olon, polyacrylonitrile) | CH~2~=CH–CN | trùng hợp | 53 | tơ tổng hợp |
| cao su buna | CH~2~=CH–CH=CH~2~ | trùng hợp | 54 | cao su |
| cao su buna-S | buta-1,3-diene + styrene | đồng trùng hợp | 54 và 104 | cao su |
| cao su buna-N | buta-1,3-diene + CH~2~=CH–CN | đồng trùng hợp | 54 và 53 | cao su |
| cao su isoprene, cao su tự nhiên | CH~2~=C(CH~3~)–CH=CH~2~ | trùng hợp (cao su tự nhiên có sẵn trong mủ cây) | 68 | cao su |
| cao su chloroprene | CH~2~=C(Cl)–CH=CH~2~ | trùng hợp | 88,5 | cao su |
| poly(urea-formaldehyde) | H~2~N–CO–NH~2~ + HCHO | trùng ngưng | 72 | keo dán |
| tơ visco, tơ cellulose acetate | cellulose (chế biến hoá học) | không tổng hợp từ monomer | — | tơ bán tổng hợp |

**Đọc bảng theo quy luật thay vì học vẹt:**

- Mọi monomer có dạng **CH~2~=CH–X** hoặc **diene liên hợp** đều đi theo con đường **trùng hợp**. Đó là toàn bộ chất dẻo thông dụng, nitron và mọi cao su tổng hợp.
- Chỉ có **bốn** polymer trùng ngưng cần nhớ: **nylon-6,6, capron (một trong hai cách), PPF, poly(urea-formaldehyde)**. Hai polymer sau cùng có chung "chất bắc cầu" là **formaldehyde**.
- Tơ bán tổng hợp **không có monomer**: người ta lấy sẵn mạch cellulose rồi biến đổi (Bài 13, mục 3.3).

### 1.3. Từ mắt xích tìm monomer và phương pháp điều chế

Đây là kĩ năng xuất hiện trong gần như mọi đề (và là Câu 4 của phần Luyện tập SGK). Hình 2 gói gọn bốn trường hợp.

![Hình 2. Từ mắt xích tìm monomer và phương pháp điều chế: hai kiểu trùng hợp, hai kiểu trùng ngưng](mat-xich.svg)

**Vì sao mắt xích có nhóm –CO–NH– trên mạch chính thì là trùng ngưng?** Nhóm amide chỉ sinh ra khi –COOH gặp –NH~2~ và **tách nước**. Nếu "trả lại" phân tử nước đó (H cho N, OH cho C=O), em thu được monomer ban đầu. Ngược lại, mạch chính chỉ có C–C thì mắt xích sinh ra do **mở liên kết đôi**, không mất nguyên tử nào.

> [!bay] Hai ngoại lệ phải thuộc
> - **Capron** có –CO–NH– trên mạch nhưng thường được điều chế bằng **trùng hợp mở vòng** caprolactam. Capron điều chế được bằng **cả hai cách**.
> - **PPF và poly(urea-formaldehyde)** đi từ HCHO có liên kết đôi C=O, nhưng **không** phải trùng hợp. Phản ứng tách nước, nên là **trùng ngưng**.

### 1.4. Ba kiểu phản ứng của polymer

Cách nhớ: nhìn **chiều dài mạch** sau phản ứng, rồi tìm xem nhóm bị tấn công nằm **trên mạch chính** hay **ở nhánh** (Bài 12, mục 3).

| Kiểu | Mạch sau phản ứng | Ví dụ trong chương | Dấu hiệu nhận ra |
|---|---|---|---|
| Cắt mạch | ngắn đi | nhiệt phân PS → styrene; thuỷ phân capron, nylon-6,6; thuỷ phân tinh bột, cellulose | nhóm amide, glycoside nằm **trên mạch chính**, hoặc nhiệt phân |
| Tăng mạch | dài ra, thành mạng lưới | lưu hoá cao su (cầu –S–S–) là ví dụ của SGK. Mở rộng: keo epoxy, poly(urea-formaldehyde) đóng rắn cũng nối mạch thành mạng lưới | có "cầu nối" giữa các mạch |
| Giữ nguyên mạch | n không đổi | poly(vinyl acetate) + NaOH; PMMA + NaOH; cao su cộng H~2~, Br~2~ | nhóm ester **ở nhánh**, hoặc cộng vào C=C trong mạch |

> [!nen-tang] Mạch chính và nhánh
> - Mạch chính là dãy nguyên tử nối liên tiếp từ mắt xích này sang mắt xích kia (trong dấu ngoặc của công thức).
> - Nhánh là nhóm "treo" bên cạnh, ví dụ –Cl của PVC, –COOCH~3~ của PMMA, –OCOCH~3~ của poly(vinyl acetate).
> - Phá nhóm ở nhánh thì mạch không đứt. Phá liên kết trên mạch chính thì mạch đứt.

## 2. So sánh – phân biệt các khái niệm dễ nhầm

### 2.1. Năm nhóm vật liệu polymer

| | Chất dẻo | Composite | Tơ | Cao su | Keo dán |
|---|---|---|---|---|---|
| Tính chất đặc trưng | **dẻo**: biến dạng rồi **giữ** hình dạng mới | tính chất **vượt trội** so với từng thành phần | **sợi mảnh**, bền, dai | **đàn hồi**: biến dạng rồi **trở lại** như cũ | **kết dính** hai bề mặt rắn |
| Cấu tạo mạch hay thành phần | polymer + chất độn, chất hoá dẻo, chất tạo màu | **cốt** (sợi, hạt) + **nền** | mạch **không nhánh**, xếp song song | mạch dài, cuộn như lò xo, có C=C | tạo màng mỏng, đông cứng |
| Ví dụ | PE, PP, PVC, PS, PMMA, PPF | sợi carbon + epoxy, bột gỗ + nhựa | bông, len, tằm, visco, nylon-6,6, capron, nitron | tự nhiên, buna, buna-S, buna-N, chloroprene | vá săm, epoxy, poly(urea-formaldehyde) |
| Xem lại | Bài 13, mục 1 | Bài 13, mục 2 | Bài 13, mục 3 | Bài 13, mục 4 | Bài 13, mục 5 |

### 2.2. Các cặp hay bị đánh tráo trong đề

| Cặp | Giống nhau | Khác nhau (chỗ đề hay hỏi) |
|---|---|---|
| Tính dẻo – tính đàn hồi | đều biến dạng khi chịu lực | dẻo **giữ** biến dạng (chất dẻo). Đàn hồi **trở lại** (cao su). Cao su **không** phải chất dẻo |
| Nhiệt dẻo – nhiệt rắn | đều là polymer rắn | nhiệt dẻo nóng chảy, tái chế được (PE, PVC, PET). Nhiệt rắn có mạng lưới, đun thì **phân huỷ** (bakelite, keo epoxy đã đóng rắn) |
| Tơ tổng hợp – tơ bán tổng hợp | đều qua nhà máy | tổng hợp đi từ **monomer** (nylon-6,6, capron, nitron). Bán tổng hợp đi từ **cellulose** có sẵn (visco, cellulose acetate) |
| Nylon-6,6 – capron | đều là tơ **polyamide**, có –CO–NH– | nylon-6,6: **hai** monomer, chỉ trùng ngưng, M mắt xích 226. Capron: **một** monomer, trùng hợp mở vòng **hoặc** trùng ngưng, M mắt xích 113 |
| Capron – nitron | đều là tơ tổng hợp, có N | nitron là polyacrylonitrile, mạch chỉ có C, nhóm –CN ở nhánh, **không** phải polyamide, bền với acid và kiềm hơn |
| Buna-S – buna-N | đều là đồng trùng hợp với buta-1,3-diene | monomer thứ hai: **S**tyrene hay acrylonitrile (có **N**). Buna-N bền dầu mỡ (găng tay nitrile) |
| Cao su tự nhiên – cao su isoprene | cùng mắt xích –CH~2~–C(CH~3~)=CH–CH~2~– | cao su tự nhiên lấy từ mủ cây (polymer thiên nhiên). Cao su isoprene do con người trùng hợp (polymer tổng hợp) |
| PPF – poly(urea-formaldehyde) | đều trùng ngưng với HCHO, tách H~2~O | PPF đi từ **phenol**, là chất dẻo. Poly(urea-formaldehyde) đi từ **urea**, dùng làm keo dán gỗ ván ép |
| Len, tơ tằm – bông | đều là tơ tự nhiên | len, tơ tằm là **protein** (kém bền với kiềm). Bông là **cellulose** |
| Monomer – mắt xích | cùng thành phần nguyên tố (khi trùng hợp) | monomer có C=C, mắt xích **không còn** C=C đó. Khi trùng ngưng, mắt xích còn **ít nguyên tử** hơn monomer |

> [!meo] Ba câu hỏi xếp loại mọi polymer
> - *Nguồn gốc?* Có sẵn trong tự nhiên, chế biến từ polymer tự nhiên, hay tổng hợp từ monomer.
> - *Điều chế bằng gì?* Soát C=C (trùng hợp) hay ≥ 2 nhóm chức tách nước (trùng ngưng).
> - *Dùng làm gì?* Dẻo, sợi, đàn hồi, kết dính, hay tổ hợp cốt + nền.
>
> Trả lời đủ ba câu thì mọi câu "có bao nhiêu chất…" chỉ còn là đếm.

## 3. Bảng công thức tính toán của chương

| Bài toán | Công thức / tỉ lệ | Xem lại |
|---|---|---|
| Hệ số polymer hoá | n = M(polymer) : M(mắt xích) | Bài 12, Dạng 3 |
| Trùng hợp (H = 100%) | 1 monomer → 1 mắt xích; m(polymer) = m(monomer) | Bài 12, mục 4.1 |
| Trùng ngưng | 1 mắt xích nylon-6,6 tách 2H~2~O; 1 mắt xích capron, PPF, poly(urea-formaldehyde) tách 1H~2~O | Bài 12, mục 4.2 |
| Hiệu suất nhiều giai đoạn | H = H~1~ · H~2~ · …; đi xuôi nhân H, đi ngược chia H | Bài 12, Ví dụ 12 |
| Lưu hoá cao su | 1 cầu –S–S– thêm 64 và thay 2H: %S = 64 : (M·k + 62) | Bài 12, Dạng 4 |
| Cộng Br~2~, H~2~ vào cao su | 1 mắt xích diene (buta-1,3-diene, isoprene, chloroprene) cộng 1 Br~2~; mắt xích styrene, acrylonitrile **không** cộng | Bài 13, Ví dụ 6, 7 |
| Tỉ lệ mắt xích buna-N | %N = 14b : (54a + 53b) | Bài 13, Dạng 4 |
| Cellulose acetate | 162 → 246 (diacetate), 288 (triacetate); mỗi nhóm –OH acetyl hoá sinh 1 CH~3~COOH | Bài 13, Ví dụ 5 |
| Chuỗi từ cellulose, tinh bột | C~6~H~10~O~5~ (162) → C~6~H~12~O~6~ → 2C~2~H~5~OH | Bài 6, Bài 7 |

> [!bay] Ba "con số" dễ quên của chương
> - Nylon-6,6 tách **2** H~2~O mỗi mắt xích (M = 146 + 116 − 36 = 226), không phải 1.
> - Cầu disulfide có **2** nguyên tử S (64), không phải 32.
> - Mắt xích acrylonitrile C~3~H~3~N có M = **53**, chloroprene C~4~H~5~Cl có M = **88,5**.

## 4. Lỗi sai hay gặp của cả chương

**Về khái niệm và gọi tên**

- Nói polymer có phân tử khối, nhiệt độ nóng chảy **xác định** (đều chỉ là giá trị trung bình, khoảng nhiệt độ).
- Coi polymer và monomer là đồng phân, vì cùng thành phần phần trăm (công thức phân tử khác nhau).
- Viết "polyvinyl chloride" không có ngoặc (đúng là **poly(vinyl chloride)**).
- Cho monomer của PVC là ethyl chloride CH~3~–CH~2~Cl (không có C=C, không trùng hợp được).

**Về điều chế**

- Cho benzene, toluene trùng hợp được vì "có liên kết đôi" (vòng benzene bền, không mở ra). Styrene trùng hợp nhờ nhóm **vinyl**.
- Xếp PPF, poly(urea-formaldehyde) vào loại trùng hợp vì HCHO có C=O.
- Nói capron **chỉ** điều chế bằng trùng ngưng (còn trùng hợp mở vòng caprolactam).
- Nói nitron điều chế bằng trùng ngưng, hoặc là tơ polyamide.
- Quên rằng **mọi** cao su tổng hợp trong SGK đều điều chế bằng trùng hợp.

**Về tính chất và vật liệu**

- Gọi thuỷ phân poly(vinyl acetate) là cắt mạch (nhóm ester ở **nhánh**, mạch giữ nguyên).
- Gọi lưu hoá cao su là cắt mạch (đúng là **tăng mạch**, tạo mạng lưới).
- Xếp tơ visco, cellulose acetate vào tơ tổng hợp hoặc tơ tự nhiên (đúng là **bán tổng hợp**).
- Coi composite là hợp chất mới (cốt và nền **không** phản ứng với nhau).
- Nhầm vai trò: **cốt** chịu lực, **nền** gắn kết.
- Cho rằng keo epoxy khô nhờ dung môi bay hơi (đó là nhựa vá săm). Epoxy đông cứng nhờ **phản ứng** với amine.

**Về tính toán**

- Quên trừ H~2~O khi trùng ngưng (lấy 262 thay 226 cho nylon-6,6).
- Nhân H khi đi ngược, hoặc chỉ dùng một hiệu suất trong chuỗi nhiều giai đoạn.
- Quên hệ số khi đổi số nguyên tử C: 2CH~4~ → 1C~2~H~2~, 2C~2~H~5~OH → 1C~4~H~6~.
- Cho Br~2~ cộng vào vòng benzene của mắt xích styrene.

## 5. Bài tập tổng hợp

Các ví dụ dưới đây phối hợp nhiều bài. Hãy tự làm trước, mở từng gợi ý khi bí.

### 5.1. Phân loại tổng hợp – đếm số chất

> [!vi-du] Ví dụ 1
> Cho các polymer: polyethylene, poly(vinyl chloride), nylon-6,6, capron, tơ nitron, tơ visco, cao su buna-S, poly(phenol formaldehyde), cao su thiên nhiên, poly(urea-formaldehyde).
>
> a) Có bao nhiêu polymer **có thể** được điều chế bằng phản ứng trùng hợp?
>
> b) Có bao nhiêu polymer **có thể** được điều chế bằng phản ứng trùng ngưng?
>
> c) Có bao nhiêu polymer trong phân tử có nguyên tố nitrogen?
>
> d) Có bao nhiêu polymer tổng hợp?

> [!goi-y] Gợi ý 1
> Lập bảng 10 dòng, mỗi dòng ghi: monomer, phản ứng điều chế, nguyên tố có trong mắt xích, nguồn gốc. Dùng bảng ở mục 1.2.

> [!goi-y] Gợi ý 2
> Capron được tính ở **cả** câu a và câu b. Tơ visco và cao su thiên nhiên **không** được tổng hợp từ monomer, nên không thuộc câu a, b, d.

> [!loi-giai] Lời giải
> a) Polyethylene, poly(vinyl chloride), capron (mở vòng caprolactam), nitron, buna-S → **5**.
>
> b) Nylon-6,6, capron (từ 6-aminohexanoic acid), PPF, poly(urea-formaldehyde) → **4**.
>
> c) Nylon-6,6, capron (nhóm –CO–NH–), nitron (nhóm –CN), poly(urea-formaldehyde) (từ urea) → **4**. Buna-S chỉ gồm C và H.
>
> d) Tất cả trừ tơ visco (bán tổng hợp) và cao su thiên nhiên (thiên nhiên) → **8**.

### 5.2. Nhận diện polymer qua hệ số polymer hoá

> [!vi-du] Ví dụ 2
> Polymer X được điều chế bằng phản ứng trùng hợp một monomer dạng CH~2~=CH–R. Một mẫu X có phân tử khối trung bình là 150 000 và hệ số polymer hoá trung bình là 2 400.
>
> a) Xác định X.
>
> b) Tính khối lượng monomer cần dùng để sản xuất 5 tấn X, biết hiệu suất trùng hợp là 80%.
>
> c) Vì sao X được dùng làm ống nước, vỏ dây điện?

> [!goi-y] Gợi ý 1
> M(mắt xích) = M(polymer) : n. Mắt xích –CH~2~–CHR– có phần –CH~2~–CH– nặng 27.

> [!goi-y] Gợi ý 2
> Trùng hợp không mất nguyên tử nào, nên m(monomer) lí thuyết = m(polymer). Tìm nguyên liệu là đi ngược: **chia** H.

> [!loi-giai] Lời giải
> a) M(mắt xích) = 150 000 : 2 400 = 62,5 → M(R) = 62,5 − 27 = 35,5 → R là Cl. X là **poly(vinyl chloride)** (PVC), monomer CH~2~=CHCl.
>
> b) m(vinyl chloride) = 5 : 0,8 = **6,25 tấn**.
>
> c) PVC cứng, bền, không bị nước ăn mòn, **cách điện** tốt (mạch chỉ có liên kết cộng hoá trị), lại khó cháy nhờ chlorine (Bài 13, mục 1.3).

### 5.3. Chuỗi sản xuất nối chương 2 với chương 4

> [!vi-du] Ví dụ 3
> Cao su buna từng được sản xuất từ ethanol, và ethanol có thể lấy từ gỗ. Xét quy trình theo sơ đồ:
>
> cellulose → glucose → ethanol → buta-1,3-diene → cao su buna
>
> Hiệu suất các giai đoạn lần lượt là 60%, 80%, 50% và 80%. Gỗ chứa 50% cellulose về khối lượng. Tính khối lượng gỗ cần dùng để sản xuất 1 tấn cao su buna.

> [!goi-y] Gợi ý 1
> Viết sơ đồ hợp thức theo số nguyên tử C: C~6~H~10~O~5~ → C~6~H~12~O~6~ → 2C~2~H~5~OH → C~4~H~6~. Một mắt xích cellulose cho đúng **một** mắt xích buna.

> [!goi-y] Gợi ý 2
> H chung = 0,6 · 0,8 · 0,5 · 0,8. Đi ngược thì **chia** H, rồi chia tiếp cho 50% để từ cellulose ra gỗ.

> [!loi-giai] Lời giải
> Phản ứng tạo buta-1,3-diene từ ethanol (xem khung nền tảng bên dưới):
>
> => 2C~2~H~5~OH → CH~2~=CH–CH=CH~2~ + 2H~2~O + H~2~    (xt, t°)
>
> n(C~4~H~6~) = 1 000 : 54 kmol → n(C~6~H~10~O~5~) lí thuyết = 1 000 : 54 kmol.
>
> H chung = 0,6 · 0,8 · 0,5 · 0,8 = 0,192.
>
> m(cellulose) = (1 000 : 54) · 162 : 0,192 = 15 625 kg.
>
> m(gỗ) = 15 625 : 0,5 = 31 250 kg = **31,25 tấn**.
>
> Nếu quên hiệu suất, em chỉ ra 6 tấn gỗ: con số nhỏ hơn rất nhiều, vì lí thuyết không có hao hụt.

> [!nen-tang] Ethanol → buta-1,3-diene (phương pháp Lebedev, mở rộng ngoài SGK)
> - Cho hơi ethanol qua xúc tác (Al~2~O~3~, ZnO) ở khoảng 400–450 °C: 2C~2~H~5~OH → CH~2~=CH–CH=CH~2~ + 2H~2~O + H~2~.
> - Phản ứng này không có trong SGK. Đề thi sẽ cho sẵn sơ đồ, em chỉ cần nhớ **2 ethanol → 1 buta-1,3-diene** (bảo toàn C: 2 · 2 = 4).

> [!ung-dung] Polymer "xanh" (mở rộng)
> Ngày nay ý tưởng này quay lại dưới tên **polymer sinh học**: ethanol từ mía được tách nước thành ethylene, rồi trùng hợp thành "PE xanh". Polymer giống hệt PE từ dầu mỏ, nhưng carbon trong nó lấy từ CO~2~ mà cây mía đã hấp thụ.

### 5.4. Trùng ngưng hay trùng hợp: khối lượng khác nhau thế nào?

> [!vi-du] Ví dụ 4
> Một nhà máy sản xuất capron theo hai cách.
>
> Cách 1: trùng ngưng 39,3 kg 6-aminohexanoic acid, hiệu suất 90%.
>
> Cách 2: trùng hợp 39,3 kg caprolactam, hiệu suất 90%.
>
> a) Tính khối lượng capron và khối lượng nước tách ra ở cách 1.
>
> b) Tính khối lượng capron ở cách 2. Vì sao cùng khối lượng nguyên liệu mà cách 2 cho nhiều capron hơn?
>
> c) Một mẫu capron có phân tử khối trung bình 22 600. Tính hệ số polymer hoá.

> [!goi-y] Gợi ý 1
> 6-aminohexanoic acid H~2~N–[CH~2~]~5~–COOH có M = 131. Caprolactam là C~6~H~11~NO, M = 113, đúng bằng M mắt xích capron.

> [!goi-y] Gợi ý 2
> Mỗi phân tử amino acid đi vào mạch thì tách ra **1** H~2~O. Caprolactam mở vòng thì không mất gì.

> [!loi-giai] Lời giải
> a) n(amino acid) = 39,3 : 131 = 0,3 kmol → n(mắt xích) = 0,3 · 0,9 = 0,27 kmol.
>
> m(capron) = 0,27 · 113 = **30,51 kg**. m(H~2~O) = 0,27 · 18 = **4,86 kg**.
>
> b) m(capron) = 39,3 · 0,9 = **35,37 kg** (trùng hợp nên khối lượng giữ nguyên, chỉ nhân H).
>
> Cách 2 nhiều hơn vì caprolactam (113) nhẹ hơn amino acid (131) đúng một phân tử nước: cùng 39,3 kg nhưng nhiều mol hơn, và không có nguyên tử nào bị tách ra.
>
> c) n = 22 600 : 113 = **200**.

### 5.5. Đúng/Sai trong bối cảnh thực tế

> [!vi-du] Ví dụ 5 (Đúng/Sai)
> Trong một gian bếp có: thớt nhựa PE, tay cầm xoong bằng nhựa bakelite, găng tay rửa bát bằng cao su buna-N, khăn lau sợi bông, tạp dề vải nylon-6,6, bình nước bằng PMMA trong suốt. Xét các phát biểu:
>
> a) Thớt PE và tay cầm bakelite đều có thể nấu chảy để tái chế.
>
> b) Găng tay buna-N bền với dầu mỡ, được điều chế bằng phản ứng đồng trùng hợp buta-1,3-diene với acrylonitrile.
>
> c) Khăn bông và tạp dề nylon-6,6 đều là tơ tổng hợp.
>
> d) Bình PMMA và thớt PE đều làm từ polymer điều chế bằng phản ứng trùng hợp.

> [!goi-y] Gợi ý 1
> Bakelite là polymer nhiệt dẻo hay nhiệt rắn? Cấu trúc mạch của nó ra sao?

> [!goi-y] Gợi ý 2
> Bông có nguồn gốc gì? Thành phần chính là chất nào?

> [!loi-giai] Lời giải
> a) **Sai**: PE là nhiệt dẻo nên tái chế được. Bakelite là **nhiệt rắn** (mạng lưới), đun nóng bị phân huỷ chứ không nóng chảy.
>
> b) **Đúng**: buna-N = buta-1,3-diene + CH~2~=CH–CN, bền dầu mỡ (găng tay nitrile).
>
> c) **Sai**: bông là tơ **tự nhiên** (cellulose). Chỉ nylon-6,6 là tơ tổng hợp.
>
> d) **Đúng**: PMMA từ methyl methacrylate và PE từ ethylene đều là trùng hợp.

## 6. Đối chiếu bài tập SGK (tr. 66)

**Câu 1, 2, 3, 5 (nhận biết monomer, kí hiệu).** Đều trả lời được ngay bằng bảng ở mục 1.2: polymer nào chứa chlorine, trùng hợp styrene ra polymer gì, PE đi từ monomer nào, buna-S từ hai chất nào. Lưu ý ở câu kiểu Câu 5: phương án "buta-1,3-diene và lưu huỳnh" là bẫy, vì lưu huỳnh dùng để **lưu hoá**, không phải monomer.

**Câu 4 (viết phương trình trùng hợp, trùng ngưng).** Dùng Hình 2 theo chiều ngược: monomer có C=C thì "mở" liên kết đôi, monomer có hai nhóm chức thì nối các nhóm chức và tách nước. Em hãy tự viết với ba monomer trong SGK, rồi luyện thêm bằng Ví dụ 6.

> [!vi-du] Ví dụ 6 (tương tự Câu 4)
> Viết phương trình hoá học điều chế polymer từ các monomer sau, cho biết đó là phản ứng trùng hợp hay trùng ngưng:
>
> a) CH~2~=CH–CN.
>
> b) H~2~N–[CH~2~]~6~–COOH.
>
> c) HOOC–C~6~H~4~–COOH (terephthalic acid) và HO–CH~2~–CH~2~–OH (ethylene glycol).

> [!goi-y] Gợi ý 1
> Câu a có C=C. Câu b có hai nhóm chức khác loại trong một phân tử, giống 6-aminohexanoic acid. Câu c có hai monomer, mỗi chất hai nhóm chức, giống nylon-6,6 nhưng nhóm tạo thành là **ester**.

> [!goi-y] Gợi ý 2
> Câu c: mỗi mắt xích gồm 1 phân tử acid và 1 phân tử alcohol, tách ra bao nhiêu phân tử nước?

> [!loi-giai] Lời giải
> a) Trùng hợp, tạo polyacrylonitrile (tơ nitron):
>
> => nCH~2~=CH–CN → (–CH~2~–CH(CN)–)~n~    (t°, xt, p)
>
> b) Trùng ngưng, tạo một tơ polyamide (tơ enang, mở rộng):
>
> => nH~2~N–[CH~2~]~6~–COOH → (–NH–[CH~2~]~6~–CO–)~n~ + nH~2~O    (t°, xt)
>
> c) Trùng ngưng, tạo PET (mở rộng: tơ lapsan, nhựa chai kí hiệu số 1):
>
> => nHOOC–C~6~H~4~–COOH + nHO–CH~2~–CH~2~–OH → (–CO–C~6~H~4~–CO–O–CH~2~–CH~2~–O–)~n~ + 2nH~2~O    (t°, xt)

**Câu 6 (keo siêu dính 502).** Thành phần chính của keo là một ester có nhóm –CN và liên kết đôi C=C dạng CH~2~=C(CN)–COOR. Hơi ẩm trong không khí chỉ đóng vai trò **khơi mào**, phản ứng xảy ra là **trùng hợp** ở liên kết C=C (không tách nước). Em hãy tự viết phương trình với methyl cyanoacrylate trong SGK theo cùng cách ở Ví dụ 7.

> [!vi-du] Ví dụ 7 (tương tự Câu 6)
> Một loại keo dán nhanh có thành phần chính là ethyl cyanoacrylate CH~2~=C(CN)–COOC~2~H~5~. Khi bôi lên bề mặt, nhờ hơi ẩm, chất này nhanh chóng tạo thành màng polymer.
>
> a) Viết phương trình phản ứng tạo polymer và gọi tên loại phản ứng.
>
> b) Tính phân tử khối của một mắt xích polymer.
>
> c) Vì sao tuýp keo phải đậy thật kín sau khi dùng?

> [!goi-y] Gợi ý 1
> Monomer có dạng CH~2~=CX–Y, giống methyl methacrylate. Liên kết đôi mở ra, hai nhóm –CN và –COOC~2~H~5~ treo ở nhánh.

> [!goi-y] Gợi ý 2
> Mắt xích có cùng công thức phân tử với monomer: C~6~H~7~NO~2~.

> [!loi-giai] Lời giải
> a) Phản ứng **trùng hợp**:
>
> => nCH~2~=C(CN)–COOC~2~H~5~ → (–CH~2~–C(CN)(COOC~2~H~5~)–)~n~    (hơi ẩm)
>
> b) M(C~6~H~7~NO~2~) = 72 + 7 + 14 + 32 = **125**.
>
> c) Hơi ẩm của không khí lọt vào tuýp sẽ khơi mào phản ứng trùng hợp ngay trong tuýp, keo đông cứng, không dùng được nữa.

> [!em-co-biet] Vì sao keo 502 dính tay rất nhanh?
> Da người luôn có một lớp ẩm mỏng, nên phản ứng trùng hợp xảy ra gần như tức thì. Muốn gỡ, người ta dùng acetone (có trong nước rửa sơn móng tay), vì nước không hoà tan được màng polymer đã tạo thành.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Polymer | nhiều mắt xích; n = M(polymer) : M(mắt xích); hỗn hợp các mạch dài ngắn khác nhau |
| Trùng hợp | C=C hoặc vòng kém bền; không tách chất; PE, PP, PVC, PS, PMMA, nitron, mọi cao su tổng hợp, capron (caprolactam) |
| Trùng ngưng | ≥ 2 nhóm chức; tách H~2~O; nylon-6,6, capron (amino acid), PPF, poly(urea-formaldehyde) |
| Cắt mạch | nhiệt phân PS; thuỷ phân polyamide, tinh bột, cellulose |
| Tăng mạch | lưu hoá cao su (cầu –S–S–) |
| Giữ nguyên mạch | phản ứng ở nhóm thế: poly(vinyl acetate) + NaOH; cộng vào C=C |

| Vật liệu | Tính chất | Đại diện |
|---|---|---|
| Chất dẻo | dẻo | PE, PP, PVC, PS, PMMA, PPF |
| Composite | cốt + nền, vượt trội | sợi carbon + epoxy |
| Tơ | sợi mảnh, bền | tự nhiên: bông, len, tằm · bán tổng hợp: visco, acetate · tổng hợp: nylon-6,6, capron, nitron |
| Cao su | đàn hồi | tự nhiên · buna, buna-S, buna-N, isoprene, chloroprene |
| Keo dán | kết dính | nhựa vá săm, epoxy, poly(urea-formaldehyde) |

**M mắt xích cần nhớ:** PE 28 · PP 42 · nitron 53 · buta-1,3-diene 54 · PVC 62,5 · polyisoprene 68 · poly(urea-formaldehyde) 72 · chloroprene 88,5 · PMMA 100 · PS 104 · PPF 106 · capron 113 · cellulose 162 · nylon-6,6 226.

**Ba bước giải mọi bài toán của chương:**

1. Đổi ra **mol mắt xích** (bỏ qua n), xác định monomer nào cho mắt xích nào.
2. Trùng hợp: khối lượng giữ nguyên. Trùng ngưng: **trừ nước**. Chuỗi nhiều giai đoạn: bảo toàn số nguyên tử C.
3. Xử lí **hiệu suất** (đi xuôi nhân, đi ngược chia, nhiều giai đoạn thì nhân các H) và **hàm lượng %** trong nguyên liệu.
