---
title: Cấu tạo và liên kết trong tinh thể kim loại
thoi-gian: 30 phút
muc-tieu:
  - Xác định được vị trí của kim loại trong bảng tuần hoàn; từ số hiệu nguyên tử hoặc cấu hình electron, nhận ra được nguyên tố là kim loại hay phi kim.
  - Trình bày được đặc điểm cấu tạo của nguyên tử kim loại (ít electron lớp ngoài cùng, bán kính lớn, độ âm điện nhỏ) và giải thích vì sao kim loại dễ nhường electron.
  - Mô tả được cấu tạo tinh thể kim loại (ion dương ở nút mạng, electron hoá trị tự do) và nhận biết ba kiểu mạng tinh thể phổ biến.
  - Nêu được đặc điểm của liên kết kim loại; so sánh được liên kết kim loại với liên kết ion và liên kết cộng hoá trị.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Các nguyên tố **khối s** (trừ H, He), **khối d**, **khối f** và một phần **khối p** (Al, Sn, Pb…) là kim loại. Kim loại chiếm khoảng **4/5** số nguyên tố.
> 2. Nguyên tử của hầu hết kim loại có **1, 2 hoặc 3 electron lớp ngoài cùng**. So với phi kim cùng chu kì: điện tích hạt nhân **nhỏ hơn**, bán kính **lớn hơn** → **dễ nhường electron**, độ âm điện **nhỏ hơn**.
> 3. Ở nhiệt độ phòng, kim loại là **chất rắn có cấu tạo tinh thể**, riêng **thuỷ ngân (Hg) ở thể lỏng**.
> 4. Tinh thể kim loại: **ion dương** nằm ở **nút mạng**, **electron hoá trị chuyển động tự do** giữa các ion.
> 5. **Liên kết kim loại** = lực hút tĩnh điện giữa các **electron hoá trị tự do** và các **ion dương kim loại** ở nút mạng.

Dây điện bằng đồng, nồi bằng nhôm, nhẫn bằng vàng: kim loại dẫn điện tốt, dát mỏng được, sáng lấp lánh. Bí mật nằm ở **cấu tạo nguyên tử** và **kiểu liên kết** của kim loại. Đây là nền cho toàn bộ Chương 6.

## 1. Đặc điểm cấu tạo của nguyên tử kim loại

> [!nen-tang] Cấu hình electron và bảng tuần hoàn (Hoá học 10)
> - Thứ tự năng lượng các phân lớp: 1s 2s 2p 3s 3p **4s 3d** 4p 5s 4d 5p 6s 4f 5d 6p… (phân lớp 4s được điền **trước** 3d).
> - Viết cấu hình thì sắp lại theo **từng lớp**: ví dụ Fe (Z = 26) là 1s^2^2s^2^2p^6^3s^2^3p^6^**3d^6^4s^2^**, viết gọn [Ar]3d^6^4s^2^.
> - Hai trường hợp "bán bão hoà, bão hoà" cần thuộc: Cr (Z = 24) là [Ar]3d^5^4s^1^ và Cu (Z = 29) là [Ar]3d^10^4s^1^.
> - **Số thứ tự chu kì** = số lớp electron.
> - Nguyên tố **khối s, p** (electron cuối điền vào s hoặc p) thuộc **nhóm A**: số thứ tự nhóm = số electron lớp ngoài cùng.
> - Nguyên tố **khối d** thuộc **nhóm B**: tính tổng số electron (n−1)d + ns. Tổng 3 đến 7 → nhóm IIIB đến VIIB; tổng 8, 9, 10 → nhóm VIIIB; tổng 11 → IB; tổng 12 → IIB.

### 1.1. Vị trí của kim loại trong bảng tuần hoàn

Nhìn vào bảng tuần hoàn (Hình 1), em sẽ thấy kim loại chiếm gần hết bảng. Có thể nhớ theo **khối nguyên tố**:

- **Khối s** (nhóm IA, IIA): đều là kim loại, **trừ H và He**. Nhóm IA gồm Li, Na, K, Rb, Cs, Fr (kim loại kiềm). Nhóm IIA gồm Be, Mg, Ca, Sr, Ba, Ra.
- **Khối d** (các nhóm B, gọi là kim loại chuyển tiếp): **toàn bộ là kim loại**, ví dụ Fe, Cu, Zn, Cr, Ag, Au.
- **Khối f** (họ lanthanide và họ actinide, xếp thành hai hàng riêng ở cuối bảng): **toàn bộ là kim loại**.
- **Khối p** (nhóm IIIA đến VIIIA): phần lớn là phi kim và khí hiếm. Chỉ **một phần** là kim loại, nằm ở **góc dưới bên trái** của khối p: Al, Ga, In, Tl (nhóm IIIA), Sn, Pb (nhóm IVA), Bi (nhóm VA)…

![Hình 1. Kim loại (xanh) và phi kim, khí hiếm (cam) trong bảng tuần hoàn. Đường bậc thang ngăn cách hai vùng; các nguyên tố sát đường này (B, Si, Ge, As, Sb, Te) có tính chất trung gian](bang-tuan-hoan.svg)

> [!bay]
> - **H ở nhóm IA nhưng là phi kim.** Câu "mọi nguyên tố nhóm IA đều là kim loại" là **sai**. Câu đúng là "mọi nguyên tố nhóm IA **trừ hydrogen** đều là kim loại kiềm".
> - **Al** ở nhóm **IIIA** (khối p) nhưng là kim loại. Đừng nghĩ cứ khối p là phi kim.

### 1.2. Cấu hình electron đặc trưng: ít electron lớp ngoài cùng

Hãy so sánh lớp ngoài cùng của một số nguyên tử:

| Nguyên tố | Z | Cấu hình electron | Số e lớp ngoài cùng | Loại |
|---|---|---|---|---|
| Na | 11 | [Ne]3s^1^ | 1 | kim loại |
| Mg | 12 | [Ne]3s^2^ | 2 | kim loại |
| Al | 13 | [Ne]3s^2^3p^1^ | 3 | kim loại |
| Cl | 17 | [Ne]3s^2^3p^5^ | 7 | phi kim |
| Fe | 26 | [Ar]3d^6^4s^2^ | 2 | kim loại |
| Cu | 29 | [Ar]3d^10^4s^1^ | 1 | kim loại |

Quy luật: nguyên tử của **hầu hết** kim loại có **1 đến 3 electron ở lớp ngoài cùng**. Phi kim thường có 4 đến 7 electron lớp ngoài cùng.

Với **kim loại chuyển tiếp** (khối d), lớp ngoài cùng là lớp ns, chỉ có **1 hoặc 2 electron** (ns^1^ hoặc ns^2^). Các electron còn lại đang điền vào phân lớp **(n−1)d sát lớp ngoài cùng**. Ví dụ Sc (Z = 21) là [Ar]3d^1^4s^2^: 2 electron lớp ngoài cùng, 1 electron ở phân lớp 3d (em hãy tự viết cho Ti, Z = 22, như câu hỏi SGK tr. 87). Electron mới thêm vào lớp trong, nên lớp ngoài cùng thường chỉ có 1–2 electron. Vì vậy **tất cả** nguyên tố khối d đều là kim loại.

> [!bay] Một số kim loại có 4–5 electron lớp ngoài cùng
> "1 đến 3 electron lớp ngoài cùng" chỉ đúng với **hầu hết** kim loại: Sn, Pb có **4**, Bi có **5**. Ngược lại, H (1s^1^) và He (1s^2^) chỉ có 1–2 electron lớp ngoài cùng nhưng **không** phải kim loại.

> [!vi-du] Ví dụ 1
> Cho bốn nguyên tố X (Z = 12), Y (Z = 17), T (Z = 19), R (Z = 26).
>
> a) Viết cấu hình electron của mỗi nguyên tử.
>
> b) Nguyên tố nào là kim loại? Xác định vị trí (chu kì, nhóm) của các kim loại đó.

> [!goi-y] Gợi ý 1
> Điền electron theo thứ tự năng lượng. Với Z = 19 và Z = 26, nhớ rằng phân lớp 4s được điền trước 3d.

> [!goi-y] Gợi ý 2
> Đếm số electron lớp ngoài cùng. Với R, electron cuối điền vào phân lớp d nên R thuộc nhóm B: cộng số electron 3d và 4s.

> [!loi-giai] Lời giải
> a) X: 1s^2^2s^2^2p^6^3s^2^.
>
> Y: 1s^2^2s^2^2p^6^3s^2^3p^5^.
>
> T: 1s^2^2s^2^2p^6^3s^2^3p^6^4s^1^.
>
> R: 1s^2^2s^2^2p^6^3s^2^3p^6^3d^6^4s^2^.
>
> b) X có 2 e lớp ngoài cùng, T có 1, R có 2 (lớp 4s): ba nguyên tố này là **kim loại**. Y có 7 e lớp ngoài cùng nên là phi kim (Cl).
>
> X (Mg): 3 lớp e → chu kì 3, khối s, 2 e lớp ngoài cùng → nhóm IIA.
>
> T (K): chu kì 4, nhóm IA.
>
> R (Fe): chu kì 4, khối d, tổng 6 + 2 = 8 electron (3d + 4s) → nhóm **VIIIB**.

### 1.3. Vì sao nguyên tử kim loại dễ nhường electron?

So sánh trong **cùng một chu kì**, ví dụ chu kì 3: Na (Z = 11) và Cl (Z = 17) đều có 3 lớp electron.

- **Điện tích hạt nhân của kim loại nhỏ hơn**: +11 so với +17.
- **Bán kính của kim loại lớn hơn**: hạt nhân Na hút electron yếu hơn nên nguyên tử "phình" to hơn (Na khoảng 186 pm, gần gấp đôi Cl, khoảng 99 pm).

Kết quả: **electron lớp ngoài cùng của kim loại ở xa hạt nhân và bị hút yếu**. Nguyên tử kim loại vì thế **dễ nhường electron hoá trị** để tạo ion dương, và có **độ âm điện nhỏ** (Na: 0,93; Cl: 3,16 theo thang Pauling).

=> M → M^n+^ + ne    (n thường bằng 1, 2 hoặc 3)

Ví dụ: Na → Na^+^ + 1e; Mg → Mg^2+^ + 2e; Al → Al^3+^ + 3e.

> [!meo] Đọc cấu hình ion ngược ra nguyên tử
> Ion kim loại M^n+^ có ít hơn nguyên tử **n electron**. Muốn tìm Z của M: đếm tổng số electron trong cấu hình ion rồi **cộng thêm n**. Với kim loại chuyển tiếp, khi tạo ion, electron ở **4s bị mất trước** 3d: Fe [Ar]3d^6^4s^2^ → Fe^2+^ [Ar]3d^6^ → Fe^3+^ [Ar]3d^5^.

> [!vi-du] Ví dụ 2
> Ion M^3+^ có cấu hình electron 1s^2^2s^2^2p^6^.
>
> a) Xác định số hiệu nguyên tử và tên nguyên tố M.
>
> b) Nguyên tử M có bao nhiêu electron lớp ngoài cùng? M là kim loại hay phi kim?

> [!goi-y] Gợi ý 1
> Ion M^3+^ được tạo ra khi nguyên tử M nhường 3 electron. Ion có 10 electron, vậy nguyên tử M có bao nhiêu?

> [!goi-y] Gợi ý 2
> Viết cấu hình của nguyên tử M rồi đếm electron ở lớp thứ ba.

> [!loi-giai] Lời giải
> a) Ion M^3+^ có 2 + 2 + 6 = 10 electron. Nguyên tử M có 10 + 3 = **13** electron, nên Z = 13. M là **aluminium (Al)**.
>
> b) Al: 1s^2^2s^2^2p^6^**3s^2^3p^1^**, có **3** electron lớp ngoài cùng. Al là **kim loại** (nhóm IIIA, chu kì 3).

## 2. Tinh thể kim loại

### 2.1. Cấu tạo của tinh thể kim loại

Ở nhiệt độ phòng, các đơn chất kim loại đều ở **thể rắn** và có **cấu tạo tinh thể**. Ngoại lệ duy nhất là **thuỷ ngân (Hg)**, ở thể lỏng (vì thế được dùng trong nhiệt kế cũ).

"Tinh thể" nghĩa là các hạt **sắp xếp đều đặn, lặp lại** trong không gian, như gạch lát nền. Trong tinh thể kim loại:

- Nguyên tử kim loại nhường bớt electron hoá trị, trở thành **ion dương**, nằm ở **các nút mạng tinh thể** (chỉ dao động nhẹ quanh vị trí đó).
- Các **electron hoá trị** tách ra không thuộc riêng nguyên tử nào, **chuyển động tự do** trong khoảng trống giữa các ion. Người ta gọi đó là **"biển electron"**.

Hãy tưởng tượng các viên bi xếp thẳng hàng (ion dương) ngâm trong làn nước (electron tự do) len khắp mọi khe hở. Chính "làn nước" electron gắn các ion lại với nhau.

![Hình 2. Mô hình tinh thể kim loại: ion dương (vòng tròn cam, dấu +) ở nút mạng, electron hoá trị (chấm xanh) chuyển động tự do khắp tinh thể](tinh-the-kim-loai.svg)

> [!bay]
> - Nút mạng tinh thể kim loại là **ion dương**, không phải "nguyên tử trung hoà" và cũng không có ion âm.
> - Electron chuyển động tự do là **electron hoá trị** (electron lớp ngoài cùng), không phải toàn bộ electron. Các electron lớp trong vẫn ở lại với ion.

### 2.2. Các kiểu mạng tinh thể phổ biến (đọc thêm)

Phần "Em có biết" (SGK tr. 88) giới thiệu ba kiểu mạng thường gặp. **Độ đặc khít** là phần trăm thể tích tinh thể do các nguyên tử (coi là quả cầu) chiếm chỗ, phần còn lại là khe rỗng. **Số phối trí** là số nguyên tử ở gần sát một nguyên tử.

| Kiểu mạng | Độ đặc khít | Số phối trí | Ví dụ |
|---|---|---|---|
| Lập phương tâm khối (8 đỉnh + tâm khối) | 68% | 8 | Li, Na, K, Ba, Fe (nhiệt độ thường) |
| Lập phương tâm mặt (8 đỉnh + tâm 6 mặt) | 74% | 12 | Ca, Sr, Cu, Al, Ag, Au |
| Lục phương chặt khít (lăng trụ lục giác) | 74% | 12 | Be, Mg, Zn |

Ví dụ trong SGK: Li, Na, K, Ba; Ca, Sr, Cu; Be, Mg. Các ví dụ Fe, Al, Ag, Au, Zn là phần mở rộng ngoài SGK.

![Hình 3. Ba kiểu mạng tinh thể kim loại phổ biến. Nguyên tử ở tâm khối, ở tâm các mặt và ở lớp giữa (lục phương) được tô xanh](mang-tinh-the.svg)

**Vì sao số phối trí 8 ứng với độ đặc khít nhỏ hơn?** Nguyên tử ở tâm khối chỉ chạm 8 nguyên tử ở 8 đỉnh, nên giữa chúng còn nhiều khe hở (32% thể tích rỗng). Ở hai kiểu còn lại, mỗi nguyên tử được 12 nguyên tử khác bao quanh sát nhất, nên chỉ còn 26% khe rỗng.

> [!vi-du] Ví dụ 3 (mở rộng ngoài SGK, vận dụng cao)
> Sắt ở nhiệt độ thường có mạng lập phương tâm khối (độ đặc khít 68%), khối lượng riêng 7,87 g/cm^3^. Coi nguyên tử Fe là quả cầu, lấy M(Fe) = 56 và số Avogadro N~A~ = 6,022·10^23^. Tính bán kính gần đúng của nguyên tử Fe (đơn vị nm, làm tròn đến hàng phần nghìn).

> [!goi-y] Gợi ý 1
> Tính thể tích của 1 mol sắt (V = m : D). Chỉ 68% thể tích đó là do các nguyên tử chiếm, 32% còn lại là khe rỗng.

> [!goi-y] Gợi ý 2
> Thể tích một nguyên tử = (thể tích các nguyên tử trong 1 mol) : N~A~. Sau đó dùng công thức thể tích quả cầu $V=\frac{4}{3}\pi r^3$ để tìm r.

> [!loi-giai] Lời giải
> Thể tích 1 mol Fe: V = 56 : 7,87 ≈ 7,116 cm^3^.
>
> Thể tích thật của các nguyên tử trong 1 mol: 7,116 · 0,68 ≈ 4,839 cm^3^.
>
> Thể tích một nguyên tử: 4,839 : (6,022·10^23^) ≈ 8,035·10^−24^ cm^3^.
>
> $r=\sqrt[3]{\dfrac{3V}{4\pi}}=\sqrt[3]{\dfrac{3\cdot 8{,}035\cdot 10^{-24}}{4\pi}}\approx 1{,}243\cdot 10^{-8}$ cm.
>
> Đổi đơn vị: 1 nm = 10^−7^ cm, nên r ≈ **0,124 nm**.

> [!meo] Bấm máy tính nhanh
> Gõ một lần: $\sqrt[3]{\dfrac{3\times 56\times 0{,}68}{4\pi\times 7{,}87\times 6{,}022\times 10^{23}}}$ rồi nhân $10^7$ để ra nm. Lưu ý: không quên hệ số 0,68 (độ đặc khít). Nếu bỏ nó, kết quả sẽ lớn hơn (≈ 0,141 nm).

## 3. Liên kết kim loại

### 3.1. Liên kết kim loại là gì?

**Liên kết kim loại** được hình thành do **lực hút tĩnh điện** giữa các **electron hoá trị tự do** và các **ion dương kim loại** ở nút mạng tinh thể.

Các ion dương đẩy nhau, nhưng "biển electron" mang điện âm phủ kín các khe giữa chúng và hút tất cả về phía mình, giữ ion ở đúng nút mạng. Các electron này **không thuộc về một cặp nguyên tử nào**, mà là "của chung" toàn tinh thể.

**Vì sao chỉ kim loại mới tạo được kiểu liên kết này?** Vì nguyên tử kim loại có **ít electron hoá trị** và **giữ chúng rất lỏng lẻo** (mục 1.3). Electron dễ tách ra, đi lại tự do giữa các ion. Phi kim giữ electron chặt, nên chúng góp chung từng cặp electron với nhau (liên kết cộng hoá trị) hoặc nhận thêm electron (tạo ion âm).

> [!ung-dung] Liên kết kim loại giải thích tính chất của kim loại
> Học kĩ ở Bài 19, ở đây chỉ cần thấy mối liên hệ:
> - **Dẫn điện**: khi nối hai đầu dây đồng với pin, các electron tự do chuyển dời thành dòng có hướng. Đó là dòng điện.
> - **Dẻo, dát mỏng được**: khi gõ búa, các lớp ion trượt lên nhau, nhưng "biển electron" vẫn bao quanh và giữ chúng lại, nên kim loại không vỡ vụn. Lá vàng có thể dát mỏng đến mức ánh sáng xuyên qua.

### 3.2. So sánh liên kết kim loại với liên kết ion và liên kết cộng hoá trị

> [!nen-tang] Liên kết ion và liên kết cộng hoá trị (Hoá học 10)
> - **Liên kết ion**: hình thành do lực hút tĩnh điện giữa **ion dương và ion âm**. Thường gặp giữa kim loại điển hình và phi kim điển hình (NaCl, MgO). Electron đã **chuyển hẳn** từ nguyên tử kim loại sang nguyên tử phi kim.
> - **Liên kết cộng hoá trị**: hình thành do **một hay nhiều cặp electron dùng chung** giữa **hai nguyên tử** (H~2~, Cl~2~, H~2~O, CO~2~).

![Hình 4. So sánh ba kiểu liên kết: ion (ion dương – ion âm), cộng hoá trị (cặp electron dùng chung giữa hai nguyên tử), kim loại (ion dương – electron tự do của cả tinh thể)](so-sanh-lien-ket.svg)

| | Liên kết ion | Liên kết cộng hoá trị | Liên kết kim loại |
|---|---|---|---|
| Hạt tham gia | ion dương và ion âm | nguyên tử (cặp electron dùng chung) | ion dương và electron hoá trị tự do |
| Bản chất | lực hút tĩnh điện | sự dùng chung electron | lực hút tĩnh điện |
| Electron hoá trị | chuyển hẳn sang ion âm | thuộc riêng hai nguyên tử liên kết | của chung toàn tinh thể |
| Ví dụ | NaCl, KF, MgO | H~2~, Cl~2~, H~2~O | Na, Fe, Cu, Al |

**Giống nhau giữa liên kết kim loại và liên kết ion** (câu hỏi SGK tr. 88): cả hai đều do **lực hút tĩnh điện** giữa các phần tử **mang điện trái dấu**, và đều có **ion dương**.

**Khác nhau**: trong liên kết ion, ion dương hút **ion âm**. Trong liên kết kim loại, ion dương hút **electron tự do**, không có ion âm nào cả.

**So với liên kết cộng hoá trị**: cùng có electron dùng chung, nhưng cộng hoá trị dùng chung **giữa hai nguyên tử xác định**, còn kim loại dùng chung **cho cả tinh thể**.

> [!bay]
> - "Liên kết kim loại là liên kết giữa ion dương và ion âm": **sai** (đó là liên kết ion).
> - "Liên kết kim loại do các cặp electron dùng chung giữa hai nguyên tử kim loại": **sai** (đó là mô tả liên kết cộng hoá trị).
> - Liên kết kim loại có trong **đơn chất kim loại** (và hợp kim). Hợp chất của kim loại với phi kim như NaCl, CaO có **liên kết ion**, không phải liên kết kim loại.

## Dạng bài thi hay gặp

### Dạng 1. Xác định kim loại từ số hiệu nguyên tử, cấu hình electron hoặc vị trí

**Nhận biết:** đề cho Z, cấu hình electron của nguyên tử hoặc ion, hoặc vị trí (ô, chu kì, nhóm). Hỏi nguyên tố là kim loại hay phi kim, số electron lớp ngoài cùng, hoặc ngược lại hỏi Z.

**Phương pháp:**

1. Nếu đề cho ion: Z = số electron của ion **+ n** (ion dương M^n+^) hoặc **− n** (ion âm X^n−^).
2. Viết cấu hình nguyên tử (4s trước 3d; nhớ ngoại lệ Cr, Cu).
3. Electron cuối vào **d hoặc f** → chắc chắn là **kim loại**.
4. Electron cuối vào **s hoặc p**: đếm số e lớp ngoài cùng. 1–3 e → kim loại (trừ H, He, B). 4–7 e → thường là phi kim, trừ vài nguyên tố ở góc dưới khối p: Sn, Pb (4 e) và Bi (5 e) là kim loại; Ge, Sb… nằm sát đường bậc thang (Hình 1) có tính chất trung gian. 8 e → khí hiếm.

> [!vi-du] Ví dụ 4
> Nguyên tử X có tổng số electron ở các phân lớp p là 7. Nguyên tử Y có electron cuối cùng điền vào phân lớp 3d và có cấu hình ứng với nhóm IB. X và Y là kim loại hay phi kim? Tính tổng số hiệu nguyên tử Z~X~ + Z~Y~.

> [!goi-y] Gợi ý 1
> Các phân lớp p được điền theo thứ tự 2p (tối đa 6) rồi 3p. Tổng p bằng 7 nghĩa là 2p^6^3p^1^.

> [!goi-y] Gợi ý 2
> Nhóm IB ứng với tổng electron (3d + 4s) bằng 11. Nhớ ngoại lệ "bão hoà" của phân lớp d.

> [!loi-giai] Lời giải
> X: 1s^2^2s^2^2p^6^3s^2^3p^1^ → Z~X~ = 13 (Al), 3 e lớp ngoài cùng → **kim loại**.
>
> Y: [Ar]3d^10^4s^1^ → Z~Y~ = 18 + 10 + 1 = 29 (Cu) → **kim loại** (khối d).
>
> Z~X~ + Z~Y~ = 13 + 29 = **42**.

> [!bay]
> - Quên ngoại lệ Cu: viết [Ar]3d^9^4s^2^ vẫn ra Z = 29, nhưng sẽ đếm sai số electron lớp ngoài cùng (2 thay vì 1).
> - Với ion dương, phải **cộng** n vào số electron để ra Z, nhiều bạn trừ nhầm.

### Dạng 2. Đếm số kim loại (hoặc số nguyên tố có một đặc điểm) trong một dãy

**Nhận biết:** "Cho các nguyên tố có số hiệu nguyên tử…/các nguyên tố… Có bao nhiêu nguyên tố là kim loại?", "Có bao nhiêu nguyên tố chu kì 4 có 1 electron lớp ngoài cùng?".

**Phương pháp:** lập bảng nhanh: Z → cấu hình rút gọn → khối (s, p, d) → số e lớp ngoài cùng → kim loại/phi kim. Đánh dấu từng nguyên tố, cuối cùng mới đếm.

> [!vi-du] Ví dụ 5
> Cho các nguyên tố có số hiệu nguyên tử: 1, 3, 9, 14, 20, 24, 29, 35. Có bao nhiêu nguyên tố là kim loại? Trong cả dãy, có bao nhiêu nguyên tử có đúng 1 electron ở lớp ngoài cùng?

> [!goi-y] Gợi ý 1
> Z = 1 là H. Z = 24 và 29 là hai trường hợp ngoại lệ về cấu hình.

> [!goi-y] Gợi ý 2
> Lớp ngoài cùng của Cr và Cu đều là 4s^1^.

> [!loi-giai] Lời giải
> | Z | Nguyên tố | Cấu hình rút gọn | e lớp ngoài cùng | Loại |
> |---|---|---|---|---|
> | 1 | H | 1s^1^ | 1 | phi kim |
> | 3 | Li | [He]2s^1^ | 1 | kim loại |
> | 9 | F | [He]2s^2^2p^5^ | 7 | phi kim |
> | 14 | Si | [Ne]3s^2^3p^2^ | 4 | phi kim |
> | 20 | Ca | [Ar]4s^2^ | 2 | kim loại |
> | 24 | Cr | [Ar]3d^5^4s^1^ | 1 | kim loại |
> | 29 | Cu | [Ar]3d^10^4s^1^ | 1 | kim loại |
> | 35 | Br | [Ar]3d^10^4s^2^4p^5^ | 7 | phi kim |
>
> Có **4** kim loại: Li, Ca, Cr, Cu.
>
> Nguyên tử có đúng 1 electron lớp ngoài cùng: H, Li, Cr, Cu → **4** nguyên tử (H cũng có 1 e lớp ngoài cùng nhưng là phi kim).

> [!meo]
> Chu kì 4 có đúng **3** nguyên tố mà nguyên tử có 1 electron lớp ngoài cùng (4s^1^): **K, Cr, Cu**. Câu này rất hay gặp.

### Dạng 3. Đúng/Sai về tinh thể và liên kết kim loại

**Nhận biết:** 4 ý về cấu tạo nguyên tử kim loại, tinh thể kim loại, liên kết kim loại, có thể kèm số liệu kiểu mạng.

**Phương pháp:** soát kĩ các từ khoá: **"tất cả"** hay **"hầu hết"** (1–3 e lớp ngoài cùng); **ion dương** hay nguyên tử ở nút mạng; **electron tự do** hay ion âm; **thuỷ ngân** là ngoại lệ thể lỏng; **cùng chu kì** thì kim loại có bán kính lớn hơn, độ âm điện nhỏ hơn.

> [!vi-du] Ví dụ 6 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Trong cùng một chu kì, nguyên tử kim loại có bán kính lớn hơn nguyên tử phi kim.
>
> b) Nguyên tử của tất cả các kim loại đều có từ 1 đến 3 electron ở lớp ngoài cùng.
>
> c) Trong tinh thể kim loại, các nguyên tử trung hoà nằm ở nút mạng, các ion âm chuyển động tự do.
>
> d) Liên kết kim loại và liên kết ion giống nhau ở chỗ đều hình thành do lực hút tĩnh điện.

> [!goi-y] Gợi ý 1
> Với ý b, hãy nhớ lại các kim loại ở nhóm IVA, VA như Sn, Pb, Bi.

> [!goi-y] Gợi ý 2
> Ở nút mạng là hạt mang điện gì? Hạt chuyển động tự do là gì?

> [!loi-giai] Lời giải
> a) **Đúng**: cùng số lớp electron, kim loại có điện tích hạt nhân nhỏ hơn nên hút electron yếu hơn, bán kính lớn hơn.
>
> b) **Sai**: chỉ **hầu hết** kim loại có 1–3 electron lớp ngoài cùng. Sn, Pb có 4, Bi có 5.
>
> c) **Sai**: nút mạng là **ion dương**, hạt chuyển động tự do là **electron hoá trị**.
>
> d) **Đúng**: cả hai đều là lực hút tĩnh điện giữa phần tử mang điện trái dấu.

## Tóm tắt

| Nội dung | Ý chính |
|---|---|
| Vị trí | Khối s (trừ H, He), khối d, khối f và một phần khối p (Al, Sn, Pb, Bi…) |
| Cấu hình | Hầu hết có 1–3 e lớp ngoài cùng; khối d: lớp ngoài cùng ns^1^ hoặc ns^2^ |
| So với phi kim cùng chu kì | Điện tích hạt nhân nhỏ hơn, bán kính lớn hơn, dễ nhường electron, độ âm điện nhỏ hơn |
| Trạng thái | Rắn, có cấu tạo tinh thể (trừ Hg lỏng) |
| Tinh thể kim loại | Ion dương ở nút mạng; electron hoá trị chuyển động tự do |
| Kiểu mạng | Lập phương tâm khối (68%, phối trí 8); lập phương tâm mặt và lục phương chặt khít (74%, phối trí 12) |
| Liên kết kim loại | Lực hút tĩnh điện giữa electron hoá trị tự do và ion dương ở nút mạng |

**Cần thuộc:**

- Cấu hình: Cr [Ar]3d^5^4s^1^; Cu [Ar]3d^10^4s^1^; Fe [Ar]3d^6^4s^2^; Fe^2+^ [Ar]3d^6^; Fe^3+^ [Ar]3d^5^.
