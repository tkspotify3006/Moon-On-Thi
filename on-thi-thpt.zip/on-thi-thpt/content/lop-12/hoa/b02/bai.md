---
title: Xà phòng và chất giặt rửa
thoi-gian: 40 phút
muc-tieu:
  - Nêu được khái niệm xà phòng, chất giặt rửa tổng hợp, chất giặt rửa tự nhiên; chỉ ra được đầu ưa nước và đuôi kị nước trong công thức của chúng.
  - Giải thích được vì sao xà phòng và chất giặt rửa làm sạch được vết dầu mỡ (cơ chế tạo micelle).
  - Trình bày được phương pháp sản xuất xà phòng (xà phòng hoá chất béo, từ dầu mỏ) và phương pháp chủ yếu sản xuất chất giặt rửa tổng hợp (từ dầu mỏ).
  - Mô tả và giải thích được thí nghiệm xà phòng hoá chất béo.
  - So sánh được ưu, nhược điểm của xà phòng và chất giặt rửa tổng hợp (nước cứng, môi trường acid, phân huỷ sinh học); biết sử dụng hợp lí, an toàn.
  - Giải được bài toán tính khối lượng xà phòng từ chất béo (có hiệu suất, có tỉ lệ % muối trong xà phòng, bảo toàn khối lượng).
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Xà phòng** = hỗn hợp **muối sodium (hoặc potassium) của acid béo** + chất phụ gia. Ví dụ: C~17~H~35~COONa, C~15~H~31~COONa.
> 2. **Chất giặt rửa tổng hợp** giặt rửa như xà phòng nhưng **không** phải muối của acid béo. Thường gặp: **sodium alkylsulfate** (R–OSO~3~Na) và **sodium alkylbenzene sulfonate** (R–C~6~H~4~–SO~3~Na). Bồ kết, bồ hòn là **chất giặt rửa tự nhiên**.
> 3. Mỗi phân tử có **đầu ưa nước** (–COO^−^, –SO~3~^−^, –OSO~3~^−^) và **đuôi kị nước** (gốc hydrocarbon dài). Đuôi cắm vào dầu mỡ, đầu quay ra nước, vết bẩn bị chia nhỏ thành các **micelle** và bị nước cuốn đi.
> 4. Sản xuất xà phòng: **chất béo + NaOH/KOH đặc, đun nóng → muối của acid béo + glycerol** (phản ứng xà phòng hoá), hoặc từ alkane của dầu mỏ. Chất giặt rửa tổng hợp: **từ dầu mỏ**.
> 5. Xà phòng **kém tác dụng trong nước cứng và môi trường acid**; chất giặt rửa tổng hợp thì vẫn dùng tốt, nhưng **một số khó phân huỷ sinh học**. Tính toán: n(NaOH) = 3n(chất béo) = 3n(glycerol); bảo toàn khối lượng.

## 1. Khái niệm và đặc điểm cấu tạo

Em hãy thử rửa một cái bát dính mỡ chỉ bằng nước lạnh: nước chảy qua, mỡ vẫn bám nguyên. Nhỏ thêm một giọt nước rửa chén là mỡ trôi đi ngay. Bí mật nằm ở **cấu tạo đặc biệt** của phân tử chất giặt rửa: một đầu "thích" nước, một đầu "thích" dầu mỡ. Trước hết, ta làm quen với từng loại.

> [!nen-tang] Chất béo và acid béo (xem Bài 1)
> - **Acid béo**: carboxylic acid đơn chức, mạch carbon dài, không phân nhánh, thường có số C chẵn (12–24 C). Hay gặp: palmitic acid C~15~H~31~COOH, stearic acid C~17~H~35~COOH, oleic acid C~17~H~33~COOH.
> - **Chất béo** (triglyceride): triester của glycerol C~3~H~5~(OH)~3~ với acid béo, viết gọn (RCOO)~3~C~3~H~5~.
> - "Giống nhau hoà tan giống nhau": chất **phân cực** (hoặc ion) tan tốt trong nước; chất **không phân cực** (như gốc hydrocarbon, dầu mỡ) không tan trong nước nhưng tan trong nhau.

### 1.1. Xà phòng

**Xà phòng** là hỗn hợp gồm **muối sodium hoặc muối potassium của các acid béo** và các **chất phụ gia** (chất tạo hương, chất diệt khuẩn, chất tạo màu…).

Thành phần chính của xà phòng thông thường là **sodium palmitate** C~15~H~31~COONa và **sodium stearate** C~17~H~35~COONa.

Để nhận ra "muối của acid béo", em kiểm tra hai điều: (1) có nhóm **–COONa** (hoặc –COOK); (2) gốc R gắn với nhóm đó là **mạch carbon dài** (khoảng 11–17 C trở lên). Ví dụ CH~3~COONa cũng là muối carboxylate, nhưng gốc CH~3~ quá ngắn, không có "đuôi" bám dầu, nên **không phải xà phòng**.

### 1.2. Chất giặt rửa tổng hợp

**Chất giặt rửa tổng hợp** là những chất được **tổng hợp hoá học**, có khả năng giặt rửa giống xà phòng, nhưng **không phải là muối sodium hay potassium của acid béo**. Hai loại thường gặp:

- **Sodium alkylsulfate** R–OSO~3~Na. Ví dụ: sodium dodecyl sulfate CH~3~[CH~2~]~11~–OSO~3~Na (có trong dầu gội, kem đánh răng).
- **Sodium alkylbenzene sulfonate** R–C~6~H~4~–SO~3~Na. Ví dụ: sodium dodecylbenzenesulfonate CH~3~[CH~2~]~11~–C~6~H~4~–SO~3~Na (thành phần chính của nhiều loại bột giặt).

Bột giặt, nước giặt, nước rửa chén, nước lau sàn ngày nay chủ yếu dùng chất giặt rửa tổng hợp.

### 1.3. Chất giặt rửa tự nhiên

Một số sản phẩm có sẵn trong tự nhiên cũng có tác dụng giặt rửa, gọi là **chất giặt rửa tự nhiên**, ví dụ **nước quả bồ kết**, **quả bồ hòn**. Ông bà ta dùng nước bồ kết để gội đầu, dùng bồ hòn để giặt đồ.

> [!em-co-biet] Vì sao bồ kết tạo bọt?
> Quả bồ kết và bồ hòn chứa nhiều **saponin**. Phân tử saponin cũng có một phần ưa nước (các gốc đường) và một phần kị nước, nên nó tạo bọt và kéo được chất bẩn giống như xà phòng.

### 1.4. Cấu tạo: đầu ưa nước – đuôi kị nước

Phân tử xà phòng và chất giặt rửa phổ biến đều gồm **hai phần** có tính chất trái ngược nhau:

| Phần | Là gì | Tính chất |
|---|---|---|
| **Đầu ưa nước** (phần phân cực) | Nhóm carboxylate –COO^−^ (xà phòng); nhóm sulfonate –SO~3~^−^ hoặc sulfate –OSO~3~^−^ (chất giặt rửa tổng hợp) | Mang điện tích, **tan được trong nước** |
| **Đuôi kị nước** (phần không phân cực) | Gốc hydrocarbon **mạch dài** R | **Không tan trong nước**, nhưng tan tốt trong dầu mỡ |

![Hình 1. Cấu tạo của một phân tử xà phòng (a) và hai chất giặt rửa tổng hợp (b, c). Phần nền cam là đuôi kị nước, phần nền xanh là đầu ưa nước. Trong các hình sau, mỗi phân tử được kí hiệu bằng một "que" (đuôi) gắn với một "hạt tròn" (đầu)](cau-tao.svg)

**So sánh cấu tạo xà phòng và chất giặt rửa tổng hợp** (SGK tr. 15, câu hỏi 1):

- **Giống nhau**: đều có đầu ưa nước và đuôi kị nước là gốc hydrocarbon mạch dài; đều thường ở dạng muối sodium.
- **Khác nhau**: ở **đầu ưa nước**. Xà phòng có nhóm **–COO^−^** (muối của carboxylic acid). Chất giặt rửa tổng hợp có nhóm **–SO~3~^−^** hoặc **–OSO~3~^−^** (muối của sulfonic acid hoặc của hydrogen sulfate).

> [!bay]
> - Muối potassium của acid béo (như C~17~H~35~COOK) **vẫn là xà phòng**. Đừng nghĩ chỉ muối sodium mới là xà phòng.
> - Chất có nhóm –SO~3~Na hay –OSO~3~Na **không phải xà phòng** dù vẫn giặt rửa được: đó là chất giặt rửa **tổng hợp**.
> - Muối carboxylate mạch ngắn (HCOONa, CH~3~COONa) **không** có tác dụng giặt rửa vì thiếu đuôi kị nước dài.

> [!vi-du] Ví dụ 1
> Cho các chất: (1) C~17~H~33~COOK; (2) CH~3~[CH~2~]~11~–C~6~H~4~–SO~3~Na; (3) CH~3~COONa; (4) CH~3~[CH~2~]~13~–OSO~3~Na; (5) C~15~H~31~COOH.
>
> a) Chất nào là xà phòng, chất nào là chất giặt rửa tổng hợp?
>
> b) Chỉ ra đầu ưa nước và đuôi kị nước của chất (2).

> [!goi-y] Gợi ý 1
> Xà phòng là **muối** (Na hoặc K) của **acid béo**: phải có –COONa/–COOK và gốc R dài. Acid béo tự do (–COOH) có phải muối không?

> [!goi-y] Gợi ý 2
> Chất giặt rửa tổng hợp thường có nhóm –SO~3~Na hoặc –OSO~3~Na gắn với gốc hydrocarbon dài.

> [!loi-giai] Lời giải
> a) **Xà phòng**: (1), là potassium oleate, muối potassium của oleic acid.
>
> **Chất giặt rửa tổng hợp**: (2) (alkylbenzene sulfonate) và (4) (alkylsulfate).
>
> (3) là muối của acetic acid, gốc CH~3~ quá ngắn nên không phải xà phòng. (5) là palmitic acid, một acid béo tự do, chưa phải muối nên cũng không phải xà phòng.
>
> b) Chất (2): đầu ưa nước là nhóm **–SO~3~^−^Na^+^**; đuôi kị nước là phần **CH~3~[CH~2~]~11~–C~6~H~4~–** (gốc dodecyl cùng vòng benzene, đều không phân cực).

## 2. Tính chất giặt rửa

### 2.1. Vì sao nước thường không rửa được dầu mỡ?

Dầu mỡ là chất **không phân cực**, còn nước là dung môi **phân cực**. Hai chất này không trộn vào nhau. Hơn nữa nước có **sức căng bề mặt lớn**: các phân tử nước hút nhau mạnh, làm giọt nước co tròn lại và khó thấm vào các khe sợi vải dính dầu.

### 2.2. Xà phòng làm sạch như thế nào?

Quá trình làm sạch gồm các bước sau (theo dõi Hình 2):

1. **Làm giảm sức căng bề mặt.** Khi tan vào nước, xà phòng tạo dung dịch có sức căng bề mặt nhỏ, nên nước **dễ thấm ướt** vật cần giặt và len vào giữa vết bẩn với bề mặt vải.
2. **Đuôi kị nước "cắm" vào vết bẩn.** Đuôi hydrocarbon tan được trong dầu mỡ nên chui vào vết bẩn. Đầu ưa nước thì ở lại ngoài, hướng ra nước.
3. **Chia nhỏ vết bẩn.** Rất nhiều phân tử bám quanh, cùng với tác dụng cơ học (vò, khuấy), kéo vết dầu ra khỏi bề mặt và chia thành những hạt rất nhỏ.
4. **Phân tán và rửa trôi.** Mỗi hạt dầu được bao kín bởi các phân tử xà phòng, đầu ưa nước quay ra ngoài. Hạt như thế gọi là **micelle**. Bề ngoài micelle "giống nước" nên phân tán đều trong nước và bị dòng nước cuốn đi.

![Hình 2. Cơ chế làm sạch vết dầu mỡ: ① xà phòng tan vào nước; ② đuôi kị nước cắm vào vết dầu; ③ vết dầu bị kéo lên, tách khỏi vải; ④ dầu nằm trong lõi micelle, đầu ưa nước quay ra ngoài, micelle phân tán và bị nước cuốn đi](co-che.svg)

**Vì sao các micelle không dính lại với nhau?** Bề mặt micelle chứa các đầu mang **cùng loại điện tích âm** (–COO^−^ hoặc –SO~3~^−^). Hai micelle đến gần sẽ **đẩy nhau**, nên dầu không kết lại thành vết lớn và không bám trở lại vải.

> [!bay]
> - Xà phòng làm sạch dầu mỡ chủ yếu nhờ **tác dụng vật lí** (thấm ướt, nhũ hoá, tạo micelle). Đây **không phải** phản ứng hoá học giữa xà phòng và dầu mỡ.
> - Phần cắm vào dầu là **đuôi kị nước**. Phần quay ra nước là **đầu ưa nước**. Đề hay đảo hai phần này để bẫy.
> - Xà phòng làm **giảm** (không phải tăng) sức căng bề mặt của nước.

> [!vi-du] Ví dụ 2
> Bạn An rửa tay dính dầu nhớt xe máy. Rửa bằng nước không sạch, nhưng xoa xà phòng, chà kĩ rồi xả nước thì sạch. Hãy giải thích bằng cấu tạo phân tử xà phòng. Vì sao phải chà xát chứ không chỉ nhúng tay vào nước xà phòng?

> [!goi-y] Gợi ý 1
> Dầu nhớt là hydrocarbon, không phân cực. Phần nào của phân tử xà phòng "hợp" với dầu nhớt? Phần nào "hợp" với nước?

> [!goi-y] Gợi ý 2
> Micelle được tạo khi vết dầu bị chia nhỏ. Chà xát giúp gì cho việc chia nhỏ?

> [!loi-giai] Lời giải
> Dầu nhớt không tan trong nước nên nước trôi qua mà không kéo được dầu đi.
>
> Khi có xà phòng, **đuôi kị nước** (gốc hydrocarbon dài) tan vào lớp dầu nhớt, còn **đầu ưa nước** (–COO^−^) quay ra phía nước. Rất nhiều phân tử xà phòng bao quanh dầu, chia dầu thành các hạt **micelle** nhỏ có vỏ ngoài ưa nước. Các micelle phân tán vào nước và bị xả trôi.
>
> **Chà xát** là tác dụng cơ học: nó xé vết dầu thành giọt nhỏ, tăng diện tích tiếp xúc để xà phòng bao kín nhanh hơn. Vì vậy giặt bằng tay phải vò, giặt bằng máy phải quay.

## 3. Phương pháp sản xuất xà phòng và chất giặt rửa

![Hình 3. Sơ đồ sản xuất: (a) xà phòng từ chất béo; (b) xà phòng từ dầu mỏ; (c) chất giặt rửa tổng hợp từ dầu mỏ](san-xuat.svg)

### 3.1. Sản xuất xà phòng

**a) Xà phòng hoá chất béo (phương pháp chính)**

Đun nóng chất béo với dung dịch **NaOH đặc** (hoặc **KOH đặc**). Liên kết ester trong chất béo bị cắt, tạo ra **glycerol** và **muối của acid béo**. Phản ứng thuỷ phân ester trong môi trường kiềm như vậy gọi là **phản ứng xà phòng hoá** (đã gặp ở Bài 1). Dạng tổng quát:

=> (RCOO)~3~C~3~H~5~ + 3NaOH → C~3~H~5~(OH)~3~ + 3RCOONa    (t°)

Ví dụ với tristearin:

=> (C~17~H~35~COO)~3~C~3~H~5~ + 3NaOH → C~3~H~5~(OH)~3~ + 3C~17~H~35~COONa    (t°)

Sản phẩm C~17~H~35~COONa (sodium stearate) là thành phần chính của xà phòng. Muối acid béo tách ra được trộn thêm chất diệt khuẩn, chất tạo hương, chất tạo màu… rồi ép khuôn thành bánh.

**Vì sao gọi là "xà phòng hoá"?** Vì phản ứng này chính là cách người ta làm ra xà phòng từ mỡ động vật và dầu thực vật hàng nghìn năm nay. Về sau tên gọi này dùng cho mọi phản ứng thuỷ phân ester trong môi trường kiềm.

> [!meo] Ba tỉ lệ "vàng" của phản ứng xà phòng hoá chất béo
> - n(NaOH) = 3·n(chất béo) = 3·n(glycerol); n(muối) = n(NaOH).
> - **Bảo toàn khối lượng**: m(chất béo) + m(NaOH) = m(muối) + m(glycerol).
> - Các khối lượng mol hay dùng: tristearin 890, tripalmitin 806, triolein 884; C~17~H~35~COONa 306, C~15~H~31~COONa 278, C~17~H~33~COONa 304; glycerol 92.

> [!vi-du] Ví dụ 3
> Xà phòng hoá hoàn toàn 17,8 g tristearin bằng dung dịch NaOH vừa đủ.
>
> a) Tính khối lượng NaOH đã phản ứng và khối lượng glycerol thu được.
>
> b) Tính khối lượng sodium stearate thu được bằng hai cách.

> [!goi-y] Gợi ý 1
> M(tristearin) = 890. Một phân tử chất béo cần 3 NaOH, cho 1 glycerol và 3 muối.

> [!goi-y] Gợi ý 2
> Cách 2 cho câu b: bảo toàn khối lượng, không cần biết M của muối.

> [!loi-giai] Lời giải
> a) n(tristearin) = 17,8 : 890 = 0,02 mol.
>
> n(NaOH) = 3 · 0,02 = 0,06 mol → m(NaOH) = 0,06 · 40 = **2,4 g**.
>
> n(glycerol) = 0,02 mol → m(glycerol) = 0,02 · 92 = **1,84 g**.
>
> b) Cách 1: n(C~17~H~35~COONa) = 0,06 mol → m = 0,06 · 306 = **18,36 g**.
>
> Cách 2: m(muối) = 17,8 + 2,4 − 1,84 = **18,36 g**. Hai cách cho cùng kết quả.

**b) Thí nghiệm xà phòng hoá chất béo** (SGK tr. 16)

*Tóm tắt cách làm:* cho một ít chất béo (dầu ăn hoặc mỡ) và dung dịch NaOH khoảng 40% vào bát sứ. Đun nhẹ khoảng 10 phút, **khuấy liên tục** bằng đũa thuỷ tinh, thỉnh thoảng **thêm nước** để bù phần bay hơi. Sau đó đổ hỗn hợp vào cốc chứa **dung dịch NaCl bão hoà**, khuấy nhẹ rồi để nguội.

*Hiện tượng:* lúc đầu hỗn hợp tách lớp (chất béo nổi trên). Sau khi đun, hỗn hợp trở nên đồng nhất. Khi đổ vào NaCl bão hoà, một **lớp chất rắn màu trắng ngà nổi lên** trên mặt. Đó là xà phòng.

*Giải thích từng thao tác:*

| Thao tác | Vì sao? |
|---|---|
| Khuấy liên tục | Chất béo không tan trong nước, nhẹ hơn nên nổi lên. Khuấy giúp chất béo **tiếp xúc** nhiều với NaOH, phản ứng nhanh và đều; đồng thời tránh hỗn hợp **sôi trào, bắn** và chất béo bị cháy khét ở đáy bát. |
| Thêm nước khi bị cạn | Phản ứng là **thuỷ phân**, cần có nước. Nếu cạn, NaOH đặc dễ làm chất béo bị **cháy, phân huỷ**, và hỗn hợp bắn ra ngoài. |
| Hỗn hợp trở nên đồng nhất | Chất béo đã chuyển thành muối và glycerol, **đều tan** trong nước. Đây là dấu hiệu phản ứng đã gần hoàn toàn. |
| Đổ vào NaCl bão hoà | Muối của acid béo **ít tan trong dung dịch NaCl đặc**, và dung dịch NaCl bão hoà nặng hơn, nên xà phòng **tách ra và nổi lên**. Glycerol tan tốt, ở lại trong dung dịch bên dưới. |

> [!em-co-biet] Xà phòng cứng, xà phòng mềm
> Muối **sodium** của acid béo cho xà phòng **cứng**, dùng làm xà phòng bánh. Muối **potassium** cho xà phòng **mềm** hoặc dạng lỏng, dễ tan hơn, hay dùng làm xà phòng nước, sữa tắm. Glycerol thu được trong sản xuất xà phòng là nguyên liệu quý cho mĩ phẩm (kem dưỡng ẩm), dược phẩm.

**c) Sản xuất xà phòng từ dầu mỏ**

Xà phòng còn được sản xuất từ dầu mỏ theo sơ đồ (Hình 3b):

=> Alkane mạch dài (từ dầu mỏ) → acid béo → muối sodium (potassium) của acid béo

Người ta **oxi hoá** alkane mạch dài (có xúc tác) để cắt mạch, thu được các acid béo. Sau đó trung hoà acid béo bằng NaOH: RCOOH + NaOH → RCOONa + H~2~O. Cách này giúp **tiết kiệm chất béo** dùng làm thực phẩm.

### 3.2. Sản xuất chất giặt rửa tổng hợp

Chất giặt rửa tổng hợp được sản xuất **từ dầu mỏ**. Từ các hydrocarbon trong dầu mỏ, qua **nhiều giai đoạn**, người ta tạo ra các acid R–SO~3~H (sulfonic acid) hoặc R–OSO~3~H (alkyl hydrogen sulfate). Sau đó trung hoà bằng NaOH:

=> R–SO~3~H + NaOH → R–SO~3~Na + H~2~O

=> R–OSO~3~H + NaOH → R–OSO~3~Na + H~2~O

Các muối sulfonate hoặc sulfate này được trộn với **phụ gia** để thành bột giặt, nước giặt, nước rửa chén…

> [!em-co-biet] Trong một gói bột giặt có gì?
> Ngoài chất giặt rửa tổng hợp (thành phần chính), bột giặt còn có: chất tẩy trắng, **enzyme** (phân giải vết bẩn protein như máu, sữa, mồ hôi), chất làm hạt bột, chất chống bám lại vết bẩn, chất điều chỉnh bọt, chất làm trắng quang học (huỳnh quang), hương liệu và chất độn. Vì có enzyme, bột giặt "sinh học" giặt tốt nhất ở nước ấm, không nên dùng nước quá nóng.

> [!bay]
> - Chất giặt rửa tổng hợp được sản xuất **từ dầu mỏ**, không phải từ chất béo.
> - Xà phòng **cũng** có thể sản xuất từ dầu mỏ (qua acid béo). Câu "xà phòng chỉ được sản xuất từ chất béo" là **sai**.
> - Thuỷ phân chất béo trong môi trường **acid** cho **acid béo** + glycerol, **không** cho xà phòng. Phải dùng **kiềm** (NaOH, KOH).

## 4. Ứng dụng, ưu nhược điểm và cách sử dụng an toàn

### 4.1. Ứng dụng

- **Xà phòng**: tắm, rửa tay, gội đầu, giặt đồ…
- **Chất giặt rửa tổng hợp**: giặt quần áo (bột giặt, nước giặt), rửa chén bát, rửa tay, lau sàn, lau kính, dầu gội, kem đánh răng…

### 4.2. Vì sao chất giặt rửa tổng hợp được dùng phổ biến hơn?

So với xà phòng, chất giặt rửa tổng hợp có các ưu điểm:

1. **Dễ hoà tan trong nước hơn** xà phòng.
2. **Dùng được trong nước cứng.** Xà phòng thì kém tác dụng.
3. **Dùng được trong môi trường acid.** Xà phòng thì kém tác dụng.

> [!nen-tang] Nước cứng là gì?
> Nước chứa nhiều ion **Ca^2+^** và **Mg^2+^** gọi là **nước cứng** (thường gặp ở nước giếng khoan, vùng núi đá vôi). Em sẽ học kĩ ở chương kim loại nhóm IIA. Ở đây chỉ cần nhớ: muối calcium, magnesium của **acid béo** **không tan** trong nước.

**Vì sao xà phòng kém tác dụng trong nước cứng?** Ion Ca^2+^, Mg^2+^ kết hợp với anion của acid béo tạo kết tủa:

=> 2C~17~H~35~COONa + Ca^2+^ → (C~17~H~35~COO)~2~Ca↓ + 2Na^+^

Xà phòng bị chuyển thành **cặn không tan**, nên mất tác dụng giặt rửa, **ít bọt**, tốn xà phòng. Cặn này còn bám vào vải làm vải cứng, xỉn màu, và bám thành vệt trên bồn tắm. Còn **muối calcium của các alkyl sulfate, alkylbenzene sulfonate tan được** trong nước, nên chất giặt rửa tổng hợp vẫn hoạt động bình thường (Hình 4).

![Hình 4. Trong nước cứng: xà phòng tạo cặn (RCOO)~2~Ca, còn chất giặt rửa tổng hợp không tạo kết tủa nên vẫn giặt tốt](nuoc-cung.svg)

**Vì sao xà phòng kém tác dụng trong môi trường acid?** Ion H^+^ chuyển muối của acid béo về **acid béo**, một chất không tan, không còn đầu ion ưa nước:

=> C~17~H~35~COONa + HCl → C~17~H~35~COOH↓ + NaCl

Trong khi đó sulfonic acid là acid mạnh, nên chất giặt rửa tổng hợp không bị "acid hoá" ngược lại như vậy.

> [!vi-du] Ví dụ 4
> Một gia đình dùng nước giếng có nồng độ ion Ca^2+^ là 0,002 mol/L (các ion khác không ảnh hưởng). Mỗi lần giặt dùng 10 L nước này với xà phòng sodium stearate. Tính khối lượng xà phòng tối đa bị mất tác dụng do tạo kết tủa với Ca^2+^ trong mỗi lần giặt.

> [!goi-y] Gợi ý 1
> Tính số mol Ca^2+^ trong 10 L nước.

> [!goi-y] Gợi ý 2
> Mỗi ion Ca^2+^ "giữ" **hai** anion stearate: tỉ lệ 1 : 2.

> [!loi-giai] Lời giải
> n(Ca^2+^) = 10 · 0,002 = 0,02 mol.
>
> Theo phương trình 2C~17~H~35~COONa + Ca^2+^ → (C~17~H~35~COO)~2~Ca↓ + 2Na^+^, ta có n(C~17~H~35~COONa) = 2 · 0,02 = 0,04 mol.
>
> m = 0,04 · 306 = **12,24 g**. Mỗi lần giặt mất khoảng 12 g xà phòng chỉ để "khử" ion Ca^2+^. Vì thế với nước cứng nên dùng bột giặt (chất giặt rửa tổng hợp).

### 4.3. Nhược điểm của chất giặt rửa tổng hợp: vấn đề môi trường

Xà phòng là muối của acid béo, một chất có nguồn gốc tự nhiên, nên **vi sinh vật phân huỷ được dễ dàng**. Ngược lại, **một số chất giặt rửa tổng hợp khó bị phân huỷ sinh học**. Chúng tồn tại lâu trong nước thải, tạo bọt trên sông hồ, gây hại cho cá và sinh vật thuỷ sinh. Vì vậy chất giặt rửa tổng hợp kém thân thiện với môi trường hơn xà phòng.

> [!em-co-biet] Mạch nhánh và mạch thẳng
> Các loại alkylbenzene sulfonate đời đầu có gốc R **phân nhánh** nhiều. Vi khuẩn rất khó "cắt" loại mạch này, nên từng có những dòng sông phủ đầy bọt trắng. Ngày nay người ta chuyển sang loại gốc R **mạch thẳng**, phân huỷ sinh học nhanh hơn nhiều. Một số bột giặt cũ còn chứa nhiều **phosphate**. Phosphate là chất dinh dưỡng cho tảo, làm tảo phát triển quá mức (hiện tượng phú dưỡng), gây thiếu oxygen cho cá.

**So sánh nhanh:**

| | Xà phòng | Chất giặt rửa tổng hợp |
|---|---|---|
| Bản chất | Muối Na/K của acid béo | Muối sulfonate, sulfate (không phải muối acid béo) |
| Đầu ưa nước | –COO^−^ | –SO~3~^−^, –OSO~3~^−^ |
| Nguyên liệu | Chất béo (chủ yếu), alkane từ dầu mỏ | Dầu mỏ |
| Độ tan trong nước | Kém hơn | Dễ tan hơn |
| Nước cứng | **Kém** (tạo kết tủa với Ca^2+^, Mg^2+^) | **Tốt** |
| Môi trường acid | **Kém** (tạo acid béo không tan) | **Tốt** |
| Phân huỷ sinh học | **Dễ**, thân thiện môi trường | Một số loại **khó**, kém thân thiện |

### 4.4. Sử dụng hợp lí, an toàn

> [!ung-dung] Dùng xà phòng và chất giặt rửa đúng cách
> - **Đúng liều lượng** ghi trên bao bì. Dùng nhiều hơn không sạch hơn, chỉ tốn tiền, khó xả sạch và tăng ô nhiễm nước thải.
> - **Chọn đúng loại**: nước cứng thì dùng bột giặt/nước giặt; da nhạy cảm thì chọn xà phòng dịu nhẹ. Dung dịch xà phòng có tính **kiềm nhẹ**, dùng nhiều có thể làm khô da.
> - **Đeo găng tay** khi tiếp xúc lâu với bột giặt, nước tẩy rửa; **xả thật sạch** bát đĩa, quần áo (đặc biệt là đồ trẻ em).
> - **Không tự ý trộn** các loại chất tẩy rửa với nhau. Ví dụ, trộn nước tẩy chứa NaClO (nước Javel) với chất tẩy có acid sẽ sinh khí chlorine độc.
> - Cất xa tầm tay trẻ em; không đựng chất tẩy rửa trong chai nước uống.
> - Ưu tiên sản phẩm **dễ phân huỷ sinh học**, ít phosphate; không xả nước giặt đậm đặc trực tiếp ra ao hồ.

## Dạng bài thi hay gặp

### Dạng 1. Câu lí thuyết, Đúng/Sai về khái niệm – cấu tạo – cơ chế – ưu nhược điểm

**Nhận biết:** đề cho dãy chất hỏi chất nào là xà phòng/chất giặt rửa; hoặc cho 4 ý Đúng/Sai về cấu tạo, cơ chế giặt rửa, thí nghiệm xà phòng hoá, nước cứng, môi trường.

**Phương pháp:**

1. Xác định loại chất: **–COONa/–COOK + gốc dài** là xà phòng; **–SO~3~Na, –OSO~3~Na + gốc dài** là chất giặt rửa tổng hợp; gốc ngắn hoặc dạng acid tự do thì không phải.
2. Soát từ khoá cơ chế: **đuôi kị nước** → vào dầu; **đầu ưa nước** → ra nước; sức căng bề mặt **giảm**; tạo **micelle**; là quá trình **vật lí**.
3. Soát từ khoá ưu nhược điểm: xà phòng **kém** trong **nước cứng** và **acid**, nhưng **dễ phân huỷ sinh học**.

> [!vi-du] Ví dụ 5 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Thành phần chính của xà phòng là muối sodium hoặc potassium của acid béo.
>
> b) Trong micelle, đầu ưa nước của các phân tử xà phòng hướng vào trong, bao lấy hạt dầu.
>
> c) Xà phòng giặt rửa tốt trong nước có nhiều ion Ca^2+^, Mg^2+^.
>
> d) Sodium dodecyl sulfate có đuôi kị nước là gốc C~12~H~25~–.

> [!goi-y] Gợi ý 1
> Hạt dầu không phân cực "hợp" với phần nào của phân tử xà phòng?

> [!goi-y] Gợi ý 2
> Muối calcium của acid béo có tan không?

> [!loi-giai] Lời giải
> a) **Đúng**: đúng khái niệm xà phòng.
>
> b) **Sai**: **đuôi kị nước** hướng vào trong (vào hạt dầu), **đầu ưa nước** quay ra ngoài, tiếp xúc với nước.
>
> c) **Sai**: Ca^2+^, Mg^2+^ tạo kết tủa (RCOO)~2~Ca, (RCOO)~2~Mg với xà phòng, làm xà phòng mất tác dụng.
>
> d) **Đúng**: CH~3~[CH~2~]~11~–OSO~3~Na có gốc dodecyl C~12~H~25~– là phần không phân cực.

### Dạng 2. Tính khối lượng xà phòng từ chất béo (hiệu suất, % muối trong xà phòng)

**Nhận biết:** đề cho khối lượng chất béo (hoặc mỡ, dầu chứa x% chất béo), hiệu suất H, và xà phòng chứa a% muối của acid béo. Đề hỏi khối lượng xà phòng, hoặc hỏi ngược khối lượng chất béo cần dùng.

**Phương pháp:**

1. m(chất béo thật) = m(nguyên liệu) · x%. Tính n(chất béo).
2. n(muối) lí thuyết = 3·n(chất béo).
3. **Đi xuôi** (chất béo → xà phòng): **nhân** H. **Đi ngược** (xà phòng → chất béo): **chia** H.
4. Muối chỉ chiếm a% xà phòng: m(xà phòng) = m(muối) : a%. Ngược lại m(muối) = m(xà phòng) · a%.

> [!vi-du] Ví dụ 6
> Một cơ sở nấu xà phòng từ 1 tấn mỡ động vật chứa 89% tristearin (phần còn lại là tạp chất không tham gia phản ứng). Hiệu suất phản ứng xà phòng hoá là 90%. Biết sodium stearate chiếm 72% khối lượng xà phòng thành phẩm. Tính khối lượng xà phòng thu được.

> [!goi-y] Gợi ý 1
> m(tristearin) = 890 kg, vậy n = 1 kmol. Mỗi kmol chất béo cho bao nhiêu kmol muối?

> [!goi-y] Gợi ý 2
> Tính muối thực tế (nhân H), rồi chia cho 72% để ra khối lượng xà phòng. Xà phòng phải **nặng hơn** muối vì còn chứa phụ gia.

> [!loi-giai] Lời giải
> m(tristearin) = 1 000 · 0,89 = 890 kg → n = 890 : 890 = 1 kmol.
>
> n(C~17~H~35~COONa) lí thuyết = 3 kmol → m(muối) thực tế = 3 · 306 · 0,9 = 826,2 kg.
>
> m(xà phòng) = 826,2 : 0,72 = **1 147,5 kg**.

> [!vi-du] Ví dụ 7
> Cần bao nhiêu kg tripalmitin để sản xuất được 1 tấn xà phòng chứa 83,4% sodium palmitate về khối lượng? Biết hiệu suất phản ứng là 80%.

> [!goi-y] Gợi ý 1
> m(C~15~H~31~COONa) = 1 000 · 0,834 = 834 kg; M = 278.

> [!goi-y] Gợi ý 2
> Đây là bài **đi ngược** (biết sản phẩm, tìm nguyên liệu): chia cho H.

> [!loi-giai] Lời giải
> n(C~15~H~31~COONa) = 834 : 278 = 3 kmol → n(tripalmitin) lí thuyết = 3 : 3 = 1 kmol.
>
> m(tripalmitin) cần dùng = 1 · 806 : 0,8 = **1 007,5 kg**.

> [!bay]
> - Quên hệ số **3**: 1 chất béo cho **3** muối.
> - Quên chia cho a%: khối lượng **xà phòng** lớn hơn khối lượng **muối** (vì còn phụ gia).
> - Đi ngược mà lại nhân H: kết quả nhỏ hơn đáp án đúng. Hãy tự hỏi: "có hao hụt thì cần nhiều hay ít nguyên liệu hơn?"
> - Đề cho "mỡ chứa x% chất béo" thì phải nhân x% trước.

### Dạng 3. Bảo toàn khối lượng; chất béo có lẫn acid béo tự do

**Nhận biết:** đề cho vài trong bốn đại lượng m(chất béo), m(NaOH), m(muối), m(glycerol) và hỏi đại lượng còn lại; hoặc chất béo **có lẫn acid béo tự do**.

**Phương pháp:**

1. Chất béo tinh khiết: n(NaOH) = 3n(glycerol); m(chất béo) + m(NaOH) = m(muối) + m(glycerol).
2. Có acid béo tự do: acid béo phản ứng RCOOH + NaOH → RCOONa + H~2~O. Khi đó:
   - n(NaOH) = 3n(chất béo) + n(acid béo); n(glycerol) = n(chất béo); n(H~2~O) = n(acid béo).
   - m(chất béo) + m(NaOH) = m(muối) + m(glycerol) + m(H~2~O).
3. Có thể tìm M của chất béo: M = m(chất béo) : n(glycerol), rồi đối chiếu 806 / 884 / 890…

> [!vi-du] Ví dụ 8
> Xà phòng hoá hoàn toàn m gam một chất béo X cần vừa đủ 0,3 mol NaOH, thu được 9,2 g glycerol và 91,8 g muối của một acid béo duy nhất. Tính m và gọi tên X.

> [!goi-y] Gợi ý 1
> Bảo toàn khối lượng: m + m(NaOH) = m(muối) + m(glycerol).

> [!goi-y] Gợi ý 2
> M(X) = m : n(glycerol). Hoặc tính M(muối) = 91,8 : 0,3 rồi suy ra gốc R.

> [!loi-giai] Lời giải
> m = 91,8 + 9,2 − 0,3 · 40 = **89 g**.
>
> n(X) = n(glycerol) = 9,2 : 92 = 0,1 mol → M(X) = 89 : 0,1 = 890.
>
> Kiểm tra: M(muối) = 91,8 : 0,3 = 306, chính là C~17~H~35~COONa. Vậy X là **tristearin** (C~17~H~35~COO)~3~C~3~H~5~.

> [!vi-du] Ví dụ 9 (vận dụng cao)
> Một mẫu mỡ để lâu gồm tristearin và stearic acid tự do. Cho 91,84 g mẫu mỡ tác dụng vừa đủ với dung dịch chứa 12,4 g NaOH, đun nóng. Tính khối lượng glycerol và khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> Đặt x = n(tristearin), y = n(stearic acid). Lập hai phương trình: theo khối lượng mẫu mỡ và theo số mol NaOH.

> [!goi-y] Gợi ý 2
> Cả hai chất đều cho cùng một muối C~17~H~35~COONa, nên n(muối) = n(NaOH). Acid béo tạo H~2~O, không tạo glycerol.

> [!loi-giai] Lời giải
> n(NaOH) = 12,4 : 40 = 0,31 mol.
>
> Hệ: 890x + 284y = 91,84 và 3x + y = 0,31. Giải ra x = 0,1; y = 0,01.
>
> m(glycerol) = 0,1 · 92 = **9,2 g**.
>
> m(muối) = n(NaOH) · 306 = 0,31 · 306 = **94,86 g**.
>
> Kiểm tra bằng bảo toàn khối lượng: 91,84 + 12,4 − 9,2 − 0,01 · 18 = 94,86 g. ✓

> [!bay]
> - Có acid béo tự do thì **đừng quên nước** sinh ra trong bảo toàn khối lượng, và n(glycerol) **không** bằng n(NaOH) : 3 nữa.
> - Bảo toàn khối lượng: NaOH ở **vế trái**, glycerol ở **vế phải**. Đừng cộng nhầm glycerol vào chất béo.

## Tóm tắt

| | Xà phòng | Chất giặt rửa tổng hợp | Chất giặt rửa tự nhiên |
|---|---|---|---|
| Ví dụ | C~17~H~35~COONa, C~15~H~31~COONa, C~17~H~35~COOK | R–OSO~3~Na, R–C~6~H~4~–SO~3~Na | Bồ kết, bồ hòn |
| Đầu ưa nước | –COO^−^ | –SO~3~^−^, –OSO~3~^−^ | (saponin) |
| Sản xuất | Xà phòng hoá chất béo; alkane → acid béo → muối | Dầu mỏ → R–SO~3~H, R–OSO~3~H → muối Na | Có sẵn |
| Nước cứng, acid | Kém | Tốt | — |
| Phân huỷ sinh học | Dễ | Một số loại khó | Dễ |

**Cơ chế giặt rửa:** giảm sức căng bề mặt → đuôi kị nước cắm vào vết dầu → chia nhỏ vết bẩn → **micelle** (đầu ưa nước quay ra) phân tán vào nước → bị rửa trôi.

**Công thức tính toán:**

- (RCOO)~3~C~3~H~5~ + 3NaOH → C~3~H~5~(OH)~3~ + 3RCOONa: n(NaOH) = n(muối) = 3n(chất béo) = 3n(glycerol).
- m(chất béo) + m(NaOH) = m(muối) + m(glycerol) [+ m(H~2~O) nếu có acid béo tự do].
- m(xà phòng) = m(muối) : a%. Đi xuôi nhân H, đi ngược chia H.
- Nước cứng: 2RCOO^−^ + Ca^2+^ → (RCOO)~2~Ca↓ (tỉ lệ 2 : 1).
- M: tristearin 890, tripalmitin 806, triolein 884; muối 306, 278, 304; glycerol 92.
