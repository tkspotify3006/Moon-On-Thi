---
title: Đại cương về polymer
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm polymer, monomer, mắt xích; tính được hệ số polymer hoá từ phân tử khối.
  - Viết được công thức cấu tạo và gọi được tên các polymer thường gặp: PE, PP, PS, PVC, polybuta-1,3-diene, polyisoprene, poly(methyl methacrylate), poly(phenol formaldehyde), capron, nylon-6,6.
  - Phân loại được polymer theo nguồn gốc, theo cách tổng hợp và theo cấu trúc mạch.
  - Nêu được đặc điểm tính chất vật lí (trạng thái, nhiệt độ nóng chảy, tính chất cơ học) và tính chất hoá học của polymer (cắt mạch, tăng mạch, giữ nguyên mạch).
  - Trình bày được phương pháp trùng hợp, trùng ngưng; nhận ra monomer nào tham gia được phản ứng nào.
  - Giải được bài toán hệ số polymer hoá, khối lượng polymer điều chế từ monomer có hiệu suất, bài toán lưu hoá cao su.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Polymer** = phân tử rất lớn gồm nhiều **mắt xích** nối với nhau; **monomer** = phân tử nhỏ ban đầu. Viết gọn (mắt xích)~n~, n là **hệ số polymer hoá**: n = M(polymer) : M(mắt xích).
> 2. Tên gọi: **poly + tên monomer** (tên monomer có từ hai cụm trở lên thì đặt trong ngoặc đơn): polyethylene, poly(vinyl chloride).
> 3. Polymer là chất rắn, không bay hơi, **không có nhiệt độ nóng chảy xác định**; đa số không tan trong nước. Có loại dẻo, loại đàn hồi, loại dai và kéo sợi được.
> 4. Ba kiểu phản ứng: **cắt mạch** (nhiệt phân PS, thuỷ phân polyamide, tinh bột, cellulose), **tăng mạch** (lưu hoá cao su), **giữ nguyên mạch** (phản ứng ở nhóm thế, ví dụ poly(vinyl acetate) + NaOH).
> 5. Điều chế: **trùng hợp** cần monomer có **liên kết đôi** hoặc **vòng kém bền**, không tách chất nhỏ; **trùng ngưng** cần monomer có **≥ 2 nhóm chức** phản ứng được, tách ra phân tử nhỏ (thường là H~2~O).

## 1. Khái niệm và danh pháp

Túi nilon, vỏ dây điện, chai nước, áo sợi tổng hợp, săm lốp xe… đều làm từ **polymer**. Cơm (tinh bột), sợi bông (cellulose), tơ tằm, lòng trắng trứng (protein) cũng là polymer. Ở chương 2 và 3 em đã gặp polymer thiên nhiên. Chương 4 sẽ học polymer một cách tổng quát.

### 1.1. Polymer, monomer, mắt xích

Hãy hình dung một **chuỗi hạt**: mỗi hạt là một đơn vị nhỏ giống nhau, xâu lại hàng nghìn hạt thành một chuỗi rất dài.

Khi đun ethylene ở áp suất cao, có xúc tác, các phân tử ethylene "mở" liên kết đôi rồi nối với nhau thành một mạch rất dài:

=> nCH~2~=CH~2~ → (–CH~2~–CH~2~–)~n~    (t°, p, xt)

![Hình 1. Từ monomer ethylene đến polymer polyethylene: phần lặp lại –CH~2~–CH~2~– là mắt xích, n là hệ số polymer hoá](polymer-monomer.svg)

- **Polymer** là hợp chất có phân tử khối **rất lớn**, do **nhiều đơn vị nhỏ** (gọi là **mắt xích**) liên kết với nhau tạo nên. Ở đây polymer là polyethylene.
- **Monomer** là những phân tử nhỏ, phản ứng với nhau để tạo nên polymer. Ở đây monomer là ethylene CH~2~=CH~2~.
- **Mắt xích** là phần cấu tạo lặp lại trong mạch, ở đây là –CH~2~–CH~2~–.
- Số mắt xích n gọi là **hệ số polymer hoá** (còn gọi là độ polymer hoá). SGK chỉ viết là n, nhưng đề thi hay dùng tên gọi này.

$$n=\frac{M_{\text{polymer}}}{M_{\text{mắt xích}}}$$

**So sánh ethylene và polyethylene.** Mắt xích –CH~2~–CH~2~– có cùng thành phần nguyên tố với ethylene (đều là C~2~H~4~, cùng %C = 24 : 28 ≈ 85,7%). Khác biệt nằm ở **kích thước**: ethylene có M = 28, còn một phân tử polyethylene có thể nặng hàng chục, hàng trăm nghìn.

**Vì sao chỉ nói "phân tử khối trung bình"?** Trong cùng một mẫu polymer, các mạch **dài ngắn khác nhau** (n không bằng nhau). Vì vậy polymer là **hỗn hợp** các phân tử có n khác nhau. Ta chỉ nói được phân tử khối trung bình và hệ số polymer hoá trung bình.

> [!vi-du] Ví dụ 1
> Một loại polyethylene có phân tử khối trung bình là 420 000.
>
> a) Tính hệ số polymer hoá trung bình.
>
> b) Polyethylene và ethylene có phải là đồng phân của nhau không? Vì sao?

> [!goi-y] Gợi ý 1
> Mắt xích của polyethylene là –CH~2~–CH~2~–. Mắt xích này nặng bao nhiêu?

> [!goi-y] Gợi ý 2
> Đồng phân phải có **cùng công thức phân tử**. Hãy so sánh C~2~H~4~ với (C~2~H~4~)~n~.

> [!loi-giai] Lời giải
> a) M(–CH~2~–CH~2~–) = 2·12 + 4·1 = 28. Vậy n = 420 000 : 28 = **15 000**.
>
> b) **Không**. Hai chất có cùng thành phần phần trăm nguyên tố nhưng công thức phân tử khác nhau: C~2~H~4~ và (C~2~H~4~)~n~ với n rất lớn.

> [!bay]
> - "Polymer có phân tử khối xác định": **sai**. Đó là giá trị **trung bình**.
> - Mắt xích **không phải** là monomer. Ví dụ, monomer CH~2~=CH~2~ có liên kết đôi, còn mắt xích –CH~2~–CH~2~– chỉ có liên kết đơn. Với polymer trùng ngưng, mắt xích còn **ít nguyên tử hơn** monomer, vì đã tách nước (mục 4.2).

### 1.2. Danh pháp

Quy tắc chung cho các polymer đơn giản:

**Tên polymer = poly + tên monomer.** Nếu tên monomer gồm **từ hai cụm từ trở lên** thì đặt tên đó trong **ngoặc đơn**.

- ethylene → **poly**ethylene (PE); styrene → **poly**styrene (PS)
- vinyl chloride → **poly(vinyl chloride)** (PVC); methyl methacrylate → **poly(methyl methacrylate)** (PMMA)

Một số polymer có **tên riêng**, không theo quy tắc trên: capron, nylon-6,6. Một số khác có **tên thông thường**: cao su thiên nhiên (polyisoprene), nhựa bakelite (thuộc loại PPF).

### 1.3. Các polymer thường gặp (cần thuộc)

Bảng dưới đây xếp các polymer trong mục tiêu SGK (SGK tr. 52), kèm monomer và phân tử khối mắt xích để dùng khi tính toán:

| Polymer (kí hiệu) | Mắt xích | Monomer | M mắt xích |
|---|---|---|---|
| polyethylene (PE) | –CH~2~–CH~2~– | CH~2~=CH~2~ (ethylene) | 28 |
| polypropylene (PP) | –CH~2~–CH(CH~3~)– | CH~2~=CH–CH~3~ (propylene) | 42 |
| poly(vinyl chloride) (PVC) | –CH~2~–CHCl– | CH~2~=CHCl (vinyl chloride) | 62,5 |
| polystyrene (PS) | –CH~2~–CH(C~6~H~5~)– | CH~2~=CH–C~6~H~5~ (styrene) | 104 |
| poly(methyl methacrylate) (PMMA) | –CH~2~–C(CH~3~)(COOCH~3~)– | CH~2~=C(CH~3~)–COOCH~3~ | 100 |
| polybuta-1,3-diene | –CH~2~–CH=CH–CH~2~– | CH~2~=CH–CH=CH~2~ | 54 |
| polyisoprene | –CH~2~–C(CH~3~)=CH–CH~2~– | CH~2~=C(CH~3~)–CH=CH~2~ (isoprene) | 68 |
| capron | –NH–[CH~2~]~5~–CO– | caprolactam (hoặc H~2~N–[CH~2~]~5~–COOH) | 113 |
| nylon-6,6 | –NH–[CH~2~]~6~–NH–CO–[CH~2~]~4~–CO– | H~2~N–[CH~2~]~6~–NH~2~ + HOOC–[CH~2~]~4~–COOH | 226 |
| poly(phenol formaldehyde) (PPF) | –C~6~H~3~(OH)–CH~2~– | C~6~H~5~OH + HCHO | 106 |

**Vì sao polybuta-1,3-diene có liên kết đôi ở giữa mắt xích?** Buta-1,3-diene có hai liên kết đôi C1=C2 và C3=C4. Khi trùng hợp, cả hai liên kết đôi đều mở ra, rồi một liên kết đôi mới hình thành giữa C2 và C3. Hai đầu C1 và C4 nối sang mắt xích bên cạnh. Isoprene cũng phản ứng theo cách đó.

> [!meo] Từ mắt xích tìm monomer (polymer trùng hợp)
> - Mắt xích có **2 C trên mạch chính** (–CH~2~–CHX–): đặt lại liên kết đôi giữa 2 C đó → CH~2~=CHX.
> - Mắt xích có **4 C trên mạch chính, liên kết đôi ở giữa** (–CH~2~–CR=CH–CH~2~–): "đẩy" liên kết đôi ra hai bên → CH~2~=CR–CH=CH~2~.
>
> Nhóm thế X giữ nguyên: X = H (PE), CH~3~ (PP), Cl (PVC), C~6~H~5~ (PS), CN (PAN).

> [!vi-du] Ví dụ 2
> a) Gọi tên polymer tạo thành từ các monomer: acrylonitrile CH~2~=CH–CN; vinyl acetate CH~2~=CH–OCOCH~3~; tetrafluoroethylene CF~2~=CF~2~.
>
> b) Viết công thức monomer tạo ra polymer có mắt xích –CH~2~–CH(CH~3~)–.

> [!goi-y] Gợi ý 1
> Tên monomer có một cụm từ hay hai cụm từ? Hai cụm thì cần ngoặc đơn.

> [!goi-y] Gợi ý 2
> Mắt xích có 2 C trên mạch chính → đặt lại liên kết đôi giữa 2 C đó.

> [!loi-giai] Lời giải
> a) **polyacrylonitrile** (PAN, một cụm từ nên không cần ngoặc); **poly(vinyl acetate)**; **polytetrafluoroethylene** (PTFE, chất chống dính Teflon).
>
> b) Monomer là CH~2~=CH–CH~3~ (**propylene**), polymer là polypropylene (PP).

### 1.4. Phân loại polymer (mở rộng)

SGK không có mục phân loại riêng trong bài này, nhưng đề thi rất hay hỏi "có bao nhiêu polymer thiên nhiên / tổng hợp…". Em cần nắm ba cách phân loại sau.

**a) Theo nguồn gốc**

| Loại | Ý nghĩa | Ví dụ |
|---|---|---|
| Thiên nhiên | Có sẵn trong tự nhiên | tinh bột, cellulose, protein, tơ tằm, len, cao su thiên nhiên |
| Tổng hợp | Con người tổng hợp từ monomer | PE, PP, PVC, PS, PMMA, capron, nylon-6,6, PPF, cao su buna |
| Bán tổng hợp (nhân tạo) | Lấy polymer thiên nhiên rồi chế hoá thêm | tơ visco, tơ cellulose acetate, cellulose nitrate |

**b) Theo cách tổng hợp** (xem mục 4)

- Polymer **trùng hợp**: PE, PP, PVC, PS, PMMA, PAN, polybuta-1,3-diene, polyisoprene…
- Polymer **trùng ngưng**: nylon-6,6, PPF, PET, các polypeptide…
- **Capron** điều chế được bằng **cả hai cách** (trùng hợp caprolactam hoặc trùng ngưng 6-aminohexanoic acid).

**c) Theo cấu trúc mạch**

![Hình 2. Ba kiểu cấu trúc mạch polymer. Mỗi vòng tròn là một mắt xích; vạch cam là cầu nối giữa các mạch](cau-truc-mach.svg)

- **Mạch không phân nhánh**: đa số polymer, ví dụ PE, PVC, amylose, cellulose.
- **Mạch phân nhánh**: amylopectin, glycogen.
- **Mạng lưới (không gian)**: cao su lưu hoá, nhựa bakelite.

> [!nen-tang] Polymer thiên nhiên em đã học
> - Tinh bột, cellulose (Bài 6): mắt xích C~6~H~10~O~5~ (M = 162). Amylose không nhánh, amylopectin phân nhánh, cellulose mạch thẳng.
> - Protein (Bài 10): các gốc α-amino acid nối bằng liên kết peptide. Tơ tằm và len là protein.

> [!vi-du] Ví dụ 3
> Cho các polymer: tinh bột, polyethylene, tơ visco, nylon-6,6, cao su thiên nhiên, poly(vinyl chloride), tơ cellulose acetate, tơ tằm. Có bao nhiêu polymer thiên nhiên, bao nhiêu polymer tổng hợp, bao nhiêu polymer bán tổng hợp?

> [!goi-y] Gợi ý 1
> Polymer nào có sẵn trong cây cối, con vật? Polymer nào hoàn toàn do nhà máy làm ra từ monomer?

> [!goi-y] Gợi ý 2
> Tơ visco và tơ cellulose acetate đi từ nguyên liệu gì? Gỗ, bông chứa cellulose.

> [!loi-giai] Lời giải
> - Thiên nhiên: tinh bột, cao su thiên nhiên, tơ tằm → **3**.
> - Tổng hợp: polyethylene, nylon-6,6, poly(vinyl chloride) → **3**.
> - Bán tổng hợp: tơ visco, tơ cellulose acetate (chế biến từ cellulose) → **2**.

> [!bay]
> - Tơ visco, tơ cellulose acetate **không** phải polymer thiên nhiên, cũng **không** phải tổng hợp. Chúng là polymer **bán tổng hợp**.
> - Cao su thiên nhiên chính là polyisoprene. Còn "polyisoprene tổng hợp" thì do con người trùng hợp isoprene. Đề phải ghi rõ nguồn gốc.

## 2. Tính chất vật lí

**Trạng thái.** Hầu hết polymer là **chất rắn, không bay hơi**. Phân tử quá lớn, lực hút giữa các mạch quá mạnh nên chúng không thể "bay" thành hơi.

**Nhiệt độ nóng chảy.** Polymer **không nóng chảy**, hoặc nóng chảy trong **một khoảng nhiệt độ khá rộng**, chứ không ở một nhiệt độ xác định. **Vì sao?** Như mục 1.1 đã nói, polymer là hỗn hợp nhiều mạch dài ngắn khác nhau. Mạch ngắn mềm ra trước, mạch dài mềm ra sau.

- **Polymer nhiệt dẻo**: nóng chảy khi đun nóng, để nguội lại rắn. Vì vậy có thể nấu chảy để đúc lại, tái chế (PE, PP, PVC, PS…).
- **Polymer nhiệt rắn**: đun nóng **không nóng chảy** mà bị **phân huỷ** (ví dụ nhựa bakelite làm tay cầm xoong, ổ cắm điện).

Cách giải thích đơn giản: polymer nhiệt dẻo thường có mạch không phân nhánh hoặc phân nhánh. Khi đun nóng, các mạch trượt được lên nhau. Polymer nhiệt rắn có cấu trúc mạng lưới, các mạch bị "khoá" với nhau nên không chảy ra được.

**Tính tan.** Hầu hết polymer **không tan trong nước**. Một số tan được trong dung môi hữu cơ.

**Tính chất cơ học và tính chất khác** (phụ thuộc vào cấu tạo):

| Tính chất | Polymer tiêu biểu | Ứng dụng |
|---|---|---|
| Tính dẻo | PE, PP, PVC | màng bọc, túi, ống nước, đồ gia dụng |
| Tính đàn hồi | polyisoprene, polybuta-1,3-diene | cao su: săm, lốp, găng tay |
| Dai, bền, kéo được sợi | capron, nylon-6,6 | vải, dây dù, lưới đánh cá |
| Cách điện | PE, PVC | vỏ bọc dây điện |
| Bán dẫn | một số polymer đặc biệt | linh kiện điện tử |

> [!ung-dung] Kí hiệu tái chế trên bao bì (SGK tr. 52)
> Sáu polymer nhiệt dẻo phổ biến có số hiệu in trong hình tam giác ở đáy chai, hộp:
>
> | Số | 1 | 2 | 3 | 4 | 5 | 6 |
> |---|---|---|---|---|---|---|
> | Polymer | PET | HDPE | PVC | LDPE | PP | PS |
>
> (HDPE, LDPE là polyethylene tỉ khối cao và thấp.) Nhờ kí hiệu này, rác nhựa được phân loại để tái chế đúng cách. Hộp đựng thức ăn dùng được trong lò vi sóng thường là PP (số 5).

> [!vi-du] Ví dụ 4
> Tay cầm xoong chảo thường làm bằng nhựa bakelite, còn chai nước khoáng làm bằng PET. Vì sao chai PET có thể nấu chảy để tái chế thành sợi, còn tay cầm bakelite thì không?

> [!goi-y] Gợi ý 1
> Hai loại nhựa này thuộc nhóm nhiệt dẻo hay nhiệt rắn?

> [!goi-y] Gợi ý 2
> Nghĩ đến cấu trúc mạch: mạch rời nhau, hay mạng lưới?

> [!loi-giai] Lời giải
> PET là polymer **nhiệt dẻo**: mạch không phân nhánh, khi đun thì các mạch trượt lên nhau và chảy ra, để nguội lại rắn. Vì vậy có thể nấu chảy rồi kéo sợi hoặc đúc lại.
>
> Bakelite là polymer **nhiệt rắn**: có cấu trúc mạng lưới, đun nóng không chảy mà bị phân huỷ. Không thể nấu chảy để tái chế. Bù lại, nó chịu nhiệt tốt nên hợp làm tay cầm xoong.

## 3. Tính chất hoá học

Polymer có thể tham gia ba kiểu phản ứng. Cách dễ nhớ nhất là nhìn **chiều dài mạch** thay đổi thế nào sau phản ứng: ngắn đi, dài ra hay giữ nguyên.

### 3.1. Phản ứng cắt mạch

Mạch polymer bị cắt thành đoạn ngắn hơn, có thể đến tận monomer, dưới tác dụng của nhiệt, tác nhân hoá học hoặc sinh học.

**a) Nhiệt phân polystyrene** (giải trùng hợp, ngược với trùng hợp):

=> (–CH~2~–CH(C~6~H~5~)–)~n~ → nCH~2~=CH–C~6~H~5~    (t°)

**b) Thuỷ phân polyamide.** Capron và nylon-6,6 có nhóm amide –CO–NH– trong mạch, giống liên kết peptide trong protein. Trong môi trường acid hoặc base, khi đun nóng, các liên kết này bị cắt hết:

=> (–NH–[CH~2~]~5~–CO–)~n~ + nH~2~O → nH~2~N–[CH~2~]~5~–COOH    (t°, xt)

Sản phẩm là **6-aminohexanoic acid**.

**c) Thuỷ phân tinh bột, cellulose** (Bài 6): nhờ acid hoặc enzyme.

=> (C~6~H~10~O~5~)~n~ + nH~2~O → nC~6~H~12~O~6~    (H^+^, t° hoặc enzyme)

> [!ung-dung] Vì sao quần áo nylon không nên giặt bằng xà phòng có tính kiềm mạnh, không là (ủi) quá nóng?
> Liên kết amide trong nylon, capron dễ bị **thuỷ phân** trong kiềm và acid, và polymer bị mềm, chảy khi gặp nhiệt độ cao. Vải sẽ bị mục, thủng.

### 3.2. Phản ứng tăng mạch

Ở điều kiện thích hợp (nhiệt độ, xúc tác…), các mạch polymer có thể nối với nhau thành mạch dài hơn hoặc thành **mạng lưới**.

Ví dụ quan trọng nhất là **lưu hoá cao su**: đun cao su với lưu huỳnh, các mạch polyisoprene được nối với nhau chủ yếu bằng **cầu disulfide –S–S–**.

![Hình 3. Lưu hoá cao su: cầu –S–S– nối các mạch rời thành mạng lưới. Mỗi cầu thay thế 2 nguyên tử H của hai mắt xích](luu-hoa.svg)

**Vì sao cao su lưu hoá tốt hơn cao su thô?** Ở cao su thô, các mạch rời nhau. Khi kéo mạnh, các mạch trượt hẳn khỏi nhau nên cao su bị biến dạng mà không co lại. Gặp nóng thì cao su dính, gặp lạnh thì giòn. Trong cao su lưu hoá, các cầu –S–S– giữ các mạch lại thành mạng lưới. Kéo ra thì mạch duỗi, buông ra thì "lò xo" kéo về. Vì vậy cao su lưu hoá **đàn hồi hơn, bền nhiệt hơn, khó tan trong dung môi hơn**. Săm, lốp xe đều làm từ cao su lưu hoá.

### 3.3. Phản ứng giữ nguyên mạch

Phản ứng xảy ra ở **nhóm thế** gắn vào mạch, hoặc là phản ứng **cộng vào liên kết đôi** trong mạch. Số mắt xích (n) không đổi.

Ví dụ trong SGK là thuỷ phân poly(vinyl acetate) trong dung dịch NaOH. Nhóm ester –OCOCH~3~ treo bên mạch bị thuỷ phân giống như phản ứng xà phòng hoá ester (Bài 1), còn mạch C–C không bị đụng tới:

=> (–CH~2~–CH(OCOCH~3~)–)~n~ + nNaOH → (–CH~2~–CH(OH)–)~n~ + nCH~3~COONa    (t°)

Sản phẩm là **poly(vinyl alcohol)**, dùng làm keo dán, màng tan trong nước.

Một ví dụ khác là cộng H~2~ vào liên kết đôi của polybuta-1,3-diene (Ni, t°). Mắt xích –CH~2~–CH=CH–CH~2~– chuyển thành –CH~2~–CH~2~–CH~2~–CH~2~–, còn số mắt xích không đổi.

> [!vi-du] Ví dụ 5
> Xác định kiểu phản ứng (cắt mạch, tăng mạch hay giữ nguyên mạch) và viết phương trình hoá học (nếu có):
>
> a) Đun poly(methyl methacrylate) với dung dịch NaOH dư.
>
> b) Đun nylon-6,6 với dung dịch HCl dư đến khi thuỷ phân hoàn toàn.
>
> c) Đun nóng cao su thiên nhiên với lưu huỳnh.

> [!goi-y] Gợi ý 1
> Hãy tìm xem nhóm dễ bị thuỷ phân (ester, amide) nằm **trong mạch chính** hay **ở nhánh**. Nằm trong mạch thì thuỷ phân sẽ cắt mạch. Nằm ở nhánh thì mạch giữ nguyên.

> [!goi-y] Gợi ý 2
> Trong PMMA, nhóm –COOCH~3~ nằm ở nhánh. Trong nylon-6,6, nhóm –CO–NH– nằm ngay trên mạch chính. Với HCl dư, nhóm –NH~2~ sinh ra sẽ tạo muối.

> [!loi-giai] Lời giải
> a) **Giữ nguyên mạch** (thuỷ phân nhóm ester ở nhánh):
>
> => (–CH~2~–C(CH~3~)(COOCH~3~)–)~n~ + nNaOH → (–CH~2~–C(CH~3~)(COONa)–)~n~ + nCH~3~OH    (t°)
>
> b) **Cắt mạch** (thuỷ phân hết liên kết amide trong mạch chính):
>
> => (–NH–[CH~2~]~6~–NH–CO–[CH~2~]~4~–CO–)~n~ + 2nH~2~O + 2nHCl → nHOOC–[CH~2~]~4~–COOH + nClH~3~N–[CH~2~]~6~–NH~3~Cl    (t°)
>
> c) **Tăng mạch**: lưu hoá cao su, tạo cầu –S–S– nối các mạch thành mạng lưới.

> [!ung-dung] Hộp xốp polystyrene và đồ ăn nóng
> Hộp xốp trắng làm từ polystyrene. PS mềm ra ở khoảng 90–100 °C. Khi đựng đồ rất nóng, nhiều dầu mỡ, hoặc cho vào lò vi sóng, hộp có thể biến dạng và một lượng nhỏ styrene có thể đi vào thức ăn. Vì vậy **không nên** dùng hộp xốp để đựng thức ăn nóng hay hâm nóng bằng lò vi sóng (đối chiếu câu hỏi SGK tr. 54).

## 4. Phương pháp tổng hợp polymer

Có hai phương pháp phổ biến: **trùng hợp** và **trùng ngưng**. Điểm khác nhau quan trọng nhất là **có tách ra phân tử nhỏ hay không**.

![Hình 4. Trùng hợp (vinyl chloride → PVC): liên kết đôi mở ra, không mất nguyên tử nào. Trùng ngưng (6-aminohexanoic acid → capron): mỗi chỗ nối tách ra một phân tử H~2~O](trung-hop-trung-ngung.svg)

### 4.1. Trùng hợp

**Trùng hợp** là quá trình kết hợp nhiều phân tử nhỏ **giống nhau hoặc tương tự nhau** (monomer) thành phân tử rất lớn (polymer).

**Điều kiện của monomer:** phân tử phải có **liên kết bội** (thường là liên kết đôi C=C, dạng CH~2~=CHR) **hoặc vòng kém bền** có thể mở ra.

**Vì sao cần liên kết đôi?** Liên kết đôi gồm 1 liên kết σ bền và 1 liên kết π kém bền. Khi trùng hợp, liên kết π bị phá. Mỗi nguyên tử carbon ở hai đầu có thêm "một tay" để nắm lấy phân tử bên cạnh. Toàn bộ nguyên tử của monomer đều đi vào polymer, không mất gì.

=> nCH~2~=CHCl → (–CH~2~–CHCl–)~n~    (t°, p, xt)

=> nCH~2~=CH–CH=CH~2~ → (–CH~2~–CH=CH–CH~2~–)~n~    (t°, p, xt)

**Trùng hợp mở vòng:** caprolactam là một vòng 7 cạnh có nhóm –CO–NH– (vòng kém bền). Khi đun nóng có xúc tác, vòng mở ra và nối thành capron:

=> n(caprolactam) → (–NH–[CH~2~]~5~–CO–)~n~    (t°, xt)

> [!bay] Có vòng benzene ≠ trùng hợp được
> - Benzene, toluene **không** trùng hợp được: vòng benzene rất bền, không có liên kết đôi C=C "thật sự" để mở ra.
> - **Styrene** C~6~H~5~–CH=CH~2~ thì trùng hợp được, nhờ liên kết đôi ở nhóm **vinyl** (CH~2~=CH–), chứ không phải nhờ vòng benzene.
> - Alkane (ethane, propane…), alcohol no (ethanol), acid no (acetic acid) **không** trùng hợp được.

> [!em-co-biet] Đồng trùng hợp
> Có thể trùng hợp **hai loại monomer khác nhau** cùng lúc, gọi là **đồng trùng hợp**. Ví dụ: buta-1,3-diene + styrene → cao su buna-S. Em sẽ gặp lại ở Bài 13.

### 4.2. Trùng ngưng

**Trùng ngưng** là quá trình kết hợp nhiều monomer thành polymer, **đồng thời giải phóng những phân tử nhỏ khác** (thường là H~2~O).

**Điều kiện của monomer:** mỗi phân tử phải có **ít nhất hai nhóm chức có khả năng phản ứng**.

**Vì sao cần hai nhóm chức?** Hãy nghĩ đến các toa tàu. Một toa chỉ có móc ở một đầu thì chỉ nối được với một toa khác rồi dừng lại. Toa có móc ở **cả hai đầu** thì nối thành đoàn tàu dài vô tận. Mỗi nhóm chức là một "cái móc". Khi hai móc gặp nhau (ví dụ –COOH gặp –NH~2~), chúng nối lại và tách ra một phân tử nước.

**Ví dụ 1: nylon-6,6** từ hexamethylenediamine (2 nhóm –NH~2~) và adipic acid (2 nhóm –COOH):

=> nHOOC–[CH~2~]~4~–COOH + nH~2~N–[CH~2~]~6~–NH~2~ → (–CO–[CH~2~]~4~–CO–NH–[CH~2~]~6~–NH–)~n~ + 2nH~2~O    (t°)

Mỗi mắt xích nylon-6,6 được tạo từ 1 phân tử acid và 1 phân tử amine, tách ra **2** phân tử H~2~O. Kiểm tra: 146 + 116 − 2·18 = 226.

**Ví dụ 2: capron** từ 6-aminohexanoic acid (1 nhóm –NH~2~ và 1 nhóm –COOH trong cùng phân tử):

=> nH~2~N–[CH~2~]~5~–COOH → (–NH–[CH~2~]~5~–CO–)~n~ + nH~2~O    (t°, xt)

**Các ví dụ khác (mở rộng):**

- Phenol + formaldehyde → **PPF** (nhựa novolac, rezol, bakelite), tách H~2~O.
- Terephthalic acid + ethylene glycol → **PET** (chai nhựa số 1, tơ lavsan), tách H~2~O.
- Các α-amino acid → polypeptide (Bài 9).

### 4.3. So sánh trùng hợp và trùng ngưng

| | Trùng hợp | Trùng ngưng |
|---|---|---|
| Điều kiện monomer | Có liên kết bội (C=C) hoặc vòng kém bền | Có ≥ 2 nhóm chức phản ứng được |
| Sản phẩm phụ | Không có | Có phân tử nhỏ (thường là H~2~O) |
| Thành phần mắt xích | Giống monomer | Ít hơn monomer (đã mất H~2~O) |
| Khối lượng (H = 100%) | m(polymer) = m(monomer) | m(polymer) = m(monomer) − m(H~2~O) |
| Ví dụ | PE, PP, PVC, PS, PMMA, cao su, capron (từ caprolactam) | nylon-6,6, PPF, PET, capron (từ amino acid) |

> [!vi-du] Ví dụ 6
> Cho các chất: ethane, styrene, toluene, caprolactam, vinyl chloride, ethylene glycol, 6-aminohexanoic acid, propylene.
>
> a) Có bao nhiêu chất tham gia được phản ứng trùng hợp?
>
> b) Chất nào tự trùng ngưng được (một mình nó tạo polymer)?

> [!goi-y] Gợi ý 1
> Trùng hợp: soát từng chất xem có liên kết đôi C=C ngoài vòng benzene hoặc vòng kém bền không.

> [!goi-y] Gợi ý 2
> Trùng ngưng một mình: một phân tử phải chứa **hai loại nhóm chức phản ứng được với nhau** (ví dụ –NH~2~ và –COOH). Ethylene glycol chỉ có 2 nhóm –OH, nên cần thêm một diacid.

> [!loi-giai] Lời giải
> a) Trùng hợp được: styrene, caprolactam (mở vòng), vinyl chloride, propylene → **4 chất**. Ethane (chỉ có liên kết đơn), toluene (vòng benzene bền), ethylene glycol, 6-aminohexanoic acid (không có liên kết đôi C=C) thì không.
>
> b) **6-aminohexanoic acid** tự trùng ngưng tạo capron. Ethylene glycol có 2 nhóm –OH nên tham gia trùng ngưng được, nhưng phải đi cùng một diacid (ví dụ terephthalic acid → PET).

> [!vi-du] Ví dụ 7
> Trùng ngưng 29,2 kg adipic acid với lượng vừa đủ hexamethylenediamine, hiệu suất 80%. Tính khối lượng nylon-6,6 thu được.

> [!goi-y] Gợi ý 1
> 1 mol adipic acid (M = 146) tạo 1 mol mắt xích nylon-6,6 (M = 226). Không cần biết n.

> [!goi-y] Gợi ý 2
> Đi từ chất đầu ra sản phẩm thì **nhân** hiệu suất.

> [!loi-giai] Lời giải
> n(adipic acid) = 29,2 : 146 = 0,2 kmol → n(mắt xích) lí thuyết = 0,2 kmol.
>
> m(nylon-6,6) = 0,2 · 226 · 0,8 = **36,16 kg**.
>
> (Nếu quên trừ nước và lấy M = 146 + 116 = 262, em sẽ ra 41,92 kg. Đây là đáp án nhiễu hay gặp.)

## Dạng bài thi hay gặp

### Dạng 1. Monomer ↔ polymer ↔ phương pháp điều chế

**Nhận biết:** đề cho tên hoặc công thức polymer, hỏi monomer; hoặc cho dãy chất, hỏi chất nào trùng hợp / trùng ngưng được; hoặc hỏi polymer nào điều chế bằng phản ứng nào.

**Phương pháp:**

1. Thuộc bảng 10 polymer ở mục 1.3 (mắt xích, monomer).
2. Trùng hợp: soát **C=C ngoài vòng benzene** hoặc **vòng kém bền** (caprolactam).
3. Trùng ngưng: soát **≥ 2 nhóm chức** (–OH, –COOH, –NH~2~); polymer có nhóm –CO–NH– hoặc –CO–O– **trong mạch chính** thường là polymer trùng ngưng.
4. Từ mắt xích trùng ngưng tìm monomer: cắt ở liên kết amide/ester, rồi trả lại H cho N (hoặc O) và OH cho C=O.

> [!vi-du] Ví dụ 8
> Xác định monomer và phương pháp điều chế các polymer có mắt xích sau:
>
> a) –CH~2~–CH(CN)–
>
> b) –NH–CH~2~–CO–
>
> c) –CH~2~–C(CH~3~)=CH–CH~2~–

> [!goi-y] Gợi ý 1
> Mắt xích nào có nhóm –CO–NH– trên mạch chính? Mắt xích đó đến từ trùng ngưng: thêm H vào N, thêm OH vào C=O.

> [!goi-y] Gợi ý 2
> Mắt xích 4 C có liên kết đôi ở giữa: đẩy liên kết đôi ra hai đầu.

> [!loi-giai] Lời giải
> a) CH~2~=CH–CN (acrylonitrile), **trùng hợp**, tạo polyacrylonitrile (PAN).
>
> b) H~2~N–CH~2~–COOH (glycine), **trùng ngưng**.
>
> c) CH~2~=C(CH~3~)–CH=CH~2~ (isoprene), **trùng hợp**, tạo polyisoprene.

> [!bay]
> - **Capron** điều chế được bằng **cả trùng hợp** (caprolactam) **lẫn trùng ngưng** (6-aminohexanoic acid). Đề hỏi "chỉ điều chế được bằng trùng ngưng" thì capron không thoả.
> - **Nylon-6,6** chỉ điều chế bằng trùng ngưng, từ **hai** monomer.
> - "Monomer của PVC là ethyl chloride" là **sai**. Monomer của PVC là **vinyl chloride** CH~2~=CHCl.

### Dạng 2. Phân loại, tính chất – đếm số chất và câu Đúng/Sai

**Nhận biết:** "Trong dãy … có bao nhiêu polymer thiên nhiên / tổng hợp / có mạch phân nhánh / thuộc loại nhiệt rắn / bị thuỷ phân trong kiềm…"; hoặc 4 ý Đúng/Sai về khái niệm, tính chất.

**Phương pháp:** đi qua từng chất, đánh dấu vào bảng, **đừng làm nhẩm**. Với câu Đúng/Sai, soát kĩ các từ khoá: "xác định", "tất cả", "chỉ", "cùng công thức", "trùng hợp / trùng ngưng", "cắt / giữ / tăng mạch".

> [!vi-du] Ví dụ 9
> Cho các polymer: amylose, amylopectin, glycogen, cao su lưu hoá, poly(vinyl chloride), cellulose, nhựa bakelite. Có bao nhiêu polymer có mạch không phân nhánh?

> [!goi-y] Gợi ý 1
> Nhắc lại: phân nhánh có amylopectin và glycogen. Mạng lưới có cao su lưu hoá và nhựa bakelite.

> [!goi-y] Gợi ý 2
> Còn lại những chất nào?

> [!loi-giai] Lời giải
> - Không phân nhánh: amylose, poly(vinyl chloride), cellulose → **3**.
> - Phân nhánh: amylopectin, glycogen (2). Mạng lưới: cao su lưu hoá, nhựa bakelite (2).

> [!vi-du] Ví dụ 10 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Polyethylene có cùng thành phần phần trăm khối lượng các nguyên tố với ethylene.
>
> b) Các polymer đều nóng chảy ở một nhiệt độ xác định.
>
> c) Thuỷ phân poly(vinyl acetate) trong NaOH là phản ứng cắt mạch polymer.
>
> d) Khi trùng ngưng, khối lượng polymer thu được nhỏ hơn tổng khối lượng monomer đã phản ứng.

> [!goi-y] Gợi ý 1
> Nhóm ester của poly(vinyl acetate) nằm ở nhánh hay trên mạch chính?

> [!goi-y] Gợi ý 2
> Trùng ngưng tách ra chất gì?

> [!loi-giai] Lời giải
> a) **Đúng**: mắt xích –CH~2~–CH~2~– và ethylene đều có thành phần C~2~H~4~.
>
> b) **Sai**: polymer nóng chảy trong một khoảng nhiệt độ, hoặc bị phân huỷ mà không nóng chảy (nhiệt rắn).
>
> c) **Sai**: nhóm –OCOCH~3~ nằm ở nhánh, mạch C–C giữ nguyên. Đây là phản ứng **giữ nguyên mạch**.
>
> d) **Đúng**: trùng ngưng tách ra phân tử nhỏ (H~2~O), nên m(polymer) = m(monomer) − m(H~2~O).

### Dạng 3. Hệ số polymer hoá và khối lượng polymer (có hiệu suất)

**Nhận biết:** đề cho phân tử khối polymer, hỏi số mắt xích; hoặc cho khối lượng monomer, hỏi khối lượng polymer (và ngược lại), có hiệu suất một hay nhiều giai đoạn.

**Phương pháp:**

1. n = M(polymer) : M(mắt xích). Nhớ M mắt xích: PE 28, PP 42, PVC 62,5, PS 104, PMMA 100, capron 113, nylon-6,6 226, polyisoprene 68.
2. Tính theo **mol mắt xích**, bỏ qua n. Trùng hợp: 1 monomer → 1 mắt xích, khối lượng giữ nguyên. Trùng ngưng: nhớ trừ nước.
3. Hiệu suất nhiều giai đoạn: H = H~1~ · H~2~ · … Đi xuôi (tìm sản phẩm) thì **nhân** H. Đi ngược (tìm nguyên liệu) thì **chia** H.
4. Viết sơ đồ hợp thức theo **số nguyên tử C**. Ví dụ: 2CH~4~ → C~2~H~2~ → C~2~H~3~Cl → (C~2~H~3~Cl), tức là 2 mol CH~4~ cho 1 mol mắt xích PVC.

> [!vi-du] Ví dụ 11
> a) Một mẫu nylon-6,6 có phân tử khối trung bình là 27 120. Tính hệ số polymer hoá.
>
> b) Trùng hợp 5,6 tấn ethylene với hiệu suất 90%. Tính khối lượng polyethylene thu được.

> [!goi-y] Gợi ý 1
> Mắt xích nylon-6,6: C~12~H~22~O~2~N~2~. Tính M.

> [!goi-y] Gợi ý 2
> Trùng hợp không mất nguyên tử nào, nên m(polymer) lí thuyết = m(monomer).

> [!loi-giai] Lời giải
> a) M(mắt xích) = 12·12 + 22·1 + 2·16 + 2·14 = 226 → n = 27 120 : 226 = **120**.
>
> b) m(PE) = 5,6 · 0,9 = **5,04 tấn**.

> [!vi-du] Ví dụ 12 (vận dụng cao)
> PVC được sản xuất từ khí thiên nhiên theo sơ đồ:
>
> CH~4~ → C~2~H~2~ → CH~2~=CHCl → PVC
>
> Hiệu suất các giai đoạn lần lượt là 50%, 80% và 90%. Tính thể tích CH~4~ (đkc, 24,79 L/mol) cần để sản xuất 2,5 tấn PVC (làm tròn đến hàng đơn vị, đơn vị m^3^).

> [!goi-y] Gợi ý 1
> n(mắt xích PVC) = 2 500 kg : 62,5. Mỗi mắt xích có 2 C, nên cần 2 phân tử CH~4~.

> [!goi-y] Gợi ý 2
> H chung = 0,5 · 0,8 · 0,9. Đây là bài đi ngược, nên **chia** cho H. Đổi 1 kmol khí = 24,79 m^3^.

> [!loi-giai] Lời giải
> n(PVC) = 2 500 : 62,5 = 40 kmol → n(CH~4~) lí thuyết = 2 · 40 = 80 kmol.
>
> H chung = 0,5 · 0,8 · 0,9 = 0,36 → n(CH~4~) cần = 80 : 0,36 ≈ 222,22 kmol.
>
> V = 222,22 · 24,79 ≈ **5 509 m^3^**.

> [!nen-tang] Điều chế acetylene, vinyl chloride (lớp 11)
> - 2CH~4~ → C~2~H~2~ + 3H~2~ (1 500 °C, làm lạnh nhanh).
> - C~2~H~2~ + HCl → CH~2~=CHCl (xt, t°).
>
> Ngày nay vinyl chloride chủ yếu được sản xuất từ ethylene, nhưng sơ đồ đi từ CH~4~ vẫn hay dùng trong bài tập.

> [!bay]
> - Quên hệ số **2** (2 CH~4~ → 1 C~2~H~2~) sẽ làm kết quả nhỏ đi một nửa.
> - Nhân H khi đi ngược sẽ cho đáp án nhỏ hơn đáp án đúng. Hãy tự hỏi: "Có hao hụt thì cần **nhiều** hay **ít** nguyên liệu hơn?"
> - Trùng ngưng nylon-6,6: M mắt xích là 226, **không phải** 262 (phải trừ 2H~2~O).

### Dạng 4. Lưu hoá cao su – số mắt xích trên một cầu disulfide

**Nhận biết:** đề cho phần trăm khối lượng S trong cao su lưu hoá, hỏi trung bình bao nhiêu mắt xích isoprene thì có một cầu –S–S–.

**Phương pháp:**

1. Gọi k là số mắt xích isoprene (C~5~H~8~, M = 68) ứng với 1 cầu –S–S–.
2. Một cầu disulfide **thêm 2 S** và **thay 2 nguyên tử H** (xem Hình 3). Khối lượng đoạn đó: 68k + 64 − 2 = 68k + 62.
3. Lập phương trình: 64 : (68k + 62) = %S, rồi giải tìm k và làm tròn.

> [!vi-du] Ví dụ 13
> Một loại cao su lưu hoá chứa 2% lưu huỳnh về khối lượng. Giả sử S chỉ tạo cầu –S–S– thay cho H ở nhóm –CH~2~– trong mạch cao su. Hỏi trung bình bao nhiêu mắt xích isoprene thì có một cầu disulfide?

> [!goi-y] Gợi ý 1
> Đoạn mạch gồm k mắt xích và 1 cầu –S–S– có công thức C~5k~H~8k−2~S~2~.

> [!goi-y] Gợi ý 2
> %S = 2·32 : (68k − 2 + 64) = 0,02.

> [!loi-giai] Lời giải
> 64 : (68k + 62) = 0,02 → 68k + 62 = 3 200 → k = 3 138 : 68 ≈ 46,1.
>
> Trung bình khoảng **46 mắt xích** isoprene thì có một cầu disulfide.

> [!bay]
> - Một cầu disulfide có **2** nguyên tử S (M = 64), không phải 32. Nếu lấy 32 : (68k + 30) = 0,02 thì sẽ ra k ≈ 23, chỉ bằng một nửa đáp án đúng.
> - Đừng quên trừ 2 nguyên tử H đã bị thay thế. Ở bài này kết quả gần như không đổi, nhưng khi %S lớn thì sai số sẽ rõ hơn.

## Tóm tắt

| Khái niệm | Ghi nhớ |
|---|---|
| Polymer | Phân tử khối rất lớn, gồm nhiều mắt xích; là hỗn hợp các mạch có n khác nhau |
| Monomer | Phân tử nhỏ tạo nên polymer |
| Hệ số polymer hoá | n = M(polymer) : M(mắt xích) |
| Tên gọi | poly + tên monomer; tên có hai cụm từ trở lên thì đặt trong ngoặc: poly(vinyl chloride) |

| Cách phân loại | Các loại |
|---|---|
| Nguồn gốc | thiên nhiên (tinh bột, cellulose, tơ tằm, cao su thiên nhiên) · tổng hợp (PE, PVC, nylon-6,6…) · bán tổng hợp (tơ visco, tơ cellulose acetate) |
| Cách tổng hợp | trùng hợp (PE, PP, PVC, PS, PMMA, cao su) · trùng ngưng (nylon-6,6, PPF, PET) · capron: cả hai |
| Cấu trúc mạch | không nhánh (PE, PVC, amylose, cellulose) · phân nhánh (amylopectin, glycogen) · mạng lưới (cao su lưu hoá, bakelite) |

| Tính chất hoá học | Ví dụ |
|---|---|
| Cắt mạch | PS → styrene (t°); capron + H~2~O → 6-aminohexanoic acid; tinh bột, cellulose → glucose |
| Tăng mạch | Lưu hoá cao su: cầu –S–S– → mạng lưới |
| Giữ nguyên mạch | Poly(vinyl acetate) + NaOH → poly(vinyl alcohol) + CH~3~COONa |

| | Trùng hợp | Trùng ngưng |
|---|---|---|
| Điều kiện | liên kết bội / vòng kém bền | ≥ 2 nhóm chức |
| Sản phẩm phụ | không | H~2~O (thường gặp) |
| Khối lượng | m(polymer) = m(monomer) · H | m(polymer) = [m(monomer) − m(H~2~O)] · H |

**M mắt xích cần nhớ:** PE 28 · PP 42 · PVC 62,5 · PS 104 · PMMA 100 · polybuta-1,3-diene 54 · polyisoprene 68 · capron 113 · nylon-6,6 226 · tinh bột/cellulose 162.
