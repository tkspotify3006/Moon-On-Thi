---
title: Thế điện cực và nguồn điện hoá học
thoi-gian: 50 phút
muc-tieu:
  - Mô tả được cặp oxi hoá – khử của kim loại, chỉ ra dạng oxi hoá và dạng khử trong mỗi cặp.
  - Hiểu thế điện cực chuẩn là đại lượng đánh giá khả năng khử của dạng khử và khả năng oxi hoá của dạng oxi hoá ở điều kiện chuẩn.
  - Dùng bảng thế điện cực chuẩn để so sánh tính khử, tính oxi hoá, dự đoán chiều phản ứng giữa hai cặp oxi hoá – khử và tính sức điện động chuẩn của pin.
  - Trình bày được cấu tạo, nguyên tắc hoạt động của pin Galvani (pin Zn – Cu), vai trò của cầu muối, quá trình ở anode và cathode.
  - Nêu được ưu, nhược điểm chính của acquy, pin nhiên liệu, pin Mặt Trời, pin lithium-ion, pin khô. Lắp được pin đơn giản (pin chanh) và đo sức điện động.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Cặp oxi hoá – khử** M^n+^/M: dạng oxi hoá (ion M^n+^) viết trước, dạng khử (nguyên tử M) viết sau, liên hệ bởi M^n+^ + ne ⇌ M.
> 2. **Thế điện cực chuẩn E°** (đo ở 25 °C, ion 1 M, quy ước E°(2H^+^/H~2~) = 0): E° càng **nhỏ** thì kim loại có tính **khử càng mạnh**; E° càng **lớn** thì ion có tính **oxi hoá càng mạnh**.
> 3. **Chiều phản ứng (quy tắc α):** chất khử của cặp có E° nhỏ hơn tác dụng với chất oxi hoá của cặp có E° lớn hơn.
> 4. **Pin Galvani:** anode (cực âm) là nơi **oxi hoá**, cathode (cực dương) là nơi **khử**. Electron đi qua dây dẫn từ anode sang cathode. Cầu muối đóng kín mạch và giữ các dung dịch trung hoà điện.
> 5. **Sức điện động chuẩn:** E°~pin~ = E°~cathode~ − E°~anode~ (luôn dương). Pin Zn – Cu: 0,340 − (−0,762) = 1,102 V.

> [!nen-tang] Phản ứng oxi hoá – khử (Hoá 10)
> - **Chất khử** nhường electron, số oxi hoá **tăng**, bị oxi hoá. **Chất oxi hoá** nhận electron, số oxi hoá **giảm**, bị khử. Mẹo nhớ: "khử cho, O nhận".
> - **Quá trình oxi hoá**: Zn → Zn^2+^ + 2e. **Quá trình khử**: Cu^2+^ + 2e → Cu.
> - **Cân bằng bằng thăng bằng electron**: tổng số electron chất khử nhường = tổng số electron chất oxi hoá nhận. Ví dụ Al nhường 3e, Cu^2+^ nhận 2e nên nhân chéo: 2Al + 3Cu^2+^ → 2Al^3+^ + 3Cu.
> - Phương trình ion rút gọn: bỏ các ion không thay đổi (như SO~4~^2−^, Cl^−^, NO~3~^−^), giữ lại các chất thật sự nhường và nhận electron.

## 1. Cặp oxi hoá – khử của kim loại

### 1.1. Bắt đầu từ một thí nghiệm quen thuộc

Nhúng một thanh kẽm vào dung dịch CuSO~4~ màu xanh. Một lúc sau, thanh kẽm được phủ một lớp đồng màu đỏ, còn màu xanh của dung dịch nhạt dần (SGK tr. 67). Phương trình ion rút gọn:

=> Zn + Cu^2+^ → Zn^2+^ + Cu

Tách thành hai nửa:

- Zn → Zn^2+^ + 2e (Zn bị **oxi hoá**, là chất khử).
- Cu^2+^ + 2e → Cu (Cu^2+^ bị **khử**, là chất oxi hoá).

Để ý rằng mỗi nguyên tố xuất hiện ở **hai dạng**: kẽm có dạng Zn^2+^ và Zn, đồng có dạng Cu^2+^ và Cu. Hai dạng này chuyển qua lại được cho nhau, chỉ khác nhau vài electron.

### 1.2. Khái niệm

Nguyên tử kim loại có thể nhường electron thành cation. Ngược lại, cation kim loại có thể nhận electron để trở lại nguyên tử. Ta viết chung bằng một **bán phản ứng** có mũi tên hai chiều:

=> M^n+^ + ne ⇌ M

- **M^n+^** là **dạng oxi hoá** (có thể nhận electron, đóng vai chất oxi hoá).
- **M** là **dạng khử** (có thể nhường electron, đóng vai chất khử).
- Hai dạng của cùng một kim loại tạo thành **cặp oxi hoá – khử**, kí hiệu **M^n+^/M**: dạng oxi hoá viết **trên/trước**, dạng khử viết **dưới/sau**.

Ví dụ: Al^3+^ + 3e ⇌ Al ứng với cặp **Al^3+^/Al**; Zn^2+^ + 2e ⇌ Zn ứng với cặp **Zn^2+^/Zn**; Ag^+^ + 1e ⇌ Ag ứng với cặp **Ag^+^/Ag**.

> [!em-co-biet] Không chỉ có ion và nguyên tử kim loại
> Hai dạng của một cặp có thể đều là ion, ví dụ **Fe^3+^/Fe^2+^** (Fe^3+^ + 1e ⇌ Fe^2+^). Phi kim cũng có cặp oxi hoá – khử, ví dụ **2H^+^/H~2~** (2H^+^ + 2e ⇌ H~2~) và **Cl~2~/2Cl^−^**. Cặp Fe^3+^/Fe^2+^ rất hay gặp trong đề thi, em sẽ dùng nó ở mục 3.

> [!bay]
> - Viết **Cu/Cu^2+^** là sai thứ tự. Luôn viết dạng oxi hoá trước: Cu^2+^/Cu.
> - Cặp Fe^2+^/Fe và cặp Fe^3+^/Fe^2+^ là **hai cặp khác nhau**. Trong cặp thứ hai, Fe^2+^ đóng vai **dạng khử**.

> [!vi-du] Ví dụ 1
> Ngâm một lá nhôm đã cạo sạch lớp oxide vào dung dịch CuSO~4~, thấy có đồng đỏ bám lên lá nhôm.
>
> a) Viết phương trình ion rút gọn của phản ứng.
>
> b) Chỉ ra hai cặp oxi hoá – khử tham gia phản ứng và vai trò của từng chất.

> [!goi-y] Gợi ý 1
> Al nhường mấy electron để thành ion? Cu^2+^ nhận mấy electron? Dùng thăng bằng electron để tìm hệ số.

> [!goi-y] Gợi ý 2
> Mỗi kim loại góp một cặp: dạng oxi hoá/dạng khử.

> [!loi-giai] Lời giải
> a) Al → Al^3+^ + 3e và Cu^2+^ + 2e → Cu. Bội chung nhỏ nhất của 3 và 2 là 6, nên:
>
> => 2Al + 3Cu^2+^ → 2Al^3+^ + 3Cu
>
> b) Hai cặp là **Al^3+^/Al** và **Cu^2+^/Cu**. Al là chất khử (dạng khử của cặp Al^3+^/Al). Cu^2+^ là chất oxi hoá (dạng oxi hoá của cặp Cu^2+^/Cu).

## 2. Thế điện cực chuẩn

### 2.1. Điện cực

Nhúng một thanh kim loại M vào dung dịch chứa ion M^n+^ của chính nó, ta được một **điện cực**. Ví dụ: thanh Zn nhúng trong dung dịch ZnSO~4~ là **điện cực kẽm**; thanh Cu nhúng trong dung dịch CuSO~4~ là **điện cực đồng**. Ở chỗ kim loại tiếp xúc với dung dịch luôn có cân bằng giữa hai dạng của cặp:

=> Zn^2+^ + 2e ⇌ Zn

**Vì sao điện cực lại có "điện thế"?** Một số nguyên tử kẽm rời thanh kim loại, đi vào dung dịch thành ion Zn^2+^ và để lại electron trên thanh. Thanh kẽm vì thế tích điện âm, còn lớp dung dịch sát bề mặt tích điện dương. Hai lớp điện tích trái dấu nằm rất sát nhau (gọi là **lớp điện kép**) tạo ra một chênh lệch điện thế, đó chính là thế điện cực. Kim loại càng dễ nhường electron thì thanh càng "âm" hơn.

**Điều kiện chuẩn** của điện cực kim loại: nồng độ ion kim loại **1 M**, nhiệt độ thường được chọn là **25 °C (298 K)**.

> [!em-co-biet] Điện cực hydrogen chuẩn
> Hydrogen là khí, không làm thành thanh được. Người ta dùng một lá **platinum (Pt)** phủ khí H~2~ (áp suất 1 bar), nhúng trong dung dịch acid có [H^+^] = 1 M. Pt chỉ là chỗ dẫn điện, không tham gia phản ứng. Trên bề mặt lá Pt có cân bằng 2H^+^ + 2e ⇌ H~2~ (SGK tr. 69).

### 2.2. Thế điện cực chuẩn E°

Mỗi điện cực ở điều kiện chuẩn có một giá trị điện thế đặc trưng, gọi là **thế điện cực chuẩn**, kí hiệu **E°** kèm tên cặp, ví dụ E°(Zn^2+^/Zn). Đơn vị là volt (V).

**Một khó khăn:** không ai đo được điện thế "tuyệt đối" của một điện cực. Vôn kế chỉ đo được **hiệu** điện thế giữa hai điện cực. Giống như độ cao của núi: ta không đo "độ cao tuyệt đối" mà đo so với **mực nước biển** quy ước bằng 0.

Vì vậy người ta **quy ước**:

=> 2H^+^ + 2e ⇌ H~2~, E°(2H^+^/H~2~) = 0 V

Sau đó, ghép từng điện cực với điện cực hydrogen chuẩn rồi đo hiệu điện thế, sẽ được E° của điện cực đó. Kết quả là bảng thế điện cực chuẩn (Bảng 15.1, SGK tr. 70). Dưới đây là các giá trị hay dùng:

| Cặp oxi hoá – khử | Bán phản ứng | E° (V) |
|---|---|---|
| K^+^/K | K^+^ + 1e ⇌ K | −2,924 |
| Na^+^/Na | Na^+^ + 1e ⇌ Na | −2,713 |
| Mg^2+^/Mg | Mg^2+^ + 2e ⇌ Mg | −2,356 |
| Al^3+^/Al | Al^3+^ + 3e ⇌ Al | −1,676 |
| Zn^2+^/Zn | Zn^2+^ + 2e ⇌ Zn | −0,762 |
| Fe^2+^/Fe | Fe^2+^ + 2e ⇌ Fe | −0,44 |
| Ni^2+^/Ni | Ni^2+^ + 2e ⇌ Ni | −0,257 |
| Sn^2+^/Sn | Sn^2+^ + 2e ⇌ Sn | −0,137 |
| Pb^2+^/Pb | Pb^2+^ + 2e ⇌ Pb | −0,126 |
| 2H^+^/H~2~ | 2H^+^ + 2e ⇌ H~2~ | 0,000 |
| Cu^2+^/Cu | Cu^2+^ + 2e ⇌ Cu | +0,340 |
| Fe^3+^/Fe^2+^ | Fe^3+^ + 1e ⇌ Fe^2+^ | +0,771 |
| Ag^+^/Ag | Ag^+^ + 1e ⇌ Ag | +0,799 |
| Hg^2+^/Hg | Hg^2+^ + 2e ⇌ Hg | +0,853 |
| Au^3+^/Au | Au^3+^ + 3e ⇌ Au | +1,52 |

(Bảng SGK còn có Li, Ba, Ca, Cr, Cd và các cặp phi kim Br~2~/2Br^−^, O~2~/H~2~O, Cl~2~/2Cl^−^. Trong đề thi, các giá trị cần dùng luôn được cho sẵn, em không phải học thuộc số.)

**Đọc bảng thế nào?** E° đo "độ muốn nhận electron" của dạng oxi hoá:

- E° càng **nhỏ** (càng âm): dạng oxi hoá rất "không muốn" nhận electron, nên **ion có tính oxi hoá yếu**. Ngược lại, dạng khử rất dễ nhường electron, nên **kim loại có tính khử mạnh**. Ví dụ K, Na, Mg.
- E° càng **lớn** (càng dương): **ion có tính oxi hoá mạnh**, **kim loại có tính khử yếu**. Ví dụ Ag^+^, Au^3+^ rất dễ bị khử, còn Ag, Au rất khó bị oxi hoá (nên bền, không gỉ).

![Hình 1. Trục thế điện cực chuẩn: đi từ trái sang phải, tính khử của kim loại giảm dần, tính oxi hoá của ion kim loại tăng dần](truc-the.svg)

> [!meo] Nhớ chiều bằng "bập bênh"
> Trong cùng một cặp, tính oxi hoá của ion và tính khử của kim loại luôn **ngược chiều nhau**: kim loại khử càng mạnh thì ion của nó oxi hoá càng yếu. Ví dụ K là kim loại khử rất mạnh, còn ion K^+^ gần như không oxi hoá được chất gì.

> [!vi-du] Ví dụ 2
> Cho các cặp oxi hoá – khử: Pb^2+^/Pb, Mg^2+^/Mg, Ag^+^/Ag, Fe^2+^/Fe, Cu^2+^/Cu, Zn^2+^/Zn. Dựa vào bảng trên:
>
> a) Sắp xếp các **ion** theo chiều tăng dần tính oxi hoá.
>
> b) Kim loại nào có tính khử mạnh nhất?

> [!goi-y] Gợi ý 1
> Tra E° của từng cặp rồi xếp theo E° tăng dần.

> [!goi-y] Gợi ý 2
> E° tăng thì tính oxi hoá của dạng oxi hoá tăng. Kim loại có tính khử mạnh nhất ứng với E° nhỏ nhất.

> [!loi-giai] Lời giải
> E°: Mg (−2,356) < Zn (−0,762) < Fe (−0,44) < Pb (−0,126) < Cu (+0,340) < Ag (+0,799).
>
> a) Tính oxi hoá tăng dần: Mg^2+^ < Zn^2+^ < Fe^2+^ < Pb^2+^ < Cu^2+^ < Ag^+^.
>
> b) Kim loại có tính khử mạnh nhất là **Mg** (E° nhỏ nhất).

## 3. Ý nghĩa của thế điện cực chuẩn

### 3.1. So sánh tính khử, tính oxi hoá. Dãy điện hoá

Giữa hai cặp, cặp có E° **nhỏ hơn** thì kim loại khử **mạnh hơn**, còn ion oxi hoá **yếu hơn**. Ví dụ E°(Cu^2+^/Cu) = +0,340 V nhỏ hơn E°(Ag^+^/Ag) = +0,799 V, nên Cu khử mạnh hơn Ag, còn Ag^+^ oxi hoá mạnh hơn Cu^2+^.

Xếp các cặp M^n+^/M theo chiều E° tăng dần, ta được **dãy điện hoá của kim loại** (SGK tr. 71). Đó chính là thứ tự các cặp M^n+^/M trong bảng ở mục 2.2, đọc từ trên xuống (SGK có thêm Ca ngay sau K), và cũng là thứ tự trên trục ở Hình 1:

- Ion: K^+^, Ca^2+^, Na^+^, Mg^2+^, Al^3+^, Zn^2+^, Fe^2+^, Ni^2+^, Sn^2+^, Pb^2+^, H^+^, Cu^2+^, Ag^+^, Au^3+^ (**tính oxi hoá tăng dần**).
- Kim loại: K, Ca, Na, Mg, Al, Zn, Fe, Ni, Sn, Pb, H~2~, Cu, Ag, Au (**tính khử giảm dần**).

Kim loại **đứng trước** khử được ion của kim loại **đứng sau** (trừ các kim loại quá mạnh phản ứng với nước, xem mục 3.3).

> [!meo] Câu thuộc lòng dãy điện hoá (ngoài SGK)
> Câu quen thuộc: "**K**hi **B**à **C**on **N**ào **M**ay **Á**o **G**iáp **S**ắt **N**hớ **S**ang **P**hố **H**ỏi **C**ửa **H**àng **Á** **P**hi **Â**u", ứng với K, Ba, Ca, Na, Mg, Al, Zn, Fe, Ni, Sn, Pb, H, Cu, Hg, Ag, Pt, Au.
>
> **Cẩn thận ở đoạn cuối:** câu nhớ này xếp Hg trước Ag theo cặp Hg~2~^2+^/Hg (không có trong SGK). Theo bảng SGK, E°(Ag^+^/Ag) = +0,799 V **nhỏ hơn** E°(Hg^2+^/Hg) = +0,853 V, nên với cặp Hg^2+^/Hg thì **Ag đứng trước Hg**. Pt không có trong bảng SGK, nó đứng sau Hg và trước Au. Khi làm bài, luôn dùng số E° đề cho.

### 3.2. Dự đoán chiều phản ứng giữa hai cặp oxi hoá – khử

Hãy xem lại hai phản ứng đã biết:

- Zn + Cu^2+^ → Zn^2+^ + Cu: Zn (cặp có E° = −0,762) khử Cu^2+^ (cặp có E° = +0,340).
- Cu + 2Ag^+^ → Cu^2+^ + 2Ag: Cu (cặp có E° = +0,340) khử Ag^+^ (cặp có E° = +0,799).

Cả hai lần, **kim loại của cặp E° nhỏ** đều phản ứng với **ion của cặp E° lớn**. Đó là quy luật chung:

> [!ghi-nho] Quy tắc chiều phản ứng
> **Chất khử** của cặp có E° **nhỏ hơn** tác dụng với **chất oxi hoá** của cặp có E° **lớn hơn**, tạo ra dạng oxi hoá và dạng khử tương ứng (chất khử yếu hơn và chất oxi hoá yếu hơn).

**Vì sao?** Electron luôn "chảy" từ nơi giữ electron lỏng lẻo (E° nhỏ) sang nơi hút electron mạnh (E° lớn), giống nước chảy từ chỗ cao xuống chỗ thấp. Phản ứng ngược lại (Cu khử Zn^2+^) giống nước tự chảy ngược lên dốc, nên không tự xảy ra.

**Quy tắc α (alpha).** Viết hai cặp cạnh nhau theo chiều E° tăng từ trái sang phải, dạng oxi hoá ở hàng trên, dạng khử ở hàng dưới. Chất khử ở **góc dưới bên trái** phản ứng với chất oxi hoá ở **góc trên bên phải** (đường chéo). Sản phẩm là hai chất ở hai góc còn lại. SGK vẽ đường nối các chất này thành một nét cong giống chữ α, nên gọi là quy tắc α (SGK tr. 72).

![Hình 2. Quy tắc α với hai cặp Cu²⁺/Cu và Ag⁺/Ag: Cu (chất khử mạnh hơn) phản ứng với Ag⁺ (chất oxi hoá mạnh hơn), tạo ra Cu²⁺ và Ag](quy-tac-alpha.svg)

> [!vi-du] Ví dụ 3
> Dựa vào bảng E°, cho biết phản ứng nào sau đây xảy ra ở điều kiện chuẩn. Viết phương trình ion rút gọn nếu có.
>
> a) Thanh Sn nhúng vào dung dịch CuSO~4~.
>
> b) Dây Ag nhúng vào dung dịch Pb(NO~3~)~2~.
>
> c) Bột Al cho vào dung dịch NiSO~4~.

> [!goi-y] Gợi ý 1
> Mỗi câu chỉ cần so hai số: E° của cặp chứa **kim loại** và E° của cặp chứa **ion** trong dung dịch.

> [!goi-y] Gợi ý 2
> Phản ứng xảy ra khi E°(cặp của kim loại) < E°(cặp của ion). Nhớ cân bằng electron ở câu c.

> [!loi-giai] Lời giải
> a) E°(Sn^2+^/Sn) = −0,137 < E°(Cu^2+^/Cu) = +0,340 nên **có phản ứng**:
>
> => Sn + Cu^2+^ → Sn^2+^ + Cu
>
> b) E°(Ag^+^/Ag) = +0,799 > E°(Pb^2+^/Pb) = −0,126. Ag là chất khử yếu hơn Pb, nên Ag **không** khử được Pb^2+^. **Không phản ứng.**
>
> c) E°(Al^3+^/Al) = −1,676 < E°(Ni^2+^/Ni) = −0,257 nên **có phản ứng**. Al nhường 3e, Ni^2+^ nhận 2e:
>
> => 2Al + 3Ni^2+^ → 2Al^3+^ + 3Ni

### 3.3. Ba trường hợp hay gặp

**a) Kim loại tác dụng với dung dịch acid (H^+^).** So kim loại với cặp 2H^+^/H~2~ (E° = 0). Kim loại có **E°(M^n+^/M) < 0** (đứng trước H trong dãy) khử được H^+^ thành H~2~. Ví dụ Fe + 2H^+^ → Fe^2+^ + H~2~. Còn Cu, Ag, Au (E° > 0) không tan trong HCl, H~2~SO~4~ loãng.

**b) Kim loại tác dụng với nước.** Bảng SGK có thêm cặp 2H~2~O/H~2~ + 2OH^−^ với E° = −0,414 V (ở pH = 7). Về lí thuyết, kim loại có E° nhỏ hơn −0,414 V khử được nước. Thực tế, ở nhiệt độ thường chỉ các kim loại rất mạnh như K, Na, Ca, Ba phản ứng mạnh với nước. Mg, Al, Zn, Fe có E° đủ nhỏ, nhưng bề mặt bị một lớp oxide hoặc hydroxide không tan che phủ, nên phản ứng gần như dừng lại ngay.

**c) Phản ứng với cặp Fe^3+^/Fe^2+^ (E° = +0,771 V).** Cặp này nằm **giữa Cu^2+^/Cu và Ag^+^/Ag**, nên:

- Fe^3+^ oxi hoá được Cu và Fe: Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^ (cách hoà tan đồng trong mạch in bằng dung dịch FeCl~3~); Fe + 2Fe^3+^ → 3Fe^2+^.
- Ag^+^ oxi hoá được Fe^2+^: Fe^2+^ + Ag^+^ → Fe^3+^ + Ag.
- Fe^3+^ **không** oxi hoá được Ag. Fe^2+^ **không** khử được Cu^2+^ (Cu^2+^ không oxi hoá được Fe^2+^).

> [!bay]
> - "Cu không tác dụng với dung dịch muối sắt": **sai**. Cu không tác dụng với muối Fe^2+^, nhưng **có** tác dụng với muối Fe^3+^ (tạo Fe^2+^, không tạo ra Fe).
> - Fe^3+^ bị Cu khử chỉ xuống **Fe^2+^**, không xuống Fe, vì E°(Fe^2+^/Fe) = −0,44 < E°(Cu^2+^/Cu).
> - Kim loại rất mạnh (Na, K, Ba…) cho vào dung dịch muối CuSO~4~ thì phản ứng **với nước trước**, tạo hydroxide rồi mới tạo kết tủa Cu(OH)~2~, chứ không đẩy Cu ra khỏi muối.

> [!vi-du] Ví dụ 4
> Có ba ống nghiệm đựng dung dịch FeCl~3~. Cho vào ống (1) một mẩu Cu, ống (2) một dây Ag, ống (3) một đinh Fe (đều dư). Cho E°(Fe^3+^/Fe^2+^) = +0,771 V, E°(Ag^+^/Ag) = +0,799 V và các giá trị E° ở bảng trên. Ống nào có phản ứng? Viết phương trình ion.

> [!goi-y] Gợi ý 1
> Fe^3+^ là dạng oxi hoá của cặp Fe^3+^/Fe^2+^. So E° của cặp này với cặp chứa từng kim loại.

> [!goi-y] Gợi ý 2
> Kim loại nào có E° nhỏ hơn +0,771 V? Nhớ Fe^3+^ chỉ bị khử thành Fe^2+^.

> [!loi-giai] Lời giải
> Ống (1): E°(Cu^2+^/Cu) = +0,340 < +0,771 → **có phản ứng**: Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^.
>
> Ống (2): E°(Ag^+^/Ag) = +0,799 > +0,771 → Ag không khử được Fe^3+^. **Không phản ứng.**
>
> Ống (3): E°(Fe^2+^/Fe) = −0,44 < +0,771 → **có phản ứng**: Fe + 2Fe^3+^ → 3Fe^2+^. Dung dịch chuyển từ vàng nâu sang lục nhạt.

## 4. Pin điện hoá

### 4.1. Phản ứng oxi hoá – khử và dòng điện

Trong phản ứng Zn + Cu^2+^, mỗi nguyên tử Zn chuyển 2 electron sang ion Cu^2+^. Dòng điện chính là dòng electron chuyển động có hướng. Vậy có thể "bắt" các electron này chạy qua một bóng đèn được không?

So sánh hai cách làm (SGK tr. 73):

- **Cách 1:** nhúng thẳng thanh Zn vào dung dịch CuSO~4~. Zn và Cu^2+^ chạm nhau, electron nhảy trực tiếp từ Zn sang Cu^2+^ **ngay trên bề mặt thanh kẽm**. Năng lượng của phản ứng thoát ra dưới dạng **nhiệt**, không có dòng điện dùng được.
- **Cách 2:** để Zn ở một cốc (dung dịch ZnSO~4~), Cu^2+^ ở cốc khác (dung dịch CuSO~4~ có thanh Cu). Hai thanh nối với nhau qua dây dẫn và bóng đèn. Zn và Cu^2+^ không chạm nhau, nên electron **buộc phải đi vòng qua dây dẫn**, đèn sáng.

Như vậy, chỉ cần **tách riêng** quá trình oxi hoá và quá trình khử ra hai nơi rồi nối bằng dây dẫn, năng lượng hoá học sẽ chuyển thành **năng lượng điện**. Thiết bị làm việc này gọi là **pin điện hoá**.

### 4.2. Pin Galvani Zn – Cu

Pin Galvani (đặt theo tên nhà khoa học Italia L. Galvani, 1737 – 1798) gồm **hai điện cực**, mỗi điện cực ứng với một cặp oxi hoá – khử, nối với nhau qua dây dẫn ngoài và một **cầu muối**. Với pin Zn – Cu ở điều kiện chuẩn:

- Cốc 1: thanh Zn nhúng trong dung dịch ZnSO~4~ 1 M.
- Cốc 2: thanh Cu nhúng trong dung dịch CuSO~4~ 1 M.
- Cầu muối: ống thuỷ tinh hình chữ U chứa thạch (agar) tẩm dung dịch muối bão hoà như KNO~3~ hoặc KCl, cắm vào hai cốc.
- Dây dẫn nối hai thanh, có vôn kế đo hiệu điện thế (đo được 1,102 V).

![Hình 3. Pin Galvani Zn – Cu: electron đi qua dây dẫn từ anode Zn sang cathode Cu, các ion trong cầu muối di chuyển để giữ hai dung dịch trung hoà điện](pin-zn-cu.svg)

**Điều gì xảy ra ở mỗi điện cực?**

- **Thanh Zn**: Zn → Zn^2+^ + 2e. Đây là **quá trình oxi hoá**. Điện cực nhường electron ra mạch ngoài, đóng vai **cực âm**, gọi là **anode**.
- **Thanh Cu**: Cu^2+^ + 2e → Cu. Đây là **quá trình khử**. Điện cực nhận electron từ mạch ngoài, đóng vai **cực dương**, gọi là **cathode**.
- **Phản ứng chung của pin**: Zn + Cu^2+^ → Zn^2+^ + Cu. Đây chính là phản ứng khi nhúng Zn vào CuSO~4~, chỉ khác là hai nửa phản ứng diễn ra ở hai nơi.
- **Electron** đi qua **dây dẫn** từ anode (Zn) sang cathode (Cu). Chiều **dòng điện** quy ước thì ngược lại, từ Cu sang Zn.

**Vì sao cần cầu muối?** Khi pin chạy, cốc Zn có thêm ion Zn^2+^ (thừa điện tích dương), còn cốc Cu mất bớt ion Cu^2+^ (thừa ion SO~4~^2−^, tức thừa điện tích âm). Nếu không bù lại, chỉ sau một khoảnh khắc, điện tích dồn lại sẽ chặn đứng dòng electron. Cầu muối giải quyết việc này:

- **Anion** (NO~3~^−^ hoặc Cl^−^) đi từ cầu muối sang **cốc anode** (cốc Zn), trung hoà Zn^2+^ mới sinh ra.
- **Cation** (K^+^) đi sang **cốc cathode** (cốc Cu), bù cho Cu^2+^ đã mất.

Nhờ đó cầu muối vừa **đóng kín mạch điện** (dòng ion bên trong nối tiếp dòng electron bên ngoài), vừa **duy trì sự trung hoà điện** của mỗi dung dịch. Bỏ cầu muối ra thì đèn tắt ngay.

> [!meo] Nhớ anode, cathode trong pin
> - "**A**node – **O**xi hoá" đều bắt đầu bằng nguyên âm. "**C**athode – **K**hử" đều bắt đầu bằng phụ âm.
> - Trong pin: anode là kim loại **mạnh hơn** (E° nhỏ hơn), là **cực âm** và **bị ăn mòn dần**. Cathode là cực dương, là nơi **kim loại bám thêm**.
> - Anion trong cầu muối chạy về **anode**, cation chạy về **cathode** (trái dấu hút nhau với điện tích đang dư ở mỗi cốc).

**Các thay đổi quan sát được khi pin hoạt động:**

| Đại lượng | Bên anode (Zn) | Bên cathode (Cu) |
|---|---|---|
| Khối lượng thanh kim loại | giảm (Zn tan ra) | tăng (Cu bám vào) |
| Nồng độ ion kim loại | [Zn^2+^] tăng | [Cu^2+^] giảm, màu xanh nhạt dần |
| Electron | đi ra mạch ngoài | đi vào từ mạch ngoài |

> [!bay]
> - Electron đi qua **dây dẫn**, **không** đi qua dung dịch hay cầu muối. Trong dung dịch và cầu muối chỉ có **ion** di chuyển.
> - Cầu muối **không** cho ion Cu^2+^ chạy sang cốc Zn. Nếu Cu^2+^ chạm được vào Zn thì lại thành phản ứng trực tiếp, sinh nhiệt chứ không sinh điện.
> - Trong **pin**, anode là cực **âm**. Sang bài điện phân (Bài 16), anode lại là cực **dương**. Điều không đổi: **anode luôn là nơi xảy ra oxi hoá**.

### 4.3. Sức điện động chuẩn của pin

Hiệu điện thế lớn nhất giữa hai điện cực khi pin chưa phát dòng gọi là **sức điện động**. Đo ở điều kiện chuẩn thì gọi là **sức điện động chuẩn**, tính từ hai giá trị E°:

$$E^o_{\text{pin}} = E^o_{\text{cathode}} - E^o_{\text{anode}}$$

Với pin Zn – Cu: E°~pin~ = 0,340 − (−0,762) = **1,102 V**, đúng bằng số đo trên vôn kế.

**Làm sao biết điện cực nào là cathode?** Điện cực có E° **lớn hơn** là cathode (ion của nó oxi hoá mạnh hơn nên được nhận electron). Điện cực có E° **nhỏ hơn** là anode. Vì vậy E°~pin~ luôn là số **dương**: "lớn trừ nhỏ".

**Vì sao không nhân E° với hệ số?** E° là "độ cao" của mỗi cặp, giống độ cao của hai bậc thang. Chênh lệch độ cao không phụ thuộc có bao nhiêu người (bao nhiêu electron) đi xuống. Dù phương trình là Cu + 2Ag^+^ → Cu^2+^ + 2Ag, ta vẫn lấy 0,799 − 0,340 chứ không lấy 2·0,799 − 0,340.

> [!em-co-biet] Đo E° bằng điện cực hydrogen chuẩn
> Muốn biết E° của cặp Cu^2+^/Cu, người ta ghép điện cực đồng chuẩn với điện cực hydrogen chuẩn thành pin. Vôn kế chỉ 0,340 V và đồng là cực dương. Vì E°(2H^+^/H~2~) = 0 nên E°(Cu^2+^/Cu) = 0 + 0,340 = +0,340 V. Với điện cực kẽm, kẽm lại là cực âm, nên E°(Zn^2+^/Zn) mang dấu âm (SGK tr. 74).

> [!vi-du] Ví dụ 5
> Lắp một pin Galvani ở điều kiện chuẩn gồm điện cực Ni (thanh Ni trong dung dịch NiSO~4~ 1 M) và điện cực Cu (thanh Cu trong dung dịch CuSO~4~ 1 M). Cho E°(Ni^2+^/Ni) = −0,257 V, E°(Cu^2+^/Cu) = +0,340 V.
>
> a) Xác định anode, cathode. Viết quá trình xảy ra ở mỗi điện cực và phản ứng chung của pin.
>
> b) Tính sức điện động chuẩn của pin.
>
> c) Electron chuyển động theo chiều nào trong dây dẫn? Khối lượng mỗi thanh thay đổi ra sao?

> [!goi-y] Gợi ý 1
> Điện cực có E° nhỏ hơn là anode (cực âm, nơi oxi hoá).

> [!goi-y] Gợi ý 2
> E°~pin~ = E°~cathode~ − E°~anode~. Electron rời anode, đi đến cathode.

> [!loi-giai] Lời giải
> a) −0,257 < +0,340 nên **Ni là anode** (cực âm), **Cu là cathode** (cực dương).
>
> Anode: Ni → Ni^2+^ + 2e. Cathode: Cu^2+^ + 2e → Cu.
>
> => Ni + Cu^2+^ → Ni^2+^ + Cu
>
> b) E°~pin~ = 0,340 − (−0,257) = **0,597 V**.
>
> c) Electron đi qua dây dẫn **từ thanh Ni sang thanh Cu**. Thanh Ni mỏng dần (khối lượng giảm), thanh Cu dày thêm (khối lượng tăng).

> [!vi-du] Ví dụ 6
> Ghép điện cực chuẩn của kim loại M (hoá trị II) với điện cực hydrogen chuẩn thành pin. Vôn kế chỉ 2,356 V, điện cực hydrogen là cực dương.
>
> a) Tính E°(M^2+^/M) và cho biết M là kim loại nào (dùng bảng E°).
>
> b) Tính sức điện động chuẩn của pin M – Cu.

> [!goi-y] Gợi ý 1
> Điện cực hydrogen là cực dương, tức là cathode. Vậy M là anode.

> [!goi-y] Gợi ý 2
> 2,356 = E°~cathode~ − E°~anode~ = 0 − E°(M^2+^/M).

> [!loi-giai] Lời giải
> a) E°(M^2+^/M) = 0 − 2,356 = **−2,356 V**. Tra bảng: M là **Mg**.
>
> b) Pin Mg – Cu: Mg là anode. E°~pin~ = 0,340 − (−2,356) = **2,696 V**.

### 4.4. Lắp một pin đơn giản: pin chanh

Theo gợi ý của SGK (tr. 75), em có thể tự làm pin tại nhà: cắm một thanh kẽm (hoặc đinh mạ kẽm) và một thanh đồng vào một quả chanh, **không để hai thanh chạm nhau**. Nối thanh Zn với cực âm và thanh Cu với cực dương của vôn kế. Vôn kế thường chỉ khoảng 0,9 – 1 V (số liệu tham khảo, ngoài SGK, tuỳ quả chanh và điện cực).

**Vì sao chanh lại thành pin?**

- Nước chanh chứa acid (citric acid) và các ion, nên đóng vai **dung dịch chất điện li**.
- Zn là kim loại mạnh hơn, bị oxi hoá: Zn → Zn^2+^ + 2e. Thanh Zn là **anode**.
- Trên thanh Cu, chủ yếu ion H^+^ của acid nhận electron: 2H^+^ + 2e → H~2~. Thanh Cu là **cathode**. Vì cathode không phải điện cực Cu^2+^/Cu chuẩn, nên điện áp đo được nhỏ hơn 1,102 V.
- Muốn điện áp lớn hơn, mắc **nối tiếp** nhiều quả chanh (Zn của quả này nối với Cu của quả kia). Điện áp của các pin cộng lại.

> [!ung-dung] Thử với nhiều cặp kim loại
> Thay Zn bằng Al hoặc Fe, giữ nguyên Cu, rồi so số đo trên vôn kế. Nhìn chung, kim loại làm anode có E° càng nhỏ thì điện áp càng lớn. Riêng Al có lớp oxide bảo vệ nên số đo có thể thấp hơn dự đoán. Em sẽ thấy pin chanh chỉ đủ làm sáng một đèn LED nhỏ khi mắc nối tiếp vài quả, vì dòng điện của nó rất yếu.

## 5. Một số loại pin khác

Pin Galvani trong phòng thí nghiệm cồng kềnh, dễ đổ vỡ. Trong đời sống, người ta dùng nhiều nguồn điện gọn và bền hơn. Có hai nhóm chính:

- **Pin sơ cấp**: dùng một lần, hết là bỏ, không sạc lại được. Ví dụ: **pin khô** (pin tiểu AA, AAA, pin cúc áo).
- **Pin thứ cấp (pin sạc)**: khi sạc bằng dòng điện một chiều, các chất phản ứng được **tái tạo**, nên dùng được nhiều lần. Ví dụ: **acquy chì**, **pin lithium-ion**.

### 5.1. Acquy chì

Acquy chì là nguồn điện quen thuộc trên ô tô, xe máy, bộ lưu điện (UPS). Đây là pin thứ cấp: các chất phản ứng được tái tạo khi sạc bằng dòng điện một chiều (SGK tr. 76). Cấu tạo (mở rộng): mỗi ngăn acquy gồm điện cực **Pb** (cực âm) và điện cực **PbO~2~** (cực dương) nhúng trong dung dịch **H~2~SO~4~**.

> [!em-co-biet] Phản ứng trong acquy chì (mở rộng, SGK không yêu cầu)
> Khi phóng điện, cả hai điện cực đều biến thành PbSO~4~:
>
> => Pb + PbO~2~ + 2H~2~SO~4~ → 2PbSO~4~ + 2H~2~O
>
> Pb (số oxi hoá 0) bị oxi hoá, PbO~2~ (số oxi hoá +4) bị khử, cả hai đều về +2. Khi sạc, dòng điện làm phản ứng chạy ngược lại. Mỗi ngăn cho khoảng 2 V, acquy ô tô 12 V gồm 6 ngăn mắc nối tiếp. H~2~SO~4~ bị tiêu thụ khi phóng điện, nên đo khối lượng riêng của dung dịch acid sẽ biết acquy còn nhiều hay ít điện.

- **Ưu điểm:** dễ sản xuất, rẻ, hoạt động ổn định. Sulfuric acid và chì dễ thu hồi để tái chế.
- **Nhược điểm:** nặng, tuổi thọ thấp. Tái chế thủ công ở các làng nghề gây ô nhiễm và **ngộ độc chì**.

### 5.2. Pin nhiên liệu

Pin nhiên liệu là pin điện hoá biến hoá năng của phản ứng giữa **nhiên liệu** và **chất oxi hoá** thành điện năng. Khác pin thường, các chất phản ứng được **bơm vào liên tục** từ bên ngoài, nên pin chạy mãi khi còn được cấp nhiên liệu. Nhiên liệu thường là hydrogen, methane, methanol, ethanol…, chất oxi hoá thường là oxygen (lấy từ không khí).

Pin **hydrogen – oxygen** được quan tâm nhiều nhất. Phản ứng chung giống phản ứng đốt cháy hydrogen, nhưng không có ngọn lửa, năng lượng ra dưới dạng điện, sản phẩm chỉ là **nước**:

=> 2H~2~ + O~2~ → 2H~2~O

Dùng bảng SGK: cặp O~2~/H~2~O (O~2~ + 4H^+^ + 4e ⇌ 2H~2~O) có E° = +1,229 V là cathode, cặp 2H^+^/H~2~ (E° = 0) là anode. Vậy E°~pin~ = 1,229 − 0 = **1,229 V**.

- **Ưu điểm:** hiệu suất chuyển hoá năng lượng cao. Điều chỉnh được cường độ dòng điện bằng cách thay đổi tốc độ cấp nhiên liệu. Ít chất thải và dễ kiểm soát.
- **Nhược điểm:** giá thành cao.

### 5.3. Pin Mặt Trời

Pin Mặt Trời (solar cell) gồm nhiều tấm vật liệu **bán dẫn** (thường là silicon) ghép lại, biến **quang năng** thành điện năng. Pin Mặt Trời **không** hoạt động dựa trên phản ứng oxi hoá – khử, nên khác hẳn các pin điện hoá ở trên.

- **Ưu điểm:** năng lượng sạch, không thải khí gây ô nhiễm. Tận dụng nguồn năng lượng gần như vô tận của Mặt Trời.
- **Nhược điểm:** sản xuất phức tạp, giá cao. Phụ thuộc thời tiết, cần nhiều nắng. Tấm pin hết hạn có thể gây ô nhiễm nếu không xử lí đúng cách.

### 5.4. Pin lithium-ion và pin khô

**Pin lithium-ion** là pin sạc trong điện thoại, laptop, xe điện. Lithium có E° rất âm (−3,040 V, nhỏ nhất trong bảng) và rất nhẹ, nên pin lithium-ion cho điện áp cao (khoảng 3,6 – 3,7 V mỗi pin, số liệu ngoài SGK) và dự trữ được nhiều năng lượng trên mỗi kilogram.

- **Ưu điểm:** nhẹ, gọn, bền, **mật độ năng lượng cao**, sạc nhanh và sạc lúc nào cũng được.
- **Nhược điểm:** đắt, dễ hỏng khi quá nóng, có nguy cơ **cháy nổ** (pin phồng, va đập, sạc sai cách).

**Pin khô** là pin sơ cấp dùng cho điều khiển, đồ chơi, đồng hồ. Ưu điểm: năng lượng ổn định, rẻ, gọn, dễ mang theo. Nhược điểm: điện áp thấp (thường khoảng 1,5 V, số liệu ngoài SGK), không sạc được, có thể gây ô nhiễm môi trường nếu vứt bừa bãi.

| Loại pin | Sơ cấp hay sạc? | Dựa trên phản ứng oxi hoá – khử? | Ghi nhớ nhanh |
|---|---|---|---|
| Pin khô | sơ cấp | có | rẻ, ổn định, điện áp thấp |
| Acquy chì | sạc | có | rẻ, nặng, nguy cơ ngộ độc chì |
| Pin lithium-ion | sạc | có | nhẹ, mật độ năng lượng cao, nguy cơ cháy nổ |
| Pin nhiên liệu | cấp nhiên liệu liên tục | có | hiệu suất cao, ít thải, giá cao |
| Pin Mặt Trời | — | **không** (quang năng → điện năng) | sạch, phụ thuộc thời tiết |

> [!ung-dung] Pin hết hạn thì bỏ đi đâu?
> Pin và acquy chứa kim loại nặng, chất điện li ăn mòn và hợp chất dễ cháy. **Không** vứt chung rác sinh hoạt, không đốt, không đập vỡ. Hãy gom riêng vào hộp kín, mang đến điểm thu gom pin cũ (nhiều siêu thị, trường học có thùng thu gom). Acquy cũ nên bán lại cho đại lý có giấy phép tái chế. Pin lithium-ion bị phồng cần cách li khỏi vật dễ cháy.

## Dạng bài thi hay gặp

### Dạng 1. Dự đoán phản ứng, so sánh tính khử – tính oxi hoá theo bảng E°

**Nhận biết:** đề cho bảng E° (hoặc dãy điện hoá), hỏi: phản ứng nào xảy ra, chất nào khử/oxi hoá mạnh nhất, sắp xếp theo thứ tự, hoặc đếm số phản ứng xảy ra.

**Phương pháp:**

1. Với mỗi phản ứng, xác định **chất khử** (vế trái, dạng khử của một cặp) và **chất oxi hoá** (vế trái, dạng oxi hoá của cặp kia).
2. Tra E° hai cặp. Phản ứng xảy ra khi E°(cặp chứa chất khử) **<** E°(cặp chứa chất oxi hoá).
3. Cẩn thận với cặp Fe^3+^/Fe^2+^: Fe^2+^ vừa là dạng khử (của cặp Fe^3+^/Fe^2+^), vừa là dạng oxi hoá (của cặp Fe^2+^/Fe).

> [!vi-du] Ví dụ 7
> Cho E° (V): Fe^2+^/Fe −0,44; Pb^2+^/Pb −0,126; 2H^+^/H~2~ 0; Cu^2+^/Cu +0,340; Fe^3+^/Fe^2+^ +0,771; Ag^+^/Ag +0,799. Xét các phản ứng ở điều kiện chuẩn:
>
> (1) Fe + Cu^2+^ → Fe^2+^ + Cu
>
> (2) Cu + Fe^2+^ → Cu^2+^ + Fe
>
> (3) Cu + 2Fe^3+^ → Cu^2+^ + 2Fe^2+^
>
> (4) 2Ag + Cu^2+^ → 2Ag^+^ + Cu
>
> (5) Fe^2+^ + Ag^+^ → Fe^3+^ + Ag
>
> (6) Pb + 2H^+^ → Pb^2+^ + H~2~
>
> Có bao nhiêu phản ứng xảy ra được?

> [!goi-y] Gợi ý 1
> Ở mỗi phản ứng, gạch chân chất khử và chất oxi hoá ở vế trái, rồi tìm cặp của mỗi chất.

> [!goi-y] Gợi ý 2
> Ở phản ứng (5), Fe^2+^ là chất khử, thuộc cặp Fe^3+^/Fe^2+^ (E° = +0,771), không phải cặp Fe^2+^/Fe.

> [!loi-giai] Lời giải
> (1) −0,44 < +0,340 → xảy ra.
>
> (2) Chất khử Cu (+0,340) > chất oxi hoá Fe^2+^ (−0,44) → không xảy ra.
>
> (3) +0,340 < +0,771 → xảy ra.
>
> (4) Chất khử Ag (+0,799) > Cu^2+^ (+0,340) → không xảy ra.
>
> (5) Chất khử Fe^2+^ (+0,771) < Ag^+^ (+0,799) → xảy ra.
>
> (6) −0,126 < 0 → xảy ra.
>
> Có **4** phản ứng xảy ra: (1), (3), (5), (6).

> [!bay]
> - Phản ứng (2) và (4) là chiều **ngược** của phản ứng tự xảy ra. Chiều thuận xảy ra thì chiều nghịch không tự xảy ra.
> - Đừng lấy nhầm cặp Fe^2+^/Fe (−0,44) khi Fe^2+^ đóng vai chất khử.

### Dạng 2. Tính sức điện động, xác định anode – cathode, suy ngược E°

**Nhận biết:** đề cho hai điện cực (hoặc phản ứng trong pin) và bảng E°, hỏi E°~pin~, cực âm/cực dương, chiều electron. Dạng khó hơn: cho E°~pin~ của một số pin, yêu cầu tìm E° chưa biết hoặc E°~pin~ của pin khác.

**Phương pháp:**

1. Cặp có E° nhỏ hơn → **anode** (cực âm, oxi hoá). Cặp có E° lớn hơn → **cathode** (cực dương, khử).
2. E°~pin~ = E°~cathode~ − E°~anode~ (> 0). **Không** nhân E° với hệ số phương trình.
3. Suy ngược: biết E°~pin~ và E° của một điện cực thì E°~anode~ = E°~cathode~ − E°~pin~, hoặc E°~cathode~ = E°~anode~ + E°~pin~. Phải biết điện cực đã biết là anode hay cathode.
4. Với ba điện cực X, Y, Z: E°~pin~(X–Z) = E°~pin~(X–Y) + E°~pin~(Y–Z) nếu E°(X) < E°(Y) < E°(Z).

> [!vi-du] Ví dụ 8
> Ở điều kiện chuẩn, pin X – Cu có sức điện động 0,780 V và Cu là cực dương. Pin Cu – Y có sức điện động 0,513 V và Cu là cực âm. Biết E°(Cu^2+^/Cu) = +0,340 V, X và Y đều là kim loại hoá trị II.
>
> a) Tính E°(X^2+^/X), E°(Y^2+^/Y). Dùng bảng E° để xác định X, Y.
>
> b) Tính sức điện động chuẩn của pin X – Y và cho biết cực âm của pin này.

> [!goi-y] Gợi ý 1
> Pin X – Cu: Cu là cathode nên 0,780 = 0,340 − E°(X^2+^/X). Pin Cu – Y: Cu là anode nên 0,513 = E°(Y^2+^/Y) − 0,340.

> [!goi-y] Gợi ý 2
> Cu nằm giữa X và Y trên trục E°, nên E°~pin~(X–Y) = 0,780 + 0,513.

> [!loi-giai] Lời giải
> a) E°(X^2+^/X) = 0,340 − 0,780 = **−0,44 V** → X là **Fe**.
>
> E°(Y^2+^/Y) = 0,340 + 0,513 = **+0,853 V** → Y là **Hg**.
>
> b) E°~pin~(Fe – Hg) = 0,853 − (−0,44) = **1,293 V** (đúng bằng 0,780 + 0,513). Cực âm (anode) là **Fe**, vì E° của Fe nhỏ hơn.

> [!bay]
> - Lấy E°~anode~ − E°~cathode~ ra số âm. Sức điện động chuẩn luôn dương, nếu ra âm là em đã đảo hai cực.
> - Quên dấu trừ của E° âm: 0,340 − (−0,44) = 0,780, không phải 0,340 − 0,44 = −0,100.
> - Nhân E°(Ag^+^/Ag) với 2 vì phương trình có 2Ag^+^ là sai.

### Dạng 3. Đúng/Sai về pin đang hoạt động, biến đổi khối lượng điện cực

**Nhận biết:** đề mô tả một pin (thường kèm hình), cho 4 ý về anode/cathode, chiều electron, vai trò cầu muối, thay đổi khối lượng và nồng độ. Ý cuối thường có tính toán khối lượng.

**Phương pháp:**

1. Xác định anode, cathode, viết hai bán phản ứng và phản ứng chung.
2. Electron: anode → dây dẫn → cathode. Anion trong cầu muối → cốc anode, cation → cốc cathode.
3. Tính toán: số mol electron qua dây dẫn là cầu nối giữa hai điện cực. n~e~ = n(kim loại tan ở anode) × hoá trị = n(kim loại bám ở cathode) × hoá trị.

> [!vi-du] Ví dụ 9 (Đúng/Sai)
> Một pin Zn – Cu (thanh Zn trong dung dịch ZnSO~4~, thanh Cu trong dung dịch CuSO~4~, cầu muối KNO~3~) làm sáng một bóng đèn nhỏ. Sau một thời gian, khối lượng thanh Zn giảm 1,95 g. Xét các phát biểu:
>
> a) Thanh Zn là cực âm, tại đó xảy ra quá trình khử.
>
> b) Trong cầu muối, ion NO~3~^−^ di chuyển về phía cốc đựng ZnSO~4~.
>
> c) Số mol electron đã đi qua dây dẫn là 0,03 mol.
>
> d) Khối lượng thanh Cu tăng 1,92 g.

> [!goi-y] Gợi ý 1
> Cực âm của pin là anode. Ở anode xảy ra quá trình gì?

> [!goi-y] Gợi ý 2
> n(Zn) = 1,95 : 65. Mỗi Zn nhường 2 electron, mỗi Cu^2+^ nhận 2 electron.

> [!loi-giai] Lời giải
> a) **Sai.** Zn là cực âm (anode) nhưng tại đó xảy ra **oxi hoá**: Zn → Zn^2+^ + 2e.
>
> b) **Đúng.** Cốc ZnSO~4~ có thêm Zn^2+^ (dư điện tích dương), nên anion NO~3~^−^ đi về phía đó.
>
> c) **Sai.** n(Zn) = 1,95 : 65 = 0,03 mol → n~e~ = 2 · 0,03 = **0,06 mol**.
>
> d) **Đúng.** n(Cu) = n~e~ : 2 = 0,03 mol → m(Cu) = 0,03 · 64 = **1,92 g**.

> [!bay]
> - Khối lượng anode giảm và khối lượng cathode tăng **không bằng nhau** (65 so với 64 cho mỗi mol), vì hai kim loại có nguyên tử khối khác nhau.
> - Nhầm số mol kim loại với số mol electron. Với kim loại hoá trị II, n~e~ gấp đôi n(kim loại). Với Al (hoá trị III), n~e~ gấp ba.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Cặp oxi hoá – khử | M^n+^/M: dạng oxi hoá trước, dạng khử sau; M^n+^ + ne ⇌ M |
| Điều kiện chuẩn | [ion] = 1 M, 25 °C; E°(2H^+^/H~2~) = 0 V (quy ước) |
| Ý nghĩa E° | E° nhỏ: kim loại khử mạnh, ion oxi hoá yếu; E° lớn: ion oxi hoá mạnh, kim loại khử yếu |
| Chiều phản ứng | Chất khử (cặp E° nhỏ) + chất oxi hoá (cặp E° lớn) → dạng oxi hoá + dạng khử tương ứng (quy tắc α) |
| Kim loại + H^+^ | Chỉ kim loại có E° < 0 giải phóng H~2~ |
| Cặp Fe^3+^/Fe^2+^ (+0,771) | Fe^3+^ oxi hoá được Fe, Cu; Ag^+^ oxi hoá được Fe^2+^; Fe^3+^ không oxi hoá được Ag |
| Anode (pin) | cực âm, oxi hoá, kim loại tan ra, khối lượng giảm |
| Cathode (pin) | cực dương, khử, kim loại bám vào, khối lượng tăng |
| Electron | đi qua dây dẫn từ anode sang cathode |
| Cầu muối | đóng kín mạch, giữ trung hoà điện; anion → cốc anode, cation → cốc cathode |
| Sức điện động chuẩn | E°~pin~ = E°~cathode~ − E°~anode~ > 0, không nhân hệ số |
| Pin Zn – Cu | Zn + Cu^2+^ → Zn^2+^ + Cu; E°~pin~ = 1,102 V |
| Pin sạc / sơ cấp | Acquy chì, lithium-ion là pin sạc; pin khô là sơ cấp |
| Pin nhiên liệu H~2~ – O~2~ | 2H~2~ + O~2~ → 2H~2~O; E°~pin~ = 1,229 V; sản phẩm chỉ có nước |
| Pin Mặt Trời | quang năng → điện năng, **không** phải pin điện hoá |
