---
title: Ester – Lipid
thoi-gian: 50 phút
muc-tieu:
  - Nêu được khái niệm ester, đặc điểm cấu tạo nhóm –COO–; nêu được khái niệm lipid, chất béo, acid béo.
  - Viết được công thức cấu tạo và gọi tên các ester đơn giản (tối đa 5 nguyên tử C) và ester thường gặp; đếm được số đồng phân ester.
  - Giải thích được vì sao ester có nhiệt độ sôi thấp; trình bày được phản ứng thuỷ phân ester trong môi trường acid và môi trường base (xà phòng hoá).
  - Trình bày được cách điều chế ester bằng phản ứng ester hoá và ứng dụng của một số ester; tính được hiệu suất ester hoá.
  - Trình bày được tính chất vật lí, phản ứng hydrogen hoá chất béo lỏng, phản ứng oxi hoá chất béo bởi oxygen không khí; ứng dụng của chất béo và acid béo omega-3, omega-6.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Ester** = carboxylic acid đã thay –OH trong nhóm –COOH bằng –OR'. Ester đơn chức: **RCOOR'**. Tên = **tên gốc R'** + **tên gốc acid (đuôi -ate)**, ví dụ CH~3~COOC~2~H~5~ là ethyl acetate.
> 2. Ester **không tạo liên kết hydrogen** giữa các phân tử, nên sôi thấp hơn alcohol và acid có cùng phân tử khối; ester nhẹ hơn nước, ít tan trong nước, nhiều chất có mùi thơm.
> 3. Thuỷ phân trong **acid** là phản ứng **thuận nghịch**. Thuỷ phân trong **base** là phản ứng **một chiều**, còn gọi là **xà phòng hoá**: RCOOR' + NaOH → RCOONa + R'OH.
> 4. Điều chế ester bằng **phản ứng ester hoá**: RCOOH + R'OH ⇌ RCOOR' + H~2~O (H~2~SO~4~ đặc, t°). Tính hiệu suất theo chất **thiếu**.
> 5. **Chất béo** = triester của glycerol với acid béo (triglyceride). Gốc no nhiều → rắn (mỡ). Gốc không no nhiều → lỏng (dầu). Chất béo bị thuỷ phân, xà phòng hoá; dầu lỏng + H~2~ → mỡ rắn; gốc không no bị O~2~ oxi hoá → dầu mỡ bị ôi.

## 1. Khái niệm ester

### 1.1. Ester là gì?

Em ngửi mùi chuối chín, mùi dứa, mùi hoa nhài… phần lớn mùi thơm đó đến từ một nhóm hợp chất gọi là **ester**. Sáp ong cũng là một ester, chỉ có điều phân tử rất lớn nên nó ở thể rắn. Xem các ví dụ ở SGK tr. 6: cả ba chất đều chứa chung một "khối" –COO– nằm **giữa** hai gốc hydrocarbon.

> [!nen-tang] Carboxylic acid và alcohol (lớp 11)
> - Carboxylic acid có nhóm **carboxyl –COOH**, ví dụ CH~3~COOH (acetic acid).
> - Alcohol có nhóm **–OH** gắn vào carbon no, ví dụ C~2~H~5~OH (ethanol).
> - Giữa các phân tử alcohol, và giữa các phân tử acid, có **liên kết hydrogen** (H của nhóm –OH hút O của phân tử bên cạnh). Đây là lí do chúng sôi khá cao.

**Định nghĩa.** Lấy một carboxylic acid R–COOH, bỏ nguyên tử H của nhóm –OH và thay vào đó một gốc hydrocarbon R'. Ta được **ester** R–COO–R'. Nói cách khác, nhóm **–OH** trong –COOH đã được thay bằng nhóm **–OR'**.

=> R–COOH (carboxylic acid)   ⟹   R–COO–R' (ester)

**Ester đơn chức** (chỉ có một nhóm –COO–) có công thức chung **RCOOR'**:

- **R** là gốc hydrocarbon **hoặc H** (khi R = H ta có ester của formic acid, ví dụ HCOOCH~3~).
- **R'** là gốc hydrocarbon, **không thể là H** (nếu R' = H thì chất đó chính là acid RCOOH).

Ví dụ: HCOOC~2~H~5~, CH~3~COOCH~3~, CH~2~=CHCOOCH~3~, CH~3~COOC~6~H~5~, C~6~H~5~COOC~2~H~5~.

> [!meo] Ester no, đơn chức, mạch hở (bổ sung, hay dùng khi giải bài)
> Khi R và R' đều là gốc alkyl (no, mạch hở), công thức phân tử chung là **C~n~H~2n~O~2~** (n ≥ 2). Ví dụ C~2~H~4~O~2~ (HCOOCH~3~), C~3~H~6~O~2~, C~4~H~8~O~2~… Lưu ý: carboxylic acid no, đơn chức cũng có công thức C~n~H~2n~O~2~. Nên "C~4~H~8~O~2~" có thể là ester hoặc acid.

> [!vi-du] Ví dụ 1
> Cho các chất: (1) CH~3~COOH; (2) HCOOCH~3~; (3) CH~3~OCH~3~; (4) CH~3~COOC~6~H~5~; (5) CH~3~CHO; (6) CH~2~=CHCOOCH~3~. Những chất nào là ester?

> [!goi-y] Gợi ý 1
> Tìm nhóm –COO– nằm **giữa** hai phần của phân tử, với phía O nối vào một gốc hydrocarbon (không phải H).

> [!goi-y] Gợi ý 2
> CH~3~COOH có nhóm –COO– nhưng phía O nối với H. CH~3~OCH~3~ chỉ có –O– (ether), không có C=O.

> [!loi-giai] Lời giải
> - (1) là carboxylic acid (–COO**H**). (3) là ether. (5) là aldehyde.
> - (2), (4), (6) đều có dạng RCOOR': HCOO–CH~3~ (R = H), CH~3~COO–C~6~H~5~ (R' là gốc phenyl), CH~2~=CHCOO–CH~3~ (R là gốc không no).
>
> Vậy có **3 ester**: (2), (4), (6).

## 2. Danh pháp

### 2.1. Quy tắc gọi tên

Tên của ester đơn chức gồm **hai từ** (SGK tr. 7):

**Tên ester = tên gốc R' + tên gốc carboxylic acid (đổi đuôi "-ic acid" thành "-ate")**

![Hình 1. Cách gọi tên ester đơn chức: phần từ alcohol (gốc R') đọc trước, phần từ acid (đuôi -ate) đọc sau](danh-phap.svg)

**Vì sao đọc R' trước?** Có thể hình dung ester như một "muối" mà gốc R' đứng vào chỗ của kim loại. Muối CH~3~COONa đọc là sodium acetate (kim loại trước, gốc acid sau). Tương tự, CH~3~COOC~2~H~5~ đọc là **ethyl acetate**.

Bảng tên các gốc thường gặp (tên thông thường dùng song song với tên thay thế). Hai cột bên trái là phần acid, hai cột bên phải là gốc R'; hai nửa bảng tra **độc lập**, không ghép theo hàng:

| Acid | Gốc acid trong ester | Gốc R' | Công thức R' |
|---|---|---|---|
| HCOOH formic acid (methanoic) | formate (methanoate) | methyl | CH~3~– |
| CH~3~COOH acetic acid (ethanoic) | acetate (ethanoate) | ethyl | C~2~H~5~– |
| C~2~H~5~COOH propionic acid (propanoic) | propionate (propanoate) | propyl | CH~3~CH~2~CH~2~– |
| CH~3~CH~2~CH~2~COOH butyric acid (butanoic) | butyrate (butanoate) | isopropyl | (CH~3~)~2~CH– |
| CH~2~=CHCOOH acrylic acid (propenoic) | acrylate (propenoate) | vinyl | CH~2~=CH– |
| C~6~H~5~COOH benzoic acid | benzoate | phenyl / benzyl | C~6~H~5~– / C~6~H~5~CH~2~– |

> [!bay]
> - Đọc ngược thứ tự là lỗi rất hay gặp. CH~3~COOC~2~H~5~ là **ethyl acetate**, còn C~2~H~5~COOCH~3~ là **methyl propionate**. Hai chất là đồng phân (cùng C~4~H~8~O~2~) nhưng khác nhau.
> - Muốn nhận ra phần nào là acid, hãy tìm nguyên tử C của nhóm C=O: gốc **gắn với C=O** (kể cả C đó) thuộc phần acid; gốc **gắn với O đơn** là R'.
> - **Phenyl** C~6~H~5~– gắn thẳng vào O. **Benzyl** C~6~H~5~CH~2~– gắn vào O qua nhóm CH~2~. CH~3~COOC~6~H~5~ là phenyl acetate, còn CH~3~COOCH~2~C~6~H~5~ là benzyl acetate (mùi hoa nhài).

> [!vi-du] Ví dụ 2
> a) Gọi tên các ester: HCOOC~2~H~5~; C~2~H~5~COOCH~3~; CH~3~COOCH=CH~2~.
>
> b) Viết công thức cấu tạo của: butyl acetate; phenyl benzoate.

> [!goi-y] Gợi ý 1
> Tách mỗi công thức tại vị trí –COO–: phần trước (kể cả C của C=O) là gốc acid, phần sau O là R'.

> [!goi-y] Gợi ý 2
> Với câu b, từ đầu tiên cho R', từ thứ hai cho gốc acid. Viết gốc acid trước rồi nối với R' qua –COO–.

> [!loi-giai] Lời giải
> a)
> - HCOO|C~2~H~5~: ethyl formate (ethyl methanoate).
> - C~2~H~5~COO|CH~3~: methyl propionate (methyl propanoate).
> - CH~3~COO|CH=CH~2~: vinyl acetate (vinyl ethanoate).
>
> b)
> - Butyl acetate: CH~3~COOCH~2~CH~2~CH~2~CH~3~.
> - Phenyl benzoate: C~6~H~5~COOC~6~H~5~.

### 2.2. Đồng phân ester

Với một công thức C~n~H~2n~O~2~, ta có thể "chia" số nguyên tử C giữa hai phía của nhóm –COO–. Phía acid (HCOO–, CH~3~COO–, …) có thể có 0 C ngoài nhóm COO (khi R = H). Phía R' có ít nhất 1 C. Với mỗi cách chia, ta lại xét các đồng phân mạch của từng gốc.

**Cách đếm theo 3 bước:**

1. Trừ 1 nguyên tử C của nhóm –COO–, còn lại (n − 1) nguyên tử C để chia cho R và R'.
2. Lần lượt cho R = H, CH~3~, C~2~H~5~, … (R' nhận phần còn lại, R' ≥ 1 C).
3. Đếm số đồng phân của mỗi gốc: C~1~, C~2~ có 1 gốc; C~3~ có 2 gốc (propyl, isopropyl); C~4~ có 4 gốc (butyl, isobutyl, sec-butyl, tert-butyl).

Ví dụ với C~3~H~6~O~2~: còn 2 C để chia → (R = H, R' = C~2~H~5~): HCOOC~2~H~5~; (R = CH~3~, R' = CH~3~): CH~3~COOCH~3~. Có **2** ester.

> [!vi-du] Ví dụ 3
> Có bao nhiêu ester có công thức phân tử C~5~H~10~O~2~? Viết công thức cấu tạo và gọi tên.

> [!goi-y] Gợi ý 1
> Còn 4 nguyên tử C để chia: (0 + 4), (1 + 3), (2 + 2), (3 + 1), trong đó số đầu là số C của R.

> [!goi-y] Gợi ý 2
> Gốc C~4~ có 4 cấu tạo, gốc C~3~ có 2 cấu tạo. Đừng quên R cũng có thể là gốc C~3~ phân nhánh.

> [!loi-giai] Lời giải
> | R (số C) | R' | Các ester | Số |
> |---|---|---|---|
> | H (0) | C~4~H~9~ | HCOOCH~2~CH~2~CH~2~CH~3~; HCOOCH~2~CH(CH~3~)~2~; HCOOCH(CH~3~)CH~2~CH~3~; HCOOC(CH~3~)~3~ | 4 |
> | CH~3~ (1) | C~3~H~7~ | CH~3~COOCH~2~CH~2~CH~3~ (propyl acetate); CH~3~COOCH(CH~3~)~2~ (isopropyl acetate) | 2 |
> | C~2~H~5~ (2) | C~2~H~5~ | C~2~H~5~COOC~2~H~5~ (ethyl propionate) | 1 |
> | C~3~H~7~ (3) | CH~3~ | CH~3~CH~2~CH~2~COOCH~3~ (methyl butyrate); (CH~3~)~2~CHCOOCH~3~ (methyl isobutyrate) | 2 |
>
> Tổng cộng: 4 + 2 + 1 + 2 = **9 ester**. Bốn ester của formic acid lần lượt là butyl, isobutyl, sec-butyl, tert-butyl formate.

> [!meo] Nhớ nhanh số đồng phân ester no, đơn chức, mạch hở
> | Công thức | C~2~H~4~O~2~ | C~3~H~6~O~2~ | C~4~H~8~O~2~ | C~5~H~10~O~2~ |
> |---|---|---|---|---|
> | Số ester | 1 | 2 | 4 | 9 |
>
> Nếu đề hỏi "số đồng phân **đơn chức** tác dụng với NaOH", phải cộng thêm các **acid**: C~3~H~6~O~2~ có 1 acid, C~4~H~8~O~2~ có 2 acid.

## 3. Tính chất vật lí

Xét ba chất có cùng phân tử khối 88: ethyl acetate CH~3~COOC~2~H~5~ (ester), pentan-1-ol C~5~H~11~OH (alcohol) và butanoic acid C~3~H~7~COOH (acid). Nhiệt độ sôi của chúng lần lượt khoảng **77 °C**, **138 °C** và **164 °C**. Bảng số liệu tương tự ở SGK tr. 7 (ba chất có M = 60) cho cùng một kết luận: **ester sôi thấp nhất**.

**Vì sao?** Muốn sôi, các phân tử phải tách khỏi nhau. Alcohol và acid có nguyên tử H gắn trên O, nên giữa các phân tử có **liên kết hydrogen** khá bền. Ester không còn nguyên tử H nào gắn trên O (vị trí đó đã bị R' chiếm). Vì vậy giữa các phân tử ester **không có liên kết hydrogen**, chỉ có lực hút yếu, và ester bay hơi dễ hơn nhiều. Acid sôi cao hơn alcohol vì hai phân tử acid có thể liên kết hydrogen với nhau ở **hai chỗ** cùng lúc (tạo cặp đôi rất bền).

> [!meo] Thứ tự nhiệt độ sôi (khi phân tử khối xấp xỉ nhau)
> **Ester < alcohol < carboxylic acid**

**Các tính chất vật lí khác:**

- Ester có phân tử khối nhỏ và trung bình thường là **chất lỏng** ở nhiệt độ phòng. Ester có phân tử khối lớn (như sáp ong, chất béo no) thường là **chất rắn**.
- Ester thường **nhẹ hơn nước** và **ít tan trong nước**. Khi đổ ethyl acetate vào nước, ta thấy chất lỏng tách thành hai lớp và lớp ester nằm trên.
- Nhiều ester có **mùi thơm** của hoa, quả chín: isoamyl acetate (mùi chuối chín), ethyl butyrate (mùi dứa), benzyl acetate (mùi hoa nhài), propyl acetate (mùi lê).

> [!vi-du] Ví dụ 4
> Ba chất propyl acetate, hexan-1-ol và pentanoic acid có cùng phân tử khối (102). Các nhiệt độ sôi (không theo thứ tự) là 102 °C, 157 °C, 186 °C. Hãy gán nhiệt độ sôi cho từng chất và giải thích.

> [!goi-y] Gợi ý 1
> Chất nào không có liên kết hydrogen giữa các phân tử?

> [!goi-y] Gợi ý 2
> Giữa alcohol và acid, chất nào tạo liên kết hydrogen bền hơn?

> [!loi-giai] Lời giải
> - Propyl acetate (ester, không có liên kết hydrogen): **102 °C**.
> - Hexan-1-ol (alcohol, có liên kết hydrogen): **157 °C**.
> - Pentanoic acid (acid, liên kết hydrogen bền hơn alcohol): **186 °C**.

## 4. Tính chất hoá học

Phản ứng quan trọng nhất của ester là **phản ứng thuỷ phân**: nước (hoặc ion OH^−^) cắt liên kết giữa C=O và O–R', trả ester về lại "phần acid" và "phần alcohol". Sản phẩm phụ thuộc vào môi trường.

### 4.1. Thí nghiệm thuỷ phân ethyl acetate

Tóm tắt thí nghiệm (SGK tr. 8): lấy hai ống nghiệm, mỗi ống chứa khoảng 1 mL ethyl acetate. Ống (1) thêm dung dịch H~2~SO~4~ loãng, ống (2) thêm dung dịch NaOH đặc. Lúc đầu cả hai ống đều **tách thành hai lớp**. Ngâm hai ống trong nước nóng 60–70 °C một lúc thì thấy:

- Ống (1): lớp chất lỏng phía trên **mỏng đi** nhưng **vẫn còn**.
- Ống (2): chất lỏng trở thành **đồng nhất**.

**Giải thích:**

- Lúc đầu tách lớp vì ethyl acetate ít tan trong nước. Ester nhẹ hơn nước nên là **lớp trên**.
- Ống (1): một phần ester bị thuỷ phân thành acetic acid và ethanol (đều tan trong nước) nên lớp ester mỏng đi. Nhưng phản ứng **thuận nghịch**, không thể hết ester, nên lớp trên vẫn còn.
- Ống (2): ester bị thuỷ phân **hoàn toàn** thành sodium acetate và ethanol, đều tan tốt trong nước, nên hỗn hợp đồng nhất. Phản ứng trong môi trường kiềm xảy ra **tốt hơn**.

### 4.2. Thuỷ phân trong môi trường acid

Ester bị thuỷ phân khi đun với nước có mặt acid (H^+^) làm xúc tác, tạo ra carboxylic acid và alcohol:

=> CH~3~COOC~2~H~5~ + H~2~O ⇌ CH~3~COOH + C~2~H~5~OH    (H^+^, t°)

**Vì sao thuận nghịch?** Acid và alcohol vừa sinh ra lại có thể phản ứng với nhau để tạo lại ester và nước (đó chính là phản ứng ester hoá ở mục 5). Hai chiều cùng xảy ra nên cuối cùng hỗn hợp đạt **cân bằng**, luôn còn lại cả ester, nước, acid và alcohol.

### 4.3. Thuỷ phân trong môi trường base (phản ứng xà phòng hoá)

Đun ester với dung dịch NaOH (hoặc KOH), sản phẩm là **muối carboxylate** và **alcohol**:

=> RCOOR' + NaOH → RCOONa + R'OH    (t°)

=> CH~3~COOC~2~H~5~ + NaOH → CH~3~COONa + C~2~H~5~OH    (t°)

**Vì sao một chiều?** Phần acid vừa tách ra lập tức bị NaOH trung hoà thành ion carboxylate RCOO^−^. Ion này **không** phản ứng được với alcohol để tạo lại ester. Không có chiều nghịch nên phản ứng đi đến cùng. Phản ứng này được dùng để nấu xà phòng từ chất béo (mục 9), nên được gọi là **phản ứng xà phòng hoá**.

![Hình 2. Ester hoá (chiều thuận) và thuỷ phân ester trong acid (chiều nghịch) là hai chiều của cùng một cân bằng; trong NaOH, phản ứng chỉ xảy ra một chiều](ester-hoa.svg)

> [!meo] So sánh nhanh
> | | Môi trường acid | Môi trường base |
> |---|---|---|
> | Vai trò của H^+^ / OH^−^ | H^+^ là **xúc tác** | OH^−^ là **chất phản ứng** (bị tiêu hao) |
> | Sản phẩm | carboxylic acid + alcohol | **muối** carboxylate + alcohol |
> | Chiều phản ứng | **thuận nghịch** | **một chiều** |
>
> Điểm giống: đều cắt liên kết C(=O)–O, đều cần đun nóng, đều cho alcohol R'OH (với ester thông thường).

> [!vi-du] Ví dụ 5
> Đun nóng 8,8 g ethyl acetate với 150 mL dung dịch NaOH 1 M đến khi phản ứng hoàn toàn. Cô cạn dung dịch sau phản ứng thu được m gam chất rắn khan. Tính m.

> [!goi-y] Gợi ý 1
> Tính số mol ester và số mol NaOH. Chất nào dư?

> [!goi-y] Gợi ý 2
> Khi cô cạn, ethanol và nước bay hơi. Chất rắn gồm muối **và cả NaOH còn dư**.

> [!loi-giai] Lời giải
> n(CH~3~COOC~2~H~5~) = 8,8 : 88 = 0,1 mol; n(NaOH) = 0,15 · 1 = 0,15 mol.
>
> CH~3~COOC~2~H~5~ + NaOH → CH~3~COONa + C~2~H~5~OH
>
> NaOH dư 0,15 − 0,1 = 0,05 mol. Chất rắn gồm 0,1 mol CH~3~COONa và 0,05 mol NaOH:
>
> m = 0,1 · 82 + 0,05 · 40 = 8,2 + 2 = **10,2 g**.

### 4.4. Một số trường hợp đặc biệt (mở rộng, hay gặp trong đề)

SGK nói thuỷ phân trong base "thường" cho muối và alcohol. Chữ "thường" có lí do: phần R' có thể không tạo alcohol bền.

- **Ester của phenol** (R' là gốc thơm gắn thẳng vào O, như CH~3~COOC~6~H~5~): khi thuỷ phân sinh ra phenol, mà phenol có tính acid nên phản ứng tiếp với NaOH. Vì vậy cần **2 NaOH** cho mỗi nhóm ester, và sản phẩm có **nước** thay cho alcohol:

=> CH~3~COOC~6~H~5~ + 2NaOH → CH~3~COONa + C~6~H~5~ONa + H~2~O    (t°)

- **Ester có R' là gốc vinyl** (CH~3~COOCH=CH~2~): "alcohol" CH~2~=CH–OH sinh ra không bền, chuyển ngay thành acetaldehyde CH~3~CHO.

=> CH~3~COOCH=CH~2~ + NaOH → CH~3~COONa + CH~3~CHO    (t°)

- **Ester của formic acid** (HCOOR') còn giữ được "phần aldehyde" H–C=O, nên có phản ứng tráng bạc với thuốc thử Tollens.

> [!em-co-biet] Aspirin cũng là một ester
> Aspirin (thuốc giảm đau, hạ sốt) có nhóm ester gắn vào vòng benzene. Trong cơ thể, nhóm ester này bị thuỷ phân, giải phóng salicylic acid là chất có tác dụng ức chế sự tạo thành các chất gây đau, sốt, viêm (SGK tr. 9). Vì cũng là ester của phenol, aspirin để lâu trong không khí ẩm bị thuỷ phân dần, có mùi giấm (acetic acid).

> [!vi-du] Ví dụ 6
> Cho 13,6 g phenyl acetate CH~3~COOC~6~H~5~ tác dụng vừa đủ với dung dịch NaOH, đun nóng. Tính khối lượng NaOH đã phản ứng và khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> Phenyl acetate là ester của phenol: tỉ lệ mol ester : NaOH = 1 : 2.

> [!goi-y] Gợi ý 2
> Sản phẩm có **hai** muối: CH~3~COONa (M = 82) và C~6~H~5~ONa (M = 116).

> [!loi-giai] Lời giải
> n(CH~3~COOC~6~H~5~) = 13,6 : 136 = 0,1 mol → n(NaOH) = 0,2 mol → m(NaOH) = 0,2 · 40 = **8 g**.
>
> m(muối) = 0,1 · 82 + 0,1 · 116 = **19,8 g**.
>
> Kiểm tra bằng bảo toàn khối lượng: 13,6 + 8 = 19,8 + m(H~2~O) → m(H~2~O) = 1,8 g = 0,1 · 18. ✓

## 5. Điều chế ester

Trong phòng thí nghiệm và công nghiệp, ester thường được điều chế bằng **phản ứng ester hoá**: đun nóng carboxylic acid với alcohol, có H~2~SO~4~ đặc làm xúc tác (Hình 2).

=> RCOOH + R'OH ⇌ RCOOR' + H~2~O    (H~2~SO~4~ đặc, t°)

=> CH~3~COOH + C~2~H~5~OH ⇌ CH~3~COOC~2~H~5~ + H~2~O    (H~2~SO~4~ đặc, t°)

Trong phản ứng này, nhóm **–OH của acid** kết hợp với **nguyên tử H của nhóm –OH trong alcohol** tạo thành nước. Phần còn lại nối với nhau thành ester.

**Vai trò của H~2~SO~4~ đặc:**

1. **Xúc tác**, làm phản ứng xảy ra nhanh hơn.
2. **Hút nước**: lấy bớt H~2~O ra khỏi hệ, làm cân bằng chuyển dịch sang phía tạo ester, nên hiệu suất tăng.

> [!nen-tang] Chuyển dịch cân bằng (Hoá 11)
> Với phản ứng thuận nghịch, khi **giảm** nồng độ một chất sản phẩm hoặc **tăng** nồng độ một chất đầu, cân bằng chuyển dịch theo chiều thuận. Vì vậy, muốn tăng hiệu suất ester hoá thì dùng dư acid hoặc alcohol, hoặc tách bớt nước (hay ester) ra khỏi hỗn hợp.

**Hiệu suất phản ứng.** Vì phản ứng thuận nghịch nên hiệu suất luôn **nhỏ hơn 100%**:

$$H = \dfrac{m_{\text{tt}}}{m_{\text{lt}}}\cdot 100\%$$

trong đó m~tt~ là khối lượng ester thực tế thu được, m~lt~ là khối lượng ester tính theo phương trình (lí thuyết).

Lượng ester **lí thuyết** tính theo chất phản ứng **thiếu** (so số mol theo tỉ lệ 1 : 1).

> [!vi-du] Ví dụ 7
> Đun nóng 12 g acetic acid với 13,8 g ethanol (xúc tác H~2~SO~4~ đặc), thu được 11 g ethyl acetate. Tính hiệu suất của phản ứng ester hoá.

> [!goi-y] Gợi ý 1
> n(CH~3~COOH) = 12 : 60; n(C~2~H~5~OH) = 13,8 : 46. Tỉ lệ phản ứng 1 : 1, chất nào thiếu?

> [!goi-y] Gợi ý 2
> Khối lượng ester lí thuyết tính theo chất thiếu. H = thực tế : lí thuyết.

> [!loi-giai] Lời giải
> n(CH~3~COOH) = 0,2 mol; n(C~2~H~5~OH) = 0,3 mol → acid thiếu, tính theo acid.
>
> m(ester) lí thuyết = 0,2 · 88 = 17,6 g.
>
> H = 11 : 17,6 · 100% = **62,5%**.

> [!bay]
> - Tính hiệu suất theo chất **dư** sẽ ra kết quả nhỏ hơn đáp án đúng. Ở ví dụ trên, tính theo ethanol được 0,125 : 0,3 ≈ 41,7%, là sai.
> - Đi xuôi (biết chất đầu, tìm ester) thì **nhân** H. Đi ngược (biết ester, tìm chất đầu) thì **chia** H.

## 6. Ứng dụng của ester

Nhiều ứng dụng của ester đến từ ba đặc điểm: **có mùi thơm**, **hoà tan tốt nhiều chất hữu cơ**, và **có thể trùng hợp** (với ester có liên kết đôi C=C).

- **Hương liệu** cho thực phẩm (ethyl butyrate, isoamyl acetate, benzyl acetate…) và mĩ phẩm, nước hoa (linalyl acetate, geranyl acetate…).
- **Dung môi**: ethyl acetate dùng để tách, chiết chất hữu cơ, làm nước rửa sơn móng tay; butyl acetate dùng để pha sơn.
- **Vật liệu polymer**: methyl methacrylate trùng hợp thành poly(methyl methacrylate), một loại "thuỷ tinh hữu cơ" trong suốt. Các polyacrylate được dùng làm sơn tường.
- **Dược phẩm**: aspirin, methyl salicylate (có trong dầu xoa bóp giảm đau).

> [!ung-dung] Vì sao kẹo "hương chuối" không có chuối?
> Nhiều loại kẹo, nước giải khát dùng isoamyl acetate tổng hợp để tạo mùi chuối, ethyl butyrate để tạo mùi dứa. Các ester này được tổng hợp bằng phản ứng ester hoá, giá rẻ hơn rất nhiều so với chiết từ quả thật, và được phép dùng làm phụ gia thực phẩm trong giới hạn quy định.

## 7. Lipid, chất béo, acid béo

### 7.1. Lipid

**Lipid** là những hợp chất hữu cơ có trong tế bào sống, **không tan trong nước** nhưng **tan trong dung môi hữu cơ không phân cực** (như xăng, hexane, benzene). Dựa theo cấu tạo, lipid gồm: **chất béo**, **sáp**, **steroid**, **phospholipid**…

> [!bay]
> Lipid **không** chỉ là chất béo. Chất béo chỉ là **một loại** lipid. Sáp ong, cholesterol (một steroid), phospholipid của màng tế bào cũng là lipid.

### 7.2. Acid béo

**Acid béo** là carboxylic acid **đơn chức**, phần lớn có mạch carbon **dài** (thường 12–24 nguyên tử C), **không phân nhánh**, và có **số nguyên tử C chẵn**.

- **Acid béo no** (bão hoà): gốc hydrocarbon chỉ có liên kết đơn.
- **Acid béo không no** (không bão hoà): gốc hydrocarbon có một hay nhiều liên kết đôi C=C (trong tự nhiên thường ở dạng **cis**).

Bốn acid béo thường gặp (SGK tr. 10):

| Acid béo | Công thức thu gọn | Công thức phân tử | M | Số C=C |
|---|---|---|---|---|
| Palmitic acid | C~15~H~31~COOH | C~16~H~32~O~2~ | 256 | 0 (no) |
| Stearic acid | C~17~H~35~COOH | C~18~H~36~O~2~ | 284 | 0 (no) |
| Oleic acid | C~17~H~33~COOH | C~18~H~34~O~2~ | 282 | 1 |
| Linoleic acid | C~17~H~31~COOH | C~18~H~32~O~2~ | 280 | 2 |

> [!meo] Nhớ công thức acid béo C18
> Gốc no C~17~H~35~– (stearic). Mỗi liên kết đôi C=C bớt **2 H**: oleic C~17~H~33~– (1 nối đôi), linoleic C~17~H~31~– (2 nối đôi). Palmitic ngắn hơn stearic 2 nhóm CH~2~: C~15~H~31~–.
>
> Cách nhớ: "**P**almitic **16** C, **S**tearic **18** C no; **O**leic **1** đôi, **L**inoleic **2** đôi."

### 7.3. Chất béo

**Chất béo** là **triester** (ester ba chức) của **glycerol** với **acid béo**, còn gọi là **triglyceride**. Glycerol C~3~H~5~(OH)~3~ có 3 nhóm –OH, mỗi nhóm "gắn" với một gốc acid béo qua nhóm –COO–.

![Hình 3. Glycerol (3 nhóm –OH) kết hợp với 3 phân tử acid béo tạo thành triglyceride và 3 phân tử nước. R^1^, R^2^, R^3^ là gốc hydrocarbon dài, có thể giống hoặc khác nhau](triglyceride.svg)

Công thức chung có thể viết gọn là **(RCOO)~3~C~3~H~5~** (khi ba gốc giống nhau). Một số chất béo thường gặp:

| Chất béo | Công thức | M |
|---|---|---|
| Tripalmitin | (C~15~H~31~COO)~3~C~3~H~5~ | 806 |
| Tristearin | (C~17~H~35~COO)~3~C~3~H~5~ | 890 |
| Triolein | (C~17~H~33~COO)~3~C~3~H~5~ | 884 |

> [!meo] Tính nhanh M của triglyceride
> M = 92 (glycerol) + tổng M của 3 acid béo − 3 · 18 (3 phân tử nước tách ra). Ví dụ tristearin: 92 + 3 · 284 − 54 = 890.

> [!vi-du] Ví dụ 8
> Từ glycerol và hai acid béo là palmitic acid và stearic acid, có thể tạo ra tối đa bao nhiêu triglyceride? Trong đó, bao nhiêu triglyceride chứa cả hai loại gốc acid?

> [!goi-y] Gợi ý 1
> Glycerol có 3 vị trí: hai vị trí đầu (C1, C3) tương đương nhau và một vị trí giữa (C2). Gọi gốc palmitic là P, gốc stearic là S.

> [!goi-y] Gợi ý 2
> Liệt kê theo dạng (đầu – giữa – đầu). Hai cách viết P–P–S và S–P–P là **cùng một chất** vì đổi đầu cho nhau.

> [!loi-giai] Lời giải
> - Chỉ chứa một loại gốc: P–P–P, S–S–S (2 chất).
> - Chứa cả hai loại gốc: P–P–S, P–S–P, S–S–P, S–P–S (4 chất).
>
> Tổng cộng **6** triglyceride, trong đó **4** chất chứa cả hai gốc acid.

> [!meo] Công thức đếm
> Với n acid béo khác nhau, số triglyceride tối đa là $\dfrac{n^2(n+1)}{2}$. Với n = 2 được 6, với n = 3 được 18.

## 8. Tính chất vật lí của chất béo

- Ở nhiệt độ thường, chất béo có thể ở thể **rắn** hoặc **lỏng**:
  - Chứa chủ yếu gốc acid béo **no** → thường **rắn**: mỡ lợn, mỡ bò, mỡ cừu (thường gọi là **mỡ**).
  - Chứa chủ yếu gốc acid béo **không no** → thường **lỏng**: dầu lạc, dầu vừng, dầu ô liu, dầu cá (thường gọi là **dầu**).
- Chất béo **nhẹ hơn nước**, **không tan trong nước**, tan tốt trong dung môi hữu cơ ít phân cực hoặc không phân cực.

**Vì sao gốc no thì rắn, gốc không no thì lỏng?** Mạch no là đường zigzag thẳng, các phân tử xếp **khít** vào nhau như những que diêm trong hộp, lực hút giữa chúng mạnh, nên dễ đông rắn. Mỗi liên kết đôi **cis** làm mạch bị **gấp khúc**, các phân tử không xếp khít được, lực hút yếu đi, nên chất béo nóng chảy ở nhiệt độ thấp và là chất lỏng.

> [!em-co-biet] Mỡ lợn hay dầu đậu nành?
> Theo số liệu ở Hình 1.2 (SGK tr. 10), gốc acid béo no chiếm khoảng 41% trong mỡ lợn và 52% trong mỡ bò. Trong dầu đậu nành và dầu ô liu, con số này chỉ khoảng 14–15%. Vì vậy mùa đông mỡ lợn đông đặc trắng, còn dầu ăn vẫn lỏng.

## 9. Tính chất hoá học của chất béo

Chất béo là ester nên có **phản ứng thuỷ phân**. Ngoài ra, các gốc acid béo **không no** còn có phản ứng ở liên kết đôi C=C: **cộng hydrogen** và **bị oxi hoá bởi oxygen**.

### 9.1. Phản ứng thuỷ phân và xà phòng hoá

Giống mọi ester, chất béo bị thuỷ phân khi đun với nước có xúc tác acid (thuận nghịch), tạo ra glycerol và acid béo:

=> (C~17~H~35~COO)~3~C~3~H~5~ + 3H~2~O ⇌ 3C~17~H~35~COOH + C~3~H~5~(OH)~3~    (H^+^, t°)

Khi đun với dung dịch NaOH (hoặc KOH), phản ứng xảy ra một chiều, tạo ra **muối sodium (potassium) của acid béo** và glycerol:

=> (C~17~H~35~COO)~3~C~3~H~5~ + 3NaOH → 3C~17~H~35~COONa + C~3~H~5~(OH)~3~    (t°)

Muối sodium hoặc potassium của acid béo chính là thành phần chính của **xà phòng**. Đây là nguồn gốc của tên gọi "phản ứng xà phòng hoá".

> [!meo] Ba quan hệ dùng mãi khi giải bài chất béo
> Với chất béo (RCOO)~3~C~3~H~5~ phản ứng với NaOH:
> - n(NaOH) = n(muối) = **3** · n(chất béo)
> - n(glycerol) = n(chất béo)
> - Bảo toàn khối lượng: **m(chất béo) + m(NaOH) = m(muối) + m(glycerol)**

> [!vi-du] Ví dụ 9
> Xà phòng hoá hoàn toàn 89 kg tristearin bằng dung dịch NaOH vừa đủ.
>
> a) Tính khối lượng NaOH đã phản ứng và khối lượng glycerol thu được.
>
> b) Toàn bộ muối sinh ra được dùng để làm xà phòng, trong đó muối chiếm 72% khối lượng bánh xà phòng. Tính khối lượng xà phòng thu được.

> [!goi-y] Gợi ý 1
> M(tristearin) = 890, M(C~17~H~35~COONa) = 306, M(glycerol) = 92. Đơn vị kg thì dùng kmol.

> [!goi-y] Gợi ý 2
> Muối chiếm 72% khối lượng xà phòng, nên m(xà phòng) = m(muối) : 0,72.

> [!loi-giai] Lời giải
> a) n(tristearin) = 89 : 890 = 0,1 kmol.
>
> n(NaOH) = 0,3 kmol → m(NaOH) = 0,3 · 40 = **12 kg**. n(glycerol) = 0,1 kmol → m(glycerol) = **9,2 kg**.
>
> b) m(C~17~H~35~COONa) = 0,3 · 306 = 91,8 kg. Kiểm tra bảo toàn khối lượng: 89 + 12 = 91,8 + 9,2 = 101. ✓
>
> m(xà phòng) = 91,8 : 0,72 = **127,5 kg**.

### 9.2. Phản ứng hydrogen hoá chất béo lỏng

Chất béo có gốc acid **không no** cộng được H~2~ vào liên kết đôi C=C (xúc tác Ni, đun nóng, có áp suất), tạo thành chất béo có gốc acid **no**. Kết quả: dầu **lỏng** chuyển thành chất béo **rắn**.

=> (C~17~H~33~COO)~3~C~3~H~5~ (triolein, lỏng) + 3H~2~ → (C~17~H~35~COO)~3~C~3~H~5~ (tristearin, rắn)    (Ni, t°, p)

**Số mol H~2~ cần dùng** = số liên kết C=C trong các gốc acid × số mol chất béo. Triolein có 3 gốc oleic, mỗi gốc 1 C=C, nên cần 3 H~2~. Trilinolein có 3 gốc linoleic, mỗi gốc 2 C=C, nên cần 6 H~2~.

> [!ung-dung] Bơ thực vật (margarine)
> Nhiều loại bơ thực vật được sản xuất bằng cách hydrogen hoá **một phần** dầu thực vật lỏng (SGK tr. 11), để có chất béo dạng rắn, dễ phết lên bánh mì, khó bị ôi hơn dầu lỏng.

> [!em-co-biet] Chất béo "trans" (mở rộng)
> Khi hydrogen hoá không hoàn toàn, một số liên kết đôi cis còn lại bị chuyển sang dạng **trans**. Chất béo trans làm tăng nguy cơ bệnh tim mạch, nên nhiều nước đã giới hạn hoặc cấm dùng dầu hydrogen hoá một phần trong thực phẩm.

> [!vi-du] Ví dụ 10
> Hydrogen hoá hoàn toàn 44,2 g triolein (xúc tác Ni, t°). Tính thể tích H~2~ (đkc) đã phản ứng và khối lượng chất béo rắn thu được. Biết ở đkc, 1 mol khí chiếm 24,79 L.

> [!goi-y] Gợi ý 1
> M(triolein) = 884. Mỗi phân tử triolein có 3 liên kết C=C.

> [!goi-y] Gợi ý 2
> Sản phẩm là tristearin (M = 890). Có thể kiểm tra bằng bảo toàn khối lượng: m(sản phẩm) = m(triolein) + m(H~2~).

> [!loi-giai] Lời giải
> n(triolein) = 44,2 : 884 = 0,05 mol → n(H~2~) = 3 · 0,05 = 0,15 mol.
>
> V(H~2~) = 0,15 · 24,79 ≈ **3,72 L**.
>
> m(tristearin) = 0,05 · 890 = **44,5 g** (đúng bằng 44,2 + 0,15 · 2).

### 9.3. Phản ứng oxi hoá chất béo bởi oxygen không khí

Để dầu mỡ lâu ngày ngoài không khí, các gốc acid béo **không no** bị oxygen oxi hoá **chậm** ở chỗ liên kết đôi C=C. Phản ứng tạo ra những chất có mùi khó chịu (như các aldehyde mạch ngắn). Đó là hiện tượng **dầu mỡ bị ôi**.

- Dầu chứa nhiều gốc không no (dầu cá, dầu đậu nành) dễ bị ôi hơn mỡ.
- Ánh sáng, nhiệt độ cao làm phản ứng xảy ra nhanh hơn.

> [!ung-dung] Bảo quản dầu mỡ và thực phẩm chiên
> - Đựng dầu trong chai kín, màu tối, để nơi thoáng mát, tránh ánh nắng.
> - Không dùng lại dầu đã chiên nhiều lần, vì dầu đã bị oxi hoá và phân huỷ một phần.
> - Thực phẩm chế biến có chất béo (mì ăn liền, bánh quy…) thường được thêm **chất chống oxi hoá** như vitamin E, vitamin C để chậm bị ôi (SGK tr. 12).

## 10. Ứng dụng của chất béo và acid béo

### 10.1. Vai trò của chất béo

- **Nguồn năng lượng và dự trữ năng lượng** cho người và động vật. Cùng một khối lượng, chất béo cung cấp nhiều năng lượng hơn tinh bột và đường (khoảng 9 kcal/g so với khoảng 4 kcal/g).
- Cung cấp các **acid béo thiết yếu** mà cơ thể không tự tổng hợp được.
- **Hoà tan và giúp hấp thụ** các vitamin tan trong chất béo: **A, D, E, K**. Ăn quá ít chất béo có thể gây thiếu các vitamin này.
- **Nguyên liệu công nghiệp**: thực phẩm (dầu ăn, bơ thực vật), sản xuất **xà phòng** và **glycerol**.

### 10.2. Acid béo omega-3 và omega-6

**Acid béo omega-3 (ω-3) và omega-6 (ω-6)** là các acid béo không no có liên kết đôi **đầu tiên** ở nguyên tử carbon số **3** hoặc số **6**, khi **đánh số từ đầu nhóm methyl** (CH~3~), tức là từ đầu mạch xa nhóm –COOH nhất.

![Hình 4. Xác định acid béo omega: đánh số từ nguyên tử C của nhóm CH~3~ cuối mạch. Linoleic acid có liên kết đôi đầu tiên ở C6 (omega-6); α-linolenic acid có liên kết đôi đầu tiên ở C3 (omega-3)](omega.svg)

> [!bay]
> - Danh pháp bình thường của acid đánh số **từ C của nhóm COOH**. Riêng "omega" thì đánh số **ngược lại**, từ đầu CH~3~.
> - Oleic acid CH~3~[CH~2~]~7~CH=CH[CH~2~]~7~COOH: đếm từ CH~3~ (C1), 7 nhóm CH~2~ (C2–C8), liên kết đôi bắt đầu ở **C9**. Vậy oleic acid là **omega-9**, không phải omega-3 hay omega-6.

**Nguồn thực phẩm:**

- **Omega-3**: nhiều trong **dầu cá biển** (cá hồi, cá thu, cá trích), hạt lanh, hạt chia, quả óc chó.
- **Omega-6**: nhiều trong **dầu thực vật** như dầu mè (vừng), dầu đậu nành, dầu hướng dương.

Cả hai đều quan trọng với cơ thể, giúp phòng ngừa nhiều bệnh (tim mạch, viêm…). Chế độ ăn hiện nay thường **thừa omega-6, thiếu omega-3**, vì dầu thực vật được dùng rất phổ biến. Do đó nên tăng cường thực phẩm giàu omega-3 (ăn cá 2–3 bữa mỗi tuần) để cân bằng.

## Dạng bài thi hay gặp

### Dạng 1. Gọi tên và đếm đồng phân ester

**Nhận biết:** đề cho công thức phân tử (C~n~H~2n~O~2~, hoặc ester có vòng benzene như C~8~H~8~O~2~), hỏi số đồng phân ester, số chất tác dụng với NaOH, hoặc cho tên gọi để chọn công thức.

**Phương pháp:**

1. Tách nhóm –COO–, chia số C còn lại cho R (được phép là H) và R' (ít nhất 1 C).
2. Đếm số cấu tạo của mỗi gốc (C~3~: 2 gốc; C~4~: 4 gốc).
3. Với ester có vòng benzene, xét thêm: vòng ở phía acid hay phía R'; nhóm CH~3~ gắn ở vị trí ortho, meta, para.
4. Gọi tên: **R' trước, gốc acid (-ate) sau**.

> [!vi-du] Ví dụ 11
> Có bao nhiêu ester chứa vòng benzene có công thức phân tử C~8~H~8~O~2~? Trong số đó, bao nhiêu chất tác dụng với NaOH theo tỉ lệ mol 1 : 2?

> [!goi-y] Gợi ý 1
> Ngoài nhóm –COO– và vòng C~6~ còn đúng 1 nguyên tử C nữa. Nó có thể nằm ở phía acid, ở phía R' (dạng CH~2~ hoặc CH~3~ gắn vào vòng), hoặc không có (R = H).

> [!goi-y] Gợi ý 2
> Tỉ lệ 1 : 2 xảy ra khi O của nhóm ester gắn **thẳng** vào vòng benzene (ester của phenol).

> [!loi-giai] Lời giải
> - C~6~H~5~COOCH~3~ (methyl benzoate).
> - CH~3~COOC~6~H~5~ (phenyl acetate) — ester của phenol.
> - HCOOCH~2~C~6~H~5~ (benzyl formate) — O gắn vào CH~2~, **không** phải ester của phenol.
> - HCOOC~6~H~4~CH~3~ (vị trí o-, m-, p-): 3 chất, đều là ester của phenol.
>
> Tổng cộng **6** ester. Số chất phản ứng với NaOH theo tỉ lệ 1 : 2 là **4** (phenyl acetate và 3 đồng phân HCOOC~6~H~4~CH~3~).

> [!bay]
> - Benzyl formate HCOOCH~2~C~6~H~5~ dễ bị nhầm là ester của phenol. Hãy xem O gắn vào **CH~2~** hay gắn thẳng vào **vòng**.
> - "Đồng phân đơn chức tác dụng với NaOH" gồm cả **acid**, không chỉ ester.

### Dạng 2. Thuỷ phân ester trong dung dịch kiềm

**Nhận biết:** đề cho ester (hoặc hỗn hợp ester) tác dụng với NaOH/KOH, hỏi khối lượng muối, khối lượng chất rắn sau khi cô cạn, hoặc tìm công thức ester.

**Phương pháp:**

1. Ester thường: n(NaOH) = n(ester) = n(muối) = n(alcohol). Ester của phenol: n(NaOH) = 2n(ester), n(H~2~O) = n(ester).
2. **Bảo toàn khối lượng**: m(ester) + m(NaOH) = m(muối) + m(alcohol) + m(H~2~O nếu có).
3. **Cô cạn** dung dịch: chất rắn = muối + **kiềm dư** (alcohol và nước bay hơi).
4. Với hỗn hợp: đặt ẩn số mol, lập hệ theo khối lượng và theo số mol NaOH.

> [!vi-du] Ví dụ 12
> Hỗn hợp X gồm methyl benzoate và phenyl acetate (hai chất là đồng phân, cùng M = 136) có khối lượng 13,6 g. X tác dụng vừa đủ với dung dịch chứa 0,14 mol NaOH, đun nóng. Tính khối lượng muối thu được.

> [!goi-y] Gợi ý 1
> n(X) = 13,6 : 136 = 0,1 mol. Methyl benzoate cần 1 NaOH, phenyl acetate cần 2 NaOH.

> [!goi-y] Gợi ý 2
> Đặt x, y là số mol methyl benzoate và phenyl acetate. Lập hệ: x + y = 0,1 và x + 2y = 0,14. Sau đó dùng bảo toàn khối lượng (sản phẩm phụ là CH~3~OH và H~2~O).

> [!loi-giai] Lời giải
> Giải hệ: y = 0,04 mol (phenyl acetate), x = 0,06 mol (methyl benzoate).
>
> Sản phẩm phụ: n(CH~3~OH) = x = 0,06 mol; n(H~2~O) = y = 0,04 mol.
>
> Bảo toàn khối lượng: m(muối) = 13,6 + 0,14 · 40 − 0,06 · 32 − 0,04 · 18 = 13,6 + 5,6 − 1,92 − 0,72 = **16,56 g**.
>
> (Kiểm tra: 0,06 · 144 (C~6~H~5~COONa) + 0,04 · 82 (CH~3~COONa) + 0,04 · 116 (C~6~H~5~ONa) = 16,56 g. ✓)

> [!bay]
> - Quên NaOH dư trong chất rắn sau cô cạn.
> - Coi ester của phenol phản ứng 1 : 1 và quên phân tử nước sinh ra.

### Dạng 3. Xà phòng hoá và hydrogen hoá chất béo

**Nhận biết:** đề cho chất béo tác dụng với NaOH/KOH, hỏi khối lượng xà phòng, glycerol, chất béo; hoặc cho chất béo tác dụng với H~2~, hỏi số mol H~2~; có thể hỏi công thức chất béo.

**Phương pháp:**

1. n(NaOH) = 3n(chất béo); n(glycerol) = n(chất béo).
2. Bảo toàn khối lượng: m(chất béo) + m(NaOH) = m(muối) + m(glycerol).
3. n(H~2~) = (số liên kết C=C trong các gốc acid) × n(chất béo).
4. Có hiệu suất hoặc độ tinh khiết: nhân/chia như các bài hiệu suất thông thường.

> [!vi-du] Ví dụ 13
> Thuỷ phân hoàn toàn a gam triglyceride X trong dung dịch NaOH vừa đủ, thu được 4,6 g glycerol và hỗn hợp muối gồm 13,9 g sodium palmitate (C~15~H~31~COONa) và 30,4 g sodium oleate (C~17~H~33~COONa).
>
> a) Tính a.
>
> b) Xác định số gốc mỗi loại trong X. Cần bao nhiêu mol H~2~ để hydrogen hoá hoàn toàn a gam X?

> [!goi-y] Gợi ý 1
> n(glycerol) = n(X); n(NaOH) = 3n(X). Áp dụng bảo toàn khối lượng.

> [!goi-y] Gợi ý 2
> Tính số mol mỗi muối (M = 278 và 304), so với số mol X để biết mỗi phân tử X có mấy gốc của từng loại. Chỉ gốc oleic có liên kết đôi.

> [!loi-giai] Lời giải
> a) n(X) = n(glycerol) = 4,6 : 92 = 0,05 mol → n(NaOH) = 0,15 mol.
>
> a = m(muối) + m(glycerol) − m(NaOH) = (13,9 + 30,4) + 4,6 − 0,15 · 40 = **42,9 g**.
>
> b) n(C~15~H~31~COONa) = 13,9 : 278 = 0,05 mol; n(C~17~H~33~COONa) = 30,4 : 304 = 0,1 mol.
>
> Mỗi phân tử X có 0,05 : 0,05 = **1 gốc palmitic** và 0,1 : 0,05 = **2 gốc oleic**. (Kiểm tra: M(X) = 42,9 : 0,05 = 858 = 92 + 256 + 2 · 282 − 54. ✓)
>
> X có 2 liên kết C=C → n(H~2~) = 2 · 0,05 = **0,1 mol**.

> [!bay]
> - Tỉ lệ NaOH : chất béo là **3 : 1**, không phải 1 : 1.
> - Muối của acid béo là C~17~H~35~COO**Na** (M = 306), đừng dùng M của acid (284).
> - Đếm liên kết C=C chỉ trong **gốc hydrocarbon**. Ba nhóm C=O của ester **không** cộng H~2~ trong điều kiện này.

### Dạng 4. Câu Đúng/Sai về ester và chất béo

**Nhận biết:** 4 ý về khái niệm, tính chất vật lí, thí nghiệm thuỷ phân, xà phòng hoá, ôi mỡ, omega-3/6.

**Phương pháp:** soát kĩ các **từ khoá dễ bị đánh tráo**:

| Từ khoá đúng | Thường bị đánh tráo thành |
|---|---|
| Thuỷ phân trong acid: **thuận nghịch** | "một chiều" |
| Xà phòng hoá: **một chiều** | "thuận nghịch" |
| Ester sôi **thấp** vì **không** có liên kết hydrogen | "sôi cao", "có liên kết hydrogen" |
| Mỡ rắn do nhiều gốc **no** | "nhiều gốc không no" |
| Ôi mỡ do gốc **không no** bị **oxi hoá** | "gốc no", "bị thuỷ phân" |
| Hydrogen hoá: **lỏng → rắn** | "rắn → lỏng" |
| Chất béo **nhẹ hơn** nước | "nặng hơn nước" |
| Omega: đánh số từ **đầu CH~3~** | "từ nhóm COOH" |

> [!vi-du] Ví dụ 14 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Dầu lạc và mỡ lợn đều có thành phần chính là triglyceride.
>
> b) Hydrogen hoá hoàn toàn triolein thu được tripalmitin.
>
> c) Xà phòng hoá chất béo luôn thu được glycerol.
>
> d) Mỡ lợn để lâu bị ôi là do các gốc acid béo no bị oxi hoá.

> [!goi-y] Gợi ý 1
> Triolein là triester của acid C18 (oleic). Cộng H~2~ có làm thay đổi số nguyên tử C không?

> [!goi-y] Gợi ý 2
> Chỗ nào trong gốc acid béo bị oxygen tấn công?

> [!loi-giai] Lời giải
> a) **Đúng**: cả dầu và mỡ đều là chất béo (triglyceride); chỉ khác tỉ lệ gốc no và không no.
>
> b) **Sai**: cộng H~2~ không làm thay đổi số C. Gốc C~17~H~33~– thành C~17~H~35~–, nên sản phẩm là **tristearin** (C18), không phải tripalmitin (C16).
>
> c) **Đúng**: mọi chất béo đều là ester của glycerol, nên khi xà phòng hoá luôn giải phóng glycerol.
>
> d) **Sai**: chỗ bị oxi hoá là liên kết đôi C=C, tức các gốc acid béo **không no**.

## Tóm tắt

| | Ester | Chất béo |
|---|---|---|
| Khái niệm | Thay –OH của nhóm –COOH bằng –OR' | Triester của glycerol với acid béo (triglyceride) |
| Công thức | RCOOR' (no, đơn chức, mạch hở: C~n~H~2n~O~2~) | (RCOO)~3~C~3~H~5~ |
| Tên gọi | gốc R' + gốc acid (-ate) | tripalmitin, tristearin, triolein… |
| Vật lí | Sôi thấp (không có liên kết hydrogen), nhẹ hơn nước, ít tan, nhiều chất thơm | Gốc no → rắn (mỡ); gốc không no → lỏng (dầu); nhẹ hơn nước, không tan trong nước |
| Thuỷ phân (H^+^) | ⇌ RCOOH + R'OH (thuận nghịch) | ⇌ 3RCOOH + C~3~H~5~(OH)~3~ |
| Xà phòng hoá (NaOH) | → RCOONa + R'OH (một chiều) | → 3RCOONa (xà phòng) + C~3~H~5~(OH)~3~ |
| Phản ứng riêng | Ester của phenol: 1 ester + 2NaOH | + H~2~ (Ni, t°): lỏng → rắn; bị O~2~ oxi hoá → ôi |
| Điều chế / nguồn | Ester hoá: RCOOH + R'OH ⇌ RCOOR' + H~2~O (H~2~SO~4~ đặc) | Mỡ động vật, dầu thực vật |
| Ứng dụng | Hương liệu, dung môi, polymer, dược phẩm | Năng lượng, vitamin A, D, E, K, xà phòng, glycerol, thực phẩm |

**Bốn acid béo cần thuộc:** palmitic C~15~H~31~COOH (256), stearic C~17~H~35~COOH (284), oleic C~17~H~33~COOH (282, 1 C=C), linoleic C~17~H~31~COOH (280, 2 C=C).

**Các quan hệ dùng trong tính toán:**

- Ester thường: n(NaOH) = n(ester); ester của phenol: n(NaOH) = 2n(ester), có thêm H~2~O.
- Chất béo: n(NaOH) = 3n(chất béo) = 3n(glycerol); m(béo) + m(NaOH) = m(muối) + m(glycerol).
- Hydrogen hoá: n(H~2~) = số C=C × n(chất béo).
- Hiệu suất ester hoá tính theo chất **thiếu**; đi xuôi nhân H, đi ngược chia H.
- Số triglyceride từ n acid béo: n^2^(n + 1) : 2.
