---
title: Ôn tập chương 1
thoi-gian: 45 phút
muc-tieu:
  - Hệ thống hoá được kiến thức về ester, chất béo, xà phòng và chất giặt rửa; thấy được mối liên hệ giữa các bài trong chương.
  - Phân biệt được các chất, các phản ứng dễ nhầm (thuỷ phân trong acid và trong base, ester thường và ester của phenol, dầu và mỡ, xà phòng và chất giặt rửa tổng hợp…).
  - Nhận ra và tránh được các lỗi sai hay gặp của cả chương.
  - Giải được các bài tập tổng hợp: hỗn hợp ester tác dụng với NaOH, ester của phenol, chất béo lẫn acid béo tự do, chuỗi chuyển hoá, câu Đúng/Sai về thí nghiệm điều chế ester và xà phòng.
---

> [!ghi-nho] Chương này trong 10 dòng
> 1. **Ester** RCOOR' (R' ≠ H): thay –OH của nhóm –COOH bằng –OR'. Tên = **gốc R' + gốc acid (-ate)**.
> 2. Ester **không có liên kết hydrogen** giữa các phân tử → sôi thấp hơn alcohol và acid có M tương đương; nhẹ hơn nước, ít tan, nhiều chất thơm.
> 3. Thuỷ phân trong **acid**: **thuận nghịch** (H^+^ chỉ là xúc tác). Trong **base** (xà phòng hoá): **một chiều**, cho **muối** + alcohol.
> 4. Ngoại lệ: ester của **phenol** cần **2 NaOH** và sinh H~2~O; ester **vinyl** cho aldehyde; ester **HCOOR'** tráng bạc được.
> 5. Điều chế ester: **ester hoá** RCOOH + R'OH ⇌ RCOOR' + H~2~O (H~2~SO~4~ đặc: xúc tác + hút nước). Hiệu suất tính theo chất **thiếu**.
> 6. **Chất béo** = triester của **glycerol** với **acid béo** (RCOO)~3~C~3~H~5~. Gốc no → rắn (mỡ); gốc không no → lỏng (dầu).
> 7. Chất béo: thuỷ phân, xà phòng hoá (1 chất béo : 3 NaOH : 1 glycerol); **+ H~2~** (lỏng → rắn); gốc không no bị **O~2~** oxi hoá → ôi.
> 8. **Xà phòng** = muối Na/K của acid béo (+ phụ gia). **Chất giặt rửa tổng hợp** = R–OSO~3~Na, R–C~6~H~4~–SO~3~Na (từ dầu mỏ). Tự nhiên: bồ kết, bồ hòn.
> 9. Cả hai đều có **đuôi kị nước + đầu ưa nước** → tạo **micelle** cuốn dầu mỡ. Xà phòng **kém** trong nước cứng và môi trường acid, nhưng **dễ phân huỷ sinh học**.
> 10. Tính toán: **bảo toàn khối lượng** là chìa khoá; nhớ NaOH dư nằm trong chất rắn, nước sinh ra từ ester của phenol và từ acid béo tự do.

## 1. Hệ thống hoá kiến thức

### 1.1. Sơ đồ toàn chương

Chương 1 thực chất chỉ xoay quanh **một nhóm chức**: nhóm ester –COO–. Ba "tầng" kiến thức nối với nhau như sau:

- **Tầng 1 – Ester** (Bài 1): học cấu tạo, tên gọi, ba phản ứng gốc (thuỷ phân trong acid, xà phòng hoá, ester hoá).
- **Tầng 2 – Chất béo** (Bài 1): là một **trường hợp riêng** của ester (triester của glycerol). Vì vậy chất béo **kế thừa** mọi tính chất của ester, cộng thêm hai phản ứng của gốc không no: cộng H~2~ và bị O~2~ oxi hoá.
- **Tầng 3 – Xà phòng và chất giặt rửa** (Bài 2): xà phòng là **sản phẩm** của phản ứng xà phòng hoá chất béo. Chất giặt rửa tổng hợp "bắt chước" cấu tạo của xà phòng nhưng thay đầu –COO^−^ bằng –SO~3~^−^ hoặc –OSO~3~^−^.

![Hình 1. Sơ đồ hệ thống hoá chương 1: ester → chất béo (một loại ester đặc biệt) → xà phòng (sản phẩm xà phòng hoá chất béo); chất giặt rửa có chung kiểu cấu tạo "đuôi kị nước + đầu ưa nước" với xà phòng](he-thong.svg)

> [!meo] Học theo "dòng chảy", đừng học rời rạc
> Khi gặp một câu hỏi về chất béo, hãy tự hỏi: "Ester làm được gì thì chất béo cũng làm được". Khi gặp câu hỏi về xà phòng, hãy lùi lại một bước: "Xà phòng sinh ra từ phản ứng nào?". Nhờ vậy em chỉ cần nhớ **ít** mà suy ra được **nhiều**.

### 1.2. Bảng tra nhanh: kiến thức nào nằm ở đâu?

| Nội dung | Ý chính cần nhớ | Xem lại |
|---|---|---|
| Khái niệm, công thức ester | RCOOR', R' ≠ H; no đơn chức mạch hở C~n~H~2n~O~2~ (n ≥ 2) | Bài 1, mục 1 |
| Tên gọi, đồng phân | gốc R' + gốc acid (-ate); C~3~: 2, C~4~: 4, C~5~: 9 ester | Bài 1, mục 2 |
| Tính chất vật lí ester | ester < alcohol < acid (nhiệt độ sôi, M xấp xỉ) | Bài 1, mục 3 |
| Thuỷ phân, xà phòng hoá | acid: ⇌; base: →; ester phenol cần 2NaOH | Bài 1, mục 4 |
| Ester hoá, hiệu suất | H~2~SO~4~ đặc; tính theo chất thiếu | Bài 1, mục 5 |
| Acid béo, chất béo | palmitic 256, stearic 284, oleic 282, linoleic 280 | Bài 1, mục 7 |
| Hydrogen hoá, ôi mỡ, omega | n(H~2~) = số C=C × n(chất béo); omega đếm từ đầu CH~3~ | Bài 1, mục 9–10 |
| Xà phòng, chất giặt rửa | –COONa/–COOK + gốc dài; –SO~3~Na, –OSO~3~Na | Bài 2, mục 1 |
| Cơ chế giặt rửa | đuôi vào dầu, đầu ra nước → micelle | Bài 2, mục 2 |
| Sản xuất, thí nghiệm xà phòng hoá | NaOH đặc, khuấy, thêm nước, NaCl bão hoà | Bài 2, mục 3 |
| Nước cứng, môi trường acid | 2RCOO^−^ + Ca^2+^ → (RCOO)~2~Ca↓ | Bài 2, mục 4 |

### 1.3. Sơ đồ chuyển hoá giữa các chất

Câu hỏi "chuỗi phản ứng" trong đề thường chỉ dùng vài mắt xích dưới đây. Em nên tự vẽ lại Hình 2 trên giấy nháp đến khi thuộc.

![Hình 2. Hai chuỗi chuyển hoá hay gặp: (a) ethanol → acetic acid ⇌ ethyl acetate → sodium acetate; (b) triolein → tristearin → sodium stearate, và số phận của xà phòng khi gặp acid hoặc nước cứng](chuyen-hoa.svg)

Các phương trình tương ứng:

=> C~2~H~5~OH + O~2~ → CH~3~COOH + H~2~O    (men giấm)

=> CH~3~COOH + C~2~H~5~OH ⇌ CH~3~COOC~2~H~5~ + H~2~O    (H~2~SO~4~ đặc, t°)

=> CH~3~COOC~2~H~5~ + NaOH → CH~3~COONa + C~2~H~5~OH    (t°)

=> (C~17~H~33~COO)~3~C~3~H~5~ + 3H~2~ → (C~17~H~35~COO)~3~C~3~H~5~    (Ni, t°, p)

=> (C~17~H~35~COO)~3~C~3~H~5~ + 3NaOH → 3C~17~H~35~COONa + C~3~H~5~(OH)~3~    (t°)

=> C~17~H~35~COONa + HCl → C~17~H~35~COOH↓ + NaCl

=> 2C~17~H~35~COONa + Ca^2+^ → (C~17~H~35~COO)~2~Ca↓ + 2Na^+^

> [!nen-tang] Lên men giấm (Hoá 11)
> Ethanol bị oxi hoá bởi oxygen không khí nhờ enzyme của vi khuẩn giấm, tạo acetic acid. Đây là cách làm giấm ăn truyền thống. Trong chuỗi phản ứng, "men giấm" là dấu hiệu nhận ra cặp ethanol → acetic acid.

## 2. So sánh – phân biệt các chất, các phản ứng dễ nhầm

### 2.1. Ba phản ứng "gốc" của nhóm ester

| | Ester hoá | Thuỷ phân trong acid | Xà phòng hoá (base) |
|---|---|---|---|
| Phương trình | RCOOH + R'OH ⇌ RCOOR' + H~2~O | RCOOR' + H~2~O ⇌ RCOOH + R'OH | RCOOR' + NaOH → RCOONa + R'OH |
| Điều kiện | H~2~SO~4~ **đặc**, t° | H~2~SO~4~ (HCl) **loãng**, t° | dung dịch NaOH/KOH, t° |
| Vai trò H^+^ / OH^−^ | xúc tác + hút nước | xúc tác | **chất phản ứng** (bị tiêu hao) |
| Chiều | thuận nghịch | thuận nghịch | **một chiều** |
| Sản phẩm thuộc nhóm | ester | **acid** + alcohol | **muối** + alcohol |

**Vì sao ester hoá và thuỷ phân trong acid lại là "hai chiều của một cân bằng"?** Cùng một hệ RCOOH, R'OH, RCOOR', H~2~O; chỉ khác ta bắt đầu từ phía nào. Muốn được nhiều ester thì **bớt nước** (dùng H~2~SO~4~ đặc). Muốn thuỷ phân nhiều thì **dùng nhiều nước** (acid loãng). Còn trong NaOH, acid sinh ra bị chuyển ngay thành ion RCOO^−^, không quay lại được, nên phản ứng đi đến cùng.

### 2.2. Năm kiểu ester khi gặp NaOH (kể cả chất béo)

| Kiểu ester | Ví dụ | n(NaOH) : n(ester) | Sản phẩm | Dấu hiệu nhận ra |
|---|---|---|---|---|
| Ester thường | CH~3~COOC~2~H~5~ | 1 : 1 | muối + **alcohol** | R' là gốc alkyl, benzyl |
| Ester của phenol | CH~3~COOC~6~H~5~ | **2 : 1** | **2 muối** + **H~2~O** | O gắn **thẳng vào vòng benzene** |
| Ester vinyl | CH~3~COOCH=CH~2~ | 1 : 1 | muối + **aldehyde** CH~3~CHO | O gắn vào C mang nối đôi |
| Ester của formic acid | HCOOC~2~H~5~ | 1 : 1 | HCOONa + alcohol | còn nhóm H–C=O → **tráng bạc** |
| Chất béo | (RCOO)~3~C~3~H~5~ | **3 : 1** | 3 muối + **glycerol** | ba nhóm –COO– trên khung C~3~H~5~ |

> [!meo] Dùng tỉ lệ NaOH để "đoán" thành phần hỗn hợp
> Với hỗn hợp ester đơn chức, đặt **k = n(NaOH) : n(ester)**.
> - k = 1: chỉ có ester thường (hoặc vinyl, formate).
> - 1 < k < 2: có cả ester thường **và** ester của phenol. Khi đó n(ester phenol) = n(NaOH) − n(ester), và n(H~2~O) = n(ester phenol).
> - k = 2: toàn ester của phenol.

### 2.3. Ester và carboxylic acid có cùng công thức C~n~H~2n~O~2~

| | Ester (HCOOCH~3~, CH~3~COOCH~3~…) | Carboxylic acid (CH~3~COOH, C~2~H~5~COOH…) |
|---|---|---|
| Liên kết hydrogen giữa các phân tử | không có | có (rất bền) |
| Nhiệt độ sôi (M xấp xỉ) | thấp | cao nhất |
| Tác dụng với NaOH | có (cần đun nóng), cho muối + alcohol | có (ngay ở nhiệt độ thường), cho muối + H~2~O |
| Tác dụng với Na, với NaHCO~3~ | **không** | **có** (giải phóng H~2~; CO~2~) |
| Mùi | nhiều chất thơm (hoa, quả) | mùi chua, hắc |

> [!bay]
> "Số chất **đơn chức** C~3~H~6~O~2~ tác dụng được với NaOH" là **3** (2 ester + 1 acid), không phải 2. Đọc kĩ đề hỏi "ester" hay "chất".

### 2.4. Lipid, chất béo, dầu, mỡ, dầu nhớt

| Tên gọi | Bản chất | Ghi chú |
|---|---|---|
| Lipid | nhóm lớn: chất béo, sáp, steroid, phospholipid… | không tan trong nước, tan trong dung môi hữu cơ |
| Chất béo | triester của glycerol và acid béo | chỉ là **một loại** lipid |
| Mỡ (lợn, bò) | chất béo nhiều gốc **no** | rắn ở nhiệt độ thường |
| Dầu ăn (lạc, vừng, cá) | chất béo nhiều gốc **không no** | lỏng; dễ bị ôi hơn mỡ |
| Dầu nhớt, mỡ bôi trơn máy | **hydrocarbon** (từ dầu mỏ), **không** phải ester | không bị xà phòng hoá (mở rộng) |

> [!em-co-biet] Phân biệt dầu ăn và dầu nhớt bằng NaOH (mở rộng)
> Đun mỗi chất với dung dịch NaOH: dầu ăn bị xà phòng hoá, sau một lúc hỗn hợp trở nên **đồng nhất**. Dầu nhớt là hydrocarbon, không phản ứng, vẫn **tách lớp** dù đun lâu.

### 2.5. Bốn chất "họ hàng" hay bị đánh tráo trong đề

| Chất | Ví dụ | Là xà phòng? | Có tác dụng giặt rửa? |
|---|---|---|---|
| Chất béo | (C~17~H~35~COO)~3~C~3~H~5~ | không | không (chính nó là vết bẩn) |
| Acid béo | C~17~H~35~COOH | không (chưa phải muối) | không (không tan) |
| Muối Na/K của acid béo | C~17~H~35~COONa, C~17~H~33~COOK | **có** | có |
| Chất giặt rửa tổng hợp | CH~3~[CH~2~]~11~–OSO~3~Na | không | **có**, kể cả trong nước cứng |

Một điểm so sánh nữa cần nhớ (chi tiết ở Bài 2, mục 4): xà phòng **dễ phân huỷ sinh học** nhưng **kém** trong nước cứng và môi trường acid; chất giặt rửa tổng hợp **ngược lại**.

## 3. Lỗi sai hay gặp của cả chương

| Lỗi | Ví dụ sai | Đúng là |
|---|---|---|
| Đọc ngược tên ester | CH~3~COOC~2~H~5~ là "acetyl ethylate", C~2~H~5~COOCH~3~ là "ethyl acetate" | Gốc **R'** (gắn với O đơn) đọc **trước**: ethyl acetate; methyl propionate |
| Nhầm phenyl và benzyl | HCOOCH~2~C~6~H~5~ là ester của phenol | O gắn vào **CH~2~** → ester thường (1 NaOH) |
| Nhầm chiều phản ứng | "Thuỷ phân ester trong acid là một chiều" | Trong acid: **thuận nghịch**; trong base: **một chiều** |
| Quên NaOH dư | Chất rắn sau cô cạn chỉ gồm muối | Chất rắn = muối **+ NaOH (KOH) dư** |
| Quên nước ở ester phenol | m(muối) = m(ester) + m(NaOH) − m(alcohol) | Ester phenol sinh **H~2~O**, không sinh alcohol |
| Quên hệ số 3 | n(NaOH) = n(chất béo) | n(NaOH) = **3** n(chất béo) |
| Dùng M của acid thay M của muối | sodium stearate M = 284 | C~17~H~35~COONa: **306**; C~15~H~31~COONa: **278**; C~17~H~33~COONa: **304** |
| Có acid béo tự do mà vẫn chia 3 | n(glycerol) = n(NaOH) : 3 | n(NaOH) = 3n(chất béo) + n(acid béo); thêm **H~2~O** trong bảo toàn khối lượng |
| Hiệu suất tính theo chất dư | lấy chất có số mol lớn hơn | Tính theo chất **thiếu**; đi xuôi nhân H, đi ngược chia H |
| Quên chia % muối trong xà phòng | m(xà phòng) = m(muối) | m(xà phòng) = m(muối) : a% (xà phòng **nặng hơn** muối) |
| Hydrogen hoá làm đổi số C | triolein + H~2~ → tripalmitin | Số C giữ nguyên: triolein → **tristearin** |
| Nhầm phần ưa nước, kị nước | "Đầu –COO^−^ cắm vào vết dầu" | **Đuôi** hydrocarbon cắm vào dầu; **đầu** ion quay ra nước |
| Nghĩ xà phòng chỉ làm từ chất béo | "Xà phòng chỉ sản xuất từ chất béo" | Còn từ **alkane của dầu mỏ** → acid béo → muối |
| Đếm omega từ nhóm COOH | oleic acid là omega-3 hoặc omega-6 | Đếm từ đầu **CH~3~**: oleic là **omega-9** |

## 4. Bài tập tổng hợp

Năm ví dụ dưới đây mỗi bài phối hợp kiến thức của **ít nhất hai** mục trong chương. Hãy tự làm trước, mở gợi ý từng nấc khi bí.

### 4.1. Hỗn hợp ester tác dụng với NaOH dư

> [!vi-du] Ví dụ 1
> Hỗn hợp X gồm ethyl formate và methyl acetate có tổng khối lượng 11,1 g. Đun nóng X với 200 mL dung dịch NaOH 1 M đến khi phản ứng hoàn toàn, thu được 6,2 g hỗn hợp hai alcohol. Cô cạn dung dịch sau phản ứng thu được m gam chất rắn khan.
>
> a) Tính phần trăm khối lượng của ethyl formate trong X.
>
> b) Tính m.

> [!goi-y] Gợi ý 1
> Ethyl formate HCOOC~2~H~5~ và methyl acetate CH~3~COOCH~3~ là **đồng phân** (cùng C~3~H~6~O~2~, M = 74). Vậy n(X) tính được ngay. NaOH đủ hay dư?

> [!goi-y] Gợi ý 2
> Ethyl formate cho C~2~H~5~OH (46), methyl acetate cho CH~3~OH (32). Đặt x, y là số mol hai ester, lập hệ theo tổng số mol và khối lượng alcohol.

> [!goi-y] Gợi ý 3
> Chất rắn gồm HCOONa, CH~3~COONa **và NaOH dư**. Có thể kiểm tra bằng bảo toàn khối lượng: m(X) + m(NaOH) = m(rắn) + m(alcohol).

> [!loi-giai] Lời giải
> n(X) = 11,1 : 74 = 0,15 mol; n(NaOH) = 0,2 mol → NaOH dư 0,05 mol.
>
> Hệ: x + y = 0,15 và 46x + 32y = 6,2 → x = 0,1 (ethyl formate); y = 0,05 (methyl acetate).
>
> a) %m(HCOOC~2~H~5~) = 0,1 · 74 : 11,1 · 100% ≈ **66,7%**.
>
> b) m = 0,1 · 68 + 0,05 · 82 + 0,05 · 40 = 6,8 + 4,1 + 2,0 = **12,9 g**.
>
> Kiểm tra: 11,1 + 0,2 · 40 − 6,2 = 12,9 g. ✓

### 4.2. Hỗn hợp có ester của phenol

> [!vi-du] Ví dụ 2
> Hỗn hợp E gồm ethyl acetate và phenyl acetate có khối lượng 22,4 g. E tác dụng vừa đủ với dung dịch chứa 0,3 mol NaOH, đun nóng, thu được dung dịch chứa m gam muối.
>
> a) Tính m.
>
> b) Tính phần trăm khối lượng phenyl acetate trong E.

> [!goi-y] Gợi ý 1
> Nếu E chỉ là ethyl acetate thì n(E) = 22,4 : 88 ≈ 0,25 mol và chỉ cần 0,25 mol NaOH. Đề cho 0,3 mol, nhiều hơn → chắc chắn có ester "ăn" 2 NaOH.

> [!goi-y] Gợi ý 2
> Đặt x = n(CH~3~COOC~2~H~5~), y = n(CH~3~COOC~6~H~5~). Lập hệ: 88x + 136y = 22,4 và x + 2y = 0,3.

> [!goi-y] Gợi ý 3
> Sản phẩm phụ: C~2~H~5~OH (x mol) và H~2~O (y mol). Muối gồm CH~3~COONa (x + y mol) và C~6~H~5~ONa (y mol).

> [!loi-giai] Lời giải
> Giải hệ: x = 0,1; y = 0,1.
>
> a) m(muối) = (0,1 + 0,1) · 82 + 0,1 · 116 = 16,4 + 11,6 = **28,0 g**.
>
> Kiểm tra bằng bảo toàn khối lượng: 22,4 + 0,3 · 40 − 0,1 · 46 − 0,1 · 18 = 28,0 g. ✓
>
> b) %m(phenyl acetate) = 0,1 · 136 : 22,4 · 100% ≈ **60,7%**.

> [!bay]
> Nếu coi cả hai ester đều phản ứng 1 : 1 thì hệ x + y = 0,3 cho số mol âm, vô lí. Gặp số mol âm, hãy kiểm tra lại xem có ester của phenol không.

### 4.3. Chất béo lẫn acid béo tự do, kết hợp hydrogen hoá

> [!vi-du] Ví dụ 3
> Một mẫu dầu ăn để lâu gồm triolein và oleic acid tự do. Cho 41,0 g mẫu dầu tác dụng vừa đủ với dung dịch chứa 0,14 mol NaOH, đun nóng.
>
> a) Tính khối lượng glycerol và khối lượng muối thu được.
>
> b) Tính thể tích H~2~ (đkc, 24,79 L/mol) cần để hydrogen hoá hoàn toàn 41,0 g mẫu dầu trên (xúc tác Ni, t°).

> [!goi-y] Gợi ý 1
> Đặt x = n(triolein) (M = 884), y = n(oleic acid) (M = 282). Triolein cần 3 NaOH, acid béo cần 1 NaOH.

> [!goi-y] Gợi ý 2
> Hai chất cho **cùng một muối** C~17~H~33~COONa (M = 304), nên n(muối) = n(NaOH). Glycerol chỉ đến từ triolein.

> [!goi-y] Gợi ý 3
> Câu b: **mỗi gốc oleic** có 1 liên kết C=C, dù nằm trong triolein hay ở dạng acid tự do. Đếm tổng số gốc oleic.

> [!loi-giai] Lời giải
> Hệ: 884x + 282y = 41,0 và 3x + y = 0,14 → x = 0,04; y = 0,02.
>
> a) m(glycerol) = 0,04 · 92 = **3,68 g**.
>
> m(muối) = 0,14 · 304 = **42,56 g**. Kiểm tra: 41,0 + 0,14 · 40 − 3,68 − 0,02 · 18 = 42,56 g. ✓
>
> b) Tổng số gốc oleic = 3 · 0,04 + 0,02 = 0,14 mol → n(H~2~) = 0,14 mol.
>
> V(H~2~) = 0,14 · 24,79 ≈ **3,47 L**.

> [!meo]
> Ở bài này n(H~2~) = n(NaOH) không phải trùng hợp ngẫu nhiên: mỗi gốc oleic "ăn" đúng 1 NaOH và đúng 1 H~2~. Với gốc linoleic (2 C=C) thì mỗi gốc ăn 1 NaOH nhưng 2 H~2~.

### 4.4. Chuỗi chuyển hoá

> [!vi-du] Ví dụ 4
> a) Ester X có công thức phân tử C~4~H~8~O~2~. Cho sơ đồ: X + NaOH → Y + Z (t°); Z + O~2~ → T + H~2~O (men giấm); T + NaOH → Y + H~2~O. Xác định X, Y, Z, T.
>
> b) Chất béo lỏng P chỉ chứa một loại gốc acid béo, 1 mol P cộng tối đa 3 mol H~2~ (Ni, t°) tạo ra chất béo rắn Q. Xà phòng hoá Q bằng NaOH thu được muối R và glycerol. Cho R tác dụng với dung dịch HCl thu được chất S không tan trong nước. Xác định P, Q, R, S.

> [!goi-y] Gợi ý 1
> Câu a: "men giấm" biến alcohol nào thành acid nào? Y vừa là muối của X, vừa là muối của T, nên gốc acid của X **trùng** với T.

> [!goi-y] Gợi ý 2
> Câu b: 1 mol P cộng 3 mol H~2~ mà P có 3 gốc **giống nhau** → mỗi gốc có 1 C=C. Acid béo nào có đúng 1 liên kết đôi?

> [!loi-giai] Lời giải
> a) Men giấm: C~2~H~5~OH → CH~3~COOH. Vậy Z = C~2~H~5~OH (ethanol), T = CH~3~COOH (acetic acid). Y là muối của T: Y = CH~3~COONa. X tạo từ gốc acetate và gốc ethyl, có C~4~H~8~O~2~: X = **CH~3~COOC~2~H~5~** (ethyl acetate). Kiểm tra: CH~3~COOC~2~H~5~ có 4 C, 8 H, 2 O, đúng là C~4~H~8~O~2~. ✓
>
> b) Mỗi gốc có 1 C=C → gốc oleic. P = **triolein** (C~17~H~33~COO)~3~C~3~H~5~. Cộng H~2~ không đổi số C: Q = **tristearin**. R = **C~17~H~35~COONa** (sodium stearate). S = **C~17~H~35~COOH** (stearic acid), không tan trong nước.

### 4.5. Đúng/Sai về thí nghiệm điều chế ester

> [!vi-du] Ví dụ 5 (Đúng/Sai)
> Isoamyl acetate (CH~3~COOCH~2~CH~2~CH(CH~3~)~2~, M = 130) có mùi chuối chín. Một nhóm học sinh điều chế chất này như sau:
>
> - Bước 1: cho vào ống nghiệm khô 2 mL isoamyl alcohol, 2 mL acetic acid nguyên chất và vài giọt H~2~SO~4~ đặc.
> - Bước 2: lắc đều, ngâm ống nghiệm trong cốc nước nóng 65–70 °C khoảng 10 phút.
> - Bước 3: làm lạnh, rồi rót hỗn hợp vào ống nghiệm chứa 4 mL dung dịch NaCl bão hoà.
>
> Xét các phát biểu sau:
>
> a) Sau bước 3, chất lỏng tách thành hai lớp, lớp phía trên có mùi chuối chín.
>
> b) H~2~SO~4~ đặc chỉ có vai trò làm xúc tác cho phản ứng.
>
> c) Dung dịch NaCl bão hoà được thêm vào để phản ứng với ester tạo kết tủa, giúp tách ester.
>
> d) Nếu dùng 8,8 g isoamyl alcohol (M = 88) với lượng dư acetic acid và thu được 9,1 g isoamyl acetate thì hiệu suất phản ứng ester hoá là 70%.

> [!goi-y] Gợi ý 1
> Ester nặng hay nhẹ hơn nước? Muối ăn bão hoà làm ester tan nhiều hơn hay ít hơn trong lớp nước?

> [!goi-y] Gợi ý 2
> Phản ứng ester hoá sinh ra nước và là phản ứng thuận nghịch. H~2~SO~4~ đặc còn tác động gì lên lượng nước đó?

> [!goi-y] Gợi ý 3
> Câu d: alcohol là chất thiếu. n(ester) lí thuyết = n(alcohol).

> [!loi-giai] Lời giải
> a) **Đúng**: isoamyl acetate ít tan và nhẹ hơn nước nên nổi thành lớp trên, có mùi chuối chín.
>
> b) **Sai**: H~2~SO~4~ đặc vừa là **xúc tác**, vừa **hút nước**, làm cân bằng chuyển dịch về phía tạo ester.
>
> c) **Sai**: NaCl **không phản ứng** với ester. Dung dịch NaCl bão hoà làm ester **ít tan** hơn trong lớp nước và làm lớp nước nặng hơn, nên ester tách lớp rõ hơn (giống vai trò của NaCl trong thí nghiệm xà phòng hoá ở Bài 2).
>
> d) **Đúng**: n(alcohol) = 8,8 : 88 = 0,1 mol → m(ester) lí thuyết = 0,1 · 130 = 13 g. H = 9,1 : 13 · 100% = **70%**.

> [!bay]
> Đừng nhầm hai thí nghiệm "anh em": trong **điều chế ester**, dùng H~2~SO~4~ **đặc** và acid/alcohol **nguyên chất** (càng ít nước càng tốt). Trong **thuỷ phân ester**, dùng H~2~SO~4~ **loãng** hoặc NaOH (cần nhiều nước). Trong **xà phòng hoá chất béo**, dùng NaOH đặc nhưng phải **thêm nước** trong lúc đun.

## 5. Đối chiếu bài tập ôn tập trong SGK

Phần Luyện tập ở SGK tr. 19 gồm 5 câu. Bảng dưới đây cho biết mỗi câu kiểm tra kiến thức gì và bẫy nằm ở đâu, kèm một câu tự luyện cùng dạng trong Ví dụ 6.

| Câu SGK | Kiểm tra gì | Cách làm nhanh | Bẫy |
|---|---|---|---|
| 1 | Gọi tên ester đơn giản | Tách tại –COO–: phần gắn với O đơn là R', đọc trước | Đọc ngược thứ tự |
| 2 | Tìm ester từ công thức phân tử + tên muối | Muối cho gốc acid; phần C còn lại thuộc R' | Chọn ester có gốc acid khác (propanoate, acetate…) |
| 3 | Phản ứng thuận nghịch | Chỉ thuỷ phân trong **acid** (và ester hoá) là thuận nghịch | Nhầm xà phòng hoá, hydrogen hoá |
| 4 | Đếm phát biểu đúng về ester, chất béo | Soát từng từ khoá: "tan tốt", "luôn", "một chiều"… | Chất béo **không** tan trong nước; thuỷ phân trong acid **không** một chiều |
| 5 | Phân loại xà phòng – chất giặt rửa tổng hợp | –COONa/–COOK là xà phòng; –SO~3~Na, –OSO~3~Na là tổng hợp | Muối **potassium** vẫn là xà phòng |

> [!vi-du] Ví dụ 6 (luyện nhanh 4 câu cùng dạng SGK)
> a) Gọi tên ester CH~3~COOCH~2~CH~2~CH~3~.
>
> b) Ester Y có mùi dứa, công thức phân tử C~6~H~12~O~2~. Thuỷ phân Y trong dung dịch NaOH thu được sodium butanoate và một alcohol. Viết công thức cấu tạo của Y.
>
> c) Trong các quá trình: (1) đun tristearin với dung dịch H~2~SO~4~ loãng; (2) đun methyl formate với dung dịch KOH; (3) đun acetic acid với methanol có H~2~SO~4~ đặc; (4) hydrogen hoá triolein. Quá trình nào là thuận nghịch?
>
> d) Phân loại: C~17~H~35~COOK; CH~3~[CH~2~]~13~OSO~3~Na; C~15~H~31~COONa; CH~3~[CH~2~]~9~C~6~H~4~SO~3~Na.

> [!goi-y] Gợi ý 1
> Câu b: sodium butanoate là CH~3~CH~2~CH~2~COONa (4 C). Y có 6 C, vậy gốc R' có mấy C?

> [!goi-y] Gợi ý 2
> Câu c: chỉ những phản ứng có mặt H^+^ và nước/acid–alcohol mới tạo được cân bằng hai chiều.

> [!loi-giai] Lời giải
> a) Gốc R' = CH~2~CH~2~CH~3~ (propyl), gốc acid = acetate → **propyl acetate**.
>
> b) Gốc acid có 4 C, R' có 6 − 4 = 2 C → Y = **CH~3~CH~2~CH~2~COOC~2~H~5~** (ethyl butanoate, mùi dứa).
>
> c) Thuận nghịch: **(1) và (3)** (thuỷ phân trong acid và ester hoá). (2) là xà phòng hoá, một chiều. (4) là hydrogen hoá, xét trong chương này là phản ứng một chiều (dầu lỏng → mỡ rắn).
>
> d) Xà phòng: C~17~H~35~COOK, C~15~H~31~COONa. Chất giặt rửa tổng hợp: CH~3~[CH~2~]~13~OSO~3~Na (alkylsulfate), CH~3~[CH~2~]~9~C~6~H~4~SO~3~Na (alkylbenzene sulfonate).

## Tóm tắt

**Các quan hệ tính toán của cả chương:**

| Tình huống | Quan hệ số mol | Bảo toàn khối lượng |
|---|---|---|
| Ester thường + NaOH | n(NaOH) = n(ester) = n(muối) = n(alcohol) | m(ester) + m(NaOH) = m(muối) + m(alcohol) |
| Ester của phenol + NaOH | n(NaOH) = 2n(ester) = 2n(H~2~O) | m(ester) + m(NaOH) = m(muối) + m(H~2~O) |
| Hỗn hợp ester thường + ester phenol | n(ester phenol) = n(NaOH) − n(hỗn hợp) | trừ cả alcohol và H~2~O |
| Chất béo + NaOH | n(NaOH) = n(muối) = 3n(chất béo) = 3n(glycerol) | m(béo) + m(NaOH) = m(muối) + m(glycerol) |
| Chất béo lẫn acid béo | n(NaOH) = 3n(béo) + n(acid); n(H~2~O) = n(acid) | thêm m(H~2~O) vào vế phải |
| Hydrogen hoá | n(H~2~) = tổng số C=C trong các gốc | m(sản phẩm) = m(chất béo) + m(H~2~) |
| Ester hoá | tính theo chất thiếu | H = m(thực tế) : m(lí thuyết) |
| Xà phòng thành phẩm | m(xà phòng) = m(muối) : a% | đi xuôi nhân H, đi ngược chia H |
| Cô cạn | chất rắn = muối + kiềm dư | alcohol, nước bay hơi |

**Bảng M hay dùng:** ethyl acetate 88; methyl/ethyl formate 60/74; phenyl acetate 136; glycerol 92; tristearin 890, tripalmitin 806, triolein 884; muối Na: stearate 306, palmitate 278, oleate 304; C~6~H~5~ONa 116; CH~3~COONa 82; HCOONa 68.

**Quy trình 4 bước cho bài ester – chất béo:**

1. **Nhận diện loại ester** (thường, phenol, vinyl, formate, chất béo) → biết tỉ lệ NaOH và sản phẩm phụ.
2. **Tính số mol** các chất đã biết; so sánh để tìm chất dư hoặc phát hiện ester của phenol (tỉ lệ k).
3. **Lập hệ** khi là hỗn hợp: một phương trình theo khối lượng, một theo số mol NaOH (hoặc theo sản phẩm).
4. **Kiểm tra bằng bảo toàn khối lượng**, nhớ đủ: kiềm dư, alcohol, nước, glycerol.
