---
title: Amine
thoi-gian: 50 phút
muc-tieu:
  - Nêu được amine là gì; xác định được bậc amine và phân biệt alkylamine với arylamine.
  - Viết được công thức cấu tạo các đồng phân, gọi được tên amine (có không quá 5 nguyên tử C) theo danh pháp gốc – chức, danh pháp thay thế và tên thông thường (aniline).
  - Giải thích được đặc điểm vật lí của amine (trạng thái, nhiệt độ sôi, khả năng tan) dựa vào liên kết hydrogen.
  - Mô tả được cấu tạo của methylamine, aniline và dùng cặp electron chưa liên kết trên N để giải thích tính base (mở rộng: so sánh lực base của các amine thường gặp).
  - Trình bày, mô tả hiện tượng và viết được phương trình các phản ứng: với quỳ tím, HCl, FeCl~3~, tạo phức với Cu(OH)~2~, với nitrous acid, aniline với nước bromine.
  - Nêu được ứng dụng của aniline, diamine và hai cách điều chế amine; giải được bài toán amine + acid, đốt cháy amine, aniline + bromine.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Amine** = NH~3~ bị thay H bằng gốc hydrocarbon. **Bậc amine = số gốc hydrocarbon gắn vào N** (1, 2 hoặc 3), không phải bậc của nguyên tử C.
> 2. Hai cách gọi tên: **gốc – chức** (tên gốc + amine: methylamine, dimethylamine) và **thay thế** (tên mạch chính bỏ "e" + vị trí + amine: methanamine, N-methylmethanamine). Riêng C~6~H~5~NH~2~ gọi là **aniline**.
> 3. Nguyên tử N còn **một cặp electron chưa liên kết** → amine nhận H^+^ → có **tính base yếu**. Aniline **không** làm quỳ tím đổi màu. (Mở rộng) Lực base: C~6~H~5~NH~2~ < NH~3~ < CH~3~NH~2~ < (CH~3~)~2~NH.
> 4. Phản ứng đặc trưng: với acid tạo muối; với FeCl~3~ tạo Fe(OH)~3~ nâu đỏ; CH~3~NH~2~ hoà tan Cu(OH)~2~ tạo phức **xanh lam**; alkylamine bậc một + HNO~2~ → alcohol + **N~2~↑**; aniline + nước bromine → **kết tủa trắng** 2,4,6-tribromoaniline.
> 5. Bài toán: amine đơn chức + HCl thì n(amine) = n(HCl), m(muối) = m(amine) + m(HCl). Đốt amine no, đơn chức, mạch hở: n(amine) = [n(H~2~O) − n(CO~2~)] : 1,5.

Bài này mở đầu **Chương 3 – Hợp chất chứa nitrogen**. Chương gồm amine, amino acid, peptide và protein. Đây là những chất có trong thuốc, thuốc nhuộm, tơ nylon, và cả trong cơ thể em. Amine là "viên gạch" đầu tiên: hiểu kĩ nhóm –NH~2~ ở bài này thì sang amino acid và protein (Bài 9, 10) sẽ thấy rất quen.

## 1. Khái niệm, phân loại, đồng phân và danh pháp

### 1.1. Khái niệm

Em đã biết phân tử **ammonia** NH~3~: một nguyên tử N liên kết với 3 nguyên tử H. Nếu ta lần lượt thay các nguyên tử H đó bằng **gốc hydrocarbon** (CH~3~–, C~2~H~5~–, C~6~H~5~–…) thì thu được **amine**.

> **Amine** là dẫn xuất của ammonia, trong đó một hoặc nhiều nguyên tử H của NH~3~ được thay bằng gốc hydrocarbon.

Ví dụ: CH~3~NH~2~ (thay 1 H), CH~3~NHCH~3~ (thay 2 H), (CH~3~)~3~N (thay cả 3 H). Nhóm –NH~2~ gọi là **nhóm amine** (nhóm amino).

> [!nen-tang] Hoá trị và cặp electron của N (lớp 10)
> - N có 5 electron lớp ngoài cùng. Trong NH~3~, N dùng 3 electron tạo 3 liên kết, còn lại **1 cặp electron chưa liên kết**.
> - Cặp electron này có thể "cho" vào ion H^+^ để tạo liên kết mới: NH~3~ + H^+^ → NH~4~^+^. Đó chính là lí do NH~3~ là base.
> - Amine giữ nguyên "bộ khung" này của NH~3~, nên cũng có cặp electron chưa liên kết trên N (mục 2).

### 1.2. Phân loại

**a) Theo bậc amine.** Bậc của amine bằng **số gốc hydrocarbon liên kết trực tiếp với nguyên tử N**.

- Amine **bậc một**: R–NH~2~ (N gắn 1 gốc).
- Amine **bậc hai**: R–NH–R′ (N gắn 2 gốc).
- Amine **bậc ba**: R–N(R′)–R″ (N gắn 3 gốc).

**b) Theo gốc hydrocarbon.** Hai loại điển hình:

- **Alkylamine**: N gắn với **gốc alkyl** (gốc no), ví dụ CH~3~NH~2~, C~2~H~5~NH~2~.
- **Arylamine**: N gắn **trực tiếp vào nguyên tử C của vòng benzene**, ví dụ aniline C~6~H~5~NH~2~.

![Hình 1. a) Bậc amine tính theo số gốc hydrocarbon gắn vào N; b) alkylamine và arylamine](bac-amine.svg)

> [!bay]
> - **Bậc amine khác bậc carbon.** Trong CH~3~–CH(NH~2~)–CH~3~ (isopropylamine), nhóm NH~2~ gắn vào C bậc hai, nhưng N chỉ gắn **1 gốc** (isopropyl) nên đây là amine **bậc một**. Còn (CH~3~)~3~C–NH~2~ cũng là amine bậc một.
> - **Benzylamine** C~6~H~5~CH~2~NH~2~ có vòng benzene nhưng N gắn vào nhóm CH~2~, không gắn trực tiếp vào vòng, nên **không** phải arylamine.

> [!vi-du] Ví dụ 1
> Xác định bậc amine và cho biết chất nào là alkylamine, chất nào là arylamine:
>
> (1) CH~3~–NH–C~2~H~5~; (2) (C~2~H~5~)~3~N; (3) C~6~H~5~–NH–CH~3~; (4) CH~3~–CH(NH~2~)–CH~2~–CH~3~.

> [!goi-y] Gợi ý 1
> Đếm số gốc hydrocarbon nối thẳng vào N, đừng nhìn vào C mang nhóm N.

> [!goi-y] Gợi ý 2
> Với chất (3): N gắn với những gốc nào? Có gốc nào là vòng benzene gắn trực tiếp vào N không?

> [!loi-giai] Lời giải
> (1) N gắn CH~3~ và C~2~H~5~ → **bậc hai**, alkylamine.
>
> (2) N gắn 3 gốc C~2~H~5~ → **bậc ba**, alkylamine.
>
> (3) N gắn C~6~H~5~ và CH~3~ → **bậc hai**. Vì N gắn trực tiếp vào vòng benzene nên đây là **arylamine** (tên N-methylaniline).
>
> (4) N chỉ gắn 1 gốc (butan-2-yl) → **bậc một**, alkylamine, dù C mang nhóm NH~2~ là C bậc hai.

### 1.3. Đồng phân

Amine có **từ 2 nguyên tử C** trở lên mới có đồng phân (CH~5~N chỉ có một chất là CH~3~NH~2~). Có ba kiểu đồng phân:

1. **Đồng phân bậc amine**: cùng công thức phân tử nhưng N gắn số gốc khác nhau. Ví dụ C~2~H~7~N có CH~3~CH~2~NH~2~ (bậc một) và CH~3~NHCH~3~ (bậc hai).
2. **Đồng phân mạch carbon**: mạch thẳng hay mạch nhánh.
3. **Đồng phân vị trí nhóm amine**: nhóm NH~2~ gắn vào C khác nhau trên cùng mạch.

> [!meo] Đếm đồng phân amine no, đơn chức, mạch hở theo bậc
> Viết lần lượt theo bậc, mỗi bậc là một "cách chia" số C cho các gốc quanh N:
> - **Bậc một** R–NH~2~: số đồng phân = số gốc R có (n) nguyên tử C.
> - **Bậc hai** R–NH–R′: chia n nguyên tử C thành 2 gốc (mỗi gốc ≥ 1 C).
> - **Bậc ba**: chia n nguyên tử C thành 3 gốc.
>
> Kết quả cần nhớ: **CH~5~N: 1; C~2~H~7~N: 2; C~3~H~9~N: 4; C~4~H~11~N: 8.**

> [!vi-du] Ví dụ 2
> Viết công thức cấu tạo các amine có công thức phân tử C~4~H~11~N. Có bao nhiêu amine bậc một, bậc hai, bậc ba?

> [!goi-y] Gợi ý 1
> Bậc một: gốc C~4~H~9~– có mấy cấu tạo? (mạch thẳng, nhánh; NH~2~ ở đầu hay giữa mạch).

> [!goi-y] Gợi ý 2
> Bậc hai: chia 4 C thành 2 gốc: 1 + 3 (gốc C~3~ có 2 dạng) và 2 + 2. Bậc ba: chia 4 C thành 3 gốc: 1 + 1 + 2.

> [!loi-giai] Lời giải
> **Bậc một (4 chất):** CH~3~CH~2~CH~2~CH~2~NH~2~; CH~3~CH~2~CH(NH~2~)CH~3~; (CH~3~)~2~CHCH~2~NH~2~; (CH~3~)~3~CNH~2~.
>
> **Bậc hai (3 chất):** CH~3~NHCH~2~CH~2~CH~3~; CH~3~NHCH(CH~3~)~2~; CH~3~CH~2~NHCH~2~CH~3~.
>
> **Bậc ba (1 chất):** (CH~3~)~2~NCH~2~CH~3~.
>
> Tổng cộng **8 đồng phân**: 4 bậc một, 3 bậc hai, 1 bậc ba.

### 1.4. Danh pháp

SGK dùng hai cách gọi tên cho amine đơn chức (SGK tr. 36).

**a) Danh pháp gốc – chức**

> **Tên gốc hydrocarbon + amine**

- Có nhiều gốc khác nhau thì viết tên các gốc **theo thứ tự chữ cái** (bỏ qua tiền tố di-, tri- khi xếp). Ví dụ: ethyl đứng trước methyl, methyl đứng trước propyl.
- Gốc lặp lại thì dùng di-, tri-: (CH~3~)~2~NH là **dimethylamine**, (CH~3~)~3~N là **trimethylamine**.
- Ví dụ: CH~3~NH~2~ methylamine; C~2~H~5~NH~2~ ethylamine; CH~3~CH(NH~2~)CH~3~ isopropylamine; C~2~H~5~N(CH~3~)~2~ ethyldimethylamine.

**b) Danh pháp thay thế**

> **(Tên nhóm thế) + tên hydrocarbon mạch chính bỏ "e" + vị trí nhóm amine + amine**

Các bước:

1. Chọn **mạch chính** là mạch carbon dài nhất có gắn với N.
2. Đánh số mạch chính từ đầu **gần N hơn**.
3. Các gốc còn lại gắn vào N là **nhóm thế**, dùng chữ **N** làm chỉ số vị trí (thay cho con số). Nhóm thế trên mạch chính dùng chỉ số là số.
4. Ghép tên: tên mạch chính bỏ chữ "e" cuối (methane → methan, propane → propan), rồi thêm vị trí nhóm amine và chữ amine.

Ví dụ: CH~3~NH~2~ là **methanamine**; CH~3~CH(NH~2~)CH~3~ là **propan-2-amine**; CH~3~NHCH~3~ là **N-methylmethanamine**.

![Hình 2. Gọi tên CH~3~CH~2~CH~2~NHCH~3~ theo hai cách](danh-phap.svg)

**c) Tên thông thường.** Một số amine có tên riêng hay dùng. Quan trọng nhất là **aniline** C~6~H~5~NH~2~ (tên thay thế là benzenamine, nhưng SGK và đề thi dùng aniline).

> [!bay]
> - Tên thay thế **bỏ "e"** của hydrocarbon: viết "ethanamine", không viết "ethaneamine".
> - Ở amine bậc hai, bậc ba, mạch chính là mạch **dài nhất**: CH~3~NHCH~2~CH~2~CH~3~ là N-methyl**propan**-1-amine, không phải N-propylmethanamine.
> - Có hai nhóm thế giống nhau trên N thì ghi **N,N-**: (CH~3~)~2~NC~2~H~5~ là **N,N-dimethylethanamine**.

> [!vi-du] Ví dụ 3
> a) Gọi tên theo hai cách: (CH~3~)~2~CHCH~2~NH~2~; CH~3~CH~2~NHCH~2~CH~3~; CH~3~CH~2~N(CH~3~)~2~.
>
> b) Viết công thức cấu tạo của N-methylpropan-2-amine. Đây là amine bậc mấy?

> [!goi-y] Gợi ý 1
> Gốc (CH~3~)~2~CHCH~2~– có tên gốc là **isobutyl**. Với tên thay thế, mạch chính của chất đầu là mạch 3 C (đánh số từ C gắn N), có nhánh CH~3~ ở C2.

> [!goi-y] Gợi ý 2
> b) "propan-2-amine": nhóm N gắn vào C2 của mạch 3 C. "N-methyl": trên N có thêm một nhóm CH~3~.

> [!loi-giai] Lời giải
> a)
>
> | Chất | Gốc – chức | Thay thế |
> |---|---|---|
> | (CH~3~)~2~CHCH~2~NH~2~ | isobutylamine | 2-methylpropan-1-amine |
> | CH~3~CH~2~NHCH~2~CH~3~ | diethylamine | N-ethylethanamine |
> | CH~3~CH~2~N(CH~3~)~2~ | ethyldimethylamine | N,N-dimethylethanamine |
>
> b) CH~3~–NH–CH(CH~3~)–CH~3~. N gắn 2 gốc (methyl và isopropyl) nên là amine **bậc hai** (tên gốc – chức: isopropylmethylamine).

## 2. Đặc điểm cấu tạo

Trong phân tử amine, nguyên tử N vẫn **còn một cặp electron chưa liên kết**, giống hệt trong NH~3~ (SGK tr. 37, Hình 8.1 có mô hình methylamine và aniline).

- **Methylamine** CH~3~NH~2~: giống NH~3~ nhưng một H được thay bằng CH~3~. Do cấu tạo tương tự NH~3~, amine có các tính chất hoá học giống NH~3~: **tính base**, phản ứng với acid, với dung dịch muối, tạo phức với Cu^2+^.
- **Aniline** C~6~H~5~NH~2~: nhóm NH~2~ gắn trực tiếp vào vòng benzene. Hai phần này **ảnh hưởng qua lại**:
  - Cặp electron của N bị kéo một phần vào vòng benzene, nên N "nghèo" electron hơn → **tính base của aniline rất yếu**.
  - Ngược lại, vòng benzene được N "đẩy" thêm electron (nhất là ở các vị trí *ortho* và *para*), nên aniline **dễ tham gia phản ứng thế H trên vòng** hơn benzene (mục 4.3).

> [!meo] Một cặp electron – hai hệ quả
> Cặp electron trên N là "chìa khoá" của cả bài:
> - Cặp electron **sẵn sàng nhận H^+^** → tính base (mục 4.1).
> - Cặp electron **đẩy vào vòng** benzene → aniline dễ thế bromine (mục 4.3), nhưng base yếu hẳn.

## 3. Tính chất vật lí

Bảng 8.1 trong SGK (tr. 37) cho nhiệt độ nóng chảy, nhiệt độ sôi của một số amine. Một vài số liệu đáng nhớ:

| Chất | Nhiệt độ sôi (°C) | Trạng thái ở 25 °C |
|---|---|---|
| CH~3~NH~2~ (methylamine) | −6,4 | khí |
| (CH~3~)~3~N (trimethylamine) | 2,8 | khí |
| C~2~H~5~NH~2~ (ethylamine) | 16,6 | khí |
| CH~3~CH~2~CH~2~NH~2~ (propylamine) | 47,2 | lỏng |
| C~6~H~5~NH~2~ (aniline) | 184,1 | lỏng |

**Cách đọc trạng thái từ bảng:** chất có nhiệt độ sôi **dưới 25 °C** thì ở nhiệt độ phòng đã sôi rồi, tức là **chất khí**. Vì vậy **methylamine, dimethylamine, trimethylamine và ethylamine là chất khí**. Chúng có mùi khai giống ammonia, hoặc mùi tanh của cá (tuỳ nồng độ).

**Vì sao amine sôi cao hơn hydrocarbon có phân tử khối tương đương?** Nhóm N–H tạo được **liên kết hydrogen** giữa các phân tử amine (N–H···N). Muốn đun sôi, ta phải phá thêm các liên kết này. Ví dụ, ethylamine (M = 45) sôi ở 16,6 °C, còn propane (M = 44) sôi ở khoảng −42 °C.

**Vì sao propylamine sôi ở 47,2 °C mà trimethylamine (cùng C~3~H~9~N) chỉ sôi ở 2,8 °C?** Trimethylamine là amine bậc ba, N **không còn H**, nên các phân tử không tạo được liên kết hydrogen với nhau.

**Khả năng tan.** Các amine ít C tan tốt trong nước, vì N (và N–H) tạo **liên kết hydrogen với nước**. Gốc hydrocarbon thì "ghét nước", nên **khi số C tăng, độ tan giảm**. **Aniline** là chất lỏng, **ít tan** trong nước.

> [!bay]
> - Liên kết hydrogen N–H···N **yếu hơn** O–H···O. Vì vậy amine sôi **thấp hơn** alcohol có phân tử khối tương đương: ethylamine (16,6 °C) sôi thấp hơn hẳn ethanol (78 °C).
> - Thứ tự nhiệt độ sôi thường gặp: hydrocarbon < amine < alcohol < carboxylic acid (khi phân tử khối xấp xỉ nhau).

> [!em-co-biet] Aniline "biến màu"
> Aniline mới cất không màu, nhưng để lâu ngoài không khí sẽ ngả vàng rồi nâu, do bị oxi hoá chậm. Aniline cũng rất độc, có thể thấm qua da. Khi làm thí nghiệm cần đeo găng tay.

## 4. Tính chất hoá học

### 4.1. Tính base và phản ứng tạo phức

**a) Vì sao amine là base?** Theo thuyết Brønsted – Lowry (lớp 11), base là chất **nhận H^+^**. Cặp electron chưa liên kết trên N của amine nhận H^+^ giống như NH~3~:

=> CH~3~NH~2~ + H~2~O ⇌ CH~3~NH~3~^+^ + OH^−^

Dung dịch có ion OH^−^ nên có tính base, nhưng chỉ là **base yếu** (phản ứng thuận nghịch).

- Dung dịch **alkylamine** (methylamine, ethylamine…) làm **quỳ tím hoá xanh**, phenolphthalein hoá hồng.
- Dung dịch **aniline không làm đổi màu quỳ tím** (base quá yếu).

**b) So sánh lực base (mở rộng).** SGK chỉ nêu amine là base yếu, alkylamine làm quỳ hoá xanh còn aniline thì không; phần so sánh dưới đây là kiến thức bổ sung, giúp em hiểu vì sao và làm được các câu so sánh còn gặp trong đề tham khảo. Lực base phụ thuộc vào cặp electron trên N **có "sẵn sàng" nhận H^+^ hay không**:

- **Gốc alkyl** (CH~3~–, C~2~H~5~–…) **đẩy electron** về phía N → N giàu electron hơn → base **mạnh hơn** NH~3~. Hai gốc alkyl đẩy nhiều hơn một gốc.
- **Gốc phenyl** C~6~H~5~– **kéo** cặp electron của N vào vòng → base **yếu hơn** NH~3~ rất nhiều.

![Hình 3. Thang tính base: gốc alkyl làm tăng, gốc phenyl làm giảm tính base so với NH~3~](tinh-base.svg)

> [!ghi-nho] Thứ tự cần thuộc
> **(C~6~H~5~)~2~NH < C~6~H~5~NH~2~ < NH~3~ < CH~3~NH~2~ < (CH~3~)~2~NH < NaOH**
>
> Tương tự: C~2~H~5~NH~2~ < (C~2~H~5~)~2~NH. Amine nào cũng là base **yếu hơn** NaOH, KOH.

> [!bay]
> - Không suy ra "bậc càng cao base càng mạnh" cho amine **bậc ba**. Trong nước, trimethylamine lại yếu hơn methylamine và dimethylamine (ion tạo ra khó được nước "ôm" giữ bền). Đề thi thường chỉ so sánh **bậc một với bậc hai** cùng loại gốc, hoặc so với NH~3~ và aniline.
> - "Aniline không làm quỳ tím đổi màu" **không** có nghĩa aniline không có tính base: aniline vẫn tác dụng với HCl.

**c) Phản ứng với acid → muối**

=> CH~3~NH~2~ + HCl → CH~3~NH~3~Cl    (methylammonium chloride)

=> C~6~H~5~NH~2~ + HCl → C~6~H~5~NH~3~Cl    (phenylammonium chloride)

Nhóm NH~2~ chỉ việc "nhận thêm" một H^+^, **không** tạo ra nước. Vì vậy **khối lượng muối = khối lượng amine + khối lượng acid**. Đây là chìa khoá của bài toán amine + HCl (Dạng 3).

Trong thí nghiệm SGK (tr. 38): dung dịch methylamine có phenolphthalein màu hồng. Khi nhỏ từ từ lượng HCl vừa đủ (cùng thể tích, cùng nồng độ) vào, **màu hồng nhạt dần rồi mất**, vì base đã bị acid trung hoà.

> [!ung-dung] Khử mùi tanh của cá bằng giấm, chanh
> Mùi tanh của cá chủ yếu do **trimethylamine** (và một số amine khác) gây ra. Các amine này là base, nên khi rửa cá bằng giấm (CH~3~COOH) hoặc nước chanh, chúng chuyển thành **muối** không bay hơi và tan trong nước, bị rửa trôi:
>
> => (CH~3~)~3~N + CH~3~COOH → [(CH~3~)~3~NH]^+^CH~3~COO^−^

> [!em-co-biet] Lấy lại amine từ muối
> Muối amine gặp kiềm mạnh thì giải phóng lại amine (base mạnh đẩy base yếu ra khỏi muối):
>
> => C~6~H~5~NH~3~Cl + NaOH → C~6~H~5~NH~2~ + NaCl + H~2~O
>
> Ống nghiệm dính aniline (ít tan trong nước) được tráng bằng dung dịch HCl trước: aniline thành muối tan, rồi rửa lại bằng nước là sạch.

**d) Phản ứng với dung dịch muối của kim loại.** Dung dịch alkylamine có OH^−^ nên tạo kết tủa hydroxide với một số ion kim loại, giống NH~3~. Với FeCl~3~ thấy **kết tủa nâu đỏ** Fe(OH)~3~:

=> FeCl~3~ + 3CH~3~NH~2~ + 3H~2~O → Fe(OH)~3~↓ + 3CH~3~NH~3~Cl

**e) Phản ứng tạo phức với Cu(OH)~2~.** Thêm từ từ dung dịch methylamine vào dung dịch muối Cu^2+^:

- Lúc đầu xuất hiện **kết tủa xanh** Cu(OH)~2~:

=> CuCl~2~ + 2CH~3~NH~2~ + 2H~2~O → Cu(OH)~2~↓ + 2CH~3~NH~3~Cl

- Thêm methylamine dư, kết tủa **tan dần**, tạo **dung dịch phức màu xanh lam**:

=> Cu(OH)~2~ + 4CH~3~NH~2~ → \[Cu(CH~3~NH~2~)~4~\](OH)~2~

**Vì sao kết tủa tan?** Mỗi phân tử CH~3~NH~2~ dùng cặp electron trên N "cho" vào ion Cu^2+^, giống hệt NH~3~ trong nước Schweizer (Bài 6). Ethylamine cũng có phản ứng này.

> [!bay]
> Đề hay cho phản ứng này lẫn với phản ứng của glucose, glycerol với Cu(OH)~2~ (cũng xanh lam). Với amine, xanh lam là do **phức của Cu^2+^ với N**; với polyalcohol là do các nhóm –OH kề nhau.

> [!vi-du] Ví dụ 4
> Sắp xếp theo chiều **tăng dần** tính base: (1) NH~3~; (2) C~6~H~5~NH~2~; (3) (C~2~H~5~)~2~NH; (4) C~2~H~5~NH~2~; (5) NaOH. Trong các chất (1)–(4), dung dịch chất nào không làm quỳ tím hoá xanh?

> [!goi-y] Gợi ý 1
> Lấy NH~3~ làm mốc. Gốc nào đẩy electron vào N (mạnh hơn mốc), gốc nào kéo electron ra (yếu hơn mốc)?

> [!goi-y] Gợi ý 2
> NaOH là base mạnh, phân li hoàn toàn, mạnh hơn mọi amine.

> [!loi-giai] Lời giải
> Thứ tự tăng dần: **(2) C~6~H~5~NH~2~ < (1) NH~3~ < (4) C~2~H~5~NH~2~ < (3) (C~2~H~5~)~2~NH < (5) NaOH.**
>
> Giải thích: phenyl kéo electron làm aniline yếu hơn NH~3~; một gốc ethyl đẩy electron làm ethylamine mạnh hơn NH~3~; hai gốc ethyl đẩy nhiều hơn nên diethylamine mạnh hơn ethylamine.
>
> Chất không làm quỳ tím hoá xanh: **aniline**.

### 4.2. Phản ứng với nitrous acid (HNO~2~)

Nitrous acid HONO (hay HNO~2~) phản ứng khác nhau với từng loại amine. SGK nêu hai trường hợp:

**a) Alkylamine bậc một, ở nhiệt độ thường** → **alcohol** + **khí N~2~** + H~2~O:

=> CH~3~NH~2~ + HONO → CH~3~OH + N~2~↑ + H~2~O

Hiện tượng: có **bọt khí không màu** thoát ra. Phản ứng này dùng để **nhận biết alkylamine bậc một**.

Quy luật: nhóm –NH~2~ được thay bằng –OH (cùng gốc R), và **1 mol amine bậc một cho 1 mol N~2~**.

**b) Aniline, ở nhiệt độ thấp (0 – 5 °C), có HCl** → **muối diazonium**:

=> C~6~H~5~NH~2~ + HONO + HCl → \[C~6~H~5~N~2~\]^+^Cl^−^ + 2H~2~O    (0 – 5 °C)

Muối diazonium là nguyên liệu tổng hợp **phẩm nhuộm azo** và dược phẩm. Phải giữ lạnh vì ở nhiệt độ cao muối này bị phân huỷ.

> [!bay]
> - Giải phóng N~2~ ở nhiệt độ thường là dấu hiệu của **alkylamine bậc một**. Amine bậc hai, bậc ba **không** cho khí N~2~ với HNO~2~.
> - Aniline + HNO~2~ (0 – 5 °C) tạo **muối diazonium**, không tạo alcohol. Đừng nhầm hai trường hợp.

> [!vi-du] Ví dụ 5
> Cho 5,9 g một amine no, đơn chức, mạch hở X tác dụng hết với nitrous acid ở nhiệt độ thường, thu được 2,479 L khí N~2~ (đkc). Xác định công thức phân tử và viết các công thức cấu tạo có thể có của X.

> [!goi-y] Gợi ý 1
> X cho khí N~2~ với HNO~2~ ở nhiệt độ thường thì X thuộc loại amine nào? Tỉ lệ mol X : N~2~ bằng bao nhiêu?

> [!goi-y] Gợi ý 2
> Ở đkc (25 °C, 1 bar), 1 mol khí chiếm 24,79 L. Tính M, rồi tìm amine no đơn chức C~n~H~2n+3~N có M đó.

> [!loi-giai] Lời giải
> X là alkylamine bậc một, n(X) = n(N~2~) = 2,479 : 24,79 = 0,1 mol.
>
> M(X) = 5,9 : 0,1 = 59 → 14n + 17 = 59 → n = 3. X là **C~3~H~9~N**.
>
> X bậc một nên có 2 cấu tạo: CH~3~CH~2~CH~2~NH~2~ (propylamine) và CH~3~CH(NH~2~)CH~3~ (isopropylamine).

### 4.3. Phản ứng của aniline với nước bromine

**Thí nghiệm (SGK tr. 39):** cho vài giọt dung dịch aniline vào nước bromine. Màu vàng nâu của bromine nhạt đi, đồng thời xuất hiện **kết tủa trắng**.

**Giải thích:** nhóm –NH~2~ đẩy electron vào vòng benzene, làm các vị trí *ortho* (2, 6) và *para* (4) rất "giàu" electron. Vì vậy aniline thế H **dễ hơn benzene rất nhiều**: không cần xúc tác, ở nhiệt độ thường, thế **ngay cả 3 nguyên tử H** ở các vị trí 2, 4, 6.

=> C~6~H~5~NH~2~ + 3Br~2~ → C~6~H~2~Br~3~NH~2~↓ + 3HBr

![Hình 4. Aniline thế bromine ở hai vị trí ortho (o) và vị trí para (p), tạo 2,4,6-tribromoaniline kết tủa trắng](brom-aniline.svg)

> [!meo] Tỉ lệ cần nhớ
> 1 aniline (M = 93) + **3** Br~2~ → **1** kết tủa C~6~H~2~Br~3~NH~2~ (M = 330) + **3** HBr. Mỗi H bị thế làm khối lượng tăng 80 − 1 = 79, nên 93 + 3 · 79 = 330.

> [!bay]
> - Benzene **không** làm mất màu nước bromine ở điều kiện thường, còn aniline thì có. Phản ứng này dùng để **nhận biết aniline** (và phenol, cũng cho kết tủa trắng).
> - Số mol Br~2~ phản ứng gấp **3 lần** số mol aniline.

> [!vi-du] Ví dụ 6
> Nhỏ nước bromine dư vào dung dịch chứa m gam aniline, thu được 6,6 g kết tủa trắng. Tính m và số mol Br~2~ đã phản ứng.

> [!goi-y] Gợi ý 1
> Kết tủa là 2,4,6-tribromoaniline, M = 330. Tỉ lệ mol aniline : kết tủa = 1 : 1.

> [!goi-y] Gợi ý 2
> Mỗi phân tử aniline cần mấy phân tử Br~2~?

> [!loi-giai] Lời giải
> n(kết tủa) = 6,6 : 330 = 0,02 mol → n(aniline) = 0,02 mol.
>
> m = 0,02 · 93 = **1,86 g**. n(Br~2~) = 3 · 0,02 = **0,06 mol**.

## 5. Ứng dụng

- **Aniline** là nguyên liệu quan trọng của công nghiệp **phẩm nhuộm** (phẩm nhuộm azo, qua muối diazonium), **dược phẩm** (như **paracetamol**, các thuốc **sulfonamide** kháng khuẩn) và **polymer**.
- Một số **diamine** dùng sản xuất tơ sợi. Ví dụ **hexamethylenediamine** H~2~N[CH~2~]~6~NH~2~ là nguyên liệu tổng hợp **tơ nylon-6,6** (sẽ học ở chương Polymer).

> [!ung-dung] Từ aniline đến viên thuốc hạ sốt
> Paracetamol, thuốc giảm đau, hạ sốt quen thuộc, có khung là vòng benzene gắn nhóm chứa N. Trong công nghiệp, nó được tổng hợp từ các dẫn xuất của aniline. Nhiều loại thuốc nhuộm vải, mực in cũng bắt nguồn từ aniline.

## 6. Điều chế

### 6.1. Alkyl hoá ammonia (điều chế alkylamine)

Cho NH~3~ tác dụng với **dẫn xuất halogen** (ví dụ CH~3~I). Gốc CH~3~ lần lượt thay thế các nguyên tử H trên N, mỗi lần tách ra một phân tử HI:

=> NH~3~ + CH~3~I → CH~3~NH~2~ + HI

=> CH~3~NH~2~ + CH~3~I → (CH~3~)~2~NH + HI

=> (CH~3~)~2~NH + CH~3~I → (CH~3~)~3~N + HI

Thực tế thường thu được **hỗn hợp** amine bậc một, hai, ba; tỉ lệ phụ thuộc lượng chất ban đầu.

### 6.2. Khử hợp chất nitro (điều chế aniline, arylamine)

Khử **nitrobenzene** bằng hydrogen mới sinh, tạo ra khi cho kim loại (Fe, Zn…) tác dụng với dung dịch HCl, đun nóng:

=> C~6~H~5~NO~2~ + 6[H] → C~6~H~5~NH~2~ + 2H~2~O    (Fe + HCl, t°)

Kí hiệu [H] là hydrogen nguyên tử mới sinh, có tính khử mạnh. Vì môi trường có HCl dư, aniline tạo ra ở dạng muối C~6~H~5~NH~3~Cl; sau đó thêm kiềm để giải phóng aniline.

> [!vi-du] Ví dụ 7
> Khử 24,6 g nitrobenzene bằng Fe trong dung dịch HCl (rồi kiềm hoá), hiệu suất 80%. Tính khối lượng aniline thu được.

> [!goi-y] Gợi ý 1
> M(C~6~H~5~NO~2~) = 123. Tỉ lệ mol nitrobenzene : aniline = 1 : 1.

> [!goi-y] Gợi ý 2
> Đi từ chất đầu ra sản phẩm thì **nhân** hiệu suất.

> [!loi-giai] Lời giải
> n(C~6~H~5~NO~2~) = 24,6 : 123 = 0,2 mol → n(aniline) lí thuyết = 0,2 mol.
>
> m(aniline) = 0,2 · 93 · 0,8 = **14,88 g**.

## Dạng bài thi hay gặp

### Dạng 1. Bậc amine, gọi tên, đếm đồng phân

**Nhận biết:** đề cho công thức phân tử, hỏi số đồng phân (tổng hoặc theo bậc); cho công thức cấu tạo, hỏi tên; hoặc cho tên, hỏi bậc amine.

**Phương pháp:**

1. Đếm đồng phân theo **bậc**: bậc một (gốc R có n C), bậc hai (chia C thành 2 gốc), bậc ba (chia C thành 3 gốc). Nhớ nhanh: C~2~H~7~N: 2; C~3~H~9~N: 4; C~4~H~11~N: 8.
2. Bậc amine = **số gốc gắn vào N** (đọc tên thay thế: "N-…" là có thêm gốc trên N).
3. Với chất có vòng benzene, xét riêng: N gắn trực tiếp vào vòng (arylamine) hay qua nhóm CH~2~.

> [!vi-du] Ví dụ 8
> Có bao nhiêu amine chứa vòng benzene có công thức phân tử C~7~H~9~N? Trong đó có bao nhiêu arylamine?

> [!goi-y] Gợi ý 1
> Ngoài vòng C~6~ chỉ còn 1 nguyên tử C và 1 nguyên tử N. C đó có thể nằm ở đâu: giữa vòng và N, gắn vào N, hay gắn vào vòng?

> [!goi-y] Gợi ý 2
> Nếu CH~3~ và NH~2~ cùng gắn vào vòng, chúng có thể ở vị trí *ortho*, *meta*, *para* với nhau.

> [!loi-giai] Lời giải
> - C nằm giữa vòng và N: C~6~H~5~CH~2~NH~2~ (benzylamine). N không gắn vào vòng → **alkylamine**.
> - C gắn vào N: C~6~H~5~NHCH~3~ (N-methylaniline, bậc hai, arylamine).
> - C gắn vào vòng: CH~3~C~6~H~4~NH~2~ có 3 đồng phân vị trí *o*, *m*, *p* (arylamine bậc một).
>
> Tổng cộng **5 amine**, trong đó **4 arylamine**.

> [!bay]
> - Đếm nhầm (CH~3~)~3~C–NH~2~ thành amine bậc ba: N chỉ gắn **1** gốc nên là bậc **một**.
> - Đề hỏi "amine bậc một" thì chỉ đếm R–NH~2~; đề hỏi "đồng phân cấu tạo" thì đếm cả ba bậc.

### Dạng 2. Nhận biết bằng quỳ tím, so sánh tính base (mở rộng)

**Nhận biết:** đề cho dãy chất (NH~3~, aniline, các alkylamine, NaOH), hỏi thứ tự lực base, hoặc đếm số dung dịch làm quỳ tím hoá xanh.

**Phương pháp:**

1. Lấy **NH~3~ làm mốc**.
2. Gốc **alkyl đẩy electron** → mạnh hơn NH~3~ (hai gốc mạnh hơn một gốc).
3. Gốc **phenyl kéo electron** → yếu hơn NH~3~ (hai gốc phenyl còn yếu hơn nữa).
4. Base mạnh (NaOH, KOH) đứng cuối dãy.
5. Quỳ tím: dung dịch NH~3~ và alkylamine → **xanh**; dung dịch aniline → **không đổi màu**.

Xem Ví dụ 4 ở mục 4.1.

> [!bay]
> Đề có thể cài phương án đặt (CH~3~)~3~N mạnh nhất "vì có 3 gốc đẩy electron". Trong nước điều này **không đúng**; nếu đề có amine bậc ba, hãy dựa vào các phương án còn lại (aniline luôn yếu nhất, NaOH luôn mạnh nhất) để loại trừ.

### Dạng 3. Amine tác dụng với acid (bảo toàn khối lượng)

**Nhận biết:** đề cho khối lượng amine và khối lượng muối (hoặc thể tích, nồng độ HCl), hỏi công thức amine, số đồng phân, hay khối lượng muối.

**Phương pháp:**

1. Amine **đơn chức**: R–N + HCl → muối, tỉ lệ 1 : 1 → **n(amine) = n(HCl)**.
2. Bảo toàn khối lượng: **m(muối) = m(amine) + m(HCl)** → n(HCl) = [m(muối) − m(amine)] : 36,5.
3. M(amine) = m : n. Amine no, đơn chức, mạch hở C~n~H~2n+3~N có **M = 14n + 17**.
4. Hỗn hợp hai amine đồng đẳng kế tiếp: tính M trung bình, suy ra hai chất, rồi lập hệ phương trình.

> [!vi-du] Ví dụ 9
> Cho 5,9 g một amine no, đơn chức, mạch hở X tác dụng vừa đủ với dung dịch HCl, thu được 9,55 g muối. Tìm công thức phân tử của X và cho biết X có bao nhiêu công thức cấu tạo.

> [!goi-y] Gợi ý 1
> Khối lượng tăng thêm chính là khối lượng HCl đã phản ứng.

> [!goi-y] Gợi ý 2
> Tìm M rồi dùng M = 14n + 17. Số đồng phân xem lại "kết quả cần nhớ" ở mục 1.3.

> [!loi-giai] Lời giải
> m(HCl) = 9,55 − 5,9 = 3,65 g → n(HCl) = 3,65 : 36,5 = 0,1 mol = n(X).
>
> M(X) = 5,9 : 0,1 = 59 → 14n + 17 = 59 → n = 3 → X là **C~3~H~9~N**.
>
> X có **4** công thức cấu tạo: propylamine, isopropylamine, ethylmethylamine, trimethylamine.

> [!vi-du] Ví dụ 10
> Hỗn hợp E gồm hai amine no, đơn chức, mạch hở, kế tiếp nhau trong dãy đồng đẳng. Cho 1,52 g E tác dụng vừa đủ với dung dịch HCl, thu được 2,98 g muối. Xác định hai amine và tính phần trăm khối lượng của amine có phân tử khối nhỏ hơn.

> [!goi-y] Gợi ý 1
> n(HCl) = (2,98 − 1,52) : 36,5. Tính M trung bình của E.

> [!goi-y] Gợi ý 2
> M trung bình phải nằm **giữa** M của hai chất kế tiếp (31, 45, 59…). Gọi số mol là x, y rồi lập hệ.

> [!loi-giai] Lời giải
> n(E) = n(HCl) = 1,46 : 36,5 = 0,04 mol → M trung bình = 1,52 : 0,04 = 38.
>
> 31 < 38 < 45 → hai amine là **CH~5~N** (CH~3~NH~2~) và **C~2~H~7~N**.
>
> Hệ: x + y = 0,04 và 31x + 45y = 1,52 → x = 0,02; y = 0,02.
>
> %m(CH~5~N) = 0,02 · 31 : 1,52 · 100% ≈ **40,8%**.

> [!bay]
> - Muối amine tạo ra **không kèm nước**, nên không trừ 18 như phản ứng acid – base thông thường.
> - Viết công thức muối cho đúng: CH~3~NH~3~Cl (M = 67,5), C~2~H~5~NH~3~Cl (M = 81,5). Không viết "CH~3~NH~2~Cl".

### Dạng 4. Đốt cháy amine

**Nhận biết:** đề cho số mol (hoặc thể tích) CO~2~, H~2~O, N~2~, O~2~ khi đốt amine; hỏi công thức hoặc khối lượng amine.

**Phương pháp** (amine no, đơn chức, mạch hở C~n~H~2n+3~N):

=> C~n~H~2n+3~N + (1,5n + 0,75)O~2~ → nCO~2~ + (n + 1,5)H~2~O + 0,5N~2~

1. Vì n(H~2~O) − n(CO~2~) = 1,5 · n(amine) nên **n(amine) = [n(H~2~O) − n(CO~2~)] : 1,5**.
2. Số C = n(CO~2~) : n(amine).
3. **n(N~2~) = 0,5 · n(amine)** (amine đơn chức).
4. Bảo toàn O: n(O~2~) = n(CO~2~) + 0,5 · n(H~2~O).

**Vì sao chia 1,5?** Mỗi phân tử C~n~H~2n+3~N có số H nhiều hơn 2 lần số C đúng 3 nguyên tử, tức là sinh thêm 1,5 phân tử H~2~O so với số CO~2~.

> [!vi-du] Ví dụ 11
> Đốt cháy hoàn toàn một amine no, đơn chức, mạch hở X, thu được 0,3 mol CO~2~ và 0,45 mol H~2~O. Xác định công thức phân tử của X và tính thể tích N~2~ (đkc) tạo thành.

> [!goi-y] Gợi ý 1
> n(X) = (0,45 − 0,3) : 1,5.

> [!goi-y] Gợi ý 2
> Số C = n(CO~2~) : n(X). n(N~2~) bằng một nửa n(X).

> [!loi-giai] Lời giải
> n(X) = 0,15 : 1,5 = 0,1 mol → số C = 0,3 : 0,1 = 3 → X là **C~3~H~9~N**.
>
> n(N~2~) = 0,1 : 2 = 0,05 mol → V(N~2~) = 0,05 · 24,79 ≈ **1,24 L**.
>
> (Kiểm tra: số H = 2 · 0,45 : 0,1 = 9 ✓.)

> [!bay]
> - Khi đốt amine trong **không khí**, khí N~2~ thu được gồm cả N~2~ của amine lẫn N~2~ có sẵn trong không khí. Đề cho "đốt bằng không khí" thì phải trừ phần N~2~ đó.
> - Công thức n(amine) = [n(H~2~O) − n(CO~2~)] : 1,5 **chỉ dùng** cho amine no, đơn chức, mạch hở.

### Dạng 5. Aniline với nước bromine

**Nhận biết:** đề cho khối lượng kết tủa trắng hoặc lượng aniline, Br~2~.

**Phương pháp:** dùng tỉ lệ **C~6~H~5~NH~2~ (93) : 3Br~2~ : C~6~H~2~Br~3~NH~2~ (330) = 1 : 3 : 1**. Xem Ví dụ 6 ở mục 4.3.

> [!bay]
> Quên hệ số 3 của Br~2~, hoặc lấy M kết tủa bằng 93 + 3 · 80 = 333 (quên trừ 3 nguyên tử H bị thế). M đúng là **330**.

### Dạng 6. Câu Đúng/Sai về thí nghiệm

> [!vi-du] Ví dụ 12 (Đúng/Sai)
> Cho từ từ dung dịch methylamine vào ống nghiệm chứa dung dịch CuSO~4~ đến dư, lắc đều. Xét các phát biểu sau:
>
> a) Lúc đầu xuất hiện kết tủa xanh.
>
> b) Kết tủa xanh là Cu(OH)~2~, tạo ra do dung dịch methylamine có ion OH^−^.
>
> c) Khi methylamine dư, kết tủa không tan.
>
> d) Nếu thay methylamine bằng aniline thì hiện tượng xảy ra hoàn toàn tương tự.

> [!goi-y] Gợi ý 1
> Methylamine giống NH~3~: vừa tạo OH^−^, vừa tạo phức với Cu^2+^ nhờ cặp electron trên N.

> [!goi-y] Gợi ý 2
> Aniline có làm quỳ tím đổi màu không? Nó có đủ OH^−^ để tạo kết tủa Cu(OH)~2~ không?

> [!loi-giai] Lời giải
> a) **Đúng.**
>
> b) **Đúng**: CH~3~NH~2~ + H~2~O ⇌ CH~3~NH~3~^+^ + OH^−^; sau đó Cu^2+^ + 2OH^−^ → Cu(OH)~2~↓.
>
> c) **Sai**: methylamine dư hoà tan Cu(OH)~2~ tạo phức \[Cu(CH~3~NH~2~)~4~\](OH)~2~ màu xanh lam.
>
> d) **Sai**: aniline là base rất yếu (không làm quỳ tím đổi màu), không cho hiện tượng "kết tủa xanh rồi tan thành dung dịch xanh lam" như methylamine. SGK chỉ nêu phản ứng tạo phức với methylamine, ethylamine.

## Tóm tắt

| Nội dung | Ghi nhớ |
|---|---|
| Khái niệm | Thay H của NH~3~ bằng gốc hydrocarbon |
| Bậc amine | Số gốc hydrocarbon gắn vào N: R–NH~2~ (1), R–NH–R′ (2), R~3~N (3) |
| Phân loại | Alkylamine (N gắn gốc alkyl); arylamine (N gắn trực tiếp vào vòng benzene) |
| Đồng phân | Bậc amine, mạch C, vị trí nhóm amine. C~2~H~7~N: 2; C~3~H~9~N: 4; C~4~H~11~N: 8 |
| Gốc – chức | Tên gốc (theo vần chữ cái) + amine: ethylmethylamine, trimethylamine |
| Thay thế | (N-nhóm thế) + mạch chính bỏ "e" + vị trí + amine: N-methylethanamine, propan-2-amine |
| Vật lí | CH~3~NH~2~, (CH~3~)~2~NH, (CH~3~)~3~N, C~2~H~5~NH~2~: khí, mùi khai/tanh. Aniline: lỏng, ít tan. Sôi: hydrocarbon < amine < alcohol |
| Tính base | C~6~H~5~NH~2~ < NH~3~ < CH~3~NH~2~ < (CH~3~)~2~NH < NaOH. Aniline không đổi màu quỳ |
| Với acid | RNH~2~ + HCl → RNH~3~Cl; m(muối) = m(amine) + m(HCl) |
| Với FeCl~3~ | Kết tủa nâu đỏ Fe(OH)~3~ |
| Với Cu^2+^ | Kết tủa xanh Cu(OH)~2~, tan trong CH~3~NH~2~ dư → phức xanh lam |
| Với HNO~2~ | Alkylamine bậc một (t° thường) → ROH + N~2~↑; aniline (0 – 5 °C, HCl) → muối diazonium |
| Aniline + Br~2~ | → 2,4,6-tribromoaniline ↓ trắng (M = 330) + 3HBr |
| Ứng dụng | Aniline: phẩm nhuộm, dược phẩm (paracetamol, sulfonamide), polymer; hexamethylenediamine → nylon-6,6 |
| Điều chế | Alkyl hoá NH~3~ bằng CH~3~I…; khử nitrobenzene bằng Fe/Zn + HCl |

**Các công thức dùng trong tính toán:**

- Amine no, đơn chức, mạch hở: C~n~H~2n+3~N, M = 14n + 17 (31, 45, 59, 73…).
- Amine đơn chức + HCl: n(amine) = n(HCl) = [m(muối) − m(amine)] : 36,5.
- Đốt cháy: n(amine) = [n(H~2~O) − n(CO~2~)] : 1,5; n(N~2~) = 0,5 · n(amine).
- Alkylamine bậc một + HNO~2~: n(N~2~) = n(amine).
- Aniline (93) + 3Br~2~ → kết tủa (330) + 3HBr.
