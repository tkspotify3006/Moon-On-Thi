---
title: Vật liệu polymer
thoi-gian: 45 phút
muc-tieu:
  - Nêu được khái niệm chất dẻo, vật liệu composite, tơ, cao su, keo dán, phân biệt tính dẻo với tính đàn hồi.
  - Viết được phản ứng điều chế PE, PP, PVC, PS, poly(methyl methacrylate) (trùng hợp) và poly(phenol formaldehyde) (trùng ngưng), nêu được ứng dụng của từng chất dẻo.
  - Nêu được tác hại của việc lạm dụng chất dẻo và các biện pháp giảm thiểu rác thải nhựa.
  - Xác định được vật liệu cốt, vật liệu nền trong một số vật liệu composite.
  - Phân loại được tơ (tự nhiên, tổng hợp, bán tổng hợp), trình bày được cấu tạo, tính chất, ứng dụng của bông, len, tơ tằm, nylon-6,6, capron, nitron, visco, cellulose acetate.
  - Trình bày được cấu tạo, tính chất của cao su tự nhiên, viết được phản ứng điều chế cao su buna, buna-S, buna-N, isoprene, chloroprene, nêu được ý nghĩa của lưu hoá cao su.
  - Nêu được thành phần, ứng dụng của nhựa vá săm, keo dán epoxy, keo dán poly(urea-formaldehyde).
  - Giải được bài toán khối lượng vật liệu có hiệu suất, số mắt xích, tỉ lệ mắt xích trong cao su buna-S, buna-N.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. **Chất dẻo** = vật liệu polymer có **tính dẻo** (biến dạng rồi **giữ nguyên** hình dạng mới). PE, PP, PVC, PS, PMMA điều chế bằng **trùng hợp**. PPF điều chế bằng **trùng ngưng** (phenol + formaldehyde).
> 2. **Composite** = vật liệu **cốt** (sợi hoặc hạt, chịu lực) + vật liệu **nền** (polymer, kim loại, gốm… gắn các cốt lại với nhau).
> 3. **Tơ** = polymer dạng **sợi mảnh**, mạch không nhánh. Tự nhiên: bông, len, tơ tằm. Tổng hợp: nylon-6,6, capron, nitron. Bán tổng hợp: visco, cellulose acetate.
> 4. **Cao su** = polymer có **tính đàn hồi** (biến dạng rồi **trở lại** như cũ). Cao su tự nhiên là polyisoprene dạng *cis*. Cao su tổng hợp đều điều chế bằng **trùng hợp**: buna, buna-S, buna-N, isoprene, chloroprene.
> 5. **Keo dán** tạo lớp màng mỏng bám chắc hai bề mặt: nhựa vá săm (cao su tan trong dung môi), epoxy (hai thành phần), poly(urea-formaldehyde) (trùng ngưng).

Bài 12 cho em "bộ khung": polymer là gì, trùng hợp và trùng ngưng khác nhau ra sao. Bài này trả lời câu hỏi: **từ polymer, người ta làm ra những vật liệu gì?** Có năm nhóm: chất dẻo, composite, tơ, cao su, keo dán. Mỗi nhóm được gọi tên theo **tính chất nổi bật**, không theo công thức hoá học.

## 1. Chất dẻo

### 1.1. Khái niệm

Em lấy một chiếc thìa nhựa, hơ nóng rồi bẻ cong, sau đó để nguội. Chiếc thìa **giữ nguyên** hình dạng cong. Còn khi kéo dãn một sợi dây chun rồi buông ra, nó **co về** như cũ. Hai hiện tượng này ứng với hai tính chất khác nhau.

![Hình 1. Tính dẻo và tính đàn hồi: chất dẻo giữ biến dạng sau khi thôi tác dụng, cao su trở lại hình dạng ban đầu](deo-dan-hoi.svg)

- **Tính dẻo**: vật liệu bị biến dạng khi chịu tác dụng của nhiệt, áp lực bên ngoài và **vẫn giữ được** biến dạng đó khi thôi tác dụng.
- **Chất dẻo** là những vật liệu polymer có tính dẻo.

Nhờ tính dẻo, người ta nấu chảy hạt nhựa rồi ép, thổi, đúc thành đủ mọi hình dạng: chai, hộp, ống, màng mỏng… Đó là lí do đồ nhựa rẻ và phổ biến.

**Thành phần của chất dẻo.** Thành phần chính là **polymer**. Ngoài ra còn có:

- **chất độn** (bột đá, bột gỗ, sợi…) để tăng độ cứng, giảm giá thành;
- **chất hoá dẻo** để nhựa mềm, dễ uốn hơn;
- **chất tạo màu**.

> [!bay]
> - "Chất dẻo là polymer nguyên chất" là **sai**. Chất dẻo là **vật liệu**, gồm polymer và các chất phụ gia.
> - Đừng nhầm **tính dẻo** (giữ biến dạng) với **tính đàn hồi** (trở lại như cũ). Cao su có tính đàn hồi, **không** phải chất dẻo.

### 1.2. Tổng hợp một số polymer dùng làm chất dẻo

**a) Bằng phản ứng trùng hợp: PE, PP, PVC, PS, PMMA**

Bốn chất dẻo thông dụng nhất có chung một "khuôn" monomer CH~2~=CH–R. Chỉ cần đổi nhóm R là được chất dẻo khác (SGK tr. 57):

=> nCH~2~=CH–R → (–CH~2~–CHR–)~n~    (t°, xt, p)

| R | –H | –CH~3~ | –Cl | –C~6~H~5~ |
|---|---|---|---|---|
| Monomer | ethylene | propylene | vinyl chloride | styrene |
| Chất dẻo | PE | PP | PVC | PS |

**Poly(methyl methacrylate)** (PMMA) cũng điều chế bằng trùng hợp, từ methyl methacrylate:

=> nCH~2~=C(CH~3~)–COOCH~3~ → (–CH~2~–C(CH~3~)(COOCH~3~)–)~n~    (t°, xt, p)

Liên kết đôi C=C mở ra, nhóm –CH~3~ và –COOCH~3~ treo ở hai bên mạch. PMMA trong suốt, cho ánh sáng đi qua rất tốt, nên còn gọi là **thuỷ tinh hữu cơ** (ngoài đời hay gọi là tấm mica, acrylic).

**b) Bằng phản ứng trùng ngưng: poly(phenol formaldehyde) (PPF)**

Phenol phản ứng với formaldehyde khi có acid làm xúc tác. Nhóm –CH~2~– từ formaldehyde "bắc cầu" giữa các vòng benzene, đồng thời tách ra nước:

=> nC~6~H~5~OH + nHCHO → (–C~6~H~3~(OH)–CH~2~–)~n~ + nH~2~O    (H^+^, t°)

**Vì sao là trùng ngưng?** Phản ứng có tách ra phân tử nhỏ (H~2~O). Mỗi phân tử phenol có nhiều vị trí H trên vòng phản ứng được (hai vị trí *ortho* và một vị trí *para* so với nhóm –OH). Nhờ vậy, khi gia công tiếp, các mạch còn nối chéo được với nhau thành mạng lưới (nhựa bakelite, xem Bài 12).

### 1.3. Ứng dụng của chất dẻo

Theo SGK, khoảng hai phần ba lượng polymer tiêu thụ trên thế giới là các chất dẻo thông dụng PE, PP, PVC, PS. Mỗi chất có thế mạnh riêng:

| Chất dẻo | Tính chất nổi bật | Ứng dụng tiêu biểu |
|---|---|---|
| PE | mềm, dai, trơ, không thấm nước | túi nylon, màng bọc thực phẩm, chai lọ, đồ chơi |
| PP | cứng hơn PE, chịu nhiệt tốt hơn | bao gói, hộp đựng, ống nước, chi tiết nhựa ô tô |
| PVC | cứng, cách điện tốt, khó cháy | ống nước, khung cửa, sàn nhựa, vỏ cáp điện, giả da, áo mưa |
| PS | nhẹ, dễ tạo xốp, cách nhiệt | hộp xốp, bao gói thực phẩm, vật liệu cách nhiệt |
| PMMA | trong suốt, bền, khó vỡ | kính máy bay, kính xây dựng, kính bảo hiểm, bể cá |
| PPF | cứng, chịu nhiệt, cách điện | vỏ ổ cắm, tay cầm xoong (bakelite) |

**Vì sao PVC hay dùng làm vỏ dây điện?** Mạch PVC chỉ có liên kết cộng hoá trị, không có electron tự do hay ion linh động, nên PVC **cách điện** tốt. Thêm vào đó PVC dẻo, uốn theo dây được, lại khó cháy nhờ có chlorine.

> [!vi-du] Ví dụ 1
> Hãy chọn chất dẻo phù hợp (trong PE, PS, PMMA, PVC) cho mỗi sản phẩm sau và giải thích ngắn gọn:
>
> a) Cửa sổ của máy bay.
>
> b) Thùng giữ lạnh để chở cá.
>
> c) Ống thoát nước trong nhà.
>
> Viết phương trình điều chế chất dẻo dùng ở câu a).

> [!goi-y] Gợi ý 1
> Cửa sổ máy bay cần trong suốt và khó vỡ. Thùng giữ lạnh cần nhẹ và cách nhiệt.

> [!goi-y] Gợi ý 2
> Thuỷ tinh hữu cơ được trùng hợp từ methyl methacrylate.

> [!loi-giai] Lời giải
> a) **PMMA** (thuỷ tinh hữu cơ): trong suốt, bền, nhẹ hơn thuỷ tinh vô cơ và khó vỡ vụn.
>
> => nCH~2~=C(CH~3~)–COOCH~3~ → (–CH~2~–C(CH~3~)(COOCH~3~)–)~n~    (t°, xt, p)
>
> b) **PS** dạng xốp: nhẹ, chứa nhiều bọt khí nên cách nhiệt tốt.
>
> c) **PVC**: cứng, bền, không bị nước ăn mòn như ống kim loại.

**Bài toán điều chế chất dẻo.** Cách tính giống Bài 12: tính theo **mol mắt xích**, trùng hợp thì 1 monomer cho 1 mắt xích. Điểm mới là quy trình thường có **nhiều giai đoạn**, ví dụ phải tổng hợp monomer trước rồi mới trùng hợp.

> [!vi-du] Ví dụ 2
> Một xưởng sản xuất thuỷ tinh hữu cơ theo sơ đồ:
>
> methacrylic acid + methanol → methyl methacrylate → PMMA
>
> Hiệu suất giai đoạn ester hoá là 60%, giai đoạn trùng hợp là 80%. Tính khối lượng methacrylic acid và methanol cần dùng để thu được 1,5 tấn PMMA (làm tròn đến hàng phần trăm).

> [!goi-y] Gợi ý 1
> Methacrylic acid là CH~2~=C(CH~3~)–COOH (M = 86). Mắt xích PMMA có M = 100. Sơ đồ hợp thức: 1 acid + 1 methanol → 1 ester → 1 mắt xích.

> [!goi-y] Gợi ý 2
> Tìm nguyên liệu từ sản phẩm là đi **ngược**, nên phải **chia** cho hiệu suất chung 0,6 · 0,8.

> [!loi-giai] Lời giải
> Phản ứng ester hoá:
>
> => CH~2~=C(CH~3~)–COOH + CH~3~OH ⇌ CH~2~=C(CH~3~)–COOCH~3~ + H~2~O    (H~2~SO~4~ đặc, t°)
>
> n(mắt xích PMMA) = 1,5 : 100 = 0,015 tấn mol (tức 15 kmol).
>
> Hiệu suất chung H = 0,6 · 0,8 = 0,48.
>
> m(acid) = 0,015 · 86 : 0,48 ≈ **2,69 tấn**.
>
> m(methanol) = 0,015 · 32 : 0,48 = **1,00 tấn**.

> [!bay]
> - Nhân với 0,48 thay vì chia sẽ cho 0,62 tấn acid, nhỏ hơn cả lượng lí thuyết 1,29 tấn. Vô lí, vì có hao hụt thì phải cần **nhiều** nguyên liệu hơn.
> - Trùng hợp không tách nước, nên **không** trừ H~2~O ở giai đoạn trùng hợp. Nước chỉ tách ra ở giai đoạn ester hoá, và nó không ảnh hưởng đến tỉ lệ mol 1 : 1.

### 1.4. Ô nhiễm môi trường do chất dẻo và rác thải nhựa

Chính vì **bền** (khó bị phân huỷ), đồ nhựa trở thành vấn đề khi bị vứt bỏ. Một chiếc túi nylon có thể tồn tại hàng trăm năm.

- **Chôn lấp**: nhựa làm đất không giữ được nước và chất dinh dưỡng, làm chết vi sinh vật có lợi, cây trồng kém phát triển.
- **Đốt**: sinh ra khí độc, đồng thời thải CO~2~ làm tăng hiệu ứng nhà kính. Đốt PVC còn sinh ra HCl và các hợp chất chứa chlorine rất độc.
- **Thải ra sông, biển**: nhựa làm ô nhiễm nguồn nước, động vật nuốt phải, mất cân bằng hệ sinh thái.

Theo số liệu SGK dẫn từ Chương trình Môi trường Liên Hợp Quốc (SGK tr. 57), mỗi năm thế giới sản xuất khoảng 400 triệu tấn nhựa, nhưng chưa đến 10% được tái chế.

**Biện pháp giảm rác thải nhựa** (SGK tr. 58):

- tái chế, tái sử dụng đồ nhựa đã dùng;
- hạn chế bao bì nhựa, túi nylon dùng một lần;
- mang túi vải, giỏ khi đi chợ, đi siêu thị;
- dùng vật liệu phân huỷ sinh học;
- phân loại rác thải tại nguồn.

> [!ung-dung] Phân loại để tái chế
> Kí hiệu số 1–6 dưới đáy chai, hộp cho biết loại nhựa (Bài 12, mục 2). Chỉ nhựa cùng loại mới nấu chảy chung được, nên **phân loại tại nguồn** là bước quan trọng nhất của tái chế.

> [!em-co-biet] Vi nhựa (mở rộng)
> Dưới tác dụng của ánh nắng, sóng, gió, đồ nhựa vỡ dần thành các mảnh nhỏ hơn 5 mm, gọi là **vi nhựa**. Vi nhựa đã được tìm thấy trong nước biển, muối ăn, hải sản và cả nước uống đóng chai. Hạn chế đồ nhựa dùng một lần là cách tốt nhất để giảm vi nhựa.

## 2. Vật liệu composite

### 2.1. Khái niệm

Hãy nghĩ đến bức tường đất trộn rơm của nhà xưa. Đất một mình thì dễ nứt. Rơm một mình thì mềm. Trộn lại, rơm làm "xương", đất làm "thịt", tường vừa cứng vừa ít nứt. Đó là ý tưởng của vật liệu composite.

**Vật liệu composite** là vật liệu tổ hợp từ **hai hay nhiều vật liệu khác nhau**, tạo nên vật liệu mới có tính chất **vượt trội** so với các vật liệu ban đầu.

Composite thường gồm hai thành phần chính:

- **Vật liệu cốt**: bảo đảm **độ bền cơ học** (chịu lực). Có hai dạng: **cốt sợi** (sợi thuỷ tinh, sợi carbon, sợi hữu cơ, vải…) và **cốt hạt**.
- **Vật liệu nền**: **gắn kết** các cốt lại với nhau, tạo thành một khối thống nhất. Nền có thể là polymer (nhựa), kim loại, gốm…

![Hình 2. Hai dạng composite: cốt sợi và cốt hạt được bao bọc trong vật liệu nền](composite.svg)

**Vì sao composite bền hơn từng thành phần?** Nền **truyền** lực sang các cốt rất bền, cốt sợi chặn đường lan của vết nứt, còn nền bảo vệ cốt khỏi va đập, ẩm và hoá chất.

### 2.2. Ứng dụng

- **Composite cốt sợi**: thân và vỏ máy bay, tàu thuyền, thân xe đua, khung xe đạp, bồn chứa, ống dẫn…
- **Composite cốt hạt**: gỗ nhựa, bê tông nhựa, gốm chất lượng cao…

> [!vi-du] Ví dụ 3
> Xác định vật liệu cốt (dạng sợi hay hạt) và vật liệu nền trong các composite sau:
>
> a) Khung vợt cầu lông làm từ sợi carbon tẩm nhựa epoxy.
>
> b) Tấm ốp "gỗ nhựa" làm từ bột gỗ trộn với nhựa PE nóng chảy rồi ép.

> [!goi-y] Gợi ý 1
> Thành phần nào chịu lực, phân bố thành từng sợi hay từng hạt? Thành phần nào bao bọc, gắn kết?

> [!goi-y] Gợi ý 2
> Nhựa (epoxy, PE) thường đóng vai trò nền.

> [!loi-giai] Lời giải
> a) Cốt **sợi**: sợi carbon. Nền: **nhựa epoxy** (nền hữu cơ). Composite này rất nhẹ mà cứng, nên vợt vung nhanh hơn.
>
> b) Cốt **hạt**: bột gỗ. Nền: **nhựa PE**. Gỗ nhựa có vẻ ngoài giống gỗ nhưng không mục, không mối mọt, chịu nước tốt.

> [!bay]
> Composite **không** phải là hợp chất hoá học mới. Cốt và nền **không phản ứng** để tạo chất mới, chúng chỉ được tổ hợp với nhau và vẫn giữ bản chất riêng.

## 3. Tơ

### 3.1. Khái niệm

**Tơ** là những vật liệu polymer có **dạng sợi mảnh** và có **độ bền nhất định**.

Polymer làm tơ thường có **mạch không phân nhánh**, các mạch xếp **song song** với nhau. Lí do: các mạch thẳng xếp sát nhau thì lực hút giữa chúng mạnh, sợi bền. Mạch phân nhánh hay mạng lưới khó xếp khít, khó kéo thành sợi.

Polymer làm tơ cần tương đối bền với các dung môi thông thường, mềm, dai, không độc và nhuộm màu được.

### 3.2. Phân loại

Dựa vào **nguồn gốc** và **cách chế tạo**, tơ chia làm ba loại:

![Hình 3. Phân loại tơ theo nguồn gốc, kèm thành phần hoá học của từng loại](phan-loai-to.svg)

- **Tơ tự nhiên**: có sẵn trong tự nhiên (bông, len, tơ tằm).
- **Tơ tổng hợp**: chế tạo từ polymer **tổng hợp** (do con người trùng hợp hoặc trùng ngưng từ monomer). Ví dụ: tơ polyamide (capron, nylon-6,6), tơ nitron.
- **Tơ bán tổng hợp** (còn gọi là tơ nhân tạo): chế biến **từ polymer tự nhiên** (cellulose) bằng phương pháp hoá học. Ví dụ: tơ visco, tơ cellulose acetate.

> [!meo] Hỏi "nguyên liệu đầu là gì?"
> - Lấy thẳng từ cây, con vật → **tự nhiên**.
> - Lấy cellulose (gỗ, bông) rồi **chế biến hoá học** → **bán tổng hợp**.
> - Đi từ **phân tử nhỏ** (monomer) → **tổng hợp**.

### 3.3. Một số loại tơ thường gặp

**a) Tơ tự nhiên**

| Tơ | Nguồn | Thành phần chính | Đặc điểm, ứng dụng |
|---|---|---|---|
| Sợi bông | quả bông | cellulose | mềm mịn, thấm mồ hôi, thoáng → vải cotton |
| Len | lông cừu, dê, lạc đà… | protein | giữ nhiệt tốt → áo len, khăn len |
| Tơ tằm | kén tằm | protein | bóng, mềm, thoáng, hút ẩm → vải may mặc mùa hè |

**b) Tơ tổng hợp**

- **Nylon-6,6** thuộc loại **tơ polyamide**, tổng hợp bằng **trùng ngưng** từ hai hợp chất đều có 6 nguyên tử C: hexamethylenediamine và adipic acid (phương trình ở Bài 12, mục 4.2). Mắt xích:

=> –NH–[CH~2~]~6~–NH–CO–[CH~2~]~4~–CO–

Nylon-6,6 dai, mềm, ít thấm nước. Dùng dệt vải may mặc, vải lót lốp xe, bện dây cáp, dây dù, đan lưới.

- **Capron** cũng là **tơ polyamide**, thường tổng hợp bằng **trùng hợp mở vòng** caprolactam:

=> n(caprolactam) → (–NH–[CH~2~]~5~–CO–)~n~    (t°)

Capron dai, bền, đàn hồi, bóng, ít nhăn, chống mài mòn.

- **Nitron** (hay **olon**) là polyacrylonitrile, tổng hợp bằng **trùng hợp** vinyl cyanide (acrylonitrile):

=> nCH~2~=CH–CN → (–CH~2~–CH(CN)–)~n~    (t°, xt, p)

Nitron dai, bền nhiệt, **giữ nhiệt tốt** ("len nhân tạo"). Dùng dệt vải may quần áo ấm, vải bạt, mái hiên, buồm.

**Vì sao gọi là "polyamide"?** Trong mạch có rất nhiều nhóm **amide –CO–NH–** lặp lại. Nhóm này giống liên kết peptide trong protein, nên tơ polyamide và tơ tằm, len có điểm chung: **kém bền trong acid và kiềm**, vì nhóm –CO–NH– bị thuỷ phân (Bài 12, mục 3.1).

**c) Tơ bán tổng hợp**

- **Tơ visco**: có cấu trúc phân tử giống cellulose, sản xuất từ các nguồn cellulose (gỗ, tre, bông vụn). Cellulose được hoà tan rồi kéo lại thành sợi mảnh, đều. Vải visco dai, bền, thấm mồ hôi, thoáng khí.
- **Tơ cellulose acetate**: một trong những tơ bán tổng hợp ra đời sớm nhất. Cellulose được acetyl hoá, tức là thay H của các nhóm –OH bằng nhóm acetyl CH~3~CO–. Mỗi mắt xích thường mang 2 nhóm acetate, [C~6~H~7~O~2~(OH)(OOCCH~3~)~2~]~n~, hoặc 3 nhóm acetate, [C~6~H~7~O~2~(OOCCH~3~)~3~]~n~. Tơ mềm, mịn, đàn hồi, khô nhanh, bền màu. Dùng dệt sa tanh, vải dệt kim.

> [!nen-tang] Mỗi mắt xích cellulose có 3 nhóm –OH (Bài 6)
> Viết cellulose dạng [C~6~H~7~O~2~(OH)~3~]~n~ để thấy rõ 3 nhóm –OH. Chúng phản ứng được như alcohol: với HNO~3~ tạo cellulose nitrate (Bài 6), với acetic anhydride (CH~3~CO)~2~O tạo cellulose acetate.

> [!vi-du] Ví dụ 4
> Cho các loại tơ: bông, capron, tơ visco, len, nitron, tơ tằm, nylon-6,6, tơ cellulose acetate.
>
> a) Có bao nhiêu tơ tổng hợp? Bao nhiêu tơ bán tổng hợp?
>
> b) Có bao nhiêu tơ mà trong phân tử có nhóm –CO–NH–?
>
> c) Có bao nhiêu tơ có nguồn gốc từ cellulose?

> [!goi-y] Gợi ý 1
> Lập bảng ba cột: tự nhiên / bán tổng hợp / tổng hợp. Xếp từng tơ vào.

> [!goi-y] Gợi ý 2
> Nhóm –CO–NH– có trong **polyamide** và trong **protein**. Len và tơ tằm là protein. Nitron có nhóm –CN, không có –CO–NH–.

> [!loi-giai] Lời giải
> a) Tổng hợp: capron, nitron, nylon-6,6 → **3**. Bán tổng hợp: visco, cellulose acetate → **2**. (Tự nhiên: bông, len, tơ tằm.)
>
> b) Có nhóm –CO–NH–: capron, nylon-6,6 (polyamide), len, tơ tằm (protein) → **4**.
>
> c) Từ cellulose: bông, visco, cellulose acetate → **3**.

> [!bay]
> - Tơ visco và tơ cellulose acetate là tơ **bán tổng hợp** (nhân tạo), **không** phải tơ tổng hợp, dù có qua nhà máy.
> - Tơ nitron điều chế bằng **trùng hợp**, không phải trùng ngưng. Nitron **không** phải polyamide.
> - Len, tơ tằm là **protein**. Bông là **cellulose**. Đừng nhầm ba loại tơ tự nhiên này có cùng bản chất.
> - *Mở rộng (ngoài SGK):* đề thi đôi khi nhắc **tơ lapsan** (polyester, cùng chất với nhựa PET, điều chế bằng trùng ngưng). Em chỉ cần biết nó là tơ tổng hợp.

> [!vi-du] Ví dụ 5
> Cho 32,4 kg cellulose phản ứng với acetic anhydride (dư, có xúc tác), thu được 55,5 kg hỗn hợp X gồm cellulose triacetate và cellulose diacetate (không còn cellulose). Tính phần trăm khối lượng cellulose triacetate trong X (làm tròn đến hàng phần mười) và khối lượng acetic acid sinh ra.

> [!goi-y] Gợi ý 1
> Một mắt xích cellulose (M = 162) thành một mắt xích triacetate C~6~H~7~O~2~(OOCCH~3~)~3~ (M = 288) hoặc diacetate C~6~H~7~O~2~(OH)(OOCCH~3~)~2~ (M = 246). Mỗi nhóm –OH được acetyl hoá sinh ra 1 phân tử CH~3~COOH.

> [!goi-y] Gợi ý 2
> Gọi x, y là số kmol mắt xích triacetate và diacetate. Lập hai phương trình: bảo toàn mắt xích và khối lượng X.

> [!loi-giai] Lời giải
> => [C~6~H~7~O~2~(OH)~3~]~n~ + 3n(CH~3~CO)~2~O → [C~6~H~7~O~2~(OOCCH~3~)~3~]~n~ + 3nCH~3~COOH
>
> => [C~6~H~7~O~2~(OH)~3~]~n~ + 2n(CH~3~CO)~2~O → [C~6~H~7~O~2~(OH)(OOCCH~3~)~2~]~n~ + 2nCH~3~COOH
>
> n(mắt xích cellulose) = 32,4 : 162 = 0,2 kmol.
>
> Hệ: x + y = 0,2 và 288x + 246y = 55,5 → x = 0,15, y = 0,05.
>
> %m(triacetate) = 0,15 · 288 : 55,5 · 100% ≈ **77,8%**.
>
> n(CH~3~COOH) = 3x + 2y = 0,55 kmol → m = 0,55 · 60 = **33 kg**.

## 4. Cao su

### 4.1. Khái niệm

**Cao su** là vật liệu polymer có **tính đàn hồi**: biến dạng khi chịu lực tác dụng và **trở lại dạng ban đầu** khi lực đó thôi tác dụng (Hình 1).

**Vì sao cao su đàn hồi?** Mạch cao su rất dài, có liên kết đôi và thường **cuộn lại** như lò xo, các mạch xoắn vào nhau. Khi kéo, các cuộn duỗi ra. Khi buông, chúng co lại về trạng thái cuộn như cũ.

Có hai loại: **cao su tự nhiên** và **cao su tổng hợp**.

### 4.2. Cao su tự nhiên

Cao su tự nhiên lấy từ **mủ cây cao su** (*Hevea brasiliensis*), cây có nguồn gốc Nam Mỹ, được trồng nhiều ở Đông Nam Bộ và Tây Nguyên nước ta.

**Cấu tạo.** Cao su tự nhiên là polymer của **isoprene**. Mỗi mắt xích –CH~2~–C(CH~3~)=CH–CH~2~– có một liên kết đôi, và **mọi liên kết đôi đều ở dạng *cis***: hai nhóm –CH~2~– của mạch nằm **cùng phía** với liên kết đôi. Dạng *cis* làm mạch gấp khúc, khó xếp khít, nên cuộn lại và đàn hồi tốt.

**Tính chất.**

- Đàn hồi, không dẫn điện, chịu mài mòn, không thấm khí và nước.
- Không tan trong nước, ethanol… nhưng **tan trong xăng, benzene**.
- Do còn **liên kết đôi** trong mạch, cao su tự nhiên tham gia **phản ứng cộng** H~2~, HCl, Cl~2~, Br~2~… (mỗi mắt xích cộng 1 phân tử).

**Ứng dụng:** lốp xe, băng tải, ống dẫn, gioăng, đệm, gối…

**Lưu hoá cao su.** Đun cao su với lưu huỳnh, các mạch được nối với nhau bằng **cầu disulfide –S–S–** thành **mạng lưới không gian**. Cao su lưu hoá đàn hồi hơn, bền nhiệt hơn, khó tan trong dung môi hơn, không dính khi nóng, không giòn khi lạnh. Lốp xe đều là cao su đã lưu hoá. Cơ chế và bài toán %S đã học ở Bài 12 (mục 3.2 và Dạng 4).

> [!vi-du] Ví dụ 6
> Tính khối lượng bromine tối đa có thể cộng vào 13,6 g cao su tự nhiên.

> [!goi-y] Gợi ý 1
> Mắt xích C~5~H~8~ (M = 68) có **1** liên kết đôi, nên cộng tối đa 1 Br~2~.

> [!loi-giai] Lời giải
> n(mắt xích) = 13,6 : 68 = 0,2 mol → n(Br~2~) = 0,2 mol → m = 0,2 · 160 = **32 g**.

### 4.3. Cao su tổng hợp

Cao su tổng hợp có tính đàn hồi tương tự cao su tự nhiên, **đều được điều chế bằng phản ứng trùng hợp**. Monomer chung của nhiều loại là **diene liên hợp** (hai liên kết đôi cách nhau một liên kết đơn). Như Bài 12 đã giải thích, khi trùng hợp, cả hai liên kết đôi mở ra và một liên kết đôi mới hình thành **ở giữa** mắt xích.

**a) Cao su buna** (trùng hợp buta-1,3-diene, xúc tác sodium):

=> nCH~2~=CH–CH=CH~2~ → (–CH~2~–CH=CH–CH~2~–)~n~    (Na, t°, p)

Tên "buna" ghép từ **bu**tadiene và **Na** (sodium).

**b) Cao su buna-S và buna-N** (đồng trùng hợp buta-1,3-diene với một monomer khác):

=> nCH~2~=CH–CH=CH~2~ + nCH~2~=CH–C~6~H~5~ → (–CH~2~–CH=CH–CH~2~–CH~2~–CH(C~6~H~5~)–)~n~    (t°, xt, p)

=> nCH~2~=CH–CH=CH~2~ + nCH~2~=CH–CN → (–CH~2~–CH=CH–CH~2~–CH~2~–CH(CN)–)~n~    (t°, xt, p)

- Buna-**S**: monomer thứ hai là **S**tyrene.
- Buna-**N**: monomer thứ hai là acrylonitrile (chứa **N**). Cao su buna-N bền với dầu mỡ, dùng làm găng tay nitrile, gioăng, ống dẫn xăng dầu.

**c) Cao su isoprene** (trùng hợp isoprene):

=> nCH~2~=C(CH~3~)–CH=CH~2~ → (–CH~2~–C(CH~3~)=CH–CH~2~–)~n~    (t°, xt, p)

**d) Cao su chloroprene** (trùng hợp chloroprene):

=> nCH~2~=C(Cl)–CH=CH~2~ → (–CH~2~–C(Cl)=CH–CH~2~–)~n~    (t°, xt, p)

So isoprene và chloroprene: chỉ khác nhóm thế ở C2 (–CH~3~ đổi thành –Cl).

**Ứng dụng:** cao su tổng hợp có độ đàn hồi tốt, bền, chống lão hoá tốt, giá thành thấp. Dùng làm lốp xe, đệm chống va đập, gối cầu, khe co giãn, băng tải, dây curoa, găng tay y tế…

> [!bay] Tỉ lệ mắt xích trong buna-S, buna-N **không** cố định 1 : 1
> Phương trình ở trên viết 1 : 1 cho gọn. Thực tế, tỉ lệ mắt xích buta-1,3-diene : styrene thay đổi theo điều kiện sản xuất (SGK tr. 62 cho biết buna-S, loại cao su tổng hợp sản xuất nhiều nhất, thường có styrene : buta-1,3-diene khoảng 1 : 3). Vì vậy trong bài tập, viết công thức chung là (C~4~H~6~)~a~(C~8~H~8~)~b~ hoặc (C~4~H~6~)~a~(C~3~H~3~N)~b~, rồi tìm tỉ lệ a : b.

![Hình 4. Một đoạn mạch cao su buna-S: mắt xích buta-1,3-diene (còn liên kết đôi, cộng được Br~2~) xen với mắt xích styrene (không cộng Br~2~ vào vòng benzene)](buna-s.svg)

**Mắt xích nào cộng được Br~2~?** Trong buna-S, chỉ mắt xích **buta-1,3-diene** còn liên kết đôi C=C. Mắt xích styrene chỉ còn vòng benzene, **không** cộng Br~2~ trong điều kiện thường. Đây là chìa khoá của bài toán tỉ lệ mắt xích.

> [!vi-du] Ví dụ 7
> Một loại cao su buna-S phản ứng vừa đủ với bromine theo tỉ lệ: 4,24 g cao su làm mất màu tối đa 6,4 g Br~2~ (trong dung môi CCl~4~). Tính tỉ lệ số mắt xích buta-1,3-diene : styrene trong loại cao su này.

> [!goi-y] Gợi ý 1
> n(Br~2~) = n(mắt xích buta-1,3-diene), vì mỗi mắt xích này có 1 liên kết đôi.

> [!goi-y] Gợi ý 2
> Lấy khối lượng cao su trừ khối lượng phần buta-1,3-diene (M = 54) ra khối lượng phần styrene (M = 104).

> [!loi-giai] Lời giải
> n(Br~2~) = 6,4 : 160 = 0,04 mol → n(C~4~H~6~) = 0,04 mol → m = 0,04 · 54 = 2,16 g.
>
> m(phần styrene) = 4,24 − 2,16 = 2,08 g → n(C~8~H~8~) = 2,08 : 104 = 0,02 mol.
>
> Tỉ lệ buta-1,3-diene : styrene = 0,04 : 0,02 = **2 : 1**.

## 5. Keo dán tổng hợp

### 5.1. Khái niệm

**Keo dán** là vật liệu có khả năng **kết dính bề mặt** của hai vật liệu rắn với nhau mà **không làm biến đổi bản chất** các vật liệu được kết dính.

**Bản chất:** keo tạo một **lớp màng mỏng** bám chắc vào bề mặt cả hai mảnh vật liệu. Keo phải đủ lỏng để len vào các chỗ lồi lõm của bề mặt, rồi **đông cứng** lại để giữ chặt.

### 5.2. Một số loại keo dán thông dụng

| Keo | Thành phần | Cách đông cứng | Ứng dụng |
|---|---|---|---|
| Nhựa vá săm | dung dịch keo của **cao su** trong dung môi hữu cơ (xăng, toluene, xylene…) | dung môi bay hơi, để lại lớp cao su | vá chỗ thủng săm, lốp |
| Keo epoxy | **hai thành phần**: chất có hai nhóm epoxy ở hai đầu + **chất đóng rắn** (thường là amine) | trộn hai thành phần, amine phản ứng với nhóm epoxy tạo **polymer mạng không gian** | dán kim loại, gỗ, thuỷ tinh, chất dẻo, bê tông (ô tô, máy bay, xây dựng) |
| Keo poly(urea-formaldehyde) | polymer từ urea + formaldehyde, thêm chất đóng rắn (NH~4~Cl, oxalic acid…) | tạo polymer mạng không gian | chất kết dính trong gỗ ván ép, chất dẻo |

**Nhóm epoxy** là vòng ba cạnh gồm 2 nguyên tử C và 1 nguyên tử O. Vòng ba cạnh rất "căng" nên dễ mở ra khi gặp nhóm –NH~2~. Vì thế hai thành phần của keo epoxy được đựng **riêng** trong hai tuýp, chỉ trộn ngay trước khi dán.

**Điều chế poly(urea-formaldehyde)** (trùng ngưng, tách nước):

=> nH~2~N–CO–NH~2~ + nHCHO → (–NH–CO–NH–CH~2~–)~n~ + nH~2~O    (xt, t°)

> [!vi-du] Ví dụ 8
> a) Vì sao keo epoxy được bán dưới dạng hai tuýp riêng? Nếu trộn sẵn hai thành phần rồi đóng chung một tuýp thì sao?
>
> b) Nhựa vá săm sau khi bôi lên săm cần chờ vài phút mới dán miếng vá. Giải thích.

> [!goi-y] Gợi ý 1
> Keo epoxy đông cứng nhờ **phản ứng hoá học** giữa nhóm amine và nhóm epoxy. Phản ứng xảy ra khi nào?

> [!goi-y] Gợi ý 2
> Nhựa vá săm là cao su **hoà tan** trong xăng, toluene. Cái gì phải đi mất thì keo mới bám chắc?

> [!loi-giai] Lời giải
> a) Hai thành phần gặp nhau là phản ứng ngay, tạo polymer mạng không gian rắn chắc. Trộn sẵn thì keo sẽ đông cứng **trong tuýp**, không dùng được nữa.
>
> b) Cần chờ để **dung môi bay hơi** bớt. Khi đó lớp cao su đặc lại, bám vào bề mặt săm, dán miếng vá mới chắc.

> [!bay]
> - Nhựa vá săm **không** phải là chất dẻo. Nó là dung dịch cao su dùng làm keo.
> - Keo poly(urea-formaldehyde) và nhựa PPF đều đi từ **formaldehyde** và đều là **trùng ngưng**. Đừng xếp chúng vào loại trùng hợp chỉ vì HCHO có liên kết đôi C=O.

## Dạng bài thi hay gặp

### Dạng 1. Phân loại vật liệu – đếm số chất

**Nhận biết:** "Trong dãy … có bao nhiêu tơ tổng hợp / tơ bán tổng hợp / tơ polyamide / chất dẻo / polymer dùng làm cao su…".

**Phương pháp:**

1. Viết dãy chất ra, gạch đầu dòng từng chất. **Đừng làm nhẩm**.
2. Với **tơ**: hỏi "nguyên liệu đầu là gì?" (mẹo ở mục 3.2).
3. Với **vật liệu**: hỏi "tính chất nổi bật là gì?". Dẻo → chất dẻo. Đàn hồi → cao su. Sợi → tơ. Kết dính → keo.

> [!vi-du] Ví dụ 9
> Cho các polymer: poly(vinyl chloride), polyacrylonitrile, polybuta-1,3-diene, poly(methyl methacrylate), poly(hexamethylene adipamide) (nylon-6,6), polychloroprene, polystyrene.
>
> a) Có bao nhiêu polymer thường dùng làm chất dẻo?
>
> b) Có bao nhiêu polymer dùng làm cao su?
>
> c) Có bao nhiêu polymer dùng làm tơ?

> [!goi-y] Gợi ý 1
> Polyacrylonitrile là tên hoá học của tơ gì? Polychloroprene là cao su gì?

> [!goi-y] Gợi ý 2
> Cao su có monomer là diene liên hợp (buta-1,3-diene, isoprene, chloroprene).

> [!loi-giai] Lời giải
> a) Chất dẻo: poly(vinyl chloride), poly(methyl methacrylate), polystyrene → **3**.
>
> b) Cao su: polybuta-1,3-diene (cao su buna), polychloroprene (cao su chloroprene) → **2**.
>
> c) Tơ: polyacrylonitrile (nitron), nylon-6,6 → **2**.

> [!bay]
> - Đề cố tình dùng **tên hoá học** thay tên thương mại: polyacrylonitrile = nitron, polybuta-1,3-diene = cao su buna. Em cần thuộc cả hai cách gọi.

### Dạng 2. Monomer và loại phản ứng điều chế

**Nhận biết:** "Polymer/tơ/cao su X được điều chế bằng phản ứng trùng hợp hay trùng ngưng?", "Monomer dùng điều chế … là", hoặc câu Đúng/Sai về điều chế vật liệu.

**Phương pháp:** thuộc bảng sau (gom từ Bài 12 và Bài 13).

| Trùng hợp | Trùng ngưng | Cả hai |
|---|---|---|
| PE, PP, PVC, PS, PMMA, nitron, mọi cao su tổng hợp (buna, buna-S, buna-N, isoprene, chloroprene) | nylon-6,6, PPF, poly(urea-formaldehyde), lapsan (PET, mở rộng) | capron (caprolactam hoặc 6-aminohexanoic acid) |

> [!vi-du] Ví dụ 10 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Cao su buna-N được điều chế bằng phản ứng đồng trùng hợp buta-1,3-diene với acrylonitrile.
>
> b) Tơ nitron và tơ capron đều thuộc loại tơ polyamide.
>
> c) Monomer dùng điều chế cao su chloroprene là CH~2~=CCl–CH=CH~2~.
>
> d) Poly(phenol formaldehyde) và poly(urea-formaldehyde) đều được điều chế bằng phản ứng trùng hợp formaldehyde.

> [!goi-y] Gợi ý 1
> Nitron có nhóm –CO–NH– không?

> [!goi-y] Gợi ý 2
> Phản ứng tạo PPF và poly(urea-formaldehyde) có tách nước không?

> [!loi-giai] Lời giải
> a) **Đúng**: buna-N = buta-1,3-diene + acrylonitrile (CH~2~=CH–CN).
>
> b) **Sai**: nitron là polyacrylonitrile, mạch chỉ có C và nhóm –CN treo bên, không có –CO–NH–. Chỉ capron (và nylon-6,6) là polyamide.
>
> c) **Đúng**: chloroprene là 2-chlorobuta-1,3-diene.
>
> d) **Sai**: cả hai đều là **trùng ngưng** (phenol hoặc urea với formaldehyde, tách H~2~O), không phải trùng hợp formaldehyde.

### Dạng 3. Khối lượng vật liệu, số mắt xích

**Nhận biết:** đề cho phân tử khối polymer hỏi số mắt xích; hoặc cho khối lượng nguyên liệu hỏi khối lượng vật liệu (và ngược lại), có hiệu suất.

**Phương pháp:**

1. Nhớ M mắt xích mới của bài này: nitron 53 · polychloroprene 88,5 · PPF 106 · poly(urea-formaldehyde) 72 · cellulose triacetate 288 · cellulose diacetate 246 (và các giá trị ở Bài 12).
2. Trùng hợp: m(polymer) = m(monomer) · H. Trùng ngưng: tính theo mol mắt xích, mắt xích đã mất H~2~O.
3. Nhiều giai đoạn: H chung = tích các H. Đi xuôi nhân H, đi ngược chia H (như Ví dụ 2).

> [!vi-du] Ví dụ 11
> a) Một mẫu cao su chloroprene có phân tử khối trung bình 177 000. Tính số mắt xích trung bình.
>
> b) Trùng ngưng 1,2 tấn urea với lượng formaldehyde vừa đủ, hiệu suất 80%. Tính khối lượng poly(urea-formaldehyde) thu được (làm tròn đến hàng phần trăm, đơn vị tấn).

> [!goi-y] Gợi ý 1
> Mắt xích chloroprene C~4~H~5~Cl: 48 + 5 + 35,5 = ?

> [!goi-y] Gợi ý 2
> Mắt xích –NH–CO–NH–CH~2~– là C~2~H~4~N~2~O. 1 urea (M = 60) cho 1 mắt xích.

> [!loi-giai] Lời giải
> a) M(C~4~H~5~Cl) = 88,5 → n = 177 000 : 88,5 = **2 000**.
>
> b) n(urea) = 1,2 : 60 = 0,02 tấn mol → n(mắt xích) = 0,02 · 0,8 = 0,016.
>
> M(mắt xích) = 24 + 4 + 28 + 16 = 72 → m = 0,016 · 72 ≈ **1,15 tấn**.
>
> (Quên trừ nước, lấy M = 60 + 30 = 90, sẽ ra 1,44 tấn: đáp án nhiễu.)

### Dạng 4. Tỉ lệ mắt xích trong cao su buna-S, buna-N

**Nhận biết:** đề cho lượng Br~2~ phản ứng, phần trăm khối lượng N, hoặc tỉ lệ sản phẩm cháy của cao su buna-S/buna-N; hỏi tỉ lệ mắt xích.

**Phương pháp:**

1. Viết công thức chung: buna-S (C~4~H~6~)~a~(C~8~H~8~)~b~, buna-N (C~4~H~6~)~a~(C~3~H~3~N)~b~. M mắt xích: C~4~H~6~ = 54, C~8~H~8~ = 104, C~3~H~3~N = 53.
2. Chọn dữ kiện:
   - Br~2~ → chỉ cộng vào mắt xích C~4~H~6~ (Ví dụ 7).
   - %N → %N = 14b : (54a + 53b).
   - Đốt cháy → bảo toàn C, H, N theo a và b (xem câu luyện tập cuối bài).
3. Đặt a : b = k (hoặc cho b = 1), giải phương trình, làm tròn về tỉ lệ số nguyên.

> [!vi-du] Ví dụ 12
> Một loại cao su buna-N chứa 8,70% nitrogen về khối lượng. Tính tỉ lệ số mắt xích buta-1,3-diene : acrylonitrile.

> [!goi-y] Gợi ý 1
> Chọn b = 1 (một mắt xích acrylonitrile), còn a mắt xích buta-1,3-diene. Đoạn mạch có 1 nguyên tử N.

> [!goi-y] Gợi ý 2
> 14 : (54a + 53) = 0,087.

> [!loi-giai] Lời giải
> 54a + 53 = 14 : 0,087 ≈ 160,9 → 54a ≈ 107,9 → a ≈ 2,0.
>
> Tỉ lệ buta-1,3-diene : acrylonitrile = **2 : 1**.

> [!bay]
> - Lấy M(acrylonitrile) = 53, **không** phải 52 hay 54. Kiểm tra: C~3~H~3~N = 36 + 3 + 14 = 53.
> - Kết quả gần đúng (như 1,998 hay 2,98…) thì làm tròn về số nguyên gần nhất.

## Tóm tắt

| Vật liệu | Tính chất đặc trưng | Ví dụ (monomer → phản ứng) |
|---|---|---|
| Chất dẻo | tính dẻo (giữ biến dạng) | PE, PP, PVC, PS, PMMA (trùng hợp CH~2~=CHR, methyl methacrylate) · PPF (trùng ngưng phenol + HCHO) |
| Composite | cốt (sợi, hạt) + nền, tính chất vượt trội | sợi carbon + epoxy · sợi thuỷ tinh + nhựa · bột gỗ + nhựa |
| Tơ | sợi mảnh, bền, mạch không nhánh | tự nhiên: bông (cellulose), len, tơ tằm (protein) · tổng hợp: nylon-6,6 (trùng ngưng), capron (trùng hợp mở vòng), nitron (trùng hợp acrylonitrile) · bán tổng hợp: visco, cellulose acetate |
| Cao su | tính đàn hồi (trở lại như cũ) | tự nhiên: polyisoprene *cis* · tổng hợp (đều trùng hợp): buna, buna-S, buna-N, isoprene, chloroprene |
| Keo dán | màng mỏng kết dính hai bề mặt | nhựa vá săm (cao su + dung môi) · epoxy (2 thành phần + amine) · poly(urea-formaldehyde) (trùng ngưng) |

| Cao su | Monomer | M mắt xích |
|---|---|---|
| buna | CH~2~=CH–CH=CH~2~ (xt Na) | 54 |
| buna-S | buta-1,3-diene + styrene CH~2~=CH–C~6~H~5~ | 54 và 104 |
| buna-N | buta-1,3-diene + acrylonitrile CH~2~=CH–CN | 54 và 53 |
| isoprene / tự nhiên | CH~2~=C(CH~3~)–CH=CH~2~ | 68 |
| chloroprene | CH~2~=C(Cl)–CH=CH~2~ | 88,5 |
