---
title: Tinh bột và cellulose
thoi-gian: 45 phút
muc-tieu:
  - Viết được công thức phân tử, mô tả được cấu tạo của tinh bột (amylose, amylopectin) và cellulose; chỉ ra đúng loại liên kết glycoside trong từng chất.
  - Trình bày được tính chất hoá học cơ bản của tinh bột (thuỷ phân, phản ứng màu với iodine) và của cellulose (thuỷ phân, phản ứng với nitric acid, tan trong nước Schweizer).
  - Mô tả hiện tượng và giải thích được các thí nghiệm về tinh bột, cellulose.
  - Nêu được trạng thái tự nhiên, ứng dụng; trình bày được sự tạo thành tinh bột trong cây xanh và sự chuyển hoá tinh bột trong cơ thể.
  - Giải được bài toán thuỷ phân – lên men có hiệu suất nhiều giai đoạn và bài toán điều chế cellulose nitrate.
---

> [!ghi-nho] Bài này trong 5 dòng
> 1. Tinh bột và cellulose đều là **polysaccharide**, cùng công thức (C~6~H~10~O~5~)~n~ nhưng **không phải đồng phân** của nhau (n khác nhau, cấu tạo khác nhau).
> 2. Tinh bột = **amylose** (α-glucose, liên kết **α-1,4**, mạch không nhánh, xoắn) + **amylopectin** (thêm các nhánh nối bằng **α-1,6**).
> 3. Cellulose = **β-glucose** nối bằng liên kết **β-1,4**, mạch thẳng, không nhánh; mỗi mắt xích còn 3 nhóm –OH → viết [C~6~H~7~O~2~(OH)~3~]~n~.
> 4. Cả hai **thuỷ phân hoàn toàn → glucose**. Riêng tinh bột + iodine → **xanh tím**; riêng cellulose + HNO~3~ đặc (H~2~SO~4~ đặc) → **cellulose nitrate**, và cellulose **tan trong nước Schweizer**.
> 5. Bài toán: đi theo chuỗi C~6~H~10~O~5~ → C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~; hiệu suất cả quá trình = **tích** các hiệu suất.

## 1. Cấu tạo phân tử

Hãy hình dung polysaccharide như một **chuỗi hạt** dài hàng nghìn hạt, mỗi hạt là một gốc glucose. Tinh bột và cellulose dùng **cùng một loại hạt**, chỉ khác ở **cách móc các hạt vào nhau**. Chính khác biệt nhỏ đó làm cơm thì mềm, ăn được, còn gỗ thì cứng và người không tiêu hoá được.

> [!nen-tang] α-glucose, β-glucose và liên kết glycoside (Bài 4, Bài 5)
> - Glucose mạch vòng 6 cạnh có nhóm –OH hemiacetal ở **C1**.
> - **α-glucose**: –OH ở C1 nằm **khác phía** với nhóm CH~2~OH (hình vẽ: hướng xuống). **β-glucose**: –OH ở C1 nằm **cùng phía** (hướng lên).
> - **Liên kết glycoside**: –OH ở C1 của gốc này kết hợp với một –OH của gốc kia, tách ra 1 phân tử H~2~O, còn lại cầu nối –O–. Tên liên kết gồm cấu hình ở C1 (α hay β) và số thứ tự hai carbon được nối. Ví dụ: maltose có liên kết α-1,4-glycoside.

### 1.1. Tinh bột

Tinh bột là **polymer thiên nhiên**, công thức phân tử **(C~6~H~10~O~5~)~n~**.

**Vì sao mắt xích là C~6~H~10~O~5~ chứ không phải C~6~H~12~O~6~?** Mỗi lần nối thêm một gốc glucose vào mạch thì tách ra một phân tử nước. Vì vậy mỗi mắt xích = C~6~H~12~O~6~ − H~2~O = C~6~H~10~O~5~ (M = 162).

Tinh bột là hỗn hợp của hai loại phân tử:

- **Amylose**: các gốc **α-glucose** nối với nhau bằng liên kết **α-1,4-glycoside** (C1 của gốc trước nối với C4 của gốc sau). Mạch **không phân nhánh** và cuộn lại thành **chuỗi xoắn** như lò xo.
- **Amylopectin**: gồm nhiều đoạn mạch α-glucose nối bằng liên kết α-1,4. Các đoạn này lại nối với nhau bằng liên kết **α-1,6-glycoside** (C1 ở đầu đoạn nhánh nối vào O của C6 trên mạch chính). Kết quả là mạch **phân nhánh** giống cành cây.

![Hình 1. Amylose (chỉ có liên kết α-1,4) và amylopectin (thêm nhánh α-1,6). Hình Haworth rút gọn, bỏ các nguyên tử H; SGK vẽ dạng ghế (tr. 28)](tinh-bot.svg)

> [!em-co-biet] Gạo nếp và gạo tẻ
> Trong đa số loại tinh bột, amylopectin chiếm phần lớn (khoảng 70–80%). Tinh bột gạo nếp gần như toàn là amylopectin. Các mạch nhánh đan vào nhau nên xôi dẻo và dính hơn cơm gạo tẻ.

> [!vi-du] Ví dụ 1
> Một mẫu amylose có phân tử khối trung bình là 486 000.
>
> a) Tính số gốc glucose trung bình trong một phân tử.
>
> b) Trong phân tử này có những loại liên kết glycoside nào?

> [!goi-y] Gợi ý 1
> Mỗi gốc glucose trong mạch là một mắt xích C~6~H~10~O~5~. Mắt xích này nặng bao nhiêu?

> [!goi-y] Gợi ý 2
> Amylose có phân nhánh không? Liên kết α-1,6 chỉ xuất hiện ở chỗ phân nhánh.

> [!loi-giai] Lời giải
> a) M(C~6~H~10~O~5~) = 6·12 + 10·1 + 5·16 = 162. Số gốc n = 486 000 : 162 = **3 000**.
>
> b) Amylose không phân nhánh, nên chỉ có liên kết **α-1,4-glycoside**.

### 1.2. Cellulose

Cellulose cũng là polymer thiên nhiên có công thức **(C~6~H~10~O~5~)~n~**. Nhưng cellulose được tạo từ các gốc **β-glucose** nối bằng liên kết **β-1,4-glycoside**, thành mạch **thẳng, không phân nhánh**.

**Vì sao mạch cellulose thẳng còn amylose lại xoắn?** Với liên kết β, gốc glucose sau bị lật ngược so với gốc trước, nên mạch kéo dài thẳng ra. Các mạch thẳng xếp **song song**, sát nhau và giữ chặt nhau bằng rất nhiều **liên kết hydrogen** giữa các nhóm –OH. Chúng bó lại thành **sợi** bền chắc, vì thế cellulose không tan trong nước.

**Ba nhóm –OH.** Trong mỗi mắt xích, C1 và C4 đã dùng để nối mạch, còn O của C5 nằm trong vòng. Các nhóm –OH còn tự do nằm ở **C2, C3 và C6**. Vì vậy công thức cellulose hay được viết là **[C~6~H~7~O~2~(OH)~3~]~n~**. Cách viết này rất có ích khi xét phản ứng với HNO~3~ (mục 2.2).

![Hình 2. Cellulose: các gốc β-glucose nối bằng liên kết β-1,4-glycoside, gốc sau lật ngược so với gốc trước (gốc giữa vẽ úp); mỗi mắt xích còn 3 nhóm –OH tự do](cellulose.svg)

> [!meo] Viết nhanh C~6~H~7~O~2~(OH)~3~
> Lấy C~6~H~10~O~5~, tách 3 nhóm OH (gồm 3 H và 3 O) ra viết riêng: còn lại C~6~H~7~O~2~. Kiểm tra lại: C~6~H~7~O~2~(OH)~3~ = C~6~H~10~O~5~.

### 1.3. So sánh cấu tạo

| | Amylose | Amylopectin | Cellulose |
|---|---|---|---|
| Gốc monosaccharide | α-glucose | α-glucose | **β-glucose** |
| Liên kết glycoside | α-1,4 | α-1,4 và **α-1,6** | **β-1,4** |
| Dạng mạch | Không nhánh, xoắn | **Phân nhánh** | Không nhánh, thẳng, xếp thành sợi |

![Hình 3. Hình dạng mạch: amylose xoắn (iodine chui vào lòng xoắn), amylopectin phân nhánh, cellulose gồm các mạch thẳng song song liên kết hydrogen với nhau](hinh-dang.svg)

> [!bay]
> - "Tinh bột và cellulose là đồng phân vì cùng công thức (C~6~H~10~O~5~)~n~": **sai**. Giá trị n khác nhau và cấu tạo khác nhau.
> - Chất có mạch **phân nhánh** là **amylopectin**. Amylose và cellulose đều **không** phân nhánh.
> - Đừng nhầm các liên kết: saccharose có α-1,2; maltose và amylose có α-1,4; nhánh amylopectin là α-1,6; cellulose là **β**-1,4.

## 2. Tính chất hoá học

Phân tử tinh bột và cellulose rất lớn. Cả mạch hàng nghìn gốc chỉ còn khoảng một nhóm –OH hemiacetal ở đầu mạch, nên chúng **không có tính khử** như glucose: **không** tráng bạc, **không** khử Cu(OH)~2~. Chúng cũng **không** hoà tan Cu(OH)~2~ tạo dung dịch xanh lam (xem bảng tổng kết ở Bài 7, SGK tr. 34). Phản ứng quan trọng là **cắt liên kết glycoside** (thuỷ phân) và phản ứng riêng của từng chất.

### 2.1. Tính chất của tinh bột

**a) Phản ứng thuỷ phân**

Tóm tắt thí nghiệm (SGK tr. 29): cho HCl vào hồ tinh bột rồi đun cách thuỷ khoảng 10 phút. Trung hoà acid bằng NaHCO~3~. Lấy dung dịch thu được cho vào Cu(OH)~2~ trong NaOH và đun nóng: xuất hiện **kết tủa đỏ gạch** Cu~2~O.

**Giải thích:** tinh bột đã bị thuỷ phân thành glucose, và glucose khử Cu(OH)~2~ khi đun nóng (Bài 4).

**Vì sao phải trung hoà acid trước?** Nếu còn HCl, acid sẽ hoà tan Cu(OH)~2~ (phản ứng acid – base), làm hỏng thuốc thử. Phản ứng oxi hoá glucose bằng Cu(OH)~2~ cần môi trường kiềm.

Tinh bột bị thuỷ phân nhờ **acid** hoặc **enzyme**. Quá trình diễn ra **từng bước**: mạch dài bị cắt dần thành **dextrin** (mạch ngắn hơn), rồi **maltose**, cuối cùng là **glucose**. Thuỷ phân không hoàn toàn thu được hỗn hợp dextrin, maltose, glucose. Thuỷ phân hoàn toàn chỉ thu được glucose.

=> (C~6~H~10~O~5~)~n~ + nH~2~O → nC~6~H~12~O~6~ (glucose)    (xúc tác enzyme hoặc H^+^, t°)

> [!meo] Bỏ chữ n cho nhanh
> Khi tính toán, coi tinh bột (hay cellulose) như "C~6~H~10~O~5~" (M = 162): 1 mắt xích → 1 glucose (M = 180). Tỉ lệ khối lượng 162 : 180 = 9 : 10.

> [!vi-du] Ví dụ 2
> Thuỷ phân 48,6 g tinh bột trong môi trường acid với hiệu suất 75%. Tính khối lượng glucose thu được.

> [!goi-y] Gợi ý 1
> Tính số mol mắt xích C~6~H~10~O~5~, rồi suy ra số mol glucose theo lí thuyết.

> [!goi-y] Gợi ý 2
> Đi từ chất đầu ra sản phẩm thì sản phẩm thực tế = lí thuyết × H.

> [!loi-giai] Lời giải
> n(C~6~H~10~O~5~) = 48,6 : 162 = 0,3 mol → n(glucose) lí thuyết = 0,3 mol.
>
> m(glucose) = 0,3 · 180 · 0,75 = **40,5 g**.

**b) Phản ứng màu với dung dịch iodine**

Nhỏ vài giọt dung dịch iodine vào hồ tinh bột: xuất hiện **màu xanh tím**.

**Vì sao?** Mạch amylose cuộn xoắn tạo thành một "ống" rỗng. Các phân tử iodine chui vào lòng ống xoắn này và tạo ra màu xanh tím (Hình 3). Phản ứng này dùng để **nhận biết tinh bột**. Ngược lại, hồ tinh bột cũng dùng để nhận biết iodine.

> [!em-co-biet] Đun nóng thì mất màu
> Đun nóng ống nghiệm có màu xanh tím thì màu biến mất, vì mạch xoắn giãn ra và iodine thoát khỏi lòng xoắn. Để nguội, màu xanh tím xuất hiện trở lại. Nhỏ iodine lên lát chuối xanh thấy xanh tím đậm. Với chuối chín, màu nhạt hơn nhiều, vì phần lớn tinh bột đã chuyển thành đường.

### 2.2. Tính chất của cellulose

**a) Phản ứng thuỷ phân**

Tóm tắt thí nghiệm (SGK tr. 30): khuấy bông trong dung dịch H~2~SO~4~ 70% và đun nóng cho tan hết. Trung hoà acid, thêm NaOH, rồi cho tác dụng với Cu(OH)~2~ và đun nóng: có **kết tủa đỏ gạch**. Vậy cellulose đã bị thuỷ phân thành glucose.

=> (C~6~H~10~O~5~)~n~ + nH~2~O → nC~6~H~12~O~6~ (glucose)    (xúc tác enzyme hoặc H^+^, t°)

Cellulose khó thuỷ phân hơn tinh bột: cần acid đặc hơn, đun lâu hơn, vì các mạch thẳng xếp rất chặt. Cơ thể người **không có enzyme cắt được liên kết β-1,4**, nên không tiêu hoá được cellulose. Trâu, bò tiêu hoá được cỏ là nhờ vi sinh vật sống trong dạ cỏ.

> [!ung-dung] Vì sao tinh bột và cellulose đều sản xuất được ethanol?
> Cả hai đều thuỷ phân thành glucose, và glucose lên men cho ethanol (Bài 4):
>
> => C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~    (enzyme)
>
> Ethanol làm từ ngô, sắn (tinh bột) hay rơm rạ, mùn cưa (cellulose) gọi là **ethanol sinh học**, được pha vào xăng thành xăng E5, E10.

**b) Phản ứng với nitric acid**

Mỗi mắt xích cellulose có 3 nhóm –OH, nên cellulose có tính chất giống alcohol: tạo **ester** với nitric acid. Khi đun nóng cellulose với hỗn hợp HNO~3~ đặc và H~2~SO~4~ đặc, tuỳ điều kiện mà 1, 2 hoặc cả 3 nhóm –OH được thay bằng nhóm –ONO~2~, tạo ra **cellulose nitrate**. Nếu cả 3 nhóm bị thay thế:

=> [C~6~H~7~O~2~(OH)~3~]~n~ + 3nHNO~3~ → [C~6~H~7~O~2~(ONO~2~)~3~]~n~ + 3nH~2~O    (H~2~SO~4~ đặc, t°)

Sản phẩm là **cellulose trinitrate**. Trong thí nghiệm SGK (tr. 30–31), bông sau phản ứng được rửa sạch acid, làm khô rồi đốt: nó **cháy bùng rất nhanh**, gần như không khói, không tro, khác hẳn bông thường. Vì vậy cellulose trinitrate được dùng làm **thuốc súng không khói**.

- **Vai trò của H~2~SO~4~ đặc**: làm xúc tác và **hút nước**, giúp phản ứng tạo ester xảy ra nhiều hơn.
- **Quan hệ khối lượng**: 1 mắt xích (162) phản ứng với 3HNO~3~ (3·63) tạo 1 mắt xích trinitrate (297). Mỗi nhóm –OH đổi thành –ONO~2~ làm khối lượng tăng thêm 45.

> [!vi-du] Ví dụ 3
> Người ta điều chế 29,7 kg cellulose trinitrate từ cellulose và nitric acid, hiệu suất 90%.
>
> a) Tính khối lượng HNO~3~ cần dùng.
>
> b) Tính thể tích dung dịch HNO~3~ 96% (D = 1,52 g/mL) cần dùng (làm tròn đến hàng phần mười, đơn vị lít).

> [!goi-y] Gợi ý 1
> n(mắt xích trinitrate) = 29,7 : 297. Mỗi mắt xích cần 3 HNO~3~.

> [!goi-y] Gợi ý 2
> Lượng sản phẩm đã cho trước, cần tìm chất phản ứng nên phải lấy **nhiều hơn** lí thuyết: **chia** cho H. Đổi D = 1,52 g/mL = 1,52 kg/L.

> [!loi-giai] Lời giải
> a) n(trinitrate) = 29,7 : 297 = 0,1 kmol → n(HNO~3~) lí thuyết = 0,3 kmol.
>
> m(HNO~3~) cần = 0,3 · 63 : 0,9 = **21 kg**.
>
> b) m(dung dịch) = 21 : 0,96 = 21,875 kg → V = 21,875 : 1,52 ≈ **14,4 L**.

**c) Cellulose tan trong nước Schweizer**

**Nước Schweizer** là dung dịch thu được khi hoà tan Cu(OH)~2~ trong dung dịch ammonia đặc. Dung dịch này có màu xanh lam đậm, chứa ion phức [Cu(NH~3~)~4~]^2+^. Cách điều chế theo SGK (tr. 31):

=> CuSO~4~ + 2NaOH → Cu(OH)~2~↓ + Na~2~SO~4~

=> Cu(OH)~2~ + 4NH~3~ → \[Cu(NH~3~)~4~\](OH)~2~

Cellulose **không tan** trong nước (kể cả khi đun nóng), trong ether hay benzene, nhưng **tan được trong nước Schweizer**, tạo dung dịch nhớt. Tính chất này dùng để hoà tan cellulose rồi kéo lại thành sợi nhân tạo.

> [!bay]
> - Cellulose nitrate là **ester** (nhóm –ONO~2~ gắn qua O), **không phải** hợp chất nitro.
> - Tinh bột và cellulose **không** phản ứng với Cu(OH)~2~ ở nhiệt độ thường, **không** tráng bạc. Chỉ sau khi thuỷ phân (tạo glucose) mới có các phản ứng đó.
> - Tan trong nước Schweizer là đặc trưng của **cellulose**. Phản ứng màu với iodine là đặc trưng của **tinh bột**.

## 3. Trạng thái tự nhiên và ứng dụng

### 3.1. Tinh bột

**Tính chất vật lí.** Tinh bột ở dạng bột trắng. Cho vào nước lạnh thì nó gần như không tan, chỉ lắng xuống. Đun với nước, hạt tinh bột hút nước, trương phồng rồi vỡ ra, cho một chất lỏng sánh, nhớt gọi là **hồ tinh bột** (như khi nấu cháo, quấy hồ dán).

**Trạng thái tự nhiên.** Tinh bột có nhiều trong hạt (gạo chứa khoảng 80% tinh bột, ngô, lúa mì), củ (khoai, sắn) và quả (chuối xanh).

**Sự tạo thành tinh bột trong cây xanh.** Quá trình này gồm hai giai đoạn chính. Đầu tiên, lá cây **quang hợp** tạo ra glucose. Sau đó, các phân tử glucose kết hợp với nhau thành tinh bột và được dự trữ trong hạt, củ, quả. Phương trình tổng cộng:

=> 6nCO~2~ + 5nH~2~O → (C~6~H~10~O~5~)~n~ + 6nO~2~    (ánh sáng, chất diệp lục)

**Vì sao là 5nH~2~O mà không phải 6nH~2~O?** Quang hợp tạo n glucose cần 6nH~2~O. Nhưng khi n glucose nối thành tinh bột, mỗi gốc lại tách ra 1 H~2~O. Tính tổng cộng chỉ tiêu tốn 6n − n = 5n phân tử nước.

![Hình 4. Sự tạo thành tinh bột trong cây xanh và sự chuyển hoá tinh bột trong cơ thể người](chuyen-hoa.svg)

**Sự chuyển hoá tinh bột trong cơ thể** (Hình 4):

1. Ở **miệng**, enzyme **α-amylase** trong nước bọt thuỷ phân một phần tinh bột thành **dextrin** và **maltose**. Vì vậy khi nhai cơm thật kĩ, em thấy vị ngọt.
2. Ở **ruột non**, phần lớn tinh bột tiếp tục bị thuỷ phân đến **glucose**.
3. Glucose được hấp thụ vào **máu** và đưa đến các tế bào. Ở đó glucose bị oxi hoá thành CO~2~ và H~2~O để cung cấp năng lượng, hoặc được chuyển thành **glycogen** dự trữ trong **gan và cơ**.

**Ứng dụng.** Cơm, bánh mì, ngô, khoai… là nguồn năng lượng chính của người và vật nuôi, và phần lớn năng lượng đó đến từ tinh bột. Ngành thực phẩm dùng tinh bột để làm sánh, kết dính (bột năng trong chè, súp), và làm nguyên liệu sản xuất glucose, mạch nha, ethanol. Ngành giấy và dệt dùng tinh bột làm hồ giấy, hồ vải.

> [!ung-dung] Chọn nguồn tinh bột hợp lí
> Tinh bột trong gạo lứt, yến mạch, khoai còn nguyên dạng được tiêu hoá **chậm** hơn so với bánh mì trắng hay đồ ngọt làm từ bột tinh chế, nên đường huyết tăng từ từ hơn. Người cần kiểm soát đường huyết nên ưu tiên các nguồn tinh bột này, kèm nhiều rau (chất xơ).

### 3.2. Cellulose

**Tính chất vật lí.** Bông gòn gần như là cellulose nguyên chất: sợi trắng, xốp. Ngâm bông trong nước sôi, hay trong ether, benzene, bông vẫn không tan, vì các mạch cellulose liên kết hydrogen với nhau rất chặt.

**Trạng thái tự nhiên.** Cellulose do thực vật tổng hợp và là thành phần chính của thành tế bào thực vật. Nó chiếm khoảng **50%** khối lượng gỗ khô và khoảng **90%** khối lượng sợi bông. Đay, gai, tre, rơm rạ cũng chứa nhiều cellulose.

**Ứng dụng:**

- Vật liệu xây dựng, đồ gỗ.
- Sản xuất **giấy**.
- Sợi tự nhiên (bông, đay) và **sợi nhân tạo**: tơ visco, tơ cellulose acetate (sẽ học ở chương Polymer).
- Nguyên liệu điều chế **ethanol** (ethanol sinh học) và **cellulose trinitrate** (thuốc súng không khói).

> [!em-co-biet] Chất xơ
> Người không tiêu hoá được cellulose, nhưng cellulose trong rau, củ vẫn rất có ích. Nó là **chất xơ**, giúp tăng khối lượng phân, kích thích nhu động ruột và chống táo bón.

## Dạng bài thi hay gặp

### Dạng 1. Thuỷ phân – lên men qua nhiều giai đoạn có hiệu suất

**Nhận biết:** đề cho khối lượng nguyên liệu (gạo, ngô, sắn, mùn cưa, rơm…) chứa x% tinh bột hoặc cellulose. Đề hỏi khối lượng glucose, ethanol, thể tích rượu, hoặc lượng CO~2~ (thường cho hấp thụ vào nước vôi trong). Có thể hỏi ngược: cần bao nhiêu nguyên liệu.

**Phương pháp:**

1. Tính khối lượng tinh bột/cellulose thật: m = m(nguyên liệu) × x%.
2. Viết sơ đồ gọn theo mắt xích: C~6~H~10~O~5~ → C~6~H~12~O~6~ → 2C~2~H~5~OH + 2CO~2~. Tỉ lệ mol là 1 → 1 → 2 và 2.
3. Hiệu suất cả quá trình: H = H~1~ · H~2~ · …
4. **Đi xuôi** (từ nguyên liệu tìm sản phẩm) thì **nhân** H. **Đi ngược** (từ sản phẩm tìm nguyên liệu) thì **chia** H.
5. Rượu: V(ethanol) = m : D (D = 0,8 g/mL); V(rượu) = V(ethanol) · 100 : độ rượu.
6. CO~2~ vào nước vôi trong: nếu chỉ thu được kết tủa thì n(CO~2~) = n(CaCO~3~). Nếu lọc kết tủa rồi đun nóng dung dịch thấy có thêm kết tủa (do Ca(HCO~3~)~2~ bị phân huỷ) thì n(CO~2~) = n(↓ lần 1) + 2·n(↓ lần 2).

> [!vi-du] Ví dụ 4
> Từ 1 tấn gạo chứa 81% tinh bột, người ta sản xuất ethanol. Hiệu suất giai đoạn thuỷ phân là 80%, hiệu suất giai đoạn lên men là 75%.
>
> a) Tính khối lượng ethanol thu được.
>
> b) Tính thể tích rượu 40° pha được (D của ethanol là 0,8 g/mL).

> [!goi-y] Gợi ý 1
> m(tinh bột) = 810 kg. Số kmol mắt xích = 810 : 162. Nhớ rằng 1 glucose cho **2** C~2~H~5~OH.

> [!goi-y] Gợi ý 2
> H chung = 0,8 · 0,75 = 0,6. Rượu 40° nghĩa là 100 L rượu có 40 L ethanol nguyên chất.

> [!loi-giai] Lời giải
> a) n(C~6~H~10~O~5~) = 810 : 162 = 5 kmol → n(C~2~H~5~OH) lí thuyết = 2 · 5 = 10 kmol.
>
> m(C~2~H~5~OH) = 10 · 46 · 0,8 · 0,75 = **276 kg**.
>
> b) V(ethanol) = 276 : 0,8 = 345 L (0,8 g/mL = 0,8 kg/L) → V(rượu 40°) = 345 · 100 : 40 = **862,5 L**.

> [!vi-du] Ví dụ 5
> Lên men m gam tinh bột thành ethanol với hiệu suất cả quá trình là 75%. Toàn bộ CO~2~ sinh ra được hấp thụ vào dung dịch Ca(OH)~2~, thu được 50 g kết tủa và dung dịch X. Đun nóng X thu thêm 25 g kết tủa nữa. Tính m.

> [!goi-y] Gợi ý 1
> Đun nóng X lại có kết tủa, nghĩa là X chứa Ca(HCO~3~)~2~: Ca(HCO~3~)~2~ → CaCO~3~ + CO~2~ + H~2~O. Mỗi mol kết tủa lần 2 ứng với 2 mol CO~2~ ban đầu.

> [!goi-y] Gợi ý 2
> Từ n(CO~2~) suy ra n(C~6~H~10~O~5~) = n(CO~2~) : 2. Đây là bài đi ngược nên chia cho H.

> [!loi-giai] Lời giải
> n(CO~2~) = 50 : 100 + 2 · (25 : 100) = 0,5 + 0,5 = 1 mol.
>
> n(C~6~H~10~O~5~) lí thuyết = 1 : 2 = 0,5 mol.
>
> m = 0,5 · 162 : 0,75 = **108 g**.

> [!bay]
> - Quên hệ số **2** (1 glucose → 2 ethanol + 2 CO~2~) là lỗi phổ biến nhất.
> - Nhân H khi đi ngược: kết quả sẽ nhỏ hơn đáp án đúng. Hãy tự hỏi: "Có hao hụt thì cần **nhiều** hay **ít** nguyên liệu hơn?"
> - Độ rượu là phần trăm **thể tích**, không phải phần trăm khối lượng.
> - Đừng quên bước nhân x% (hàm lượng tinh bột/cellulose trong nguyên liệu).

### Dạng 2. Điều chế cellulose nitrate

**Nhận biết:** cellulose + HNO~3~ (H~2~SO~4~ đặc) → cellulose trinitrate (thuốc súng không khói). Đề hỏi khối lượng sản phẩm, lượng HNO~3~ hoặc thể tích dung dịch HNO~3~, có hiệu suất. Đề cũng có thể cho %N để tìm số nhóm –ONO~2~.

**Phương pháp:**

1. Dùng mắt xích: C~6~H~7~O~2~(OH)~3~ (162) + 3HNO~3~ → C~6~H~7~O~2~(ONO~2~)~3~ (297) + 3H~2~O.
2. Tìm HNO~3~ thì chia H. Đổi sang dung dịch: m(dd) = m(chất tan) · 100 : C%; V = m(dd) : D.
3. Mắt xích có x nhóm nitrate: M = 162 + 45x. Từ đó %N = 14x : (162 + 45x) · 100%. Kết quả: x = 1 có 6,76% N; x = 2 có 11,11% N; x = 3 có 14,14% N.

> [!vi-du] Ví dụ 6
> Một loại cellulose nitrate có chứa 11,11% nitrogen về khối lượng. Xác định số nhóm –OH trong mỗi mắt xích đã bị ester hoá và viết công thức của chất đó.

> [!goi-y] Gợi ý 1
> Mỗi nhóm –OH đổi thành –ONO~2~ thì mắt xích nặng thêm 46 − 1 = 45, và có thêm 1 nguyên tử N.

> [!goi-y] Gợi ý 2
> Lập phương trình 14x : (162 + 45x) = 0,1111.

> [!loi-giai] Lời giải
> 14x = 0,1111 · (162 + 45x) → 14x − 5x ≈ 18 → x ≈ 2.
>
> Mỗi mắt xích có 2 nhóm –OH đã bị ester hoá. Công thức là [C~6~H~7~O~2~(OH)(ONO~2~)~2~]~n~ (cellulose dinitrate). Kiểm tra: M = 252, %N = 28 : 252 · 100% = 11,11%. ✓

> [!bay]
> - Lượng HNO~3~ cần dùng = lí thuyết **chia** H (không nhân H).
> - Mỗi mắt xích cần **3** HNO~3~. Đừng tính 1 : 1.
> - Thuốc súng không khói là cellulose **tri**nitrate.

### Dạng 3. Phân biệt chất và câu Đúng/Sai lí thuyết

**Nhận biết:** đề cho dãy carbohydrate (glucose, fructose, saccharose, maltose, tinh bột, cellulose), hỏi thuốc thử phân biệt, đếm số chất có một tính chất, hoặc cho 4 ý Đúng/Sai về cấu tạo, thí nghiệm, ứng dụng.

**Phương pháp:** dùng bảng "dấu hiệu nhận biết" dưới đây. Với câu Đúng/Sai, soát kĩ các từ khoá: **α hay β**, **có nhánh hay không**, **sản phẩm thuỷ phân**, **chất nào phản ứng với iodine/HNO~3~/nước Schweizer**.

| Thuốc thử | Glucose | Saccharose | Tinh bột | Cellulose |
|---|---|---|---|---|
| Nước (lạnh) | tan | tan | không tan (nước nóng → hồ) | không tan |
| Cu(OH)~2~, nhiệt độ thường | xanh lam | xanh lam | không | không |
| Thuốc thử Tollens | kết tủa Ag | không | không | không |
| Dung dịch iodine | không | không | **xanh tím** | không |
| Thuỷ phân | không | glucose + fructose | glucose | glucose |

> [!vi-du] Ví dụ 7
> Có ba ống nghiệm không nhãn, mỗi ống chứa một trong các dung dịch: glucose, saccharose, hồ tinh bột. Hãy chọn thuốc thử để nhận biết từng dung dịch.

> [!goi-y] Gợi ý 1
> Chất nào có phản ứng màu riêng, chỉ cần một thuốc thử là nhận ra ngay?

> [!goi-y] Gợi ý 2
> Còn lại glucose và saccharose. Chất nào có nhóm aldehyde (có tính khử)?

> [!loi-giai] Lời giải
> Bước 1: nhỏ dung dịch iodine vào mỗi ống. Ống chuyển **xanh tím** là hồ tinh bột.
>
> Bước 2: cho hai dung dịch còn lại tác dụng với thuốc thử Tollens rồi ngâm nước nóng. Ống có lớp **bạc sáng** là glucose. Ống không có hiện tượng là saccharose.
>
> (Không dùng Cu(OH)~2~ ở nhiệt độ thường để phân biệt glucose với saccharose, vì cả hai đều cho dung dịch xanh lam.)

> [!vi-du] Ví dụ 8 (Đúng/Sai)
> Xét các phát biểu sau:
>
> a) Amylose và cellulose đều có mạch không phân nhánh.
>
> b) Thuỷ phân hoàn toàn tinh bột hoặc cellulose đều chỉ thu được glucose.
>
> c) Cellulose có phản ứng màu với iodine vì có nhiều nhóm –OH.
>
> d) Tinh bột và cellulose là đồng phân của nhau.

> [!goi-y] Gợi ý 1
> Nhớ lại: chỉ amylopectin có nhánh. Màu với iodine cần mạch xoắn.

> [!goi-y] Gợi ý 2
> Đồng phân phải có **cùng** công thức phân tử, tức là cùng giá trị n.

> [!loi-giai] Lời giải
> a) **Đúng**: amylose (α-1,4) và cellulose (β-1,4) đều không nhánh.
>
> b) **Đúng**: cả hai đều được tạo từ các gốc glucose.
>
> c) **Sai**: chỉ tinh bột (mạch amylose xoắn) mới cho màu xanh tím với iodine. Cellulose không có phản ứng này.
>
> d) **Sai**: giá trị n khác nhau, nên công thức phân tử khác nhau.

## Tóm tắt

| | Tinh bột | Cellulose |
|---|---|---|
| Công thức | (C~6~H~10~O~5~)~n~ | (C~6~H~10~O~5~)~n~ hay [C~6~H~7~O~2~(OH)~3~]~n~ |
| Gốc, liên kết | α-glucose; amylose: α-1,4; amylopectin: α-1,4 và α-1,6 | β-glucose; β-1,4 |
| Dạng mạch | Amylose xoắn, không nhánh; amylopectin phân nhánh | Thẳng, không nhánh, xếp thành sợi |
| Tính chất vật lí | Bột trắng, không tan trong nước lạnh; nước nóng → hồ | Sợi trắng, không tan trong nước và dung môi thường |
| Thuỷ phân (H^+^ hoặc enzyme) | → dextrin → maltose → glucose | → glucose |
| Phản ứng riêng | Iodine → xanh tím | HNO~3~ đặc/H~2~SO~4~ đặc → cellulose nitrate; tan trong nước Schweizer |
| Có trong | Hạt, củ, quả (gạo ~80%) | Bông ~90%, gỗ khô ~50% |
| Ứng dụng | Lương thực, thực phẩm, glucose, ethanol, hồ giấy/vải | Gỗ, giấy, sợi, tơ visco/acetate, ethanol, thuốc súng không khói |

**Các tỉ lệ dùng trong tính toán:**

- C~6~H~10~O~5~ (162) → C~6~H~12~O~6~ (180) → 2C~2~H~5~OH (2·46) + 2CO~2~ (2·44).
- C~6~H~7~O~2~(OH)~3~ (162) + 3HNO~3~ (3·63) → C~6~H~7~O~2~(ONO~2~)~3~ (297).
- Quang hợp: 6nCO~2~ + 5nH~2~O → (C~6~H~10~O~5~)~n~ + 6nO~2~.
- H chung = H~1~·H~2~·…; đi xuôi nhân H, đi ngược chia H.
