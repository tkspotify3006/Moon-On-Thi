# Hướng dẫn thêm và sửa nội dung

Toàn bộ nội dung nằm trong thư mục `content/`. Khi thêm hoặc sửa bài, **không cần đụng vào code**.

## 1. Thêm một bài mới

1. Mở `content/catalog.json` và tìm bài trong danh sách (đã có sẵn theo mục lục SGK).
2. Tạo thư mục trùng mã bài, ví dụ `content/lop-12/hoa/b05/`. Trong đó tạo 2 file `bai.md` và `quiz.json`. Có thể chép từ một bài đã có rồi sửa.
3. Trong `catalog.json`, thêm `"ready": true` vào bài đó:
   ```json
   { "id": "b05", "title": "Saccharose và maltose", "pages": "25–27", "ready": true }
   ```
4. Chạy `node scripts/kiem-tra.mjs`. Nếu báo **0 lỗi** thì đưa lên GitHub.

## 2. Viết bài học (`bai.md`)

Bài viết bằng Markdown, phần đầu là thông tin bài:

```markdown
---
title: Saccharose và maltose
thoi-gian: 30 phút
muc-tieu:
- Mục tiêu 1
- Mục tiêu 2
---

## 1. Tiêu đề mục lớn         ← hiện thành nút trong mục lục của bài
### 1.1. Mục nhỏ

Chữ **đậm**, *nghiêng*, bảng | a | b |, danh sách - …
```

**Ký hiệu hóa học, toán học:**

| Gõ | Hiển thị |
|---|---|
| `H~2~SO~4~` | H₂SO₄ (chỉ số dưới) |
| `Fe^3+^`, `2^4^` | Fe³⁺, 2⁴ (chỉ số trên) |
| `=> A + B → C` | phương trình, canh giữa trong khung |
| `$\int_0^1 x^2\,dx$` | công thức Toán (KaTeX) trong dòng |
| `$$\overrightarrow{AB}=(x_B-x_A;\,y_B-y_A;\,z_B-z_A)$$` | công thức Toán riêng một dòng |

Trong `$…$` viết LaTeX (chỉ số dưới `x_1`, mũ `x^2`); ngoài `$` dùng `~ ~` và `^ ^` như trên. Không bọc công thức **hóa học** trong `$`.

**Hình:** `![Chú thích hình](ten-hinh.svg)`. Đặt file hình vào cùng thư mục với bài. Ưu tiên SVG dùng `currentColor`, để hình tự đổi màu khi bật giao diện tối.

**Khung nổi bật** (dùng đúng các mã sau):

```markdown
> [!ghi-nho] Tiêu đề (có thể bỏ trống)
> Nội dung…

> [!bay]        Bẫy hay gặp / dễ nhầm khi thi
> [!meo]        Mẹo làm bài, mẹo bấm máy
> [!nen-tang]   Kiến thức nền lớp 10–11 cần nhớ
> [!ung-dung]   Ứng dụng thực tế
> [!em-co-biet] Mở rộng thú vị
> [!vi-du]      Đề bài ví dụ
> [!goi-y]      Gợi ý (bấm để mở) — có thể nhiều nấc liên tiếp
> [!loi-giai]   Lời giải (bấm để mở)
```

**Nguyên tắc biên soạn:**

- Bám mục lục và trọng tâm của SGK; giảng cho học sinh tự học hiểu được.
- Diễn đạt lại bằng lời của mình, không chép nguyên văn sách.
- Ví dụ mẫu luôn có gợi ý từng nấc trước lời giải.
- Mỗi mục lớn nên có ít nhất một "vì sao" (giải thích bản chất) và một ứng dụng thực tế.

## 3. Viết câu hỏi (`quiz.json`)

```json
{
  "questions": [
    { "id": "q01", "type": "mcq", "level": 1,
      "q": "Câu hỏi…",
      "options": ["A", "B", "C", "D"],
      "answer": 1,
      "explain": "Vì sao đúng / vì sao các đáp án khác sai",
      "ref": "SGK tr. 26" },

    { "id": "q02", "type": "multi", "q": "Chọn tất cả…", "options": ["…"], "answer": [0, 2], "explain": "…" },

    { "id": "q03", "type": "tf", "q": "Xét các nhận định:",
      "statements": [
        { "s": "Nhận định 1", "a": true },
        { "s": "Nhận định 2", "a": false, "why": "Giải thích riêng cho ý này" }
      ],
      "explain": "…" },

    { "id": "q04", "type": "short", "q": "… (làm tròn đến hàng phần mười)", "answer": "2,5", "explain": "…" }
  ]
}
```

- `answer` **đếm từ 0**: A = 0, B = 1, C = 2, D = 3. Thứ tự đáp án sẽ được xáo trộn khi hiển thị.
- `"fixed": true` giữ nguyên thứ tự đáp án (dùng khi có lựa chọn "Tất cả đều đúng", hoặc các đáp án là dãy số tăng dần).
- `level`: 1 = Nhớ, 2 = Hiểu, 3 = Vận dụng. Nên có đủ cả 3 mức.
- `tf` (Đúng/Sai): nên đúng **4 ý** như đề thi; app báo "đúng x/4 ý — được … điểm" theo thang 0,1 / 0,25 / 0,5 / 1.
- `short` (trả lời ngắn): `answer` là chuỗi số `"12"`, `"-1,5"` (tối đa 4 ký tự như đề thi). Có thể thêm `"accept": ["3/2"]` và `"tol": 0.01`.
- **Không đổi `id` của câu đã đăng.** Tiến độ ôn tập của người học gắn với `id`. Có thể sửa nội dung câu thoải mái.
- Nên có 20–35 câu mỗi bài, mỗi câu đều có `explain`.

## 4. Thêm phần mới (chuyên đề, lớp 11…)

Trong `catalog.json`, thêm một phần tử vào `years` (ví dụ `{ "id": "chuyen-de", "title": "Chuyên đề học tập 12", "subjects": [ … ] }`) rồi tạo thư mục `content/chuyen-de/…` theo cùng quy ước.

## 5. Khi sửa code giao diện

Nếu sửa `index.html`, `style.css` hoặc `js/`, hãy tăng số phiên bản trong **`js/version.js`** (ví dụ `0.2.0` → `0.2.1`). Như vậy điện thoại người dùng mới tải bản giao diện mới. Sửa nội dung trong `content/` thì không cần: bài học luôn được lấy bản mới khi có mạng.

## Bộ đề ôn thi (nhập riêng trên máy)

Dùng cho tài liệu ôn tập **lưu hành nội bộ** — KHÔNG đặt trong repo. Người học bấm *Ôn tập → Ôn thi theo đề cương → Nhập bộ đề* và chọn file `.json`; file được lưu trong bộ nhớ trình duyệt của máy đó (`localStorage`, khóa `onThiThpt.banks`). Nhập lại file cùng `id` = cập nhật, tiến độ giữ nguyên.

```json
{ "kind": "hocy-bank", "v": 1, "id": "de-thi-thu-truong", "title": "Đề thi thử của trường", "short": "Đề trường",
  "subject": "lop-12/sinh", "version": "2026-10-14", "note": "…",
  "groups": [ { "id": "m1p1", "title": "Mức độ 1 — Phần 1", "level": 1 } ],
  "questions": [ { "id": "m1p1-01", "group": "m1p1", "n": 1, "type": "mcq", "level": 1, "levelLabel": "Mức độ 1",
      "q": "…", "options": ["…", "…"], "answer": 0, "explain": "…", "warn": "",
      "see": { "lesson": "lop-12/sinh/b08", "h": "m-…" } } ] }
```

- `answer` 0-based; app luôn trộn thứ tự phương án → lời giải không được gọi "A/B/C/D".
- `warn`: ghi chú ⚠ (đề có vấn đề, nên hỏi lại thầy cô) — hiện sau khi trả lời, và có bộ lọc riêng.
- `see`: mục lý thuyết liên quan (`h` = id tiêu đề trong bài, dạng `m-…`); bấm "Xem lý thuyết" mở khung xem nhanh, không rời bài đang làm.
- Chỉ cho phép thẻ `<sub> <sup> <br>`; chỉ số `H~2~O`, mũ `x^2^` như bài học.
- Khóa tiến độ: `<subject>/@<id>#<mã câu>` → câu sai tự vào Ôn tập và lọc theo môn được.
