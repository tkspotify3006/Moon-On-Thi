# Dùng: python3 scripts/mark-ready.py toan:b11 hoa:b13 ...
import json,sys
p='content/catalog.json'; c=json.load(open(p))
want={tuple(a.split(':')) for a in sys.argv[1:]}
n=0
for s in c['years'][0]['subjects']:
    for part in s['parts']:
        for l in part['lessons']:
            if (s['id'],l['id']) in want: l['ready']=True; n+=1
json.dump(c,open(p,'w'),ensure_ascii=False,indent=1)
print('marked',n,'of',len(want))
