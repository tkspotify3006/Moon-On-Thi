# Biên bản thẩm định Hóa 12 (đợt 2): b04, b08, b09

- b04: Giới thiệu về carbohydrate. Glucose và fructose
- b08: Amine
- b09: Amino acid và peptide

Ngày 24/10/2026. Đối chiếu SGK KNTT Hóa 12, tr. 20–24, 35–40, 41–45 (PDF 22–26, 37–42, 43–47).

Cách kiểm:
- Giải lại độc lập cả 84 câu quiz (45 mcq, 14 tf × 4 ý, 25 short) và mọi ví dụ trong bai.md bằng python (`scratchpad/rv-hoa-2/kt.py`). Tất cả kết quả số đều khớp.
- Render 12 hình SVG bằng Playwright và tự xem từng hình.
- Mở 3 bài và 3 quiz trong app (390×844): không có `.katex-error`, không có ảnh hỏng, không có lỗi console.
- `kiem-tra.mjs`: 0 lỗi, 0 cảnh báo. Dòng "No character metrics 'ặ'" không do 3 bài này gây ra.

## Lỗi nghiêm trọng

Không có. Không câu nào sai đáp án, không mcq nào có 2 đáp án đúng, và không hình nào sai cấu tạo.

## Lỗi nhỏ đã sửa (11)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b04 `q13` explain | Ghi "4,9 g là Cu(OH)~2~ nếu dùng tỉ lệ 2 : 1", nhưng tỉ lệ 2 : 1 cho ra 2,45 g. Thực ra 4,9 g = 0,05 · 98, tức là nhầm chất kết tủa. | Viết lại giải thích cho cả 3 phương án nhiễu (4,9 / 14,4 / 3,6). |
| b04 bai.md, khung "Bài này trong 5 dòng" | Câu "Chỉ glucose … tạo methyl glucoside" sai về khoa học, vì fructose cũng tạo glycoside. | Tách câu: "Chỉ glucose làm mất màu nước bromine. Glucose (dạng vòng) còn tạo methyl glucoside…". |
| b04 bai.md, mục 3.2d | Ý "fructose không làm mất màu nước bromine" là kiến thức ngoài SGK 2018 nhưng không ghi chú. | Thêm ghi chú: SGK không nêu trực tiếp; đây là kiến thức bổ sung, hay gặp trong đề. |
| b04 bai.md, khung "Saccharide, glucide" | Câu "tên các chất trong chương **đều** có đuôi -saccharide/-ose" sai, vì "tinh bột" không có đuôi này. | Sửa thành "nhiều chất…" và nêu ví dụ. |
| b04 `glucose.svg`, `methyl-glucoside.svg` | Nét C5–C6 chạm vào chữ số 2 của "CH~2~OH" (4 chỗ). | Rút ngắn nét (y2 20 → 24 và 195 → 199). |
| b08 `q14` | Phương án nhiễu "7,95 g" không ứng với lỗi nào, trong khi explain lại nói về lỗi "trừ nước". | Thay bằng "6,35 g" (8,15 − 1,8, lỗi trừ nước) và sửa explain cho khớp. |
| b08 `q15` explain | Ghi "nhầm số H thành 2n + 2 sẽ không ra số nguyên", nhưng thực tế ra n = 2 (C~2~H~7~N, đúng là một phương án nhiễu). | Sửa thành: nếu nhầm thì n : (n + 1) = 2 : 3, ra n = 2, tức C~2~H~7~N, là sai. |
| b08 bai.md, phần so sánh lực base (mục tiêu, khung 5 dòng, mục 4.1b, tiêu đề Dạng 2) | SGK 2018 chỉ nêu "amine là base yếu; alkylamine làm quỳ hoá xanh, aniline thì không". Phần so sánh lực base là kiến thức thêm nhưng chưa ghi rõ. | Ghi rõ "(mở rộng)" ở cả 4 chỗ, kèm một câu nói SGK nêu đến đâu. Nội dung vẫn đúng khoa học: pKa của ion liên hợp NH~4~^+^ 9,25, CH~3~NH~3~^+^ 10,64, (CH~3~)~2~NH~2~^+^ 10,73, (CH~3~)~3~NH^+^ 9,80. Lưu ý về trimethylamine cũng đúng. |
| b09 bai.md, mục 3.3 (pI) | SGK chỉ nêu ví dụ glycine ở pH ≈ 6, không định nghĩa pI. Bài không ghi đây là phần mở rộng. | Ghi rõ "mở rộng" và thêm "khi cần, đề sẽ cho sẵn pI". Các giá trị pI (Gly 5,97, Lys 9,74, Glu 3,22) đều đúng. |
| b09 bai.md, mục 3.3, hai chỗ diễn đạt | (1) "Lys ở pH ≈ 9,7 mới rút **hết** điện tích dương": sai, vì tại pI phân tử vẫn mang một nhóm NH~3~^+^ và một nhóm COO^−^, chỉ là tổng điện tích bằng 0. (2) "ở pH 5 glycine **là cation**": không chính xác, vì ở pH 5 dạng ion lưỡng cực vẫn chiếm ưu thế (dạng cation chỉ khoảng 0,2%). | (1) Sửa thành "rút bớt … để tổng điện tích bằng 0", Glu sửa tương tự. (2) Sửa thành "vẫn mang tổng điện tích dương nên đi về cực âm". |
| b09 bai.md, bảng quỳ tím và bẫy ở Dạng 4 | (1) Quy tắc "đếm số NH~2~ và COOH" không có trong SGK. (2) Cụm "công thức n, n(n − 1)" khó hiểu. | (1) Thêm ghi chú "quy tắc bổ sung". (2) Sửa thành tỉ lệ "n NaOH", "n HCl", đếm theo số nhóm –COOH, –NH~2~. |

## Đã kiểm, không có lỗi

- **Đáp án:** đúng ở toàn bộ 84 câu.
  - b04 short: 5; 4,9; 16,2; 108; 45; 66,7; 139; 62,5.
  - b08 short: 4; 3; 4; 31; 9,9; 7,9; 40,8; 24.
  - b09 short: 3; 6; 4; 18,7; 18,8; 0,5; 30,8; 0,78.
  - Đáp số short đều ≤ 4 ký tự. Câu short có kết quả không nguyên đều ghi rõ cách làm tròn. Không chỗ nào gọi phương án bằng chữ A/B/C/D. Vị trí đáp án mcq phân bố đều.
- **Câu nhận biết, phân biệt có thể có nhiều đáp án:**
  - b04 `q09`: chỉ nước bromine phân biệt được glucose và fructose.
  - b04 `q11`: chỉ phản ứng với CH~3~OH/HCl khan chứng minh glucose có dạng vòng.
  - b08 `q11`: chỉ giấm đúng. Nước vôi và NaHCO~3~ không trung hoà được amine.
  - b08 `q12`: HCl, quỳ tím và FeCl~3~ đều phản ứng được với cả amine bậc hai, bậc ba, nên chỉ HNO~2~ đặc trưng cho alkylamine bậc một.
  - b09 `q06`, `q12`: chỉ có 1 đáp án.
- **Ví dụ trong bai.md:** cả 34 ví dụ (9 + 12 + 13) đều đúng. Kiểm thêm các bước "khó":
  - b04 VD8: khối lượng dung dịch giảm, có Ca(HCO~3~)~2~.
  - b08 VD10: M trung bình = 38.
  - b09 VD12: bảo toàn số gốc, ra 61,5 g.
  - b09 VD6: trình tự Gly-Ala-Gly-Val là duy nhất.
- **Đếm đồng phân:** C~3~H~9~N có 4, C~4~H~11~N có 8 (4 / 3 / 1 theo bậc một / hai / ba). Amine thơm C~7~H~9~N có 5, trong đó 4 arylamine.
- **Phương trình:** đều cân bằng, gồm đốt amine (1,5n + 0,75)O~2~, Gly-Gly với HCl/NaOH, diazonium hoá, Tollens với fructose.
- **Danh pháp như SGK:**
  - Amine: N-methylpropan-1-amine, N,N-dimethylethanamine, N,N-dimethylmethanamine.
  - Amino acid: 2-aminopentane-1,5-dioic acid, α,ε-diaminocaproic acid, α-aminoisovaleric acid.
- **Hình:**
  - `glucose.svg`: Fischer D (OH ở C2 phải, C3 trái, C4 phải, C5 phải). Haworth: C2 xuống, C3 lên, C4 xuống, CH~2~OH lên; α xuống, β lên. O vòng lấy từ OH ở C5.
  - `fructose.svg`: furanose có C3-OH lên, C4-OH xuống, C6 lên. α: OH xuống, CH~2~OH lên. β: ngược lại. Đúng D-fructofuranose và khớp SGK.
  - `peptide.svg`: liên kết peptide là nét C(O)–N.
  - Các hình còn lại (`bac-amine`, `brom-aniline`, `danh-phap`, `tinh-base`, `ion-luong-cuc`, `dien-di`, `thuy-phan`, `phan-loai`): không có chữ chồng chữ.
- **Phần tác giả tự thêm ngoài SGK, đúng khoa học và đã ghi chú:**
  - Tỉ lệ α/β/mạch hở khoảng 36/64/<1%.
  - Sorbitol (đã ghi "Ngoài SGK").
  - Mẹo đổi đường huyết sang mg/dL (×18).
  - Lưu ý tách N~2~ có sẵn trong không khí khi đốt amine.
  - Ion lưỡng cực giải thích tính chất vật lí.
- **Phức amine–Cu(OH)~2~:** có trong SGK (tr. 38) và được trình bày đúng.
- **Bản quyền:** không thấy đoạn nào chép nguyên văn SGK. Phần thí nghiệm đã được tóm tắt bằng lời khác.

## Góp ý chưa sửa

1. b04 giải thích fructose tráng bạc là do "fructose chuyển thành glucose trong kiềm". Đây là cách giải thích quen thuộc ở Việt Nam và hợp với SGK, nhưng đã đơn giản hoá: thực tế phản ứng đi qua enediol và cho hỗn hợp sản phẩm. Để nguyên được.
2. b08 mục 4.2 viết "Giải phóng N~2~ ở nhiệt độ thường là dấu hiệu của alkylamine bậc một". Thực ra aniline với HNO~2~ ở nhiệt độ thường cũng giải phóng N~2~, do muối diazonium bị phân huỷ. Không ảnh hưởng đến đề thi theo SGK. Có thể thêm một câu nếu muốn chặt chẽ.
3. b09 `q17` ý 4 ("thu được ester M = 103"): SGK chú thích rằng trong điều kiện phản ứng, ester tồn tại ở dạng muối. Ý này vẫn Đúng theo phương trình SGK viết, nhưng có thể thêm "(tính theo dạng ester tự do)" cho chặt.
4. b08 `q10` (dãy tính base) dùng kiến thức mở rộng. Giữ lại vì đề tham khảo vẫn hay hỏi, và nay bai.md đã ghi rõ là mở rộng.
