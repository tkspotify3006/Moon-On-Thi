# Biên bản thẩm định Hóa 12 (đợt 3): b01, b02, b10

- b01: Ester – Lipid
- b02: Xà phòng và chất giặt rửa
- b10: Protein và enzyme

Ngày 24/10/2026. Đối chiếu SGK KNTT Hóa 12, tr. 6–13, 14–17, 46–48 (PDF 8–15, 16–19, 48–50); xem thêm tr. 49–50 (Bài 11) để kiểm một trích dẫn.

Cách kiểm:
- Giải lại độc lập cả 84 câu quiz (45 mcq, 15 tf × 4 ý, 24 short) và mọi ví dụ trong bai.md bằng python, nguyên tử khối như SGK (`scratchpad/rv-hoa-3/kt.py`). Đếm đồng phân ester bằng RDKit (C~3~H~6~O~2~: 2, C~4~H~8~O~2~: 4, C~5~H~10~O~2~: 9, ester thơm C~8~H~8~O~2~: 6). Đếm triglyceride bằng liệt kê.
- Render 12 hình SVG bằng Playwright và tự xem từng hình.
- Mở 3 bài và 3 quiz trong app (390×844): không có `.katex-error`, đủ 4 hình mỗi bài, không có lỗi console.
- `kiem-tra.mjs`: 0 lỗi, 0 cảnh báo.

## Lỗi nghiêm trọng đã sửa (1)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b02 `q14` và `q24` | Hai câu dùng chung một bộ số, làm ngược của nhau. `q14` cho 44,5 g chất béo và hỏi khối lượng muối (45,9 g). `q24` cho 45,9 g muối, 0,15 mol NaOH và hỏi m. Đáp số 44,5 của `q24` nằm sẵn trong đề `q14`, còn đáp án 45,9 của `q14` nằm trong đề `q24`. | Đổi số liệu `q24` sang triolein: 0,18 mol NaOH, 54,72 g muối. m = 54,72 + 5,52 − 7,2 = 53,04, đáp số **53** (làm tròn hàng đơn vị). Explain có kiểm tra M = 884 và M muối = 304. |

## Lỗi nhỏ đã sửa (12)

**Câu quiz trùng nguyên số liệu với ví dụ trong bai.md, nên học sinh chép được đáp số (5 câu):**

| Câu | Trùng với | Sửa |
|---|---|---|
| b01 `q10` (dãy nhiệt độ sôi) | Ví dụ 4: cùng ba chất M = 102, cùng nhiệt độ sôi. | Đổi sang bộ M = 116: ethyl butanoate (121 °C), heptan-1-ol (176 °C), hexanoic acid (205 °C). Vị trí đáp án giữ nguyên. |
| b01 `q23` (số triglyceride từ 3 acid) | Khung mẹo "với n = 3 được 18". | Hỏi số triglyceride chứa **đúng hai loại** gốc acid: 18 − 3 − 3 = **12** (đã liệt kê kiểm). |
| b10 `q24` (liên kết peptide của insulin) | Ví dụ 1 (đáp số 49). | Đổi sang hemoglobin (2 chuỗi α 141 gốc, 2 chuỗi β 146 gốc): **570**. Bỏ trường `ref` cũ. |
| b10 `q26` (bảng thời gian thuỷ phân tinh bột) | Ví dụ 11: cùng bảng số liệu. | Bảng mới 15/25/35/45/55 °C, thời gian 20/9/4/6/18 phút, đáp số **35**. Ghi "(Số liệu minh hoạ.)". |
| b10 `q28` (hemoglobin 0,34% Fe) | Ví dụ 2 (≈ 65 900). | Đổi sang cytochrome c: 0,45% Fe, 1 nguyên tử Fe, M ≈ 12 444, đáp số **12** (nghìn). |

**Các lỗi khác:**

- **b10 `q20`**: bảng hoạt tính enzyme theo pH là số tự đặt nhưng không ghi. Đã thêm "số liệu minh hoạ" vào đề.
- **b10 bai.md, Ví dụ 6**: viết (C~6~H~10~O~5~)~n~ + nH~2~O → nC~6~H~12~O~6~ với xúc tác "enzyme amylase…". Viết vậy chưa chính xác, vì amylase chủ yếu cắt tinh bột thành maltose. Đã sửa xúc tác thành "enzyme" và thêm một câu giải thích amylase → maltose → (maltase) → glucose.
- **b10 bai.md, Ví dụ 7b**: câu "50 °C chỉ lệch khỏi 37 °C nhiều hơn một chút" sai: 50 °C lệch 13 °C, gần gấp đôi mức lệch 7 °C của 30 °C. Đã viết lại để so hai điểm cách đều 37 °C (30 °C khoảng 78%, 44 °C khoảng 55%, đọc từ đường cong trong `hoat-tinh.svg`).
- **b10 bai.md, mục 3.2 bẫy**: ghi "SGK (tr. 50)" như thể nằm trong Bài 10, nhưng tr. 50 thuộc phần Luyện tập của Bài 11. Đã ghi rõ.
- **b01 bai.md, bảng tên gốc**: cột gốc acid và cột gốc R' xếp cùng hàng (ví dụ "butyrate | isopropyl"), dễ làm học sinh tưởng là một cặp. Đã thêm chú thích rằng hai nửa bảng tra độc lập.
- **b01 bai.md, mục 1.1**: câu "sáp ong … không có mùi" không chính xác. Đã bỏ vế này.
- **b02 `co-che.svg`, khung ④**: chữ "dầu" nằm đè lên các đuôi kị nước trong lõi micelle. Đã chuyển nhãn xuống dưới, thành "lõi: dầu", và chụp lại để kiểm.

## Đã kiểm, không có lỗi

- **Đáp án:** đúng ở toàn bộ 84 câu, kể cả các ý tf có số liệu.
  - b01 short: 2; 4; 5,3; 12 (mới); 104; 1,49; 17,7; 70.
  - b02 short: 2; 8,34; 4,6; 53 (mới); 0,94; 8,1; 24,5; 52.
  - b10 short: 3; 5; 570 (mới); 15; 35 (mới); 150; 12 (mới); 21,3.
  - Phương án nhiễu đều ứng với lỗi điển hình, kể cả các phép tính:
    - b01 `q13`: 50% (tính theo chất dư), 95,7%.
    - b01 `q14`: 4,9; 12,4; 9,9.
    - b02 `q13`: 30,6; 85,2; 89,0.
    - b02 `q14`: 39,9; 43,2; 55,1.
    - b10 `q16`: 51,20; 65,60; 79,82.
  - mcq chỉ có 1 đáp án đúng. Đáp số short đều ≤ 4 ký tự. Câu short có kết quả không nguyên đều ghi rõ cách làm tròn. Không chỗ nào gọi phương án bằng chữ A/B/C/D. Vị trí đáp án mcq phân bố đều.
- **Câu có thể bị 2 đáp án:**
  - b10 `q09`: chỉ biuret phân biệt được lòng trắng trứng với Gly-Ala.
  - b10 `q06`: chỉ glucose không gây đông tụ.
  - b02 `q15`: chỉ một cách dùng an toàn.
  - b01 `q12`: chỉ một phát biểu đúng.
- **Ví dụ trong bai.md:** cả 34 ví dụ (14 + 9 + 11) đều đúng. Kiểm thêm các bước khó:
  - b01 VD12: hệ methyl benzoate / phenyl acetate, 16,56 g, khớp cả hai cách.
  - b01 VD13: M(X) = 858.
  - b02 VD9: chất béo lẫn acid béo, x = 0,1; y = 0,01; 94,86 g.
  - b10 VD10: % gốc dùng M − 18.
- **Phương trình:** đều cân bằng, gồm ester của phenol + 2NaOH, vinyl acetate → CH~3~CHO, xà phòng hoá, hydrogen hoá triolein, 2RCOONa + Ca^2+^, RCOONa + HCl, R–SO~3~H/R–OSO~3~H + NaOH, thuỷ phân Gly-Ala.
- **Danh pháp và acid béo theo SGK:** tên ester theo dạng gốc R' + gốc acid (ethyl ethanoate/ethyl acetate…). Bốn acid béo đúng công thức và M (256/284/282/280). Định nghĩa omega đánh số từ đầu CH~3~; oleic là ω-9.
- **Phần ngoài SGK, đúng khoa học và đã ghi chú:**
  - Ester của phenol, ester vinyl, HCOOR' tráng bạc: mục 4.4 ghi "mở rộng".
  - Chất béo trans: ghi "mở rộng".
  - Bậc cấu trúc protein: ghi "mở rộng, SGK không yêu cầu".
  - Nhiệt độ và pH tối ưu: ghi "SGK chỉ nêu gián tiếp". Giá trị pepsin ≈ 2, amylase ≈ 7, trypsin ≈ 8 đúng.
  - Hệ số 6,25 (16% N): ghi "mở rộng; đề sẽ cho sẵn tỉ lệ". `q25` có cho 16% trong đề.
  - Mô hình ổ khoá – chìa khoá: ghi "mô hình mở rộng".
  - Các giá trị khác đều đúng: nhiệt độ sôi minh hoạ (77/138/164 °C với M = 88), M insulin ≈ 5 800, 9 so với 4 kcal/g.
- **Hình:**
  - `triglyceride.svg`: 3 nhóm –O–C(=O)–R gắn vào khung glycerol, có 3H~2~O.
  - `omega.svg`: mạch 18 C (17 đỉnh + COOH). Linoleic có nối đôi ở C6 và C9 tính từ CH~3~ (tức Δ9,12). α-Linolenic có nối đôi ở C3, C6, C9. Có ghi "không thể hiện cis".
  - `ester-hoa.svg`: OH của acid + H của alcohol → H~2~O; mũi tên thuận nghịch.
  - `danh-phap.svg`: đúng.
  - `cau-tao.svg` (b02): stearate 17 C + COO^−^; dodecyl 12 C; vòng benzene ở alkylbenzene sulfonate.
  - `co-che.svg`: đuôi kị nước hướng vào dầu, đầu ưa nước quay ra nước, đúng ở cả 4 khung.
  - `nuoc-cung.svg`, `san-xuat.svg`: đúng.
  - `cau-tao.svg` (b10): –CO–NH– đúng chiều, đầu N/đầu C đúng, có cầu –S–S–.
  - `dong-tu.svg`, `enzyme.svg`: đúng.
  - `hoat-tinh.svg`: đường cong nhiệt độ bất đối xứng, bên phải dốc hơn, khớp khung "Đọc đồ thị". Đã ghi "Số liệu minh hoạ".
  - Không hình nào có chữ chồng chữ, trừ chỗ đã sửa ở `co-che.svg`.
- **Đủ nội dung SGK:**
  - Bài 1: khái niệm, danh pháp, tính chất vật lí (kể cả bảng M = 60), thí nghiệm thuỷ phân, ester hoá, ứng dụng; lipid, acid béo, chất béo; Hình 1.2; hydrogen hoá, bơ thực vật; ôi mỡ, chất chống oxi hoá; vai trò, vitamin A, D, E, K; omega-3/6.
  - Bài 2: khái niệm, giặt rửa tự nhiên, cấu tạo 2 phần, cơ chế, xà phòng hoá, thí nghiệm, sản xuất từ dầu mỏ, chất giặt rửa tổng hợp, bột giặt, ưu nhược điểm.
  - Bài 10: insulin, đơn giản/phức tạp, sợi/cầu, thuỷ phân, biuret, HNO~3~, đông tụ (thí nghiệm), vai trò, enzyme (chọn lọc, tốc độ), ứng dụng.
- **Bản quyền:** không thấy đoạn nào chép nguyên văn SGK, trừ các câu định nghĩa bắt buộc phải giữ nghĩa. Thí nghiệm đã được tóm tắt bằng lời khác, ví dụ đều tự đặt.

## Góp ý chưa sửa

1. b10 bảng 1.2 và các câu Đúng/Sai coi albumin lòng trắng trứng là protein đơn giản. Đây là cách xếp loại quen thuộc trong sách Việt Nam. Thực ra ovalbumin có gắn gốc đường (glycoprotein). Không ảnh hưởng đến đề thi theo SGK.
2. b02 mục 3.1c nói "oxi hoá alkane mạch dài (có xúc tác)": SGK chỉ vẽ sơ đồ alkane → acid béo, không nói cách làm. Nội dung đúng, có thể ghi "(mở rộng)".
3. b02 `q13` (0,1 mol tristearin → 91,8 g muối) cho cùng đáp số với Ví dụ 8 (91,8 g muối), nhưng hướng hỏi khác. Giữ lại vì là câu mức 2 dễ.
4. b01 `q09` và `q20` (số ester C~4~H~8~O~2~, C~3~H~6~O~2~) có sẵn trong bảng "Nhớ nhanh". Đây là câu nhận biết nên chấp nhận được.
5. b01 `q18` và b02 `q18` đều là thí nghiệm nấu xà phòng nhưng hỏi ý khác nhau. Không cần sửa.
