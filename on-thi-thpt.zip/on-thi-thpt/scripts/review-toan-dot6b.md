# Biên bản thẩm định — Toán 12 đợt 6b (b15, b16, b17)

Ngày: 2026-10-28 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/b15` (Bài 15 Phương trình đường thẳng trong không gian, SGK T2 tr. 41–49 = PDF 42–50), `b16` (Bài 16 Công thức tính góc trong không gian, tr. 50–53 = PDF 51–54), `b17` (Bài 17 Phương trình mặt cầu, tr. 54–60 = PDF 55–61).

## 1. Cách kiểm
- Đọc lại từng trang SGK của 3 bài (cả Luyện tập, Vận dụng, Bài tập 5.11–5.30, mục Em có biết GPS) và trang 38 (mục 6 Bài 14, công thức khoảng cách). Các số trang `(SGK tr. X)` trong 3 bài đều đúng: định nghĩa VTCP tr. 41, tham số tr. 42, chính tắc tr. 43, qua hai điểm và vuông góc mặt phẳng tr. 44, vuông góc tr. 45, vị trí tương đối tr. 46, hệ (*) tr. 47, nút giao khác mức tr. 49; góc hai đường thẳng tr. 50, quy ước làm tròn và công thức sin tr. 51, góc hai mặt phẳng tr. 52, Kheops tr. 53; mặt cầu tr. 54–56, Trái Đất tr. 57–58, BT 5.27/5.30 tr. 59, GPS tr. 59–60.
- Giải lại **toàn bộ 84 câu** (mỗi bài 28: 15 mcq · 5 tf · 8 short, kể cả mọi phương án nhiễu có giải thích và từng ý tf) và **mọi ví dụ** trong 3 bai.md bằng sympy/numpy. Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-6b/kt.py`.
- Kiểm mcq chỉ 1 phương án đúng, nhiễu ứng với lỗi điển hình; short ≤ 4 ký tự, có ghi làm tròn khi cần; explain không gọi A/B/C/D. Vị trí đáp án mcq: b15 4/4/4/3, b16 4/4/4/3, b17 4/4/3/4. Đáp án đúng dài nhất: 5/15, 1/15, 1/15. Mức độ: b15 11/10/7, b16 10/9/9, b17 11/10/7. Mỗi tf có cả ý Đúng lẫn Sai.
- **b17 q27** (TP.HCM 11°N 107°E – Tokyo 36°N 140°E): tính đúng $\cos\widehat{POQ}\approx0{,}77819$, $\widehat{POQ}\approx38{,}905^\circ$, $d\approx4\,326{,}05$ km. Làm tròn giữa chừng như SGK (4 chữ số thập phân) cho $4\,325{,}9$, vẫn làm tròn thành 4326; `tol: 3` hợp lí và app hỗ trợ (`js/quiz.js` dùng `q.tol`). Khoảng cách thực tế khoảng 4 320 km, nên số liệu hợp lí. Đáp số 4 ký tự.
- Soát trùng số liệu: ví dụ ↔ quiz trong từng bài, quiz ↔ quiz, chéo 3 bài và với Bài 14 (dò mọi phương trình mặt phẳng dùng chung, xem ngữ cảnh), với ví dụ, luyện tập và bài tập SGK Bài 15–17.
- Nhất quán với b14: VTPT/VTCP, $\vec n$, $[\vec u,\vec v]$, mẹo "che cột", $d(M,(P))$. Các chỗ dẫn chéo đều đúng: "Bài 14, mục 6 (SGK tr. 38)" khớp mục 6 của b14; phương trình đoạn chắn (b14 mục 3.4); "Bài 15" (VTCP) ở b16; "Bài 8" (tích vô hướng).
- Render 12 hình SVG (sáng + tối) bằng Playwright và tự xem ảnh. Mở 3 bài + 3 quiz trong app (bản sao repo bật `ready`, cổng 8902, 390×844), mở hết khung gợi ý/lời giải, đo tràn. Render đề, lời giải và ý tf của toàn bộ quiz ở khung 358 px. Không `.katex-error`, không lỗi console, `scrollWidth = 390`. Vài công thức khung ghi nhớ rộng 420–505 px nằm trong vùng cuộn ngang riêng của `.katex-display` (thiết kế chung).
- `node scripts/kiem-tra.mjs`: **0 lỗi** (cảnh báo còn lại là các bài chưa `ready`).

## 2. Kết quả
**Không có đáp án sai** (84/84), không có lỗi tính toán trong ví dụ, không có lỗi kiến thức. Lỗi tìm được thuộc loại trùng/lộ đáp số với ví dụ, phần ngoài SGK chưa gắn nhãn, ghi chú máy tính và số liệu thực tế viết quá chắc chắn, nhiễu kém, chữ chạm hình.

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b16 quiz q16 (tf) | $\vec u=(1;-2;2)$, $\vec u'=(2;1;-2)$ cho $\cos=\mp\frac49$, góc $63{,}6^\circ$ / $116{,}4^\circ$: **trùng đúng** kết quả và nhiễu "quên trị tuyệt đối" của Ví dụ 6a. Lộ đáp số. | Đổi $\Delta':\frac{x-2}{2}=\frac{y+1}{3}=\frac{z-3}{-6}$: $\vec u\cdot\vec u'=-16$, $\lvert\vec u'\rvert=7$. a) VTCP $(2;3;-6)$ Đ; b) $\cos(\vec u,\vec u')=\frac{16}{21}$ S; c) $\cos(\Delta,\Delta')=\frac{16}{21}$ Đ; d) $139{,}6^\circ$ S (đúng $40{,}4^\circ$). |
| b16 quiz q18b | Với $m=2$ cũng ra $\frac49$, $63{,}6^\circ$/$116{,}4^\circ$ (lần thứ ba cùng số với Ví dụ 6a và q16). | Đổi thành $m=4$: $\cos=\frac{8}{3\sqrt{21}}\approx0{,}582$, góc $\approx54{,}4^\circ$. Phát biểu "$\approx125{,}6^\circ$" vẫn Sai. |
| b15 bai.md: hình chiếu lên mặt phẳng, Ví dụ 9, Dạng 2, Ví dụ 16 + quiz q15, q25 | Ba phần ngoài SGK: vị trí đường thẳng – mặt phẳng đã ghi nhãn. Còn hình chiếu lên mặt phẳng (khung ứng dụng), điểm đối xứng, Ví dụ 9, Ví dụ 16 và hai câu quiz dùng chúng thì **chưa ghi** "mở rộng/ngoài SGK". | Gắn nhãn "(mở rộng, ngoài SGK)" cho khung ứng dụng, "(mở rộng)" cho Ví dụ 9, Ví dụ 16 và các gạch đầu dòng hình chiếu/đối xứng. Thêm câu dẫn đầu Dạng 2 nói rõ phần nào thuộc SGK (giao điểm, Vận dụng 1), phần nào mở rộng. Explain q15, q25 mở đầu bằng "(Mở rộng, ngoài SGK — xem Dạng 2)". Nội dung các phần này đúng, giữ lại. |
| b16 bai.md khung mẹo Casio | Khẳng định chắc chắn "OPTN có lệnh Dot và Abs", "nhiều bản máy có lệnh Angle". Không kiểm chứng được tên lệnh/vị trí phím trên fx-580VN X. Abs (độ dài) thường không nằm trong OPTN. | Viết lại thận trọng: cách chắc chắn là tự tính phân số rồi SHIFT cos (Deg). Chế độ Vectơ có lệnh tích vô hướng; **một số phiên bản** có lệnh góc giữa hai vectơ (tên lệnh, phím có thể khác, xem hướng dẫn kèm máy). Giữ lưu ý: lệnh góc cho góc giữa hai **vectơ** trong $[0^\circ;180^\circ]$, góc tù thì lấy $180^\circ$ trừ đi. |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b16 bai.md khung ứng dụng mái nhà | "Mái tôn thường dưới $15^\circ$, mái ngói thường trên $30^\circ$": số liệu thực tế viết như quy chuẩn. | "thường chỉ khoảng $10^\circ$–$15^\circ$", "thường khoảng $30^\circ$ trở lên", thêm câu "đây là các con số tham khảo, mỗi loại vật liệu có hướng dẫn riêng". Pin mặt trời giữ "khoảng $10^\circ$–$20^\circ$". |
| b16 quiz q02 | Nhiễu "$\cos(\Delta,(P))=\lvert\sin(\vec u,\vec n)\rvert+1$" vô lí, học sinh loại ngay. | Thay bằng "$\sin(\Delta,(P))=\lvert\sin(\vec u,\vec n)\rvert$" (nhầm hàm). Explain thêm: $\lvert\sin(\vec u,\vec n)\rvert=\cos\varphi$. |
| b17 quiz q04 | $x^2+y^2+z^2+4x-2y+6z-2=0$ cùng bộ $a^2+b^2+c^2=14$, $d=-2$, $R=4$ và cùng nhiễu $2\sqrt3$ với Ví dụ 4 (tâm chỉ hoán vị tọa độ). | Đổi hằng số thành $+5$: $R=3$, nhiễu lỗi dấu $d$ là $\sqrt{19}$ (giữ vị trí đáp án). |
| b17 quiz q25 | $d(I,(P))=\frac93=3$, $k=9$ cùng phép tính và đáp số với Ví dụ 3a. | Đổi $(P):2x+2y-z+19=0$: $R=\frac{15}{3}=5$, $k=25$. |
| b15/h1-vtcp.svg | Nhãn "M" bị mũi tên nét đứt chạm vào. | Dời nhãn sang trái, phía trên đường thẳng. |
| b15/h3-vi-tri.svg | Ô "Chéo nhau": chữ "không cùng mặt phẳng" bị đường $\Delta_2$ cắt ngang. | Căn phải chữ, tránh khỏi $\Delta_2$. |

Các hình còn lại đúng và sạch: b15 h2 (D trong tấm bìa, giữa M và N), h4 (cáp treo, $TH=100$ m vuông góc cáp, $125$ m theo phương đứng); b16 h1 ($120^\circ$/$60^\circ$), h2 ($\varphi$ và $90^\circ-\varphi$), h3 (nhìn dọc giao tuyến), h4 (mái che 3,2/2,6/2,9 m, $AB=4$, $AC=3$); b17 h1 (trong/thuộc/ngoài, đường kính), h2 (tiếp xúc), h3 (vĩ độ, kinh độ, tọa độ), h4 (quả bóng góc phòng). Bản tối hiển thị đúng.

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức. **4 lỗi đáng kể**: 2 câu lộ/trùng đáp số với ví dụ (b16 q16, q18b), phần mở rộng chưa gắn nhãn ở b15 (bài + 2 câu quiz), mẹo Casio khẳng định chưa kiểm chứng. **6 lỗi nhỏ**.

## 4. Nội dung, cách giảng, nhất quán
- **b15** đủ nội dung SGK: VTCP, tham số, chính tắc (và khi không có chính tắc), qua hai điểm, vuông góc mặt phẳng, song song đường thẳng, giao với mặt phẳng (Vận dụng 1), vuông góc, vị trí tương đối theo tích có hướng và theo hệ (*), va chạm (Vận dụng 3), nút giao khác mức. Ba phần mở rộng (vị trí đường thẳng – mặt phẳng, hình chiếu lên đường thẳng/mặt phẳng, điểm đối xứng) đúng và đều đã gắn nhãn. Ví dụ 8 (tấm bìa) đổi số so với SGK ($M(2;-1;4)$, $N(-2;3;-4)$, $r=1{,}5$).
- **b16** dựng đúng ba công thức từ góc giữa vectơ (bù, phụ), quy ước làm tròn đúng SGK tr. 51, phân biệt góc giữa hai mặt phẳng với góc nhị diện. Mái che Ví dụ 8 đổi số so với tình huống mở đầu SGK (tam giác vuông 4–3, cột 3,2/2,6/2,9 m thay vì tam giác đều cạnh 4, cột 7/6/5 m). Kheops ghi "khoảng $52^\circ$".
- **b17** đủ: định nghĩa, trong/ngoài, hai dạng phương trình và điều kiện $a^2+b^2+c^2-d>0$ (giải thích ba trường hợp dương/0/âm), lập phương trình (tâm–bán kính, đường kính, qua điểm, tiếp xúc mặt phẳng ứng BT 5.27), vùng phủ sóng (BT 5.30), tọa độ vĩ độ–kinh độ, khoảng cách trên mặt đất, GPS. Ví dụ 7 Hà Nội – Singapore $\approx2\,234$ km, có ghi thực tế "khoảng 2 200 km" (thực tế khoảng 2 199 km).
- Kí hiệu thống nhất với b14. Dẫn chéo đúng mục.

## 5. Góp ý chưa sửa (không phải lỗi)
1. b16 dùng nhiều vectơ độ dài 3 ($(1;2;-2)$, $(2;1;-2)$, $(2;-1;2)$…) ở Ví dụ 1, 6, 9. Các kết quả $\frac89$, $\frac49$ lặp trong bài giảng nhưng là các ví dụ khác nhau. Quiz nay không còn trùng.
2. Mô hình chóp tứ giác đều (b16 Ví dụ 12 ↔ q27) và mái che ba cột (Ví dụ 8 ↔ q25) dùng lại với số liệu khác: luyện lại dạng vừa học, chấp nhận. Bài ôn chương nên đổi mô hình.
3. b17 q03 có phương án đúng $x^2+y^2+z^2-2x+4y-6z+1=0$, cùng bộ hệ số bậc nhất với Ví dụ 3 SGK (hằng số khác, tâm và bán kính khác). Chấp nhận.
4. Hình SVG rộng 520 px nằm trong khung cuộn ngang theo thiết kế chung của app.
