# Biên bản thẩm định — Sinh 12, Bài 8 & Bài 9 (pilot)

Ngày: 2026-10-17 · Người thẩm định: Claude, thẩm định độc lập với người soạn
Đối chiếu: SGK Sinh học 12 KNTT (PDF tr. 42–47 = sách tr. 40–45; PDF tr. 48–51 = sách tr. 46–49), mục lục tr. 4.
Script kiểm tính toán: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/kt-review-b08b09.py`. Script liệt kê tổ hợp giao tử bằng phân số, giải lại toàn bộ 55 câu và các ví dụ có tính toán.
Kết quả `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**. App (390×844): không có katex-error, không có ảnh hỏng, console sạch.

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b08 | 28 (15 mcq · 5 tf · 8 short) | 0 | Mọi tỉ lệ khớp khi liệt kê giao tử: q12 3/8; q14 1/8; q16 1/3, 3/8; q18 1/9, 1/4; q19 6 kiểu gene, 1/8, 3:3:1:1, 1/3; q25 27/64; q26 37,5; q27 4/9; q28 1/9 |
| b09 | 27 (14 mcq · 5 tf · 8 short) | 0 | Phân bố cộng gộp 1:6:15:20:15:6:1 khớp; q13 15/64; q23 43,75→43,8; q24 0,31; q25 1/6; q26 37,5; q27 22/64; q14: chỉ nhóm AB bị loại |

- Mỗi câu mcq chỉ có một phương án đúng. Câu short có số ≤ 4 ký tự, và đề nói rõ cách làm tròn khi kết quả không chẵn.
- Không câu nào gọi phương án bằng A/B/C/D. Vị trí đáp án mcq phân bố đều (4/4/4/3 và 3/4/4/3).
- Các câu cần dữ kiện đều có đủ: trội hoàn toàn, phân li độc lập, hai gene trên hai cặp NST khác nhau.

## 2. Lỗi đã sửa

### Lỗi nội dung (nghiêm trọng vừa)
1. **b08/bai.md, mục tiêu và mục 2.5: thiếu vai trò của nguyên phân.** Yêu cầu cần đạt của SGK là "cơ sở tế bào học… dựa trên mối quan hệ giữa **nguyên phân**, giảm phân và thụ tinh", nhưng bài chỉ nói giảm phân và thụ tinh. Đã sửa mục tiêu và thêm đoạn "Ba quá trình nối tiếp nhau thành một vòng": hợp tử → nguyên phân → giảm phân → thụ tinh.
2. **b08/bai.md, bảng thuật ngữ: định nghĩa gene chưa chính xác.** Bài viết "Gene: đoạn DNA quy định một tính trạng", mâu thuẫn với Bài 2 (gene mã hoá sản phẩm) và Bài 9 (một tính trạng do nhiều gene). Đã sửa thành "đoạn DNA mang thông tin mã hoá một sản phẩm (RNA hoặc chuỗi polypeptide), qua đó quy định tính trạng".

### Lỗi nhỏ
3. **b08/quiz.json q10: phương án nhiễu "9" kém hợp lý.** Lời giải cũ giải thích là "nhầm số kiểu gene của phép lai hai cặp", không khớp với đề có 3 cặp gene. Đã đổi thành "27" (nhầm với 3^3^ kiểu gene) và viết lại explain.
4. **b08/bai.md, bẫy của Ví dụ 5:** câu "có thể ghép AaBb × Aabb; nếu không cho kiểu hình thì liệt kê đủ khả năng" dễ gây hiểu nhầm, vì ở ví dụ này chỉ có một cách ghép. Đã viết lại kèm ví dụ thật sự có 2 cách ghép: (Aa × aa)(Bb × bb) → AaBb × aabb hoặc Aabb × aaBb.
5. **b09/bai.md mục 1.1: thiếu thuật ngữ SGK "di truyền trung gian".** SGK tr. 46 dùng song song hai tên "trội không hoàn toàn" và "di truyền trung gian". Đã bổ sung.
6. **b09/bai.md, khung [!bay] về tên gọi.** Đã đối chiếu SGK tr. 47–48. Người soạn ghi đúng: SGK gọi ví dụ ốc sên là **"tương tác át chế"**, nguyên văn ý là gene bị đột biến mất chức năng sẽ át chế sự biểu hiện của các gene khác. Lưu ý thêm: SGK **không** nêu tỉ lệ 9 : 7; tỉ lệ này do bài tự suy ra và suy ra đúng. Đã viết lại lời dẫn sát ý SGK (ghi tr. 48) và cảnh báo thêm: trong sách cũ, chữ "át chế" thường chỉ các tỉ lệ 12 : 3 : 1, 13 : 3, 9 : 3 : 4. Học sinh vì vậy phải đọc cơ chế đề cho, không suy tỉ lệ từ tên gọi.
7. **b09/bai.md mẹo "tổng = 16":** đã thêm điều kiện "4 loại giao tử tỉ lệ ngang nhau".
8. **b09/bai.md công thức cộng gộp:** `\text{… trội}` trong KaTeX làm kiem-tra.mjs báo "No character metrics for 'ộ'", nguy cơ hiển thị dấu tiếng Việt lệch. Đã đưa phần chữ ra ngoài công thức: "Tỉ lệ con có đúng $k$ allele trội: $$P(k)=…$$".
9. **b09/hinh-troi-khong-hoan-toan.svg:** mũi tên P → F~1~ cắt ngang nhãn "giao tử A₁". Đã dời nhãn.
10. **b09/hinh-abo.svg:** chỉ số trên viết ở cỡ 10–11px, dưới mức tối thiểu 12px của brief. Đã nâng lên 12px. Khoảng trống thừa ở đáy hình (viewBox cao 380) đã cắt còn 330.

## 3. Đã kiểm, không cần sửa
- Tiêu đề b08 "Học thuyết di truyền của Mendel" khớp mục lục SGK (đầu trang bài in là "Học thuyết di truyền Mendel"; hai cách viết đều chấp nhận được).
- Số liệu Mendel đúng: 705 : 224; 315 : 101 : 108 : 32 (ghép đúng nhãn kiểu hình).
- Các dẫn trang "SGK tr. …" đều đúng: 41, 43, 46, 47, 47–48, 48. "Bài 7" là bài NST, đúng.
- Hình b08: giảm phân (nhân đôi → GP I tách cặp tương đồng → GP II tách chromatid) đúng. Hình 3 có hai cách xếp ở kì giữa I, cho 4 loại giao tử ¼, đúng. Bảng Punnett 16 ô tô màu đúng 9 : 3 : 3 : 1. Không có chữ chồng.
- Hình b09: con đường chuyển hoá, biểu đồ cộng gộp 1:6:15:20:15:6:1 và bảng ABO đều đúng.
- Bản quyền: không phát hiện câu, ví dụ hay bài tập chép nguyên văn SGK. Phát biểu hai quy luật được diễn đạt lại theo thuật ngữ allele.
- Nội dung ngoài SGK (gene gây chết; các tỉ lệ 9:6:1, 12:3:1…) đã đặt trong [!em-co-biet] và ghi rõ "không có trong SGK". Quiz không hỏi phần này. Chấp nhận được.

## 4. Góp ý chưa sửa (để người soạn hoặc chủ dự án quyết)
- Tiêu đề trong catalog.json/quiz.json giữ "của Mendel" theo mục lục. Nếu muốn khớp tiêu đề in trên trang bài thì sửa ở catalog (ngoài phạm vi thẩm định).
- Nhiều câu tính toán chưa có cụm "Theo lí thuyết," như văn phong đề thật. Nên thêm thống nhất khi biên tập toàn bộ ngân hàng câu hỏi.
- b08 thiếu một câu tf dạng phả hệ hoặc bối cảnh thực nghiệm (bảng số liệu đếm thô → nhận ra 9 : 3 : 3 : 1). Đề 2025–2026 hay cho số liệu thô; nên thêm 1 câu khi mở rộng ngân hàng.
- b09 có thể thêm 1 câu mcq hoặc tf về ý "một gene quy định nhiều tính trạng" (SGK tr. 46 có nêu) và về hemoglobin như ví dụ "nhiều gene cùng tạo một protein". Hiện chỉ có q10 hỏi ý này.
- Hình 1 (b08): tế bào sau GP I chỉ ghi một nhãn "A" cho NST kép. Có thể ghi "A A" cho rõ hai chromatid. Không sai.
