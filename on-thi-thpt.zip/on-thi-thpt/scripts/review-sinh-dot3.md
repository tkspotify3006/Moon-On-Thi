# Biên bản thẩm định — Sinh 12, Bài 1, 12, 13 (đợt 3)

Ngày: 2026-10-24 · Người thẩm định: Claude (độc lập với người soạn)
Đối chiếu: SGK Sinh học 12 KNTT. PDF tr. 7–10 là sách tr. 5–8 (Bài 1), PDF tr. 62–69 là sách tr. 60–67 (Bài 12), PDF tr. 70–76 là sách tr. 68–74 (Bài 13). Mục lục ở PDF tr. 6.
Script giải lại: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-sinh-3/kt.py`. Script dùng phân số chính xác và giải lại mọi câu có tính toán cùng mọi ví dụ trong bai.md. Nó gồm:
- mô phỏng từng mạch đơn cho bài N^15^/N^14^;
- liệt kê tổ hợp giao tử của thể tứ bội và thể ba;
- tính xác suất phả hệ, có chia trường hợp kiểu gene bố mẹ khi hỏi nhiều con.

Kết quả `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**.
App (390×844, `python3 -m http.server 8823`): không có katex-error, console sạch, hình SVG hiển thị đủ, các khung mới thêm hiển thị đúng.

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b01 | 28 (15 mcq · 5 tf · 8 short) | 0 | q12: 15%. q13: đoạn A 15% (G 35%). q14: 5'-TCGAATC-3'. q15: 160. q18: chạc mở sang phải, khuôn trên 3'→5' cho mạch liên tục. q19: 8 DNA, 2 DNA chứa N^15^, 1/8; ý 4 có 2 DNA chỉ chứa N^15^. q20: 1022. q21–q28: 408 · 3600 · 0,67 · 62 · 30 · 4200 · 30 · 10. Vị trí đáp án 4/4/4/3. |
| b12 | 28 (15 mcq · 5 tf · 8 short) | 0 | q15: 32. q19: giao tử Aa 10%, 8 loại giao tử, thể một 10%, AAaBb 2,5%. q20: 4 kiểu gene, 11 : 1, AAaa 5/12. q22: 28. q23: 30. q24: 54. q25: 88. q26: 1/6 → 0,17. q27: 1/12 → 0,08. q28: 17. Vị trí đáp án 3/4/4/4. |
| b13 | 28 (15 mcq · 5 tf · 8 short) | 0 | q15: 1/6. q19.4: 5/12. q20: vợ X^B^X^b^, không bệnh 5/8, con trai chỉ một bệnh 1/4. q23: 0,25. q24: 12,5. Đáp số của q25–q28 sau khi sửa: 2/9 → 0,22; 17/24 → 0,71; 4/9 → 0,44; 1/128 → 0,8. Vị trí đáp án 4/4/3/4. |

- Mỗi câu mcq chỉ có một phương án đúng.
- Câu short có đáp số ≤ 4 ký tự và ghi rõ cách làm tròn.
- Không câu nào gọi phương án bằng A/B/C/D.
- Các câu về thể ba/tứ bội đều có giả thiết về giao tử thụ tinh. Các câu phả hệ đều có giả thiết "không có đột biến mới" hoặc dữ kiện đủ.

## 2. Lỗi đã sửa

### Nghiêm trọng (3)
1. **b12/bai.md: trình tự gene sai khi đảo đoạn chứa tâm động.** Lỗi có ở hai chỗ:
   - Mục 2.2c: ví dụ "AB**ED•C**FGH" sai. Đảo đoạn C D • E phải cho AB**E•DC**FGH.
   - Ví dụ 1 (3) và lời giải: "MQP•ONRST" sai. Đảo đoạn N O P • Q phải cho **MQ•PONRST**.

   Người soạn đảo các chữ nhưng để tâm động đứng yên, trong khi tâm động cũng quay theo đoạn bị đảo. Đã sửa cả đề, lời giải và câu giảng, có thêm ghi chú "tâm động quay theo".
2. **b13 quiz q19 ý 2 nhập nhằng.** Câu cũ là "xác định chính xác kiểu gene của 6 người", trong khi thực tế xác định được 7 người. Học sinh biết đáp số 7 vẫn có thể chọn Đúng ("6 người thì cũng xác định được"). Đã sửa thành "của **đúng** 6 người" (Sai), và `why` liệt kê đủ 7 người.
3. **b13 quiz: câu trả lời ngắn bị lộ đáp số.**
   - q26 trùng hoàn toàn Ví dụ 5(d), và đáp số 29/36 in sẵn ở mục Tóm tắt. q25 trùng Ví dụ 5(c) (4/9). q28 trùng Ví dụ 3 (1/64 → 1,6).
   - q27 dùng chung dữ liệu với q20, mà `why` của q20.3 đã cho sẵn "không bị M = 5/6", nên đáp số q27 (5/6 × 1/2) suy ra ngay.

   Đã đặt lại đề, giữ `id`:
   - q25: hỏi "con gái dị hợp", đáp số 2/9 → 0,22.
   - q26: chồng 1/3 AA : 2/3 Aa, vợ Aa, hỏi hai con đều không bệnh. Đáp số 17/24 → 0,71; cách nhân sai cho 0,69.
   - q27: chồng có em trai bị M (1/3 : 2/3). Đáp số 4/9 → 0,44.
   - q28: hỏi "con trai bị bệnh", đáp số 1/128 → 0,8.

   Đã kiểm lại bằng python.

### Lỗi nhỏ (10)
4. **b12/bai.md: chưa có ví dụ Burkitt; SGK tr. 64 có lỗi in.** SGK tr. 64 ghi "chuyển đoạn giữa NST số 8 và số 9 … (Burkitt lymphoma)". SGK tr. 71 (Bài 13) lại ghi đúng **8 và 14**, đúng với chuẩn y học t(8;14).
   - Đã thêm Burkitt (8–14) vào bảng tác hại và bảng Tóm tắt.
   - Đã thêm khung [!bay] "Burkitt: NST 8 với NST 14 (không phải 8 với 9)". Khung nói rõ đây là lỗi in, chính SGK Bài 13 ghi 8–14, và khi đi thi dùng 8–14. Khung cũng giải thích vì sao SGK gọi một loại u lympho là "ung thư bạch cầu".
   - b13 mục 2.3c có thêm một câu dẫn chéo về lỗi này.
5. **b12/bai.md: SGK tr. 61 viết "Chuyển đoạn giữa các NST được gọi là chuyển đoạn tương đồng".** Cách gọi này dễ gây hiểu nhầm: chuyển đoạn thường xảy ra giữa NST không tương đồng, và tên chuẩn là tương hỗ/không tương hỗ. Bài soạn chưa nhắc chỗ này. Đã thêm khung [!bay] phân biệt hai trường hợp:
   - trao đổi đoạn giữa hai NST tương đồng là trao đổi chéo;
   - trao đổi đoạn giữa hai NST không tương đồng là chuyển đoạn.
6. **b12/bai.md mục 5.1:** câu "ở tổ tiên chung của người và tinh tinh, hai NST dung hợp" mâu thuẫn với câu "tinh tinh vẫn giữ 48". Đã sửa thành: tổ tiên chung có 48 NST, sự dung hợp xảy ra ở dòng tiến hoá dẫn tới loài người.
7. **b12/bai.md mục 4.2:** đã thống nhất với b13.
   - Trước khi sửa, b12 ghi "hầu hết lệch bội NST thường gây chết thai". b13 lại có Patau, Edwards trong bảng. SGK tr. 64 ghi "tất cả … trừ thừa NST 21".
   - Nay b12 dẫn đúng lời SGK, kèm câu "thực tế Patau/Edwards có thể sinh ra nhưng thường chết sớm (xem Bài 13)".
   - b13 có thêm câu nói rõ Patau, Edwards là phần mở rộng ngoài SGK.
8. **b12/bai.md Dạng 4 (giao tử thể tứ bội, thể ba):** dạng này ngoài SGK 2018. Đề tốt nghiệp từ 2025 ít hỏi trực tiếp, nhưng đề thi thử và đề tuyển sinh riêng vẫn dùng, nên giữ lại. Đã thêm khung [!em-co-biet] ghi rõ "ngoài SGK, học sau khi vững Dạng 1–3, chỉ cần đếm tổ hợp".
   - Các giá trị trong bảng giao tử đã kiểm bằng liệt kê và đều đúng: AAaa 1 : 4 : 1; AAa 1 : 2 : 2 : 1; Aaa 2 : 1 : 1 : 2.
9. **b12 quiz q15:** phương án nhiễu "48" không ứng với lỗi sai nào ("không ứng với cơ chế nào"). Đã đổi thành "23" (14 + 9, nhầm chỉ đa bội hoá bộ NST của một loài) và sửa explain.
10. **b01 quiz q14:** explain mô tả sai phương án nhiễu 5'-GATTCGA-3'. Explain cũ gọi đó là "đọc ngược rồi lấy bổ sung", nhưng thực ra đó chính là mạch khuôn viết theo chiều 5'→3'. Đã sửa.
11. **b13/bai.md bảng dấu hiệu phả hệ:** dòng "Trội trên X: bố bệnh → tất cả con trai bình thường" chỉ đúng khi mẹ bình thường. Đã thêm "(mẹ bình thường)".
12. **b13/hinh-4-karyotype-down.svg:** "thể ba nhiễm" là thuật ngữ cũ. Đã đổi thành "thể ba, 2n + 1" theo SGK 2018.
13. **b12/hinh-3-da-boi.svg và hinh-1-cau-truc.svg:** có 14 nhãn cỡ chữ 11px, nhỏ hơn quy chuẩn ≥ 12px. Đã nâng lên 12px. Nhãn mũi tên "tế bào không phân chia" chạm viền hai hộp nên đã rút gọn thành "tế bào không chia". Đã chụp lại hình và không còn chữ chồng.

## 3. Đã kiểm, không cần sửa
- **Enzyme làm mồi:** SGK tr. 6 gọi là **"enzyme RNA polymerase"** (không dùng chữ primase). b01 ghi "RNA polymerase (primase)", vừa đúng SGK vừa đúng tên quốc tế. Quiz q06 cũng dùng cách gọi này nên không gây nhầm.
- **b01:**
  - Đã có đủ các nội dung: chức năng, 4 ý cấu trúc phù hợp chức năng, câu hỏi "vì sao protein không là vật chất di truyền", Ori/đơn vị tái bản, hai giai đoạn, các enzyme, bán bảo toàn, so sánh nhân sơ – nhân thực.
  - Đã có đủ các mục ngoài phần giảng: Khoa học và đời sống (PCR, pháp y, chẩn đoán) và Luyện tập 1–3 (G–C, bảng tóm tắt, kháng sinh).
  - Ví dụ tính đều đúng: 720/480, 408 nm, 2880; 360/540, 2340; 2400, 360/840; 6300/4200/25 200; N^15^ 6 và 2; 256 đoạn mồi; E. coli ≈ 38 phút.
- **b12:**
  - Đã có đủ các nội dung: khái niệm, nguyên nhân/cơ chế (H 12.1), 4 dạng cấu trúc, lệch bội (35% do GP I ở mẹ, H 12.2), đa bội (colchicine, H 12.3, tự/dị đa bội, mức bội thể, lúa mì 6n, chuối 3n), tác hại (mèo kêu, mắt dẹt, giảm 50% sinh sản, Down chuyển đoạn 21→14, 9–22), vai trò (họ gene hemoglobin, NST 2, đa bội ở động vật, mất đoạn Y – SRY, chuyển đoạn trong chọn giống, côn trùng, dưa hấu/nho/dâu tằm), mối quan hệ di truyền – biến dị, biểu đồ Down theo tuổi mẹ (1/2 300 → 1/100 → 1/46).
  - Ví dụ tính đều đúng: 17/19/16/20, 9, 36; 25 → thể ba, 72 chromatid; 8%/8%/4%; 35 : 1, AAaa 1/2; ví dụ trao đổi chéo không cân (10 + 4 = 14 đoạn).
- **b13:**
  - Đã có đủ các nội dung: khái niệm/vai trò, các phương pháp, phả hệ (kí hiệu, cách lập, cholesterol LDL, hạn chế), di truyền tế bào (bạch cầu, colchicine, karyotype 1–22), y học tư vấn (1/4 tan máu, chọc ối 16 tuần/20 mL/2 tuần/40 loại rối loạn, sinh thiết nhau thai 11–13 tuần, thuốc đích, cận huyết 25%, galactose huyết), liệu pháp gene (RPE65 2007, Leber 2009 với 12 người, CRISPR 2018, tế bào gốc tuỷ xương, rào cản kĩ thuật và đạo đức), Luyện tập 2.
  - Đã kiểm thêm ba chi tiết ngoài SGK: Casgevy được cấp phép ở Anh/Mỹ cuối 2023; luật cấm kết hôn trong phạm vi ba đời; tỉ lệ Aa/aa ≈ 198 lần khi q = 1/100.
- **Hình:** đã xem cả 11 SVG.
  - b01 Hình 1: chuỗi P–D đúng chiều. Mạch 1 có 5'-P ở trên, 3' ở dưới; mạch 2 ngược lại. A–T có 2 vạch liên kết, G–C có 3. Một chu kì = 10 bậc.
  - b01 Hình 2: mạch liên tục và gián đoạn đúng ở cả hai chạc. Đoạn mồi nằm ở đầu 5' của mỗi đoạn Okazaki và của mạch liên tục, cạnh Ori.
  - b01 Hình 3: chạc mở sang phải, khuôn trên 3'→5' cho mạch liên tục, đúng.
  - b01 Hình 4: bán bảo toàn 2 thế hệ, đúng.
  - b12: trình tự gene của 4 dạng đúng. Không phân li GP I/GP II đúng tỉ lệ. Ba con đường đa bội có số NST khớp.
  - b13: kí hiệu khớp Hình 13.1 SGK (có ghi chú kí hiệu dị hợp là ngoài SGK). Bốn dấu hiệu (a)–(d) đúng. Phả hệ Hình 3 khớp Ví dụ 1, 5. Karyotype 47,XY,+21 đúng.
- **Bản quyền:** không có câu chép nguyên văn SGK. Ví dụ đều tự đặt số liệu. Bài Luyện tập của SGK chỉ được dẫn và trả lời bằng lời của người soạn.

## 4. Góp ý chưa sửa
- b01 q20 ý 4 (kháng sinh ức chế enzyme tái bản của vi khuẩn) hơi lệch chủ đề của đề dẫn (PCR). Ý này vẫn đúng và bám Luyện tập 3 của SGK, nên giữ nguyên.
- b13 q24 (máu khó đông, 12,5) có cùng cấu trúc với nửa sau Ví dụ 6. Mức độ trùng chấp nhận được với câu level 2.
- Một số đề tính toán chưa mở đầu bằng "Theo lí thuyết," (b01 q21–q24, q26; b12 q22–q24). Nên thống nhất khi biên tập chung toàn bộ ngân hàng câu hỏi.
- Hình đa bội (b12 Hình 3) ghi "nA", "nB" không có chỉ số dưới. Hình vẫn dễ đọc, có thể đổi sang `<tspan baseline-shift="sub">` khi biên tập.
