# Biên bản thẩm định — Toán 12 đợt 6a (on-4, b14)

Ngày: 2026-10-28 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/on-4` (Ôn tập chương IV, SGK T2 tr. 27–28 = PDF 28–29; bài lẻ b11, b12, b13), `b14` (Bài 14 Phương trình mặt phẳng, tr. 29–40 = PDF 30–41).

## 1. Cách kiểm
- Đọc lại SGK: Bài tập cuối chương IV 4.20–4.35 (tr. 27–28), BT 4.10 (tr. 18); Bài 14: VTPT + chú ý (tr. 30), HĐ2 + định nghĩa tích có hướng + kí hiệu định thức (tr. 30), cặp VTCP (tr. 31), moment lực (tr. 31), PT tổng quát (tr. 32), lập PT qua điểm + VTPT / cặp VTCP / ba điểm (tr. 33–34), đoạn chắn LT8 (tr. 35), Vận dụng 2 (tr. 35), vuông góc + chú ý (tr. 36), song song/trùng (tr. 37), Vận dụng 4 (tr. 37–38), khoảng cách (tr. 38), Vận dụng 5 camera (tr. 39), BT 5.1–5.10, Em có biết (tr. 40). Các số trang `(SGK tr. X)` đúng.
- Giải lại **toàn bộ 63 câu** (on-4 35 = 22 mcq/5 tf/8 short; b14 28 = 15/5/8), mọi phương án nhiễu có giải thích, từng ý tf, và **mọi ví dụ/bài tự luyện** trong 2 bai.md bằng sympy: 121 phép kiểm, tất cả khớp (kể cả các câu sau khi sửa). Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-6a/kt.py`; bản sửa quiz: `sua_quiz.py` cùng thư mục.
- on-4 Ví dụ 2: dựng lại $f'=\frac18(x+1)(x-2)^2(4-x)$ — cho đúng $S_1=\frac{12}5$, $S_2=\frac{409}{160}$, đỉnh $x\approx-0{,}15$; $3{,}40$ khớp Ôn tập chương I Ví dụ 2 và Hình 2 (tỉ lệ 26 px/đơn vị).
- **on-4 không dùng đổi biến/từng phần:** soát toàn bộ — mọi hàm hợp đều khai triển ($(x-2)^2$, $f^2$ của bình gốm, $(x^2/20+3)^2$); $\cos3x$ (T1) xử lí bằng đạo hàm phương án; $e^{-x}=(1/e)^x$ (T3).
- Soát trùng số liệu: ví dụ ↔ quiz trong bài, quiz ↔ quiz, on-4 ↔ bai.md + quiz.json của b11/b12/b13, và với ví dụ/luyện tập/bài tập SGK.
- Render 8 hình SVG (sáng + tối) bằng Playwright, tự xem ảnh, đo cỡ chữ. Mở 2 bài + 2 quiz trong app (bản sao repo bật `ready`, cổng 8901, 390×844), mở hết khung: 0 `.katex-error`, 0 lỗi console, `scrollWidth = 390`; chụp riêng các bảng.
- mcq: 1 đáp án đúng; vị trí đáp án on-4 6/6/5/5, b14 4/4/4/3; mức độ on-4 9/14/12 (34% vận dụng), b14 11/10/7; short ≤ 4 kí tự, có ghi làm tròn; explain không gọi A/B/C/D.
- `node scripts/kiem-tra.mjs`: **0 lỗi** (cảnh báo: bài chưa `ready`).

## 2. Kết quả
**Không có đáp án sai** (63/63), không có lỗi kiến thức. Tích có hướng trình bày đúng SGK (công thức $(bc'-b'c;\ ca'-c'a;\ ab'-a'b)$ và dạng ba định thức cấp hai, tọa độ giữa "cột 3 – cột 1"). Lỗi tìm được: trùng/lộ số liệu với bài lẻ, công thức ngoài SGK chưa ghi nhãn, mẹo Casio chưa thận trọng.

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| on-4 q18 | $V=\pi\int_1^{e^2}\frac{dx}{x}$: tích phân chính là **b12 Ví dụ (c)** $\int_1^{e^2}\frac{dx}x=2$ đã giải sẵn → lộ đáp số. | Đổi cận $x=e^3$, đáp án $3\pi$; nhiễu $3$, $2\pi(e\sqrt e-1)$, $\pi(e^3-1)$. |
| on-4 q20 | Hình $(H)$: $y=\sqrt x$, $Ox$, $x=4$ trùng đúng **b12 Ví dụ** (diện tích $\frac{16}3$ đã giải). | Đổi $x=16$: $k=32^{2/3}=8\sqrt[3]2$; nhiễu $8$, $8\sqrt2$, $4\sqrt[3]4$. |
| on-4 q21 | Khối do $y=2\sqrt x$ trên $[0;4]$ ($32\pi$) đã tính trong **tf b13** → lộ một nửa lời giải. | Đổi miền $y=\sqrt x$, $y=x^2$: $V=\frac{3\pi}{10}$; nhiễu $\frac{9\pi}{70}$ (bình phương hiệu), $\frac3{10}$, $\frac\pi3$. |
| on-4 q28 | $f=6x^2-4x+3$, $F(1)=2$ gần trùng **b12 Ví dụ** ($f=6x^2-4x$, $F(1)=2$). | Đổi $f=6x^2+2x-5$, $F(1)=3$, đáp số $F(-1)=9$. |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b14 Ví dụ 1 | $A(1;-2;3)$ trùng điểm $A$ của Luyện tập 1 SGK. | $A(2;-1;3)$, $B(4;3;-1)$ ($\overrightarrow{AB}$ giữ nguyên, lời giải không đổi). |
| b14 q06 | $M(1;-2;3)$ trùng điểm Ví dụ 5a. | $M(-1;3;2)$, đáp án $2x+y-z+1=0$, nhiễu viết lại. |
| b14 q28 | Camera $C(1;2;7)$, $(P):x+2y+2z-3=0$ quá sát Vận dụng 5 SGK ($C(1;2;4)$, $x+2y+2z+3=0$). | $C(2;1;7)$, $(P):2x+y+2z-3=0$ (đáp số giữ $6{,}4$). |
| b14 mục 2.2 (bảng mặt phẳng đặc biệt), mẹo $\frac{\lvert D_1-D_2\rvert}{\sqrt{A^2+B^2+C^2}}$ | Ngoài SGK, chưa ghi nhãn. | Ghi "mở rộng, ngoài SGK"; nêu mẹo chỉ là $d(E,(P_2))$ rút gọn. |
| b14 mẹo Casio | "MENU → 5" phụ thuộc phiên bản; chưa nhắc thứ tự VctA, VctB. | "MENU → Vectơ"; thêm: đổi thứ tự là đổi dấu, chỉ dùng để soát lại. |
| on-4 mẹo Casio | "Abs = SHIFT + hyp" không chắc đúng trên fx-580VN X. | Chỉ ghi "lệnh Abs". |
| on-4 khung "hàm lạ" | Thiếu cách xử lí $\int e^{2x}$ (BT 4.10c là tích phân xác định, không thử phương án được). | Thêm $e^{2x}=(e^2)^x$ dùng bảng: $\frac{e^{2x}}2+C$. |
| on-4 q27 explain | "đồ thị $v$ cong lồi lên" (thuật ngữ lồi/lõm dễ hiểu ngược). | Diễn đạt: cung parabol nằm phía trên dây cung nối $(0;0)$, $(6;18)$. |
| b14 q12, q15 explain | Không giải thích các nhiễu. | Thêm nguồn gốc nhiễu ($m=3$, $\frac43$, $\frac56$…). |
| b14 khung B00, khung "Đọc VTPT" | Dấu ";" trong câu văn → app tự xuống dòng giữa câu ("(Toán; Hóa; Sinh)"). | Đổi thành dấu phẩy/dấu chấm. |
| b14 mục 1.2 | Công thức $[\vec u,\vec v]\cdot\vec u=\dots$ dài, bị cắt ở 390 px. | Tách 2 dòng. |
| b14/h1-vtpt-vtcp.svg | Chỉ số "0" của $M_0$ cỡ 11 px. | 12 px. |

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức; **4 lỗi đáng kể** (trùng/lộ số liệu với bài lẻ trong bài ôn chương); **12 lỗi nhỏ**.

## 4. Nhận xét nội dung
- on-4 đúng khuôn ôn chương: 10 dòng ghi nhớ, sơ đồ + bảng "đề hỏi → công thức", 5 bảng phân biệt, 16 lỗi sai theo bài, 5 bài tổng hợp (nối cả Chương I: GTLN, đồ thị $f'$ kết nối đúng Ôn tập chương I Ví dụ 2), bảng đối chiếu 4.20–4.35 với bài tự luyện khác số (T1–T13, đáp số đúng). Bình gốm (Ví dụ 5) dùng $(f+1)^2-f^2=2f+1$ — hay, có ghi chú mô hình gần đúng. Phần quay miền giữa hai đồ thị chỉ dùng "trừ hai khối" (công thức SGK).
- b14 đủ nội dung SGK: VTPT, tích có hướng (giải thích vì sao vuông góc), cặp VTCP, moment lực, PT tổng quát, 3 cách lập PT + đoạn chắn (có chứng minh), vật chuyển động trong mặt phẳng (cùng ý Vận dụng 2, khác số), vuông góc/song song/trùng, khoảng cách có dẫn dắt HĐ10, Em có biết. Dạng bài thi 4 dạng sát đề 2025.
- Hình sạch, đúng: on-4 h2 khớp hàm $f'$, h3 (giao điểm $-1,0,2$), h4 ($f(0)=5$, $f(10)=7{,}5$, đáy bán kính 6); b14 h4 pháp tuyến và $MN$ vuông góc mặt dốc (kiểm bằng tích vô hướng tọa độ SVG).

## 5. Góp ý chưa sửa (không phải lỗi)
1. b14: mặt phẳng $x+2y-2z+1=0$ xuất hiện ở Ví dụ 13b, q18 và q27 (câu hỏi khác nhau, không lộ đáp số); VTPT $(2;-1;2)$ dùng nhiều lần. Chấp nhận.
2. b14 q20 cùng khuôn flycam – sườn đồi với Ví dụ 17 (số liệu khác) — luyện lại dạng vừa học.
3. on-4 q12 ($\int_{\pi/6}^{\pi/2}\frac{dx}{\sin^2x}$) và q31 ($e^x$, $1-x$ trên $[0;1]$) cùng dạng BT 4.32c, 4.33 nhưng khác số liệu.
4. Bảng đối chiếu mục 5 của on-4 dài (14 dòng, 3 cột) — đọc được ở 390 px nhưng phải cuộn nhiều.
