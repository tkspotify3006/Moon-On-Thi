# Biên bản thẩm định — Toán 12 đợt 4 (b04, b05, on-1)

Ngày: 2026-10-24 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/b04` (Bài 4 Khảo sát sự biến thiên và vẽ đồ thị của hàm số, SGK tr. 26–32 = PDF 27–33), `b05` (Bài 5 Ứng dụng đạo hàm để giải quyết một số vấn đề liên quan đến thực tiễn, tr. 33–41 = PDF 34–42), `on-1` (Ôn tập chương I + Bài tập cuối chương I, tr. 42–44 = PDF 43–45).

## 1. Cách kiểm
- Đọc lại từng trang SGK của 3 phần. Đối chiếu: sơ đồ khảo sát (tr. 26), chú ý vẽ đồ thị và chú ý bậc ba (tr. 27), chú ý $\frac{ax+b}{cx+d}$ (tr. 29), chú ý $\frac{ax^2+bx+c}{px+q}$ (tr. 32), tốc độ thay đổi (tr. 33), Ví dụ 2 logistic (tr. 34), Ví dụ 4 ô nhiễm (tr. 35), Luyện tập 1 (tr. 36), quy trình tối ưu (tr. 36–37), Luyện tập 2 và các hàm kinh tế (tr. 38), BT 1.26 (tr. 40), BT 1.30–1.46 (tr. 42–44). Mọi số trang `(SGK tr. X)` trong 3 bài đều đúng; bảng đối chiếu 1.30–1.46 ở on-1 mục 5 khớp nội dung từng bài tập.
- Giải lại **toàn bộ 90 câu** (b04 28, b05 27, on-1 35) và **mọi ví dụ** trong 3 bai.md bằng sympy: cực trị (dấu $f'$ hai phía), GTLN/GTNN trên đoạn kèm đầu mút, giới hạn một bên và tại $\pm\infty$, chia đa thức lấy TCX, đếm nghiệm $f(x)=m$ bằng nghiệm thực của tử, đếm giá trị nguyên của $m$, các bài tối ưu (sông/cáp, cứu hộ, cửa sổ, dây cắt đôi, giá vé, drone, hai tàu), mô hình mũ/logistic. 123 phép kiểm đều khớp. Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-4/kt.py`.
- Kiểm thêm: mcq chỉ 1 phương án bảo vệ được; nhiễu là lỗi điển hình; short ≤ 4 ký tự, có ghi làm tròn (b05 q20 30,3; q24 34,3; q25 2,52; q27 43,5; on-1 q29 9,47; q32 6,9); explain không gọi A/B/C/D; vị trí đáp án mcq: b04 4/4/3/4, b05 3/4/3/4, on-1 5/6/5/6; mức độ b04 10/10/8, b05 9/10/8, on-1 8/15/12 (vận dụng 34%); on-1 có 22 mcq (63%) · 5 tf · 8 short. Đề dùng BBT/đồ thị đều mô tả đủ bằng bảng hoặc lời (quiz không có hình).
- Soát trùng số liệu on-1 với b01–b05 (dò mọi công thức trong đề + đối chiếu cấu trúc hàm sau khi tịnh tiến).
- Render 15 hình SVG bằng Playwright, tự xem ảnh; so tọa độ với hàm số. Mở 3 bài + 3 quiz trong app (390×844), mở hết khung gợi ý/lời giải, đo tràn ngang mọi công thức và bảng; render toàn bộ đề + lời giải + ý tf của quiz ở bề rộng `.q-text` thật (324 px). Không lỗi console, không `.katex-error`.
- `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo** (3 dòng "No character metrics" của KaTeX do chữ Việt trong `\text{}` — chỉ là cảnh báo font, hiển thị đúng).

## 2. Kết quả quiz
**Không có đáp án nào sai** (90/90), mọi ý tf đúng như ghi, lời giải từng bước đúng. Lỗi tìm được thuộc loại: trùng số liệu (lộ đáp số), kiến thức ngoài chương, chép đề SGK, hiển thị trên điện thoại.

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| on-1 quiz q23 ý d | Phải dựng $f$ từ $f'$ (nguyên hàm — Chương IV) để tính GTNN. | Thay bằng ý chương I: "$g(x)=f(x)+4x$ đồng biến trên $\mathbb R$" (Đúng: đỉnh parabol $f'$ là $(1;-4)$ nên $g'=f'+4\ge0$, chỉ bằng 0 tại $x=1$). Viết lại explain. |
| on-1 quiz q24 | Trùng số liệu b04 q18: $\frac{x^2-3x+6}{x-2}=x-1+\frac4{x-2}$ chỉ là tịnh tiến của $x+\frac4{x-1}$ — cùng $y_{CĐ}=-3$, $y_{CT}=5$, cùng ý "cực đại nhỏ hơn cực tiểu". | Đổi hàm $y=\frac{x^2-3x+11}{x-2}=x-1+\frac9{x-2}$ (CĐ $(-1;-5)$, CT $(5;7)$); ý b) "nghịch biến trên $(-1;5)$" Sai; ý d) "13 giá trị nguyên để vô nghiệm" Sai (đúng là 11; 13 là đếm cả hai đầu). |
| b04 quiz q12 ↔ on-1 Ví dụ 1 | BBT của q12 (CĐ $-4$, CT $4$, TCĐ giữa) chính là hàm $x-1+\frac4{x-1}$ của on-1 Ví dụ 1 tịnh tiến; đáp số "đúng hai nghiệm $\iff m<-4$ hoặc $m>4$" trùng ý c) của ví dụ → lộ đáp số. | Đổi giá trị trong BBT q12 thành CĐ $-3$, CT $2$; phương án và explain viết lại ($m<-3$ hoặc $m>2$). |
| b04 quiz q13 | Cùng hàm $x^3-3x^2$ với Ví dụ 7b trong bai.md (chỉ đổi dấu tham số) → đáp số suy thẳng từ ví dụ. | Đổi thành $2x^3-3x^2+m=0$, đáp án $0<m<1$; nhiễu $-1<m<0$, $0\le m\le1$, $m>1$. |
| b04 bai.md Ví dụ 4 + Hình 4 | Chép nguyên đề SGK BT 1.43b ($y=\frac{2x-1}{x+1}$). | Đổi thành $y=\frac{3x-1}{x+1}$ (TCĐ $x=-1$, TCN $y=3$, $I(-1;3)$, $M(1;1)$, $M'(-3;5)$); sửa gợi ý, BBT, lời giải, đoạn "vì sao"; vẽ lại `h4-phan-thuc-bac-nhat.svg` (bản sinh hình: `rv-toan-4/gen_b04.py`). |
| b05 quiz q16 | Dùng đúng hàm của SGK $s=t^3-9t^2+15t$. | Đổi $s=t^3-12t^2+36t$: $v(3)=-9$; đổi chiều tại $t=2$, $t=6$; "quãng đường 6 giây đầu bằng 0" Sai (64 m, 0 là độ dịch chuyển); giảm tốc trên $(4;6)$ Đúng. |
| Quiz b04 q07, q12, q14; on-1 q13 | BBT rộng 330–355 px trong khung đề 324 px: cột "$+\infty$" bị cắt, phải cuộn. | b04 q07, q14 thêm `\small`; b04 q12, on-1 q13 đổi `\footnotesize` → `\scriptsize`. Đo lại: không tràn. |
| on-1 h1-ban-do-chuong.svg | Mũi tên nét đứt đi từ ô **Giới hạn** sang Bài 5 lại ghi "f′ = tốc độ" (sai nguồn). | Đổi nhãn thành "tiệm cận = ngưỡng". |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b05 quiz q09 | $s=t^3-6t^2+9t+1$ là hàm ví dụ của b01 (+1), đáp án $(1;3)$ trùng. | Đổi $s=t^3-9t^2+24t+1$, đáp án $(2;4)$, nhiễu $(3;+\infty)$ (nhầm dấu gia tốc). |
| on-1 quiz q27 ý c | "$y=0$ là TCN của $x^2e^{-x}$" dựa vào $\lim x^2/e^x=0$ — SGK chưa có công cụ chứng minh. | Thay bằng "Giá trị cực đại bằng $\frac4{e^2}$" (Đúng); sửa explain. |
| b04/h1-bac-ba-vd1.svg | Nhãn "1 + √3" bị đồ thị cắt qua chữ "1". | Đặt nhãn sang trái giao điểm. |
| b05/bai.md mục 1.2 | Công thức $v$, $a$ kèm chữ rộng 429 px, cuộn ngang. | Tách chữ ra khỏi công thức. |
| b05/bai.md Ví dụ 9, Ví dụ 12 | $\overline C(700)=\dots$ (341 px) và $S(r)=\dots$ (389 px) rộng hơn khung 328 px. | Tách đơn vị ra ngoài; tách $S(r)$ thành 2 dòng. |
| b04 Ví dụ 6, on-1 Ví dụ 1 (BBT 9 cột) | Rộng 330 px > 328 px. | Bỏ khoảng `\;` cạnh vạch kép; hết tràn. |
| b04 bảng "Sáu dạng"; on-1 bảng 2.3, 2.4 | Công thức trong ô bị ngắt dòng giữa chừng ("$a>$ / $0$", "$y=$ / $y_0$", "$\mathbb R\setminus$ / $\{\dots\}$"). | Bọc nhóm `{…}`; tiêu đề cột bậc ba đổi thành "Bậc ba $y=ax^3+\dots$". |

Các hình còn lại đúng tọa độ và sạch: b04 h2 (6 dạng, đúng hàm ghi dưới mỗi ô), h3 ($-x^3+1{,}5x^2+6x-2$: CT $(-1;-5{,}5)$, CĐ $(2;8)$, cắt $Oy$ tại $-2$), h5 (CĐ $(0;-2)$, CT $(2;2)$, TCĐ $x=1$, TCX $y=x-1$, $I(1;0)$), h6 (các đường $m=3,2,1,-3$ và số giao điểm), h7 ($\frac{2x+3}{x-1}$: TCĐ 1, TCN 2, qua $(0;-3)$, $(-\frac32;0)$); b05 h1–h4; on-1 h2 ($f'=-\frac18(x+1)(x-2)^2(x-4)$, đỉnh tại $x\approx-0{,}15$ và $3{,}40$ khớp lời giảng), h3 (TCĐ $p=12$, TCN $q=12$, điểm $(24;24)$), h4 (tam giác 3–4–5, góc $\alpha=\widehat{CMB}$).

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức trong bài giảng; **8 lỗi đáng kể** (1 ý dùng kiến thức chương IV, 3 câu trùng/lộ số liệu, 2 chỗ chép đề SGK, 1 nhóm BBT bị cắt trong quiz, 1 nhãn sơ đồ sai nguồn); **7 lỗi nhỏ**.

## 4. Nội dung, cách giảng, bản quyền
- b04 đủ nội dung SGK: sơ đồ khảo sát, bậc ba (tâm đối xứng, giải thích vì sao hệ số $t^2$ triệt tiêu), $\frac{ax+b}{cx+d}$ và $\frac{ax^2+bx+c}{px+q}$ (tâm, trục đối xứng, vì sao dời gốc về tâm thì hàm thành lẻ), thêm đọc dấu hệ số và đếm nghiệm — đúng các dạng đề thi. Bảng biến thiên viết đúng kiểu SGK (vạch kép, giới hạn hai bên).
- b05: tốc độ trung bình/tức thời, vận tốc–gia tốc (tăng/giảm tốc theo dấu $v\cdot a$), hóa–sinh, chi phí biên, quy trình tối ưu 3 bước, hàm cầu–doanh thu–lợi nhuận. **Mô hình logistic** (Ví dụ 4, quiz q14): chấp nhận được — chỉ dùng $(e^{kx})'=ke^{kx}$ (Toán 11) và $\left(\frac av\right)'$, được nhắc trong khung nền tảng và gợi ý từng bước; SGK cũng có ví dụ cùng dạng (tr. 34). Phần "tăng nhanh nhất tại $K/2$" để trong khung "Em có biết".
- on-1 đúng mẫu bài ôn tập: ghi nhớ 10 dòng, bản đồ chương, 5 bảng so sánh, 17 lỗi sai theo từng bài, 5 bài tổng hợp có gợi ý nhiều nấc, bảng đối chiếu BT 1.30–1.46 kèm bài tự luyện (đáp số T1–T10 đúng).
- Không chép nguyên văn; ví dụ cùng dạng SGK đều đổi số (bóng $1{,}5+19{,}6t$; ghế gỗ; sông 1 km/4 km; bể bơi; thấu kính $f=12$; dân số $80e^{0{,}015t}$; đảo 3 km/8 km).
- Bảng 4–6 cột (b05 bảng dấu Ví dụ 3, bảng BBT Ví dụ 6; on-1 các bảng so sánh, bảng đối chiếu) đọc được ở 390 px, không tràn (chữ xuống dòng nhiều nhưng rõ). Hình SVG rộng 520 px nằm trong khung cuộn ngang có chú thích "vuốt ngang", theo thiết kế chung của app.

## 5. Góp ý chưa sửa (không phải lỗi)
1. b04 q08 và on-1 q18 cùng cặp điểm tới hạn $0$, $2$ và cặp giá trị $\{-1;3\}$ (một hàm $a<0$, một hàm $a>0$) — không lộ đáp án nhưng có thể đổi số liệu on-1 q18 nếu muốn chặt hơn.
2. b05 Ví dụ 12 (cửa sổ chu vi 4 m) và q25 (chu vi 6 m) cùng mô hình; Ví dụ 13 (homestay) và q26 (nhà nghỉ) cùng mô hình — phù hợp cho bài học thường (luyện lại dạng vừa học), không áp dụng cho bài ôn tập.
3. on-1 q33 (cáp ra đảo) cùng mô hình Ví dụ 5 trong chính bài on-1 và b05 Ví dụ 7, q12 — số liệu khác, chấp nhận.
4. Ba công thức có chữ Việt trong `\text{}` (b04 dòng 97, b05 Luyện tập 2 "vận tốc", on-1 $y_{\text{CĐ}}$) gây cảnh báo font KaTeX khi kiểm tra; hiển thị trong trình duyệt vẫn đúng.
