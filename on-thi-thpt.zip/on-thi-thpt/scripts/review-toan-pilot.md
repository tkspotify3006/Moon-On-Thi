# Biên bản thẩm định — Toán 12 pilot (b07, b08)

Ngày: 2026-10-17 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/b07` (Bài 7 Hệ trục tọa độ trong không gian), `content/lop-12/toan/b08` (Bài 8 Biểu thức tọa độ của các phép toán vectơ). Đối chiếu SGK KNTT Toán 12 T1, tr. 60–72 (PDF 61–73).

## 1. Cách kiểm
- Giải lại **toàn bộ 55 câu** (b07: 14 mcq + 5 tf + 8 short; b08: 15 mcq + 5 tf + 8 short) và mọi ví dụ/lời giải trong 2 bai.md bằng numpy/sympy — script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/kt-review.py`.
- Kiểm thêm: mỗi mcq chỉ có 1 phương án đúng; phương án nhiễu đúng là "lỗi sai điển hình" như explain nói (ví dụ ABDC/ACBD, đối xứng qua trục/mặt phẳng khác, quên chia 3…); short ≤ 4 ký tự, có nói rõ làm tròn khi đáp số không nguyên; explain không gọi phương án bằng A/B/C/D.
- Render 8 hình SVG bằng Playwright, tự xem ảnh; mở bài trong app (390×844), không lỗi console.
- So từng ví dụ/bài tập với trang SGK để kiểm việc chép nguyên văn.
- `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo** sau khi sửa.

## 2. Kết quả quiz
**Không có câu nào sai đáp án.** 55/55 đáp án đúng; mcq đều chỉ có 1 phương án bảo vệ được; nhiễu hợp lý; vị trí đáp án phân bố đều (b07: 3/4/4/3, b08: 4/4/4/3); short đúng định dạng. Không sửa quiz.json.

## 3. Lỗi đã sửa

### b07/bai.md
| Mục | Lỗi | Sửa thành |
|---|---|---|
| Ví dụ 8 (phòng học – drone) | **Lỗi dữ kiện:** đề chỉ nói "$Ox$, $Oy$ dọc theo hai mép chân tường" của phòng rộng 6 m, dài 10 m, nhưng lời giải có $C(2;7;2)$ — nếu học sinh đặt $Oy$ dọc chiều rộng 6 m thì $C$ nằm **ngoài** phòng; bài không xác định được. | Ghi rõ $Ox$ dọc chiều rộng (6 m), $Oy$ dọc chiều dài (10 m) và thêm miền $0\le x\le6$, $0\le y\le10$, $0\le z\le3{,}5$ (khớp Hình 4). |
| Khung `[!ung-dung]` Theo dõi máy bay | Trùng **y hệt** số liệu và đáp số với Ví dụ 12 (trả lời ngắn, đáp số −160) ở phần Dạng bài thi, nên học sinh đọc thấy đáp án trước khi làm. | Đổi sang tình huống bay về hướng **tây** 600 km/h trong 20 phút → dịch chuyển $(-200;0;0)$, vị trí $(-230;40;10)$; thêm lưu ý SGK tr. 64 chọn trục khác (Ox tây, Oy nam), nên phải đọc kĩ đề chọn trục thế nào. |

### b08/bai.md
| Mục | Lỗi | Sửa thành |
|---|---|---|
| Dạng 3 – Bẫy | Ghi "ngược hướng thì góc là 180°, không gọi là góc tù **trong tam giác**" — diễn đạt sai, không liên quan đến tam giác. | "góc bằng 180° — đó là góc bẹt, **không** phải góc tù". |
| `[!ung-dung]` Công của lực | Nói "phần lực theo phương thẳng đứng (20 N)" nhưng không nói trục nào là thẳng đứng. | Thêm "(trục $Oz$ thẳng đứng, sàn là $(Oxy)$)… trượt trên sàn". |
| Thiếu nội dung SGK | SGK Ví dụ 4 tr. 69 (đặt hệ trục vào hình chóp $SA\perp(ABCD)$ để tính độ dài, góc) chưa có dạng tương ứng — đây là dạng hay ra Đúng/Sai. | Thêm **Dạng 5** (nhận biết, phương pháp, bẫy) và **Ví dụ 13** Đúng/Sai tự đặt (đáy hình vuông cạnh 2, $SA=3$; $SC=\sqrt{17}$, $SC\perp BD$, góc$(\overrightarrow{SB},\overrightarrow{AC})\approx66{,}9^\circ$), đã kiểm bằng python. |

### Hình SVG
| File | Lỗi | Sửa |
|---|---|---|
| b08/h4-cot-ang-ten.svg | **Sai toán:** chú thích "SA · SB = 144" đọc như tích **độ dài** (13·15 = 195 ≠ 144). | "vectơ SA · vectơ SB = 144". |
| b08/h2-hinh-binh-hanh.svg | Chú thích "AB = DC ⇔ …" đọc như **độ dài** bằng nhau (không suy ra được hình bình hành). | "vectơ AB = vectơ DC ⇔ A + C = B + D / ⇔ I là trung điểm của cả AC và BD" (2 dòng, viewBox cao 320). |
| b07/hinh-hop-oxyz.svg | Chữ "A ≡ O" và số "3" bị nét đứt trục $Ox$ cắt qua; nhãn "C′" nằm đè lên cạnh C′D′. | Dời "A ≡ O", "3", "C′" ra chỗ trống. |
| b07/toa-do-diem.svg | Nhãn "M(x; y; z)" bị nét đứt (M → đỉnh sau) cắt ngang. | Dời nhãn sang trái (text-anchor end). |
| b08/h1-trung-diem-trong-tam.svg | Chữ "O" bị trục $Ox$ cắt qua. | Dời "O" lên trên – trái gốc. |

Các hình còn lại (he-truc-oxyz, phong-drone, h3) đúng: hướng trục Oxyz đúng quy ước SGK (Ox chéo ra phía trước, Oy sang phải, Oz lên trên), tọa độ điểm khớp tỉ lệ (đã đo lại A, B, C của phong-drone theo thang trục), không chữ chồng.

**Tổng:** 0 lỗi sai đáp án; 2 lỗi nghiêm trọng (Ví dụ 8 b07 thiếu dữ kiện; chú thích hình h4 sai về toán); 1 bổ sung nội dung SGK còn thiếu (Dạng 5 b08); 8 lỗi nhỏ (2 diễn đạt, 1 trùng số liệu làm lộ đáp án, 1 chú thích hình mơ hồ, 4 hình có chữ bị nét cắt/đè).

## 4. Bản quyền
Không phát hiện chép nguyên văn. Các ví dụ cùng dạng với SGK đều đã đổi số liệu và cách hỏi (VD1 b07 ↔ SGK VD1+LT1: đổi cạnh 2, đỉnh A; bóng đèn q26 b07 ↔ tình huống mở đầu: số khác; đèn chùm q20 b08 ↔ BT 2.23: kích thước khác, đèn cách trần 0,5 m; flycam VD7 b08 ↔ SGK VD5 máy bay: số khác).

## 5. Góp ý chưa sửa (không phải lỗi)
1. b07 dạy thêm đối xứng qua trục/mặt phẳng và khoảng cách tới trục — SGK Bài 7 không có, nhưng rất hay gặp trong đề, nên giữ; có thể gắn nhãn "mở rộng" để học sinh biết.
2. Chính tả "tọa độ" (bài) và "toạ độ" (SGK) đều đúng; giữ "tọa" cho thống nhất toàn app.
3. Hình h3 (dấu tích vô hướng) ghi "a · b" không có mũi tên vectơ; chấp nhận được vì hình vẽ rõ là vectơ, nhưng nếu muốn chặt chẽ thì thêm chữ "vectơ".
4. b08 quiz có thể thêm 1 câu dạng "đặt hệ trục vào hình chóp/hình lập phương" (khớp Dạng 5 mới) cho học sinh nhắm 9+; hiện các câu vận dụng thiên về bối cảnh thực tế.
5. Mẹo Casio (MENU → 5 Vectơ, Dot trong OPTN) đúng với fx-580VN X; nên nhắc rằng đề thi chấp nhận máy này.
