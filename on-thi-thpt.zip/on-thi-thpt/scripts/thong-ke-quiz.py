"""Thống kê chất lượng quiz: python3 scripts/thong-ke-quiz.py"""
import json, glob, re, unicodedata, collections, os
root = os.path.join(os.path.dirname(__file__), '..', 'content')
def norm(s):
    s = unicodedata.normalize('NFD', s); s = ''.join(c for c in s if unicodedata.category(c) != 'Mn')
    return re.sub(r'[^a-z0-9]+', ' ', s.lower().replace('đ','d')).strip()
tot = 0; longest = 0; mcq = 0; letters = []; stems = collections.defaultdict(list); lv = collections.Counter(); per = {}
for f in sorted(glob.glob(f'{root}/**/quiz.json', recursive=True)):
    key = '/'.join(f.split('/')[-3:-1]); qs = json.load(open(f))['questions']
    L = M = 0
    for q in qs:
        tot += 1; lv[q.get('level')] += 1
        stems[norm(q['q'])].append(f'{key}#{q["id"]}')
        if re.search(r'(phương án|đáp án|câu|ý)\s+[A-E]\b|\([A-E]\)\s|\b[A-E]\s+(sai|đúng)\b', q.get('explain','')): letters.append(f'{key}#{q["id"]}')
        if q['type'] == 'mcq':
            M += 1; mcq += 1
            lens = [len(o) for o in q['options']]
            if lens[q['answer']] == max(lens) and lens.count(max(lens)) == 1: L += 1; longest += 1
    per[key] = (len(qs), M, round(100*L/max(M,1)))
print(f'Tổng {tot} câu; mcq {mcq}; đáp án đúng là phương án DÀI NHẤT: {round(100*longest/mcq)}% (ngẫu nhiên ≈ 25%)')
print('Mức độ:', dict(lv))
print('Lời giải nhắc chữ cái phương án:', letters)
print('Câu trùng đề:', [v for v in stems.values() if len(v) > 1])
print('Bài có tỉ lệ "dài nhất = đúng" > 45%:', {k: v for k, v in per.items() if v[2] > 45})
