# Biên bản thẩm định Hóa 12 – b05 (Saccharose và maltose), b06 (Tinh bột và cellulose)

Ngày 17/10/2026. Đối chiếu SGK KNTT Hóa 12, tr. 20–34 (PDF 22–36). Đã giải lại từng câu (56 câu) và mọi ví dụ trong bai.md bằng python (`scratchpad/rv-hoa/`, `kt-review.py`). Kết quả số đều đúng. Đã render 7 hình SVG bằng Playwright và tự xem từng hình. `kiem-tra.mjs`: 0 lỗi, 0 cảnh báo.

## Lỗi nghiêm trọng đã sửa (2)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b06 `q12` (mcq) | Có **2 đáp án đúng**. Phương án nhiễu "nước bromine, rồi Cu(OH)~2~ ở nhiệt độ thường" cũng phân biệt được: Br~2~ → nhận ra glucose; Cu(OH)~2~ → saccharose cho xanh lam, hồ tinh bột thì không. | Thay bằng "dung dịch iodine, rồi Cu(OH)~2~ ở nhiệt độ thường" (sai thật, vì bước 2 không tách được glucose với saccharose). Bổ sung explain. |
| b06 `cellulose.svg` | Hình Haworth sai cấu hình C4. Cả 3 gốc vẽ cùng hướng nên cầu O từ C1 (β, hướng lên) đi lên C4 của gốc sau, tức –O– ở C4 hướng **lên**. Đó là cấu hình của galactose, không phải glucose (ở glucose, C4–O hướng xuống). Đầu mạch bên trái cũng vẽ C4–O hướng lên. | Vẽ lại: gốc giữa lật úp (quay 180° quanh trục C1–C4), vòng O ở cạnh trước, mọi nhóm thế đảo chiều. Cầu O thứ hai nằm dưới; C4 đầu mạch nối O hướng xuống. Thêm dòng chú thích "gốc giữa vẽ lật ngược" và sửa chú thích Hình 2 trong bai.md. Đã kiểm tra lại: C2-OH, C3-OH, C6 đúng hướng ở cả ba gốc. |

## Lỗi nhỏ đã sửa (7 mục, 13 chỗ)

- **b06 `q20` ý 4** (tf): câu "cần **ít nhất khoảng** 0,3 tấn mùn cưa" mơ hồ, vì kết quả đúng là 0,313 tấn, lớn hơn 0,3, nên đọc theo hai cách đều được. Sửa thành "cần khoảng 313 kg mùn cưa loại này" (vẫn Đúng), why ghi rõ 40 : 127,8 ≈ 0,313 tấn.
- **Câu short thiếu yêu cầu làm tròn** (brief bắt buộc). Đáp số không đổi, đã thêm "(làm tròn đến hàng đơn vị)" vào: b05 `q23`, `q25`, `q26`; b06 `q22`, `q23`.
- **b05 bai.md, khung "Ai ngọt hơn ai?"**: câu "mật ong ngọt hơn đường kính cùng khối lượng" không chắc đúng, vì mật ong chứa khoảng 17% nước. Sửa thành "mật ong và quả chín giàu fructose có vị rất ngọt".
- **b05 bai.md, Dạng 1 bước 4**: câu "thủy phân rồi so lượng Ag, hoặc dựa vào sản phẩm" mơ hồ. Sửa thành: glucose và maltose cho hiện tượng giống nhau với ba thuốc thử, chỉ phân biệt được qua định lượng Ag (2 so với 4).
- **b05 bai.md, sản xuất đường từ mía**: phần này (sữa vôi, CO~2~, SO~2~) không có trong SGK 2018 mà lấy từ SGK cũ. Nội dung đúng nhưng đã ghi rõ là "phần mở rộng" để học sinh không nhầm là trọng tâm thi.
- **b06 bai.md**: trích "(SGK tr. 34)" trỏ sang Bài 7, sửa thành "bảng tổng kết ở Bài 7, SGK tr. 34".
- **b06 bai.md, bản quyền**: 3 đoạn gần như nguyên văn SGK (tính chất vật lí của tinh bột, tính chất vật lí của cellulose, ứng dụng tinh bột) đã được viết lại bằng lời khác, kèm ví dụ đời thường (bột năng, bông gòn).

## Đã kiểm, không có lỗi

- Toàn bộ đáp án mcq, tf, short và ví dụ ở hai bài đều đúng: Ag theo 4nH và 2n(1 + H), Cu(OH)~2~ theo tỉ lệ 2 : 1, %N = 6,76 / 11,11 / 14,14, CO~2~ khi có Ca(HCO~3~)~2~, rượu 40°, HNO~3~ chia H… Phương án nhiễu đều đúng là lỗi điển hình (quên H, quên hệ số 2, nhân H thay vì chia). Không chỗ nào gọi phương án bằng chữ A/B/C/D. Đáp số short đều ≤ 4 ký tự.
- `saccharose.svg`: α-glucose (C1–O hướng xuống, OH ở C2 xuống, C3 lên, C4 xuống). β-fructose vẽ lật đúng như SGK (C1 lên, O glycoside xuống, C3-OH xuống, C4-OH lên, C6 xuống).
- `maltose.svg`: vị trí α-1,4 đúng. Nhóm –OH hemiacetal vẽ ngang (α hoặc β). Dạng mở vòng có CHO ở C1, OH ở C5.
- `tinh-bot.svg`: amylose α-1,4 đúng; nhánh α-1,6 nối vào CH~2~ ở C6.
- `hinh-dang.svg`, `chuyen-hoa.svg`, `san-xuat-duong.svg`: không có chữ chồng chữ.
- Kiến thức "ngoài SGK" nhưng đúng khoa học và có ích khi thi: tính chất aldehyde của maltose (tráng bạc 1 : 2, mất màu nước Br~2~, khử Cu(OH)~2~ khi đun nóng), màu iodine mất khi đun nóng và trở lại khi để nguội, %N của các cellulose nitrate.

## Góp ý chưa sửa

1. Vị trí đáp án mcq ở cả hai bài đi theo vòng 0,1,2,3,0,1,… Nếu app luôn trộn thứ tự thì không sao; nếu không thì nên xáo lại.
2. b05 `q20` ý 3 (SO~2~ tẩy màu trong sản xuất đường) kiểm tra kiến thức mở rộng, không có trong SGK 2018. Có thể thay bằng ý về Hình 5.2 hoặc về chế độ ăn.
3. b05 `q10`: hai phương án nhiễu "Dung dịch NaOH" và "Quỳ tím" hơi yếu. Không nên thay bằng "nước bromine", vì nước bromine cũng phân biệt được hai chất nên sẽ thành 2 đáp án đúng.
4. b06 `tinh-bot.svg` chú thích "SGK vẽ dạng ghế": hình SGK là dạng phối cảnh gần dạng ghế, ghi như vậy chấp nhận được.
5. Hai bài khá dài (b06 khoảng 45 phút đọc). Có thể tách phần "Dạng bài thi" thành trang riêng nếu app hỗ trợ.
