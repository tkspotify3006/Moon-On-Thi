# Biên bản thẩm định Hóa 12 (đợt 5a): b11, b15

- b11: Ôn tập chương 3 (Hợp chất chứa nitrogen)
- b15: Thế điện cực và nguồn điện hoá học

Ngày 28/10/2026. Đối chiếu SGK KNTT Hóa 12, tr. 49–50 và tr. 67–77 (PDF 51–52, 69–79).

Cách kiểm:
- Giải lại độc lập mọi câu tính toán trong quiz (62 câu: 36 mcq, 10 tf × 4 ý, 16 short) và mọi ví dụ có số liệu trong bai.md bằng python/sympy (`scratchpad/rv-hoa-5a/kt.py`). E° lấy đúng Bảng 15.1 SGK. Đếm lại từng chất ở các câu "có bao nhiêu chất". Liệt kê vét cạn các bộ X, Y, Z (b15 `q15`) và mọi trình tự peptide (b11 `q26`).
- Với b11: đối chiếu số liệu với bai.md và quiz.json của b08, b09, b10.
- Render 5 hình SVG bằng Playwright và tự xem từng hình.
- Mở 2 bài và 2 quiz trong app (390×844, bản sao repo có bật cờ ready): không có `.katex-error`, đủ hình (2/3), không có lỗi console, `scrollWidth` = 390. Bảng rộng cuộn ngang trong khung riêng, đọc được.
- `kiem-tra.mjs`: 0 lỗi. Các cảnh báo chỉ là "chưa ready".

## Lỗi nghiêm trọng đã sửa (4)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b11 bai.md, bảng 2.1, hàng Cu(OH)~2~/NaOH | Ô methylamine ghi "—", tức là không phản ứng. Điều này trái với SGK (tr. 49: methylamine tạo phức với Cu(OH)~2~) và trái với chính khung ghi nhớ của bài. Ba ô amino acid cũng ghi "—", dễ hiểu là "không phản ứng". | Hàng đổi tên thành "Cu(OH)~2~/NaOH". Ô methylamine ghi "xanh lam (không phải biuret)". Ba ô glycine, lysine, glutamic acid ghi "không tím". Chú thích bảng thêm một câu: ở hàng này, điều cần xét là có màu tím biuret hay không. |
| b11 bai.md, bảng 2.2 (bậc amine – bậc carbon) và `q01` explain | Viết "(CH~3~)~3~C–NH~2~ gắn vào C bậc bốn". Sai: C này liên kết với 3 nguyên tử C nên là C **bậc ba**. Chỗ này lại nằm đúng ở mục dạy phân biệt bậc C với bậc amine. | Sửa thành "N gắn vào C bậc ba" ở cả hai chỗ. |
| b11 `q26` (trùng bài lẻ) | Peptide Ala-Gly-Val-Gly, với ba dipeptide Ala-Gly, Gly-Val, Val-Gly, trùng hẳn với b09 `quiz` (câu thuỷ phân không hoàn toàn Ala-Gly-Val-Gly). Thành phần 2 Gly, 1 Ala, 1 Val cũng trùng với ví dụ của b09. | Đổi thành X gồm 2 Ala, 1 Gly, 1 Val với các dipeptide Val-Ala, Ala-Gly, Gly-Ala, suy ra X = Val-Ala-Gly-Ala (đã liệt kê vét cạn, chỉ có 1 trình tự). Đáp án các ý: Đ (3 liên kết peptide) / S (đầu N là Val, không phải Ala) / Đ (M = 316) / S (15,8 g X cho 22,9 g muối, không phải 23,8 g; 23,8 là quên trừ nước). |
| b11 `q30` (lộ đáp số) | %N = 19,18% dẫn tới C~4~H~11~N, có 8 đồng phân. Kết quả "C~4~H~11~N: 8" là số cần nhớ của b08 (in đậm ở bai.md, có Ví dụ 2 và câu quiz riêng), nên học sinh không cần đếm. | Đổi thành %N = 16,09%. Suy ra C~5~H~13~N, có **17** đồng phân: 8 bậc một, 6 bậc hai (4 + 2), 3 bậc ba (2 + 1). Explain viết lại từng bước. Đáp án nhiễu nêu trong explain là 8 (chỉ đếm bậc một). |

## Lỗi nhỏ đã sửa (9)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b15 bai.md, khung "Câu thuộc lòng dãy điện hoá" | Câu nhớ xếp Hg trước Ag, trái với Bảng 15.1 SGK: E°(Ag^+^/Ag) = +0,799 V < E°(Hg^2+^/Hg) = +0,853 V. Khung này cũng không ghi là ngoài SGK. | Tiêu đề thêm "(ngoài SGK)". Giữ câu nhớ quen thuộc nhưng thêm đoạn "Cẩn thận ở đoạn cuối": thứ tự Hg trước Ag là theo cặp Hg~2~^2+^/Hg. Với cặp Hg^2+^/Hg của SGK thì Ag đứng trước Hg. Pt đứng sau Hg, trước Au. Luôn dùng số E° đề cho. |
| b15 `truc-the.svg` | Giá trị E° bị làm tròn đến 2 chữ số (−2,92; −0,26; −0,13; +0,80…), khác với bảng SGK và bảng trong bài. | Ghi đủ như SGK: −2,924; −2,713; −2,356; −1,676; −0,762; −0,44; −0,257; −0,137; −0,126; 0; +0,340; +0,799; +1,52. Đã render lại và kiểm: không có chữ chồng. |
| b15 bai.md, mục 3.1, dãy điện hoá | Thiếu Ca, trong khi dãy SGK tr. 71 có Ca^2+^ ngay sau K^+^. | Thêm Ca vào cả hai dãy và ghi chú "SGK có thêm Ca ngay sau K". |
| b15 bai.md, mục 5.1, acquy chì | Cấu tạo Pb/PbO~2~/H~2~SO~4~ nằm ngoài khung "mở rộng" nhưng không có nhãn. | Thêm câu theo SGK (acquy là pin thứ cấp, tái tạo khi sạc bằng dòng một chiều) và nhãn "Cấu tạo (mở rộng)". |
| b15 bai.md, mục 4.4, pin chanh | Viết "khoảng 0,9 V" như số liệu chắc chắn. SGK không nêu số này. | Sửa thành "khoảng 0,9 – 1 V (số liệu tham khảo, ngoài SGK, tuỳ quả chanh và điện cực)". |
| b15 bai.md, khung "Thử với nhiều cặp kim loại" | Viết "E° chênh càng nhiều thì điện áp càng lớn". Trong pin chanh, cathode là H^+^ bị khử trên Cu, và Al có lớp oxide nên thực tế cho điện áp thấp hơn dự đoán. | Sửa thành "nhìn chung, kim loại làm anode có E° càng nhỏ thì điện áp càng lớn" và thêm lưu ý về Al. |
| b15 bai.md, mục 5.4 | Điện áp pin lithium-ion 3,6 – 3,7 V và pin khô 1,5 V là số liệu ngoài SGK nhưng không ghi nhãn. Bản thân các số này đúng. | Thêm "số liệu ngoài SGK". |
| b11 `q07` | Đề nói "trong công nghiệp" điều chế aniline bằng Fe/HCl. Thực tế, công nghiệp chủ yếu hydro hoá xúc tác. SGK và b08 chỉ nói "khử hợp chất nitro" bằng hydrogen mới sinh. | Đổi thành "Trong phòng thí nghiệm, aniline thường được điều chế bằng cách". |
| b11 `q18` | Đáp án đúng dài gấp đôi các phương án khác và có chữ "(một protease)" gợi ý đáp án. | Viết lại 4 phương án dài tương đương. Đáp án đúng là "Enzyme papain thuỷ phân một phần protein của thịt". |

## Đã kiểm, không có lỗi

- **Giá trị E° (b15).** Bảng trong bài, các ví dụ và 28 câu quiz đều khớp từng số với Bảng 15.1 SGK:
  - K −2,924; Na −2,713; Mg −2,356; Al −1,676; Zn −0,762; Fe −0,44; Cd −0,403; Ni −0,257; Sn −0,137; Pb −0,126.
  - Cu +0,340; Fe^3+^/Fe^2+^ +0,771; Ag +0,799; Hg +0,853; Au +1,52; Li −3,040; O~2~/H~2~O +1,229; 2H~2~O/H~2~ −0,414 (pH = 7).
- **Quy tắc α, chiều electron, cầu muối (b15).** Đúng hết.
  - Quy tắc α: dạng oxi hoá ở trên, dạng khử ở dưới, E° tăng từ trái sang phải. Chất khử ở góc dưới bên trái phản ứng với chất oxi hoá ở góc trên bên phải.
  - Electron đi qua dây dẫn từ anode (cực âm) sang cathode. Electron không đi qua dung dịch.
  - Cầu muối: anion về cốc anode, cation về cốc cathode.
  - Hình `pin-zn-cu.svg` và `quy-tac-alpha.svg` vẽ đúng các chiều này.
  - Acquy chì: phương trình Pb + PbO~2~ + 2H~2~SO~4~ → 2PbSO~4~ + 2H~2~O cân bằng, mỗi ngăn khoảng 2 V, 6 ngăn cho 12 V. Phần này đã ghi "mở rộng".
- **Đáp án b15.**
  - short: 5; 1,56; 1,92; 3; 1,55; 3,25; 3; 2,48.
  - mcq tính toán:
    - `q12`: 1,056 (nhiễu 0,542; 1,855; −1,056).
    - `q14`: Ni.
    - `q15`: Fe, Cu, Zn là bộ duy nhất đúng trong 4 phương án.
  - tf có số liệu:
    - `q17`: 1,102 V.
    - `q19`: 2,016 V; 0,09 mol e; 0,81 g (nhiễu 1,336; 1,215).
  - Ví dụ trong bài:
    - Ví dụ 5: 0,597 V.
    - Ví dụ 6: Mg; 2,696 V.
    - Ví dụ 7: 4 phản ứng.
    - Ví dụ 8: Fe, Hg; 1,293 V.
    - Ví dụ 9: 0,06 mol; 1,92 g.
- **Đáp án b11.**
  - short: 3; 4; 3; 17 (mới); 33,1; 18,3; 41,1; 0,97.
  - mcq tính toán:
    - `q14`: 22,8% (nhiễu 77,2; 30,0).
    - `q15`: 28,65 (nhiễu 25,35; 34,05; 27,525).
    - `q16`: 4,95 (nhiễu 14,85; 4,995; 1,395).
    - `q19`: 13,25 (nhiễu 12,35; 11,425; 14,15).
    - `q20`: 12.
    - `q21`: 22,2 (nhiễu 28,8; 29,4; 15,0).
  - tf:
    - `q25`: 0,1 mol; 20,7 g; 66,4%; 0,35 mol.
    - `q26` mới: 316; 22,9 g.
  - Ví dụ trong bài:
    - Ví dụ 1: 6 / 2 / 2 / 1.
    - Ví dụ 2: 11,48 g; 18,78 g; 78,4%.
    - Ví dụ 3: 45,1%; 0,35 mol; 31,2 g.
    - Ví dụ 4: 18,55 g.
    - Ví dụ 7: 3 dipeptide, 2 tripeptide.
- **Bảng thuốc thử × chất (b11, 8 chất × 7 thuốc thử).** Đã kiểm từng ô. Ngoài hàng Cu(OH)~2~ đã sửa, các hàng còn lại đều đúng:
  - Quỳ tím: methylamine, lysine làm quỳ hoá xanh. Glutamic acid làm quỳ hoá đỏ. Aniline, glycine không đổi màu quỳ.
  - HCl: phản ứng với tất cả các chất.
  - NaOH: amine không phản ứng.
  - Nước bromine: chỉ aniline cho kết tủa trắng.
  - Biuret: dipeptide không tím. Tripeptide và protein cho màu tím.
  - HNO~3~ đặc và đun nóng: chỉ xét với protein.
  - Bảng 4.1 ("dấu hiệu chỉ một chất có") và sơ đồ `nhan-biet.svg` (quỳ tím, rồi biuret, rồi nước bromine) đều đúng.
- **Trùng số liệu với bài lẻ (b11).** Đã so với b08, b09, b10. Ngoài `q26` và `q30` đã sửa, không còn câu nào trùng.
  - `q31` (% gốc Gly trong fibroin) cùng dạng với Ví dụ 10 của b10 nhưng khác số liệu.
  - pI của glycine và glutamic acid trùng b09 vì đó là hằng số. pH đệm khác.
- **Hình thức.**
  - Mỗi câu short có kết quả không nguyên đều ghi rõ cách làm tròn. Đáp số đều ≤ 4 ký tự.
  - Không chỗ nào gọi phương án bằng chữ A/B/C/D.
  - Vị trí đáp án mcq: b11 là 5/5/6/5, b15 là 4/4/4/3.
  - b11 có 34 câu (21 mcq, 5 tf, 8 short), 35% ở mức vận dụng.
  - b15 có 28 câu (15 mcq, 5 tf, 8 short).
- **Nội dung so với SGK.** b15 đủ 4 mục của SGK: cặp oxi hoá – khử, thế điện cực chuẩn, pin điện hoá (kể cả lắp pin chanh), các loại pin khác. Bảng 15.2 về ưu, nhược điểm các loại pin đã được diễn đạt lại. b11 có đủ 6 hàng của bảng hệ thống SGK tr. 49 và đối chiếu cả 5 câu luyện tập SGK tr. 50 bằng các ví dụ tự đặt.
