# Brief thẩm định bài (dùng chung)

Bạn là giáo viên giỏi của môn được giao, thẩm định ĐỘC LẬP các bài vừa soạn cho app ôn thi THPT (học sinh lớp 12, SGK Kết nối tri thức, chương trình 2018). Quy chuẩn soạn: `scripts/BRIEF-SOAN-BAI.md` (đọc kỹ, gồm mục Ôn tập chương / Thực hành / Trình bày). SGK bản ảnh trong /home/claude/thpt/src/ (Read với pages). Tham khảo các biên bản thẩm định trước trong `scripts/review-*.md` để biết lỗi hay gặp.

## Việc cần làm
1. **Giải lại độc lập TỪNG câu trong quiz.json** (mcq, từng ý tf, short) bằng python/sympy — không tin đáp án sẵn có. Kiểm: đáp án đúng; mcq chỉ 1 phương án đúng; nhiễu hợp lý (ứng với lỗi sai điển hình); đề đủ dữ kiện và giả thiết; short ghi rõ làm tròn, đáp số ≤ 4 ký tự; explain đúng, KHÔNG gọi phương án bằng A/B/C/D; đáp án đúng không thường là phương án dài nhất.
2. **Chống lộ đáp số / trùng**: câu luyện tập không được trùng số liệu với ví dụ trong bài, với câu khác cùng bài, hay với bài lẻ cùng chương (đối với bài ôn chương); không chép nguyên đề/ví dụ SGK.
3. **bai.md**: kiến thức đúng khoa học và đúng SGK (đối chiếu trang sách); phần ngoài SGK phải đúng và ghi rõ "mở rộng/ngoài SGK"; số liệu thực tế không chắc thì viết thận trọng hoặc bỏ; ví dụ tính đúng; đủ nội dung SGK; giảng dễ hiểu; không chép nguyên văn SGK.
4. **Hình SVG**: render bằng Playwright, tự nhìn ảnh — đúng khoa học, không chữ chồng, chữ ≥ 12px.
5. **Hiển thị**: mở bài và quiz trong app ở 390×844 — không `.katex-error`, không lỗi console, trang không cuộn ngang (document.scrollWidth ≤ 390), bảng/BBT đọc được.
6. **Sửa trực tiếp** lỗi trong thư mục các bài được giao (giữ `id` câu; không sửa file khác). Chạy `node scripts/kiem-tra.mjs` (0 lỗi).
7. Server xem thử: `cd /home/claude/on-thi-thpt && python3 -m http.server <cổng>` (bài chưa có "ready" thì dùng bản sao repo trong scratchpad riêng và bật cờ ở bản sao). Tắt server bằng kill PID, KHÔNG dùng `pkill -f`. Script tạm để trong thư mục scratchpad riêng của bạn.
8. Ghi biên bản `scripts/review-<môn>-<tên-đợt>.md`.

Trả lời ngắn: số lỗi nghiêm trọng đã sửa (sai đáp án/kiến thức/lộ đáp số/đề 2 nghĩa), số lỗi nhỏ, nhận xét 1–3 câu.
