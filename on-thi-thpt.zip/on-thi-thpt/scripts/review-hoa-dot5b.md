# Biên bản thẩm định Hóa 12 (đợt 5b): b13, b14

- b13: Vật liệu polymer
- b14: Ôn tập chương 4 (Polymer)

Ngày 28/10/2026. Đối chiếu SGK KNTT Hóa 12, tr. 56–66 (PDF 58–68). Xem thêm tr. 52–53 (Bài 12) để kiểm phần "tăng mạch" và nhiệt dẻo/nhiệt rắn.

Cách kiểm:
- Giải lại độc lập cả 60 câu quiz (34 mcq, 10 tf × 4 ý, 16 short) và mọi ví dụ có số liệu trong hai bai.md bằng python/sympy, nguyên tử khối như SGK (`scratchpad/rv-hoa-5b/kt.py`). Đếm lại từng chất ở các câu "có bao nhiêu".
- Đối chiếu số liệu của b14 (quiz và ví dụ) với quiz.json, bai.md của b12 và b13. Đối chiếu số liệu trong nội bộ b13.
- Render 6 hình SVG bằng Playwright và tự xem từng hình.
- Mở 2 bài và 2 quiz trong app (390×844, bản sao repo, cổng 8874): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390. Bảng rộng nằm trong khung cuộn riêng và đọc được.
- `kiem-tra.mjs`: 0 lỗi (các cảnh báo "chưa ready" là bình thường).

## Lỗi nghiêm trọng đã sửa (1)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b13 `q27` (short, đốt cháy buna-S) | Dùng đúng mẫu 5,32 g buna-S như `q15` (mcq, cộng Br~2~), và cả hai có cùng đáp số tỉ lệ 3 : 1. Đề và phương án của `q15` cho sẵn đáp số 3 của `q27`. | Đổi số liệu: 3,74 g cao su, 12,32 g CO~2~, 3,42 g H~2~O. Khi đó C~28~H~38~, M = 374, k = **5**. Explain viết lại, có bước kiểm tra khối lượng. |

## Lỗi nhỏ đã sửa (9)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b13 `q11` | Phương án đúng ("nhóm amine của chất đóng rắn phản ứng với nhóm epoxy tạo polymer mạng không gian") dài gấp đôi các phương án nhiễu. | Rút gọn thành "chất đóng rắn (amine) phản ứng với nhóm epoxy". Các phương án nhiễu viết dài hơn cho cân. Explain thêm lí do loại hai phương án "kết tinh" và "lạnh". |
| b14 mục 1.4, bảng ba kiểu phản ứng | Xếp keo epoxy và poly(urea-formaldehyde) đóng rắn vào "tăng mạch" mà không ghi nhãn. SGK tr. 53 chỉ nêu lưu hoá cao su. Về khoa học thì đúng (khâu mạch thành mạng lưới), nhưng nằm ngoài SGK. | Ghi rõ: "lưu hoá cao su … là ví dụ của SGK. Mở rộng: keo epoxy, poly(urea-formaldehyde) đóng rắn cũng nối mạch thành mạng lưới". |
| b14 khung Lebedev | Tiêu đề không ghi "mở rộng". Chỉ có dòng cuối ghi "không có trong SGK". | Tiêu đề thêm "mở rộng ngoài SGK". |
| b14 khung "Polymer xanh" | PE xanh (ethanol mía → ethylene → PE) nằm ngoài SGK, chưa ghi nhãn. | Thêm "(mở rộng)". |
| b14 Ví dụ 6c | PET và tơ lapsan nằm ngoài SGK, chưa ghi nhãn. Ở ý b, tơ enang đã có nhãn. | Ghi "(mở rộng: tơ lapsan, nhựa chai kí hiệu số 1)". |
| b14 Ví dụ 7 | Viết "keo dán vết thương ngoài da dùng trong y tế có thành phần chính là ethyl cyanoacrylate". Không chính xác: keo y tế dùng chủ yếu octyl hoặc butyl cyanoacrylate. Ethyl cyanoacrylate là keo dán nhanh thông thường. | Đổi thành "Một loại keo dán nhanh có thành phần chính là ethyl cyanoacrylate…". Số liệu (M = 125) giữ nguyên. |
| b13 khung bẫy về tơ lapsan | Viết "SGK không học riêng", chưa rõ là phần mở rộng. | Viết thành "*Mở rộng (ngoài SGK):* …". |
| b13 mục 1.2, PMMA | "(mica, acrylic)" dễ hiểu nhầm, vì mica là tên một khoáng vật. | Sửa thành "(ngoài đời hay gọi là tấm mica, acrylic)". |
| b13 mục 3.1 | Viết "Mạch phân nhánh hay mạng lưới … không kéo thành sợi được". Câu này tuyệt đối hơn SGK, vì SGK chỉ nói polymer làm tơ "thường" có mạch không phân nhánh. | Đổi thành "thường có …" và "khó xếp khít, khó kéo thành sợi". |

**Rút gọn b13** (từ 6 317 xuống 6 164 chữ theo `wc`):
- Gọn đoạn "Vì sao composite bền hơn" và đoạn bản chất của keo dán.
- Bỏ bước 4 thừa ở phương pháp Dạng 1.
- Bỏ một ý trong khung bẫy sau Ví dụ 12. Ý này lặp lại chuyện Br~2~ không cộng vào vòng benzene, đã có ở mục 4.3 và Ví dụ 7.
- Bỏ danh sách "Ghi nhớ khi làm bài" cuối bài, vì trùng với khung ghi nhớ đầu bài và các khung bẫy.

Phần còn lại không lan man. Bài dài vì SGK có 5 mục (9 trang), mỗi mục cần ví dụ. Độ dài này tương đương b09, b10.

## Đã kiểm, không có lỗi

- **Đáp án b13**:
  - mcq tính toán: `q14` 10,75 tấn (nhiễu 8,60; 5,38; 1,72), `q15` 3 : 1.
  - tf `q20`: M = 215; 6,51%; 48 g Br~2~ (ý sai ghi 16 g); 2,6 mol khí.
  - short: 53; 1200; 5; 48; 21,6; 4; 5 (mới); 397.
  - Câu đếm: `q12` có 3 polymer trùng ngưng (tơ visco không tính). `q13` có 3 tơ từ cellulose. `q23` có 5 polymer trùng hợp.
- **Ví dụ b13**:
  - Ví dụ 2: 2,69 tấn và 1,00 tấn (nhiễu 0,62). Ví dụ 5: 77,8% và 33 kg. Ví dụ 6: 32 g. Ví dụ 7: 2 : 1.
  - Ví dụ 11: 2 000 và 1,15 tấn (nhiễu 1,44). Ví dụ 12: a = 1,998 ≈ 2.
  - Ví dụ 4: 3/2, 4, 3. Ví dụ 9: 3/2/2.
- **Đáp án b14**:
  - mcq tính toán:
    - `q15`: 42, tức PP.
    - `q16`: 5,40 (nhiễu 10,80; 13,50; 6,75).
    - `q17`: 3,80% (nhiễu 1,94; 3,04; 3,95).
    - `q18`: 7,20 (nhiễu 3,60; 6,21; 14,40).
  - tf: `q22` 1,25 tấn. `q23` 266 g/mol và 0,3 mol. `q24` M = 111.
  - short: 4; 56,8; 2500; 2,6; 6,4; 24 (a : b = 3 : 2); 1,92; 1,15.
  - Câu đếm: `q11` có 4 chất trùng hợp được. `q12` có 4 polymer chứa N. `q25` có 4 polymer.
- **Ví dụ b14**:
  - Ví dụ 1: 5/4/4/8. Ví dụ 2: PVC và 6,25 tấn. Ví dụ 3: 31,25 tấn gỗ (nếu quên H thì ra 6 tấn).
  - Ví dụ 4: 30,51 kg, 4,86 kg, 35,37 kg, n = 200. Ví dụ 7: 125.
- **Phương trình.** Đều cân bằng và khớp SGK:
  - Trùng hợp CH~2~=CHR, PMMA, nitron, 5 loại cao su tổng hợp, keo 502.
  - PPF và poly(urea-formaldehyde) (+nH~2~O).
  - Acetyl hoá cellulose.
  - Mở rộng: enang và PET (+2nH~2~O).
- **Phân loại theo SGK.**
  - Tơ: tự nhiên (bông, len, tơ tằm), tổng hợp (nylon-6,6, capron, nitron), bán tổng hợp (visco, cellulose acetate). Khớp sơ đồ SGK tr. 59 và hình `phan-loai-to.svg`.
  - Chất dẻo: PE, PP, PVC, PS, PMMA, PPF.
  - Cao su: tự nhiên và tổng hợp. Cao su tổng hợp đều điều chế bằng trùng hợp (SGK tr. 62).
  - Keo dán: 3 loại như SGK tr. 63.
  - Capron điều chế bằng trùng hợp mở vòng (SGK tr. 60). Trùng ngưng 6-aminohexanoic acid dựa trên Câu 4b, tr. 66.
- **Phần ngoài SGK đều đúng và nay đã có nhãn**: lapsan/PET, enang, Lebedev, PE xanh, vi nhựa (khung "em có biết", có ghi mở rộng), epoxy trong "tăng mạch".
- **Dẫn chéo sang Bài 12** đều đúng mục: mục 2 (kí hiệu tái chế), 3.1, 3.2, 4.2, Dạng 3, Dạng 4, Ví dụ 12.
- **Trùng số liệu.** Quiz và ví dụ của b14 không trùng nguyên bộ số với b12, b13. Một số con số trùng nhau chỉ là ngẫu nhiên, ở bài khác dạng: 2,08 tấn PS ở b14 `q28` so với 2,08 g ở b13 Ví dụ 7; đáp số 1,15 ở b14 `q32` so với b13 Ví dụ 11.
- **Hình.** 6 hình đều đúng khoa học, không có chữ chồng chữ. Cỡ chữ từ 12 đến 15, viewBox rộng 540, mỗi hình có `<title>`.
- **Hình thức quiz.**
  - Không gọi phương án bằng chữ A/B/C/D. Short ≤ 4 ký tự, các câu cần làm tròn đều ghi rõ.
  - Vị trí đáp án: b13 4/4/3/4, b14 5/5/5/4.
  - Số câu "đáp án là phương án dài nhất": b13 4/15, b14 5/19.
  - b14 có 32 câu (19 mcq, 5 tf, 8 short), 11 câu ở mức vận dụng.
- **Bản quyền.** Không có đoạn chép nguyên văn SGK. Câu 4 và Câu 6 phần Luyện tập (tr. 66) được làm thành đề tương tự với chất khác (Ví dụ 6, 7; `q24`).

## Góp ý chưa sửa

1. b14 `q23` (buna-S 3 : 1, M = 266) và b13 `q15` (5,32 g = 0,02 · 266) có cùng tỉ lệ 3 : 1. Đây là tỉ lệ SGK tr. 62 nêu, và hai câu khác dạng, nên giữ lại.
2. b13 bảng 1.3 có thêm cột "tính chất nổi bật" và hàng PPF (bakelite: vỏ ổ cắm, tay cầm xoong). SGK không có phần này, nhưng là kiến thức phổ thông đúng.
3. Bảng 1.2 của b14 rộng khoảng 506 px trên màn 390 px. Bảng cuộn ngang trong khung riêng, trang không cuộn ngang.
4. Một số `explain` (b13 `q14`, b14 `q16`–`q18`) có ghi "Nhiễu: …" kèm con số. Cách này giống các bài trước, không gọi phương án bằng chữ cái.
