# Biên bản thẩm định Hóa 12 (đợt 4): b03, b07, b12

- b03: Ôn tập chương 1 (Ester – Lipid)
- b07: Ôn tập chương 2 (Carbohydrate)
- b12: Đại cương về polymer

Ngày 24/10/2026. Đối chiếu SGK KNTT Hóa 12, tr. 18–19, 33–34, 51–55 (PDF 20–21, 35–36, 53–57).

Cách kiểm:
- Giải lại độc lập mọi câu tính toán trong quiz (94 câu: 54 mcq, 16 tf × 4 ý, 24 short) và mọi ví dụ có số liệu trong bai.md bằng python, nguyên tử khối như SGK (`scratchpad/rv-hoa-4/kt.py`). Đếm lại từng chất ở các câu "có bao nhiêu chất".
- Đối chiếu số liệu với quiz.json và bai.md của b01, b02 (cho b03) và b04, b05, b06 (cho b07).
- Render 9 hình SVG bằng Playwright và tự xem từng hình.
- Mở 3 bài và 3 quiz trong app (390×844): không có `.katex-error`, đủ hình (2/3/4), không có lỗi console.
- `kiem-tra.mjs`: 0 lỗi, 0 cảnh báo.

## Lỗi nghiêm trọng đã sửa (0)

Không có. Đáp án của cả 94 câu đều đúng, mcq chỉ có 1 đáp án bảo vệ được.

## Lỗi nhỏ đã sửa (9)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b07 `chuyen-hoa.svg` | Mũi tên "tinh bột, cellulose → dextrin → maltose → glucose" cho thấy cellulose cũng thuỷ phân qua dextrin, maltose. Sai: đó là con đường của tinh bột. Ghi chú bên trái lại nằm cạnh đường CO~2~ quay về, dễ hiểu nhầm. | Ô giữa đổi thành "dextrin, maltose (từ tinh bột)". Ghi chú đổi thành "cellulose thuỷ phân (H^+^, t°) cũng cho glucose, không qua dextrin, maltose". |
| b07 bai.md, bảng 2.1, hàng nước Schweizer | Ô tinh bột ghi "—", tức khẳng định tinh bột không tan trong nước Schweizer. SGK không nói điều này, và thực tế không chắc. Bốn ô đường để "—" cũng dễ hiểu là "không tan". | Hàng đổi thành "Nước Schweizer (dấu hiệu SGK chỉ nêu cho cellulose)". Bốn ô đường ghi "(tan sẵn trong nước)", ô tinh bột ghi "không xét". Thêm một câu vào chú thích: nhận ra tinh bột thì dùng iodine. |
| b07 bai.md, Ví dụ 3b | Viết "1 000 : 138 ≈ 7,25 tấn ≈ 7,2 tấn". Làm tròn hai lần nên trông như sai, vì 7,25 thường được làm tròn lên 7,3. | Viết "≈ 7,246 tấn ≈ 7,2 tấn". |
| b12 `q24` | Gần như chép Ví dụ 7: cùng dạng, cùng hiệu suất 80%, số liệu chỉ chia đôi (29,2 → 14,6 kg), đáp số cũng chỉ bằng một nửa (36,16 → 18,08). | Đổi hiệu suất thành 90%: m = 0,1 · 226 · 0,9 = 20,34, đáp số **20,3**. Đáp án nhiễu trong explain (quên trừ nước) là 23,6. |
| b12 bai.md, mục 1.4 | Phần phân loại polymer theo nguồn gốc, cách tổng hợp và cấu trúc mạch không có trong bài này của SGK, nhưng không ghi "mở rộng". | Tiêu đề đổi thành "Phân loại polymer (mở rộng)". |
| b03 bai.md, mục 2.2 | Tiêu đề ghi "Bốn kiểu ester", nhưng bảng có 5 dòng (kể cả chất béo). | Sửa thành "Năm kiểu ester khi gặp NaOH (kể cả chất béo)". |
| b03 `he-thong.svg` | Chữ "trường hợp riêng:" chạm vào đường nối của nhánh ester. | Ngắt dòng thành "trường hợp / riêng: triester / của glycerol". |
| b12 `trung-hop-trung-ngung.svg` | Viền elip nét đứt quanh "OH H" đè lên dấu "–" ở hai bên, đọc thành "H+NH". | Giãn chữ, dời elip và mũi tên "tách ra H~2~O". |
| b12 `polymer-monomer.svg` | "(–CH~2~–CH~2~–)~n~    n = hệ số…" thiếu dấu ngăn, đọc như một biểu thức. | Thêm dấu ";". |

## Đã kiểm, không có lỗi

- **Đáp án.** Phương án nhiễu đều ứng với lỗi điển hình (đã tính lại từng số).
  - b03 short: 5; 7; 15; 7,8; 16,8; 1,68; 600; 25,8.
  - b03 mcq tính toán:
    - `q16`: 15,0 (nhiễu 16,4; 13,6; 21,4).
    - `q17`: 22,4 (nhiễu 18,4; 24,2; 14,8).
    - `q18`: 35,28 (nhiễu 33,36; 32,24; 30,72).
    - `q19`: 882 (nhiễu 884; 880; 878).
  - b03 tf có số liệu:
    - `q22`: 60%.
    - `q24`: 0,05 mol; 52,1%; 16,7 g.
    - `q25`: 2,76 g; 30,58 g; 17,5%.
  - b07 short: 4; 38,9; 7,84; 4; 32,4; 22,8; 144; 81.
  - b07 mcq tính toán:
    - `q15`: 47,52.
    - `q16`: 43,2 (nhiễu 41,47; 51,84; 46,66).
    - `q17`: 125,12.
    - `q18`: 432.
    - `q19`: 49 580 L.
  - b07 tf có số liệu:
    - `q25`: 0,02 / 0,03 / 0,02 mol; 43,2%.
    - `q26`: 181,7 kg; 97,9 m^3^; 11,0 tấn.
  - b12 short: 62,5; 5; 3000; 3,4; 20,3 (mới); 2088; 40; 8,8.
  - b12 mcq tính toán:
    - `q13`: 150 (nhiễu 129; 139; 300).
    - `q14`: 4,00 tấn.
  - b12 tf `q18`: 113 g.
- **Câu đếm số chất.** Đã đếm lại từng chất:
  - b03: `q13` có 4 phát biểu đúng. `q14` có 3 chất. `q15` có 2 đồng phân. `q26` có 5 ester (kể cả methyl methacrylate, methyl benzoate). `q27` có 9 − 2 = 7 ester.
  - b07: `q08` có 3 chất. `q09` có 3 chất (amylopectin có α-1,4). `q27` có 4 chất. `q30` có 4 phát biểu đúng. Ví dụ 1: 2 / 3 / 3 / 5.
  - b12: `q11` có 5 chất (có caprolactam). `q12` có 3 polymer. `q21` có 5 polymer. Ví dụ 3: 3/3/2. Ví dụ 6: 4 chất. Ví dụ 9: 3 polymer.
- **Hình thức câu hỏi.** Mỗi câu short có kết quả không nguyên đều ghi rõ cách làm tròn. Đáp số short đều ≤ 4 ký tự. Không chỗ nào gọi phương án bằng chữ A/B/C/D.
- **Vị trí đáp án mcq:**
  - b03 và b07: phân bố đều 5/5/5/5.
  - b12: phân bố 4/3/4/3.
- **Tỉ lệ dạng câu của hai bài ôn chương:**
  - b03 có 33 câu (20 mcq, 5 tf, 8 short), 36% ở mức vận dụng.
  - b07 có 34 câu (20 mcq, 6 tf, 8 short).
- **Ví dụ trong bai.md:** đúng hết.
  - b03: Ví dụ 1 đến 5.
  - b07: Ví dụ 2 (35,1 g; 48,7%), Ví dụ 3 (138 kg), Ví dụ 4 (0,54 mol; 73,3%).
  - b12: Ví dụ 1 (15 000), Ví dụ 7 (36,16 kg), Ví dụ 11 (120; 5,04 tấn), Ví dụ 12 (5 509 m^3^), Ví dụ 13 (46; nhiễu 23).
- **Phương trình.** Đều cân bằng: chuỗi ester/chất béo, quang hợp tạo tinh bột (6nCO~2~ + 5nH~2~O), cellulose trinitrate, nylon-6,6 (+2nH~2~O), thuỷ phân nylon-6,6 trong HCl dư (tạo muối ClH~3~N–…–NH~3~Cl), PMMA + NaOH, PVA + NaOH.
- **Bảng 6 chất × 8 thuốc thử (b07).** Kiểm từng ô và khớp bảng SGK tr. 34. Fructose: không làm mất màu nước bromine, nhưng có tráng bạc và tạo Cu~2~O. Saccharose: chỉ cho xanh lam và bị thuỷ phân. Tinh bột, cellulose: không hoà tan Cu(OH)~2~.
- **Kiến thức ngoài SGK đã ghi chú đúng:**
  - Glycerol + Cu(OH)~2~ (b03 `q23`): ghi "Hoá 11".
  - Lên men giấm: ghi "Hoá 11".
  - Điều chế C~2~H~2~, vinyl chloride: ghi "lớp 11".
  - Chỉ số acid (b03 `q31`): định nghĩa ngay trong đề.
  - Dầu nhớt: ghi "mở rộng".
  - PPF, PET, polypeptide: nằm dưới nhãn "Các ví dụ khác (mở rộng)".
  - Đồng trùng hợp: khung "em có biết".
- **Mắt xích polymer (bảng và hình):**
  - M mắt xích: PE 28, PP 42, PVC 62,5, PS 104, PMMA 100, polybuta-1,3-diene 54, polyisoprene 68, capron 113, nylon-6,6 226, PPF 106.
  - Hình lưu hoá: cầu –S–S– gắn vào C thay một H của nhóm CH~2~.
- **Trùng số liệu với bài lẻ.** Không có câu nào trùng nguyên số liệu với quiz hoặc ví dụ của b01, b02, b04–b06.
- **Bản quyền.** Không thấy đoạn nào chép nguyên văn SGK. Các câu ứng với phần Luyện tập SGK (b03 mục 5, b07 mục 7) đều đã đổi số liệu và chất.

## Góp ý chưa sửa

1. b07 `q31` có 34,56 g Ag (thuỷ phân tinh bột, H = 80%), trùng con số với đáp số Ví dụ 6 của b05 (maltose, H = 60%). Hai bài khác chất và khác chiều tính, nên giữ lại.
2. b07 `q32` cùng dạng với Ví dụ 4 (hỗn hợp cellulose dinitrate và trinitrate), số liệu khác. Chấp nhận được vì là bài ôn chương.
3. b12 hình `cau-truc-mach.svg` và mục 1.4c xếp PE vào loại "không phân nhánh". Đây là cách xếp loại quen thuộc ở sách Việt Nam, dù LDPE thực ra có nhánh. Không ảnh hưởng đến đề thi.
4. b12 `quiz.json` được ghi lại bằng `json.dump` (indent 1) khi sửa `q24`. Nội dung không đổi, chỉ đổi cách xuống dòng.
