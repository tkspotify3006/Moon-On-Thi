# Biên bản thẩm định — Sinh 12, Bài 14, 15, 16, 17 (đợt 6)

Ngày: 2026-10-28 · Người thẩm định: Claude (độc lập với người soạn)
Đối chiếu SGK Sinh học 12 KNTT:
- Bài 14 (thực hành): PDF tr. 77–78, tức sách tr. 75–76. PDF tr. 79 là Sơ đồ tóm tắt chương 2.
- Bài 15: PDF tr. 80–84, tức sách tr. 78–82.
- Bài 16: PDF tr. 85–89, tức sách tr. 83–87.
- Bài 17 (thực hành): PDF tr. 90–91, tức sách tr. 88–89. PDF tr. 92 là Sơ đồ tóm tắt chương 3.

Script giải lại: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-sinh-6/kt.py`. Script tính lại mọi đáp số và mọi ví dụ có số liệu: số NST/chromatid, tỉ lệ %, phần bộ gene nhân sau lai trở lại, chiều dài mtDNA, nghiệm giao điểm hai đường năng suất (sympy), trung bình và % so với đối chứng.

Kết quả `node scripts/kiem-tra.mjs` trên bản sao repo có bật `ready` cho b14–b17: **0 lỗi**.
App (390×844, `python3 -m http.server 8904` chạy trên bản sao):
- 4 bài và 4 quiz không có `.katex-error`, console sạch, không có ảnh hỏng;
- `scrollWidth` = 390 (không cuộn ngang); bảng 4 cột (b15 mục 2.1, b16 bảng so sánh) đọc được.

Hình SVG (10 hình): đã render bằng Playwright và xem từng ảnh. Chữ nhỏ nhất 12px, không có chữ chồng. Nội dung đúng khoa học:
- Hình 1 b15 khớp đủ 6 phép lai của Bảng 15.1 (cộng 3 ô thụ phấn cùng loại cành).
- Phả hệ b15 khớp Ví dụ 5 (người bệnh là 2, 4, 5, 6, 10, 11).
- Đồ thị b16 khớp bảng Ví dụ 3.
- Biểu đồ b17 khớp Ví dụ 5 (18/17, 35/27, 52/36).

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b14 | 19 (11 mcq · 4 tf · 4 short) | 0 | q07 3n; q14 cây IV 18 chromatid; q15 78 NST đơn; q16–q19 = 1000 · 9 · 94 · 2,8. Vị trí đáp án 3/3/2/3. |
| b15 | 28 (15 mcq · 5 tf · 8 short) | 0 | q15 ½ hữu dục : ½ bất dục, đều (S); q21–q28 = 3 · 7 · 3,1 (1/32) · 5,6 · 1600 · 25 · 37,5 · 0,75. Vị trí đáp án 3/4/4/4. |
| b16 | 28 (15 mcq · 5 tf · 8 short) | 0 | q14 TB M ≈ 5,97, N = 5,5; q19 6,225 > 5,95 và 37,7%; q21 = 4; q22 3,2; q23 93,8; q24 (đã đổi số) 44; q25 2,2; q26 60 (tại đó cả hai giống đạt 5,3); q27 3; q28 5. Vị trí đáp án 4/4/4/3. |
| b17 | 18 (10 mcq · 4 tf · 4 short) | 0 | q13: 66,7 · 102,2 · 26,7; q15–q18 = 27,8 · 71 · 28 · 150. Vị trí đáp án 3/2/3/2. |

Các ví dụ trong bai.md đều tính đúng:
- b14: VD5 = 54, VD6 (cũ là VD7) = 85%.
- b15: VD4 = 1/16 = 6,25%; VD7, VD10, VD11 đúng.
- b16: VD3 3,6/1,2; VD6 12,5%; VD7 40% và 29%; VD11 6,6 · 1,6 · 4,1, trung bình hai giống cùng 6,7.
- b17: VD2 43,3 / 31,7 / 73,1%; VD3 3,2 · 2,4 · 75%; VD5 56%.

Không câu nào gọi phương án bằng A/B/C/D. Câu short đều có đáp số ≤ 4 ký tự và nói rõ cách làm tròn.

## 2. Lỗi đã sửa

### Nghiêm trọng (3)
1. **b17 q14 ý 3: đề 2 nghĩa, có thể tranh cãi.** Ý cũ ghi Đúng: "nếu nhóm Y chia hạt ngẫu nhiên với số lượng rất lớn thì khác biệt trung bình vẫn gợi ý… nhưng không chứng minh được thường biến…". Có hai vấn đề:
   - Đây là mệnh đề ghép, có chữ "gợi ý" mang tính chủ quan.
   - Về thống kê, một thí nghiệm ngẫu nhiên hóa với cỡ mẫu lớn **có** chứng minh được môi trường ảnh hưởng đến kiểu hình. Vì vậy học sinh giỏi có thể chấm ngược.

   Đã thay bằng ý rõ ràng, giữ `id`: "Để kết quả nhóm Y chứng minh được thường biến theo đúng nguyên lí SGK, chỉ cần tăng số hạt gieo…" → **Sai**, vì gieo thêm hạt vẫn không làm các cây cùng kiểu gene. Câu bây giờ có 2 ý Đúng, 2 ý Sai; đã sửa `explain` cho khớp.
2. **b16 q24 trùng đáp số với Ví dụ 7.** VD7 tính ra 40% (so với trung bình bố mẹ), và đáp số q24 cũng là "40", nên học sinh có thể "đoán theo ví dụ". Đã đổi F~1~ 8,7 → 8,9 tấn/ha, đáp số mới **44** (43,5%). `explain` có thêm bẫy: so với trung bình bố mẹ sẽ ra ≈ 53%.
3. **b15 q18 ý 4: đề 2 nghĩa.** Câu cũ "xác suất họ sinh một người con trai bị bệnh là 1/2" có thể hiểu là P(bệnh | con trai) = 1. Đã sửa thành "xác suất để đứa con đầu lòng là con trai và bị bệnh là 1/2".

### Lỗi nhỏ (15)
4. **b14: dẫn sai bài.** Câu "thường biến, Bài 15" đã sửa thành **Bài 16**.
5. **b14: rút gọn phần lặp.** Bài thực hành dài gần bằng bài thường (5 670 từ), nên đã cắt 4 chỗ:
   - Bỏ Ví dụ 6 (Dạng 2) vì trùng gần nguyên câu q12. Dạng 2 nay dẫn về Ví dụ 1 và Ví dụ 3b, kèm một dòng *Bẫy*. Ví dụ 7 đổi số thành Ví dụ 6.
   - Bỏ bảng "dấu hiệu → kết luận" ở mục 2.2 vì trùng danh sách 3 câu hỏi, Hình 1 và dòng Tóm tắt.
   - Bỏ 2 dòng ở bảng "Lỗi thường gặp" vì trùng 2 khung *Bẫy*.
   - Gộp khung "tiêu bản cố định" và khung mẹo đếm NST.

   Bài còn khoảng 5 300 từ. Mọi nội dung SGK vẫn đủ.
6. **b14: sửa ý về chuyển đoạn trong một NST.** Câu cũ khẳng định chuyển đoạn trong một NST làm "vị trí tâm động không đổi", nhưng chuyển đoạn từ vai này sang vai kia làm đổi tỉ lệ hai vai. Đã viết lại thành "giữ nguyên chiều dài, nên thường khó nhận ra".
7. **b14 Dạng 1:** sửa lỗi gõ "số NST S".
8. **b14 q19:** sửa câu lủng củng "chuyển đoạn đoạn lớn".
9. **b14: đáp án mcq luôn là phương án dài nhất (11/11 câu).** Đã cân lại độ dài ở 8 câu: q01, q03, q04, q05, q08, q09, q10, q11. Chỉ còn q02, q06, q07 có phương án là cụm 2–3 từ, độ dài chênh không đáng kể.
10. **b15:** ghi nhãn "mở rộng, ngoài SGK" cho các phần sau:
    - khung "Phép thử thay nhân" (lai trở lại liên tiếp);
    - dòng "Thay nhân" trong bảng phân biệt;
    - khung số liệu hệ gene ti thể (16 569 cặp nucleotide, 37 gene = 13 + 22 + 2, số liệu đúng);
    - Ví dụ 7 (lúa lai ba dòng). Nội dung đúng: A = (S)rr, B = (N)rr, R = RR, F~1~ = (S)Rr hữu dục.
11. **b15 Ví dụ 10:** ghi rõ cải dầu kháng atrazine là ví dụ thực tế ngoài SGK. Thông tin đúng: đột biến ở gene lục lạp, di truyền theo dòng mẹ.
12. **b16:** ghi nhãn ngoài SGK cho các mục tác giả nêu, sau khi đối chiếu sách tr. 83–87:
    - "sự mềm dẻo kiểu hình": SGK không dùng thuật ngữ này;
    - danh sách đặc điểm thường biến: SGK KNTT không liệt kê thành mục;
    - bảng so sánh thường biến – đột biến – biến dị tổ hợp: phần tổng hợp từ nhiều bài;
    - Ví dụ 10 hoa anh thảo *Primula sinensis* (AA đỏ ở 20 °C, trắng ở 35 °C): ví dụ kinh điển của SGK cũ.

    Nội dung các mục này đều đúng khoa học.
13. **b16 khung ưu thế lai:** câu cũ gọi cả hai cơ chế là "giả thuyết siêu trội". Đã tách thành giả thuyết siêu trội và giả thuyết trội (che allele lặn có hại).
14. **b16 bò BBB:** sửa "cao hơn khoảng 40%" thành "cao hơn 40%" theo SGK tr. 86, ở cả bai.md và q08.
15. **b16 Ví dụ 8:** SGK không nói KC06-1 được tạo bằng phương pháp gì. Đã sửa đề thành "dựa vào mô tả trong SGK và tên giống".
16. **b16 q21:** ý (2) "cây lúa bạch tạng" trùng Ví dụ 9. Đã thay bằng "cành hoa giấy hoa trắng trên cây hoa đỏ, giâm vẫn hoa trắng" (đột biến soma). Đáp số vẫn là 4.
17. **b16 và b17: đáp án thường là phương án dài nhất.** Đã cân lại: b16 ở q04, q07, q09, q10, q13, q15; b17 ở q01, q02, q04, q06, q09.
18. **b15 q22:** câu đếm tổng hợp qua ba thế hệ trước ghi level 1. Đã đổi thành level 2.

## 3. Đã kiểm, không cần sửa
- **Bản quyền:** không thấy câu chép nguyên văn dài. Định nghĩa "giống cây trồng / vật nuôi" ở b16 mục 2.1 bám sát SGK nhưng đã diễn đạt lại và ghi nguồn, nên chấp nhận được.
- **b15:**
  - Bối cảnh 1900/1909 đúng; 3 kết luận của Correns đúng.
  - Năm đặc điểm di truyền ngoài nhân khớp SGK tr. 80.
  - Kĩ thuật thay ti thể khớp Hình 15.3. Ca Mexico 2016 (hội chứng Leigh, bé trai) đúng thực tế.
  - Bất dục đực tế bào chất: "trên 140 loài", các giống VT 505, MV2, Long Hương 8117, đúng SGK tr. 81.
  - Khung "ảnh hưởng của mẹ" ở ốc *Lymnaea* đã ghi nhãn ngoài SGK; nội dung đúng (kiểu gene nhân của mẹ quyết định, biểu hiện chậm một thế hệ).
- **b16:**
  - Ruồi giấm cánh cụt: dưới 29 °C cánh cụt, 31 °C cánh gần bình thường, khớp SGK.
  - PKU, galactosemia, leptin khớp SGK.
  - Thỏ Himalaya: 25 °C trở xuống thì đầu mút đen, từ 30 °C trở lên thì trắng toàn thân, khớp SGK.
  - Thành tựu: gà Đông Tảo, Landrace, BBB (900–1 250 kg), ST25 (từ thể đột biến trong CD20), Đài thơm 8 (10 tấn/ha), KC06-1 (8,5–10 tấn/ha), khớp SGK.
  - Khung myostatin và cẩm tú cầu có nhãn ngoài SGK, nội dung đúng.
  - Câu "lợn siêu nạc do đột biến gene điều hoà" khớp b04 (theo SGK Bài 4).
- **b17:**
  - Kích thước luống 20–30 cm × 1 m × 1,5 m, cách nhau 1 m, khớp SGK.
  - Cuống dài 15 cm, cắm sâu 4–5 cm, cây cách cây 15 cm, khớp SGK.
  - Chế độ tưới (mỗi ngày / 1 lần mỗi tuần, cùng lượng nước và thời điểm), đo sau 3 tuần hoặc 1 tháng, dùng T-test hoặc % so với đối chứng, khớp SGK tr. 88–89.
  - Hai câu thu hoạch được trả lời đúng ý.
- **b14:**
  - Trình tự 10× → 40× → dầu soi → 100× → lau dầu khớp SGK tr. 75–76.
  - Hai câu thu hoạch được trả lời đúng ý: đột biến NST có hại vì mất cân bằng gene; cây to bất thường thì nghi đa bội và kiểm chứng bằng đếm NST tế bào đầu rễ.

## 4. Góp ý chưa sửa
- b14 vẫn dài hơn mức gợi ý cho bài thực hành, khoảng 5 300 từ so với b17 khoảng 4 100. Phần còn lại không lặp và có giá trị, gồm Ví dụ 2–5, đọc ảnh bộ NST người, thể khảm. Có thể rút tiếp khi biên tập chung.
- b16 dài, khoảng 8 300 từ, vì có cả phần mở rộng (bảng so sánh, mức phản ứng rộng/hẹp, đồ thị). Các phần này đã ghi nhãn. Nên giữ, vì đề thi hay hỏi.
