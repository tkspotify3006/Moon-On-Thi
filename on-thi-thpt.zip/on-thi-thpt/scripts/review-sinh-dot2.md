# Biên bản thẩm định — Sinh 12, Bài 7, 10, 11 (đợt 2)

Ngày: 2026-10-24 · Người thẩm định: Claude (độc lập với người soạn)
Đối chiếu: SGK Sinh học 12 KNTT. PDF tr. 38–41 là sách tr. 36–39 (Bài 7), PDF tr. 52–55 là sách tr. 50–53 (Bài 10), PDF tr. 56–61 là sách tr. 54–59 (Bài 11). Mục lục ở PDF tr. 6.
Script giải lại: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-sinh-2/kt.py`. Script liệt kê giao tử bằng phân số: X/Y kèm allele cho Bài 10; giao tử liên kết và hoán vị theo f cho Bài 11. Nó giải lại mọi câu có tính toán và mọi ví dụ trong bai.md.
Kết quả `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**. Dòng "No character metrics for 'ặ'" đến từ bài Toán, không thuộc 3 bài này.
App (390×844): không có katex-error, cả 10 hình SVG hiển thị, console sạch, khung gợi ý mở được.

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b07 | 28 (15 mcq · 5 tf · 8 short) | 0 | q19: 5946 cặp, 2,02 µm, 269 histone. q20: 333 333 lần. q25: 224. q26: 1,73. q27: 100. q28: 5100. Vị trí đáp án mcq 4/4/4/3. |
| b10 | 27 (14 mcq · 5 tf · 8 short) | 0 | Đã liệt kê theo giới. q10: cái 100% đỏ, đực 1 : 1. q16.4: 1/4. q18.4: 3/16. q24: 9/16 → 0,56. q25: 25/32 → 0,78. q26: 3/16 → 0,19. q27: 5. Vị trí đáp án 4/4/3/3. |
| b11 | 28 (15 mcq · 5 tf · 8 short) | 0 | q14: A-bb 9%. q15: ab/ab = 1% → $\frac{Ab}{aB}$, f = 20% (đã kiểm cả 3 phương án nhiễu). q17: 8%, 46%, 160. q19: 10 kiểu gene, dị hợp 2 cặp 34%. q20.4: 7%. q25: 51. q26: 70. q27: 30. q28: 2. Vị trí đáp án 4/4/4/3. |

- Mỗi câu mcq chỉ có một phương án đúng. Câu short có đáp số ≤ 4 ký tự và ghi rõ cách làm tròn khi cần.
- Không câu nào gọi phương án bằng A/B/C/D.
- Các câu về ruồi giấm đều nói rõ giới nào có hoán vị. Câu hoán vị ở thực vật nói rõ "cả hai giới, tần số như nhau".
- Số liệu ngoài SGK (146 cặp nucleotide, 8 histone, H1, 0,34 nm) luôn được cho sẵn trong đề nên quiz không vượt chương trình.

## 2. Lỗi đã sửa

### Nghiêm trọng (1)
1. **b10 quiz q26 và bai.md Ví dụ 9: đề nhập nhằng "không mắc cả hai bệnh".** Cụm này đọc được theo hai nghĩa:
   - "không mắc bệnh nào": đáp số 3/16 ≈ 0,19 (đáp án của người soạn);
   - "không đồng thời mắc cả hai": đáp số ½ − 1/16 = 7/16 ≈ 0,44.

   Với câu trả lời ngắn, hai cách đọc cho hai đáp số khác nhau. Đã sửa thành "không mắc bệnh nào trong hai bệnh" ở cả quiz và ví dụ.

### Lỗi nhỏ (7)
2. **b07/bai.md, bảng hình thái:** câu "khi phân bào, mỗi chromatid sẽ đi về một tế bào con" sai với giảm phân I, vì khi đó hai chromatid đi cùng nhau. Đã sửa thành "khi tâm động tách (kì sau nguyên phân, kì sau II)…".
3. **b07/hinh-2-cau-truc.svg:** sợi DNA của chuỗi nucleosome kéo dài cắt qua ngoặc và nhãn "10 nm". Đã rút ngắn sợi và dời nhãn.
4. **b10/bai.md mục 1.2:** "Kí hiệu A là bộ NST thường" chưa đúng. Theo SGK, A chỉ **một** NST thường (44A = 44 NST thường). Đã sửa.
5. **b10/bai.md mục 1.4, số liệu "theo trí nhớ":** giữ con số khoảng 111–112 bé trai/100 bé gái vì khớp các số liệu thống kê dân số gần đây (2019–2024 dao động khoảng 111,4–112,1). Câu đã viết thận trọng hơn ("theo các số liệu thống kê…", kèm mức tự nhiên 104–106). Câu "hàng triệu nam giới khó tìm bạn đời" đổi thành dạng dự báo.
6. **b10/bai.md mục 1.1:** SGK tr. 50 lấy "chim cánh cụt" làm ví dụ loài có nhiều cặp NST giới tính. Ví dụ kinh điển của hiện tượng này là thú mỏ vịt (5 cặp X/Y). Bài vẫn ghi theo SGK, có thêm ví dụ thú mỏ vịt. Quiz không hỏi ý này.
7. **b11/bai.md, mẹo mục 2.4:** "giao tử liên kết luôn > 25%" sai khi f = 50%. Đã sửa thành ≥ 25% và nói rõ dấu bằng xảy ra khi f = 50%.
8. **b11/bai.md, khung nền tảng:** chú thích "(lớp 10, Bài 8)" chưa kiểm được số bài, nên đã đổi thành "(Sinh học 10)". **b11 quiz** cũng được bổ sung dữ kiện ở hai câu:
   - q20: thêm "mỗi gene quy định một tính trạng, trội hoàn toàn" (ý 4 hỏi kiểu hình lặn).
   - q23: thêm quy ước allele cho từng tính trạng (explain có suy ra dị hợp đều từ kiểu hình).

## 3. Đã kiểm, không cần sửa
- **Số liệu cấu trúc NST theo SGK:** SGK tr. 36–37 (Hình 7.1) chỉ dùng 2 nm (DNA), 10 nm (chuỗi nucleosome / sợi nhiễm sắc) và 700 nm (chromatid kì giữa), không có sợi 30/300 nm. Người soạn ghi đúng. Phần 146 cặp nucleotide, 8 histone, H1 nằm trong [!em-co-biet]. Riêng mục Kiến thức cốt lõi tr. 39 của SGK in nhầm "700 mm"; bài ghi đúng 700 nm.
- **Thuật ngữ:** dị nhiễm sắc, nguyên nhiễm sắc, condensin I/II, khung NST, locus, chromatid đều đúng như SGK.
- **Bài 10:** Bảng 10.1 (XX–XY, ZZ–ZW, XX–XO), ong/kiến, rùa/cá sấu, *Aedes aegypti*, PAR1/PAR2/SRY, thí nghiệm Morgan 1910 (hình 10.2: thuận/nghịch), còi xương giảm phosphate (trội trên X), túm lông vành tai (Y), tằm và muỗi, bất hoạt X: đều khớp SGK.
  - Nội dung ruồi XXY/XO nằm trong [!em-co-biet].
  - Klinefelter/Turner thuộc chương trình (Bài 12–13) và dùng đúng yêu cầu "phát hiện bệnh do rối loạn phân li NST giới tính".
- **Bài 11:**
  - Thí nghiệm liên kết (♂ F~1~ lai phân tích → 1 : 1) và hoán vị (♀ F~1~ → 41,5/41,5/8,5/8,5) khớp Hình 11.1–11.2.
  - Hình 11.3 (34% tế bào trao đổi chéo → f = 17%) được dùng đúng.
  - Bản đồ liên kết và bản đồ vật lí, quan điểm Mendel–Morgan: đủ.
  - Bateson 1905, Sturtevant 1913, Nobel 1933: đúng.
- **Ví dụ trong bai.md:**
  - b07: 3870 cặp / 1,32 µm / 179 histone; 1,5·10^8^; 8 500 lần; 630; 2^23^ ≈ 8,4 triệu.
  - b10: ¾; 3/16; 1/8; 5/8; gà Z^b^Z^b^ × Z^B^W.
  - b11: 12%; 18,4%; 7,5%; 70/5/5/20; f = 40% và 54%; P–Q–R–S.

  Tất cả đều đúng.
- **Hình:** đã xem 10 SVG.
  - b07: hình thái và 3 dạng tâm động; các mức xoắn; locus với chromatid chị em mang allele giống nhau.
  - b10: X/Y với PAR và SRY ở Yp; sơ đồ 1 : 1; Punnett thuận/nghịch tô đúng màu; di truyền chéo/thẳng.
  - b11: liên kết hoàn toàn; trao đổi chéo giữa chromatid 2–3 cho AB, Ab, aB, ab; bản đồ A–B–C.

  Tất cả đúng khoa học. Sau khi sửa mục 3 ở phần 2 thì không còn chữ chồng.
- **Bản quyền:** không phát hiện câu, ví dụ hay bài tập chép nguyên văn SGK. Ví dụ đều tự đặt số liệu; bài luyện tập 721/751/49/45 của SGK không bị chép lại.

## 4. Góp ý chưa sửa
- b11/bai.md dùng `=> F~a~: …` (cú pháp dòng phương trình của Hóa). App hiển thị thành khung "eq" có font serif. Dòng vẫn đọc được, nhưng nên đổi thành đoạn in đậm thường khi biên tập chung.
- Đơn vị cM không có trong SGK KNTT, nhưng đề thi dùng phổ biến và bài đã giải thích. Chấp nhận được.
- "Số nhóm gene liên kết = n" là cách nói chuẩn của đề thi. Nếu muốn chặt chẽ, có thể thêm một dòng [!em-co-biet]: ở giới XY, X và Y là hai nhóm khác nhau.
- Một số câu tính toán chưa có cụm "Theo lí thuyết," (b07 q19, q26; b11 q22, q24). Nên thống nhất khi biên tập toàn bộ ngân hàng câu hỏi.
- File quiz.json của b10 và b11 đã được ghi lại bằng `json.dump(indent=2)`, nên định dạng xuống dòng thay đổi; nội dung chỉ đổi ở các câu nêu trên.
