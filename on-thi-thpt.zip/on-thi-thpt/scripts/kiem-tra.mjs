// Kiểm tra nội dung trước khi đưa lên GitHub:   node scripts/kiem-tra.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errs = [], warns = [];
// Công thức KaTeX phải dịch được (cùng quy tắc tách $…$ / $$…$$ như js/content.js)
const katex = createRequire(import.meta.url)(path.join(root, 'vendor/katex/katex.min.js'));
const MATH_RE = /\$\$([\s\S]+?)\$\$|(?<![\\\w$])\$(?=\S)((?:\\\$|[^$\n])+?)(?<=\S)\$(?![\w$])/g;
function checkMath(text, where) {
  for (const m of String(text || '').matchAll(MATH_RE)) {
    const tex = m[1] ?? m[2];
    try { katex.renderToString(tex, { displayMode: m[1] != null, throwOnError: true, strict: 'ignore' }); }
    catch (e) { errs.push(`${where}: công thức lỗi «${tex.slice(0, 60)}» — ${e.message.split('\n')[0].slice(0, 100)}`); }
  }
}
let nLessons = 0, nQ = 0;
const cat = JSON.parse(fs.readFileSync(path.join(root, 'content/catalog.json'), 'utf8'));
for (const y of cat.years) for (const s of y.subjects) {
  const ids = new Set();
  for (const part of s.parts || []) for (const l of part.lessons) {
    const where = `${y.id}/${s.id}/${l.id}`;
    if (ids.has(l.id)) errs.push(`${where}: trùng mã bài`); ids.add(l.id);
    if (/[\/#?%\s]/.test(l.id)) errs.push(`${where}: mã bài không được chứa / # ? % hoặc khoảng trắng`);
    const dir = path.join(root, 'content', y.id, s.id, l.id);
    const hasDir = fs.existsSync(path.join(dir, 'bai.md'));
    if (l.ready && !hasDir) { errs.push(`${where}: đánh dấu "ready" nhưng thiếu bai.md`); continue; }
    if (!l.ready && hasDir) warns.push(`${where}: đã có bai.md nhưng chưa đánh dấu "ready": true`);
    if (!l.ready) continue;
    nLessons++;
    const md = fs.readFileSync(path.join(dir, 'bai.md'), 'utf8');
    checkMath(md.replace(/```[\s\S]*?```/g, ''), `${where}/bai.md`);
    for (const m of md.matchAll(/!\[[^\]]*\]\(([^)\s]+)\)/g))
      if (!/^https?:/.test(m[1]) && !fs.existsSync(path.join(dir, m[1]))) errs.push(`${where}: thiếu hình ${m[1]}`);
    // SVG phải là XML hợp lệ: ký tự < & trong chữ phải viết &lt; &amp;
    for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.svg'))) {
      const svg = fs.readFileSync(path.join(dir, f), 'utf8');
      if (!/<svg[\s>]/.test(svg) || !/<\/svg>\s*$/.test(svg)) errs.push(`${where}/${f}: không phải SVG hoàn chỉnh`);
      if (/<(?![a-zA-Z\/!?])/.test(svg)) errs.push(`${where}/${f}: có ký tự "<" chưa viết thành &lt;`);
      // thẻ mở/đóng phải khớp nhau
      const stack = []; let bad = '';
      for (const t of svg.replace(/<!--[\s\S]*?-->/g, '').matchAll(/<(\/?)([a-zA-Z][\w:.-]*)[^>]*?(\/?)>/g)) {
        if (t[3]) continue;
        if (!t[1]) stack.push(t[2]);
        else if (stack.pop() !== t[2]) { bad = t[2]; break; }
      }
      if (bad || stack.length) errs.push(`${where}/${f}: thẻ SVG không khớp (${bad || stack.join(',')})`);
      if (/&(?![a-zA-Z]+;|#\d+;|#x[0-9a-fA-F]+;)/.test(svg)) errs.push(`${where}/${f}: có ký tự "&" chưa viết thành &amp;`);
    }
    const qf = path.join(dir, 'quiz.json');
    if (!fs.existsSync(qf)) { warns.push(`${where}: chưa có quiz.json`); continue; }
    let quiz; try { quiz = JSON.parse(fs.readFileSync(qf, 'utf8')); } catch (e) { errs.push(`${where}/quiz.json: lỗi JSON — ${e.message}`); continue; }
    const qids = new Set();
    for (const q of quiz.questions || []) {
      nQ++;
      const w = `${where}#${q.id}`;
      if (!q.id) errs.push(`${where}: câu hỏi thiếu id`);
      else if (/[\/#?%\s]/.test(q.id)) errs.push(`${w}: id không được chứa / # ? % hoặc khoảng trắng`);
      if (qids.has(q.id)) errs.push(`${w}: trùng id`); qids.add(q.id);
      if (!q.q) errs.push(`${w}: thiếu nội dung câu hỏi (q)`);
      if (q.type === 'mcq') {
        if (!Array.isArray(q.options) || q.options.length < 2) errs.push(`${w}: cần ≥ 2 lựa chọn`);
        else if (!Number.isInteger(q.answer) || q.answer < 0 || q.answer >= q.options.length) errs.push(`${w}: "answer" phải là số thứ tự (0 = A) trong phạm vi`);
      } else if (q.type === 'multi') {
        if (!Array.isArray(q.options) || q.options.length < 2) errs.push(`${w}: cần ≥ 2 lựa chọn`);
        else if (!Array.isArray(q.answer) || !q.answer.length || q.answer.some(a => !Number.isInteger(a)) || q.answer.some(a => a < 0 || a >= q.options.length)) errs.push(`${w}: "answer" phải là mảng chỉ số hợp lệ`);
      } else if (q.type === 'tf') {
        if (!Array.isArray(q.statements) || !q.statements.length) errs.push(`${w}: thiếu "statements"`);
        else q.statements.forEach((st, k) => { if (typeof st.a !== 'boolean') errs.push(`${w}: ý ${k + 1} thiếu "a": true/false`); });
      } else if (q.type === 'short') {
        // đáp số dạng chuỗi "1,5" (tối đa 4 ký tự như đề thi: dấu trừ, dấu phẩy đều tính)
        const a = String(q.answer ?? '');
        if (!/^-?\d+(,\d+)?$/.test(a)) errs.push(`${w}: "answer" của câu trả lời ngắn phải là số dạng "12" hoặc "-1,5"`);
        else if (a.length > 4) warns.push(`${w}: đáp số dài hơn 4 ký tự (đề thi chỉ cho tối đa 4 ký tự)`);
      } else errs.push(`${w}: "type" phải là mcq | multi | tf | short`);
      // công thức KaTeX: $ phải đi thành cặp
      checkMath([q.q, q.explain, ...(q.options || []), ...((q.statements || []).flatMap(st => [st.s, st.why]))].filter(Boolean).join('\n'), w);
      const allTxt = [q.q, q.explain, ...(q.options || []), ...((q.statements || []).flatMap(st => [st.s, st.why]))].filter(Boolean).join(' ');
      if (((allTxt.replace(/\\\$/g, '').match(/\$/g) || []).length) % 2) errs.push(`${w}: số dấu $ lẻ (công thức chưa đóng)`);
      if (!q.explain) warns.push(`${w}: nên có lời giải thích (explain)`);
    }
  }
}
warns.forEach(m => console.log('⚠ ', m));
errs.forEach(m => console.log('✗ ', m));
console.log(`\n${nLessons} bài có nội dung, ${nQ} câu hỏi. ${errs.length} lỗi, ${warns.length} cảnh báo.`);
process.exit(errs.length ? 1 : 0);
