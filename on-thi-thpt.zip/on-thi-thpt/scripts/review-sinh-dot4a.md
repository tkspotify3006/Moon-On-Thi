# Biên bản thẩm định — Sinh 12, Bài 2, Bài 3 (đợt 4a)

Ngày: 2026-10-24 · Người thẩm định: Claude (độc lập với người soạn)
Đối chiếu: SGK Sinh học 12 KNTT. PDF tr. 11–19 là sách tr. 9–17 (Bài 2), PDF tr. 20–24 là sách tr. 18–22 (Bài 3).
Script giải lại: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-sinh-4a/kt.py`. Script gồm:
- bảng mã di truyền chuẩn (64 codon), dùng để kiểm bảng mã trong bai.md theo từng ô;
- các hàm mạch khuôn → mRNA → chuỗi amino acid và anticodon, phiên mã ngược;
- công thức đếm codon, amino acid, liên kết peptide và tỉ lệ bộ ba (dùng phân số);
- mô hình logic operon *lac* (bình thường, *lacI*⁻, promoter *lacI* hỏng, *lacI*^s^, O hỏng, P hỏng, *lacZ*, *lacA*) × (có/không lactose);
- kiểm độ dài phương án mcq và cách gọi phương án A/B/C/D.

Kết quả `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**. Có một dòng cảnh báo KaTeX về chữ 'ậ', nhưng nó đến từ `toan/b05`, không phải hai bài này.
App (390×844, `python3 -m http.server 8853`):
- 0 katex-error, console sạch, không cuộn ngang trang;
- 7 hình hiển thị; số khung bấm-để-mở là 33 (b02) và 27 (b03);
- quiz hiển thị đúng.

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b02 | 28 (15 mcq · 5 tf · 8 short) | 0 | q12: 5'-AUG CAU GGC-3'. q13: 3'-CGU-5'. q14: mRNA 5'-AUG AAA UGG GAC UAA-3' → Met–Lys–Trp–Asp. Hai nhiễu đều đúng là lỗi điển hình: đọc khuôn như mRNA cho Tyr–Phe–Thr–Leu–Ile, đọc mRNA theo chiều 3'→5' cho Asn–Gln–Gly–Lys–Val. q19: 299 · 1794 · 1788. q20.4: 5'-TGCCAT-3'. q21–q28: 61 · 247 · 449 · 500 · 160 · 379 · 24 · 14,4. Mỗi exon của q26 đều chia hết cho 3. Vị trí đáp án 4/4/4/3. |
| b03 | 28 (15 mcq · 5 tf · 8 short) | 0 | Mô hình logic cho q10, q11, q13, q14, q18, q19 khớp đáp án. q23: 24. q24: 3 (các trường hợp 1, 2, 5). q25: 60. q26: 612 cặp → 203 aa × 20 = 4060. q27: 3 (các trường hợp 1, 4, 5). q28: 3. Vị trí đáp án 4/4/3/4. |

- Câu short có đáp số ≤ 4 ký tự. Không câu nào gọi phương án bằng A/B/C/D.
- Không câu nào trùng số liệu với ví dụ:
  - q12, q14 khác Ví dụ 3, 7 (nay là 2, 6).
  - q26 khác Ví dụ gene phân mảnh.
  - q27 dùng A, U, G; ví dụ dùng A, U, C.
  - b03 q23 khác Ví dụ 2: q23 dùng *lacZ* 12/*lacI* 5, ví dụ dùng *lacY* 15/*lacI* 4.
  - b03 q26 (*lacA*) khác Ví dụ 9 (*lacY*).
- Đề operon đủ dữ kiện: luôn nói có/không lactose và vị trí đột biến, và có giả thiết "mỗi chủng một đột biến". Đề dịch mã có bảng mã rút gọn chứa đủ codon cho cả đáp án lẫn nhiễu.

## 2. Lỗi đã sửa

### Nghiêm trọng (1)
1. **b03 quiz q13: có thể có hai đáp án bảo vệ được.**
   - Phương án nhiễu cũ là "Gene *lacY* đột biến làm thay đổi một amino acid của permease". Thực tế, permease hỏng thì lactose không vào được tế bào, nên operon không được cảm ứng. Học sinh giỏi có thể chọn phương án này.
   - Explain cũ phải rào đón "theo cách xét của chương trình".
   - Đã đổi phương án nhiễu thành "*lacA* đột biến làm transacetylase mất hoạt tính" (không ảnh hưởng phiên mã) và viết lại explain. Đã cân lại độ dài các phương án vì đáp án đúng trước đây dài nhất rõ rệt.

### Lỗi nhỏ (11)
2. **b02/bai.md: bảng mã di truyền bị ngắt dòng lệch trên màn 390px.** Ô "Ile Ile Ile Met" xuống dòng thành 3 + 1, trong khi các ô khác ngắt 2 + 2, nên dễ đọc nhầm vị trí nucleotide thứ ba. Đã nối từng cặp bằng dấu cách không ngắt (NBSP). Nay mọi ô hiển thị đều 2 dòng: dòng trên ứng với U, C; dòng dưới ứng với A, G. Bảng rộng 358px, vừa khung. Đã kiểm lại toàn bộ 64 ô bằng script, đều đúng.
3. **Đáp án đúng dài nhất rõ rệt ở b02 q15 và b03 q08.** b02 q15 dài 110 ký tự, các phương án khác khoảng 72. Đã cân lại độ dài các phương án.
4. **b02 q23:** đã thêm "kể cả bộ ba kết thúc" vào đề cho chặt dữ kiện.
5. **b02 q06 explain:** câu cũ "DNA không ra khỏi nhân" sai với vi khuẩn. Đã sửa thành "DNA là khuôn của phiên mã, không trực tiếp tham gia dịch mã".
6. **b02 q08 explain:** đã thêm "(SGK gọi là mã vạn năng)" để khớp thuật ngữ SGK tr. 14.
7. **b02/bai.md mục 2.1:** câu cũ "phần DNA ngoài gene lớn hơn rất nhiều" không có căn cứ. Đã thay bằng lập luận dựa trên số liệu SGK: exon, intron và vùng điều hoà cộng lại khoảng một phần tư hệ gene.
8. **b03/bai.md mục 1.2 "các cấp độ điều hoà":** SGK KNTT không có nội dung này.
   - Đã ghi "(mở rộng ngoài SGK)" ngay ở tiêu đề mục, không chỉ trong khung bẫy.
   - Quiz q07 (nhân sơ điều hoà chủ yếu ở cấp phiên mã) dựa vào phần này, nên explain có thêm ghi chú "mở rộng ngoài SGK".
9. **b03/bai.md:** đã sửa ba chỗ.
   - "khoảng 20 000 gene" → "khoảng 21 300 gene (Bài 2)", cho khớp số liệu SGK tr. 10.
   - "transacetylase … khử các chất độc vào tế bào" (câu chép sát SGK, tối nghĩa) → "tham gia khử độc cho tế bào".
   - Bỏ cụm "(di truyền ngoài gene)", vì dễ nhầm với di truyền ngoài nhân. Giữ đúng thuật ngữ SGK "di truyền biểu sinh".
10. **b03/hinh-2-khong-lactose.svg:** chữ "polymerase" chạm viền elip. Đã nới elip (rx 42 → 48) và chỉnh mũi tên.
11. **b03/hinh-3-co-lactose.svg:** nhãn cũ "lactose" ở phân tử bám protein ức chế. SGK ghi rõ chất bám vào protein ức chế là **đồng phân** của lactose, nên đã thêm dòng "(đồng phân)". Đã chụp lại hình và không có chữ chồng.
12. **b02/bai.md quá dài (~8 600 từ):** đã rút những đoạn trùng lặp, không cắt nội dung SGK.
    - Ví dụ 2 (tính 48 triệu cặp exon) gộp thành một đoạn "Nhận xét từ bảng" 3 câu. Các ví dụ sau đã đánh số lại và sửa chỗ dẫn chéo "Dạng 2, Ví dụ 8".
    - Bỏ "Công thức nhanh" ở cuối bài, vì trùng khung công thức ở Dạng bài và bảng "Đếm trong dịch mã". Thay bằng một dòng dẫn tới hai chỗ đó.
    - Bỏ dòng "Đơn phân lắp vào" trong bảng so sánh tái bản – phiên mã, vì trùng bảng mục 3.6.
    - Kết quả: còn khoảng 8 400 từ (wc). Bài vẫn dài nhất chương vì SGK có 9 yêu cầu cần đạt (gene, hệ gene, RNA, phiên mã ngược, mã di truyền, dịch mã, sơ đồ). Phần còn lại không lặp đáng kể nên không cắt thêm.

## 3. Đã kiểm, không cần sửa
- **Chiều mạch khuôn và vùng điều hoà.** SGK tr. 9 ghi vùng điều hoà ở đầu 3', vùng kết thúc ở đầu 5' của mạch khuôn. bai.md, quiz q02 và Hình 1 đều đúng như vậy. Khung [!bay] có nhắc "nếu nhìn theo mạch mã hoá thì ngược lại".
- **Vị trí E – P – A.** SGK có nội dung này (tr. 15, Hình 2.6–2.7: tRNA đi A → P → E, ribosome dịch 5'→3'), nên không phải mở rộng. Hình 3 (b02) đúng ở các điểm:
  - codon AUG/UUU/GGC lần lượt dưới E/P/A;
  - anticodon 3'-UAC/AAA/CCG-5' bổ sung đúng;
  - chuỗi Met–Phe ở P, liên kết peptide hình thành với Gly ở A;
  - mRNA 5' ở bên trái.
- **Các hình còn lại của b02:**
  - Hình 2 (phiên mã): mạch khuôn 3' bên trái; RNA 5' ở phía sau, 3' ở RNA polymerase; RNA polymerase đi từ promoter về vùng kết thúc. Hoàn thiện mRNA có mũ G ở 5', poly A ở 3', cắt intron.
  - Hình 1: nhân sơ có chung vùng điều hoà, vùng kết thúc; nhân thực có exon/intron.
  - Hình 4: phiên mã ngược vẽ nét đứt.
- **Operon *lac*.** Thuật ngữ khớp SGK tr. 19 ở các điểm:
  - promoter/vùng khởi động P, operator/vùng vận hành O, *lacZ/lacY/lacA*;
  - gene điều hoà *lacI* "không thuộc operon *lac*";
  - protein ức chế lacI (không in nghiêng);
  - "đồng phân của lactose";
  - "RNA polymerase không thể liên kết được với promoter".

  Hình 2 và Hình 3 (b03) đúng thứ tự *lacI* … P – O – Z – Y – A. Có một mRNA chung, protein ức chế bám O.
- **Số liệu SGK đã kiểm.**
  - Bài 2: 3,2 tỉ cặp, 2004, 99,999%, 21 300 gene, 1,5% / 5% / 20%, 27 000 cặp/10 exon; tRNA tối thiểu 20, thường 30–40; rRNA 3 loại/1 gene (nhân sơ), 4 loại/2 gene (nhân thực); ngoại lệ ti thể (UGA – Trp, AUA – Met, AGA/AGG kết thúc).
  - Bài 3: E. coli dùng 90% ATP cho tổng hợp protein; tamoxifen – ERα; cá rô phi xử lí testosterone; chiếu sáng cho cây ra hoa (trồng trọt); lùn bẩm sinh; tế bào gốc; Em có biết về methyl hoá.
- **Ví dụ trong bai.md.** Đã giải lại tất cả và đều đúng:
  - b02 (tính số): 5'-AUG CCU AAG UGA-3'; 5'-TGAATC-3'; Met–Ala–Phe–Ser; Met–Phe–Gly–Lys với 3 liên kết; Met–Val–Gln–Ala, anticodon 3'-GUU-5'.
  - b02 (đếm): 1440 nucleotide → 900/1260/1080/1080, 2395, 478; 2200/900, 298; 27/26; 38,4% và 12,8%.
  - b03: 15/15 lần; 18 chuỗi × 417 = 7506.
  - Phần trả lời Luyện tập SGK tr. 17 và tr. 22 viết bằng lời của người soạn và đúng.
- **Bản quyền.** Không có đoạn chép nguyên văn. Chỉ có câu transacetylase sát SGK, đã sửa ở lỗi 9. Bảng mã di truyền là dữ kiện khoa học, trình bày lại theo dạng riêng.

## 4. Góp ý chưa sửa
- b02 Hình 2: đoạn RNA mới rời bong bóng phiên mã cắt ngang nét mạch khuôn. Không sai kiến thức, nhưng nếu vẽ lại nên cho RNA thoát ra phía dưới mà không cắt nét.
- Các hình rộng (ví dụ b02 Hình 3) trên màn 390px phải vuốt ngang để xem hết hình. App có dòng nhắc "vuốt ngang", giống các bài khác.
- b03 q12 và q28(4) cùng hỏi về tamoxifen. Chấp nhận được vì một câu hỏi nguyên lí, một câu đếm phát biểu.
- b02 q22 (248 → 247) rất dễ. Có thể nâng thành câu hỏi số liên kết peptide hình thành khi tổng hợp chuỗi chưa cắt Met.
