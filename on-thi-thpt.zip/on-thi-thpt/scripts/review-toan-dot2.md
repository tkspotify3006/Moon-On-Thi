# Biên bản thẩm định — Toán 12 đợt 2 (b06, b09, b10)

Ngày: 2026-10-24 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/b06` (Bài 6 Vectơ trong không gian, SGK tr. 45–59 = PDF 46–60), `b09` (Bài 9 Khoảng biến thiên và khoảng tứ phân vị, tr. 75–79 = PDF 76–80), `b10` (Bài 10 Phương sai và độ lệch chuẩn, tr. 80–84 = PDF 81–85).

## 1. Cách kiểm
- Đọc lại từng trang SGK của 3 bài, đối chiếu định nghĩa, kí hiệu, số trang ghi `(SGK tr. X)`.
- **Bài 9:** công thức SGK tr. 77: $Q_r=a_p+\dfrac{\frac{rn}{4}-(m_1+\dots+m_{p-1})}{m_p}(a_{p+1}-a_p)$, $[a_p;a_{p+1})$ là nhóm chứa $Q_r$; $R=a_{k+1}-a_1$ với $m_1,m_k>0$. Viết lại hàm tính bằng `Fraction` theo đúng công thức này, chạy lại SGK Ví dụ 2 (ra 7,71; 14,5; 6,79 như sách), sau đó tính lại mọi ví dụ và câu hỏi. Cách chọn nhóm "nhóm đầu tiên có tần số tích lũy $\ge rn/4$" trong bài cho cùng nhóm với cách của SGK (chỉ ra vị trí $x_{10}$ khi $n=38$). Trường hợp tần số tích lũy đúng bằng $rn/4$ cũng không sai, vì hai nhóm kề nhau cho cùng một giá trị.
- Giải lại **toàn bộ 84 câu** (mỗi bài 15 mcq + 5 tf + 8 short, riêng b09: 15/5/8) và mọi ví dụ trong 3 bai.md bằng python (numpy/Fraction; b06 dùng tọa độ tứ diện đều, lập phương). Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-2/` (`b06.py`, `b09.py`, `b10.py`, `b10q.py`, `new.py`).
- Kiểm thêm: mcq chỉ có 1 phương án đúng; phương án nhiễu khớp đúng lỗi mà explain nêu (ví dụ b09 q09: 6,22 / 6,27 / 9,78; b10 q09: $s_x$ = 9,40); short không quá 4 ký tự và có ghi làm tròn; explain không gọi phương án bằng A/B/C/D; vị trí đáp án mcq phân bố đều (b06 4/4/4/3, b09 4/3/4/4, b10 3/4/4/4).
- Render 10 hình SVG bằng Playwright ở nền sáng và tối, tự xem ảnh. Mở 3 bài và 3 quiz trong app (390×844): không lỗi console, không `.katex-error`, bảng Markdown trong đề hiển thị đúng.
- `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**.

## 2. Kết quả quiz
**Không có đáp án nào sai.** 84/84 đáp án đúng. Mỗi mcq chỉ có một phương án bảo vệ được và phương án nhiễu hợp lý. Ý "làm tròn" của các câu short đều đúng (b09 q25 8,142 → 8,14; q27 26,43 → 26,4; q28 0,764 → 0,76; b10 q23 50,04 → 50; q24 1,339 → 1,34; q26 2,086 → 2,09; q28 3,184 → 3,18).

## 3. Lỗi đã sửa

### Quiz
| Câu | Lỗi | Sửa |
|---|---|---|
| b09 (19 câu có bảng) | Bảng viết bằng KaTeX `array` nằm trong `$$` (khó đọc trên điện thoại, cột "Nhóm/Tần số" không có tên đại lượng). | Chuyển sang **bảng Markdown dọc** (cột nhóm, cột tần số), tiêu đề cột có tên đại lượng và đơn vị ("Thời gian chờ (phút) \| Số khách"…). |
| b09 q22, q24, q25 | **Lộ đáp án:** dùng cùng bảng với q14, q19, q16, mà explain (hoặc lời giải từng ý tf) của các câu này đã ghi sẵn $Q_1\approx5{,}71$, $\Delta_Q\approx18{,}92$, $\Delta_Q\approx8{,}14$, tức đúng đáp số của câu short. | Đổi số liệu mới (giữ id, dạng, mức độ): q22 $n=36$, $Q_1=\frac{52}{9}\approx5{,}78$; q24 $n=48$, $\Delta_Q=\frac{305}{18}\approx16{,}9$; q25 $n=45$ (vị trí lẻ 11,25 và 33,75), $\Delta_Q\approx9{,}03$. Đã kiểm bằng python. |
| b10 q27 | **Lộ đáp án:** cùng bảng với nhà đầu tư lớn ở q19, mà lời giải q19 đã ghi $CV_2\approx15{,}9\%$. | Bảng mới $[20;70)$, tần số $3;7;10;7;3$: $\bar x=45$, $s\approx11{,}25$, $CV\approx25\%$. |
| b10 (17 bảng) | Bảng ngang 6 cột bị xuống dòng giữa đầu mút ("[20;⏎30)") ở màn 390 px. | Xoay thành bảng dọc; rút gọn tiêu đề cột của q14 và q17. |

### bai.md
| Bài / mục | Lỗi | Sửa |
|---|---|---|
| b06 `[!ung-dung]` Lực và phản lực | Câu tự mâu thuẫn: "vận tốc hai làn thang cuốn là hai vectơ cùng độ dài, ngược hướng — nhưng chỉ đối nhau khi hai làn song song" (đã "ngược hướng" thì giá phải song song). | Viết lại: hai làn song song, cùng tốc độ thì vận tốc là hai vectơ đối nhau; hai làn không song song hoặc khác tốc độ thì không đối nhau. |
| b10 `[!meo]` Bấm máy | Khẳng định chắc chắn chuỗi phím (SHIFT → MENU → ▼ …, MENU → 6 → 1), có thể không đúng trên mọi máy hoặc mọi phiên bản. | Viết dạng chung: bật cột tần số trong SETUP, vào thống kê một biến, nhập giá trị đại diện và tần số, đọc trong mục tính toán một biến (thường ở OPTN). Ghi rõ tên mục khác nhau tùy máy và nên thử với Ví dụ 1. Giữ phần "$\sigma_x$ (chia $n$) chứ không phải $s_x$". |
| b09 `[!nen-tang]` Giá trị ngoại lệ | `\text{hoặc}` trong KaTeX: font KaTeX không có chữ "ặ" (kiem-tra báo "No character metrics"). | Tách thành hai công thức, chữ "hoặc" để ngoài công thức. |

### Hình SVG
| File | Lỗi | Sửa |
|---|---|---|
| b06/h4-den-treo.svg | Chữ "α" nằm đúng trên dây $SD$; chữ "S" bị dây $SC$ cắt. | Dời "α" vào giữa $SA$ và $SD$; dời "S" lên trên thanh trần. |
| b09/h1-khoang-bien-thien.svg | Nhãn "3 cây" căn phải, "8 cây" căn trái nên đứng sát nhau ở ranh giới 15, dễ đọc nhầm nhóm; "4 cây" chạm đường đứt "max". | Căn giữa từng nhãn trong nhóm của nó; dời nhãn "4 cây" sang trái. |
| b09/h3-gia-tri-bat-thuong.svg | Điểm "290 phút" vẽ ở vị trí 285 trên trục. | Đặt đúng tọa độ 290. |
| b10/h3-dau-tu.svg | Ô tô màu "vùng lỗ" phủ lên tiêu đề "Phương án P/Q", nhãn "vùng lỗ" sát mép trên. | Ô tô bắt đầu dưới tiêu đề; nhãn đặt trong vùng tô. |

Các hình còn lại đều đúng: b06 h1–h3 có cạnh bên song song và bằng nhau, $G$ ở 2/3 trung tuyến, $I$ ở 3/4 $AG$; b09 h2 có đường tần số tích lũy đúng, $Q_1=48$, $Q_3=97{,}5$; b10 h1–h3 có $\bar x\pm s$ đúng thang đo. Không có chữ chồng chữ.

**Tổng:** 0 lỗi sai đáp án hay sai kiến thức toán. 4 lỗi đáng kể (4 câu short lộ đáp án qua lời giải của câu khác). 8 lỗi nhỏ (1 diễn đạt mâu thuẫn, 1 mẹo Casio khẳng định chắc tên phím, 1 lỗi hiển thị KaTeX, 4 hình chữ chồng hoặc lệch vị trí, 1 điểm vẽ sai tọa độ) và cải tiến hiển thị bảng (36 bảng trong quiz b09 và b10).

## 4. Nội dung và bản quyền
- Đủ nội dung SGK: b06 có định nghĩa, cùng phương/hướng, bằng nhau, vectơ-không, tổng (ba điểm, hình bình hành, hình hộp), hiệu, tích với số, trọng tâm tứ diện, góc, tích vô hướng, công của lực. b09 có $R$, $Q_r$, $\Delta_Q$, ý nghĩa, nhận xét về giá trị bất thường. b10 có $s^2$ (hai dạng), $s$, $\hat s$ (chia $n-1$), ý nghĩa, đo rủi ro, nhận xét khi trung bình chênh lệch, CV.
- Không phát hiện chép nguyên văn. Các ví dụ cùng dạng SGK đã đổi số liệu hoặc đối tượng (thang máy tầng 3–9–15 so với SGK 15–22–29; lực cản ô tô 60→90 km/h so với SGK máy bay 900→920; tứ diện đều cạnh 6 cm so với rubik cao 8 cm; nhiệt kế 25 lần đo so với máy đo độ ẩm 20 lần; hai phương án P, Q so với lĩnh vực A, B).
- Kí hiệu đúng SGK: $\Delta_Q$, $Q_r$, $a_p$, $m_p$, $s^2$, $s$, $\hat s$, $(\vec a,\vec b)$.

## 5. Góp ý chưa sửa (không phải lỗi)
1. b06 chưa nhắc hai chú ý nhỏ của SGK: "$k\vec a=\vec0\Rightarrow k=0$ hoặc $\vec a=\vec0$" (tr. 53) và "góc giữa một vectơ bất kì và $\vec0$ nhận giá trị tùy ý" (tr. 55). Có thể thêm một dòng vào khung Chú ý.
2. b06 q16 và Ví dụ 13 trong bài khá giống nhau (cùng dạng Đúng/Sai trên hình hộp). Có thể thay một ý của q16 bằng ý về góc hoặc tích vô hướng.
3. b09 q14 và q27 vẫn dùng chung một bảng (q14 nêu $Q_1$, $Q_3$ trong explain). q27 còn phải tính ngưỡng $Q_3+1{,}5\Delta_Q$ nên chưa lộ hẳn đáp số. Nếu muốn chặt chẽ thì đổi bảng q27.
4. Bảng trong bai.md (b09, b10) vẫn là bảng ngang 6–7 cột. Trên điện thoại, bảng có thanh cuộn ngang nên vẫn đọc được; chưa đổi để giữ dáng giống SGK.
