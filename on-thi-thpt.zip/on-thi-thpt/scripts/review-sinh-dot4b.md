# Biên bản thẩm định — Sinh 12, Bài 4 và Bài 5 (kèm Bài 6 thực hành) (đợt 4b)

Ngày: 2026-10-24 · Người thẩm định: Claude (độc lập với người soạn)
Đối chiếu: SGK Sinh học 12 KNTT, PDF tr. 25–28 (sách tr. 23–26, Bài 4), PDF tr. 29–33 (sách tr. 27–31, Bài 5), PDF tr. 34–36 (sách tr. 32–34, Bài 6). PDF tr. 37 là Sơ đồ tóm tắt chương 1.
Script giải lại: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-sinh-4b/kt.py`. Script làm các việc sau:
- tính A, G, N, H, L cho mọi câu đột biến điểm;
- dịch mRNA bằng bảng mã cho trong đề;
- mô phỏng từng mạch DNA qua các lần tái bản có 5-BU;
- dò trình tự nhận biết trên cả hai mạch và đếm số đoạn cắt.

Kết quả `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**.
App (390×844, `python3 -m http.server 8844`): không có katex-error, console sạch, hình hiển thị đủ.

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b04 | 28 (15 mcq · 5 tf · 8 short) | 0 | q14: Met – Leu – Ser – Leu – Asn. q17: G 600, H 3600, A của d = 901. q18: Met – Thr – Arg – Gly – Asp; CAG → UAG còn 2 amino acid. q20.3: 7/16. q21–q28: 1802 · 2881 · 399 · 2 · 15 · 5397 · 100 · 2. Vị trí đáp án 4/4/4/3. |
| b05 | 28 (15 mcq · 5 tf · 8 short) | 0 | q07: chỉ GGATCC đối xứng. q21: EcoRI 2, BamHI 2 → 5 đoạn (đã dò cả mạch bổ sung). q22: 3. q23: 320. q24: 1,904 → 1,9. q26: 3. q28: 409. q25, q27 đã đặt lại đề (mục 2). Vị trí đáp án 4/5/3/3. |

Ví dụ trong bai.md đều đúng:
- b04: VD1 2901 → A 699 / G 501; VD5 2883 / 4317; VD6 đủ 4 trường hợp; VD7 = 3.
- b05: VD2 3 / 4 đoạn; VD4 1/4 và 1/3; VD7 3 và 48.

Về 5-BU: mô phỏng cho 0, 1, 3, 7, 15, 31 gene đột biến với k = 2…7, khớp $2^{k-2}-1$. Công thức này chỉ đúng khi đủ các giả thiết: một 5-BU vào ở lần 1, sau đó không còn 5-BU, và 5-BU luôn bắt cặp với G. Ví dụ 7 và q25 đều đã nêu đủ giả thiết. Nếu 5-BU chỉ bắt cặp với G một lần thì đáp số là $2^{k-3}$.

Các yêu cầu khác: mỗi câu mcq chỉ có một phương án đúng; câu short có đáp số ≤ 4 ký tự; không câu nào gọi phương án bằng A/B/C/D.

## 2. Lỗi đã sửa

### Nghiêm trọng (2)
1. **b05 q27 trùng hoàn toàn Ví dụ 4** (T/– × T/–, đồng hợp 25%), nên đáp số đã in sẵn trong bài. Đã đặt lại đề, giữ `id`:
   - chọn ngẫu nhiên cừu F~1~ mang gene chuyển rồi cho giao phối;
   - tính TT ở F~2~ = (2/3)² = 4/9 → **44,4**;
   - nếu quên loại cừu –/– sẽ ra 25.
2. **b05 q25 lộ đáp số.** Dạng 2, bước 4 của bai.md ghi sẵn "gắn một đoạn vào plasmid mở 1 điểm → 4 liên kết", đúng là đáp số của q25. Đã đặt lại đề, giữ `id`:
   - plasmid có 2 vị trí EcoRI, nối thành vòng gồm 2 đoạn plasmid và 1 đoạn gene;
   - có 3 chỗ nối → **6** liên kết; level 3.

### Lỗi nhỏ (9)
3. **b04/bai.md: thêm khung [!bay] "Chất độc màu cam" trong SGK.** SGK tr. 24 viết "chất độc màu cam (acridine orange)", gộp lẫn hai thứ khác nhau:
   - acridine orange là thuốc nhuộm;
   - ở Việt Nam, "chất độc màu cam" thường là Agent Orange, có dioxin.

   Người soạn đã khéo léo tránh cụm từ này, nhưng học sinh sẽ gặp nó trong đề làm theo SGK, nên cần có khung giải thích. Mục cơ chế có thêm chú thích "(theo SGK)" cho dioxin là chất chèn.
4. **b04/bai.md: thêm khung [!bay] về giả thiết của công thức $2^{k-2}-1$.** Khung nói rõ các điều kiện của công thức và đáp số $2^{k-3}$ khi dùng giả thiết khác. Tiêu đề khung không chứa công thức, vì tiêu đề in hoa làm hỏng KaTeX (đã xem trong app).
5. **b04 Ví dụ 2:** câu cũ "codon thứ 6 của mRNA" là sai, vì nếu tính cả AUG thì đó là codon thứ 7. Đã sửa thành "codon quy định amino acid thứ 6 của chuỗi β-globin".
6. **b04 [!ung-dung] HbS – sốt rét:** nội dung đúng (người dị hợp HbS ít bị sốt rét ác tính). Đã ghi nhãn "Mở rộng (ngoài SGK)".
7. **b04 q15:** gene mắt trắng kinh điển ở ruồi giấm nằm trên NST X. Với gene liên kết X, học sinh giỏi có thể phân vân về kết quả lai. Đã thêm "gene nằm trên NST thường".
8. **b05 bảng thành tựu và khung [!ung-dung]:** đã thêm mốc Eli Lilly 1979 theo SGK. Kèm ghi chú: tư liệu khác ghi insulin tái tổ hợp được tạo năm 1978 và cấp phép năm 1982; khi thi thì dùng mốc của SGK.
9. **b05 cừu antithrombin:** đã thêm khung [!em-co-biet]. Khung ghi rõ thuốc antithrombin tái tổ hợp đầu tiên được cấp phép (EU 2006) thực tế lấy từ dê chuyển gene, nguyên lí giống ví dụ cừu trong SGK.
10. **b05 ngô biến đổi gene ở VN từ 2015:** thông tin đúng. Năm 2015 Bộ NN&PTNT công nhận các giống ngô biến đổi gene (kháng sâu, chịu thuốc trừ cỏ) và cho trồng thương mại. Đã ghi nhãn "Mở rộng (ngoài SGK)".
11. **b05 Dạng 3 (chọn dòng bằng amp^R^/tet^R^):**
    - đã thêm khung ghi rõ đây là mở rộng ngoài SGK 2018;
    - kiến thức đúng: chèn gene làm bất hoạt gene, rồi cấy chuyển;
    - đã viết lại câu "Nguyên lí" ở mục 1.3 vì câu cũ quá sát văn SGK tr. 27.

## 3. Đã kiểm, không cần sửa
- **FOXP2:** bai.md ghi "*FOXP2* (SGK ghi là *FOX2*)", khác 2/715 amino acid so với tinh tinh. Cách ghi này đúng thực tế và vẫn dẫn được về SGK.
- **Tên bài:** "Công nghệ gene" đúng SGK. Phần Kiến thức cốt lõi của SGK gọi là "công nghệ di truyền", và bai.md có nêu cả hai tên.
- **5-BU:** bai.md ghi A–5-BU → G–5-BU (tiền đột biến) → G–C qua 3 lần tái bản, khớp Hình 4.1 SGK (thế hệ 2 là tiền đột biến, thế hệ 3 là đột biến).
- **Hình b04** (đã xem bằng Playwright):
  - H1: thay C–G → T–A cho H − 1; thêm và mất G–C cho ±3, đúng.
  - H2: mất G của GAA → AAA GCU GGC = Lys – Ala – Gly; UGG → UGA, đúng.
  - H3: hai T kề nhau trên cùng mạch.
  - H4: cây tái bản 2 + 1 + 1 + 4 = 8 DNA ở lần 3.
- **Hình b05:**
  - H1: EcoRI cắt G^AATTC trên cả hai mạch, đúng chỗ. Cả hai đầu dính đều là 5'-AATT. Hai chỗ hở sau ghép nằm đúng vị trí ở hai mạch.
  - H2: thứ tự tách chiết → cắt → nối → chuyển → chọn dòng đúng.
  - H3: hai quy trình khớp SGK.
  - Không có chữ chồng chữ.
- **Bài 6:** ý nghĩa của nước lạnh, chất tẩy rửa, nước dứa (protease), cồn lạnh và diphenylamine đều khớp SGK tr. 32–34.
- **Bản quyền:** ví dụ đều tự đặt số liệu. Chỉ có một câu trích ngắn từ SGK, ghi rõ nguồn, dùng để giải thích tên "chất độc màu cam".

## 4. Góp ý chưa sửa
- SGK ghi tia UV gây thêm/mất cặp nucleotide. Thực tế dimer T–T chủ yếu gây thay thế (C→T). Bài đã bám SGK, nên giữ nguyên để tránh mâu thuẫn với đề.
- b04 q24 (G* cần 2 lần tái bản) lấy thẳng từ bảng Dạng 3. Câu này ở level 1 (nhớ), nên chấp nhận được.
- Một số đề tính toán chưa mở đầu bằng "Theo lí thuyết," (b04 q21–q23). Nên thống nhất khi biên tập chung.
