# Brief soạn bài — app "Ôn thi THPT" (Toán · Hóa · Sinh lớp 12)

Người học: **học sinh lớp 12** (thi tốt nghiệp THPT tháng 6/2027, xét tuyển khối B00; mục tiêu từ 8 điểm đến 9+ để vào Y Dược).
Học sinh **đang học trên lớp** theo SGK bộ **Kết nối tri thức với cuộc sống** — app phải **DẠY** được (tự học hiểu bài), rồi mới luyện.

## Đọc trước (bắt buộc)
- Quy ước nội dung & cú pháp: `/home/claude/on-thi-thpt/HUONG-DAN-NOI-DUNG.md`
- SGK (bản quét ẢNH, không có chữ — xem bằng Read tool, `pages="a-b"`, tối đa 20 trang/lần; đọc KỸ từng trang của bài được giao, kể cả hình và bài tập):
  - Toán 12 T1: `/home/claude/thpt/src/toan12-t1.pdf` (trang PDF = trang sách + 1)
  - Toán 12 T2: `/home/claude/thpt/src/toan12-t2.pdf` (trang PDF = trang sách + 1)
  - Hóa học 12: `/home/claude/thpt/src/hoa12.pdf` (trang PDF = trang sách + 2)
  - Sinh học 12: `/home/claude/thpt/src/sinh12.pdf` (trang PDF = trang sách + 2)

## Cấu trúc bai.md (giảng dạy thật, dễ hiểu)
```
---
title: <đúng tên bài trong SGK>
thoi-gian: <phút đọc>
muc-tieu:
  - <theo "Kiến thức, kĩ năng"/"Yêu cầu cần đạt" của SGK, diễn đạt lại>
---
> [!ghi-nho] Bài này trong 5 dòng
> …

## 1. … (theo đúng trình tự mục của SGK)
### 1.1 …
```
1. **Giảng từ trực quan → khái niệm → công thức**, giải thích **vì sao** (không chỉ đưa công thức). Câu ngắn, xưng "em"/"ta" thân thiện, như gia sư giỏi giảng cho học sinh trung bình–khá hiểu được.
2. **Ví dụ mẫu**: mỗi mục quan trọng ≥ 1 ví dụ, từ dễ đến khó. Mẫu bắt buộc:
   ```
   > [!vi-du] Ví dụ 1
   > Đề bài…

   > [!goi-y] Gợi ý 1
   > Nghĩ xem…

   > [!goi-y] Gợi ý 2
   > …

   > [!loi-giai] Lời giải
   > Bước 1… Bước 2… Kết luận…
   ```
   (Các khung cách nhau 1 dòng trống. `goi-y`, `loi-giai` hiển thị dạng bấm-để-mở → học sinh tự nghĩ trước.)
3. `[!nen-tang]` khi cần nhắc kiến thức lớp 10–11 (đạo hàm, vectơ phẳng, phân bào, liên kết hóa học…) — ngắn gọn, đủ để học tiếp.
4. `[!bay]` lỗi hay sai / bẫy trong đề. `[!meo]` mẹo làm nhanh, mẹo bấm máy tính cầm tay (Casio fx-580VN X) nếu thật sự hữu ích. `[!ung-dung]` ứng dụng thực tế. `[!em-co-biet]` mở rộng thú vị (ít).
5. **`## Dạng bài thi hay gặp`** (gần cuối): 2–4 dạng, mỗi dạng: *nhận biết*, *phương pháp* (các bước), 1 ví dụ có gợi ý + lời giải, *bẫy*. Bám định dạng đề tốt nghiệp từ 2025 (4 lựa chọn / Đúng–Sai 4 ý / trả lời ngắn).
6. `## Tóm tắt`: bảng công thức / sơ đồ ý chính.
7. **Bản quyền**: KHÔNG chép nguyên văn câu, ví dụ, bài tập của SGK. Viết lại bằng lời của mình; ví dụ tự đặt (có thể cùng dạng, khác số liệu). Ghi `(SGK tr. X)` khi muốn học sinh đối chiếu.
8. Thuật ngữ, kí hiệu, tên chất **theo đúng SGK GDPT 2018** (Hóa: tên IUPAC tiếng Anh như SGK — saccharose, maltose, glucose, amylose, amylopectin, cellulose…; Sinh: gene, allele, nhiễm sắc thể, kiểu gene, kiểu hình…; Toán: kí hiệu như SGK).

## Công thức & hình
- Toán/Lý–Hóa có công thức: KaTeX `$...$` trong dòng, `$$...$$` dòng riêng. Không đặt `|` trong công thức nằm trong bảng (dùng `\lvert x\rvert`). Vectơ: `\overrightarrow{AB}`, `\vec{a}`. Tọa độ: `A(1;2;3)` dùng dấu chấm phẩy như SGK.
- Hóa: công thức hóa học viết `C~12~H~22~O~11~`, ion `Cu^2+^` (KHÔNG bọc công thức hóa học trong `$`), mũi tên phản ứng `→`, dòng phương trình bắt đầu bằng `=> `.
- Hình: 1–4 SVG tự vẽ (không chép hình SGK), đặt trong thư mục bài, chèn `![Hình n. Chú thích](ten.svg)`. Dùng `currentColor` cho nét/chữ chính; màu nhấn `#d97706` và `#2563eb`; chữ ≥ 12px; viewBox rộng ≤ 560; có `<title>`. Ký tự `<` `&` trong chữ phải viết `&lt;` `&amp;`. **Kiểm tra bằng Playwright** (chụp, tự xem ảnh, sửa đến khi sạch, không chữ chồng chữ).

## quiz.json — luyện tập cuối bài, đúng 3 dạng đề thi
```json
{ "lesson": "<mã>", "title": "<tên bài>", "questions": [
  {"id":"q01","type":"mcq","level":1,"q":"…","options":["…","…","…","…"],"answer":0,"explain":"…"},
  {"id":"q15","type":"tf","level":2,"q":"Cho … Xét các phát biểu sau:","statements":[{"s":"…","a":true,"why":"…"},{"s":"…","a":false,"why":"…"},{"s":"…","a":true,"why":"…"},{"s":"…","a":false,"why":"…"}],"explain":"…"},
  {"id":"q20","type":"short","level":3,"q":"… (làm tròn đến hàng phần mười)","answer":"2,5","explain":"…"}
]}
```
- **25–30 câu/bài**: ~14 `mcq` (4 lựa chọn), **4–5 `tf`** (đúng 4 ý, có cả ý đúng và sai, ý sau khó dần như đề thật), **6–8 `short`**.
- Mức độ: ~40% biết (level 1), ~35% hiểu (2), ~25% vận dụng (3) — có 2–3 câu vận dụng cao/bối cảnh thực tế cho học sinh nhắm 9+.
- `short`: đáp số là **số**, chuỗi dạng `"12"`, `"-3"`, `"0,25"`, `"2,5"` — **tối đa 4 ký tự** (kể cả dấu trừ, dấu phẩy) như đề thật → đề phải nói rõ làm tròn. Không hỏi câu trả lời là chữ.
- Đề/lời giải cần **bảng số liệu**: viết bảng Markdown trong chuỗi `q`/`explain` (xuống dòng bằng `\n`, có dòng trống trước bảng) — app hiển thị được bảng và nhiều đoạn.
- `explain`: lời giải đầy đủ, từng bước (bài tính: công thức → thế số → kết quả). **Không bao giờ gọi phương án bằng chữ A/B/C/D** (app trộn thứ tự) — nhắc lại nội dung. `mcq`: chỉ đúng 1 đáp án bảo vệ được; phương án nhiễu phải "hợp lý" (lỗi sai điển hình), độ dài các phương án tương đương (đừng để đáp án luôn dài nhất).
- `answer` của mcq là chỉ số 0-based; phân bố vị trí đáp án đều.
- **BẮT BUỘC kiểm tra mọi đáp án tính toán bằng python** (sympy/numpy đã cài): giải lại từng câu `short`/`mcq` có tính toán và từng ý `tf` có số liệu; lưu script kiểm tra ở `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/<môn>-<mã>/kt.py` (mỗi bài một thư mục riêng — nhiều người soạn chạy song song, KHÔNG ghi file chung tên ra thư mục gốc scratchpad).

## Thống nhất văn phong
Đọc 1 bài đã hoàn chỉnh cùng môn trước khi viết (đã qua thẩm định): Toán `content/lop-12/toan/b08`, Hóa `content/lop-12/hoa/b06`, Sinh `content/lop-12/sinh/b08`. Giữ cùng cấu trúc, độ dài (~3 500–5 000 chữ), cách dùng khung. Có thể dẫn chéo "xem Bài X" thay vì lặp lại.
Bài chưa có `"ready": true` trong catalog thì app chưa hiện — để kiểm tra trong trình duyệt, chạy server trên một BẢN SAO repo (`cp -r /home/claude/on-thi-thpt <thư mục scratchpad riêng>/repo`) và bật cờ ở bản sao; KHÔNG sửa catalog thật.

## Kiểm tra trước khi xong
1. `node /home/claude/on-thi-thpt/scripts/kiem-tra.mjs` — bài của bạn không có lỗi (lỗi do bài khác chưa có thì bỏ qua). Lệnh này kiểm cả công thức KaTeX.
2. Xem bài trong app: `cd /home/claude/on-thi-thpt && python3 -m http.server <cổng riêng>` rồi Playwright mở `http://localhost:<cổng>/#/bai/lop-12/<môn>/<mã>` (viewport 390×844) và `#/quiz/lop-12/<môn>/<mã>`; chụp, tự xem: công thức hiển thị đúng, khung gợi ý mở được, không lỗi console. Tắt server khi xong.
3. Chỉ sửa trong thư mục bài của bạn (`content/lop-12/<môn>/<mã>/`). Không sửa catalog.json, js/, style.css.

## Báo cáo khi xong (< 200 từ)
Số mục, số ví dụ, số hình, số câu (mcq/tf/short); chỗ SGK khó hiểu bạn đã giảng thêm; điều chưa chắc chắn.

## Bài "Ôn tập chương" (khác bài thường)
- bai.md: KHÔNG giảng lại từ đầu. Gồm: `> [!ghi-nho] Chương này trong 10 dòng`; **Sơ đồ/bảng hệ thống hóa** toàn chương (liên kết ý giữa các bài, dẫn "xem Bài X"); **Bảng so sánh – phân biệt** các chất/khái niệm dễ nhầm; **Lỗi sai hay gặp của cả chương**; **3–5 bài tổng hợp** (ví dụ có gợi ý từng nấc + lời giải) phối hợp nhiều bài; đối chiếu các câu "Bài tập" trong trang Ôn tập chương của SGK (tự đặt đề tương tự, không chép).
- quiz.json: **30–36 câu dạng "đề luyện chương"**, tỉ lệ như đề thi (≈ 60% mcq, 4–6 tf, 6–8 short), phủ đều các bài trong chương, mức vận dụng nhiều hơn bài thường (~35%). Không trùng số liệu với ví dụ/quiz của các bài lẻ (đọc quiz.json các bài trong chương để tránh).
