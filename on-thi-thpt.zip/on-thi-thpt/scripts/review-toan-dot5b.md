# Biên bản thẩm định — Toán 12 đợt 5b (b11, b12, b13)

Ngày: 2026-10-28 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/b11` (Bài 11 Nguyên hàm, SGK T2 tr. 4–11 = PDF 5–12), `b12` (Bài 12 Tích phân, tr. 12–18 = PDF 13–19), `b13` (Bài 13 Ứng dụng hình học của tích phân, tr. 19–26 = PDF 20–27).

## 1. Cách kiểm
- Đọc lại từng trang SGK của 3 bài. Đối chiếu: định nghĩa và chú ý đầu mút (tr. 5), họ nguyên hàm (tr. 5), 4 chú ý (tr. 6), tính chất (tr. 6–7), lũy thừa và $\ln\lvert x\rvert$ (tr. 8), lượng giác (tr. 9), mũ và bảng nguyên hàm (tr. 10), BT 4.1–4.7 (tr. 11); hình thang cong (tr. 12), HĐ1–HĐ2 (tr. 13), diện tích, định nghĩa, chú ý (tr. 14), ý nghĩa hình học (tr. 15), tính chất (tr. 16), giá trị trung bình (tr. 17), BT 4.8–4.13 (tr. 18); diện tích $\int\lvert f\rvert$ (tr. 19), $\int\lvert f-g\rvert$ và chú ý (tr. 21), thặng dư (tr. 22), $V=\int S(x)dx$ (tr. 22), chóp (tr. 23), khối tròn xoay (tr. 24), khối cầu (tr. 25), BT 4.14–4.19 (tr. 25–26). Các số trang `(SGK tr. X)` trong 3 bài đều đúng.
- Giải lại **toàn bộ 85 câu** (b11 29, b12 28, b13 28, mọi phương án nhiễu có giải thích và từng ý tf) và **mọi ví dụ** trong 3 bai.md bằng sympy: 119 phép kiểm, tất cả khớp. Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-5b/kt.py`; bản sửa quiz: `sua_quiz.py` cùng thư mục.
- Kiểm thêm: mcq chỉ 1 phương án đúng; nhiễu ứng với lỗi điển hình (quên $+C$, quên trừ $F(a)$, sai dấu $\int\sin$, nhầm $x^a$/$a^x$, quên $\pi$/bình phương, $\int\lvert f\rvert$ với $\lvert\int f\rvert$); short ≤ 4 ký tự, có ghi làm tròn khi cần; explain không gọi A/B/C/D; vị trí đáp án mcq: b11 4/4/4/4, b12 4/4/4/3, b13 4/4/3/4; mức độ 10/11/8, 10/10/8, 10/10/8; mỗi bài 5 tf · 8 short.
- **Không đòi hỏi đổi biến/từng phần:** soát toàn bộ bài và quiz — không có $\int e^{2x}$, $\int\cos2x$, $\int(ax+b)^n$ dạng phải đặt ẩn; các hàm hợp đều được khai triển trước ($(x+1)^2$, $(\sqrt x+1)^2$, $(1+\frac x2)^2$, $2^{x+1}=2\cdot2^x$, $4^{-x}=(\frac14)^x$).
- Soát trùng số liệu: ví dụ ↔ quiz trong từng bài, quiz ↔ quiz, chéo 3 bài, và với ví dụ/luyện tập/bài tập SGK Bài 11–13.
- Render 11 hình SVG (sáng + tối) bằng Playwright, tự xem ảnh, so tọa độ với hàm số. Mở 3 bài + 3 quiz trong app (bản sao repo bật `ready`, cổng 8872, 390×844), mở hết khung gợi ý/lời giải, đo tràn công thức/bảng; render toàn bộ đề + lời giải + ý tf ở khung 358 px. Không `.katex-error`, không lỗi console, `scrollWidth = 390`; bảng tóm tắt 2–3 cột đọc được.
- `node scripts/kiem-tra.mjs`: **0 lỗi** (cảnh báo còn lại: bài chưa `ready`, font KaTeX chữ Việt).

## 2. Kết quả
**Không có đáp án sai** (85/85), không có lỗi kiến thức trong bài giảng. Lỗi tìm được thuộc loại chép số liệu SGK, trùng/lộ đáp số, nội dung ngoài SGK chưa gắn nhãn, chữ chạm hình.

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b12 bai.md Ví dụ 8b | $\int_0^3\lvert x^2-4\rvert dx=\frac{23}{3}$ trùng đúng hàm, cận, đáp số của **Luyện tập 1 Bài 13 SGK** ($y=x^2-4$, $x=0$, $x=3$) → chép SGK và lộ đáp án bài sau. | Đổi thành $\int_2^4\lvert x^2-9\rvert dx=\frac83+\frac{10}3=6$ (nghiệm $-3$ ngoài đoạn vẫn dùng cho ý "bỏ qua nghiệm ngoài"); sửa gợi ý, lời giải, khung bẫy ($\int_2^4(x^2-9)dx=\frac23\ne6$). |
| b13 quiz q21 | $y=2x+1$ trên $[1;3]$ = **Luyện tập 2a Bài 12 SGK** $\int_1^3(2x+1)dx$. | Đổi $y=2x+3$, đáp số $14$ (hình thang đáy 5 và 9). |
| b13 quiz q16 (tf) | $f=x^2-4x+3$ trên $[0;3]$ trùng hàm và đoạn của b12 Ví dụ 9 ($v=t^2-4t+3$, quãng đường $\frac83$ đã giải sẵn) → lộ đáp số chéo bài. | Đổi $f=x^2-5x+4$ trên $[0;2]$: a) $f\le0$ trên $[1;2]$ Đ; b) $S=\int_0^2f$ S ($=\frac23$); c) $\int_0^1\lvert f\rvert=\frac76$ S (đúng $\frac{11}6$); d) $S=3$ Đ. |
| b11 quiz q16 ↔ q17 | Cùng hàm $3t^2+2$ / $3x^2+2$; ý a của q17 cho sẵn nguyên hàm dùng ở q16. | q16 đổi $v=3t^2+4$: đáp án $64$ m, nhiễu $80$ ($S(4)$), $36$ ($v(4)-v(2)$), $16$ ($S(2)$). |
| b11 quiz q10 | $\int\frac{dx}{\sqrt x}=2\sqrt x$ được giải sẵn nguyên văn trong lời giải Ví dụ 6c. | Đổi $\int\frac{dx}{\sqrt[3]x}=\frac32\sqrt[3]{x^2}+C$; nhiễu: quên lật $\frac23$, đạo hàm $-\frac{1}{3x\sqrt[3]x}$, nguyên hàm của $\sqrt[3]x$. |
| b13 bai.md Dạng 3 (vành khăn) + quiz q13 | Công thức $V=\pi\int(f^2-g^2)$ không có trong SGK nhưng chưa ghi "ngoài SGK"; điều kiện "cùng phía với $Ox$" không chính xác (miền dưới trục cho $f^2-g^2<0$). | Ghi "mở rộng, ngoài SGK", điều kiện $0\le g\le f$; giải thích bằng $V=\int S(x)dx$ của SGK và cách nghĩ "hiệu hai khối tròn xoay" (chỉ dùng công thức SGK); nêu trường hợp miền dưới trục. q13 explain thêm nhãn ngoài SGK và cách giải không dùng công thức mới ($\frac\pi3-\frac\pi5$). |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b13 khung "Công thức (SGK tr. 24)" | SGK yêu cầu $f$ liên tục, **không âm**; bài bỏ điều kiện. | Thêm "không âm"; câu sau nói rõ trường hợp $f$ có chỗ âm là mở rộng. |
| b13 mẹo $\frac{\lvert a\rvert(x_2-x_1)^3}{6}$, mẹo $\frac23\cdot$đáy$\cdot$cao | Ngoài SGK, chưa gắn nhãn. | Ghi "(mở rộng, ngoài SGK)" / "(ngoài SGK, chỉ để kiểm tra)". |
| b11 quiz q12 | $\int(2\cos x-3\sin x)$ = đổi dấu đúng Ví dụ 7a. | Đổi $\int(4\cos x-5\sin x)=4\sin x+5\cos x+C$. |
| b11 quiz q28 | $k=3x^2-4x+1$ trùng $f$ của Ví dụ 1a. | Đổi $k=3x^2-2x+1$, $A(2;5)$, đáp số $f(-1)=-4$. |
| b12 quiz q23 | Dữ kiện $\int_0^2f=3$ trùng Ví dụ 7. | Đổi $\int_0^2f=-1$, đáp số $-10$. |
| b13 quiz q06 | Cùng miền $y=x^2$, $y=2x$ với Ví dụ 11 (gợi ý đã giải giao điểm, vị trí trên/dưới). | Đổi $y=x^2$ và $y=1$, $S=\frac43$; nhiễu $\frac23$, $2$, $\frac83$. |
| b11 bai.md khung nền tảng lượng giác | Nêu hạ bậc ra $\cos2x$ có thể dẫn học sinh tới $\int\cos2x$ (cần đổi biến, SGK chưa dạy). | Thêm câu: ở bài này dùng dạng $2\cos^2\frac x2=1+\cos x$ vì $\cos2x$ chưa có trong bảng. |
| b12/h1-dai-mong.svg | Nhãn "y = f(x)" chạm đường cong. | Dời nhãn lên trái. |
| b13/h4-khoi-tron-xoay.svg | Nhãn "−2", "2" bị đuôi parabol cắt; "f(x)" chạm đường cong. | Dời nhãn vào trong, hạ "f(x)". |
| b13 bai.md | "Newton–Leibniz" khác b12 "Newton – Leibniz". | Thống nhất "Newton – Leibniz". |

Các hình còn lại đúng và sạch: b11 h1 (sơ đồ đạo hàm ↔ nguyên hàm), h2 ($x^2+C$, $C=-2..2$, tiếp tuyến song song tại $x=1$, qua $(1;3)$), h3 ($v=29{,}4-9{,}8t$, $h$ max $46{,}1$ tại $t=3$, $h(0)=2$); b12 h2 (hình thang $1$–$4$ trên $[-1;2]$, phần tư tròn bán kính 2), h3 ($t^2-4t+3$, cực tiểu $(2;-1)$, hai mảnh $\pm\frac43$), h4 (24 + 72 + 18); b13 h1 ($x^2-2x$, ba mảnh $\frac43$), h2 ($(-1;1)$, $(2;4)$), h3 (thiết diện). Bản tối hiển thị đúng.

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức; **6 lỗi đáng kể** (2 chép số liệu SGK, 3 trùng/lộ đáp số, 1 công thức ngoài SGK chưa gắn nhãn/điều kiện chưa chặt); **10 lỗi nhỏ**.

## 4. Nội dung, cách giảng, nhất quán
- b11 đủ nội dung SGK (định nghĩa + chú ý đầu mút, họ nguyên hàm có giải thích vì sao chỉ khác hằng số, 4 chú ý, tính chất, lũy thừa/$\ln\lvert x\rvert$ chứng minh hai trường hợp, lượng giác, mũ, bảng, bài toán thực tế); thêm mục "nguyên hàm thỏa điều kiện" đúng dạng đề.
- b12 giảng hàm diện tích $S(x)$ bằng kẹp hai hình chữ nhật (đúng tinh thần HĐ2), định nghĩa, quy ước, ý nghĩa hình học/vật lí, 4 tính chất, trị tuyệt đối, độ dịch chuyển – quãng đường (BT 4.11), giá trị trung bình (Vận dụng 2). "Hàm lẻ trên đoạn đối xứng" đã ghi ngoài SGK.
- b13 đủ: $\int\lvert f\rvert$, $\int\lvert f-g\rvert$ + chú ý không đổi dấu, thặng dư, $V=\int S(x)dx$ kèm lăng trụ/chóp, khối tròn xoay, nón/cầu/nón cụt.
- Kí hiệu thống nhất 3 bài: $\int f(x)\,dx$, $F(x)\Big|_a^b$, $[a;b]$, $\lvert\cdot\rvert$, $\pi f^2(x)$. Mỗi bài dẫn chéo đúng bài trước (khung "Cần nhớ từ Bài 11/12").
- Ví dụ cùng dạng SGK đều đổi số (máy bay → tàu điện $2+1{,}2t$; ô tô phanh $20-5t$, $16-2t$; bóng $29{,}4-9{,}8t$; $\int_0^2\sqrt{4-x^2}$ thay $\int_{-2}^2$; thặng dư $10-0{,}4x$ / $0{,}1x+5$; nón cụt bán kính 1–3).

## 5. Góp ý chưa sửa (không phải lỗi)
1. Mô hình "ô tô phanh, $v$ giảm tuyến tính" xuất hiện ở b11 Ví dụ 14, q20; b12 Ví dụ 5, q19 (số liệu khác nhau). Chấp nhận cho bài thường; bài ôn chương nên dùng mô hình khác.
2. b12 q17d cùng khuôn $\int[3f-2g+x]$ với Ví dụ 7b (số liệu khác) — luyện lại dạng vừa học, chấp nhận.
3. Hình SVG rộng 520 px nằm trong khung cuộn ngang theo thiết kế chung của app.
