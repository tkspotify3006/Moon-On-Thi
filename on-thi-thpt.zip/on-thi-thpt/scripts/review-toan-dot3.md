# Biên bản thẩm định — Toán 12 đợt 3 (b01, b02, b03)

Ngày: 2026-10-24 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/b01` (Bài 1 Tính đơn điệu và cực trị của hàm số, SGK tr. 5–14 = PDF 6–15), `b02` (Bài 2 GTLN và GTNN của hàm số, tr. 15–19 = PDF 16–20), `b03` (Bài 3 Đường tiệm cận của đồ thị hàm số, tr. 20–25 = PDF 21–26).

## 1. Cách kiểm
- Đọc lại từng trang SGK của 3 bài. Đối chiếu cách phát biểu: định nghĩa đồng biến/nghịch biến (tr. 6), định lí dấu đạo hàm và chú ý "$f'=0$ tại hữu hạn điểm" (tr. 7), các bước xét đơn điệu (tr. 8), định nghĩa cực trị và các khái niệm điểm cực trị / giá trị cực trị / điểm cực trị của đồ thị (tr. 9), điều kiện đủ (tr. 10), quy tắc tìm cực trị (tr. 11), định nghĩa GTLN–GTNN (tr. 15), chú ý (tr. 16), quy tắc trên đoạn (tr. 18), định nghĩa TCN (tr. 20), TCĐ (tr. 21), TCX (tr. 23), công thức $a$, $b$ (tr. 24). Mọi số trang ghi `(SGK tr. X)` trong bài đều đúng.
- Giải lại **toàn bộ 84 câu** (mỗi bài 15 mcq + 5 tf + 8 short) và **mọi ví dụ** trong 3 bai.md bằng sympy: điểm tới hạn và dấu đạo hàm hai phía, GTLN/GTNN trên đoạn (gồm đầu mút), giới hạn ở $\pm\infty$ và giới hạn một bên, $a=\lim f/x$, $b=\lim(f-ax)$, các bài có tham số (đếm trực tiếp từng $m$). Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-3/kt.py`.
- Kiểm thêm: mcq chỉ có 1 phương án bảo vệ được; nhiễu đúng là lỗi điển hình mà explain nêu; short ≤ 4 ký tự và có ghi làm tròn khi cần (b01 q26 4,47; q27 4,6; b02 q24 2,6; q27 75,4); explain không gọi A/B/C/D; vị trí đáp án mcq 4/4/4/3 ở cả 3 bài; mức độ b01 10/11/7, b02 10/10/8, b03 10/10/8; mỗi câu tf có cả ý đúng và sai.
- Render 12 hình SVG bằng Playwright (nền sáng và tối), tự xem ảnh; so tọa độ với hàm số (cực trị, nghiệm, tiệm cận, đồ thị $f'$ của b01 h4 là $k(x+2)(x-1)^2(x-3)$, đáy tại $x\approx-1{,}15$ và $x\approx2{,}40$ khớp lời giảng "≈ −1,1 và ≈ 2,4").
- Mở 3 bài và 3 quiz trong app (390×844), mở hết khung lời giải, đo tràn ngang của mọi công thức/bảng; render toàn bộ đề + lời giải quiz bằng `Content.mdBlock` + `fitMath` ở bề rộng thẻ câu hỏi. Không lỗi console, không `.katex-error`.
- `node scripts/kiem-tra.mjs`: **0 lỗi, 0 cảnh báo**.

## 2. Kết quả quiz
**Không có đáp án nào sai** (84/84). Các ý tf đều đúng như ghi; lời giải từng bước đúng. Đề đủ dữ kiện (tập xác định, đoạn/khoảng, điều kiện thực tế $t\ge0$, $0<r\le1{,}2$, $0\le p<100$…).

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b03/h1-tiem-can-ngang.svg | **Sai toán:** chú thích "x → +∞: MH = f(x) − 2 → 0", nhưng với $x>-1{,}5$ đồ thị nằm **dưới** $y=2$ ($f(x)-2=\frac{-7}{2x+3}<0$), độ dài không thể âm. | "MH = 2 − f(x) → 0". |
| b03 quiz q15, q25 (explain) | Chuỗi JSON ghi `\\n\\n` nên app hiện nguyên chữ "\n\n- …" thay vì xuống dòng và danh sách gạch đầu dòng. | Đổi thành ký tự xuống dòng thật (đã kiểm: lời giải q15 hiện thành danh sách). |
| b01 quiz q12 | Bảng xét dấu 9 cột: trên màn 390 px cột cuối bị cắt, chỉ còn "+" của "+∞". | Thêm `\footnotesize` cho bảng (cùng cách bai.md đang dùng cho bảng 9 cột); đã chụp lại, đọc đủ. |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b03/bai.md, khung Định nghĩa TCĐ | Bốn giới hạn viết trên một dòng `$$`, rộng 586 px, phải cuộn ngang trên điện thoại. | Tách thành 2 dòng (mỗi dòng 2 giới hạn). |
| b03/bai.md, Ví dụ 5 cách 1 | Công thức $b=\lim[\dots]=\lim\frac{x-1}{x+2}=1$ rộng 367 px > 328 px. | Tách thành 2 dòng. |
| b01/h1-don-dieu-cuc-tri.svg | Số "−2" trên trục $Ox$ bị đồ thị cắt qua (đồ thị đi qua $(-2;0)$); số "4" trên trục $Oy$ bị nét đứt từ điểm cực đại cắt qua. | Dời "−2" sang phải; đặt "4" bên phải trục $Oy$. |
| b01/h3-cuc-tri-la-dia-phuong.svg | "−1" trên $Ox$ và "−2" trên $Oy$ bị nét đứt cắt; hai dải tô màu chạm dòng chú thích dưới hình. | Dời hai nhãn ra khỏi nét đứt; rút ngắn dải tô. |
| b01/h4-do-thi-dao-ham.svg | Dấu "−" màu cam đứng sát nhãn "−2" của trục $Oy$ (đọc thành "−−2"); "−2" trên $Ox$ bị đồ thị $f'$ cắt. | Đặt "−2" ($Oy$) bên phải trục, dời dấu "−"; dời "−2" ($Ox$) sang trái. |
| b02/h1-gtln-gtnn-doan.svg | Nhãn "3" trên $Oy$ bị đồ thị (đoạn gần cực đại) che. | Bỏ nhãn số (giá trị đã ghi trong chú thích "cực đại: 3"). |
| b02/h4-do-thi-dao-ham.svg | Nhãn "−1" chạm nét đứt tại $x=-1$. | Dời nhãn sang trái. |

Các hình còn lại đúng và sạch: b01 h2 ($y=x^3$, $y=\lvert x\rvert$), b02 h2 (cực tiểu $(2;4)$ của $x+4/x$), b02 h3 (hộp $16\times10$), b03 h2 (4 trường hợp TCĐ, khớp SGK H.1.23), b03 h3 (TCX $y=x+1$, TCĐ $x=-2$, nhánh trái trên, nhánh phải dưới tiệm cận đúng dấu của $-3/(x+2)$), b03 h4 (BBT dùng cho VD7, VD9). Đồ thị b01 h1, h3, b02 h1, h4, b03 h1 đúng tọa độ cực trị/nghiệm/tiệm cận.

**Tổng:** 0 lỗi sai đáp án hay sai kiến thức trong bài giảng; 3 lỗi đáng kể (1 chú thích hình sai dấu, 2 lỗi hiển thị trên điện thoại ở quiz); 8 lỗi nhỏ (2 công thức tràn ngang, 6 chỗ nhãn hình bị nét cắt/che ở 5 hình).

## 4. Nội dung, cách giảng, bản quyền
- Đủ nội dung SGK. b01: định nghĩa, định lí dấu đạo hàm + 2 chú ý, BBT, các bước, định nghĩa cực trị, ba khái niệm điểm/giá trị/điểm của đồ thị, điều kiện đủ (bảng gọn), quy tắc 4 bước, chú ý $y=x^3$, $y=\lvert x\rvert$ (BT 1.8), đọc đồ thị $f'$ (BT 1.6). b02: định nghĩa (đủ hai điều kiện), chú ý, trên khoảng (không tồn tại GTLN), quy tắc trên đoạn với đúng giả thiết SGK, bài toán tối ưu, "tăng nhanh nhất" (Vận dụng tr. 18). b03: TCN, TCĐ (4 điều kiện), TCX và công thức $a$, $b$, trường hợp $a=0$ là TCN, ý nghĩa thực tế.
- Phát biểu đúng SGK, không chép nguyên văn; ví dụ cùng dạng SGK đều đổi số (chất điểm $t^3-6t^2+9t$ so với $t^3-9t^2+15t$; dân số $(40t+30)/(t+2)$ so với BT 1.5; tấm bìa $16\times10$ so với hình vuông 60 cm; virus $-t^3+12t^2$ → lượt tải $-t^3+18t^2$; tảo $45p/(100-p)$ → $50p/(100-p)$; vườn 144 m² → 64 m²).
- Tham số $m$: đồng biến trên $\mathbb R$ của hàm bậc ba (b01 q15, q25), TCX qua điểm, số TCĐ của $\frac{x-3}{x^2-2x+m}$ (b03 q25, VD10) — đúng mức đề tốt nghiệp từ 2025, không đi sâu.
- Mẹo máy tính đều có câu rào ("tên mục có thể khác tùy máy", "chỉ để soát", CALC với $10^9$ có thể sai với căn).

## 5. Góp ý chưa sửa (không phải lỗi)
1. b01 q06 ($y=x^3-3x^2+4$) và q26 ($y=x^3-3x^2+1$) có cùng $y'$; explain q06 cho sẵn nghiệm $x=0$, $x=2$ — chưa lộ đáp số q26 (còn phải tính tung độ và khoảng cách) nhưng nếu muốn chặt thì đổi hệ số q26.
2. Một số phương án nhiễu chưa được explain giải thích (b01 q14 "$x=20$", b02 q14 "400 m²", b03 q09 "$y=\pm1$") — vẫn hợp lí, có thể thêm nửa câu.
3. b01 bai.md gọi khung tr. 7 là "Định lí" (SGK không đặt tên) — chấp nhận được.
4. Bảng BBT 9 cột trong bai.md (VD7, VD9 b01) dùng `\footnotesize`, đọc được ở 390 px nhưng chữ hơi nhỏ; nếu cần có thể bỏ bớt cột trống.
