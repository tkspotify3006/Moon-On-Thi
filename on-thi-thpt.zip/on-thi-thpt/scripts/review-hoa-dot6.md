# Biên bản thẩm định Hóa 12 (đợt 6): b16, b18

- b16: Điện phân (SGK tr. 78–84, PDF 80–86)
- b18: Cấu tạo và liên kết trong tinh thể kim loại (SGK tr. 87–88, PDF 89–90)

Ngày 28/10/2026.

Cách kiểm:
- Đọc lại từng trang SGK của hai bài và đối chiếu với bai.md (thứ tự điện phân, ví dụ, số liệu, thuật ngữ).
- Giải lại độc lập toàn bộ quiz (b16: 28 câu; b18: 24 câu, nay 25) và mọi ví dụ có số liệu trong bai.md bằng python (`scratchpad/rv-hoa-6/kt.py`). Đếm lại các câu "có bao nhiêu".
- Đối chiếu số liệu giữa quiz và ví dụ trong bài, và giữa các câu trong cùng quiz.
- Render 8 hình SVG bằng Playwright và tự xem từng hình. Cỡ chữ từ 12 đến 18, mỗi hình có `<title>`.
- Mở 2 bài và 2 quiz trong app (390×844, bản sao repo, cổng 8903): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390. Bảng vừa khung. Hình rộng 520 px nằm trong `figure` cuộn ngang riêng, giống các bài đã duyệt (b13).
- `kiem-tra.mjs`: 0 lỗi (cảnh báo "chưa ready" là bình thường).

## Lỗi nghiêm trọng đã sửa (3)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b16 mục 2.3, quy tắc "từ Zn^2+^ trở đi bị khử" | Quy tắc này là phần tác giả tự thêm, không ghi là ngoài SGK. Câu "từ Zn^2+^ trở đi … bị khử thành kim loại ở cathode" không nói Zn^2+^, Fe^2+^, Ni^2+^ đứng **sau H^+^** và **trước H~2~O**. Học sinh dễ hiểu là các ion này bị khử trước H^+^, nên làm sai đề có acid và muối Fe^2+^. Hình 2 cũng chỉ có H^+^ → H~2~O, không có chỗ cho các ion này. | Viết lại thành "quy ước thường dùng khi làm đề (ngoài SGK)" gồm 3 nhóm: Al^3+^ trở về trước không bị khử; Zn^2+^ … Pb^2+^ bị khử sau H^+^ (acid), trước H~2~O; Cu^2+^ … Au^3+^ như SGK. Thêm thứ tự đầy đủ Au^3+^ > Ag^+^ > Hg^2+^ > Cu^2+^ > H^+^ > Pb^2+^ > Sn^2+^ > Ni^2+^ > Fe^2+^ > Zn^2+^ > H~2~O và khung bẫy (dung dịch HCl + FeCl~2~ thì H^+^ bị khử trước). Hình 2 thêm ghi chú "Zn^2+^, Fe^2+^, Ni^2+^… (quy ước làm đề): bị khử sau H^+^, trước H~2~O". Dạng 1 bước 2 và bảng Tóm tắt sửa theo. |
| b16 mục 3.1, phương trình điện phân Al~2~O~3~ | Ghi "(điện phân nóng chảy, **xúc tác** cryolite)". Sai kiến thức: cryolite không phải xúc tác, chỉ hạ nhiệt độ nóng chảy. Câu này còn mâu thuẫn với khung bẫy ngay bên dưới. | Đổi thành "(điện phân nóng chảy, có mặt cryolite)". |
| b18 `q21` (short, M^2+^ [Ar]3d^5^ → 25) | Lộ đáp số: `q13` (mcq) có phương án "Mn (Z = 25)", và explain của `q13` viết đúng [Ar]3d^5^4s^2^, Z = 25. | Đổi đề: ion M^3+^ có cấu hình [Ar]3d^6^ → Z = **27** (Co). Explain nêu bẫy: nếu chỉ cộng 2 thì ra 26 (Fe). |

## Lỗi nhỏ đã sửa (11)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b16 khung "Bài này trong 5 dòng", ý 5 | Công thức n~e~ = It/F chưa ghi là phần mở rộng. | Thêm "(mở rộng, ngoài SGK)". Tiêu đề Dạng 2, Dạng 3 và bảng Tóm tắt cũng thêm nhãn mở rộng. |
| b16 mục 4, câu mở đầu | Viết "đề tốt nghiệp thường có câu tính toán điện phân". Nhận định này không chắc chắn. | Đổi thành "nhiều đề thi thử và đề luyện thi có câu tính toán điện phân". |
| b16 bảng Tóm tắt, thứ tự ở anode | Thiếu ClO~4~^−^, trong khi SGK tr. 81 có nêu. | Thêm ClO~4~^−^. |
| b16 `q24` | Đáp số 32,2 phút ứng với t = 1 930 s, trùng thời gian "32 phút 10 giây" của Ví dụ 4. | Đổi số liệu: 6,9 g Na, I = 8 A → **60,3** phút. |
| b18 `q19` | Hỏi số electron lớp ngoài cùng của Al. Đáp án 3 có sẵn trong bảng mục 1.2 và Ví dụ 2. | Đổi sang Ga (Z = 31) → 3 (phải bỏ 3d^10^ khỏi lớp ngoài cùng). Mức đổi thành 2. |
| b18 quiz | Có 24 câu, ít hơn mức tối thiểu 25 câu của quy chuẩn. | Thêm `q25` (mcq, mức 1): kim loại có mạng lục phương chặt khít theo SGK (Mg; nhiễu Na, Cu, K). |
| b18 `q02` | Phương án đúng dài nhất rõ rệt (86 so với 56–65 ký tự). | Rút gọn phương án đúng, viết dài thêm một phương án nhiễu (62/69/65/73). |
| b18 Dạng 1, bước 4 | Ghi "5–7 e → phi kim" và "4 e, chu kì lớn (Sn, Pb) là kim loại". Bi (5 e) là kim loại, còn Ge (chu kì 4, 4 e) là nguyên tố trung gian. Như vậy mâu thuẫn với khung bẫy và Hình 1 của chính bài. | Viết lại: 4–7 e thường là phi kim, trừ Sn, Pb (4 e) và Bi (5 e) là kim loại; Ge, Sb… có tính chất trung gian. |
| b18 mục 1.2 | Viết "lớp ngoài cùng **luôn** chỉ có 1–2 electron" (khối d). Câu này tuyệt đối quá, vì có ngoại lệ như Pd. | Đổi thành "thường". |
| b18 mục 2.2, bảng kiểu mạng, và Hình 3 | Ghi "Lục phương", trong khi SGK gọi là "lục phương chặt khít". Bảng có thêm ví dụ Fe, Al, Ag, Au, Zn nằm ngoài SGK (đúng khoa học) nhưng chưa ghi nhãn. Ví dụ 3 chỉ ghi "mở rộng". | Đổi thuật ngữ ở bảng, Tóm tắt và hình. Thêm dòng "Ví dụ trong SGK: …; Fe, Al, Ag, Au, Zn là mở rộng ngoài SGK". Ví dụ 3 ghi "(mở rộng ngoài SGK, vận dụng cao)". |
| b18 Hình 4 (`so-sanh-lien-ket.svg`) | Dùng kí hiệu cân bằng "⇄" giữa "ion dương" và "ion âm/electron". Kí hiệu này dễ gây hiểu nhầm. | Đổi thành "ion dương hút ion âm" và "ion dương hút electron tự do". |

## Đã kiểm, không có lỗi

- **Thứ tự ở điện cực (b16) khớp SGK tr. 81**:
  - Anode: I^−^ > Br^−^ > Cl^−^. Các anion CO~3~^2−^, NO~3~^−^, PO~4~^3−^, SO~4~^2−^, F^−^, ClO~4~^−^ coi như không bị điện phân.
  - Cathode: Au^3+^ > Ag^+^ > Hg^2+^ > Cu^2+^ > H^+^ > H~2~O.
  - Khung Fe^3+^ (mở rộng): Ag^+^ > Fe^3+^ > Cu^2+^ > H^+^ > Fe^2+^. Thứ tự này nhất quán với quy ước mới.
- **Thể tích khí** dùng 24,79 L/mol (25 °C, 1 bar) ở mọi chỗ: Ví dụ 4, Ví dụ 8, `q23`. Không còn chỗ nào dùng 22,4.
- **Đáp án b16**:
  - mcq tính toán: `q14` 3,84 g (nhiễu 7,68; 1,92; 0,064), `q15` 29,8 giờ (nhiễu 9,9; 19,9; 59,6).
  - tf: `q19` 537 kg (ý sai 1,61 tấn là kết quả khi quên chia 3). `q20`: n~e~ = 0,12; 0,075 mol khí; dung dịch giảm 6,31 g.
  - short: 3; 4; 2,48; 60,3 (mới); 6,3 (6,254); 96,5; 136 (143 nếu bỏ hiệu suất); 4,05.
- **Ví dụ b16**:
  - Ví dụ 4: 5,4 g và 0,31 L. Ví dụ 5: 1,21 tấn và 403 kg. Ví dụ 6: 24,3 phút.
  - Ví dụ 8: 1,98 L (bẫy 1,49 L). Ví dụ 9: 6,2 g. Ví dụ 10d: 0,54 g.
  - Ví dụ 2, 3, 7: quá trình và phương trình đúng.
- **Đáp án b18**:
  - Ví dụ 3: Fe 0,124 nm (0,141 nm nếu bỏ 0,68).
  - `q18`: V = 45,3 cm^3^; r(K) = 0,230 nm (ý sai 0,262 nm là kết quả khi quên nhân 0,68).
  - `q24`: Cu 128 pm (141 pm nếu bỏ 0,74).
  - Câu đếm: `q20` có 6 kim loại. `q22` có 9 nguyên tố chu kì 4 có 4s^2^ ở lớp ngoài cùng. `q23` Ni (28). Ví dụ 5: 4 kim loại và 4 nguyên tử có 1 e lớp ngoài cùng.
- **Hình.**
  - Bảng tuần hoàn: kim loại là khối s (trừ H, He), d, f, cùng Al, Ga, In, Tl, Sn, Pb, Bi, Po. Nhóm trung gian gồm B, Si, Ge, As, Sb, Te. Phi kim và khí hiếm tô màu riêng. Đường bậc thang vẽ đúng.
  - Ba kiểu mạng có độ đặc khít và số phối trí đúng SGK tr. 88.
  - Thùng điện phân Al~2~O~3~ có cathode lót đáy, anode treo phía trên, nhôm lỏng nằm dưới lớp điện li.
  - Không hình nào có chữ chồng chữ.
- **Phần ngoài SGK đều đúng và đã có nhãn**: định luật Faraday, Fe^3+^, công nghiệp chlor – kiềm, bùn anode, AlCl~3~, quy ước Zn^2+^, tính bán kính từ khối lượng riêng.
- **Hình thức quiz.**
  - Không gọi phương án bằng chữ A/B/C/D. Đáp số short ≤ 4 ký tự, các câu cần làm tròn đều ghi rõ.
  - Vị trí đáp án: b16 4/4/4/3, b18 4/4/4/3.
  - b16 có 15 mcq, 5 tf, 8 short. b18 có 15 mcq, 4 tf, 6 short.
- **Bản quyền.** Không có đoạn chép nguyên văn SGK. Các thí nghiệm SGK được thuật lại bằng lời khác và có ghi trang.

## Góp ý chưa sửa

1. b16 dài khoảng 7 100 từ theo `wc` (có tính markup), dài hơn mức 3 500–5 000 của quy chuẩn. Phần dài thêm chủ yếu là mục 4 (Faraday, mở rộng) và 4 dạng bài. Nội dung không lặp, nên giữ nguyên.
2. Vị trí đáp án mcq của b16 xoay vòng đều 0-1-2-3. Đáp án vẫn phân bố đều, và app có trộn phương án, nên không đổi.
3. b18 `q17` dùng K (Z = 19) và Cu (Z = 29), giống Ví dụ 1 và Ví dụ 4 của bài, nhưng hỏi các ý khác (nhóm IB, Se, bán kính). Đây là ôn kiến thức chứ không lộ đáp số, nên giữ.
4. Các hình rộng 520 px được hiển thị trong khung cuộn ngang trên màn 390 px. Cách hiển thị này giống các bài đã duyệt.
