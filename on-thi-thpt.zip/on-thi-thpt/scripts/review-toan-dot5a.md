# Biên bản thẩm định — Toán 12 đợt 5a (on-2, on-3)

Ngày: 2026-10-28 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/on-2` (Ôn tập chương II, Bài tập cuối chương II, SGK tr. 73–74 = PDF 74–75; các bài lẻ b06, b07, b08) và `on-3` (Ôn tập chương III, Bài tập cuối chương III, tr. 85–86 = PDF 86–87; các bài lẻ b09, b10).

## 1. Cách kiểm
- Đọc lại SGK PDF 74–75 (BT 2.25–2.42), 86–87 (BT 3.9–3.17) và PDF 78–79 (công thức tứ phân vị của Bài 9, Ví dụ 2 SGK). Bảng đối chiếu BT ở mục 5 của cả hai bài khớp nội dung từng bài tập. Mọi chỗ dẫn "Bài X mục/Dạng/Ví dụ" đều có thật trong b06–b10.
- **Công thức tứ phân vị ở on-3** (khung ghi nhớ mục 3, bảng tóm tắt) đúng như SGK tr. 77: $Q_r=a_p+\frac{\frac{rn}{4}-(m_1+\dots+m_{p-1})}{m_p}(a_{p+1}-a_p)$. Cách chọn nhóm "nhóm đầu tiên có tần số tích lũy $\ge\frac{rn}{4}$" cho cùng kết quả với cách của SGK (theo vị trí trong mẫu gốc). Phương sai chia cho $n$, độ lệch chuẩn là $\sigma_x$, đúng SGK.
- Giải lại **toàn bộ 67 câu** (on-2 33, on-3 34) và mọi ví dụ, bài tự luyện T1–T12 (on-2), T1–T5 (on-3) bằng sympy/Fraction, kể cả các phương án nhiễu được giải thích trong explain. Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-5a/kt2.py` (chương II), `kt3.py` (chương III).
- Thống kê: on-2 20 mcq (61%) · 5 tf · 8 short, mức độ 10/12/11 (vận dụng 33%), vị trí đáp án 5/5/5/5; on-3 21 mcq (62%) · 5 tf · 8 short, mức độ 9/13/12 (35%), vị trí 5/5/5/6. Đáp án đúng dài nhất hẳn: 3/20 và 0/21. Short ≤ 4 ký tự, đều ghi làm tròn. Explain không gọi A/B/C/D. Mỗi tf có cả ý Đúng lẫn Sai.
- Soát trùng: dò mọi bộ tọa độ (on-2) và mọi bảng tần số (on-3) với bai.md + quiz.json của b06–b10, rồi so sánh cấu trúc đề.
- Render 6 hình SVG bằng Playwright và tự xem ảnh. Mở 2 bài + 2 quiz trong app trên bản sao repo (cổng 8871, 390×844), mở hết khung gợi ý/lời giải, đo tràn ngang mọi công thức và bảng. Render đề, lời giải và ý tf của quiz ở bề rộng khung đề. Không lỗi console, không `.katex-error`, `scrollWidth = 390`.
- `node scripts/kiem-tra.mjs`: **0 lỗi** (cảnh báo chỉ là "chưa ready" và font KaTeX cho chữ Việt trong `\text{}`).

## 2. Kết quả quiz
**Không có đáp án nào sai** (67/67). Mọi ý tf đúng như ghi, mcq chỉ có 1 phương án bảo vệ được, nhiễu đều là lỗi điển hình và được giải thích đúng.

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| on-3 bai.md mục 5, T5 | Bảng của Lan (tần số 1; 6; 2; 1, nhóm cách đều) là số liệu An ở SGK BT 3.17 được tịnh tiến/co giãn. Chép số liệu SGK, đáp số suy ra thẳng từ lời giải SGK. | Đổi tần số của Lan thành 1; 5; 3; 1. Đáp số mới: $\bar x=99{,}95$ g, $s^2=0{,}16$, $s=0{,}4$ g; Huệ vẫn $s\approx0{,}51$; kết luận giữ nguyên (Lan ổn định hơn). |
| on-3 bai.md bảng Tóm tắt | Công thức $Q_r$ dài làm bảng 3 cột rộng 374 px > 358 px. Cột "Nhớ ngay" bị cắt chữ, mỗi dòng chỉ còn 1–2 chữ. | Viết gọn $Q_r=a_p+\frac{\frac{rn}{4}-C}{m_p}\cdot h$ và giải nghĩa $C$, $h$ ở cột "Nhớ ngay"; bọc nhóm cho công thức ngoại lệ. Đo lại: 358 px, hết tràn. |
| on-3 quiz q22 ý c, q26 ý c | Công thức $\bar x=\frac{\dots}{30}$ viết trên một dòng rộng 379 px và 422 px, lớn hơn khung 324 px, phải cuộn ngang. | Tách thành $\sum m_ix_i=\dots=985$ (q26: $=650$), rồi mới viết $\bar x=\dots$. Đo lại: tối đa 318 px. |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| on-2 quiz q33 | Dùng GTNN tam thức bậc hai (lớp 10) nhưng chỉ ghi "nhỏ nhất tại $t=\frac{220}{50}$", chưa giảng vì sao. | Explain bổ sung: $PQ$ nhỏ nhất khi $PQ^2$ nhỏ nhất; đỉnh parabol $t=-\frac{b}{2a}$ (lớp 10), hoặc lập BBT với $(PQ^2)'=50t-220$ như Chương I; $t=4{,}4$ thỏa $t\ge0$. |
| on-3 quiz q27 | Bảng tuổi hiến máu có các nhóm $[20;25)\dots[40;45)$ với tần số 4; 9; 12; 8, trùng gần hết với bảng b09 q16. | Đổi tần số thành 3; 8; 13; 9; 5; 2 ($n=40$). Đáp án $R=30$ giữ nguyên. |
| on-3 bai.md (ghi nhớ 9, bảng 1.3, bảng tóm tắt) | Hệ số biến thiên $CV$ không có trong SGK (b10 để trong khung "Em có biết") nhưng on-3 dùng như kiến thức chính, không ghi chú. | Ghi rõ "(mở rộng, ngoài SGK)" ở cả 3 chỗ. Quiz q17 và q33 đã cho sẵn công thức $CV$ trong đề nên giữ nguyên. |

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức; **3 lỗi đáng kể** (1 chỗ chép số liệu SGK, 2 chỗ tràn ngang trên điện thoại), **3 lỗi nhỏ**.

## 4. Nội dung, hình
- on-2: đủ mẫu bài ôn tập — ghi nhớ 10 dòng, "từ điển hai ngôn ngữ" hình học ↔ tọa độ, 5 bảng phân biệt (4 quan hệ vectơ, trục/mặt phẳng, 3 loại góc, vectơ hay số, thứ tự đỉnh hình bình hành), 17 lỗi sai theo từng bài, 5 bài tổng hợp có gợi ý nhiều nấc (lập phương hai cách, tứ diện chia tỉ lệ, hình hộp Đúng/Sai, $MA+MB$ nhỏ nhất, đèn + camera), bảng đối chiếu 2.25–2.42 với 12 bài tự luyện (đáp số đều đúng). Ví dụ cùng dạng SGK đều đổi số (2.36 → tỉ lệ $\frac14$; 2.39 → tọa độ khác, thêm ý lập phương; 2.42 → phòng 6×5×3,2 m, thêm camera).
- on-3: đúng mẫu, đủ $R$ (bỏ nhóm tần số 0 ở hai đầu), $Q_r$/$\Delta_Q$, ngoại lệ $1{,}5\Delta_Q$, $s^2$/$s$ ($\sigma_x$ khác $s_x$), bảng biến đổi "nhân tần số / thay tần số / đổi đơn vị" (ứng với BT 3.12–3.13), 5 bài tổng hợp (thời gian rã thuốc, hai cây dược liệu, chờ lấy thuốc Đúng/Sai, tần số ẩn, cân nặng trẻ sơ sinh).
- Hình: on-2 h1 (bảng dịch), h2 (lập phương cạnh 2, $M$ đúng trung điểm $CC'$, $N$ đúng trung điểm $A'D'$), h3 (đối xứng qua $(Oxy)$), h4 (phòng, $K(6;5;3{,}2)$, $L_1$, $L_2$ treo từ trần); on-3 h1 (bản đồ chương), h2 (biểu đồ Ví dụ 1: $R=10$, $Q_1\approx7{,}56$, $Q_3\approx10{,}67$, $\bar x\pm s=6{,}96..11{,}24$ — khớp số liệu). Chữ ≥ 12 px, không chồng chữ, đúng khoa học.

## 5. Góp ý chưa sửa (không phải lỗi)
1. on-3 q33 (quầy thuốc nhỏ – nhà thuốc lớn, nhóm $[2;4)\dots$ và $[100;110)\dots$) cùng mô hình với b10 Ví dụ 6 (quầy tạp hóa – siêu thị). Tần số và số nhóm khác nhau, đáp số khác, nên chấp nhận.
2. on-3 q25 (máy chiết rót 500 ml) cùng bối cảnh với một câu của b10, khác số liệu.
3. on-2 q31 (dời đèn) cùng dạng SGK 2.42 và Ví dụ 5 của chính bài, khác số liệu — phù hợp vai trò "luyện lại dạng".
