# Biên bản thẩm định Hóa 12: b24, b25

- b24: Nguyên tố nhóm IA (SGK tr. 108–115, PDF 110–117)
- b25: Nguyên tố nhóm IIA (SGK tr. 116–125, PDF 118–127)

Ngày 29/10/2026.

Cách kiểm:
- Đọc lại từng trang SGK của hai bài, đối chiếu với bai.md: Bảng 24.1–24.3, 25.1–25.5, bảng độ tan hydroxide và muối, bảng Δ~r~H°~298~, các thí nghiệm, Hình 24.4, 24.5, 25.3.
- Giải lại độc lập toàn bộ quiz (b24: 29 câu, b25: 28 câu) và mọi ví dụ có số liệu bằng python/sympy (`scratchpad/rv-hoa-b24b25/kt.py`). Đếm lại các câu "có bao nhiêu".
- Đối chiếu số liệu: trong từng bài, giữa b24 và b25, với b16 (điện phân), b19 và b22, và với b26 (Ôn tập chương 7, đã có sẵn) để không tạo trùng mới.
- Render 7 hình SVG bằng Playwright và tự xem từng hình. Kiểm cỡ chữ (≥ 12 px) và chữ chồng chữ.
- Mở 2 bài và đi qua đủ 29 + 28 câu quiz trong app (390×844, bản sao repo, cổng 8812): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390, không có ảnh hỏng.
- `kiem-tra.mjs`: 0 lỗi.

## Lỗi nghiêm trọng đã sửa (3)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b24 Ví dụ 3 (K + nước) | Trùng với Ví dụ 5 của b19: cùng dạng bài "V(H~2~) và C%", cùng 0,2 mol kim loại → **2,479 L**. | Đổi thành 9,75 g K và 90,5 g nước → 0,125 mol H~2~ → **3,10 L**, dung dịch 100 g, **14%** KOH. |
| b24 `q28` (short, viên sủi) | Lộ đáp số. Đề dùng 0,015 mol CO~2~ → **372** mL, trùng chữ số với Ví dụ 5 của bài (15 kmol Cl~2~ → 372 m^3^). | Đổi thành 1,47 g NaHCO~3~ → 0,0175 mol → **434** mL. |
| b24 `q14` (mcq, Na + nước) | Đáp án 1,240 L (0,05 mol khí) trùng với Ví dụ 8 (1), cũng 0,05 mol CO~2~ → 1,24 L. Nhiễu 2,479 L trùng đáp số Ví dụ 3 cũ và b19. | Đổi thành 2,53 g Na → 0,055 mol H~2~ → **1,363 L**. Nhiễu: 2,727 (quên chia 2), 1,232 (dùng 22,4), 0,682 (nhầm tỉ lệ 4 : 1). |

## Lỗi nhỏ đã sửa (10)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b24 mục 1.4a "Dùng E° để giải thích" | Viết "mọi kim loại có E° < −0,414 V đều có thể khử nước ở điều kiện thường". Câu này mâu thuẫn với Bài 19 và Bài 15, vì Mg, Al, Zn, Fe thực tế không phản ứng. | Viết lại: về lí thuyết thì khử được nước. Mg, Al, Zn, Fe bị lớp oxide/hydroxide che phủ. Kim loại kiềm có MOH tan nên phản ứng ngay. Dẫn đúng sang Bài 19 mục 2.2. |
| b24 `q21` ý d (Solvay) | Giá trị đúng 11,7 tấn NaCl trùng số liệu 11,7 tấn NaCl ở b26 `q24`. | Đổi thành 8,48 tấn Na~2~CO~3~ → **9,36 tấn** NaCl (ý sai: 4,68 tấn). Ý vẫn Sai. |
| b24 cathode thùng điện phân (mục 2.2a, Hình 2, `q19`) | Ghi "thép". SGK tr. 113 ghi cathode bằng sắt. | Sửa thành "sắt" ở bai.md, `dien-phan.svg` và đề `q19`. |
| b24 mục 1.3a | Câu "Cs cầm lâu trong lòng bàn tay là chảy ra (nếu có lớp bảo vệ)" tối nghĩa, dễ hiểu thành cầm Cs trần. | Viết lại: ống thuỷ tinh hàn kín đựng Cs, cầm trong tay một lúc thì Cs chảy lỏng. |
| b24 khung "Sản phẩm cháy thật sự" | Có thêm ý mở rộng. | Nội dung Na~2~O~2~ và KO~2~ **đúng**: khi đốt trong oxygen dư, Li cho Li~2~O, Na cho chủ yếu Na~2~O~2~, K cho KO~2~. Khung đã có nhãn ngoài SGK. Chỉ sửa chữ "oxygen dư" thành "oxygen (dư)" cho rõ. |
| b24 độ dài | Khoảng 6 490 chữ, có vài phần lặp. | Bỏ khung "Thuốc muối giảm đau dạ dày" (ngoài SGK, là lời khuyên y tế, lặp bảng ứng dụng). Gộp khung bẫy ở mục Bảo quản (ý 2 lặp đoạn giải thích ngay trên). Gộp khung bẫy ở Dạng 3 (lặp khung mẹo). Rút danh sách "Các tỉ lệ" ở Tóm tắt thành 1 dòng. Còn 6 396 chữ theo `wc`, đủ nội dung SGK. |
| b25 khung bẫy nitrate | Viết "KNO~3~ → KNO~2~ + ½O~2~, xem Bài 24". Bài 24 không có phản ứng này. | Ghi "mở rộng, ngoài SGK". |
| b25 mục 1.5 và mục 2.3 | Ý "hợp kim Cu – Be làm mỏ lết không phát tia lửa" và đoạn vai trò calcium (co cơ, đông máu, còi xương) chưa có nhãn ngoài SGK. Câu "thiếu calcium gây còi xương" viết quá tuyệt đối. | Thêm nhãn "mở rộng". Sửa thành "góp phần gây còi xương". Nối với câu hỏi 3 SGK. |
| b25 `q19` ý d, lời giải thích | Câu "thậm chí Ca^2+^ thêm vào cũng nằm lại trong nước" không đúng: Ca(OH)~2~ vừa đủ thì phần Ca^2+^ thêm vào cũng kết tủa. | Sửa thành: phần cứng vĩnh cửu (Ca^2+^, Mg^2+^ ứng với SO~4~^2−^) vẫn còn. Ý vẫn Sai. |
| b25 độ dài | Khoảng 6 940 chữ. Có phần lặp: khung nền tảng lặp Bài 24, khung ghi nhớ "Quy tắc SGK" lặp đoạn ngay trên, khung bẫy BaCl~2~ độc lặp lưu ý trong thí nghiệm, khung "Thổi CO~2~" lặp `q13` và Dạng 2, khung mẹo màu ngọn lửa dài. | Rút gọn hoặc gộp các phần lặp vào đoạn văn. Còn 6 870 chữ theo `wc`. Không cắt nội dung SGK. |

## Các chỗ người soạn chưa chắc: đã kiểm, đúng

- **Na~2~O~2~ và KO~2~** (b24): đúng, khung đã có nhãn ngoài SGK. Bài tập vẫn dùng dạng chung 4M + O~2~ → 2M~2~O, không mâu thuẫn với đề.
- **Nhỏ acid từ từ vào carbonate** (b24 Dạng 2, Ví dụ 8, `q26`): đúng.
  - CO~3~^2−^ chuyển hết thành HCO~3~^−^ trước, sau đó mới có khí.
  - Nhỏ ngược lại (carbonate vào acid) thì có khí ngay, n(CO~2~) = n(H^+^) : 2 khi acid thiếu.
  - Ví dụ 8: 1,24 L và 1,86 L. `q26`: 1,49 L.
- **Mg(HCO~3~)~2~ + 2Ca(OH)~2~ → Mg(OH)~2~↓ + 2CaCO~3~↓ + 2H~2~O** (b25): phương trình đã cân bằng và đúng hoá học, vì Mg(OH)~2~ khó tan hơn MgCO~3~. Bài có ghi chú rằng một số tài liệu viết MgCO~3~ + CaCO~3~ (tỉ lệ 1 : 1). Không câu quiz nào phụ thuộc vào tỉ lệ này. Giữ nguyên.
- **NaOH làm mềm nước cứng tạm thời** (b25 `q22`, đáp số 4): đúng.
  - Cơ chế: OH^−^ + HCO~3~^−^ → CO~3~^2−^, rồi CO~3~^2−^ kết tủa Ca^2+^, Mg^2+^. Đây cũng là đáp án quen thuộc trong đề thi.
  - 4 chất làm mềm được: Ca(OH)~2~, NaOH, Na~2~CO~3~, Na~3~PO~4~.
  - HCl, NaCl, Na~2~SO~4~ không làm mềm được.

## Đã kiểm, không có lỗi

- **Kiến thức khớp SGK.**
  - b24: Bảng 24.1 và 24.2 chép đúng số. Ba thí nghiệm với nước, Cl~2~, O~2~. Cách bảo quản (Na, K trong dầu hoả; Rb, Cs trong ống hàn kín). Màu ngọn lửa đỏ tía / vàng / tím nhạt. Ứng dụng NaCl. Điện phân có và không có màng ngăn. Số liệu Hình 24.4 (300 g/L, 200 g/L, 32%). NaHCO~3~ phân huỷ ở khoảng 120 °C. Ứng dụng Na~2~CO~3~. Hai giai đoạn Solvay. Câu hỏi 4a, 4b.
  - b25: Bảng 25.1, 25.2, 25.3, bảng độ tan, Bảng 25.4 (T/I/K). Thí nghiệm CaSO~4~/BaSO~4~ với CuSO~4~. Màu ngọn lửa đỏ cam / đỏ son / lục. Δ~r~H° carbonate và nitrate. Thí nghiệm nhận biết ion. Bảng 25.5. Ba loại tính cứng. Tác hại của nước cứng. Phương pháp kết tủa và trao đổi ion (cationite).
- **Ví dụ b24**: Ví dụ 5 1 200 kg và 372 m^3^. Ví dụ 6 Na/K 37,1% và 200 mL. Ví dụ 7 61,3%. Ví dụ 8 1,24 L / 1,86 L. Ví dụ 9 4,24 tấn.
- **Ví dụ b25**: Ví dụ 2 Ca. Ví dụ 3 90 g. Ví dụ 6 54,3%. Ví dụ 7 4 g, tăng 3,04 g. Ví dụ 8 2,65 g và 0,010 mol.
- **Đáp án b24**:
  - mcq: `q15` 15,9 g (nhiễu 31,8; 9,3; 12,6). `q16` M̄ = 19 → Li, Na (0,05 / 0,15 mol).
  - tf: `q18` 0,124 L. `q19` 72 kg. `q20` 12,4 g. `q21` 9,36 tấn (mới).
  - short: 3; 12; 13; 3; 1,49; 340; 434 (mới); 252.
- **Đáp án b25**:
  - mcq: `q15` 7,65 g (nhiễu 11,45 / 8,45 / 6,85 đều ứng với lỗi điển hình).
  - tf: `q18` 0,1 g. `q19` 0,001 mol; 1,06 g. `q20` 1,792·10^6^ kJ; 8,8 g; 37,22 kJ.
  - short: 2; 4; 0,74; 2,97; 3,7; 19,4; 69; 28.
- **Hình thức quiz.**
  - Không gọi phương án bằng chữ A/B/C/D. Đáp số short ≤ 4 ký tự, các câu cần làm tròn đều ghi rõ.
  - Số câu: b24 có 16 mcq, 5 tf, 8 short. b25 có 15 mcq, 5 tf, 8 short.
  - Vị trí đáp án mcq: b24 4/4/4/4, b25 4/3/4/4.
  - Số câu có đáp án đúng là phương án dài nhất: b24 4/16, b25 2/15.
- **Hình.** 7 hình đều đúng khoa học, có `<title>`, chữ ≥ 12 px, không có chữ chồng chữ.
  - Ở hình chu trình calcium, script báo hai nhãn "+ H~2~O" và "(toả nhiệt)" chạm khung nhau. Xem ảnh thì hai nhãn nằm trên hai dòng, không đè nhau.
  - Hình rộng 540 hiển thị trong khung vuốt ngang có nhắc "vuốt ngang", giống các bài đã duyệt.
- **Bản quyền.** Không có đoạn chép nguyên văn SGK.

## Góp ý chưa sửa

1. Sau khi rút gọn, hai bài vẫn dài (6 396 và 6 870 chữ theo `wc`, có tính markup). Lý do: SGK có 8 trang và 10 trang, mỗi bài có 4 dạng bài. Phần còn lại không lặp nhiều nên không cắt thêm.
2. **b26 (Ôn tập chương 7), không thuộc phạm vi đợt này**: Ví dụ 1 của b26 có 2,479 L H~2~, trùng đáp số Ví dụ 5 của b19. Người thẩm định b26 nên xem lại.
3. b25 `q24` có nhắc trường hợp V nhỏ nhất ≈ 1,98 L (trùng số với Ví dụ 8 của b16). Đây chỉ là ghi chú trong lời giải, không phải đáp án, nên giữ.
4. b25 mục 2.1 ghi ngưỡng "S < 0,01: không tan", trong khi SGK xếp MgCO~3~ (0,01) vào loại không tan. Bài đã có khung bẫy nói rõ "làm bài theo Bảng 25.4", nên giữ.
