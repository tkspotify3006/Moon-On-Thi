# Biên bản thẩm định — Toán 12 đợt 7b (b18, b19, on-6)

Ngày: 2026-10-29 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi gồm 3 bài, đều là chương VI SGK Toán 12 tập 2:
- `content/lop-12/toan/b18`: Bài 18 Xác suất có điều kiện, SGK tr. 64–71 (PDF 65–72).
- `b19`: Bài 19 Công thức xác suất toàn phần và công thức Bayes, tr. 72–78 (PDF 73–79).
- `on-6`: Bài tập cuối chương VI, tr. 79–80 (PDF 80–81).

## 1. Cách kiểm
- Đọc lại toàn bộ 17 trang SGK. Đối chiếu như sau:
  - Định nghĩa và công thức $P(A\mid B)$ (tr. 65).
  - Ví dụ 2 về tính độc lập và bảng $2\times2$ dây an toàn (tr. 66–67).
  - Công thức nhân (tr. 68), sơ đồ cây (tr. 69), Ô cửa bí mật (tr. 69–70), Em có biết về Bayesian updating (tr. 71).
  - Công thức xác suất toàn phần (tr. 72), Vận dụng đậu Hà Lan (tr. 74), công thức Bayes và ý nghĩa của nó (tr. 75), Ví dụ 4 về âm tính (tr. 77).
  - Bài tập 6.1–6.21.
  Các số trang `(SGK tr. X)` trong 3 bài đều đúng.
- Giải lại toàn bộ **88 câu** bằng `fractions` (b18: 28 câu, b19: 28 câu, on-6: 32 câu), gồm mọi phương án nhiễu có giải thích và từng ý tf.
  - Đã giải lại mọi ví dụ trong 3 bai.md: b18 Ví dụ 1–11, b19 Ví dụ 1–10 và phần xét nghiệm lần hai, on-6 Ví dụ 1–5.
  - Đã giải lại đáp số T1–T6.
  - Câu bốc thăm (b18 q28) và các câu xúc xắc được kiểm bằng cách liệt kê toàn bộ không gian mẫu.
  - Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-7b/kt.py`, kết quả 0 FAIL.
- Thống nhất kí hiệu giữa 3 bài theo SGK:
  - Giao của hai biến cố viết $AB$ (SGK không dùng $\cap$ trong công thức). Riêng b18 và b19 có một dòng nhắc "(hay $A\cap B$)".
  - Biến cố đối dùng gạch trên $\overline{A}$.
  - Xác suất có điều kiện viết `\mid`.
  - Công thức toàn phần viết $P(B)=P(A)\cdot P(B\mid A)+P(\overline{A})\cdot P(B\mid\overline{A})$.
  - Thuật ngữ độ nhạy $P(B\mid A)$, độ đặc hiệu $P(\overline{B}\mid\overline{A})$ và dương tính giả $P(B\mid\overline{A})=1-$ độ đặc hiệu đều đúng, thống nhất ở b18, b19 và on-6 (bảng thuật ngữ mục 2.4).
- Soát trùng số liệu theo 4 hướng: ví dụ ↔ quiz trong từng bài, quiz ↔ quiz, on-6 ↔ b18/b19, cả 3 bài ↔ SGK.
- Render 10 hình SVG ở cả nền sáng và nền tối bằng Playwright, tự xem ảnh. Không có chữ nhỏ hơn 12px, viewBox rộng ≤ 560.
- Mở 3 bài và 3 quiz trong app: bản sao repo có bật `ready`, cổng 8932, khung 390×844, mở hết các khung gợi ý/lời giải. Render đề, phương án, ý tf và lời giải của cả 88 câu trong khung 358px.
- `node scripts/kiem-tra.mjs`: **0 lỗi**.

## 2. Kết quả
**Không có đáp án sai** (88/88), không có lỗi tính toán trong ví dụ và đáp số tự luyện. Kiến thức đúng SGK. Lỗi đáng kể chủ yếu là lộ đáp số, trùng SGK và một lỗi hiển thị hàng loạt ở on-6.

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| on-6 quiz, 27 lời giải | Xuống dòng bị ghi thành chuỗi `\\n` (dấu gạch chéo ngược và chữ n thật). Kiểm trong app thấy hiện nguyên văn "\n\n", và **công thức sau đó không được render** (lộ mã `$0{,}09$`). | Đổi mọi `\n` không thuộc lệnh LaTeX (`\ne`, `\neq`) thành xuống dòng thật. Kiểm lại: không còn `$` hay `\n` lộ ra. |
| b18 q12 | Đúng đề và đáp số $\frac{5}{28}$ của khung Mẹo (5 đỏ, 3 xanh, lấy 3 viên) trong bai.md, nên lộ đáp số. | Đổi thành 7 đỏ, 3 xanh: $\frac7{24}$. Các nhiễu: $\frac{343}{1000}$ (lấy có hoàn lại), $\frac1{120}$ (cả ba xanh), $\frac7{15}$ (mới tính hai lần lấy). |
| b18 q15 | Ô cửa bí mật lặp đúng tình huống và đáp số $\frac23$ của mục 2.3. | Đổi thành chọn cửa 3, quản trò mở cửa 2, hỏi xác suất thắng nếu giữ nguyên: $\frac13$. Lời giải đi lại các bước. |
| b18 q23 | 7 đỏ, 5 vàng, hỏi "khác màu" ($\frac{35}{66}$): đúng số liệu SGK HĐ1/Ví dụ 4 (7 xanh, 5 đen) và là phần bù của Luyện tập 4b. | 7 đỏ, 4 vàng: $\frac{28}{55}\approx0{,}51$. Bẫy chỉ tính một thứ tự cho $\approx0{,}25$. |
| b18 q26 | $x$ xanh và 4 đỏ, xác suất $\frac13$, ra $x=6$ và tổng 10 viên: đúng cấu hình SGK Bài tập 6.6 (6 kẹo cam, $\frac13$, ra 10 kẹo). | 3 đỏ, xác suất $\frac7{15}$: $4x^2-25x-21=0$, $x=7$. |
| on-6 Ví dụ 5, q30 | Bài di truyền liên môn chưa gắn nhãn "mở rộng". | Gắn nhãn ở tiêu đề mục 4.5, ở lời dẫn ("không có trong SGK Toán"), ở khung Ví dụ 5 và ở đầu đề q30: "(Mở rộng, liên môn Sinh học 12)". |
| b19 mục 1.4, Dạng 2, Hình 4, Tóm tắt | Công thức nhiều trường hợp $A_1,A_2,A_3$ chỉ ghi "Mở rộng", chưa nói rõ là ngoài SGK. | Ghi "(mở rộng, ngoài SGK)" ở 4 chỗ này. Thêm ghi chú vào lời giải b19 q18, q22, q23, q28 và on-6 q18, q32 (các câu dùng ba trường hợp). Bảng "Gặp câu hỏi nào" của on-6 cũng có nhãn này. |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| b19 bai.md (khung Nhắc lại, khung Mẹo) và b19 q05, q07, q13, q16 | Viết $P(A\cap B)$, không theo kí hiệu $P(AB)$ của SGK và của b18, on-6. | Đổi thành $P(AB)$ và $P(A\overline{B})$. |
| on-6 bảng mục 1.1 | Công thức toàn phần viết thiếu dấu nhân, khác SGK. | Viết lại $P(A)\cdot P(B\mid A)+P(\overline{A})\cdot P(B\mid\overline{A})$. |
| on-6 lỗi số 9 | "Hai số chỉ bằng nhau khi $P(\overline{A})=1$" chưa đủ (còn trường hợp $P(B\mid\overline{A})=0$). | "Nói chung hai số này khác nhau, vì lá bằng nhánh nhân thêm $P(\overline{A})$". |
| b18 khung Bẫy mục 1.2 | Ví dụ hút thuốc/bị bệnh dùng $P(AB)$, $P(A\mid B)$ mà chưa đặt tên $A$, $B$. | Thêm "Với $A$: bị bệnh, $B$: hút thuốc". |
| b18 q18, q20 | 4/5 câu tf của b18 cùng mẫu Đ-Đ-S-Đ. | q18 ý a đổi thành bẫy "$P(AB)=0{,}2=P(A)P(B)$ khi không độc lập" (Sai). q20 ý b đổi thành bẫy lấy nhánh $0{,}4$ thay cho lá $0{,}08$ (Sai). |
| on-6 q23 | 4 trắng, 2 đen cùng tỉ lệ 2:1 với Ví dụ 2 (6 gừng, 3 bạc hà). Ý b có đáp số $\frac13$ trùng Ví dụ 2c. Cả 5 câu tf đều mở đầu bằng Đúng. | 5 trắng, 2 đen. Ý a là bẫy có hoàn lại $\frac4{49}$ (S). Ý b: $\frac27$ (Đ). Ý c: $\frac16\ne\frac27$ (S). Ý d: $\frac{11}{21}>\frac12$ (Đ). |
| b18 mục 2.3, mục 1.2. on-6 Ví dụ 2c. on-6 q28, q32 | Công thức dòng riêng rộng 362–771px, phải cuộn ngang. | Tách dòng bằng `aligned` hoặc hai `$$`. Kiểm lại, chỉ còn công thức nhân trong khung ghi nhớ của b18 rộng 354px, vượt khung vài px. |

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức. **7 lỗi đáng kể**: 1 lỗi hiển thị hàng loạt (27 lời giải), 2 lỗi lộ đáp số/trùng ví dụ, 2 lỗi trùng SGK, 2 lỗi thiếu nhãn mở rộng/ngoài SGK theo yêu cầu đợt. **8 lỗi nhỏ**.

## 4. Thống kê sau sửa
| Bài | mcq/tf/short | Mức 1/2/3 | Vị trí đáp án mcq | Mẫu Đ/S của các câu tf |
|---|---|---|---|---|
| b18 | 15/5/8 | 11/11/6 | 4/4/4/3 | ĐĐSĐ, ĐĐSS, SĐSĐ, ĐĐSĐ, ĐSSĐ |
| b19 | 15/5/8 | 11/9/8 | 4/4/4/3 | (đa dạng) |
| on-6 | 20/5/7 | 9/12/11 | 5/5/5/5 | ĐSĐS, ĐSSĐ, SĐSĐ, ĐSĐS, ĐSĐS |

Short đều ≤ 4 ký tự, có ghi làm tròn khi cần. Explain không gọi A/B/C/D.

## 5. Hình
10 hình đúng khoa học và sạch ở cả hai nền:
- b18: h1 không gian thu gọn, h2 cây thời tiết, h3 Ô cửa (đường cam đúng hai trường hợp mở cửa 3).
- b19: h1 cây tổng quát, h2 cây xét nghiệm, h3 tần số 10 000 người ($90/585$), h4 ba máy.
- on-6: h1 bản đồ chương, h2 cây bốn lá, h3 biểu đồ Ven sang bảng.

## 6. Góp ý chưa sửa (không phải lỗi)
1. b18 Ví dụ 1 (6 đỏ, 4 xanh) cùng cấu hình bi với SGK 6.15 (6 đen, 4 trắng) nhưng hỏi khác ($P(A\mid B)$, $P(A\mid\overline{B})$), không lộ đáp số SGK.
2. Tỉ lệ "đáp án đúng là phương án dài nhất" (tính cả trường hợp dài bằng nhau): b19 5/15, on-6 7/20. Nhiều câu có phương án là số cùng độ dài nên chấp nhận được.
3. b19 q20 ý d ($\frac{15}{23}\approx0{,}652$ so với ngưỡng $0{,}65$) có biên sát nhưng đúng.
