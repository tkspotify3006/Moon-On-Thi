# Biên bản thẩm định Hóa 12: b23 (Ôn tập chương 6), b26 (Ôn tập chương 7)

- b23: SGK tr. 106–107 (PDF 108–109). Bài lẻ của chương: b18–b22.
- b26: SGK tr. 126–127 (PDF 128–129). Bài lẻ của chương: b24, b25. Đã đọc lại SGK Bài 24, 25 (PDF 110–127) để đối chiếu bảng số liệu.

Ngày 29/10/2026.

Cách kiểm:
- Đối chiếu bai.md với trang "Hệ thống hoá kiến thức" và "Luyện tập" của SGK. Đối chiếu số liệu với Bảng 24.1, 24.2, 25.1, 25.2, 25.3, 25.4, bảng Δ~r~H° nhiệt phân và bảng ứng dụng 25.5.
- Giải lại độc lập toàn bộ ví dụ và quiz (b23: 33 câu, b26: 33 câu) bằng python/sympy (`scratchpad/rv-hoa-on67/kt.py`). Đếm lại các câu "có bao nhiêu".
- Dò số liệu trùng với bai.md và quiz.json của b15–b22 (b23) và b24, b25 (b26).
- Kiểm tra mọi câu dẫn chéo "Bài X mục Y / Ví dụ / Dạng" tới đúng mục hiện có.
- Render 5 hình SVG bằng Playwright, đo cỡ chữ nhỏ nhất, xem từng ảnh.
- Mở 2 bài và 2 quiz trong app (390×844, bản sao repo có bật `ready`, cổng 8811): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390, không có ảnh hỏng.
- `kiem-tra.mjs`: 0 lỗi (repo thật và bản sao bật `ready`).

## Lỗi nghiêm trọng đã sửa (3)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b23 `q30` (short, thanh Ni nhúng vào AgNO~3~) | Lộ đáp số. 0,02 mol Ni → 0,04 mol Ag = 4,32 g trùng đúng số liệu của b17 `q16` (pin Ni – Ag, cathode tăng 4,32 g, n(Ni) = 0,02). | Đổi thanh sau phản ứng thành 24,71 g → x = 0,03 mol → **6,48** g Ag. Thêm bẫy: quên hệ số 2 ra 10,38 g. |
| b26 `q25` ý 4 (hấp thụ CO~2~ vào dung dịch K, Ba) | Trùng số liệu với `q18` cùng bài: cùng n(Ba^2+^) = 0,04, cùng đáp số 0,03 mol BaCO~3~ = 5,91 g và cùng con số nhiễu 7,88 g. Làm `q18` xong là biết ý này. | Đổi thành 0,145 mol CO~2~, phát biểu "khối lượng kết tủa lớn hơn 7 g". Giải: n(CO~3~^2−^) = 0,035 < 0,04 → 6,90 g < 7 g → **Sai**. Lấy theo Ba^2+^ (7,88 g) sẽ chọn nhầm Đúng. |
| b26 `q29` (short, CaCO~3~ + KHCO~3~ với HCl) | Lộ số liệu. 15 g → 0,15 mol CO~2~ → 3,72 L, chính là 3,7185 L CO~2~ (0,15 mol) của Ví dụ 1 trong bài. | Đổi thành 18 g → 0,18 mol → **4,46** L (không trùng b24, b25). |

## Lỗi nhỏ đã sửa (7)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b23 Hình 2 (`truc-e.svg`) | Trục ghi "E° tăng dần" nhưng xếp K, Na, Ca. Theo E° (b15): K −2,924 < Ca −2,84 < Na −2,713. | Đổi thành K, Ca, Na. Các thanh màu không đổi vì đều phủ cả ba ô đầu. |
| b23 `q07` (magnetite) | Lời giải không ghi magnetite và siderite là ngoài bảng SGK (b20 đã ghi). | Ghi rõ "không có trong bảng SGK nhưng đề thi hay nhắc tới". |
| b26 mục 1.1 ý 2 và Hình 1 | Viết "liên kết kim loại yếu → mềm, **nhẹ**, dễ nóng chảy". SGK tr. 110 giải thích khối lượng riêng nhỏ là do bán kính lớn và mạng tinh thể kém đặc khít, không phải do liên kết yếu. | bai.md: tách ý "bán kính lớn, mạng kém đặc khít → nhẹ (Bài 24 mục 1.3)". Hình 1: dòng dưới "Liên kết kim loại yếu" còn "mềm, nóng chảy thấp". |
| b26 `he-thong.svg`, `lien-ket.svg` | 6 dòng chữ cỡ 11–11,5 px, dưới mức 12 px. | Nâng lên 12 px. Bỏ "↓" ở dòng Ca^2+^ + CO~3~^2−^ → CaCO~3~ cho vừa khung. Đã render lại, không có chữ chồng. |
| b26 `q24` ý 1 | "cathode bằng thép". SGK tr. 113 ghi cathode bằng sắt. | Sửa thành "sắt". |
| b25 bai.md, khung bẫy nitrate (dẫn chéo do người soạn báo) | Dòng "KNO~3~ → KNO~2~, xem Bài 24" dẫn tới nội dung Bài 24 không có. | Khi tôi mở file (09:11), dòng này **đã được sửa** thành "(… mở rộng, ngoài SGK)" và không còn "xem Bài 24". Tôi không sửa thêm để tránh ghi đè. |
| b25 (ghi chú, không sửa) | `q` về Ba(NO~3~)~2~ trong b25/quiz.json còn câu "như KNO~3~ của nhóm IA". Lời này chỉ nằm trong phần giải thích bẫy. | Ngoài phạm vi được giao, chỉ ghi lại. |

## Đã kiểm, không có lỗi

- **Kiến thức b23 khớp SGK tr. 106** và các bài lẻ: 1–3 e lớp ngoài; mô hình ion dương ở nút mạng + electron tự do; 4 tính chất vật lí chung; tính khử với phi kim, nước, acid, muối; M^n+^ + ne → M; điện phân nóng chảy cho kim loại mạnh, nhiệt luyện / điện phân dung dịch / thuỷ luyện cho kim loại trung bình, yếu; hợp kim (gang 2–4% C, thép < 2% C, inox ≥ 10% Cr, duralumin, Au – Cu 8–12% Cu); ăn mòn hoá học và điện hoá (3 điều kiện); 2 phương pháp chống ăn mòn. Các phần ngoài SGK (Fe → Fe^3+^ trong H~2~SO~4~ đặc nóng, magnetite) có nhãn.
- **Kiến thức b26 khớp SGK tr. 126** và Bảng 24.1–25.4: E° nhóm IIA −1,99 đến −2,92 V; t~nc~ Cs 28,4 → Li 180,5 °C; Mg 651, Be 1 287 °C; D: K 0,89 < Na 0,968, nhóm IIA 1,55–3,51; bảng tính tan T/I/K đúng 4 hàng của Bảng 25.4 (hàng HCO~3~^−^, Cl^−^ và cột IA có ghi là tổng hợp ngoài bảng); màu ngọn lửa 6 ion; Δ~r~H° MgCO~3~ 100,7 → BaCO~3~ 271,5; NaHCO~3~ phân huỷ khoảng 120 °C; điện phân có và không có màng ngăn (Javel); Solvay; nước cứng 3 loại, 2 phương pháp làm mềm. Khung "xút hoá soda" có nhãn ngoài SGK.
- **Đối chiếu Luyện tập SGK**: b23 có Ví dụ 5–8 tương tự Câu 1–5 (đổi chất, đổi số). b26 có hướng dẫn Câu 1–7 và Ví dụ 3, 5 tương tự Câu 6, 7. Không chép nguyên đề.
- **Ví dụ b23**: VD1 21 g, 9,44 g, 2,479 L, 3,84 g, 0,21 mol SO~2~ (bẫy 0,15 và 0,16); VD2 giảm 0,72 g (chỉ CuSO~4~ tăng 0,4 g); VD3 0,525 tấn gang, 0,507 tấn thép, 18,5 kg C; VD5 3 ý đúng; VD6 Cu, Ag và (2), (4); VD7 Ni^2+^/Ni < Cu^2+^/Cu < Fe^3+^/Fe^2+^ < Ag^+^/Ag.
- **Ví dụ b26**: VD1 0,1 mol Na, 0,05 mol Ba, 9,85 g, không có thêm kết tủa; VD2 62,7%, 10 g CaCO~3~; VD3 504 kg CaO, 98 kg than, 17,2 kmol CO~2~ (≈ 426 m^3^), than chiếm ≈ 48%; VD4 Đ-S-Đ-S (Na m/46 < Ca m/40).
- **Đáp án b23**: mcq tính toán `q16` 44,0% (nhiễu 56,0; 62,7 khi cho Fe^3+^; 38,0 khi dùng 22,4), `q17` 0,4 mol (0,1 Fe~2~O~3~ + 0,1 CuO), `q18` 0,4% thép (nhiễu 1,47% = m CO~2~), `q19` 1,12 g (FeCl~2~ ra 1,68; n(Fe) = n(Cl) ra 3,36), `q20` không còn chất rắn. tf `q24` 1,24 L SO~2~, 10,8 g Ag; `q25` 500 mol e. short 5; 5; 4; 4; 6,48 (mới); 1,8; 11,9; 2,4 (bỏ Fe^3+^ ra 2,96).
- **Đáp án b26**: mcq `q16` 220 mL (nhiễu 170, 110, 440), `q17` 9,3 g (12,4; 10,2), `q18` 5,91 g (7,88; 13,79), `q19` 3,28 g (4,92; 3,18), `q20` 7,80 tấn (4,39; 3,90; 5,85). tf `q23` 1 120 kg, 3 584 000 kJ; `q24` 3,2 tấn NaOH, 3,71 tấn soda, 992 m^3^ Cl~2~; `q25` 0,1 mol K, 0,04 mol Ba, 9,32 g BaSO~4~, 6,90 g (mới). short 3; 3; 12,9; 4,46 (mới); 13,3; 347; 173; 2.
- **Dẫn chéo đúng mục**: b23 tới Bài 18 mục 1.2; Bài 19 mục 1.1–1.4, 2.1–2.4 (2.3a, 2.3b), Dạng 1–2; Bài 20 mục 1.2, 2.2, 2.3a–c, 3, Dạng 2–3; Bài 21 mục 2, 2.1, 3.1, Dạng 2–3; Bài 22 mục 1.2, 1.3, 2, 2.1, Ví dụ 1, Dạng 3; Bài 17. b26 tới Bài 24 mục 1.1–1.5, 2.1, 2.2a–b, Ví dụ 6, 8, Dạng 1–3; Bài 25 mục 1.1–1.5, 2.1, 2.2a, 2.3, 3.3, Dạng 1–3 (kiểm lại sau khi b24, b25 được sửa song song).
- **Hình**: b23 Hình 1 (hệ thống hoá, hai chiều khử ion / oxi hoá kim loại), Hình 2 (dãy E° với các thanh phạm vi: nước, H^+^, các phương pháp tách, đơn chất, hi sinh / gỉ nhanh hơn với mốc Fe). b26 Hình 1 hệ thống, Hình 2 màu ngọn lửa 6 ion, Hình 3 liên hệ Solvay – vòng calcium – làm mềm nước. Đúng khoa học, không chữ chồng, có `<title>`, viewBox rộng 540.
- **Hình thức quiz**: mỗi bài 20 mcq, 5 tf, 8 short (≈ 61% mcq); vị trí đáp án 5/5/5/5; đáp án là phương án dài nhất ở 4/20 (b23) và 3/20 (b26); không gọi A/B/C/D; short ≤ 4 ký tự, có ghi làm tròn; mức độ b23 10/12/11, b26 10/13/10.

## Góp ý chưa sửa

1. b23 dài 6 750 chữ, b26 khoảng 6 000 chữ (theo `wc`). Tương đương b17 (Ôn tập chương 5, 5 900) và các bài lẻ cùng chương. Nội dung không lặp nhiều, nên giữ.
2. b23 `q33` cùng dạng với Ví dụ 2 (Fe vào dung dịch Fe^3+^ + Cu^2+^) nhưng số liệu và đáp số khác (2,4 g so với giảm 0,72 g). Đây là luyện cùng dạng, không lộ đáp số.
3. b26 `q28`, `q30` (pH) và `q30` (It/F, Bài 16) dùng kiến thức lớp 11 và chương 5. Câu hợp với bài ôn tổng hợp, nên giữ.
4. Trong bảng 4–5 cột ở mục 1.2 của b26, bảng rộng hơn khung 7 px và cuộn ngang trong khung. Trang không cuộn ngang (`scrollWidth` = 390).
