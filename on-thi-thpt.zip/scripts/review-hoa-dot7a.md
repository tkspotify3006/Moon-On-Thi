# Biên bản thẩm định Hóa 12 (đợt 7a): b17, b19

- b17: Ôn tập chương 5 (SGK tr. 85–86, PDF 87–88). Bài lẻ của chương: b15, b16.
- b19: Tính chất vật lí và tính chất hoá học của kim loại (SGK tr. 89–93, PDF 91–95).

Ngày 29/10/2026.

Cách kiểm:
- Đọc lại từng trang SGK của hai bài và đối chiếu với bai.md: thuật ngữ, số liệu (D, t°nc, E°), thí nghiệm, số trang được dẫn.
- Giải lại độc lập toàn bộ quiz (b17: 33 câu, b19: 28 câu) và mọi ví dụ có số liệu bằng python (`scratchpad/rv-hoa-7a/kt.py`). Đếm lại các câu "có bao nhiêu".
- Đối chiếu số liệu b17 với ví dụ và quiz của b15, b16. Đối chiếu giữa các câu trong cùng quiz và với ví dụ trong bài.
- Render 6 hình SVG bằng Playwright và tự xem từng hình. Cỡ chữ từ 12 đến 20, mỗi hình có `<title>`.
- Mở 2 bài và 2 quiz trong app (390×844, bản sao repo, cổng 8933): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390.
- `kiem-tra.mjs`: 0 lỗi (cảnh báo "chưa ready" là bình thường).

## Lỗi nghiêm trọng đã sửa (3)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b17 Ví dụ 1 (mục 5.1) | Dùng **một** pin Zn – Cu (khoảng 1,1 V) làm nguồn để điện phân dung dịch NaCl. Điều này sai khoa học: phản ứng 2NaCl + 2H~2~O → 2NaOH + H~2~ + Cl~2~ cần ít nhất khoảng 2,2 V theo lí thuyết, thực tế còn cao hơn. Ví dụ 3 của chính bài cũng nói điện phân phải dùng hiệu điện thế lớn hơn E°~pin~ của phản ứng ngược, nên hai ví dụ mâu thuẫn nhau. | Đổi thành bộ 3 pin Zn – Cu mắc nối tiếp (khoảng 3,3 V), mỗi thanh Zn giảm 1,3 g. Đáp số giữ nguyên (n~e~ = 0,04 mol, mỗi thanh Cu tăng 1,28 g, mỗi khí 0,50 L, 0,04 mol NaOH). Thêm đoạn "Vì sao cần 3 pin?" (ghi mở rộng, ngoài SGK). Gợi ý 2 thêm bẫy "không nhân 3". Khung mẹo về mạch nối tiếp sửa theo. (`q24` dùng một pin để điện phân AgNO~3~ thì khả thi, nên giữ.) |
| b19 `q26` (short, tìm M từ SO~2~) | Lộ đáp số: đề cho 3,7185 L SO~2~, đúng bằng thể tích H~2~ chưa làm tròn trong lời giải `q24` (đáp số 3,72). Học sinh làm `q26` trước sẽ thấy đáp số của `q24`. | Đổi số liệu: 11,7 g M, 4,4622 L SO~2~ (0,18 mol). Đáp số vẫn là **65** (Zn). |
| b19 `q22` (short, đếm kim loại tác dụng mạnh với nước) | Tiêu chí "tác dụng **mạnh** với nước" hiểu được hai cách. Li phản ứng êm hơn Na, K nhiều, nên có học sinh không tính Li và ra 3. Ngược lại, theo E° (< −0,414 V) thì Al, Zn, Fe "có thể khử nước", nên có học sinh tính cả những kim loại này. | Đề sửa thành: "Ở nhiệt độ thường, có bao nhiêu kim loại **tan được trong nước, giải phóng khí H~2~ và tạo thành dung dịch base**?" Đáp số vẫn là 4 (Li, Na, K, Ba). Explain nói rõ vì sao Al, Zn, Fe tuy có E° < −0,414 V nhưng không tính. |

## Lỗi nhỏ đã sửa (9)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b17 `q10` | Phương án đúng dài nhất rõ rệt (59 ký tự, các phương án nhiễu 34–46). | Viết dài thêm ba phương án nhiễu (47/69/54). |
| b17 `q04` | Đề nói Mg "chỉ điều chế được bằng điện phân nóng chảy". Câu này tuyệt đối quá, vì Mg còn được sản xuất bằng phương pháp nhiệt. | Đổi đề thành "không thể điều chế bằng điện phân dung dịch muối, mà phải điện phân nóng chảy". Đáp án vẫn là Mg. |
| b17 mục 1.4, bảng ứng dụng | Trên màn 390 px, số "2 050 °C" bị ngắt giữa số. | Dùng dấu cách không ngắt cho "2 050 °C" và "1 000 °C". |
| b19 mục 1.5, khung ứng dụng W | Ghi "điện cực que hàn, đầu mũi tên lửa". Que hàn thường là thép. Ứng dụng tên lửa chưa chắc. | Đổi thành "điện cực hàn hồ quang trong khí trơ, một số chi tiết phải chịu nhiệt độ rất cao". |
| b19, Fe(III) với H~2~SO~4~ đặc nóng | Ở mục 2.3b chỉ ghi "mở rộng". Khung bẫy, Dạng 1 bước 2 và bảng Tóm tắt chưa có nhãn. | Ghi "ngoài SGK" ở cả 4 chỗ. |
| b19 mục 2.3b | Danh sách "Công thức hay dùng" (H~2~SO~4~ đặc) lặp lại nguyên ý ở Dạng 1 và Tóm tắt. | Rút thành 1 câu, dẫn sang Dạng 1. |
| b19 Dạng 1 | Bước 3–4 lặp các công thức đã có ở mục 2.3. Khung bẫy lặp 2 ý đã nói ở mục 2.3 và bước 1. | Gộp bước 3–4 thành 1 bước. Khung bẫy giữ 2 ý (24,79 L/mol; acid đặc nguội). |
| b19 Dạng 2, Dạng 3, mục 1.4, mục 2.4 | Khung bẫy Dạng 2 lặp bước 1–2 của phương pháp. Danh sách kiểm tra 5 mục ở Dạng 3 lặp bảng Tóm tắt và Hình 3. Mục 1.4 và 2.4 cũng có ý lặp. | Rút gọn: Dạng 2 còn 2 ý bẫy. Dạng 3 chỉ dẫn sang bảng Tóm tắt kèm 4 "chỗ hay bị gài". Mục 1.4 bỏ ý trùng với 1.5. Mục 2.4 gộp ý Na + CuSO~4~. |
| b19, độ dài | Bài dài khoảng 6 800 từ (theo `wc`). | Sau khi rút gọn còn khoảng 6 700 từ. Không cắt ví dụ, vì mỗi ví dụ ứng với một dạng khác nhau. |

## Đã kiểm, không có lỗi

- **b17, khớp SGK tr. 85–86.**
  - Đủ 4 khối hệ thống hoá: cặp oxi hoá – khử, thế điện cực chuẩn, nguồn điện, điện phân.
  - Các bài tập SGK được đặt lại đề và đổi số: Câu 1 thành Ví dụ 5 (Na, Ni, Cu, Zn). Câu 2 (Pb – Zn) thành Ví dụ 6 (Sn – Ni, 0,120 V). Câu 3 (1,056 V) thành Ví dụ 7 (0,936 V → Sn, chọn Fe được 1,239 V).
- **Quy ước thứ tự điện phân thống nhất với b16.**
  - Thứ tự: Au^3+^ > Ag^+^ > Hg^2+^ > Fe^3+^ > Cu^2+^ > H^+^ > Pb^2+^, Sn^2+^, Ni^2+^, Fe^2+^, Zn^2+^ > H~2~O.
  - Đã ghi "quy ước ngoài SGK" ở mục 1.4 (khung bẫy), `q13`, `q25` và bảng Tóm tắt.
- **Nền tảng Vật lí.** Ví dụ 3 dùng W = qU, có khung `[!nen-tang]` (Vật lí 11). Số liệu: W~1~ = 347 kJ, W~2~ = 213 kJ, tỉ lệ ≈ 61%.
- **Đáp án b17.**
  - mcq tính toán: `q12` 1,419 V (nhiễu 1,933 và 2,581 đúng là lỗi điển hình), `q16` 1,18 g, `q17` 3,24 g, `q18` 6,50 g, `q19` Ni, `q20` 3,155 V.
  - tf: `q22` ý Mg – Ni 2,099 V. `q24`: 0,016 mol e; Cu tăng 0,512 g; Ag 1,728 g; O~2~ 0,099 L (ý sai 0,198 L). `q25`: n~e~ = 0,12 mol; Cu 3,2 g (ý sai 4,32 g); O~2~ 0,744 L.
  - short: 3; 4; 0,76; 2,69; 3,47; 74,6; 0,54; 5,65.
- **Ví dụ b17.**
  - Ví dụ 1: 1,28 g; 0,50 L; 0,04 mol.
  - Ví dụ 2: 2,56 g; 1,49 L; 6,82 g.
  - Ví dụ 3: 22,31 L; 11,16 L; 173 700 C; 16,2 g.
  - Ví dụ 4–7: lập luận và phương trình đúng.
- **Không trùng b15/b16.** Đã so mọi số liệu và đáp số. `q33` cùng dạng với Ví dụ 9 của b16 nhưng khác chất (KCl) và số liệu. Các giá trị 1,561 V và 2,696 V có trong b15, nhưng ở b17 chỉ xuất hiện làm phương án nhiễu.
- **Hình thức quiz b17.**
  - Có 20 mcq, 5 tf, 8 short. Mức độ 11/11/11.
  - Vị trí đáp án mcq 5/5/5/5. Vị trí xoay vòng đều, nhưng app có trộn phương án.
- **b19, khớp SGK tr. 89–93.**
  - Số liệu đúng sách: D(Li) = 0,534 g/cm^3^, D(Os) = 22,6 g/cm^3^, W 3 410 °C, Hg −39 °C, mốc 5 g/cm^3^, Cr cứng nhất, thứ tự dẫn điện Ag > Cu > Au > Al, lá vàng 8 nm, E°(H~2~O) = −0,414 V.
  - Ba thí nghiệm SGK được thuật lại bằng lời khác (Mg cháy và Al + S, Zn + H~2~SO~4~ 10%, đinh sắt trong CuSO~4~ 1 M), có ghi trang.
- **Phần ngoài SGK của b19 đúng và có nhãn.** Gồm HNO~3~ (khung "mở rộng ngoài SGK"), Fe(III) với H~2~SO~4~ đặc nóng dư, giải thích tính chất riêng, và số liệu D(Au) = 19,3 g/cm^3^.
- **Đáp án b19.**
  - Ví dụ: 6,5 m^2^; 2,7 g/cm^3^ và 42 lần; Mg và 16,25 g; 2,479 L và 7,66%; 2,4 g, 5,4 g, 36,2 g; 16 g; 9,6 g và 8,4 g; Al và 34,2 g; 12 g và 36 g; 10,2 g. Ví dụ 12 có 5 thí nghiệm.
  - mcq: `q14` 22,8 g (nhiễu 30,0 và 19,05 g), `q15` 13,0 g.
  - tf: `q19` m = 12,9 g; Cu 6,4 g; SO~2~ 4,958 L. `q20`: Cu tan 0,96 g; thanh nặng 22,28 g; thay bằng Fe thì thanh tăng 2,40 g.
  - short: 5; 4; 3; 3,72; 65,9; 65; 10,8; 4,0.
- **Thể tích khí** dùng 24,79 L/mol ở mọi chỗ của cả hai bài.
- **Hình.**
  - b17: Hình 2 có dấu điện cực, chiều electron, khí O~2~ ở anode và Cu bám cathode đều đúng.
  - b19: các hạt electron chuyển dời từ cực âm sang cực dương. Trục E° có −0,414 V nằm giữa Fe và Ni, ngoặc "E° < 0" kết thúc trước H~2~. Δm = +8 g/mol.
  - Không hình nào có chữ chồng chữ.
- **Hình thức quiz b19.**
  - Có 15 mcq, 5 tf, 8 short. Mức độ 10/10/8. Vị trí đáp án 3/4/4/4.
  - Không gọi phương án bằng chữ A/B/C/D, short ≤ 4 ký tự, các câu cần làm tròn đều ghi rõ.

## Góp ý chưa sửa

1. b17 dài khoảng 5 800 từ, nhiều hơn mức 3 500–5 000 của quy chuẩn. Đây là bài ôn chương có 7 ví dụ và nhiều bảng, nội dung không lặp, nên giữ.
2. b19 vẫn khoảng 6 700 từ theo `wc` (có tính markup). Có thể bỏ Ví dụ 13 (Đúng/Sai về đinh sắt, khá trùng với `q10`) nếu muốn ngắn hơn. Tôi giữ lại vì đây là mẫu duy nhất của dạng Đúng/Sai trong bài.
3. b17, bảng ứng dụng 5 cột ở mục 1.4 khá chật trên màn 390 px, nhưng vẫn đọc được và không cuộn ngang.
4. b19 `q17` ý d: Zn + H~2~SO~4~ đặc nóng → SO~2~. Thực tế Zn có thể khử S^+6^ xuống S hoặc H~2~S, nhưng ở mức SGK thì chấp nhận được, nên giữ.
