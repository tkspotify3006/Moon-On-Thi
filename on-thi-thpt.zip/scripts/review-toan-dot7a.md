# Biên bản thẩm định — Toán 12 đợt 7a (on-5)

Ngày: 2026-10-29 · Người thẩm định: Claude (thẩm định độc lập)
Phạm vi: `content/lop-12/toan/on-5` (Ôn tập chương V Phương pháp tọa độ trong không gian, Bài tập cuối chương V SGK T2 tr. 61–63 = PDF 62–64).

## 1. Cách kiểm
- Đọc lại 3 trang Bài tập cuối chương V (5.31–5.52, Hình 5.45). Bảng đối chiếu ở mục 5 đúng số bài và nội dung từng câu SGK. Bài tự luyện T1–T15 và các bài "làm lại" đều đổi số liệu so với SGK. Ví dụ 4 (đáy bể: tam giác đều cạnh 4, độ sâu 1,5/2,1/2,4) và Ví dụ 5 ($B(0;0;2)$) khác số với 5.50 (cạnh 2; 4/4,4/4,8) và 5.52 ($B(1;1;-1)$).
- Giải lại **toàn bộ 33 câu** (20 mcq · 6 tf · 7 short), kể cả mọi phương án nhiễu có giải thích và từng ý tf. Giải lại 5 ví dụ tổng hợp, khung mở rộng (khoảng cách hai đường chéo nhau $7/\sqrt{14}\approx1{,}87$, đường tròn chân trời) và **toàn bộ đáp số T1–T15 cùng 4 bài "làm lại"** bằng numpy/sympy. Script: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-toan-7a/kt.py`.
- Vị trí đáp án mcq: 5/5/5/5. Mức độ: 11/11/11. Mỗi tf có cả Đúng lẫn Sai. Short ≤ 4 ký tự, có ghi làm tròn. Explain không gọi A/B/C/D. Có 1/20 câu mà đáp án đúng là phương án dài nhất duy nhất.
- Soát trùng số liệu: dò tự động mọi điểm, vectơ, phương trình của on-5 trong `bai.md` và `quiz.json` của b14–b17 (`dup.py`, `dup2.py`), xem ngữ cảnh từng chỗ trùng, rồi soát chéo trong nội bộ quiz.
- Các chỗ dẫn chéo ("Bài 14 mục 6", "Bài 15 mục 1.5", "Bài 17 Dạng 2", "Bài 17 Hình 2", "Bài 17 mục 2.2"…) đều khớp đề mục của b14–b17.
- Render 4 SVG (sáng + tối) bằng Playwright và tự xem ảnh. Không có chữ < 12px, viewBox rộng 560. Mở bài và quiz trong app (bản sao repo bật `ready`, cổng 8931, 390×844), mở cả 20 khung gợi ý/lời giải, đo tràn. Render đề, phương án, ý tf và lời giải của cả 33 câu ở khung 358 px. Không `.katex-error`, không lỗi console, `scrollWidth = 390`. Mọi bảng rộng ≤ 358 px.
- `node scripts/kiem-tra.mjs`: **0 lỗi** (cảnh báo on-5 chưa `ready` là bình thường).

## 2. Kết quả
**Không có đáp án sai** (33/33), không có lỗi tính toán trong ví dụ và đáp số tự luyện. Ba phần ngoài SGK (mặt phẳng cắt mặt cầu theo đường tròn, khoảng cách hai đường chéo nhau, hình chiếu của đường thẳng lên mặt phẳng) đều đúng và đã gắn nhãn "mở rộng, ngoài SGK". Vị trí tương đối đường – mặt cũng gắn "(mở rộng)".

## 3. Lỗi đã sửa

### Đáng kể
| Chỗ | Lỗi | Sửa |
|---|---|---|
| quiz q23 (tf) | $(S):x^2+y^2+z^2-4x+2y-6z+5=0$: tâm $(2;-1;3)$, $R=3$, nhiễu $\sqrt{19}$. Đây là **đúng đề b17 q04 đổi dấu**: tâm của q23 trùng phương án nhiễu "quên đổi dấu" của b17 q04, cùng $R=3$, cùng nhiễu $\sqrt{19}$. | Đổi thành $x^2+y^2+z^2-4x-4y+6z+8=0$: tâm $I(2;2;-3)$, $R=3$, nhiễu lỗi dấu $d$ là $R=5$. $IO^2=17>9$ (thay $O$ được $8>0$). $\lvert z_I\rvert=3=R$ nên $(S)$ tiếp xúc $(Oxy)$ tại $(2;2;0)$. Giữ nguyên Đ/S của 4 ý. |
| quiz q28 (short) | Đáp số $70{,}5^\circ$ ($\cos=\frac13$) trùng phương án nhiễu "bấm $\cos^{-1}\frac13$" của q20 (đường ống, $\sin=\frac13$). Làm q20 xong là lộ đáp số q28. | $(Q):4x+3y-2=0$: $\vec n_P\cdot\vec n_Q=-2$, $\cos=\frac{2}{15}$, góc $\approx82{,}3^\circ$ (nhiễu quên trị tuyệt đối $97{,}7^\circ$). Vẫn giữ bẫy "thiếu biến $z$". |

### Nhỏ
| Chỗ | Lỗi | Sửa |
|---|---|---|
| bai.md mục 2.1 (bảng đọc vectơ) | Bảng 4 cột rộng 365 px > 358. Công thức cột đầu bị bẻ 5–6 dòng. | Gộp thành 2 cột "Phương trình → đọc ra" và "Bẫy". Bảng rộng 357 px, công thức dài nhất chỉ bẻ 1 dòng. Nội dung giữ nguyên. |
| bai.md lỗi số 8 | "(SGK Bài tập 5.36 có phương án dùng điểm khác)" không đúng: đáp án của 5.36 viết qua chính $A$, phương án qua $B$ thì sai VTCP. | "ví dụ đường $AB$ viết qua $A$ hay qua $B$ đều đúng, xem bài tự luyện T4 ở mục 5". |
| bai.md Ví dụ 5 | "Vệ tinh **đứng yên** ngay trên cực Bắc": về vật lí không có vệ tinh đứng yên trên cực. | "Tại một thời điểm, một vệ tinh ở vị trí $B$…". Câu c) đổi thành "Tại thời điểm đó, ở Hà Nội có nhìn thấy vệ tinh không?". |
| bai.md mục 2.5 | "tam giác vuông $IHM$": chưa nói $M$ là điểm nào, vuông tại đâu. | "tam giác $IHM$ vuông tại $H$, với $M$ là một điểm bất kì của đường tròn đó". |
| quiz q23 ý d | Nhãn mở rộng chỉ ghi "(mở rộng…)". | "(mở rộng, ngoài SGK, xem mục 2.5)". |
| quiz q32 explain | Công thức dòng riêng rộng 579 px, phải cuộn ngang nhiều. | Tách làm 2 dòng (`aligned`), vừa khung 358 px. |
| h3-day-doi.svg | Chữ "mặt nước" bị cạnh phải của mặt phẳng cắt ngang. | Dời nhãn vào trong mặt phẳng. |
| h4-chan-troi.svg | Nhãn "Hà Nội (21°N)" sát tiếp tuyến $BA$. | Dời sang phải 8 px. |

Các hình còn lại đúng và sạch. h1: bản đồ chương, các mũi tên đúng quan hệ. h2: bốn quan hệ $\vec u\parallel\vec n$, $\vec u\perp\vec n$, $\vec n'=k\vec n$, $\vec n\cdot\vec n'=0$. h3: dây dọi thẳng đứng, đúng độ sâu. h4: $A$ ở $30^\circ$, $OA\perp AB$, $AB=\sqrt3$, Hà Nội ở $21^\circ$ nằm ngoài cung nhìn thấy. Bản tối hiển thị đúng.

**Tổng:** 0 đáp án sai, 0 lỗi kiến thức. **2 lỗi đáng kể** (q23 trùng số liệu với b17 q04; q28 lộ đáp số qua nhiễu q20). **8 lỗi nhỏ**.

## 4. Nội dung, cách giảng
- Đúng khuôn bài ôn chương: ghi nhớ 10 dòng, bản đồ chương, bảng "đề hỏi → công thức", 6 bảng so sánh – phân biệt (đọc vectơ, bảy quan hệ song song – vuông góc, vị trí tương đối, ba công thức góc, mặt cầu, cặp dễ nhầm trong bài thực tế), 18 lỗi sai chia theo bài, 5 bài tổng hợp phối hợp nhiều bài, đối chiếu đủ 22 bài tập SGK 5.31–5.52 kèm bài tự luyện và đáp số.
- Quiz phủ đều Bài 14–17, có 7 câu thực tế/vận dụng cao (q25 drone – mặt kính, q26 mái vòm, q31 hồ bơi, q32 chân trời máy bay, q33 tham số theo góc).

## 5. Góp ý chưa sửa (không phải lỗi)
1. Lời giải q11, q16, q17, q19, q30 và q08, q31 có công thức dòng riêng rộng 381–593 px (chủ yếu là khai triển tích có hướng). Chúng cuộn ngang trong `.katex-display` theo thiết kế chung, trang không tràn. Nếu muốn gọn hơn có thể tách thành từng tọa độ như Ví dụ 4.
2. Vài vectơ "đẹp" độ dài 3 ($(1;-2;2)$, $(2;1;-1)$…) và vài phương án nhiễu có phương trình tình cờ trùng với b14/b16 (ví dụ $x+y-2z+1=0$). Đáp số T9 ($x+2y-2z-8=0$) trùng một phương trình trong b14 Ví dụ 13b nhưng là bài khác hẳn. Không lộ đáp số, chấp nhận.
