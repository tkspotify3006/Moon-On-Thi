# Biên bản thẩm định Hóa 12 (đợt 7b): b20, b21, b22

- b20: Kim loại trong tự nhiên và phương pháp tách kim loại (SGK tr. 94–98, PDF 96–100)
- b21: Hợp kim (SGK tr. 99–101, PDF 101–103)
- b22: Sự ăn mòn kim loại (SGK tr. 102–105, PDF 104–107)

Ngày 29/10/2026.

Cách kiểm:
- Đọc lại từng trang SGK của ba bài, đối chiếu với bai.md: Bảng 20.1, các phương trình, ví dụ, số liệu tái chế, thành phần hợp kim, ba điều kiện ăn mòn điện hoá, hai phương pháp chống ăn mòn.
- Giải lại độc lập toàn bộ quiz (b20: 28 câu, b21: 25 câu, b22: 29 câu) và mọi ví dụ có số liệu bằng python/sympy (`scratchpad/rv-hoa-7b/kt.py`). Đếm lại các câu "có bao nhiêu".
- Đối chiếu số liệu: trong từng bài, giữa ba bài với nhau, và với b16, b19 (bai.md và quiz.json).
- Render 9 hình SVG bằng Playwright và tự xem từng hình.
- Mở 3 bài và 3 quiz trong app (390×844, bản sao repo, cổng 8934): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390, không có ảnh hỏng.
- `kiem-tra.mjs`: 0 lỗi (cảnh báo "chưa ready" là bình thường).

## Lỗi nghiêm trọng đã sửa (2)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b21 `q23` (short, hợp kim Al – Mg – Cu + HCl) | Lộ đáp số. Đề dùng 6,00 g, 0,24 g Cu, 0,315 mol H~2~, tức đúng thành phần 90% Al, 6% Mg, 4% Cu của Ví dụ 5 trong bài (10,00 g), chỉ thu nhỏ theo tỉ lệ. Đáp số 90 có sẵn trong lời giải ví dụ. | Đổi số liệu: 8,00 g hợp kim, 0,50 g chất rắn, 10,1639 L H~2~. Khi đó x = 0,26, y = 0,02, %Al = 87,75 → **88**. |
| b22 `q24` (short, Zn + H~2~SO~4~ có CuSO~4~) | Lộ đáp số. Tỉ lệ n(Zn) : n(Cu^2+^) = 5 : 1 giống Ví dụ 8 của bài (6,5 g Zn, 0,02 mol), và đáp số 0,99 L đúng bằng một nửa đáp số 1,98 L của ví dụ. | Đổi số liệu: 5,85 g Zn, 0,025 mol CuSO~4~ → 0,065 mol H~2~ → **1,61** L. Nếu quên phần Zn khử Cu^2+^ thì ra 2,23 L. |

## Lỗi nhỏ đã sửa (16)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b20 khung "Một số mỏ quặng quan trọng ở Việt Nam" | Chưa ghi là ngoài SGK. Có tên nhà máy (Tân Rai, Nhân Cơ), câu "một trong những mỏ sắt lớn nhất Đông Nam Á" và tên mỏ thiếc cụ thể, khó kiểm chứng sau khi sắp xếp địa giới năm 2025. | Ghi "(tham khảo, ngoài SGK)" và nối với câu hỏi 1b SGK. Bỏ tên nhà máy và tên mỏ thiếc cụ thể, viết thận trọng ("trữ lượng lớn", "vùng Cao Bằng, Nghệ An"). Giữ Thạch Khê (Hà Tĩnh), Sin Quyền (Lào Cai), Bắc Kạn cũ nay thuộc Thái Nguyên. Thêm ghi chú: tên tỉnh theo địa giới sau sắp xếp năm 2025, nên đối chiếu tài liệu địa lí. |
| b20 khung "Con số về tái chế thép (SGK tr. 98)" | Câu "tái chế nhôm chỉ tốn khoảng 5% năng lượng" nằm trong khung ghi nguồn SGK. Con số này không có trong SGK. | Tách khỏi khung SGK, đưa sang khung riêng có nhãn "(ngoài SGK)", viết "nhiều tài liệu quốc tế ước tính khoảng 5%, tuỳ công nghệ". |
| b20 khung làng nghề tái chế (Đa Hội, Văn Môn) | Chưa ghi là ngoài SGK. | Thêm "(tham khảo, ngoài SGK)". |
| b20 thuỷ luyện (mục 2.3c, bảng so sánh 2.4, Dạng 1 bước 3, Tóm tắt, Hình 1) | Viết "thuỷ luyện thường/chủ yếu dùng cho kim loại yếu Cu, Ag, Au". SGK xếp thuỷ luyện vào nhóm tách kim loại trung bình, yếu (ví dụ Cu). Phần "kim loại quý Au, Ag" chỉ nằm trong mục Em có biết. | Viết lại: theo SGK thuỷ luyện dùng cho kim loại trung bình, yếu; "thường gặp" là Cu, Ag, Au. Đây là cách nói "thường dùng", không phải quy tắc chỉ áp dụng cho 3 kim loại. Bảng, Dạng 1, Tóm tắt sửa theo. Hình 1 thêm dòng "(thường gặp: Cu, Ag, Au)". |
| b20 khung "Tinh chế kẽm và đồng" | Viết "kẽm thô từ nhiệt luyện… điện phân dung dịch muối để làm sạch". Câu này không chính xác: kẽm điện phân thường đi từ ZnO hoà tan trong H~2~SO~4~ rồi điện phân ZnSO~4~. | Đồng thô làm anode, điện phân trong dung dịch CuSO~4~ (Bài 16 mục 3.2). Kẽm: hoà tan ZnO trong H~2~SO~4~ rồi điện phân ZnSO~4~ (ghi mở rộng). Dẫn tới mục "Em có thể" SGK tr. 98. |
| b20 mục 2.3b, "Vì sao điện phân dung dịch chỉ dùng cho kim loại từ Zn trở về sau" | Chưa nói đây là quy ước làm đề. | Thêm "Theo quy ước làm đề ở Bài 16 (ngoài SGK)". |
| b20 Ví dụ 3 | Đáp số 3,84 kg Mg trùng con số 3,84 (g Cu) là đáp án `q14` của b16. | Đổi hiệu suất thành 85%: **4,08 kg** Mg và **4,21 m^3^** Cl~2~. |
| b21 độ dài | Khoảng 5 000 chữ cho một bài 3 trang SGK. Nhiều phần trùng nhau: 2 khung "trả lời câu hỏi SGK" lặp bảng ứng dụng và bảng Tóm tắt; bảng từ khoá Dạng 1 lặp bảng so sánh ở Tóm tắt; 3 khung bẫy lặp ý. Ví dụ 2 (nhẫn 10% Cu) cùng dạng với `q20`. Ví dụ Fe – C + H~2~SO~4~ cùng dạng với `q21`. Ví dụ đốt mẫu thép cùng dạng với `q22`. | Rút từ 4 995 xuống 3 853 chữ theo `wc` (khoảng 3 550 chữ không tính markup). Bỏ 3 ví dụ thừa nêu trên, khung "Tuổi vàng", 2 khung trả lời câu hỏi SGK (thay bằng một câu dẫn tới bảng), bảng Dạng 1 (dẫn sang Tóm tắt). Gộp 3 khung bẫy thành 1. Rút gọn các đoạn "vì sao". Đánh số lại ví dụ 1–6. Đủ nội dung SGK, giữ 3 hình và 3 dạng bài. |
| b21 mục 2.4 | Nhiệt độ nóng chảy của Sn, Pb ghi số chính xác (232 °C, 327 °C). Đoạn "liên kết yếu đi ở nhiều chỗ nên nóng chảy thấp hơn" giải thích chưa chặt. | Ghi "khoảng" cho mọi số liệu nhiệt độ (sắt, gang, Sn, Pb, thiếc hàn). Bỏ đoạn giải thích, chỉ giữ ý "không có quy luật luôn thấp hơn". |
| b22 Ví dụ 1 (lớp Fe~3~O~4~, khối lượng tăng) | Khối lượng tăng 1,92 g (0,12 mol O) trùng 1,92 g O ở b20 `q27`. Cũng là đúng gấp đôi số liệu của b22 `q15` (0,96 g). | Đổi thành tăng 2,56 g → 0,16 mol O → 0,12 mol Fe → **6,72 g**. |
| b22 Ví dụ 8 (nay là Ví dụ 7) | Đáp số 1,98 L trùng với Ví dụ 8 của b16. | Đổi thành 0,03 mol CuSO~4~ → 0,07 mol H~2~ → **1,74 L**. |
| b22 `q18` ý d | Cùng tỉ lệ 5 : 1 với Ví dụ 8, chỉ chia 10 (0,65 g Zn, 0,002 mol). | Đổi thành 1,30 g Zn, 0,005 mol CuSO~4~. Chênh lệch thể tích là **0,12 L** (ý vẫn Đúng). |
| b22 `q21` ý 4 | Câu "Cr có tính khử mạnh hơn Fe" là kiến thức ngoài SGK, nhãn chưa rõ. Đề ghi "ít nhất khoảng 10%". | Lời giải ghi "Mở rộng, ngoài SGK", kèm E°(Cr^3+^/Cr) ≈ −0,74 V < −0,44 V và dẫn sang Bài 21. Đề sửa thành "ít nhất 10%" như SGK. |
| b22 mục 2.2, kim loại phủ | Liệt kê "Au, Sn, Zn, Cr, Ni" như của SGK. SGK chỉ nêu Au, Sn, Zn. Đoạn "Vì sao Zn, Sn bền" và khung đồ hộp cũng nằm ngoài SGK nhưng chưa có nhãn. | Viết "Au, Sn, Zn (SGK; mạ Cr, Ni cũng hay gặp, mở rộng)". Thêm "(mở rộng)" cho hai phần kia. |
| b22 mục 2.1, khối Mg bảo vệ ống chôn | Chưa ghi nhãn ngoài SGK. | Ghi "Mở rộng". Nối đoạn này với câu hỏi 2 SGK tr. 104 (kẽm bị ăn mòn). |
| b22 độ dài | Khoảng 7 050 chữ. Có các phần lặp: Ví dụ 2 (ống thép) lặp cơ chế vừa giảng, khung "Câu thần chú" lặp khung ghi nhớ, sơ đồ nhận diện cuối bài lặp phương pháp Dạng 1, một ý bẫy lặp. Mục 2.3 lặp phần giải thích inox của Bài 21. | Rút xuống 6 325 chữ theo `wc`. Bỏ các phần lặp nêu trên. Gộp 2 dòng Fe^3+^ trong bảng Dạng 1. Rút gọn đoạn thí nghiệm đinh sắt, khung "yếu tố làm ăn mòn nhanh hơn", ăn mòn hoá học. Mục 2.3 chỉ dẫn sang Bài 21. Đánh số lại ví dụ 1–9. |

## Đã kiểm, không có lỗi

- **Kiến thức khớp SGK.**
  - b20: Bảng 20.1 (bauxite Al~2~O~3~·2H~2~O, ZnS, Fe~2~O~3~, FeS~2~, CuFeS~2~). Nguyên tắc M^n+^ + ne → M. Điện phân nóng chảy K, Na, Ca, Mg, Al. Nhiệt luyện Zn, Fe, Sn, Pb, Cu. Các phương trình ZnS → ZnO → Zn, Fe~2~O~3~ + 3CO. Phương trình KCN/Zn tách vàng. Số liệu 75% (Al), 80% (Cu), 70%, 80%, 40%, 76% (thép). Quy trình tái chế 6 bước.
  - b21: định nghĩa hợp kim. Gang khoảng 95% Fe, 2–4% C. Thép < 2,0% C. Inox ≥ 10% Cr. Duralumin > 90% Al, khoảng 4% Cu. Au – Cu 8–12% Cu. Gang nóng chảy thấp hơn sắt.
  - b22: định nghĩa ăn mòn. 3Fe + 2O~2~ → Fe~3~O~4~. Hai quá trình ở điện cực và gỉ Fe~2~O~3~·nH~2~O. Ba điều kiện ăn mòn điện hoá đúng như SGK tr. 103. Hai phương pháp chống ăn mòn. Số liệu 25% thép ở Mỹ.
- **Câu đếm ăn mòn điện hoá đúng điều kiện SGK** (hai điện cực khác nhau, tiếp xúc trực tiếp hoặc qua dây dẫn, cùng một dung dịch chất điện li):
  - Ví dụ 2: chỉ ý b. Ý c có hai cốc riêng, không có cầu muối, nên loại.
  - Ví dụ 5: 3 thí nghiệm. Fe^3+^ với Fe, Cu chỉ là ăn mòn hoá học.
  - `q22`: 4. Fe trong ZnSO~4~ không phản ứng. Zn tinh khiết trong HCl là ăn mòn hoá học.
  - `q12`: Fe + FeCl~3~ là ăn mòn hoá học.
  - Ví dụ 6: 4 cặp Fe bị ăn mòn. `q23`: 3 cặp Fe được bảo vệ. `q29`: 4 biện pháp.
- **Đáp án b20**:
  - mcq tính toán: `q14` 14,87 L (nhiễu 11,16; 3,72; 4,96), `q15` 416 kg (nhiễu 520; 620,8; 332,8).
  - tf: `q18` 0,65 g Zn. `q19` n = 0,05; 0,25 mol CO; 25 g kết tủa; 11,6 g rắn. `q20` 800 tấn.
  - short: 5; 4; 5; 66,7; 2,38; 9,1; 16; 8,28.
- **Ví dụ b20**: Ví dụ 1 70% và 46,7%. Ví dụ 5 12,8 kg và 11,2 kg. Ví dụ 6 0,912 tấn và 3,75 tấn. Ví dụ 7 4/4. Ví dụ 8 15,2 g và 60%. Ví dụ 9 9,92 L. Ví dụ 10 400,8 kg và 2,49 tấn.
- **Đáp án b21**:
  - tf: `q16` 1,8%. `q17` 39% Zn; 6,1 g; 3,85 L SO~2~. `q18` 0,20 g; tỉ lệ 62,7; 6,58 L (ý sai 5,94 L là khi dùng 22,4).
  - short: 0,28; 3,64; 1,4; 0,9; 88 (mới); 1,94; 91,2.
  - mcq: `q13` 3,0%. `q14` 5 hợp kim.
- **Ví dụ b21**: Ví dụ 1 4 hợp kim. Ví dụ 2 3,2% (gang) / thép / inox. Ví dụ 4 90/6/4. Ví dụ 5 92% Au. Ví dụ 6 964,8 kg và 35,2 kg.
- **Đáp án b22**:
  - mcq: `q15` 2,52 g (nhiễu 3,36 FeO; 2,24 Fe~2~O~3~; 1,68).
  - tf: `q18` 0,12 L (mới). `q20` 4,4 năm (nhiễu 5,6).
  - short: 4; 3; 1,61 (mới); 0,32; 2; 428; 3,0; 4.
- **Ví dụ b22**: Ví dụ 1 6,72 g (mới). Ví dụ 3 0,031 và 0,083 mol e (gấp khoảng 2,7 lần). Ví dụ 7 1,74 L (mới). Ví dụ 8 4,45 g. Ví dụ 9 2,1 kg.
- **E° dùng thống nhất với b15**: Zn −0,762; Fe −0,44; Sn −0,137; Cu +0,340; Mg −2,356; Ni −0,257.
- **Dẫn chéo đúng mục**: Bài 15 (dãy điện hoá, pin), Bài 16 mục 2.1, 2.3, 3.1, 3.2, Bài 18, Bài 19, Bài 21 (khung inox).
- **Hình.** 9 hình đều đúng khoa học, không có chữ chồng chữ, có `<title>`, viewBox rộng 540.
  - b20: ranh giới Al | Zn, ống sứ khử oxide và nước vôi trong, 6 bước tái chế.
  - b21: thay thế và xen kẽ, thang carbon 2% / 4%, lớp trượt và electron lệch hướng.
  - b22: giọt nước Fe anode / C cathode, kẽm hi sinh trên vỏ tàu, tôn và sắt tây khi xây xát.
- **Hình thức quiz.**
  - Không gọi phương án bằng chữ A/B/C/D. Đáp số short ≤ 4 ký tự, các câu cần làm tròn đều ghi rõ.
  - Số câu: b20 có 15 mcq, 5 tf, 8 short. b21 có 14 mcq, 4 tf, 7 short. b22 có 16 mcq, 5 tf, 8 short.
  - Vị trí đáp án mcq: b20 4/4/4/3, b21 3/4/4/3, b22 4/4/4/4.
- **Bản quyền.** Không có đoạn chép nguyên văn SGK. Các thí nghiệm SGK được tóm tắt bằng lời khác và có ghi trang.

## Góp ý chưa sửa

1. b20 dài khoảng 6 600 chữ theo `wc`. Bài có 3 mục SGK và 4 dạng bài, nội dung không lặp nhiều, nên giữ nguyên (đợt này không yêu cầu rút gọn bài này).
2. Một số thể tích khí trong b21 (13,01475 L; 10,1639 L; 0,136345 L…) được chọn để ra số mol chẵn khi chia 24,79, nên trông "lẻ". Các thể tích này đúng và nhất quán, nên giữ.
3. Chỉ số dưới trong SVG (H~2~O, Al~2~O~3~) dùng cỡ chữ 10 px, giống các hình đã duyệt ở bài trước.
4. Vị trí đáp án mcq của b20 xoay vòng 0-1-2-3. Đáp án vẫn phân bố đều và app có trộn phương án, nên không đổi.
5. b22 `q23` dùng cùng nhóm kim loại với Ví dụ 6 (cặp Fe – X) nhưng hỏi chiều ngược lại (Fe được bảo vệ), đáp số khác (3 so với 4). Đây là ôn kiến thức chứ không lộ đáp số, nên giữ.
