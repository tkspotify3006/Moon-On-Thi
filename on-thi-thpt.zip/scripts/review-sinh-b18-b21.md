# Biên bản thẩm định — Sinh 12, Bài 18 và Bài 21

Ngày: 2026-10-29 · Người thẩm định: Claude (độc lập với người soạn)

Đối chiếu SGK Sinh học 12 KNTT:
- Bài 18 "Di truyền học quần thể": PDF tr. 93–98, tức sách tr. 91–96 (tr. 96 là Sơ đồ tóm tắt chương 4).
- Bài 21 "Học thuyết tiến hóa tổng hợp hiện đại": PDF tr. 108–114, tức sách tr. 106–112.

Script giải lại: `/tmp/claude-0/-home-claude/3b17551e-f73f-5a71-ad7d-e845d5a87acd/scratchpad/rv-sinh-b18b21/kt.py`. Script tính lại mọi đáp số quiz (cả số liệu mới sau khi sửa) và mọi ví dụ có số liệu trong bai.md. Các ví dụ gồm:
- Hardy – Weinberg, tự thụ phấn (xuôi và ngược), tần số allele khác nhau ở hai giới, ABO, gene trên X, hôn nhân họ hàng (F = 1/16);
- dòng gene 1 và 2 thế hệ, chọn lọc loại aa (q/(1 + q), q~n~), giá trị thích nghi, phiêu bạt, đếm NST lai xa.

`node scripts/kiem-tra.mjs` cho kết quả **0 lỗi** trên cả repo thật và bản sao có bật `ready` cho sinh b18, b21. Trên repo thật, b18 và b21 chỉ có cảnh báo "chưa ready".

App (390×844, `python3 -m http.server 8814` chạy trên bản sao):
- 2 bài và 2 quiz: 0 `.katex-error`, console sạch, không ảnh hỏng, `scrollWidth` = 390;
- các bảng 3–5 cột đều đọc được.

Hình SVG (7 hình): đã render bằng Playwright và xem từng ảnh. Chữ nhỏ nhất 12px, không có chữ chồng. Nội dung đúng khoa học:
- b18 Hình 1: 4 AA, 4 Aa, 2 aa → p = 0,6.
- b18 Hình 3: khớp Bảng 18.2.
- b21 Hình 1: đếm lại từ mã SVG được 5/10/5 → p = 0,5; trên đảo 4 AA + 4 Aa → p = 0,75; còn 3 AA → p = 1.
- b21 Hình 2: q~n~ = 0,5/(1 + 0,5n), tại n = 10 được 0,083.
- b21 Hình 4: khớp Hình 21.3 SGK.

## 1. Kết quả giải lại quiz

| Bài | Số câu | Đáp án sai | Ghi chú |
|---|---|---|---|
| b18 | 28 (15 mcq · 5 tf · 8 short) | 0 | Đáp số short (sau sửa): 0,8 · 0,36 · 3,9 · 6 · 3,0 (1/33) · 0,18 · 0,30 · 18. q19: 2/21 và 1/441; q20: 0,36%, 3,18%, 11,3%. Vị trí đáp án mcq 4/4/4/3. |
| b21 | 28 (15 mcq · 5 tf · 8 short) | 0 | Đáp số short: 0,12 · 0,23 · 20 · 18 · 0,4 · 100 · 0,35 · 2,8. q20: 94,7% và 0,526. Vị trí đáp án mcq 4/4/3/4. |

Các ví dụ trong bai.md đều tính đúng:
- b18 VD1–VD9: 0,625; F~1~ 0,49 : 0,42 : 0,09; 0,0198; 0,575/0,05/0,375; đàn bò cân bằng (p = 0,65); 1/36; P = 0,35 : 0,4 : 0,25; ABO 0,3/0,4/0,3, B = 27%, AB = 24%.
- b21: VD1 0,7 → 0,3; VD2 0,26; VD3 1/3, 1/9, 8 thế hệ, 0; VD4 p = 0,6 không đổi; VD7 0,5 → 0,8; VD8 0,414 và 4/9; VD9 17/34/24.

Không câu nào gọi phương án bằng A/B/C/D. Câu short đều có ≤ 4 ký tự và đề nói rõ cách làm tròn.

## 2. Lỗi đã sửa

### Nghiêm trọng (8)
1. **b18 q24 lộ đáp số.** Ý 4 của q18 (cùng y = 0,8) có `why` ghi sẵn "n = 5 thì Aa = 0,025", trùng nguyên đề q24 (80% → 2,5%, n = 5). Đã đổi q24 thành 64% → 1%, đáp số **6**.
2. **b18 q11 lộ đáp số.** Câu hỏi AA ở G~3~ khi xuất phát toàn Aa (7/16), nhưng con số này có sẵn trong bảng bài học, Hình 3 và Bảng 18.2 SGK. Đã đổi thành G~5~ → **31/64**. Các nhiễu là 1/32, 15/32, 63/128.
3. **b18 q15 lộ đáp số.** Bài học viết sẵn "4 allele → 10 kiểu gene". Đã đổi thành 5 allele → **15**. Các nhiễu là 25, 10, 30.
4. **b18 q10 lộ đáp số.** Đề cho 9% aa → Aa = 0,42, đúng các số của Hình 2 và Ví dụ 2. Đã đổi thành 2,25% aa → **0,255**. Các nhiễu là pq, p^2^, 1 − q^2^.
5. **b18 q27 lộ chéo đáp số.** `explain` q27 ghi aa = 0,3625, trùng đáp số q22. Đáp số cũ 0,16 cũng có sẵn trong ý 3 của q17. Đã đổi P thành 0,3 : 0,3 : 0,4 → aa = **0,30**. Thêm bẫy "lấy luôn aa = 0,5125 của thế hệ tự thụ".
6. **b21 q21 trùng đáp số với Ví dụ 2** (m = 0,1). Đã đổi số liệu thành 440 + 60 → **0,12**.
7. **b21 mục 2.5: sai khoa học.** Ví dụ giao phối có lựa chọn "con cái chỉ chọn con đực có màu sắc, tiếng hót nổi bật" là chọn lọc giới tính, làm thay đổi tần số allele. Ví dụ này mâu thuẫn với câu ngay sau "cả hai kiểu đều không làm thay đổi tần số allele". Đã thay bằng giao phối theo kiểu hình giống mình (cây cao với cây cao).
8. **b21 mâu thuẫn với b20 (bảng so sánh Darwin – thuyết tổng hợp).**
   - Bảng cũ ghi "Đơn vị chịu tác động: Darwin = cá thể, hiện đại = quần thể". Ghi như vậy dễ hiểu sai, vì theo chính b21 chọn lọc vẫn tác động trực tiếp lên kiểu hình cá thể.
   - Dòng "Thước đo: sự thay đổi đặc điểm sinh vật" không khớp b20. b20 viết Darwin = "tăng dần tần số cá thể mang biến dị có lợi".
   - Đã viết lại các dòng cho khớp b20: nguồn biến dị (chưa rõ nguồn gốc và cơ chế di truyền); "chọn lọc tác động lên" (Darwin: từng cá thể; hiện đại: kiểu hình cá thể, kết quả ở quần thể); cách mô tả tiến hóa. Bảng có thêm nhãn "tổng hợp, ngoài SGK".

### Lỗi nhỏ (14)
9. **b21 rút gọn** từ 8 887 xuống 7 543 từ (đếm bằng `wc -w`, tính cả dấu `>`; phần chữ thực ≈ 7 000). Không cắt nội dung SGK. Các thay đổi:
   - bỏ Ví dụ 7 (Karpechenko, ngoài SGK, trùng kĩ năng với Dạng 3) và thay bằng đoạn ngắn đọc Hình 4 lúa mì theo SGK; đánh số lại VD 8–10 → 7–9;
   - bỏ khung "Chìa khóa chung" vì trùng phần Tóm tắt;
   - bỏ khung ghi-nho "Đột biến" vì trùng bảng 2.6;
   - bỏ khung bẫy mẫu số m vì trùng gợi ý; đã gộp vào lời giải;
   - gộp đoạn vân sam vào khung bẫy;
   - nén phép ước lượng đột biến, danh sách đặc điểm phiêu bạt, đoạn penicillin, Ví dụ 5, mục tiêu, nền tảng và Tóm tắt.
10. **b21 thêm nhãn "mở rộng, ngoài SGK"** cho các phần sau trong bài: công thức chọn lọc loại aa, giá trị thích nghi w, Dạng 2, lí do đa bội hay gặp ở thực vật. Thêm nhãn "(Dạng mở rộng, ngoài SGK.)" vào `explain` của q13, q22, q23, q26, q27, q28. Phần ngoài SGK chiếm khoảng 6/28 câu.
11. **b18 thêm nhãn ngoài SGK** vào `explain` của q14 và q26. Các câu q15, q20, q28 đã có nhãn. Phần ngoài SGK chiếm khoảng 5/28 câu.
12. **b18 q26** dùng đúng bộ tần số của q14 (p = 0,5, q = 0,3, r = 0,2). Đã đổi thành 1% trắng, 48% xám → p = 0,3 → **0,18**.
13. **b21 q12:** nhiễu "48" không ứng với lỗi nào. Đã thay bằng "25" (cộng nhầm 2n~A~ + n~B~) và bổ sung `explain`.
14. **b21:** "chuối tam bội không hạt tạo bằng lai 4n × 2n" là không chính xác (chuối nhà là tam bội tự nhiên). Đã chỉ giữ ví dụ dưa hấu.
15. **b21:** số liệu không chắc "sao la, voọc… có vốn gene nghèo nàn" đã viết thận trọng thành "dễ bị phiêu bạt làm mất allele".
16. **b21:** "vi khuẩn kháng thuốc thường sinh trưởng chậm hơn" đã đổi thành "có thể", ở cả bai.md và why của q17.
17. **b21:** `$q_{\text{mới}}$` gây cảnh báo KaTeX (chữ Việt trong chế độ toán). Đã đổi thành `q'`.
18. **b21:** "Muốn biết loài mới là loài nào" đã sửa thành "Muốn khẳng định là loài mới".
19. **b21:** khung ứng dụng kháng sinh đổi thành "dùng khi cần và theo đúng chỉ định".
20. **b18:** "các nhân tố tiến hoá ở chương sau" đã sửa thành "ở Bài 21".
21. **b18 q27:** đề đổi thành "(làm tròn đến hàng phần trăm)" cho khớp đáp số 0,30.
22. **JSON:** b18/quiz.json được định dạng lại (indent 2) khi sửa. Mọi `id` câu giữ nguyên.

## 3. Nhận xét
- **b18** đủ nội dung SGK tr. 91–95. Phần giảng "bể giao tử" và công thức tự thụ rất rõ. Phần mở rộng (nhiều allele, gene trên X, hai giới khác tần số, họ hàng gần) đúng và có nhãn. Không chép bài tập SGK: bài tập 3 MN 182/172/44 không xuất hiện.
- **b21** đủ năm nhân tố, thích nghi, tính tương đối, loài sinh học, hai con đường hình thành loài, Hình 21.3. Sau khi sửa, bài nhất quán với b20 về Darwin: Darwin dùng biến dị cá thể và tần số cá thể; thuyết hiện đại dùng tần số allele và quần thể.
- Ngoài phạm vi được sửa: catalog ghi tên b18 là "Di truyền quần thể", còn SGK ghi "Di truyền học quần thể". Cảnh báo KaTeX "ả" còn lại đến từ toan/on-5, on-6.
