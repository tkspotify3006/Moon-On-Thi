# Biên bản thẩm định Hóa 12: b27, b28

- b27: Đại cương về kim loại chuyển tiếp dãy thứ nhất (SGK tr. 128–133, PDF 130–135)
- b28: Sơ lược về phức chất (SGK tr. 134–137, PDF 136–139)

Ngày 29/10/2026.

Cách kiểm:
- Đọc lại từng trang SGK của hai bài, đối chiếu với bai.md: Bảng 27.1–27.4, phương trình chuẩn độ, hai thí nghiệm, Bảng 28.1, mục Em có biết (cầu nội, cầu ngoại), phức aqua.
- Giải lại độc lập toàn bộ quiz (b27: 28 câu, b28: 27 câu) và mọi ví dụ có số liệu bằng python (`scratchpad/rv-hoa-b27-b28/kt.py`). Đếm lại các câu "có bao nhiêu".
- Render 8 hình SVG bằng Playwright và tự xem từng hình.
- Mở 2 bài và 2 quiz trong app (390×844, bản sao repo, cổng 8813): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390, không có ảnh hỏng.
- `kiem-tra.mjs`: 0 lỗi (cảnh báo "chưa ready" là bình thường).

## Lỗi nghiêm trọng đã sửa (4)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b28 `q24` (short, số electron Fe^3+^ nhận trong [Fe(H~2~O)~6~]^3+^) | Lộ đáp số: lời giải Ví dụ 8 viết sẵn "M nhận 12 electron" cho mọi phức bát diện. Câu lại xếp mức 3 dù chỉ nhân 6 × 2. | Đổi thành tổng số liên kết cho – nhận của [Cu(H~2~O)~6~]^2+^, [Ni(CO)~4~], [Ag(NH~3~)~2~]^+^, [PtCl~2~(NH~3~)~2~] → **16**, mức 2. Bỏ cụm "(M nhận 12 electron)" ở Ví dụ 8. |
| b28 `q23` (short, đếm phức bát diện) | Cùng dạng, cùng đáp số 3 với Ví dụ 8, trùng 2 chất ([PtCl~4~]^2−^, [Ag(NH~3~)~2~]^+^). | Đổi dãy chất, thêm [Ni(CO)~4~] và [CrCl(NH~3~)~5~]^2+^ (phức nhiều loại phối tử, 1 + 5 = 6) → **4**. |
| b28 `q11` (mcq, Fe^3+^ + 6F^−^) | Gần như chép Ví dụ 2a (Fe^3+^ + 6CN^−^ → điện tích −3). | Đổi thành Co^2+^ + 4Cl^−^ → [CoCl~4~]^2−^. Nhiễu ^2+^ (quên dấu phối tử), ^4−^ (bỏ điện tích Co^2+^), ^6−^ (trừ nhầm). |
| b28 `q18` ý 3 | Zn^2+^ nhận 8 electron, trùng đúng ion và đáp số của Ví dụ 5 ([Zn(NH~3~)~4~]^2+^, 8 electron). | Đổi thành ý hình học: "Zn^2+^ và 4 nguyên tử O cùng một mặt phẳng" → Sai (đề đã cho tứ diện). |

## Theo yêu cầu: giảm câu dạng Cl^−^ cầu ngoại + AgNO~3~ (mở rộng)

Trước có 4 câu (q13, q15 ý 4, q19, q27). Giữ **2 câu**: `q19` (tf, X/Y/Z của CoCl~3~·nNH~3~, vận dụng cao) và `q27` (short, PtCl~4~·4NH~3~, đáp số 2). Hai câu còn lại đổi sang nội dung SGK:
- `q13` (mcq, mức 3): phức Fe^3+^ bát diện, phối tử H~2~O và OH^−^, điện tích +2 → [Fe(OH)(H~2~O)~5~]^2+^. Nhiễu: [Fe(H~2~O)~6~]^2+^ (sai nguyên tử trung tâm), [Fe(OH)~2~(H~2~O)~4~]^2+^ (sai điện tích), [Fe(OH)(H~2~O)~3~]^2+^ (chỉ 4 phối tử).
- `q15` ý 4: "cầu nội [Co(NH~3~)~6~]^3+^ vuông phẳng vì có 4 NH~3~ cùng mặt phẳng với Co^3+^" → Sai (6 phối tử, bát diện). Thứ tự ý vẫn Đ–S–Đ–S.

Trong bai.md vẫn giữ khung Em có biết và Dạng 3 (Ví dụ 9, [CrCl(H~2~O)~5~]Cl~2~·H~2~O), đều đã ghi rõ mở rộng. Câu "Đề thi hay khai thác ý này" sửa thành "Một số đề luyện thi khai thác ý này".

## Lỗi nhỏ đã sửa (7)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| b27 mục 2.1, nhận xét 1 | SGK Bảng 27.3 ghi "khó nóng chảy, đặc biệt là V, Cr và **cobalt**", nhưng theo Bảng 27.2 Co (1 494 °C) thấp hơn Ti, Sc, Fe. Bài bỏ cobalt mà không nói vì sao. | Ghi thứ tự V (1 917) > Cr (1 907) > Ti (1 668). Thêm khung bẫy "Đọc số liệu, đừng chỉ đọc lời": nêu chỗ chưa khớp này trong SGK; nếu hỏi kim loại khó nóng chảy nhất thì so số liệu (V, rồi Cr). Ghi rõ Sc in "1,541" trong SGK nghĩa là 1 541 °C. |
| b27 Ví dụ 8 | Ý a, b là nguyên văn yêu cầu 1a, 1b SGK tr. 130. | Ý a đổi ngưỡng thành 1 500 °C → **5** kim loại (bẫy Sc 1 541, Fe 1 535). Thêm một dòng hướng dẫn em tự làm câu 1a SGK. Ý b giữ nguyên (khái niệm kim loại nặng). Không trùng `q23` (ngưỡng 1 600 → 3). |
| b27, tất cả các số có dấu cách hàng nghìn | Trong bảng 9 cột ở 390 px, "1 541" bị xuống dòng thành "1 / 541", đọc nhầm. | Thay dấu cách hàng nghìn bằng dấu cách không ngắt (NBSP) trong bai.md (30 chỗ) và quiz.json (25 chỗ). Đã chụp lại: bảng hiển thị gọn trên một dòng. |
| b27 giải thích ngoại lệ Cr, Cu | Lời giải thích d^5^/d^10^ bền không có trong SGK nhưng chưa có nhãn. | Thêm "(giải thích thêm, ngoài SGK)". |
| b27 khung bẫy chuẩn độ | Viết "axit hoá". | Sửa thành "acid hoá" theo thuật ngữ SGK. |
| b27 `q20` | Đề ghi "khoảng 2,0 mL" nhưng ý d tính khối lượng kết tủa chính xác 0,196 g. | Bỏ chữ "khoảng". |
| b27 Tóm tắt | "Khó nóng chảy (V, Cr > 1 900 °C)" | "(cao nhất V, Cr > 1 900 °C)". |

## Đã kiểm, không có lỗi

- **Cấu hình Cr/Cu**: Cr [Ar]3d^5^4s^1^, Cu [Ar]3d^10^4s^1^ đúng Bảng 27.1. Ion: Fe^2+^ 3d^6^, Fe^3+^ 3d^5^, Cr^3+^ 3d^3^, Mn^2+^ 3d^5^, Cu^2+^ 3d^9^, Cu^+^ 3d^10^, V^3+^ 3d^2^, Co^2+^ 3d^7^. Hình 1 đúng quy tắc Hund cho cả 9 nguyên tố. Ví dụ 7: X^3+^ 3d^3^ → Cr, Y^2+^ 3d^9^ → Cu.
- **Tỉ lệ chuẩn độ**: phương trình SGK cân bằng (S: 18 = 18). n(Fe^2+^) = 5·n(KMnO~4~), Mn +7 → +2 nhận 5e. Ví dụ 5 0,097 M; Ví dụ 9 96,4%; `q14` 0,0625 M (nhiễu 0,0125, 0,025, 0,3125 ứng đúng lỗi đã nêu); `q19` 5,1 mL, 0,102 M (ý sai 0,0204 là quên hệ số 5); `q25` 1,05; `q26` 65; `q27` 50.
- **Bảng 27.2** chép đúng cả 45 số. Khối lượng riêng tăng đơn điệu từ Sc đến Cu (nhận xét trong khung bẫy đúng). Ví dụ 2a 1,75; `q17` ý d 4,46 kg; `q28` 1,68 → 1,7; `q23` 3; `q22` 7; `q24` 4. Số liệu K, Ca (63,4; 842; 0,89; 1,55; 13,3; 28,5; 0,4; 1,75) khớp SGK tr. 130.
- **b28**: điện tích phức, nguyên tử trung tâm (Ví dụ 1, 2, 3, 7; `q10` Cr^3+^; `q21` 2; `q22` 3). Ví dụ 9 0,04 mol AgCl; `q19` 0,03/0,02/0,01 mol, ion phức Z +1, 0,02 mol ion; `q25` 4,5 g; `q26` 22,1%; `q27` 2.
- **Hình học 4 phối tử**: bài nói rõ chỉ đếm 4 phối tử thì chưa đủ, đề phải cho thêm dữ kiện. Ví dụ 4, 8, `q14`, `q18` đều cho dữ kiện; `q23` chỉ hỏi bát diện nên không cần. Ví dụ trong bảng đúng ([Zn(OH)~4~]^2−^, [Ni(CO)~4~] tứ diện; [PtCl~4~]^2−^, [PtCl~2~(NH~3~)~2~] vuông phẳng).
- **Hình.** 8 hình đúng khoa học, không có chữ chồng chữ, có `<title>`, viewBox rộng 540. Chữ chính ≥ 12 px; chỉ chỉ số trên/dưới (tspan) là 10 px, giống các bài trước.
- **Hình thức quiz.** Không gọi phương án bằng A/B/C/D. Short ≤ 4 ký tự, có ghi làm tròn khi cần. b27: 15 mcq, 5 tf, 8 short. b28: 14 mcq, 5 tf, 8 short. Vị trí đáp án mcq phân bố đều. `q03` b28 có `"fixed": true` (đáp án là dãy số tăng dần), đúng quy ước.
