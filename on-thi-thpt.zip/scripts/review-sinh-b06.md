# Biên bản thẩm định Sinh 12: b06 Thực hành: Tách chiết DNA

SGK Sinh học 12 KNTT tr. 32–34 (PDF 34–36). Ngày 29/10/2026.

Cách kiểm:
- Đọc lại 3 trang SGK (chuẩn bị, lưu ý chọn mẫu, nguyên lí 4 ý, lưu ý diphenylamine, 5 bước, Hình 6.1, câu hỏi thu hoạch a–d). Đối chiếu với bai.md.
- Giải lại các ví dụ và quiz có số liệu bằng python (`scratchpad/rv-sinh-b06/kt.py`). Đếm lại các câu "có bao nhiêu".
- Dò số liệu và nội dung trùng với b05 mục 4 (bảng tóm tắt tách chiết) và b01.
- Render 2 hình SVG bằng Playwright, xem ảnh. Mở bài và quiz trong app (390×844, bản sao repo có bật `ready`, cổng 8811): không có `.katex-error`, không có lỗi console, `scrollWidth` = 390, không có ảnh hỏng.
- `kiem-tra.mjs`: 0 lỗi.

## Lỗi nghiêm trọng đã sửa (1)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| Ví dụ 4a và `q14` ý 2 (bỏ bước nước rửa bát) | Giải thích "DNA bị giữ trong nhân và **bị lọc bỏ cùng cặn**". Sai trình tự: theo SGK, lọc (bước 2) làm **trước** khi thêm nước rửa bát (bước 3), nên bỏ chất tẩy rửa không làm nhân bị lọc bỏ. Học sinh sẽ hiểu sai thứ tự quy trình, trong khi Dạng 1 và `q13` hỏi đúng thứ tự này. | Viết lại: màng không bị phá nên DNA vẫn nằm trong nhân, không ra dịch chiết, hầu như không có kết tủa (ghi rõ bước lọc đã làm trước đó). Kết luận Đúng của `q14` ý 2 giữ nguyên. |

## Lỗi nhỏ đã sửa (4)

| Chỗ | Sai gì | Sửa gì |
|---|---|---|
| Mục 1 | "gom **hàng triệu tỉ** phân tử DNA từ hàng trăm triệu tế bào". Phép tính không khớp: 10^8^–10^9^ tế bào × vài chục NST là khoảng 10^10^ phân tử. | Sửa thành "hàng chục tỉ". |
| Mục 3.3, "Vì sao phải dùng cồn lạnh?" | Phần giải thích (DNA khó tan hơn, nuclease chậm lại) là ngoài SGK nhưng chưa có nhãn. SGK chỉ ghi "cồn ethanol lạnh". | Thêm nhãn "SGK chỉ yêu cầu cồn lạnh, phần giải thích dưới đây là mở rộng". |
| Mục 3.3, bọt khí giúp DNA nổi | Chưa có nhãn ngoài SGK. | Thêm "mở rộng:". |
| Khung ứng dụng | Viết "giám định ADN", không đúng thuật ngữ SGK 2018. | Sửa thành "giám định DNA". |

## Đã kiểm, không có lỗi

- **Kiến thức khớp SGK**:
  - Dụng cụ, hoá chất: ¼ quả dứa, 500 mL nước rửa bát, cồn lạnh 70–95%.
  - Lưu ý chọn mẫu: thực vật nhiều nước, ít DNA, có sắc tố; khoảng 5 g gan, 50 g thực vật; mỗi nhóm một loại mẫu.
  - Nguyên lí: nghiền phá mô; chất tẩy rửa hoà tan lipid màng; protease của dứa cắt protein (histone…) thành amino acid và peptide, còn DNA, RNA; ethanol có ái lực với nước mạnh hơn nên DNA kết tụ thành chất trắng đục; ethanol nhẹ hơn nên tạo lớp trên; DNA kết tủa dễ gãy.
  - Diphenylamine ở nhiệt độ cao cho màu xanh lam.
  - Đủ 5 bước với các số liệu: 30–60 giây, 150 mL nước lạnh, 30 mL nước rửa bát, 5–10 phút, 1/3–1/2 ống, 5 mL nước dứa, 10 phút, rót cồn theo thành ống.
  - Trả lời đủ 4 câu thu hoạch a–d.
  - Phần ngoài SGK có nhãn hoặc là kiến thức chuẩn: bromelain, papain, actinidin, proteinase K, isopropanol, thêm muối ăn (khung Em có biết), hồng cầu thú không nhân / chim có nhân, biuret.
- **Số liệu**:
  - Ví dụ 1: 2,176 m; 6,37 pg ≈ 6,4 pg; 1,57×10^8^ tế bào.
  - Ví dụ 3: 4 / 3,6 / 0,3 / 0,12 mg/g; tỉ lệ 13.
  - Ví dụ 2: thứ tự b → d → e → a → c → g.
  - Ví dụ 5: 2 phát biểu đúng.
  - Quiz:
    - `q16`: 3 (dứa tươi, đu đủ xanh, kiwi).
    - `q17`: 0,816 m → 0,8.
    - `q18`: 2,39 mg → 2,4 (quên nhân 2 thì ra 1,2).
    - `q19`: 12 (so thẳng thì ra 1,2).
    - `q20`: 0,96V = 0,7(V + 12) → 32,3.
- **Hình**:
  - Hình 1: 5 bước bóc từng lớp, đánh số khớp các bước SGK.
  - Hình 2: lớp cồn nằm trên dịch chiết, DNA kết tủa ở ranh giới và đi lên lớp cồn, đũa xoay nhẹ.
  - Đúng khoa học, chữ ≥ 12 px, không có chữ chồng chữ.
- **Hình thức quiz**:
  - Có 20 câu: 11 mcq, 4 tf, 5 short.
  - Mức độ: 7 câu mức 1, 7 câu mức 2, 6 câu mức 3.
  - Vị trí đáp án mcq: 3/3/3/2. Chỉ 1/11 câu có đáp án là phương án dài nhất.
  - Không gọi phương án bằng A/B/C/D. Đáp số short ≤ 4 ký tự và có ghi cách làm tròn.
  - Mỗi câu tf có cả ý Đúng lẫn ý Sai.

## Góp ý chưa sửa

1. Bài dài khoảng 4 600 chữ theo `wc`, trong khi brief đề xuất 2 000–3 000 chữ cho bài thực hành. Bài vẫn tương đương các bài thực hành đã duyệt (b14 khoảng 5 300, b17 khoảng 4 100) và không lặp nhiều, nên giữ.
2. `q19` cùng dạng với Ví dụ 3 (gan gà so với chuối, tính mg/g), nhưng số liệu và đáp số khác (12 so với 13). Đây là luyện cùng dạng, không lộ đáp số.
3. `q20` (pha cồn 96% đến 70%) là bối cảnh phòng thí nghiệm ngoài SGK. Đề đã cho đủ dữ kiện, nên giữ làm câu vận dụng.
